/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/paging/paging.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:30:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * declares paging structures, defines, etc.
 *
 */

#ifndef IA32_IA32_PAGING_H
#define IA32_IA32_PAGING_H	1


#endif
