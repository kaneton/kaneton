/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/pmode/ldt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 20:13:58 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:58:02 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage global descriptor table.
 *
 */


/*
 * ---------- assignments -----------------------------------------------------
 *
 * this is the good place to put code dealing with ldt.
 *
 */


/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

