/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/pmode/gdt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:45:19 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:57:21 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage global descriptor table.
 *
 */


/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have  to place here code to manage  gdt. there are no
 * restrictions on prototypes, names etc.
 *
 */

/*
 * ---------- Macros ----------------------------------------------------------
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

/*
** Creates a GDT entry, being given the adress where to place it (sd)
** The GDT entry is dependant of :
** - dp for dpl segment ?
** - code or data space ?
*/
void	set_segment_descriptor(	t_uint8 dpl,
					t_uint8 type,
					struct gdt_segment_descriptor* sd)
{
  sd->segment_limit_15_0 = 0xFFFF;
  sd->base_address_15_0 = 0x0000;
  sd->base_address_23_16 = 0x00;
  sd->segment_type = type;
  sd->descriptor_type = 0x1;
  sd->dpl = dpl;
  sd->segment_present = 0x1;
  sd->segment_limit_19_16 = 0xF;
  sd->avl = 0x0;
  sd->bit64 = 0x0;
  sd->operation_size = 0x1;
  sd->granularity = 0x1;
  sd->base_address_31_24 = 0x00;
}

/*
** enters protected mode
** 'gdt' is the start address of the gdt
** 'size' is the gdt's number of entries (the starting 'null' included)
*/
int   set_gdt(struct gdt_segment_descriptor* gdt, t_uint16 size)
{
  struct gdt_segment_register gdtr;

  /* creating gdtr register */
  gdtr.limit = size * 8;
  gdtr.base = (t_uint32) gdt;

  /* setting gdt */
  asm("lgdt %0\n\t"
      :
      : "m" (gdtr));

  /* going into protected mode */
  asm (	"mov %%cr0,%%eax\n\t"
	"orl %%eax, 1\n\t"
        "mov %%eax,%%cr0"
      :
      :
      : "eax");

  /* updating segment registers */
  asm(	"ljmp $0x8, $lbl  \n\t"
        "lbl:             \n\t"
	"movw $0x10, %%ax \n\t"
        "movw %%ax,  %%ss \n\t"
        "movw %%ax,  %%ds \n\t"
        "movw %%ax,  %%es \n\t"
        "movw %%ax,  %%fs \n\t"
        "movw %%ax,  %%gs"
	:
	:
	: "eax" );

  return 0;
}

