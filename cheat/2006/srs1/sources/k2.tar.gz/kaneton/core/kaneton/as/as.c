/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/as/as.c
 *
 * created       julien quintard   [tue dec 13 03:05:27 2005]
 * updated       matthieu bucchianeri   [fri jan 27 18:11:14 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the address space manager manages address spaces.
 *
 * an address space describes process' useable memory. each address space
 * is composed of two sets.
 *
 * the first describes the segments held by this address space, in other
 * words the physical memory.
 *
 * the latter describes the regions, the virtual areas which reference
 * some segments.
 *
 * a task can give its address space to another with as_give.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the address space manager builds address space objects.
 *
 * every address space object is essentially composed of two sets: a
 * set of segments which list the segments held by this address space and
 * a set of regions which describes the useable virtual address ranges.
 *
 * the student just has to write the functions to reserve, release, get etc..
 * an address space.
 *
 * note that the address space does nothing more. indeed, the segment
 * manager and the region manager will add and/or remove the segments/regions
 * to/from the address space by their own.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(as);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the address space manager variable.
 */

m_as*			as = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
** This function shows a precise address space displaying information on it
*/
t_error	  as_show(t_asid  asid)
{
  o_as*		oas;
  t_error	error;

  AS_ENTER(as);

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "as: impossible to release an as\n");
      AS_LEAVE(as, error);
    }

  printf("---- as %i ----\n", asid);

  set_show(oas->regions);
  set_show(oas->segments);

  AS_LEAVE(as, ERROR_NONE);
}

/*
** This function dumps all the address space manager
*/
t_error	  as_dump(void)
{
  t_state	state;
  t_iterator	iterator;

  AS_ENTER(as);

  set_foreach(SET_OPT_FORWARD, as->container, &iterator, state)
    if (as_show(((o_as*)(iterator.u.ll.node->data))->asid) != ERROR_NONE)
      cons_msg('!', "as: impossible to show as %i\n", ((o_as*)(iterator.u.ll.node->data))->asid);

  AS_LEAVE(as, ERROR_NONE);

}

/*
** This function clones an address space taking care of cloning everything necessary
** for k2, task argument ignored
*/
t_error	  as_clone(t_tskid  task, t_asid   old, t_asid*  new)
{
  t_error error;
  o_as*	oas;
  o_as*	new_oas;

  AS_ENTER(as);

  if ((new_oas = malloc(sizeof (o_as))) == NULL)
    {
      cons_msg('!', "as: impossible to clone as no memory\n");
      AS_LEAVE(as, ERROR_NO_MEMORY);
    }

  if ((error = as_get(old, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "as: impossible to get an as\n");
      AS_LEAVE(as, error);
    }

  memcpy(new_oas, oas, sizeof(o_as));

  if ((error = id_reserve(&as->id, (t_id*)new)) != ERROR_NONE)
    {
      cons_msg('!', "as: unable to reserve an identifier\n");
      return error;
    }

  new_oas->asid = *new;

  if ((error = set_clone(oas->segments, &(new_oas->segments))) != ERROR_NONE)
    AS_LEAVE(as, error);
  if ((error = set_clone(oas->regions, &(new_oas->regions))) != ERROR_NONE)
    AS_LEAVE(as, error);

  if ((error = set_add(as->container, new_oas)) != ERROR_NONE)
    {
      cons_msg('!', "as: impossible to aadd new clone as\n");
      AS_LEAVE(as, error);
    }

  free(new_oas);

  AS_LEAVE(as, ERROR_NONE);
}

/*
** This function reserves an address space object for the task 'task'
*/
t_error	  as_reserve(t_tskid  task, t_asid*   asid)
{
  o_as oas;
  t_error error;

  AS_ENTER(as);

  oas.tskid = task;

  if ((error = id_reserve(&(as->id), &(oas.asid))) != ERROR_NONE)
    {
      cons_msg('!', "segment: unable to reserve an identifier\n");
      AS_LEAVE(segment, error);
    }
  if ((error = set_reserve(array, SET_OPT_SORT | SET_OPT_ALLOC,
			   sizeof(t_segid), SET_ARRAY_SIZE, &oas.segments)) != ERROR_NONE)
  {
    cons_msg('!', "segment: unable to reserve set for as segments\n");
    AS_LEAVE(segment, error);
  }
  if ((error = set_reserve(array, SET_OPT_SORT | SET_OPT_ALLOC,
			   sizeof(t_segid), SET_ARRAY_SIZE, &oas.regions)) != ERROR_NONE)
  {
    cons_msg('!', "segment: unable to reserve set for as regions\n");
    AS_LEAVE(segment, error);
  }
  set_add(as->container, &oas);
  *asid = oas.asid;

  if ((error = machdep_call(as, as_reserve, task, asid)) != ERROR_NONE)
    AS_LEAVE(as, error);

  AS_LEAVE(as, ERROR_NONE);
}

/*
** This function releases an address space
*/
t_error		as_release(t_asid   asid)
{
  t_error	error;
  o_as*		oas;
  t_iterator	iterator;
  t_state	state;

  AS_ENTER(as);

  /*
   * 1)
   */
  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "as: impossible to get an as\n");
      AS_LEAVE(as, error);
    }

  if ((error = segment_flush(asid)) != ERROR_NONE)
    {
      cons_msg('!', "as: impossible to flush segments of this as\n");
      AS_LEAVE(as, error);
    }
  /*
   * 2)
   */
  if ((error = set_release(oas->segments)) != ERROR_NONE)
    {
      cons_msg('!', "as: impossible to release a segment\n");
      AS_LEAVE(as, error);
    }

  /*
   * 3)
   */
  if ((error = set_release(oas->regions)) != ERROR_NONE)
    {
      cons_msg('!', "as: impossible to release a region\n");
      AS_LEAVE(as, error);
    }

  /*
   * 4)
   */
  if ((error = set_remove(as->container, asid)) != ERROR_NONE)
    {
      cons_msg('!', "as: impossible to remove an as\n");
      AS_LEAVE(as, error);
    }

  AS_LEAVE(as, ERROR_NONE);
}


/*
** This function should only be used by the segment and region managers.
** This function just returns the address space object corresponding to
** the address space identifier.
*/
t_error	  as_get(t_asid	asid, o_as** o)
{
  t_iterator	iterator;
  t_error	error;

  AS_ENTER(as);

  if ((error = set_locate(as->container, asid, &iterator)) != ERROR_NONE)
    {
      cons_msg('!', "as: impossible to get as\n");
      AS_LEAVE(as, error);
    }

  *o = (o_as*)iterator.u.ll.node->data;

  AS_LEAVE(as, ERROR_NONE);
}


/*
** This function initializes the address space manager.
*/
t_error	  as_init(void)
{
  t_error error;

  /*
   * 1)
   */
  if ((as = malloc(sizeof(m_as))) == NULL)
    {
      cons_msg('!', "as: cannot allocate memory for the as manager "
	       "structure\n");
      return (ERROR_NO_MEMORY);
    }

  memset(as, 0x0, sizeof(m_as));

  /*
   * 2)
   */
  if ((error = id_build(&as->id)) != ERROR_NONE)
    {
      cons_msg('!', "as: unable to initialise the identifier object\n");
      return (error);
    }

  /*
   * 3)
   */
  if ((error = set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof(o_as), &(as->container))) != ERROR_NONE)
    {
      cons_msg('!', "as: unable to reserve an ll for as manager\n");
      return (error);
    }

  STATS_RESERVE("as", &as->stats);

  return ERROR_NONE;
}


/*
** This function cleans the address space manager.
*/
t_error	  as_clean(void)
{
  t_error error;
  t_state state;
  t_iterator iterator;

  set_foreach(SET_OPT_FORWARD, as->container, &iterator, state)
    {

      if ((error = as_release(((o_as *)(iterator.u.ll.node->data))->asid)) != ERROR_NONE)
	{
	  cons_msg('!', "as: unable to release the as container\n");
	  return (error);
	}
    }

  STATS_RELEASE(as->stats);

  if ((error = id_destroy(&as->id)) != ERROR_NONE)
    {
      cons_msg('!', "as: unable to destroy the identifier object\n");

      return (error);
    }

  free(as);

  return ERROR_NONE;
}

