/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:48:24 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Funtion to call the init function for the kernel
 */
void			kaneton_init(t_init* bootloader)
{
  init = bootloader;

  printf_init(t_printf_char, t_printf_attr);
  alloc_init((t_vaddr) init->alloc, (t_size) init->allocsz, FIT_FIRST);
}

void			kaneton(t_init*				bootloader)
{
  t_asid  asid;
  t_uint32  i;

  // init gdt
  /*  create_new_gdt(bootloader);*/

  kaneton_init(bootloader);
  clean_cons();
  // init id manager
  if (id_init() != ERROR_NONE)
    return;
  // init set manager
  if (set_init() != ERROR_NONE)
    return;
  // init as manager
  if (as_init() != ERROR_NONE)
    return;
  // init segment manager
  if (segment_init() != ERROR_NONE)
    return;

  /******************************* tests *********************************/

  /*test_set();*/

  /****************************** fin tests ******************************/

  // create kernel address space and inject pre allocated segments in it.
  as_reserve(0, &asid);

  for (i = 0; i < init->nsegments; i++)
    segment_inject(asid, init->segments + i);

  /*set_dump();
    test_as();*/

  /* Print all segment information of t_segment*/
  /*print_seg_reg(init);*/

  /* Print all region information of t_region */
  /*print_module(init);*/

  /* Print all t_init fields */
  /*print_t_init(init);*/

  // clean all managers
  if (segment_clean() != ERROR_NONE)
    {
      printf("Segment clean failed\n");
      return;
    }
  if (as_clean() != ERROR_NONE)
    {
      printf("AS clean failed\n");
      return;
    }
  if (set_clean() != ERROR_NONE)
    {
      printf("Set clean failed\n");
      return;
    }
  if (id_clean() != ERROR_NONE)
    {
      printf("iD clean failed\n");
      return;
    }
  while (1)
    ;
}

