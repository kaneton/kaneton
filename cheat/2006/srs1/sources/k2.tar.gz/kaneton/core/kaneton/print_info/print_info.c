/*
 * Funtions to print some information from bootloader
 * operation and memory area.
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

/* <Fixed by Enguerrand> */

/*
 * Function to display t_segment area
 */
void print_seg_reg(t_init* init)
{
  int i;
  o_segment* segment = init->segments;
  o_region* region = init->regions;

  clean_cons();
  printf("--+++ Segments +++--\n\n");
  for(i = 1; i <= 11; ++i)
    {
      printf("---segment %i addr = 0x%x size = %i\n", i, segment->address, segment->size);
      segment += 1;
    }
  printf("\n\n--+++ Regions +++--\n\n");
  for (i = 1; i <= 7; ++i)
    {
      printf("+++region %i addr = 0x%x size = %i\n", i, region->address, region->size);
      region += 1;
    }
}

/*
 * Function to print the t_module area
 */
void print_module(t_init* init)
{
  int i;
  t_module* module = (t_module*)((void*)init->modules + sizeof(t_modules));

  clean_cons();
  printf("--+++ %i modules +++--\n\n", init->modules->nmodules, module->name);

  for (i = 1; i <= init->modules->nmodules; ++i)
    {
      printf("module %i name : %s size : %i", i, module->name, module->size);
      printf(" address : 0x%x\n", module->name - module->size);
      module = (t_module*)((t_uint32) module + sizeof(t_module));
    }
}

/*
 * Function to print the t_init elements
 */
void print_t_init(t_init* init)
{
  clean_cons();
  printf("--+++ t_init +++--\n\n");
  printf("mem = %i -- memsz = %i\n\n", init->mem, init->memsz);
  printf("kcode = 0x%x -- kcodesz = %i\n\n", init->kcode, init->kcodesz);
  printf("init = 0x%x -- initsz = %i\n\n",init->init, init->initsz);
  printf("modules = 0x%x -- modulesz = %i\n\n", init->modules, init->modulessz);
  printf("nsegments = %i -- segments = 0x%x -- segmentssz = %i\n\n", init->nsegments, init->segments, init->segmentssz);
  printf("nregions = %i -- regions = 0x%x -- regionssz = %i\n\n", init->nregions, init->regions, init->regionssz);
  printf("kstack = 0x%x -- kstacksz = %i\n\n", init->kstack, init->kstacksz);
  printf("alloc = 0x%x -- allocsz = %i\n\n", init->alloc, init->allocsz);
}
