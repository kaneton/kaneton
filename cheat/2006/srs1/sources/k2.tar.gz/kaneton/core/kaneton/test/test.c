/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/test/test.c
 *
 * created       chiche   [fri feb 11 03:04:40 2005]
 * updated       phenix   [tue jan 24 19:50:54 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *  test file
 */

/*
 * ---------- assignments -----------------------------------------------------
 *  chiche
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */




t_error test_set(void)
{
  t_setid   id;

  id = test_set_ll();
  test_set_insert_before_after(id);
/*  test_set_add(id);*/

  return ERROR_NONE;
}


t_setid test_set_array(void)
{
  t_setid   id;
  t_error   error;

  if ((error = set_reserve(array, SET_OPT_ALLOC, 4, sizeof(t_id), &id)) != ERROR_NONE)
    printf("set_reserve failed with error %i\n", error);

  if ((error = set_type(array, id)) != ERROR_NONE)
    printf("set_type failed with error %i\n", error);
  else
    printf("*** Type of set is ARRAY ***\n");
  return id;
}


t_setid test_set_ll(void)
{
  t_setid   id;
  t_error   error;

  if ((error = set_reserve(ll, SET_OPT_ALLOC, sizeof(t_id), &id)) != ERROR_NONE)
    printf("set_reserve failed with error %i\n", error);

  if ((error = set_type(ll, id)) != ERROR_NONE)
    printf("set_type failed with error %i\n", error);
  else
    printf("*** Type of set is LL ***\n");
  return id;
}


t_error test_set_add(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  o_set*    set;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i5);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i2);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i6);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i4);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i1);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i3);

  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_remove(id, 12);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_remove(id, 11);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_remove(id, 16);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_flush(id);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");
  printf("ERROR REMOVING WHEN EMPTY : %i\n", set_remove(id, 16));

  return ERROR_NONE;
}


t_error test_set_insert_head(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  o_set*    set;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_head(id, &i5);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_head(id, &i2);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_head(id, &i6);
  set_insert_head(id, &i4);
  set_insert_head(id, &i1);
  set_insert_head(id, &i3);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  return ERROR_NONE;
}


t_error test_set_insert_tail(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  o_set*    set;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_tail(id, &i5);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_tail(id, &i2);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_tail(id, &i6);
  set_insert_tail(id, &i4);
  set_insert_tail(id, &i1);
  set_insert_tail(id, &i3);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  return ERROR_NONE;
}

/*
** Chiche
*/
t_error test_set_insert_before_after(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  o_set*    set;
  t_iterator chiche;
  t_error error;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  if ((error = set_insert_tail(id, &i2)) != ERROR_NONE)
    printf("CHICHE ERROR %i\n", error);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_locate(id, 12, &chiche);

  set_insert_before(id, chiche, &i1);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");
  set_locate(id, 12, &chiche);
  set_insert_after(id, chiche, &i6);
  set_insert_after(id, chiche, &i5);
  set_insert_after(id, chiche, &i4);
  set_insert_after(id, chiche, &i3);

  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  return ERROR_NONE;
}


/*
** Test clone
*/
t_error test_set_clone(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  t_id	clone;
  o_set*    set;
  o_set*    set_clone;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (set_descriptor(clone, &set_clone) != ERROR_NONE)
    SET_LEAVE(set_clone, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i5);
  set_add(id, &i2);
  set_add(id, &i6);
  set_add(id, &i4);
  set_add(id, &i1);
  set_add(id, &i3);

  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_clone(id, &clone);

  printf("Set clone avec %i element :\n-->", set_clone->size);
  if (set_show(clone) != ERROR_NONE)
    printf("set_show failed\n");

  set_flush(id);
  printf("Set d'origine flushe avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  return ERROR_NONE;
}

void		test_as(void)
{
  t_asid	asid1;
  t_asid	asid2;
  t_asid	asid3;

  t_segid	segid1;
  t_segid	segid2;
  t_segid	segid3;

  if (as_reserve(0, &asid1) != ERROR_NONE)
    printf("as test: error as_reserve 1\n");

  if (segment_reserve(asid1, 4096, 0, &segid1) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  if (segment_reserve(asid1, 4096, 0, &segid2) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  if (segment_reserve(asid1, 4096, 0, &segid3) != ERROR_NONE)
    printf("as test: error seg_reserve\n");

  if (as_reserve(0, &asid2) != ERROR_NONE)
    printf("as test: error as_reserve 2\n");

  if (segment_reserve(asid2, 4096, 0, &segid2) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  if (segment_reserve(asid2, 4096, 0, &segid3) != ERROR_NONE)
    printf("as test: error seg_reserve\n");

  if (as_reserve(0, &asid3) != ERROR_NONE)
    printf("as test: error as_reserve 3\n");
  if (segment_reserve(asid3, 4096, 0, &segid2) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  if (segment_reserve(asid3, 4096, 0, &segid3) != ERROR_NONE)
    printf("as test: error seg_reserve\n");

  if (as_release(asid2) != ERROR_NONE)
    printf("as test: error as_release\n");

  if (as_reserve(0, &asid2) != ERROR_NONE)
    printf("as test: error as_reserve 2\n");

  if (segment_reserve(asid2, 4096, 0, &segid2) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  if (segment_reserve(asid2, 4096, 0, &segid3) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  as_dump();
}
