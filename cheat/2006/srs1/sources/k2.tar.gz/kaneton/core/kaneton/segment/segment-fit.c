/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/segment/segment-fit.c
 *
 * created       matthieu bucchianeri   [tue jan 10 01:03:46 2006]
 * updated       matthieu bucchianeri   [tue jan 31 00:20:33 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file implements simple  fitting algorithms for physical memory
 * management.
 *
 * you can define which algorithm to use with the macro SEGMENT_FIT.
 *
 *  - FIT_FIRST: first fit algorithm - the first large enough space is taken
 *  - FIT_BEST: best fit algorithm - the smaller space is taken
 *  - ...
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  have  to develop  at  least  the  first-fit algorithm  to
 * allocate physical memory.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

extern m_segment*	segment;

/*
 * ---------- functions -------------------------------------------------------
 */

t_error		segment_fit(t_psize size, t_paddr* address)
{
  o_set*	oset;
  t_iterator	iterator;
  t_state	state;
  t_error	error;
  t_psize	tpsize;
  t_paddr	adr1;
  t_paddr	adr2;

  SEGMENT_ENTER(segment);

  if ((error = set_descriptor(segment->container, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  set_foreach(SET_OPT_FORWARD, oset->setid, &iterator, state)
    {
      if (iterator.u.ll.node->nxt != NULL)
	{
	  tpsize = nbr_page(((o_segment*)iterator.u.ll.node->data)->size) * PAGESZ;
	  adr1 = ((o_segment*)iterator.u.ll.node->data)->segid;
	  adr2 = ((o_segment*)iterator.u.ll.node->nxt->data)->segid;

	  if ((adr2 - (adr1 + tpsize)) > (nbr_page(size) * PAGESZ))
	    break;
	}
      else
	break;
    }

  *address = ((o_segment*)iterator.u.ll.node->data)->segid +
    (nbr_page(((o_segment*)iterator.u.ll.node->data)->size) * PAGESZ);

  if (*address > (segment->size * 1024 * 1024))
    SEGMENT_LEAVE(segment, ERROR_NO_MEMORY);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}
