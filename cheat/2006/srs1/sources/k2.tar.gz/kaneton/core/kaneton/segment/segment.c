/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/segment/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:39:03 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the segment manager manages physical memory.
 *
 * it  is  able   to  reserve  and  release  memory   areas  (see  the
 * segment-fit.c for  allocation algorithm)  and to operated  on these
 * area: resize, split, copy, etc.
 *
 * a segment  is identified by  a 64 bits identifier  corresponding to
 * its physical  address. so  it is easy  to retrieve  this identifier
 * given the base address of a segment.
 *
 * remember  that  segments are  global:  there  is  only one  set  of
 * segments objects for  the entire kernel. the set  of segments in an
 * address space is just a set of identifiers.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have  to write the entire manager:  this file implementing
 * independent code plus  an architecture dependant file (ia32-virtual
 * or ia32-segment for example).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the init variable, filled by the bootloader, containing in this case
 * the list of segments to mark used.
 */

extern t_init*		init;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

m_segment*		segment;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * This function displays information on specified segment.
 */
t_error segment_show(t_segid u)
{
  o_segment *oseg;
  t_error error;

  SEGMENT_ENTER(segment);

  if ((error = segment_get(u, &oseg)) != ERROR_NONE)
    {
      cons_msg('!', "segment: impossible to get a segment\n");
      SEGMENT_LEAVE(segment, error);
    }

  printf("---- segment %i ----\n", u);

  printf("segment.asid = %d", oseg->asid);
  printf("segment.type = %d", oseg->type);
  printf("segment.address = %d", oseg->address);
  printf("segment.size = %d", oseg->size);
  printf("segment.perms = %d", oseg->perms);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function displays all segments in the segment container.
 */
t_error segment_dump(void)
{
  t_state       state;
  t_iterator    iterator;

  SEGMENT_ENTER(segment);

  set_foreach(SET_OPT_FORWARD, segment->container, &iterator, state)
    if (segment_show(((o_segment*)(iterator.u.ll.node->data))->segid) != ERROR_NONE)
      cons_msg('!', "segment: impossible to show segment %i\n", ((o_segment*)(iterator.u.ll.node->data))->segid);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function clones a segment copying its content.
 */
t_error segment_clone(t_asid as, t_segid old, t_segid* new)
{
  o_segment* old_seg;
  o_as*	oas;
  t_error error;

  SEGMENT_ENTER(segment);

  if ((error = segment_get(old, &old_seg)) != ERROR_NONE)
    {
      cons_msg('!', "segment: impossible to get a segment\n");
      SEGMENT_LEAVE(segment, error);
    }

  if ((error = segment_reserve(as, old_seg->size, old_seg->perms, new)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  if ((error = as_get(as, &oas)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  if ((error = set_add(oas->segments, new)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function injects a pre-allocated segment in the segment container.
 * This function concerns k1 pre-reserved segments. All of these must be passed to
 * the inject function at kernel boot time. ?
 */
t_error segment_inject(t_asid as, o_segment* o)
{
  o_as* oas;
  t_error	error;

  SEGMENT_ENTER(segment);

  if (o->segid != o->address)
    o->segid = o->address;
  o->asid = as;
  if ((error = set_add(segment->container, o)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  if ((error = as_get(as, &oas)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = set_add(oas->segments, &(o->segid))) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function gives a segment from one address space to another.
 */
t_error segment_give(t_segid u, t_asid as)
{
  o_as* old_as;
  o_segment* oseg;
  t_error error;

  SEGMENT_ENTER(segment);

  if ((error = segment_get(u, &oseg)) != ERROR_NONE)
    {
      cons_msg('!', "segment: impossible to get a segment\n");
      SEGMENT_LEAVE(segment, error);
    }
  if ((error = as_get(oseg->asid, &old_as)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = set_remove(old_as->segments, u)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = set_add(as, &u)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  oseg->asid = as;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function resizes a segment.
 */
t_error segment_resize(t_segid u, t_psize size, o_segment* new )
{
  o_segment* oseg;
  t_segid id;
  t_error error;

  SEGMENT_ENTER(segment);

  if ((error = segment_get(u, &oseg)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  if ((error = segment_reserve(oseg->asid, size, oseg->perms, &id)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  if ((error = segment_release(u)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function split a segment into two segments.
 */
t_error segment_split(t_segid u, t_psize size, t_segid* left, t_segid* right)
{
  o_segment *oseg;
  t_segid id;
  t_psize   size_r;
  t_error error;

  SEGMENT_ENTER(segment);

  if ((error = segment_get(u, &oseg)) !=  ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  size_r = oseg->size - size;

  if ((error = segment_reserve(oseg->asid, size, oseg->perms, &id)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = segment_reserve(oseg->asid, size_r, oseg->perms, &id)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = segment_release(u)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function merges two segments into a single one.
 */
t_error segment_coalesce(t_segid left, t_segid right, t_segid* u)
{
  o_segment *lseg;
  o_segment *rseg;
  t_psize size;
  t_segid id;
  t_error error;

  SEGMENT_ENTER(segment);

 if ((error = segment_get(left, &lseg)) !=  ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
 if ((error = segment_get(right, &rseg)) !=  ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

 /* Les segs doivent etre dans le meme as */
 if (lseg->asid != rseg->asid)
   SEGMENT_LEAVE(segment, ERROR_SEGMENT_COALESCE);
 /* Les perms doivent etre idem */
 if (lseg->perms != rseg->perms)
   SEGMENT_LEAVE(segment, ERROR_SEGMENT_PERMS);

 size = lseg->size + rseg->size;
 if ((error = segment_reserve(lseg->asid, size, lseg->perms, &id)) != ERROR_NONE)
   SEGMENT_LEAVE(segment, error);
 if ((error = segment_release(left)) != ERROR_NONE)
   SEGMENT_LEAVE(segment, error);
 if ((error = segment_release(right)) != ERROR_NONE)
   SEGMENT_LEAVE(segment, error);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function reserves a segment of specified size.
 */
t_error segment_reserve(t_asid as, t_psize size, t_perms perms, t_segid* u)
{
  o_segment oseg;
  o_as* oas;
  t_error   error;

  SEGMENT_ENTER(segment);
  oseg.type = SEGMENT_TYPE_MEMORY;
  oseg.asid = as;
  oseg.size = size;
  oseg.perms = perms;
  if ((error = segment_fit(size, &(oseg.address))) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  oseg.segid = oseg.address;

  if ((error = as_get(as, &oas)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = set_add(oas->segments, &(oseg.segid))) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = set_add(segment->container, &oseg)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  *u = oseg.segid;
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function releases a segment.
 */
t_error segment_release(t_segid u)
{
  o_segment* oseg;
  o_as*  oas;
  t_error error;

  SEGMENT_ENTER(segment);

  if (segment_get(u, &oseg) != ERROR_NONE)
    {
      cons_msg('!', "segment: impossible to get a segment\n");
      SEGMENT_LEAVE(segment, ERROR_NO_LOCATE);
    }

  if ((error = as_get(oseg->asid, &oas)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = set_remove(oas->segments, u)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  if ((error = set_remove(segment->container, u)) != ERROR_NONE)
    {
      cons_msg('!', "segment: impossible to remove a segment\n");
      SEGMENT_LEAVE(segment, error);
    }

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function is used to force a segment to be given to an address space. catcheable
 * segments are reserved by the module service for architecture specific servers.
 * Catcheable segments are defined in the kaneton.conf file.
 */
t_error segment_catch(t_asid as, t_segid u)
{
  o_segment *oseg;
  o_as* old_as;
  t_error error;

  SEGMENT_ENTER(segment);

  if ((error = segment_get(u, &oseg)) !=  ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  if (oseg->type != SEGMENT_TYPE_CATCH)
    {
      cons_msg('!', "segment: wrong segment type for catch");
      SEGMENT_LEAVE(segment, ERROR_SEGMENT_TYPE);
    }
  oseg->type = SEGMENT_TYPE_MEMORY;
  oseg->asid = as;
  if ((error = as_get(oseg->asid, &old_as)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = set_remove(old_as->segments, u)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = set_add(as, &u)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function changes permissions for a segment.
 */
t_error segment_perms(t_segid u, t_perms perms)
{
  o_segment* oseg;
  t_error error;

  SEGMENT_ENTER(segment);

  if ((error = segment_get(u, &oseg)) != ERROR_NONE)
    {
      cons_msg('!', "segment: impossible to get a segment\n");
      SEGMENT_LEAVE(segment, error);
    }
  oseg->perms = perms;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function changes the type of a segment.
 */
t_error segment_type(t_segid u, t_type type)
{
  o_segment* oseg;
  t_error error;

  SEGMENT_ENTER(segment);

  if ((error = segment_get(u, &oseg)) != ERROR_NONE)
    {
      cons_msg('!', "segment: impossible to get a segment\n");
      SEGMENT_LEAVE(segment, error);
    }
  oseg->type = type;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function removes every segment that belongs to the address space specified.
 */
t_error segment_flush(t_asid as)
{
  o_as* oas;
  t_state state;
  t_iterator iterator;
  t_error error;
  o_set*	oset;

  SEGMENT_ENTER(segment);

  if ((error = as_get(as, &oas)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  set_descriptor(oas->segments, &oset);

  set_foreach(SET_OPT_FORWARD, oas->segments, &iterator, state)
    if ((error = segment_release(*(t_id*)(oset->u.array.array[iterator.u.array.i]))) != ERROR_NONE)
      SEGMENT_LEAVE(segment, error);

  if ((error = set_flush(oas->segments)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}


/*
 * This function gets the segment object associated to a segment identifier.
 */
t_error segment_get(t_segid u, o_segment** o)
{
  t_iterator iterator;
  t_error   error;

  SEGMENT_ENTER(segment);

  if ((error = set_locate(segment->container, u, &iterator)) != ERROR_NONE)
    {
      cons_msg('!', "segment: impossible to get segment\n");
      SEGMENT_LEAVE(as, error);
    }

  *o = (o_segment*)iterator.u.ll.node->data;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function initializes the segment manager.
 */
t_error segment_init(void)
{
  t_error error;

  if ((segment = malloc(sizeof(m_segment))) == NULL)
    {
      cons_msg('!', "segment: cannot allocate memory for the segment manager "
               "structure\n");
      return (ERROR_NO_MEMORY);
    }
  memset(segment, 0x0, sizeof(m_segment));

  if ((error = id_build(&segment->id)) != ERROR_NONE)
    {
      cons_msg('!', "segment: unable to initialise the identifier object\n");
      return error;
    }

  if ((error = set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof(o_segment), &(segment->container))) != ERROR_NONE)
    {
      cons_msg('!', "segment: unable to reserve an ll for segment manager\n");
      return error;
    }

  segment->fit = SEGMENT_FIT;
  segment->start = init->mem;
  segment->size = init->memsz;

  STATS_RESERVE("as", &as->stats);

  machdep_call(segment, segment_init);

  return ERROR_NONE;
}

/*
 * This function cleans the segment manager.
 */
t_error segment_clean(void)
{
  t_state state;
  t_iterator iterator;
  o_as* oas;
  t_error error;

  SEGMENT_ENTER(segment);

  set_foreach(SET_OPT_FORWARD, segment->container, &iterator, state)
    {
      if ((error = as_get(((o_segment *)(iterator.u.ll.node->data))->asid, &oas)) != ERROR_NONE)
	SEGMENT_LEAVE(segment, error);
      if ((error = set_remove(oas->segments, ((o_segment *)(iterator.u.ll.node->data))->segid)) != ERROR_NONE)
	SEGMENT_LEAVE(sgment, error);
    }

  error = set_flush(segment->container);
  if (error != ERROR_NONE && error != ERROR_EMPTY_SET)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  STATS_RELEASE(segment->stats);

  if ((error = id_destroy(&segment->id)) != ERROR_NONE)
    {
      cons_msg('!', "segment: unable to destroy the identifier object\n");
      return (error);
    }

  free(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}
