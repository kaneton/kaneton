/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:29:40 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  file implements dependent  code for  segment manager  on ia32
 * with paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_segment*	segment;
extern t_init*		init;
/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager interface.
 */

i_segment		segment_interface =
  {
    NULL, NULL,
    NULL, NULL,
    NULL, NULL,
    NULL, NULL,
    NULL, NULL,
    NULL, NULL,
    NULL, NULL,
    NULL, ia32_segment_init,
    NULL
  };

/*
 * ---------- functions -------------------------------------------------------
 */

t_error		ia32_segment_init(void)
{
  struct gdt_segment_descriptor* gdt;

  /* allocating space for gdt, after 16Mo */
  gdt = (struct gdt_segment_descriptor*) init->machdep.gdtr;
  /* creating new gdt descriptors */

  /* Kernel code and data */
  set_segment_descriptor(DPL_0, CODE, gdt + 1);
  set_segment_descriptor(DPL_0, DATA, gdt + 2);

  /* Driver code and data */
  set_segment_descriptor(DPL_1, CODE, gdt + 3);
  set_segment_descriptor(DPL_1, DATA, gdt + 4);

  /* Service code and data */
  set_segment_descriptor(DPL_2, CODE, gdt + 5);
  set_segment_descriptor(DPL_2, DATA, gdt + 6);

  /* User program code and data */
  set_segment_descriptor(DPL_3, CODE, gdt + 7);
  set_segment_descriptor(DPL_3, DATA, gdt + 8);

  set_gdt(gdt, 9);

  return ERROR_NONE;
}
