/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/kaneton/set/set_ll.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon dec 19 17:25:13 2005]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this subpart of the set manager is used to build linked-list
 * data structures.
 *
 * note that this data structure is in fact a doubly linked-list.
 *
 * each set of this type can be used in two ways. the first one ask the
 * set manager to allocate and copy each object to add while the second
 * way tells the set manager to simply include the objects in the set.
 *
 * moreover the option free can be used to tell the set manager to call
 * the free() function each time an object is released. this option
 * means that objects passed to the set manager was previously allocated
 * with the malloc() functions suite.
 *
 * moreover, the linked-list data structure can be used either with the
 * sort option or without.
 *
 * the datasz argument of the set_reserve() function is meaningful only in the
 * case the allocate or free options are set.
 *
 * options: SET_OPT_CONTAINER, SET_OPT_SORT, SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire linked-list data structure, nothing
 * less, nothing more.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * This function just returns an error if the set corresponding to u is not of the type
 */
t_error set_type_ll(t_setid u)
{
  o_set*		oset;

  SET_ENTER(set);

  DESCRIPTOR;

  if (oset->type != SET_TYPE_LL)
    {
      print_error(ERROR_TYPE, "function set_type_ll");
      SET_LEAVE(set, ERROR_TYPE);
    }

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function displays an entire set.
 */
t_error set_show_ll(t_setid u)
{
  t_iterator	iterator;
  t_state	state;

  SET_ENTER(set);

  printf("---- set #%i ----\n", u);

  set_foreach(SET_OPT_FORWARD, u, &iterator, state)
    printf("%qd * ", *((t_id*)iterator.u.ll.node->data));
  printf("\n");
  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function returns an iterator on the first element of the set.
 */
t_error set_head_ll(t_setid u, t_iterator* iterator)
{
  o_set*		oset;

  SET_ENTER(set);

  if (iterator == NULL)
    return ERROR_ITERATOR_NULL;

  DESCRIPTOR;

  if (oset->u.ll.head == NULL)
    SET_LEAVE(set, ERROR_EMPTY_SET);

  iterator->u.ll.node = oset->u.ll.head;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function returns an iterator on the last element of the set.
 */
t_error set_tail_ll(t_setid u, t_iterator* iterator)
{
 o_set*		oset;

  SET_ENTER(set);

  if (iterator == NULL)
    return ERROR_ITERATOR_NULL;

  DESCRIPTOR;

  if (oset->u.ll.tail == NULL)
    SET_LEAVE(set, ERROR_EMPTY_SET);

  iterator->u.ll.node = oset->u.ll.tail;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function returns an iterator on the previous element of the set.
 */
t_error set_prev_ll(t_setid u, t_iterator current, t_iterator* previous)
{
  SET_ENTER(set);

  if ((current.u.ll.node == NULL) || (previous == NULL))
    return ERROR_ITERATOR_NULL;

  if (current.u.ll.node->prv == NULL)
    SET_LEAVE(set, ERROR_END_SET);

  previous->u.ll.node = current.u.ll.node->prv;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function returns an iterator on the next element of the set.
 */
t_error set_next_ll(t_setid u, t_iterator current, t_iterator* next)
{
  SET_ENTER(set);

  if ((current.u.ll.node == NULL) || (next == NULL))
    return ERROR_ITERATOR_NULL;

  if (current.u.ll.node->nxt == NULL)
    SET_LEAVE(set, ERROR_END_SET);

  next->u.ll.node = current.u.ll.node->nxt;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function inserts an object at the head of the set.
 */
t_error set_insert_head_ll(t_setid u, void* data)
{
  o_set*		oset;
  t_set_ll_node*	new_node;
  void*			new_data;

  SET_ENTER(set);

  DESCRIPTOR;

  if (oset->u.ll.opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);

  if ((new_node = malloc(sizeof(t_set_ll_node))) == NULL)
    SET_LEAVE(set, ERROR_NO_MEMORY);

  new_data = data;

  SET_DATA_OPT_ALLOC;

  new_node->data = new_data;

  if (oset->u.ll.head != NULL)
    oset->u.ll.head->prv = new_node;
  else
    oset->u.ll.tail = new_node;

  new_node->nxt = oset->u.ll.head;
  new_node->prv = NULL;
  oset->u.ll.head = new_node;
  ++oset->size;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function inserts an object at the tail of the set.
 */
t_error set_insert_tail_ll(t_setid u, void* data)
{
  o_set*		oset;
  t_set_ll_node*	new_node;
  void*			new_data;

  SET_ENTER(set);

  DESCRIPTOR;

  if (oset->u.ll.opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);

  if ((new_node = malloc(sizeof(t_set_ll_node))) == NULL)
    SET_LEAVE(set, ERROR_NO_MEMORY);

  new_data = data;

  SET_DATA_OPT_ALLOC

  new_node->data = new_data;

  if (oset->u.ll.tail != NULL)
    oset->u.ll.tail->nxt = new_node;
  else
    oset->u.ll.head = new_node;

  new_node->prv = oset->u.ll.tail;
  new_node->nxt = NULL;
  oset->u.ll.tail = new_node;
  ++oset->size;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function inserts an object before the one specified by the iterator.
 */
t_error set_insert_before_ll(t_setid u, t_iterator iterator, void* data)
{
  o_set*		oset;
  t_set_ll_node*	new_node;
  void*			new_data;

  SET_ENTER(set);

  if (iterator.u.ll.node == NULL)
    SET_LEAVE(set, ERROR_ITERATOR_NULL);

  DESCRIPTOR;

  if (oset->u.ll.opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);
  new_data = data;

  SET_DATA_OPT_ALLOC;

  if ((new_node = malloc(sizeof(t_set_ll_node))) == NULL)
    SET_LEAVE(set, ERROR_NO_MEMORY);
  new_node->data = new_data;
  new_node->nxt = iterator.u.ll.node;
  new_node->prv = iterator.u.ll.node->prv;

  if (iterator.u.ll.node->prv != NULL)
     iterator.u.ll.node->prv->nxt = new_node;
  else
    oset->u.ll.head = new_node;
  iterator.u.ll.node->prv = new_node;

  ++oset->size;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function inserts an object before the one specified by the iterator.
 */
t_error set_insert_after_ll(t_setid u, t_iterator iterator, void* data)
{
  o_set*		oset;
  t_set_ll_node*	new_node;
  void*			new_data;

  SET_ENTER(set);

  if (iterator.u.ll.node == NULL)
    return ERROR_ITERATOR_NULL;

  DESCRIPTOR;

  if (oset->u.ll.opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);

  new_data = data;

  SET_DATA_OPT_ALLOC

  if ((new_node = malloc(sizeof(t_set_ll_node))) == NULL)
    SET_LEAVE(set, ERROR_NO_MEMORY);
  new_node->data = new_data;
  new_node->nxt = iterator.u.ll.node->nxt;
  new_node->prv = iterator.u.ll.node;

  if (iterator.u.ll.node->nxt != NULL)
    iterator.u.ll.node->nxt->prv = new_node;
  else
    oset->u.ll.tail = new_node;
  iterator.u.ll.node->nxt = new_node;

  ++oset->size;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function adds a data object in the set.
 */
t_error set_add_ll(t_setid u, void* data)
{
  o_set*		oset;
  void*			new_data;
  t_iterator		iterator;
  t_id			id;
  t_set_ll_node		*new_node;
  t_state		state;

  SET_ENTER(set);

  DESCRIPTOR;

  new_data = data;

  SET_DATA_OPT_ALLOC;

  id = *((t_id*)new_data);
  if (oset->u.ll.opts & SET_OPT_SORT)
    {
      if ((new_node = malloc(sizeof(t_set_ll_node))) == NULL)
	SET_LEAVE(set, ERROR_NO_MEMORY);

      new_node->data = new_data;
      new_node->prv = NULL;
      new_node->nxt = NULL;

      iterator.u.ll.node = oset->u.ll.head;

      if (iterator.u.ll.node == NULL)
	{
	  oset->u.ll.head = new_node;
	  oset->u.ll.tail = new_node;
	}
      else
      {
	set_foreach(SET_OPT_FORWARD, u, &iterator, state)
	  if (*((t_id*)iterator.u.ll.node->data) > id)
	    break;

        if (*((t_id*)iterator.u.ll.node->data) > id)
	{
	  new_node->nxt = iterator.u.ll.node;
	  new_node->prv = iterator.u.ll.node->prv;
	  if (iterator.u.ll.node->prv != NULL)
	    iterator.u.ll.node->prv->nxt = new_node;
	  else
	    oset->u.ll.head = new_node;
	  iterator.u.ll.node->prv = new_node;
	}
	else
	{
          new_node->nxt = iterator.u.ll.node->nxt;
          new_node->prv = iterator.u.ll.node;
          iterator.u.ll.node->nxt = new_node;
	  oset->u.ll.tail = new_node;
	}
      }
      oset->size++;

      SET_LEAVE(set, ERROR_NONE);
    }
  SET_LEAVE(set, set_insert_head_ll(u, new_data));
}

/*
 * This function removes an object identified by id from the set u.
 */
t_error set_remove_ll(t_setid u, t_id id)
{
  t_iterator	iterator;
  t_error	error;

  if ((error = set_locate_ll(u, id, &iterator)) != ERROR_NONE)
    SET_LEAVE(set, error);

  if ((error = set_delete_ll(u, iterator)) != ERROR_NONE)
    SET_LEAVE(set, error);

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function deletes the object corresponding to the iterator.
 */
t_error set_delete_ll(t_setid u, t_iterator iterator)
{
  o_set*	oset;

  SET_ENTER(set);

   if (iterator.u.ll.node == NULL)
     SET_LEAVE(set, ERROR_ITERATOR_NULL);

   DESCRIPTOR;

   if (iterator.u.ll.node->prv != NULL)
     iterator.u.ll.node->prv->nxt = iterator.u.ll.node->nxt;
   else
     oset->u.ll.head = iterator.u.ll.node->nxt;
   if (iterator.u.ll.node->nxt != NULL)
     iterator.u.ll.node->nxt->prv = iterator.u.ll.node->prv;
   else
     oset->u.ll.tail = iterator.u.ll.node->prv;
   --oset->size;

   if ((oset->u.ll.opts & SET_OPT_ALLOC) || (oset->u.ll.opts & SET_OPT_FREE))
     free(iterator.u.ll.node->data);
   free(iterator.u.ll.node);
   SET_LEAVE(set, ERROR_NONE);
 }

/*
 * This function removes every object stored in the set.
 */
t_error set_flush_ll(t_setid u)
{
  o_set*	oset;
  t_iterator	iterator;
  t_iterator	save_iterator;
  t_error	error;

  SET_ENTER(set);

  DESCRIPTOR;

  iterator.u.ll.node = oset->u.ll.head;

  while (iterator.u.ll.node != NULL)
    {
      save_iterator.u.ll.node = iterator.u.ll.node->nxt;
      if ((error = set_delete_ll(u, iterator)) != ERROR_NONE)
	SET_LEAVE(set, error);
      iterator.u.ll.node = save_iterator.u.ll.node;
    }

  if (iterator.u.ll.node == NULL)
    SET_LEAVE(set, ERROR_EMPTY_SET);

  oset->u.ll.head = NULL;
  oset->u.ll.tail = NULL;
  oset->size = 0;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function returns an iterator on the element corresponding to the identifier id.
 */
t_error set_locate_ll(t_setid u, t_id id, t_iterator* iterator)
{
  o_set*	oset;

  SET_ENTER(set);

  DESCRIPTOR;

  iterator->u.ll.node = oset->u.ll.head;

  while ((iterator->u.ll.node != NULL) && (*((t_id*)iterator->u.ll.node->data) != id))
    iterator->u.ll.node = iterator->u.ll.node->nxt;

  if (iterator->u.ll.node == NULL)
    SET_LEAVE(set, ERROR_NO_LOCATE);

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function returns the data object corresponding to the iterator.
 */
t_error set_object_ll(t_setid u, t_iterator iterator, void** data)
{
  SET_ENTER(set);

  if (iterator.u.ll.node == NULL)
    SET_LEAVE(set, ERROR_NO_ELT);

  *data = iterator.u.ll.node->data;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function adds an object to a FIFO or LIFO structure.
 */
t_error set_push_ll(t_setid u, void* data)
{
  SET_ENTER(set);

  SET_LEAVE(set, ERROR_BAD_STRUCTURE);
}

/*
 * This function removes the next object of a FIFO or LIFO structure.
 */
t_error set_pop_ll(t_setid u)
{
  SET_ENTER(set);

  SET_LEAVE(set, ERROR_BAD_STRUCTURE);
}

/*
 * This function returns the next object of a FIFO or LIFO structure
 * without deleting it.
 */
t_error set_pick_ll(t_setid u, void** data)
{
  SET_ENTER(set);

  SET_LEAVE(set, ERROR_BAD_STRUCTURE);
}

/*
 * This function releases a set.
 */
t_error set_release_ll(t_setid u)
{
  o_set	*oset;
  t_error error;

  SET_ENTER(set);
  DESCRIPTOR;

  error = set_flush_ll(u);
  if (error != ERROR_NONE && error != ERROR_EMPTY_SET)
    SET_LEAVE(set, error);

  if (u != set->container)
    set_destroy(u);

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function reserves a ll set with options opts which will contain object of datasz
 * size.
 */
t_error set_reserve_ll(t_opts opts, t_size datasz, t_setid* u)
{
  o_set*	new_set;
  o_set	n_set;
  t_error error;

  SET_ENTER(set);

  if (opts & SET_OPT_CONTAINER)
    {
      if ((new_set = malloc(sizeof(o_set))) == NULL)
	SET_LEAVE(set, ERROR_NO_MEMORY);
      new_set->setid = set->container;
      new_set->size = 0;
      new_set->type = SET_TYPE_LL;
      new_set->u.ll.opts = opts;
      new_set->u.ll.datasz = datasz;
      new_set->u.ll.head = NULL;
      new_set->u.ll.tail = NULL;
      set->co = new_set;
    }
  else
    {
      if ((error = id_reserve(&(set->id), &(n_set.setid))) != ERROR_NONE)
	SET_LEAVE(set, error);
      *u = n_set.setid;
      n_set.size = 0;
      n_set.type = SET_TYPE_LL;
      n_set.u.ll.opts = opts;
      n_set.u.ll.datasz = datasz;
      n_set.u.ll.head = NULL;
      n_set.u.ll.tail = NULL;
      set_add(set->co->setid, (void*)&n_set);
    }

  SET_LEAVE(set, ERROR_NONE);
}

/*
** Clone a set - Not applicable for LL
*/
t_error set_clone_ll(t_setid u, t_setid *new)
{
  SET_ENTER(set);

  SET_LEAVE(set, ERROR_BAD_STRUCTURE);
}

