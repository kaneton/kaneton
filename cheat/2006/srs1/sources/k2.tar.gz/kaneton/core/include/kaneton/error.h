/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/kaneton/error.h
 *
 * created       julien quintard   [fri feb 11 02:19:11 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:32:44 2006]
 */

#ifndef KANETON_ERROR_H
#define KANETON_ERROR_H		1

/*
 * ---------- Macro display error mesg ----------------------------------------
 */

#define print_error(_error_, _msg_, _args_...)	\
error_msg(_msg_, _error_ ## _MSG, ## _args_);

/*
 * ---------- defines ---------------------------------------------------------
 */

#define ERROR_NONE		(1 << 0)
#define ERROR_NONE_MSG		"No error"

#define ERROR_UNKNOWN		(1 << 1)
#define ERROR_UNKNOWN_MSG	"Unknown error"
/*
 * the other values are reserved for the specific managers use.
 */

#define ERROR_TYPE		ERROR_UNKNOWN + 1
#define ERROR_TYPE_MSG		"set: invalid type for the function"

#define ERROR_EMPTY_SET		ERROR_TYPE + 1
#define ERROR_EMPTY_SET_MSG	"set : no set's element found"

#define ERROR_END_SET		ERROR_EMPTY_SET + 1
#define ERROR_END_SET_MSG	"set : no previous element found"

#define ERROR_NO_LOCATE         ERROR_END_SET + 1
#define ERROR_NO_LOCATE_MSG	"set : no element found by locate function"

#define ERROR_NO_MEMORY		ERROR_NO_LOCATE + 1
#define ERROR_NO_MEMORY_MSG	"set : not enough memory"

#define ERROR_ITERATOR_NULL	ERROR_NO_MEMORY + 1
#define ERROR_ITERATOR_NULL_MSG	"set : iterator gave is NULL"

#define ERROR_BAD_STRUCTURE	ERROR_ITERATOR_NULL + 1
#define ERROR_BAD_STRUCTURE_MSG	"set : bad structure to use function LIFO, FIFO"

#define ERROR_NO_ELT		ERROR_BAD_STRUCTURE + 1
#define ERROR_NO_ELT_MSG	"set : no element found"

#define ERROR_SORT		ERROR_NO_ELT + 1
#define ERROR_SORT_MSG		"set : bad insertion in a sorted set"

#define ERROR_NO_COPY		ERROR_SORT + 1
#define ERROR_NO_COPY_MSG	"set : copy did not done"

#define ERROR_SEGMENT_COALESCE	ERROR_NO_COPY + 1
#define ERROR_SEGMENT_COALESCE_MSG "segment : the 2 segments must be in the same as"

#define ERROR_SEGMENT_PERMS	ERROR_SEGMENT_COALESCE + 1
#define ERROR_SEGMENT_PERMS_MSG "segment : the 2 segments must have same permissions"

#define ERROR_SEGMENT_TYPE	ERROR_SEGMENT_PERMS + 1
#define ERROR_SEGMENT_TYPE_MSG "segment : wrong segment type"

#endif
