/*
 * Funtions to print some information from bootloader
 * operation and memory area.
 */

#ifndef PRINT_INFO_H
#define PRINT_INFO_H

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <kaneton/types.h>

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/print_info/print_info.c
 */

/*
 * ../../kaneton/print_info/print_info.c
 */

void print_seg_reg(t_init* init);

void print_module(t_init* init);

void print_t_init(t_init* init);


/*
 * eop
 */

#endif
