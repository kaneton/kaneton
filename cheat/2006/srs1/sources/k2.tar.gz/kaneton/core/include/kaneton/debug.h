/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/kaneton/debug.h
 *
 * created       julien quintard   [mon nov 28 19:37:01 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:24:17 2006]
 */

#ifndef KANETON_DEBUG_H
#define KANETON_DEBUG_H		1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <arch/machdep/machdep.h>

/*
 * ---------- defines ---------------------------------------------------------
 */

#define DEBUG_PARAMS		(1 << 0)
#define DEBUG_AS		(1 << 1)
#define DEBUG_SEGMENT		(1 << 2)
#define DEBUG_SET		(1 << 3)
#define DEBUG_STATS		(1 << 4)
#define DEBUG_REGION		(1 << 5)
#define DEBUG_TASK		(1 << 6)
#define DEBUG_THREAD		(1 << 7)
#define DEBUG_SCHEDULE		(1 << 8)

#define DEBUG								\
  (CONF_DEBUG)

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/debug/debug.c
 *      ../../kaneton/debug/cons-text.c
 *      ../../kaneton/debug/serial.c
 */

/*
 * ../../kaneton/debug/debug.c
 */


/*
 * ../../kaneton/debug/cons-text.c
 */

void			cons_msg(char				indicator,
				 char*				fmt,
				 ...);

void			error_msg(const char *msg,
				  const char * msg_error,
				  ...);
/*
 * ../../kaneton/debug/serial.c
 */


/*
 * eop
 */

#endif
