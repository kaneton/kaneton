/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/export_kaneton/kaneton/core/bootloader/arch/ia32-virtual/pmode.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       matthieu bucchianeri   [mon jan 30 20:22:46 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the student just has to setup the protected mode in this file,
 * nothing more.
 *
 * of course, it will be better to provide some debug functions etc..
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libia32.h>
#include "bootloader.h"


/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * ---------- functions -------------------------------------------------------
 */

int enter_pmode(t_uint32 alloc)
{
  struct gdt_segment_descriptor* gdt;

  /* allocating space for gdt, after 16Mo */
  gdt = (struct gdt_segment_descriptor*) alloc;

  /* creating gdt descriptors */
  set_segment_descriptor(DPL_0, CODE, gdt + 1);
  set_segment_descriptor(DPL_0, DATA, gdt + 2);
  set_segment_descriptor(DPL_3, CODE, gdt + 3);
  set_segment_descriptor(DPL_3, DATA, gdt + 4);

  set_gdt(gdt, 5);

  return 0;
}

