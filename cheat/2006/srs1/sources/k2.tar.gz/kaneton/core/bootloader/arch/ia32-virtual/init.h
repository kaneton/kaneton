/*
** File used to define macro constant for region address
*/

/*
 * Macro
 */

#ifndef INIT_H
#define INIT_H

#define RELOCATE_BASE 0x1000000
#define ISA_START 0x1000
#define ISA_SIZE 0xff000
#define KCODE_START 0x1001000

#endif
