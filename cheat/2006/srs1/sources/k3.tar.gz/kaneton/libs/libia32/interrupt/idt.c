/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/interrupt/idt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:47:59 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:48:35 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage interrupt descriptor table.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will  place  here   the  function  they  need  to  manage
 * idt. prototypes are not imposed.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */


/*
** Init the idt structure
**
**
*/

/* tableau IDT */
static struct idt_entry    idt[IDTE_NB];

/*
** fonction d'initialisation de l'IDT
*/
void idt_init(void)
{
  struct idt_register idtr;
  int i;

  // on rempli chaque entree de l'IDT (IDTE_NUM=256 entree au total)
  for (i = 0; i < IDTE_NB; i++)
  {
    struct idt_entry *idte = idt + i;

    idte->seg_sel = 1 << 3; // segment KERNEL_CODE
    idte->reserved = 0;
    idte->flags = 0; // 0 pour interrupt gate
    idte->type = 6; // type de gate
    idte->op_size = 1; // mode 32 bits
    idte->zero = 0; // 0
    idte->dpl = 0;
    // pas encore de handler
    set_idte_handler(i, 0);
  }

  // on remplit le registre IDT, puis on le met a jour
  idtr.base = (t_uint32) idt;
  idtr.limit = IDTE_NB * 8;

  asm ("lidt %0\n\t"
      :
      : "m" (idtr)
      : "memory");
}

/*
** ajout d'un handler, sur l'entree 'id'
*/
int set_idte_handler(int id, t_vaddr handler_addr)
{
  struct idt_entry *idte;

  if (id < 0 || id >= IDTE_NB)
    return 1;

  idte = idt + id;
  if (handler_addr != 0)
  {
    idte->offset_low = handler_addr & 0xFFFF;
    idte->offset_high = (handler_addr) >> 16 & 0xFFFF;
    idte->present = 1;
  }
  else
  {
    idte->offset_low = 0;
    idte->offset_high = 0;
    idte->present = 0;
  }
  return 0;
}
