/*
** idt.h for Kaneton in /home/goinfre/zzz/kaneton/libs/libia32/interrupt
**
** Made by Mad
** Login   <mad@maddax.net>
**
** Started on  Sun Jun  4 12:33:25 2006 Mad
** Last update Tue Jun 13 15:41:27 2006 Mad
*/

#ifndef IDT_H_
# define IDT_H_


/* Number of IDT Entries limited by Intel doc to 256. */
#define IDTE_NB 256


/* Mapping of the CPU exceptions in the IDT (imposed by Intel
   standards) */
#define EXCEPT_BASE 0
#define EXCEPT_NB    32
#define EXCEPT_MAX  (EXCEPT_BASE + EXCEPT_NUM - 1) /* voir dans
sos pourquoi ils ont mis HWEXCEPT a la place d'EXCEPT */


/* Mapping of the IRQ lines in the IDT */
#define IRQ_BASE    32
#define IRQ_NB      16
#define IRQ_MAX     (IRQ_BASE + IRQ_NB - 1)



struct idt_register
{
  t_uint16  limit;
  t_uint32  base;
} __attribute__((packed, aligned (8)));



struct idt_entry
{
 /* Low dword */
  t_uint16 offset_low;  /* 15..0, offset of the routine in the segment */
  t_uint16 seg_sel;     /* 31..16, the ID of the segment */

  /* High dword */
  t_uint8 reserved:5;   /* 4..0 */
  t_uint8 flags:3;      /* 7..5 */
  t_uint8 type:3;       /* 10..8 (interrupt gate, trap gate...) */
  t_uint8 op_size:1;    /* 11 (0=16bits instructions, 1=32bits instr.) */
  t_uint8 zero:1;       /* 12 */
  t_uint8 dpl:2;        /* 14..13 */
  t_uint8 present:1;    /* 15 */
  t_uint16 offset_high; /* 31..16 */
} __attribute__ ((packed));


#endif /* !IDT_H_ */
