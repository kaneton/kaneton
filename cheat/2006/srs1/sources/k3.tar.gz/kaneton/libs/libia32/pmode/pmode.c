/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/pmode/pmode.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:15 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:59:44 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage protected mode.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  must  write  here  function related  to  protected  mode:
 * entering, leaving etc.
 *
 * but  be careful: everything  that deals  with gdt  and ldt  must be
 * placed in the corresponding file, not here.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */
