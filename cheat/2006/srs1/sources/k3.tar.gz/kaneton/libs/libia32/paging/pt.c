/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/pt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:48 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:54:23 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page tables.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to place here everything dealing with page tables. no
 * restrictions apply on this file.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
** create a pt in memory and sets all bit to 0
*/
t_uint32 create_pt(t_uint32 location)
{
  t_uint32* i;

  for (i = (t_uint32 *) location; (t_uint32) i < location + 4096; i++)
    *i = 0;

  return location;
}

/*
** return the pt that allows to find the address 'p' in memory,
** or -1 if that page table is not available.
*/
t_uint32 get_pt(t_uint32 p, t_uint32 pd)
{
  t_uint32* pde;
  t_uint32 offset;

  offset = (p >> 22) & 0x000003FF;

  /* check if the page table is present */
  pde = (t_uint32 *) pd + offset;
  if (((*pde) & 1) == 0)
    return 0;
  else
      return ((*pde) >> 12) << 12;
}

/*
** Updates the page table with the entry 'p', at offset given by 'p'
*/
t_uint32 update_pt(t_uint32 p, t_uint32 pt)
{
  t_uint32* pte;
  t_uint32 offset;

  offset = ((p & 0x003FF000) >> 12);
  pte = (t_uint32*) pt + offset;
  *pte = ((p >> 12) << 12) + 3;
  return 0;
}

/*
 * Function to get index in pt
 */
t_uint32	get_pt_index(t_uint32 index)
{
  return (index >> 12) & 0x000003FF;
}

/*
 * Function to calculate a pt entry
 */
t_uint32	get_pt_entry(t_paddr paddr)
{
  t_uint32	res;
  t_uint32	tmp;

  tmp = 0xfffff00f & paddr;
  res = tmp | 0x00000005;
  return res;
}
