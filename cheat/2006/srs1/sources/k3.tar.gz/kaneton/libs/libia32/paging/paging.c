/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/paging.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:05 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:51:57 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage paging.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will have  to fill  this  file with  function related  to
 * paging mode in the cpu: enable, disabling etc.
 *
 * there are no  restrictions about these functions, but  keep in mind
 * that  page-directory management and  page-tables management  are to
 * place in pd.c and pt.c.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */

/*
** Sets pagination
*/
t_uint32 install_paging(t_uint32 pd)
{
  t_uint32 tmp = pd;

  asm("movl %0, %%cr3\n\t"
      "movl %%cr0, %%eax\n\t"
      "orl $0x80010000, %%eax\n\t"
      "movl %%eax, %%cr0\n\t"
      :
      : "r" (tmp)
      : "eax");
  return 0;
}

/*
 * Function to print page
 */
void		print_page(t_paddr page)
{
  t_uint32*	entry = (t_uint32*)page;
  t_uint32	i;

  for (i = 0; i < 1024; ++i)
    {
      if (entry[i])
	printf("entry number %d -- %d\n", i, entry[i]);
    }
}

/*
 * Function to get offset from virtual address
 */
t_uint32	get_offset(t_vaddr vaddr)
{
  return vaddr & 0x00000FFF;
}
