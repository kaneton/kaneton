/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/pd.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:20 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:53:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page directory.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this    file   is    destinated   to    functions    dealing   with
 * page-directories. there are no restrictions about function names or
 * prototype, so feel free.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */

/*t_uint32	map_memory(t_uint32 locationPd, t_uint32 pstart, t_uint32 pend, t_uint32 vstart)
{

}*/

/*
** create a pd in memory and sets all bit to 0
*/
t_uint32 create_pd(t_uint32 location)
{
  t_uint32* i;

  for (i = (t_uint32 *) location; (t_uint32) i < location + 4096; i++)
    *i = 0;

  return location;
}

/*
** Updates the page directory with the entry 'pt', at offset given by 'p'
*/
t_uint32 update_pd(t_uint32 p, t_uint32 pd, t_uint32 pt)
{
  t_uint32* pde;
  t_uint32 offset;

  offset = (p >> 22) & 0x000003FF;
  pde = (t_uint32 *) (pd + (sizeof(t_uint32) * offset));
  /* kernel privilege + read-write + present */
  *pde = ((pt >> 12) << 12) + 3;
  return 0;
}

/*
 * Function to get index in pd
 */
t_uint32	get_pd_index(t_uint32 index)
{
  return index >> 22;
}

/*
 * Function to calculate a pd entry
 */
t_uint32	get_pd_entry(t_paddr pt)
{
  t_uint32	res;
  t_uint32	tmp;

  tmp = 0xfffff00f & pt;
  res = tmp | 0x00000005;
  return res;
}
