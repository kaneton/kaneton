/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/include/kaneton/test.h
 *
 * created       julien quintard   [sun jan 19 14:51:33 2005]
 * updated       matthieu bucchianeri   [tue dec  6 00:48:18 2005]
 */
#ifndef KANETON_TEST_H
#define KANETON_TEST_H		1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <kaneton/types.h>

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/test/test.c
 */

/*
 * ../../kaneton/test/test.c
 */

t_error test_set(void);

t_setid test_set_array(void);

t_setid test_set_ll(void);

t_error test_set_add_brute(t_id id);

t_error test_set_add_sort_locate(t_id id);

t_error test_set_add(t_id id);

t_error test_set_insert_head(t_id id);

t_error test_set_insert_tail(t_id id);

t_error test_set_insert_before_after(t_id id);

t_error test_set_clone(t_id id);

void		test_as(void);

void		test_ll(void);

void		test_region(void);

void		test_as_full(void);

void		test_map(void);

void		test_no_memory(void);

void		test_segment_rw(void);


/*
 * eop
 */

#endif
