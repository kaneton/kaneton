/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/kaneton/irq.h
 *
 * created       julien quintard   [fri feb 11 02:19:44 2005]
 * updated       matthieu bucchianeri   [thu jan 26 11:48:16 2006]
 */

#ifndef KANETON_IRQ_H
#define KANETON_IRQ_H	1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <arch/machdep/machdep.h>
#include <kaneton/types.h>

/*
 * ---------- defines ---------------------------------------------------------
 */


/*
 * ---------- types -----------------------------------------------------------
 */

typedef void (*irq_handler)(int irq_number);


/*
 * ---------- macros ----------------------------------------------------------
 */

#define IRQ_TIMER         0
#define IRQ_KEYBOARD      1
#define IRQ_SLAVE_PIC     2
#define IRQ_COM2          3
#define IRQ_COM1          4
#define IRQ_LPT2          5
#define IRQ_FLOPPY        6
#define IRQ_LPT1          7
#define IRQ_8_NOT_DEFINED 8
#define IRQ_RESERVED_1    9
#define IRQ_RESERVED_2    10
#define IRQ_RESERVED_3    11
#define IRQ_RESERVED_4    12
#define IRQ_COPROCESSOR   13
#define IRQ_HARDDISK      14
#define IRQ_RESERVED_5    15

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/interrupt/irq.c
 */


/*
 * eop
 */

#endif
