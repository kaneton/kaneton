/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/kaneton/segment.h
 *
 * created       julien quintard   [fri feb 11 02:19:44 2005]
 * updated       matthieu bucchianeri   [thu jan 26 11:48:16 2006]
 */

#ifndef KANETON_INTERRUPT_H
#define KANETON_INTERRUPT_H	1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <kaneton/types.h>
#include <kaneton/kaneton.h>

/*
 * ---------- defines ---------------------------------------------------------
 */


/*
 * ---------- macros ----------------------------------------------------------
 */

/*
 * ---------- types -----------------------------------------------------------
 */

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/interrupt/interrupt.c
 *      ../../kaneton/interrupt/exception.c
 *      ../../kaneton/interrupt/irq.c
 *      ../../kaneton/interrupt/pic.c
 */

/*
 * ../../kaneton/interrupt/interrupt.c
 */

t_error		interrupt_init(void);


/*
 * ../../kaneton/interrupt/exception.c
 */

t_error	  exception_init(void);

t_error	  bind_exception(int nb, exception_handler hdl);

void exception_global_handler(int nb);


/*
 * ../../kaneton/interrupt/irq.c
 */

t_error	  irq_init(void);

t_error	  bind_irq(int nb, irq_handler hdl);

void irq_timer_handler(int irq_nb);

void irq_keyboard_handler(int irq_nb);


/*
 * ../../kaneton/interrupt/pic.c
 */

t_error		init_pic(void);

t_error enable_irq(int nb);

t_error disable_irq(int nb);

void	end_of_interrupt(int irq);


/*
 * eop
 */

#endif
