/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/kaneton/pic.h
 *
 * created       Mad   [fri feb 11 02:19:44 2005]
 * updated       Mad   [thu jan 26 11:48:16 2006]
 */

#ifndef KANETON_PIC_H
#define KANETON_PIC_H	1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <arch/machdep/machdep.h>
#include <kaneton/types.h>

/*
 * ---------- defines ---------------------------------------------------------
 */

/*
 * Les deux pics utilises
 * Chaque pic a deux adresses, entree et sortie
 *           IN     OUT
 * Master   0x20   0x21
 * Slave    0xa0   0xa1
 */
#define PIC_MASTER_IN 0x20
#define PIC_SLAVE_IN  0xa0

/*
 * ---------- types -----------------------------------------------------------
 */




/*
 * ---------- macros ----------------------------------------------------------
 */

// This macro allows to write to an I/O port
#define outb(value, port)                                       \
  __asm__ (	                                                \
        "outb %b0,%w1"                                          \
        ::"a" (value),"Nd" (port)                               \
        )                                                       \

// read one byte from port
#define inb(port)                                               \
({                                                              \
  unsigned char _v;                                             \
  __asm__ (	                                                \
        "inb %w1,%0"                                            \
        :"=a" (_v)                                              \
        :"Nd" (port)                                            \
        );                                                      \
  _v;                                                           \
})


/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/interrupt/pic.c
 */


/*
 * eop
 */

#endif
