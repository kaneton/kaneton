/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/include/kaneton/cons.h
 *
 * created       julien quintard   [sun jan 19 14:51:33 2005]
 * updated       matthieu bucchianeri   [tue dec  6 00:48:18 2005]
 */
#ifndef KANETON_CONS_H
#define KANETON_CONS_H		1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <kaneton/types.h>

/*
 * ---------- defines ---------------------------------------------------------
 */
#define CONS_PAGES	5
/*
 * ---------- types -----------------------------------------------------------
 */

typedef struct
{
  t_uint8*		buffer;
  t_uint32	line;
  t_uint8	column;
  t_uint32	maxline;
  t_uint32	display;
  t_uint8	attr;
  t_uint8*	vga;
}		t_cons_buffer;

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/cons/cons.c
 */

/*
 * ../../kaneton/cons/cons.c
 */

void	t_cons_init(void);

void	clean_cons(void);

void	t_cons_printf(char	c);

int		t_printf_char(char	c);

void	t_printf_attr(u_int8_t	attr);

t_error		init_buffered_console(t_uint32 nbr_page);

t_error		clean_buffered_console(void);

t_error		console_scroll_up(void);

t_error		console_scroll_down(void);

void		console_backspace(void);


/*
 * eop
 */

#endif
