/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/include/arch/machdep/kaneton/kaneton.h
 *
 * created       julien quintard   [sat dec 17 17:13:18 2005]
 * updated       matthieu bucchianeri   [tue jan 10 01:26:32 2006]
 */

#ifndef IA32_KANETON_KANETON_H
#define IA32_KANETON_KANETON_H	1

/*
 * ---------- defines ---------------------------------------------------------
 */

#define ___endian		ENDIAN_LITTLE
#define ___wordsz		WORDSZ_32

#define PAGESZ			4096

/*
 * ---------- includes --------------------------------------------------------
 */

#include <arch/machdep/kaneton/as.h>
#include <arch/machdep/kaneton/debug.h>
#include <arch/machdep/kaneton/init.h>
#include <arch/machdep/kaneton/region.h>
#include <arch/machdep/kaneton/segment.h>
#include <arch/machdep/kaneton/stats.h>
#include <arch/machdep/kaneton/task.h>

typedef struct s_init t_init;

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../../../kaneton/arch/machdep/as.c
 *      ../../../../kaneton/arch/machdep/region.c
 *      ../../../../kaneton/arch/machdep/segment.c
 *      ../../../../kaneton/arch/machdep/task.c
 */

/*
 * ../../../../kaneton/arch/machdep/as.c
 */

t_error		ia32_as_reserve(t_tskid task, t_asid* as);

t_error		map_memory_kaneton(t_paddr start, t_paddr end, t_paddr pd, t_asid asid);

t_error		unmap_memory_kaneton(t_paddr start, t_paddr end, t_paddr pd);

t_error		as_paddr(t_asid asid, t_vaddr virtual, t_paddr* physical);

t_error		as_vaddr(t_asid asid, t_segid segid, t_paddr physical, t_vaddr* virtual);


/*
 * ../../../../kaneton/arch/machdep/region.c
 */

t_error		ia32_region_reserve(t_asid asid, t_segid segid, t_paddr offset,
				    t_opts opts, t_vaddr vaddr, t_vsize vsize,
				    t_regid regid);


/*
 * ../../../../kaneton/arch/machdep/segment.c
 */

t_error		ia32_segment_init(void);

t_paddr		ia32_segment_fit(t_segid segid, t_psize psize);

t_error		ia32_segment_read(t_segid segid,t_paddr offs, void* buff, t_psize sz);

t_error		ia32_segment_write(t_segid segid, t_paddr offs, const void* buff, t_psize sz);


/*
 * ../../../../kaneton/arch/machdep/task.c
 */


/*
 * eop
 */

#endif
