/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/include/kaneton/cons.h
 *
 * created       julien quintard   [sun jan 19 14:51:33 2005]
 * updated       matthieu bucchianeri   [tue dec  6 00:48:18 2005]
 */

#ifndef KANETON_KEYBOARD_H
#define KANETON_KEYBOARD_H		1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <kaneton/types.h>

/*
 * ---------- defines ---------------------------------------------------------
 */

#define PORT_CTRL		0x64
#define PORT_IO			0x60

#define STATUS_DATA_READY	0x1
#define STATUS_CMD_BUSY		0x2

#define RET_TOO_MANY		0x00
#define RET_BAT_END		0xaa
#define RET_ECHO		0xee
#define RET_ACK			0xfa
#define RET_BAT_FAILED		0xfc
#define RET_RESEND		0xfe
#define RET_ERROR		0xff

#define PAGE_UP			0x49
#define PAGE_DOWN		0x51
#define BACKSPACE		0xe

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/keyboard/keyboard.c
 */

/*
 * ../../kaneton/keyboard/keyboard.c
 */

void		kbd_checkchar(void);


/*
 * eop
 */

#endif
