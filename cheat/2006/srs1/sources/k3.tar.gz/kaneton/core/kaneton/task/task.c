/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/task/task.c
 *
 * created       julien quintard   [sat dec 10 13:56:00 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:16:37 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * XXX
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * XXX
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(task);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the init variable, filled by the bootloader, containing in this case
 * the list of segments to mark used.
 */

extern t_init*		init;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the task manager variable.
 */

m_task*			task = NULL;

/*
 * the kernel task.
 */

t_tskid			ktask = ID_UNUSED;

/*
 * ---------- functions -------------------------------------------------------
 */

