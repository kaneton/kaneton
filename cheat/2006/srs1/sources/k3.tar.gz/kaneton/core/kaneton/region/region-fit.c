/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/region/region-fit.c
 *
 * created       matthieu bucchianeri   [tue jan 10 01:28:36 2006]
 * updated       matthieu bucchianeri   [tue jan 31 00:21:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file implements simple  fitting algorithms for virtual memory
 * management.
 *
 * you can define which algorithm to use with the macro REGION_FIT.
 *
 *  - FIT_FIRST: first fit algorithm - the first large enough space is taken
 *  - FIT_BEST: best fit algorithm - the smaller space is taken
 *  - ...
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop at least a first-fit algorithm.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(region);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the region manager structure.
 */

extern m_region*       region;

/*
 * ---------- functions -------------------------------------------------------
 */


t_error		region_fit(t_asid asid, t_vsize size, t_vaddr* address)
{
  t_error	error;
  t_iterator	iterator;
  t_state	state;
  t_vsize	tvsize;
  t_vaddr	adr1;
  t_vaddr	adr2;
  o_as*		oas;

  REGION_ENTER(region);

  iterator.u.ll.node = NULL;

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_fit: unable to get as %i\n", asid);
      REGION_LEAVE(region, error);
    }

  set_foreach(SET_OPT_FORWARD, oas->regions, &iterator, state)
    {
      if (iterator.u.ll.node->nxt != NULL)
	{
	  tvsize = ((o_region*)iterator.u.ll.node->data)->size;
	  adr1 = ((o_region*)iterator.u.ll.node->data)->address;
	  adr2 = ((o_region*)iterator.u.ll.node->nxt->data)->address;

	  if ((adr2 - (adr1 + tvsize)) >= size)
	    break;
	}
      else
	{
	  if ((region->size - ((o_region*)iterator.u.ll.node->data)->address) < size)
	    {
	      cons_msg('!', "region: region_fit: unable to allocate region\n");
	      REGION_LEAVE(region, ERROR_NOT_ENOUGH_VIRTUAL_SPACE);
	    }
	  break;
	}
    }

  if (iterator.u.ll.node == NULL)
    *address = 0;
  else
    {
      *address = ((o_region*)iterator.u.ll.node->data)->address +
	((o_region*)iterator.u.ll.node->data)->size;
    }

  REGION_LEAVE(region, ERROR_NONE);
}



