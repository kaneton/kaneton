/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/set/set_array.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 24 19:50:54 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  subpart  of the  set  manager is  used  to  build array  data
 * structures.
 *
 * there  are two  way  to use  the  arrays :  with  pointers or  with
 * objects.    the  first   method   is  the   default  one   (without
 * SET_OPT_ALLOC) : it only  stores pointers refering to objects.  The
 * second method (used with  SET_OPT_ALLOC) makes copies of objects in
 * the set,  using memcpy. with  SET_OPT_FREE, objects are  freed when
 * they   are  removed   from  the   array  or   when  the   array  is
 * flushed/released.
 *
 * the option ORGANISE is used to keep the array as small as possible,
 * but  some operation  requires to  shift entire  parts of  the array
 * (loss of performances).
 *
 * when an array set is cloned, data are reorganised in. it means than
 * when a  clone operation occurs,  the array is reduced  clearing the
 * empty/unused places.
 *
 * options:    SET_OPT_CONTAINER,    SET_OPT_SORT,   SET_OPT_ORGANISE,
 * SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire array data structure.
 *
 * this data structure is very useful to contain very little objects like
 * identifiers.
 *
 * the address space objects, the task objects etc.. use it widely.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */


/*
** This function just returns an error if the set corresponding to u is not
** of the type array.
*/
t_error set_type_array(t_setid u )
{
  t_error error;
  o_set* oset;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);
  if (oset->type != SET_TYPE_ARRAY)
    SET_LEAVE(set, ERROR_TYPE)
  else
    SET_LEAVE(set, ERROR_NONE);
}


/*
** This function displays an entire set.
*/
t_error set_show_array(t_setid u )
{
  t_error error;
  t_state state;
  t_iterator i;
  o_set* data;

  SET_ENTER(set);

  printf("[#] Show Array\n  ");
  set_foreach(SET_OPT_FORWARD, u, &i, state)
    {
      if ((error = set_object(u, i, (void**)&data)) != ERROR_NONE)
	{
	  cons_msg('!', "set: cannot find the set object "
		   "corresponding to its identifier\n");
	  SET_LEAVE(set, error);
	}
      printf("%qd - ", *((t_id *)data));
    }
  printf("\n");
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function returns an iterator on the first element of the set.
*/
t_error set_head_array(t_setid u, t_iterator* iterator )
{
  t_error error;
  t_setsz i;
  o_set* oset;
  t_set_array *a;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  for (i = 0; i < a->arraysz && a->array[i] == NULL; i++)
    ;
  if (i == a->arraysz)
    i = -1;
  iterator->u.array.i = i;
  if (i == -1)
    SET_LEAVE(set, ERROR_EMPTY_SET);
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function returns an iterator on the last element of the set.
*/
t_error set_tail_array(t_setid u, t_iterator* iterator )
{
  t_error error;
  t_setsz i;
  o_set* oset;
  t_set_array *a;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  for (i = a->arraysz; i >= 0 && a->array[i] == NULL; i--)
    ;
  iterator->u.array.i = i;
  if (oset->u.array.array == NULL)
    SET_LEAVE(set, ERROR_EMPTY_SET);
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function returns an iterator on the previous element of the set.
*/
t_error set_prev_array(t_setid u, t_iterator current, t_iterator* previous )
{
  t_error error;
  t_setsz i;
  o_set* oset;
  t_set_array *a;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  for (i = current.u.array.i - 1; i >= 0 && a->array[i] == NULL; i--)
    ;
  if (i < 0)
    {
      previous->u.array.i = -1;
      SET_LEAVE(set, ERROR_EMPTY_SET);
    }
  previous->u.array.i = i;
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function returns an iterator on the next element of the set.
*/
t_error set_next_array(t_setid u, t_iterator current, t_iterator* next )
{
  t_error error;
  t_setsz i;
  o_set* oset;
  t_set_array *a;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  for (i = current.u.array.i + 1; i < a->arraysz && a->array[i] == NULL; i++)
    ;
  if (i == a->arraysz)
    {
      next->u.array.i = -1;
      SET_LEAVE(set, ERROR_END_SET);
    }
  next->u.array.i = i;
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function inserts an object at the head of the set.
*/
t_error set_insert_head_array(t_setid u, void* data )
{
  t_error error;
  t_setsz i;
  o_set* oset;
  t_set_array *a;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  if (a->opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);

  if (a->array[0] != NULL)
    {
      for (i = 0; i < a->arraysz && a->array[i] != NULL; i++)
	;
      if (i == a->arraysz)
        SET_REALLOC_ARRAY(i);
      for (; i > 0; i--)
	a->array[i] = a->array[i - 1];
    }
  if (a->opts & SET_OPT_ALLOC)
    {
      if ((a->array[0] = malloc(a->datasz)) == NULL)
	SET_LEAVE(set, ERROR_NO_MEMORY);
      memcpy(a->array[0], data, a->datasz);
    }
  else
    a->array[0] = data;
  oset->size++;
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function inserts an object at the tail of the set.
*/
t_error set_insert_tail_array(t_setid u, void* data )
{
  t_error error;
  t_setsz i;
  o_set* oset;
  t_set_array *a;


  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  if (a->opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);

  for (i = a->arraysz - 1; i >= 0 && a->array[i] == NULL; i--)
    ;
  if (i == a->arraysz - 1)
    SET_REALLOC_ARRAY(i + 1);
  if (a->opts & SET_OPT_ALLOC)
    {
      if ((a->array[i + 1] = malloc(a->datasz)) == NULL)
	SET_LEAVE(set, ERROR_NO_MEMORY);
      memcpy(a->array[i + 1], data, a->datasz);
    }
  else
    a->array[i + 1] = data;
  oset->size++;
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function inserts an object before the one specified by the iterator.
*/
t_error set_insert_before_array(t_setid u, t_iterator iterator, void* data )
{
  t_error error;
  t_setsz i;
  o_set* oset;
  t_set_array *a;
  void *new;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  if (a->opts & SET_OPT_ALLOC)
    {
      if ((new = malloc(a->datasz)) == NULL)
	SET_LEAVE(set, ERROR_NO_MEMORY);
      memcpy(new, data, a->datasz);
    }
  else
    new = data;

  if (a->opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);

  if (a->array[iterator.u.array.i - 1] == NULL)
    a->array[iterator.u.array.i - 1] = new;
  else
    {
      for (i = iterator.u.array.i; i < a->arraysz && a->array[i] != NULL; i++)
	;
      if (i == a->arraysz)
	SET_REALLOC_ARRAY(i);
      for (; i > iterator.u.array.i; i--)
	a->array[i] = a->array[i - 1];
      a->array[i] = new;
    }
  oset->size++;
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function inserts an object after the one specified by the iterator.
*/
t_error set_insert_after_array(t_setid u, t_iterator iterator, void* data )
{
  t_error error;
  t_setsz i;
  o_set* oset;
  t_set_array *a;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  if (a->opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);

  for (i = iterator.u.array.i + 1; i < a->arraysz && a->array[i] != NULL; i++)
    ;
  if (i == a->arraysz)
    SET_REALLOC_ARRAY(i);
  for (; i > iterator.u.array.i + 1; i--)
    a->array[i] = a->array[i - 1];
  if (a->opts & SET_OPT_ALLOC)
    {
      if ((a->array[i] = malloc(a->datasz)) == NULL)
	SET_LEAVE(set, ERROR_NO_MEMORY);
      memcpy(a->array[i], data,a->datasz);
    }
  else
    a->array[i] = data;
  oset->size++;
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function adds a data object in the set.
*/
t_error set_add_array(t_setid u, void* data )
{
  t_error error;
  t_state state;
  t_setsz i;
  t_iterator iterator;
  o_set* oset;
  t_set_array *a;
  void* tmp;
  void* new;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &(oset->u.array);
  if (a->opts & SET_OPT_ALLOC)
    {
      if ((new = malloc(a->datasz)) == NULL)
	SET_LEAVE(set, ERROR_NO_MEMORY);
      memcpy(new, data, a->datasz);
    }
  else
    new = data;

  if (a->opts & SET_OPT_SORT)
    {
      set_foreach(SET_OPT_FORWARD, u, &iterator, state)
      {
        if ((error = set_object(u, iterator, (void **)&tmp)) != ERROR_NONE)
	{
	  cons_msg('!', "set: cannot find the set object "
		   "corresponding to its identifier\n");
	  SET_LEAVE(set, error);
	}
	if ((*((t_id *)new)) < (*((t_id *)tmp)))
	  {
	  break;
	  }

      }
      if (iterator.u.array.i == -1)
	{
	  for (i = a->arraysz - 1; i >= 0 && a->array[i] == NULL; i--)
	    ;
	  if (i == a->arraysz - 1)
	    SET_REALLOC_ARRAY(i + 1);
	  a->array [i + 1] = new;
	}
      else
	{
	  for (i = iterator.u.array.i; i < a->arraysz && a->array[i] != NULL; i++)
	    ;
	  if (i == a->arraysz)
	    SET_REALLOC_ARRAY(i);
	  for (; i > iterator.u.array.i; i--)
	    a->array[i] = a->array[i - 1];
	  a->array[i] = new;
	}
    }
  else
    {
      for (i = 0; i < a->arraysz && a->array[i] != NULL; i++)
	;
      if (i == a->arraysz)
        SET_REALLOC_ARRAY(i);
      a->array[i] = new;
    }
  oset->size++;
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function removes an object identified by id from the set u.
*/
t_error set_remove_array(t_setid u, t_id id )
{
  t_error error;
  t_iterator iterator;

  SET_ENTER(set);
  if ((error = set_locate_array(u, id, &iterator)) != ERROR_NONE)
    SET_LEAVE(set, error)

  SET_LEAVE(set, set_delete_array(u, iterator));
}


/*
** This function deletes the object corresponding to the iterator.
*/
t_error set_delete_array(t_setid u, t_iterator iterator )
{
  t_error error;
  o_set* oset;
  t_set_array *a;
  t_setsz i;


  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  if (a->opts & SET_OPT_FREE || a->opts & SET_OPT_ALLOC)
    free(a->array[iterator.u.array.i]);

  if (a->opts & SET_OPT_ORGANISE)
  {
    for (i = iterator.u.array.i + 1; i < a->arraysz && a->array[i] != NULL; i++)
      a->array[i - 1] = a->array[i];
    a->array[i - 1] = NULL;
  }
  else
    a->array[iterator.u.array.i] = NULL;
  oset->size--;
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function removes every object stored in the set.
*/
t_error set_flush_array(t_setid u )
{
  t_error error;
  t_iterator it;

  SET_ENTER(set);

  while (set_head(u, &it) == ERROR_NONE)
  {
    if ((error = set_delete(u, it)) != ERROR_NONE)
      SET_LEAVE(set, error);
  }
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function returns an iterator on the element corresponding to the identifier id.
*/
t_error set_locate_array(t_setid u, t_id id, t_iterator* iterator )
{
  int bool = 1;
  t_error error;
  t_setsz i;
  o_set* oset;
  t_set_array *a;
  t_id id_test;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);
  a = &oset->u.array;
  for (i = 0; bool && i < a->arraysz; i++)
    {
      id_test = *((t_id *)(a->array[i]));
      if (id_test == id)
	bool = 0;
    }
  iterator->u.array.i = i - 1;
  if (bool)
    SET_LEAVE(set, ERROR_NO_LOCATE);
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function returns the data object corresponding to the iterator.
*/
t_error set_object_array(t_setid u, t_iterator iterator, void** data )
{
  t_error error;
  o_set* oset;
  t_set_array *a;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  a = &oset->u.array;
  *data = a->array[iterator.u.array.i];
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function adds an object to a FIFO or LIFO structure.
*/
t_error set_push_array(t_setid u, void* data )
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_BAD_STRUCTURE);
}


/*
** This function removes the next object of a FIFO or LIFO structure.
*/
t_error set_pop_array(t_setid u )
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_BAD_STRUCTURE);
 }


/*
** This function returns the next object of a FIFO or LIFO structure without deleting it.
*/
t_error set_pick_array(t_setid u, void** data )
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_BAD_STRUCTURE);
}


/*
** This function releases a set.
*/
t_error set_release_array(t_setid u )
{
  t_error error;
  o_set* oset;

  SET_ENTER(set);
  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);
  if ((error = set_flush_array(u)) != ERROR_NONE)
      SET_LEAVE(set, error);

  free(oset->u.array.array);
  if (u != set->container)
    set_destroy(u);
  SET_LEAVE(set, ERROR_NONE);
}


/*
** This function reserves an array set with options opts. This set will contain objects
** of datasz size and will initialy be composed of initsz unused elements.
*/
t_error set_reserve_array(t_opts opts, t_setsz initsz, t_size datasz, t_setid* u )
{
  t_error error;
  o_set oset;
  o_set *oset_alloc = NULL;

  SET_ENTER(set);

  if (opts >= (1 << 7) || (u == NULL) || ((opts & SET_OPT_FREE) && (opts & SET_OPT_ALLOC)))
    {
      cons_msg('!', "set array: set_reserve_array: invalid argument\n");
      SET_LEAVE(set, ERROR_BAD_ARG);
    }

  if (opts & SET_OPT_CONTAINER)
    {
      if ((oset_alloc = malloc(sizeof(o_set))) == NULL)
	SET_LEAVE(set, ERROR_NO_MEMORY);
      oset_alloc->setid = set->container;
    }
  else
    {
      oset_alloc = &oset;
      if ((error = id_reserve(&set->id, &oset_alloc->setid)) != ERROR_NONE)
	{
	  cons_msg('!', "set: unable to reserve an identifier\n");
	  SET_LEAVE(set, error);
	}
    }
  *u = oset_alloc->setid;
  oset_alloc->u.array.opts = opts;
  oset_alloc->type = SET_TYPE_ARRAY;
  oset_alloc->size = 0;
  oset_alloc->u.array.datasz = datasz;
  oset_alloc->u.array.initsz = initsz;
  oset_alloc->u.array.arraysz = initsz;
  if ((oset_alloc->u.array.array = malloc(initsz * sizeof(void *))) == NULL)
    SET_LEAVE(set, ERROR_NO_MEMORY);
  memset(oset_alloc->u.array.array, 0x0, initsz *sizeof(void *));
  if (opts &  SET_OPT_CONTAINER)
    set->co = oset_alloc;
  else
    {
      if ((error = set_add(set->container, oset_alloc)) != ERROR_NONE)
	SET_LEAVE(set, error);
    }
  SET_LEAVE(set, ERROR_NONE);
}


/*
** Clone a set_array
**
*/
t_error set_clone_array(t_setid u, t_setid *new)
{
  t_error error;
  o_set* oset;
  t_state state;
  t_iterator i;

  SET_ENTER(set);

  if ((error = set_descriptor(u, &oset)) != ERROR_NONE)
    SET_LEAVE(set, error);

  if ((error = set_reserve_array(oset->u.array.opts, oset->u.array.initsz, oset->u.array.datasz, new)) != ERROR_NONE)
    SET_LEAVE(set, error);

  set_foreach(SET_OPT_FORWARD, u, &i, state)
    {
      if ((error = set_add_array(*new, oset->u.array.array[i.u.array.i])) != ERROR_NONE)
	SET_LEAVE(set, error);
    }
  SET_LEAVE(set, ERROR_NONE);
}
