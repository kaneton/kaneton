/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/interrupt/interrupt.c
 *
 * created       chiche   [fri feb 11 03:04:40 2005]
 * updated       chiche   [tue jan 31 00:39:03 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * interruption file
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * none
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/* array of IRQ wrappers, defined in irq_wrap.S */
extern t_vaddr irq_wrapper_array[IRQ_NB];

/* arrays of IRQ handlers, shared with irq_wrap.S */
irq_handler irq_handler_array[IRQ_NB] = { NULL, };


/*
 * ---------- functions -------------------------------------------------------
 */


/*
 * This function initializes the interruption manager.
 */
t_error	  irq_init(void)
{

  // Appelle de la fonction d'initialisation du (roi de) pic
  init_pic();

  // appel de bind_irq pour le clavier et le timer
  bind_irq(IRQ_KEYBOARD, irq_keyboard_handler);
  // bind_irq(IRQ_TIMER, irq_timer_handler);

  return ERROR_NONE;
}

t_error	  bind_irq(int nb, irq_handler hdl)
{
  irq_handler_array[nb] = hdl;
  if (hdl != NULL)
    set_idte_handler(IRQ_BASE + nb, irq_wrapper_array[nb]);
  else
    set_idte_handler(IRQ_BASE + nb, 0);

  if (irq_handler_array[nb] != NULL)
    enable_irq(nb);
  else
    disable_irq(nb);

  return ERROR_NONE;
}

// driver timer
void irq_timer_handler(int irq_nb)
{
  printf("Timer IRQ activated\n");
}

// driver clavier
void irq_keyboard_handler(int irq_nb)
{
  kbd_checkchar();
  end_of_interrupt(PIC_MASTER_IN);
  end_of_interrupt(PIC_SLAVE_IN);
}
