/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/debug/cons-text.c
 *
 * created       quintard julien   [sat may 28 18:23:13 2005]
 * updated       matthieu bucchianeri   [tue jan 31 01:11:52 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file implements a basic console management for kernel bootup.
 *
 * in the  future, the console control  will be passed  to a dedicated
 * server.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * similar to the bootloader one, students will have to develop the
 * code for console display.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * the console variable.
 */

t_cons			cons;

/*
 * ---------- functions -------------------------------------------------------
 */


/*
 * this function prints a status message.
 *
 * '+' is used for printing information about the execution.
 * '#' is used for printing debug information.
 * '!' is used for printing warning and error messages.
 */

void			cons_msg(char				indicator,
				 char*				fmt,
				 ...)
{
  va_list vl;

  va_start(vl, fmt);

  switch(indicator)
    {
    case '+':
      {
	printf("execution: ");
	break;
      }
    case '#':
      {
	printf("debug: ");
	break;
      }
    case '!':
      {
	printf("error: ");
	break;
      }
    }
  printf(fmt, vl);
  va_end(vl);
}

/*
 * This function build the error message before
 * call cons_msg function
 */
void			error_msg(const char *msg,
				  const char * msg_error,
				  ...)
{
  char *str = NULL;
  va_list vl;

  str = malloc(strlen(msg) + strlen(msg_error) + 3);
  va_start(vl, msg);
  str[strlen(msg) + strlen(msg_error) + 2] = 0;
  str = strcat(str, msg);
  str = strcat(str, " ");
  str = strcat(str, msg_error);
  str = strcat(str, "\n");
  cons_msg('!', str, vl);
  free(str);
  va_end(vl);
}
