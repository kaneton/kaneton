/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/test/test.c
 *
 * created       chiche   [fri feb 11 03:04:40 2005]
 * updated       phenix   [tue jan 24 19:50:54 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *  test file
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

t_error test_set(void)
{
  t_setid   id;

  id = test_set_ll();
/*  test_set_insert_before_after(id);*/
//  test_set_add_brute(id);
  test_set_add_sort_locate(id);

  return ERROR_NONE;
}

/*
** main array test function
*/
t_setid test_set_array(void)
{
  t_setid   id;
  t_error   error;

  if ((error = set_reserve(array, SET_OPT_ALLOC, 4, sizeof(t_id), &id)) != ERROR_NONE)
    printf("set_reserve failed with error %i\n", error);

  if ((error = set_type(array, id)) != ERROR_NONE)
    printf("set_type failed with error %i\n", error);
  else
    printf("*** Type of set is ARRAY ***\n");
  return id;
}

/*
** main ll test function
*/
t_setid test_set_ll(void)
{
  t_setid   id;
  t_error   error;

  if ((error = set_reserve(ll, SET_OPT_ALLOC | SET_OPT_SORT, sizeof(t_id), &id)) != ERROR_NONE)
    printf("set_reserve failed with error %i\n", error);

  if ((error = set_type(ll, id)) != ERROR_NONE)
    printf("set_type failed with error %i\n", error);
  else
    printf("*** Type of set is LL ***\n");
  return id;
}


/*
** testing mass add
*/
t_error test_set_add_brute(t_id id)
{
  o_set*    set;
  t_id	    i;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  for (i = 0; i < 20; i++)
    set_add(id, &i);

  set_flush(id);
  /*
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");
    */
  return ERROR_NONE;
}


/*
** testing mass add and locate
*/
t_error test_set_add_sort_locate(t_id id)
{
  o_set*    set;
  t_id	    i;
  t_id	    tmp;
  t_iterator it;
  void * data;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  for (i = 0; i < 100; i++)
  {
    tmp = (i * 100) % 242 * 6;
    set_add(id, &(tmp));
  }
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  if (set_locate(id, 1440, &it) != ERROR_NONE)
    printf("set_locate failed\n");

  set_object(id, it, &data);

  printf("\nelement located = %qd\n", *((t_id *) data));




  set_flush(id);
  /*
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");
    */
  return ERROR_NONE;
}


/*
** testing add
*/
t_error test_set_add(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  o_set*    set;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i5);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i2);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i6);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i4);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i1);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i3);

  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_remove(id, 12);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_remove(id, 11);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_remove(id, 16);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_flush(id);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");
  printf("ERROR REMOVING WHEN EMPTY : %i\n", set_remove(id, 16));

  return ERROR_NONE;
}


/*
** testing head insertion
*/
t_error test_set_insert_head(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  o_set*    set;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_head(id, &i5);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_head(id, &i2);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_head(id, &i6);
  set_insert_head(id, &i4);
  set_insert_head(id, &i1);
  set_insert_head(id, &i3);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  return ERROR_NONE;
}


/*
** testing tail insertion
*/
t_error test_set_insert_tail(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  o_set*    set;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_tail(id, &i5);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_tail(id, &i2);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_insert_tail(id, &i6);
  set_insert_tail(id, &i4);
  set_insert_tail(id, &i1);
  set_insert_tail(id, &i3);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  return ERROR_NONE;
}

/*
** Chiche
*/
t_error test_set_insert_before_after(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  o_set*    set;
  t_iterator chiche;
  t_error error;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  if ((error = set_insert_tail(id, &i2)) != ERROR_NONE)
    printf("CHICHE ERROR %i\n", error);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_locate(id, 12, &chiche);

  set_insert_before(id, chiche, &i1);
  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");
  set_locate(id, 12, &chiche);
  set_insert_after(id, chiche, &i6);
  set_insert_after(id, chiche, &i5);
  set_insert_after(id, chiche, &i4);
  set_insert_after(id, chiche, &i3);

  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  return ERROR_NONE;
}


/*
** Test clone
*/
t_error test_set_clone(t_id id)
{
  t_id	i1 = 11;
  t_id	i2 = 12;
  t_id	i3 = 13;
  t_id	i4 = 14;
  t_id	i5 = 15;
  t_id	i6 = 16;
  t_id	clone;
  o_set*    set;
  o_set*    set_clone;

  if (set_descriptor(id, &set) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (set_descriptor(clone, &set_clone) != ERROR_NONE)
    SET_LEAVE(set_clone, ERROR_UNKNOWN);

  printf("Set vide :\n-->");
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_add(id, &i5);
  set_add(id, &i2);
  set_add(id, &i6);
  set_add(id, &i4);
  set_add(id, &i1);
  set_add(id, &i3);

  printf("Set avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  set_clone(id, &clone);

  printf("Set clone avec %i element :\n-->", set_clone->size);
  if (set_show(clone) != ERROR_NONE)
    printf("set_show failed\n");

  set_flush(id);
  printf("Set d'origine flushe avec %i element :\n-->", set->size);
  if (set_show(id) != ERROR_NONE)
    printf("set_show failed\n");

  return ERROR_NONE;
}

/*
 * as_reserve = OK
 * as_release = OK
 * as_dump = OK
 * as_clone = OK
 *
 * segment_reserve = OK
 * segment_fit = OK
 * segment_clone = OK
 */
void		test_as(void)
{
  t_asid	asid1;
  t_asid	asid2;
  t_asid	asid3;

  t_segid	segid1;
  t_segid	segid2;
  t_segid	segid3;

  o_segment*	seg;

  if (as_reserve(0, &asid1) != ERROR_NONE)
    printf("as test: error as_reserve 1\n");
  if (segment_reserve(asid1, 4096, 2, &segid1) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  if (segment_reserve(asid1, 4096, 2, &segid2) != ERROR_NONE)
    printf("as test: error seg_reserve\n");

  if (as_reserve(0, &asid2) != ERROR_NONE)
    printf("as test: error as_reserve 2\n");
  if (segment_reserve(asid2, 4096, 2, &segid2) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  if (segment_reserve(asid2, 4096, 2, &segid3) != ERROR_NONE)
    printf("as test: error seg_reserve\n");

  if (as_reserve(0, &asid3) != ERROR_NONE)
    printf("as test: error as_reserve 3\n");
  if (segment_reserve(asid3, 4096, 2, &segid2) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  if (segment_reserve(asid3, 4096, 2, &segid3) != ERROR_NONE)
    printf("as test: error seg_reserve\n");

  /*  as_dump();*/

  if (as_release(asid2) != ERROR_NONE)
    printf("as test: error as_release\n");

  /*  if (as_reserve(0, &asid2) != ERROR_NONE)
    printf("as test: error as_reserve 2\n");
  if (segment_reserve(asid2, 4096, 0, &segid2) != ERROR_NONE)
    printf("as test: error seg_reserve\n");
  if (segment_reserve(asid2, 4096, 0, &segid3) != ERROR_NONE)
  printf("as test: error seg_reserve\n");*/

  if (as_clone(0, asid1, &asid2) != ERROR_NONE)
    printf("as test: error as_clone\n");

  printf("segid2 = %qd\n", segid2);
  if (segment_get(segid2, &seg) != ERROR_NONE)
    printf("as test: error segment_get\n");

  /*as_dump();*/
}

void		test_ll(void)
{
  t_setid	id1;
  int		i;
  t_iterator	it;
  t_iterator	it2;

  if (set_reserve(ll, SET_OPT_ALLOC | SET_OPT_SORT, 4, &id1) != ERROR_NONE)
    cons_msg('!', "test_ll: reserve_set_ll 1\n");

  for (i = 0; i < 991; ++i)
    if (set_add(id1, &i) != ERROR_NONE)
      cons_msg('!', "test_ll: set_add_ll\n");

  if (set_head(id1, &it) != ERROR_NONE)
    cons_msg('!', "test_ll: set_head\n");

  for (i = 0; i < 50; ++i)
    if (set_next(id1, it, &it) != ERROR_NONE)
      cons_msg('!', "test_ll: set_next\n");

  if (set_show(id1) != ERROR_NONE)
    cons_msg('!', "test_ll: set_show\n");

  if (set_locate (id1, *(t_id*)(it.u.ll.node->data), &it2) != ERROR_NONE)
    cons_msg('!', "test_ll: set_locate\n");
  printf("id searched = %i -- id found = %i\n", *(int*)( it.u.ll.node->data), *(int*)( it2.u.ll.node->data));
}


void		test_region(void)
{
  t_asid	asid1;
  //t_asid	asid2;
  //t_asid	asid3;

  t_segid	segid1;
  t_segid	segid2;
  t_segid	segid3;

  t_regid	regid1;
  t_regid	regid2;
  t_regid	regid3;
  //t_regid	regid4;

  //o_segment*	seg;

  if (as_reserve(0, &asid1) != ERROR_NONE)
    printf("region test: error as_reserve 1\n");
  if (segment_reserve(asid1, 8192, 2, &segid1) != ERROR_NONE)
    printf("region test: error seg_reserve\n");
  if (segment_reserve(asid1, 8192, 2, &segid2) != ERROR_NONE)
    printf("region test: error seg_reserve\n");
  if (segment_reserve(asid1, 8192, 2, &segid3) != ERROR_NONE)
    printf("region test: error seg_reserve\n");

  if (region_reserve(asid1, segid1, 0, REGION_OPT_NONE, 0, 4096, &regid1) != ERROR_NONE)
    printf("region test: error region_reserve\n");
  if (region_reserve(asid1, segid2, 4096, REGION_OPT_NONE, 65536, 4096, &regid2) != ERROR_NONE)
    printf("region test: error region_reserve\n");
  if (region_reserve(asid1, segid3, 0, REGION_OPT_NONE, 0, 4096, &regid3) != ERROR_NONE)
    printf("region test: error region_reserve\n");

  if (region_reserve(asid1, segid1, 4096, REGION_OPT_FORCE, 65536, 4096, &regid1) != ERROR_NONE)
    printf("region test: error region_reserve\n");
  if (region_reserve(asid1, segid1, 4096, REGION_OPT_FORCE, 65536 + 8192, 4096, &regid1) != ERROR_NONE)
    printf("region test: error region_reserve\n");
  if (region_reserve(asid1, segid3, 4096, REGION_OPT_FORCE, 65536 + 4096, 4096, &regid1) != ERROR_NONE)
    printf("region test: error region_reserve\n");

  /*if(region_release(asid1, regid2) != ERROR_NONE)
  printf("region test: error region_release\n");*/

  /*if (region_reserve(asid1, segid2, 4096, REGION_OPT_NONE, 65536, 4096, &regid2) != ERROR_NONE)
    printf("region test: error region_reserve\n");*/

  /*if (region_reserve(asid1, segid1, 4096, REGION_OPT_FORCE, 4096, 4096, &regid2) != ERROR_NONE)
    printf("region test: error region_reserve\n");*/

  /*if (region_reserve(asid1, segid2, 0, REGION_OPT_NONE, 0, 20, &regid2) != ERROR_NONE)
    printf("region test: error region_reserve\n");
  if (region_reserve(asid1, segid2, 2068, REGION_OPT_NONE, 0, 40, &regid2) != ERROR_NONE)
    printf("region test: error region_reserve\n");
  if (region_reserve(asid1, segid2, 2108, REGION_OPT_NONE, 0, 40, &regid2) != ERROR_NONE)
  printf("region test: error region_reserve\n");*/

  region_dump(asid1);
  //as_show(asid1);

  //segment_dump();

  /*if (as_reserve(0, &asid2) != ERROR_NONE)
    printf("region test: error as_reserve 2\n");
  if (segment_reserve(asid2, 4096, 2, &segid1) != ERROR_NONE)
    printf("region test: error seg_reserve\n");
  if (segment_reserve(asid2, 4096, 2, &segid2) != ERROR_NONE)
    printf("region test: error seg_reserve\n");
  if (segment_reserve(asid2, 4096, 2, &segid3) != ERROR_NONE)
  printf("region test: error seg_reserve\n");*/

  /* if (region_reserve(asid2, segid1, 0, REGION_OPT_NONE, 0, 2048, &regid1) != ERROR_NONE)
     printf("region test: error region_reserve\n");*/

  //region_dump(asid2);

  /*if (as_reserve(0, &asid3) != ERROR_NONE)
    printf("region test: error as_reserve 3\n");
  if (segment_reserve(asid3, 4096, 2, &segid1) != ERROR_NONE)
    printf("region test: error seg_reserve\n");
  if (segment_reserve(asid3, 4096, 2, &segid2) != ERROR_NONE)
    printf("region test: error seg_reserve\n");
  if (segment_reserve(asid3, 4096, 2, &segid3) != ERROR_NONE)
  printf("region test: error seg_reserve\n");*/
}

void		test_as_full(void)
{
  t_asid	asid1;

  if (as_reserve(0, &asid1) != ERROR_NONE)
    printf("region test: error as_reserve 1\n");
  as_show(asid1);
  //segment_display(asid1);
  //segment_dump();
}

void		test_map(void)
{
  t_asid	asid1;
  //t_paddr	paddr;
  t_segid	segid1;
  t_regid	regid1;
  t_vaddr	vaddr;
  //t_segid	segid2;

  if (as_reserve(0, &asid1) != ERROR_NONE)
    printf("region test: error as_reserve 1\n");

  if (segment_reserve(asid1, 8192, 2, &segid1) != ERROR_NONE)
    printf("region test: error seg_reserve\n");

  if (region_reserve(asid1, segid1, 4096, REGION_OPT_FORCE, 409600, 4096, &regid1) != ERROR_NONE)
    printf("region test: error region_reserve\n");

  /*if (map_reserve(asid1, 0, 0, 8192, PERM_READ | PERM_WRITE) != ERROR_NONE)
    printf("map error: map_reserve 1\n");*/

  /*if (segment_reserve(asid1, 4096, 2, &segid1) != ERROR_NONE)
    printf("region test: error seg_reserve\n");
  if (segment_reserve(asid1, 4096, 2, &segid2) != ERROR_NONE)
  printf("region test: error seg_reserve\n");*/

  //segment_dump_as(asid1);

  /*if (map_release(asid1, 0) != ERROR_NONE)
    printf("map error: map_release 1\n");*/

  /*if(as_paddr(asid1, 0, &paddr) != ERROR_NONE)
    printf("map error: as_paddr failed\n");*/

  as_show(asid1);

  if (as_vaddr(asid1, segid1, segid1 + 4096 + 10, &vaddr) != ERROR_NONE)
    printf("translate virtual failed\n");

  printf("trad = %d\n", vaddr);

  /*if (map_reserve(asid1, 0, 0, 8192, PERM_READ | PERM_WRITE) != ERROR_NONE)
    printf("map error: map_reserve 2\n");*/

  //as_show(asid1);
  //segment_dump_as(asid1);
}

/*
 * Test when computer has no more memory for a new segment_reserve
 */
void		test_no_memory(void)
{
  t_asid	asid;
  t_segid	segid;

  if (as_reserve(0, &asid) != ERROR_NONE)
    printf("region test: error as_reserve 1\n");

  while (1)
    segment_reserve(asid, 0x1000000, 2, &segid);
}

void		test_segment_rw(void)
{
  t_asid	asid1;
  t_segid	segid1;
  t_segid	segid2;
  t_uint8*	buffer;

  if (as_reserve(0, &asid1) != ERROR_NONE)
    printf("region test: error as_reserve 1\n");

  if (segment_reserve(asid1, 8192, PERM_WRITE, &segid1) != ERROR_NONE)
    printf("region test: error seg_reserve\n");

  if (segment_reserve(asid1, 8192, PERM_READ, &segid2) != ERROR_NONE)
    printf("region test: error seg_reserve\n");

  as_show(asid1);

  buffer = malloc(101);
  memset(buffer, 69, 101);
  buffer[100] = 0;

  segment_write(segid1, 0, buffer, 101);

  segment_copy(segid2, 0, segid1, 0, 101);
  memset(buffer, 65, 100);
  printf("%s\n", buffer);
  segment_read(segid2, 0, buffer, 101);
  printf("#%s\n", buffer);
}
