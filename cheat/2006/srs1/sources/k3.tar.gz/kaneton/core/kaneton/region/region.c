/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/region/region.c
 *
 * created       julien quintard   [wed nov 23 09:19:43 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:44:09 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the region manager manages mapping of segments.
 *
 * reserving a region means to map virtual addresses to a segment.
 *
 * like for  segment, region identifiers are the  virtual address they
 * maps.
 *
 * unlike segments, regions  are proper to an address  space: there is
 * one set of region objects for each address space to prevent collisions.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to develop  entirely this manager, including the code
 * for one architecture (ia32-virtual or ia32-segment).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(region);

/*
 * ---------- defines ---------------------------------------------------------
 */
#define MAPPED		0x1
#define NO_MAPPED	0x2

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the region manager structure.
 */

m_region*		region;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Displays information on a region.
 */
t_error		region_show(t_asid asid, t_regid regid)
{
  o_region*	oreg;
  t_error	error;

  REGION_ENTER(region);

  if ((error = region_get(asid, regid, &oreg)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_show: impossible to get a region\n");
      REGION_LEAVE(region, error);
    }

  printf("region.regid = %qd\n", oreg->regid);
  printf("region.segid = %qd\n", oreg->segid);
  printf("region.address = %i\n", oreg->address);
  printf("region.offset = %i\n", oreg->offset);
  printf("region.size = %i\n\n", oreg->size);

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Displays information on all regions of the address space.
 */
t_error		region_dump(t_asid asid)
{
  t_state	state;
  o_as*		oas;
  t_iterator	iterator;
  t_error	error;

  REGION_ENTER(region);

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    REGION_LEAVE(region, error);

  set_foreach(SET_OPT_FORWARD, oas->regions, &iterator, state)
    if (region_show(asid, ((o_region*)iterator.u.ll.node->data)->regid) != ERROR_NONE)
      cons_msg('!', "region: region_dump: impossible to show region %qd\n", ((o_region*)iterator.u.ll.node->data)->regid);

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Injects a pre-reserved region.
 */
t_error		region_inject(t_asid asid, o_region* o)
{
  o_as*		oas;
  t_error	error;

  REGION_ENTER(region);

  if (o->regid != o->address)
    o->regid = o->address;

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_inject: unable to get as %qd\n", asid);
      REGION_LEAVE(region, error);
    }

  if ((error = set_add(oas->regions, o)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_inject: unable to add region %qd\n", asid);
      REGION_LEAVE(region, error);
    }

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Function that verify if a virtual address is already in region
 */
t_error		already_reserved(t_asid asid, t_vaddr vaddr, t_vsize vsize)
{
  o_as*		oas;
  t_iterator	iterator;
  t_state	state;
  o_region*	oreg;
  o_region*	oreg2;
  t_error	error;

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_reserve: unable to get as %qd\n", asid);
      REGION_LEAVE(region, error);
    }

  set_foreach(SET_OPT_FORWARD, oas->regions, &iterator, state)
    {
      oreg = (o_region*)iterator.u.ll.node->data;
      /*if ((vaddr >= oreg->address) && (vaddr <= (oreg->address + oreg->size - 1)))
	return MAPPED;*/

      if (iterator.u.ll.node->nxt != NULL)
	{
	  oreg2 = (o_region*)iterator.u.ll.node->nxt->data;
	  if ((vaddr < oreg2->address) && (vaddr >= (oreg->address + oreg->size)))
	    {
	      if ((vaddr + vsize) <= oreg2->address)
		return NO_MAPPED;
	      else
		return MAPPED;
	    }
	}
      else
	if ((oreg->address + oreg->size) <= vaddr)
	  return NO_MAPPED;
	else
	  return MAPPED;
    }

  return NO_MAPPED;
}

/*
 * Reserves a region given some properties.
 */
t_error		region_reserve(t_asid asid, t_segid segid, t_paddr offset, t_opts opts,
			       t_vaddr address, t_vsize size, t_regid* regid)
{
  t_error	error;
  o_as*		oas;
  o_region	oreg;
  o_segment*	oseg;

  REGION_ENTER(region);

  if ((opts != 1) && (opts != 2) && (opts != 4))
    {
      cons_msg('!', "region: region_reserve: bad option\n");
      REGION_LEAVE(region, ERROR_BAD_ARG);
    }

  if ((opts & REGION_OPT_FORCE) && (already_reserved(asid, address, size) == MAPPED))
    {
      cons_msg('!', "region: region_reserve: address already use in as %qd\n", asid);
      return ERROR_REGION_EXIST;
    }

  if ((error = segment_get(segid, &oseg)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_reserve: unable to get segment %qd\n", segid);
      REGION_LEAVE(region, error);
    }

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_reserve: unable to get as %qd\n", asid);
      REGION_LEAVE(region, error);
    }

  if(opts & REGION_OPT_MAPALL)
    {
      size = oseg->size;
      offset = 0;
    }
  else
    if ((oseg->address + offset + size) > (oseg->address + oseg->size))
      {
	cons_msg('!', "region: region_reserve: unable to reserve region it is too big %qd\n", regid);
	REGION_LEAVE(region, ERROR_TOO_BIG_REGION);
      }

  oreg.segid = segid;
  oreg.offset = offset;
  oreg.size = size;
  oreg.address = address;

  if (!(opts & REGION_OPT_FORCE))
    if ((error = region_fit(asid, size, &(oreg.address))) != ERROR_NONE)
      {
	cons_msg('!', "region: region_reserve: unable to find free virtual space\n");
	REGION_LEAVE(region, error);
      }

  oreg.regid = oreg.address;
  *regid = oreg.regid;

  if ((error = set_add(oas->regions, &oreg)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_reserve: unable to add new element in region set\n");
      REGION_LEAVE(region, error);
    }

  if ((error = machdep_call(region, region_reserve, asid,
			    segid, oreg.offset,
			    opts, oreg.address, oreg.size, oreg.regid)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_reserve: unable to map region %qd\n", oreg.regid);
      if (region_release(asid, oreg.regid) != ERROR_NONE)
	cons_msg('!', "region: region_reserve: unable to release region\n");
      REGION_LEAVE(region, error);
    }

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Releases a region.
 */
t_error		region_release(t_asid asid, t_regid regid)
{
  o_region*	oreg;
  t_error	error;
  o_as*		oas;

  REGION_ENTER(region);

  if ((error = region_get(asid, regid, &oreg)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_release: unable to get region %qd\n", regid);
      REGION_LEAVE(region, error);
    }

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_release: unable to get as %qd\n", asid);
      REGION_LEAVE(region, error);
    }

  if ((error = set_remove(oas->regions, regid)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_release: unable to remove region %qd\n", regid);
      REGION_LEAVE(region, error);
    }

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Removes every region that belongs to the specified address space
 */
t_error		region_flush(t_asid asid)
{
  o_as*		oas;
  t_error	error;
  t_iterator	iterator;
  o_set*	oset;

  REGION_ENTER(region);

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_flush: unable to get as %qd\n", asid);
      REGION_LEAVE(region, error);
    }

  if ((error = set_descriptor(oas->regions, &oset)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_flush: unable to get set descriptor\n", asid);
      REGION_LEAVE(region, error);
    }

  while (set_head(oset->setid, &iterator) == ERROR_NONE)
    if ((error = region_release(asid, ((o_region*)iterator.u.ll.node->data)->regid)) != ERROR_NONE)
      REGION_LEAVE(region, error);

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Looks for and returns a region object.
 */
t_error		region_get(t_asid asid, t_regid regid, o_region** o)
{
  t_iterator	iterator;
  t_error	error;
  o_as*		oas;

  REGION_ENTER(region);

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_get: unable to get as %qd\n", asid);
      REGION_LEAVE(region, error);
    }

  if ((error = set_locate(oas->regions, regid, &iterator)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_get: unable to locate region %qd\n", regid);
      REGION_LEAVE(region, error);
    }

  *o = (o_region*)iterator.u.ll.node->data;

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Initializes the region manager.
 */
t_error		region_init(t_vaddr start, t_vsize size)
{
  t_error	error;

  if ((region = malloc(sizeof(m_region))) == NULL)
    {
      cons_msg('!', "region: region_init: cannot allocate memory for the region manager "
               "structure\n");
      return ERROR_NO_MEMORY;
    }

  memset(region, 0x0, sizeof(m_region));

  if ((error = id_build(&region->id)) != ERROR_NONE)
    {
      cons_msg('!', "region: region_init: unable to initialise the identifier object\n");
      return error;
    }

  region->start = start;
  region->size = size;

  STATS_RESERVE("region", &region->stats);

  return ERROR_NONE;
}

/*
 * Cleans the region manager.
 */
t_error		region_clean(void)
{
  REGION_ENTER(region);

  if (region == NULL)
    {
      cons_msg('!', "region: region_clean: region already free\n");
      REGION_LEAVE(region, ERROR_ALREADY_FREE);
    }

  free(region);

  region = NULL;

  REGION_LEAVE(region, ERROR_NONE);
}
