/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/interrupt/interrupt.c
 *
 * created       chiche   [fri feb 11 03:04:40 2005]
 * updated       chiche   [tue jan 31 00:39:03 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * interruption file
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * none
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/* DEBUGGING */
void (*hand)(void);


/* array of exception wrappers, defined in exception_wrap.S */
extern t_vaddr exception_wrapper_array[EXCEPT_NB];

/* arrays of exception handlers, shared with exception_wrappers.S */
exception_handler exception_handler_array[EXCEPT_NB] =
  { NULL, };

/*
 * ---------- functions -------------------------------------------------------
 */


/*
 * This function initializes the interruption manager.
 */
t_error	  exception_init(void)
{
  int i;

  for (i = 0; i < EXCEPT_NB; i++)
    bind_exception(i, exception_global_handler);

  return ERROR_NONE;
}


t_error	  bind_exception(int nb, exception_handler hdl)
{
  exception_handler_array[nb] = hdl;
  if (hdl != NULL)
    set_idte_handler(nb, exception_wrapper_array[nb]);
  else
    set_idte_handler(nb, 0);
  return ERROR_NONE;
}

void exception_global_handler(int nb)
{
  printf("Exception %d raised\n", nb);
  while(1)
    ;
}

