/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/as.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:27:59 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file  implements dependent  code for as  manager on  ia32 with
 * paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_as*		as;
extern t_tskid		ktask;
extern t_init*		init;
extern t_asid		kasid;
/*
 * ---------- globals ---------------------------------------------------------
 */



/*
 * the address space manager interface.
 */

i_as			as_interface =
  {
    NULL, NULL,
    NULL, NULL,
    ia32_as_reserve, NULL,
    NULL, NULL
  };

/*
 * ---------- functions -------------------------------------------------------
 */

t_error		ia32_as_reserve(t_tskid task, t_asid* as)
{
  t_segid	segid;
  t_error	error;
  o_as*		oas;
  o_segment*	oseg;

  if (*as)
    {
      if ((error = segment_reserve(*as, PAGESZ, PERM_READ | PERM_WRITE, &segid)) != ERROR_NONE)
	{
	  cons_msg('!', "as: ia32_as_reserve: unable to reserve segment\n");
	  return error;
	}

      if ((error = as_get(*as, &oas)) != ERROR_NONE)
	{
	  cons_msg('!', "as: ia32_as_reserve: unable to get as %qd\n", *as);
	  segment_release(segid);
	  return error;
	}

      if ((error = segment_get(segid, &oseg)) != ERROR_NONE)
	{
	  cons_msg('!', "as: ia32_as_reserve: impossible to get segment %qd\n", segid);
	  return error;
	}

      oas->machdep.pd_addr = oseg->address;

      if ((error = map_memory_kaneton(oseg->address, oseg->address + PAGESZ, init->machdep.kpd, kasid)) != ERROR_NONE)
	{
	  cons_msg('!', "as: ia32_as_reserve: unable to map new pd of as %qd\n", *as);
	  segment_release(segid);
	  return error;
	}
      memset((void*)oseg->address, 0, PAGESZ);

      if ((error = unmap_memory_kaneton(oseg->address, oseg->address + PAGESZ, init->machdep.kpd)) != ERROR_NONE)
	{
	  cons_msg('!', "as: ia32_as_reserve: unable to unmap new pd of as %qd\n", *as);
	  segment_release(segid);
	  return error;
	}
      //memset((void*)oseg->address, 0, PAGESZ);
    }

  return ERROR_NONE;
}

/*
 * Funtion to map memory temporaly, using to map pd and pt
 */
t_error		map_memory_kaneton(t_paddr start, t_paddr end, t_paddr pd, t_asid asid)
{
  t_paddr	pt = 0;
  t_paddr	cpt = 0;
  t_error	error = ERROR_NONE;
  t_segid	segid;

  for (cpt = start; cpt < end; cpt += 4096)
    {
      pt = get_pt(cpt, pd);

      if (!pt)
	{
	  if ((error = segment_reserve(asid, PAGESZ, PERM_READ | PERM_WRITE, &segid)) != ERROR_NONE)
	    return error;

	  update_pd(cpt, pd, segid);

	  if ((error = map_memory_kaneton(segid, segid + PAGESZ, pd, asid)) != ERROR_NONE)
	    {
	      segment_release(segid);
	      return error;
	    }

	  pt = segid;
	  create_pt(pt);
	}

      update_pt(cpt, pt);
    }
  return ERROR_NONE;
}

/*
 * Function to unmap memory temporaly, using to map pd and pt
 */
t_error		unmap_memory_kaneton(t_paddr start, t_paddr end, t_paddr pd)
{
  t_paddr	cpt = 0;
  t_paddr	pt = 0;
  t_uint32*	entry;
  t_uint32	index;
  t_uint32	i;
  t_error	error;

  for (cpt = start; cpt < end; cpt += 4096)
    {
      pt = get_pt(cpt, pd);

      if (!pt)
	return ERROR_NONE;

      index = get_pt_index(cpt);
      entry = (t_uint32*)pt;
      entry[index] = 0;

      for (i = 0; i < 1024; ++i)
	if (entry[i] != 0)
	  break;

      if (i == 1024)
	{
	  if ((error = segment_release(pt)) != ERROR_NONE)
	    cons_msg('!', "as: unmap_memory_kaneton: unable to release segment %qd\n", pt);

	  if ((error = unmap_memory_kaneton((t_paddr)entry, pt + PAGESZ, pd)) != ERROR_NONE)
	    cons_msg('!', "as: unmap_memory_kaneton: unable to unmap suplementary pt\n");

	  index = get_pd_index(cpt);
	  entry = (t_uint32*)pd;
	  entry[index] = 0;
	}
    }

  flush_tlb();
  return ERROR_NONE;
}

/*
 * This function translates a virtual address to a physical address.
 */
t_error		as_paddr(t_asid asid, t_vaddr virtual, t_paddr* physical)
{
  o_as*		oas;
  t_uint32	pt;
  t_uint32	index;
  t_uint32*	entry;
  t_paddr	paddr;
  t_error	error;

  if (physical == NULL)
    {
      cons_msg('!', "as: as_paddr: physical argument is NULL\n");
      return ERROR_DATA_NULL;
    }

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "as: as_paddr: unable to get as %qd\n", asid);
      return error;
    }

  if ((error = map_memory_kaneton(oas->machdep.pd_addr, oas->machdep.pd_addr + PAGESZ,
				  init->machdep.kpd, kasid )) != ERROR_NONE)
    {
      cons_msg('!', "as: as_paddr: unable to map pd\n");
      return error;
    }

  pt = get_pt(virtual, oas->machdep.pd_addr);

  if (!pt)
    {
      cons_msg('!', "as: as_paddr: pt does not exist\n");
      if ((error = unmap_memory_kaneton(oas->machdep.pd_addr, oas->machdep.pd_addr + PAGESZ, init->machdep.kpd)) != ERROR_NONE)
	cons_msg('!', "as: as_paddr: unable to unmap pd after pt = 0\n");
      return error;
    }

  if ((error = map_memory_kaneton(pt, pt + PAGESZ,
				  init->machdep.kpd, kasid )) != ERROR_NONE)
    {
      cons_msg('!', "as: as_paddr: unable to map pd\n");
      if ((error = unmap_memory_kaneton(oas->machdep.pd_addr, oas->machdep.pd_addr + PAGESZ, init->machdep.kpd)) != ERROR_NONE)
	cons_msg('!', "as: as_paddr: unable to unmap pd after map_memory_kaneton pt error\n");
      return error;
    }

  index = get_pt_index(virtual);
  entry = (t_uint32*)pt;
  paddr = entry[index];

  paddr &= 0xfffff000;
  paddr += get_offset(virtual);

  *physical = paddr;

  if ((error = unmap_memory_kaneton(pt, pt + PAGESZ, init->machdep.kpd)) != ERROR_NONE)
    cons_msg('!', "as: as_paddr: unable to unmap pt\n");

  if ((error = unmap_memory_kaneton(oas->machdep.pd_addr, oas->machdep.pd_addr  + PAGESZ, init->machdep.kpd)) != ERROR_NONE)
    cons_msg('!', "as: as_paddr: unable to unmap pd\n");

  return ERROR_NONE;
}

/*
 * This function translates a physical address to a virtual address.
 */
t_error		as_vaddr(t_asid asid, t_segid segid, t_paddr physical, t_vaddr* virtual)
{
  t_iterator	iterator;
  o_region*	oreg = NULL;
  o_as*		oas;
  t_error	error;
  t_state	state;

  *virtual = 0;

  if (virtual == NULL)
    {
      cons_msg('!', "as: as_vaddr: virtual argument is NULL\n");
      return ERROR_DATA_NULL;
    }

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "as: as_vaddr: unable to get as %qd\n", asid);
      return error;
    }

  set_foreach(SET_OPT_FORWARD, oas->regions, &iterator, state)
    if (((o_region*)iterator.u.ll.node->data)->segid == segid)
      {
	oreg = (o_region*)iterator.u.ll.node->data;
	break;
      }

  if (oreg == NULL)
    {
      cons_msg('!', "as: as_vaddr: region not found\n");
      return ERROR_REGION_NOT_FOUND;
    }

  if (physical > (segid + oreg->offset + oreg->size) || (physical < (segid + oreg->offset)))
    {
      cons_msg('!', "as: as_vaddr: physical not in region\n");
      return ERROR_BAD_ARG;
    }

  *virtual = oreg->address + (physical - (segid + oreg->offset));

  return ERROR_NONE;
}
