/*
 * File to define printf functions for the kernel
 */

#include <klibc.h>
#include <kaneton.h>

extern t_init*	init;

t_cons		cons;
t_cons_buffer	cons_buffer;

/*
 * ---------- functions -------------------------------------------------------
 */

/* <Fixed by Enguerrand> */

/*
** Initialize after bootloader the cons
 */
void	t_cons_init(void)
{
  cons = init->machdep.cons;
  init_buffered_console(CONS_PAGES);
}

/*!
** Set to 0 the global t_cons structure
*/
static void	t_cons_empty(void)
{
      cons.vga = (char *)CONS_ADDR;
      cons.line = 0;
      cons.column = 0;
      cons.attr = CONS_GREEN;
}

/*!
** Clean the console
*/
void	clean_cons(void)
{
  int	i = 0;

  t_cons_empty();
  for (i = 0; i < 4000 ; ++i)
    cons.vga[i] = 0x0;
  clean_buffered_console();
}

void	t_cons_printf(char	c)
{
  int i = 0;

   if (cons.vga != (char *)CONS_ADDR)
      t_cons_init();
   if (c == 10)
     {
       ++cons.line;
       cons.column = 0;
     }
   else
     {
       cons.vga[cons.line * (CONS_COLUMNS * 2) + cons.column] = c;
       cons.vga[cons.line * (CONS_COLUMNS * 2) + cons.column + 1] = cons.attr;

       cons.column = (cons.column + 2) % 160;
       if (!cons.column && cons.line != CONS_LINES)
	 ++cons.line;
     }
   if (cons.line == CONS_LINES && !cons.column)
     {
       for (i = 160; i < 4000; ++i)
	 {
	   cons.vga[i - 160] = cons.vga[i];
	   cons.vga[i] = 0;
	 }
       --cons.line;
     }
}

/*
 * Function to display new cursor
 */
static void		display_cursor(void)
{
  cons_buffer.buffer[cons_buffer.line * (CONS_COLUMNS * 2) + cons_buffer.column] = 8;
  cons_buffer.buffer[cons_buffer.line * (CONS_COLUMNS * 2) + cons_buffer.column + 1] = CONS_FLI | CONS_BLUE;
}

/*
 * Function to erase current cursor
 */
static void		erase_cursor(void)
{
  cons_buffer.buffer[cons_buffer.line * (CONS_COLUMNS * 2) + cons_buffer.column] = 0;
  cons_buffer.buffer[cons_buffer.line * (CONS_COLUMNS * 2) + cons_buffer.column + 1] = 0;
}

/*
 * Function to display console
 */
static void	update_console(void)
{
  t_uint32	i;

  for (i = (cons_buffer.display * 160); i < ((cons_buffer.display + 25) * 160); ++i)
     cons_buffer.vga[i - (cons_buffer.display * 160)] = cons_buffer.buffer[i];
}

/*!
** Print the char c on the console
** @param c : the char to print
** @return : we don't know what to return for the moment (12.02.2006)
*/
int		t_printf_char(char	c)
{
  t_uint32	i;

   if (cons_buffer.vga != (t_uint8*)CONS_ADDR)
     t_cons_init();

   if (c == 10)
     {
       erase_cursor();
       ++cons_buffer.line;
       cons_buffer.column = 0;
       display_cursor();
     }
   else
     {
       cons_buffer.buffer[cons_buffer.line * (CONS_COLUMNS * 2) + cons_buffer.column] = c;
       cons_buffer.buffer[cons_buffer.line * (CONS_COLUMNS * 2) + cons_buffer.column + 1] = cons_buffer.attr;

       cons_buffer.column = (cons_buffer.column + 2) % 160;
       if (!cons_buffer.column && cons_buffer.line != cons_buffer.maxline)
	 {
	   cons_buffer.column = 178;
	   erase_cursor();
	   cons_buffer.column = 0;
	   ++cons_buffer.line;
	 }
       display_cursor();
     }
   if (cons_buffer.line == cons_buffer.maxline && !cons_buffer.column)
     {
       for (i = 160; i < (cons_buffer.maxline * 160);  ++i)
	 {
	   cons_buffer.buffer[i - 160] = cons_buffer.buffer[i];
	   cons_buffer.buffer[i] = 0;
	 }
       --cons_buffer.line;
       display_cursor();
     }
   if ((cons_buffer.line > CONS_LINES - 1) && !cons_buffer.column)
     (cons_buffer.display < (cons_buffer.maxline - 25)) ? ++cons_buffer.display : cons_buffer.display;

   update_console();
   return 0;
}

/*!
** Update cons.attr
*/
void	t_printf_attr(u_int8_t	attr)
{
   cons_buffer.attr = attr;
}

/*
 * Init the console buffer
 */
t_error		init_buffered_console(t_uint32 nbr_page)
{
  t_uint32	i;

  if (cons_buffer.buffer != NULL)
    {
      cons_msg('!', "cons: init_buffered_console: already init\n");
      return ERROR_ALREADY_INIT;
    }

  cons_buffer.buffer = malloc(sizeof(t_uint8) * (4000 * nbr_page));
  memset((void*)cons_buffer.buffer, 0, sizeof(t_uint8) * (4000 * nbr_page));
  cons_buffer.line = cons.line;
  cons_buffer.maxline = nbr_page * 25;
  cons_buffer.column = cons.column;
  cons_buffer.display = 0;
  cons_buffer.vga = cons.vga;
  cons_buffer.attr = cons.attr;
  for (i = 0; i < (25 * 160); ++i)
    cons_buffer.buffer[i] = cons.vga[i];
  return ERROR_NONE;
}

/*
 * Function to clean cons_buffer
 */
t_error		clean_buffered_console(void)
{
  if (cons_buffer.buffer == NULL)
    {
      cons_msg('!', "cons: clean_buffered_console: already clean\n");
      return ERROR_ALREADY_FREE;
    }

  free(cons_buffer.buffer);
  cons_buffer.buffer = NULL;
  return ERROR_NONE;
}

t_error		console_scroll_up(void)
{
  if (!cons_buffer.display)
    return ERROR_NONE;

  --cons_buffer.display;

  update_console();
  return ERROR_NONE;
}

t_error		console_scroll_down(void)
{
  if ((cons_buffer.display + 25) > cons_buffer.line)
    return ERROR_NONE;

  ++cons_buffer.display;

  update_console();
  return ERROR_NONE;
}

void		console_backspace(void)
{
  if (cons_buffer.column)
    {
      cons_buffer.buffer[cons_buffer.line * (CONS_COLUMNS * 2) + cons_buffer.column - 1] = 0;
      cons_buffer.buffer[cons_buffer.line * (CONS_COLUMNS * 2) + cons_buffer.column - 2] = 0;


      erase_cursor();

      cons_buffer.column -= 2;

      display_cursor();

      update_console();
    }
}
