/*
 * File containing map manager function
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * ---------- globals ---------------------------------------------------------
 */

m_map*	map;

/*
 * Reserves a map. This function will so reserve a segment of the given size and finally
 * perform the mapping by reserving a region.
 */
t_error		map_reserve(t_asid asid, t_opts opts,
			    t_vaddr* addr, t_vsize size,
			    t_perms perms)
{
  t_error	error;
  t_segid	segid;
  t_regid	regid;
  t_opts	regopts = REGION_OPT_MAPALL;
  t_vaddr	regaddr;
  o_region*	oreg;

  MAP_ENTER(map);

  if ((opts != MAP_OPT_NONE) && (opts != MAP_OPT_FORCE))
    {
      cons_msg('!', "map: map_reserve: bad option\n");
      MAP_LEAVE(map, ERROR_BAD_ARG);
    }

  if (opts & MAP_OPT_FORCE)
    {
      regopts = REGION_OPT_FORCE;
      if (addr == NULL)
	{
	    cons_msg('!', "map: map_reserve: addr = NULL with MAP_OPT_FORCE option\n");
	    MAP_LEAVE(map, ERROR_DATA_NULL);
	}
      regaddr = *addr;
    }

  if ((error = segment_reserve(asid, size, perms, &segid)) != ERROR_NONE)
    {
      cons_msg('!', "map: map_reserve: unable to reserve a segment\n");
      MAP_LEAVE(map, error);
    }

  if ((error = region_reserve(asid, segid, 0, regopts, regaddr, size, &regid)) != ERROR_NONE)
    {
      cons_msg('!', "map: map_reserve: unable to reserve a region\n");
      if (segment_release(segid) != ERROR_NONE)
	cons_msg('!', "map: map_reserve: unable to release segment after region_reserve error\n");
      MAP_LEAVE(map, error);
    }

  if ((error = region_get(asid, regid, &oreg)) != ERROR_NONE)
    {
      cons_msg('!', "map: map_reserve: unable to get region %qd\n", regid);
      MAP_LEAVE(map, error);
    }

  *addr = oreg->address;

  MAP_LEAVE(map, ERROR_NONE);
}

/*
 * Releases a map.
 */
t_error		map_release(t_asid asid, t_vaddr addr)
{
  t_error	error;
  t_iterator	iterator;
  o_as*		oas;
  o_region*	oreg = NULL;
  t_state	state;

  MAP_ENTER(map);

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "map: map_release: unable to get as %qd\n", asid);
      MAP_LEAVE(map, error);
    }

  set_foreach(SET_OPT_FORWARD, oas->regions, &iterator, state)
    if ( ((o_region*)iterator.u.ll.node->data)->address == addr)
      {
	oreg = (o_region*)iterator.u.ll.node->data;
	break;
      }

  if (oreg == NULL)
    {
      cons_msg('!', "map: map_release: unable to find region %d\n", addr);
      MAP_LEAVE(map, ERROR_REGION_NOT_FOUND);
    }

  if ((error = segment_release(oreg->segid)) != ERROR_NONE)
    {
      cons_msg('!', "map: map_release: unable to release segment %qd\n", oreg->segid);
      MAP_LEAVE(map, error);
    }

  if ((error = region_release(asid, oreg->regid)) != ERROR_NONE)
    {
      cons_msg('!', "map: map_release: unable to release region %qd\n", oreg->regid);
      MAP_LEAVE(map, error);
    }

  MAP_LEAVE(map, ERROR_NONE);
}

/*
 * Initializes the map manager.
 */
t_error map_init(void)
{
  if ((map = malloc(sizeof(m_map))) == NULL)
    {
      cons_msg('!', "map: map_init: unable to malloc map manager\n");
      return ERROR_NO_MEMORY;
    }

  STATS_RESERVE("map", &map->stats);

  return ERROR_NONE;
}

/*
 * Cleans the map manager.
 */
t_error map_clean(void)
{
  MAP_ENTER(map);

  if (map == NULL)
    {
      cons_msg('!', "map: map_clean: map already free\n");
      MAP_LEAVE(map, ERROR_ALREADY_FREE);
    }

  free(map);

  map = NULL;

  MAP_LEAVE(map, ERROR_NONE);
}

