/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/region.c
 *
 * created       julien quintard   [wed dec 14 07:06:44 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:44:47 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file  implements dependent  code for region  manager on  ia32 with
 * paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_region*	region;
extern t_init*		init;
extern t_asid		kasid;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the region manager interface.
 */

i_region		region_interface =
  {
    ia32_region_reserve, NULL,
    NULL, NULL,
    NULL
  };

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Function to map memory reserved
 */
t_error		ia32_region_reserve(t_asid asid, t_segid segid, t_paddr offset,
				    t_opts opts, t_vaddr vaddr, t_vsize vsize,
				    t_regid regid)
{
  t_paddr	cpt = 0;
  t_error	error;
  o_as*		oas;
  t_paddr	pt;
  t_segid	ptsegid;
  t_uint32	index;
  t_uint32*	entry;
  o_segment*	oseg;
  t_paddr	segaddr;
  o_segment*	ptoseg;

  if ((vaddr % PAGESZ) || (vsize % PAGESZ) || (offset % PAGESZ))
    {
      cons_msg('!', "region: ia32_region_reserve: argument not aligned\n");
      return ERROR_BAD_ALIGN;
    }

  if ((error = as_get(asid, &oas)) != ERROR_NONE)
    {
      cons_msg('!', "region: ia32_region_reserve: unable to get as %qd\n", asid);
      return error;
    }

  if ((error = map_memory_kaneton(oas->machdep.pd_addr, oas->machdep.pd_addr + PAGESZ, init->machdep.kpd, kasid)) != ERROR_NONE)
    {
      cons_msg('!', "region: ia32_region_reserve: unable to map pd from as %qd\n", asid);
      return error;
    }

  if ((error = segment_get(segid, &oseg)) != ERROR_NONE)
    {
      cons_msg('!', "region: ia32_region_reserve: unable to get segment  %qd\n", segid);
      return error;
    }

  for (cpt = vaddr, segaddr = (oseg->address + offset);
       cpt < vaddr + vsize;
       cpt += 4096, segaddr += 4096)
    {
      pt = get_pt(cpt, oas->machdep.pd_addr);

      if (!pt)
	{
	  if ((error = segment_reserve(asid, PAGESZ, PERM_READ | PERM_WRITE, &ptsegid)) != ERROR_NONE)
	    {
	      cons_msg('!', "region: ia32_region_reserve: unable to reserve segment for new pt\n");
	      return error;
	    }
	}
      else
	ptsegid = pt;
      if ((error = map_memory_kaneton(ptsegid, ptsegid + PAGESZ, init->machdep.kpd, kasid)) != ERROR_NONE)
	{
	  cons_msg('!', "region: ia32_region_reserve: unable to map pd from as %qd\n", asid);
	  if (segment_release(ptsegid) != ERROR_NONE)
	    cons_msg('!', "region: ia32_region_reserve: unable to release segment\n");
	  return error;
	}

      if (!pt)
	{
	  pt = ptsegid;
	  memset((void*)pt, 0, 1024);
	}

      if ((error = segment_get(pt, &ptoseg)) != ERROR_NONE)
	{
	  cons_msg('!', "region: ia32_region_reserve: unable to get segment %qd\n", segid);
	  if (segment_release(ptsegid))
	    cons_msg('!', "region: ia32_region_reserve: unable to release segment\n");
	  return error;
	}

      index = get_pt_index(cpt);
      entry = (t_uint32*)pt;
      entry[index] = get_pt_entry(segaddr);

      entry = (t_uint32*)oas->machdep.pd_addr;
      index = get_pd_index(cpt);
      entry[index] = get_pd_entry(pt);

      if ((error = unmap_memory_kaneton(ptsegid, ptsegid + PAGESZ, init->machdep.kpd)) != ERROR_NONE)
	cons_msg('!', "region: ia32_region_reserve: unable to map pd from as %qd\n", asid);
    }

  if ((error = unmap_memory_kaneton(oas->machdep.pd_addr, oas->machdep.pd_addr + PAGESZ, init->machdep.kpd)) != ERROR_NONE)
    cons_msg('!', "region: ia32_region_reserve: unable to map pd from as %qd\n", asid);

  return ERROR_NONE;
}
