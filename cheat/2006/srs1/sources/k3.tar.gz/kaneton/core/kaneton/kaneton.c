/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:48:24 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];


extern t_asid		kasid;
/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Funtion to call the init function for the kernel
 */
void		kaneton_init(t_init* bootloader, t_asid* asid)
{
  t_uint32	i;

  init = bootloader;
  alloc_init((t_vaddr) init->alloc, (t_size) init->allocsz, FIT_FIRST);
  t_cons_init();
  printf_init(t_printf_char, t_printf_attr);

  /*
   * init id manager
   */
  if (id_init() != ERROR_NONE)
    return;
  /*
   * init set manager
   */
  if (set_init() != ERROR_NONE)
    return;
  /*
   * init as manager
   */
  if (as_init() != ERROR_NONE)
    return;
  /*
   * init segment manager
   */
  if (segment_init() != ERROR_NONE)
    return;

  /*
  ** init interruptions
  */

  if (interrupt_init() != ERROR_NONE)
    return;

  if (region_init(PAGESZ, REGION_VMEM_MAX) != ERROR_NONE)
    return;

  if (map_init() != ERROR_NONE)
    return;

  /*
   * create kernel address space and inject pre allocated segments in it.
   */
  as_reserve(0, asid);
  kasid = *asid;

  for (i = 0; i < init->nsegments; ++i)
    segment_inject(*asid, init->segments + i);

  for (i = 0; i < init->nregions; ++i)
    region_inject(*asid, init->regions + i);
}

/*
 * Clean all managers
 */
void			kaneton_clean(void)
{
  if (as_clean() != ERROR_NONE)
    {
      printf("AS clean failed\n");
      return;
    }
  if (segment_clean() != ERROR_NONE)
    {
      printf("Segment clean failed\n");
      return;
    }
  if (set_clean() != ERROR_NONE)
    {
      printf("Set clean failed\n");
      return;
    }
  if (id_clean() != ERROR_NONE)
    {
      printf("Id clean failed\n");
      return;
    }
  if (region_clean() != ERROR_NONE)
    {
      printf("Region clean failed\n");
      return;
    }
  if (map_clean() != ERROR_NONE)
    {
      printf("Map clean failed\n");
      return;
    }
}

void			kaneton(t_init*				bootloader)
{
  t_asid		asid;

  /*
   * Init Kaneton data structures
   */
  kaneton_init(bootloader, &asid);

  /*
   * LSE TESTS
   */

#ifdef SERIAL
  debug_init();
#endif


  /*
   * Alloc and free numbers verification
   */
  /*printf("alloc number : %d\n", alloc_nalloc());
    printf("free  number : %d\n", alloc_nfree());*/

  /*
   ****************************** tests ********************************
   */
  /*clean_cons();*/
  /*test_set();*/
  /*test_as();*/
  /*test_ll();*/
  /*test_region();*/
  /*test_as_full();*/
  /*test_map();*/
  /*test_no_memory();*/
  /*test_segment_rw();*/
  /*as_dump();*/
  /*
   ***************************** fin tests *****************************
   */

  /*
   * Print all segment information of t_segment
   */
  /*print_seg_reg(init);*/

  /*
   * Print all region information of t_region
   */
  /*print_module(init);*/

  /*
   * Print all t_init fields
   */
  /*print_t_init(init);*/

  /*
   * Clean Kaneton data structures
   */
  kaneton_clean();

  /*
   * Alloc and free verification
   */
  /*printf("alloc number : %d\n", alloc_nalloc());
    printf("free  number : %d\n", alloc_nfree());*/

  while (1)
    ;
}

