/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/pic/pic.c
 *
 * created       chiche   [fri feb 11 03:04:40 2005]
 * updated       chiche   [tue jan 31 00:39:03 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * pic file
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * none
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Fonction qui initialise les (pommes d'a) PICs
 *
 */
t_error		init_pic(void)
{
  /* Send ICW1: 8086 mode + NOT Single ctrl + call address
     interval=8 */
  outb(0x11, PIC_MASTER_IN);
  outb(0x11, PIC_SLAVE_IN);

  /* Send ICW2: ctrl base address */
  outb(0x20, PIC_MASTER_IN+1);
  outb(0x28, PIC_SLAVE_IN+1);

  /* Send ICW3 master: mask where slaves are connected */
  outb(0x4, PIC_MASTER_IN+1);
  /* Send ICW3 slave: index where the slave is connected on master */
  outb(0x2, PIC_SLAVE_IN+1);

  /* Send ICW4: 8086 mode, fully nested, not buffered, no implicit EOI */
  outb(0x1, PIC_MASTER_IN+1);
  outb(0x1, PIC_SLAVE_IN+1);

  /* Send OCW1:
   * Closing all IRQs : waiting for a correct handler The only IRQ
   * enabled is the cascade (that's why we use 0xFB for the master) */
  outb(0xFB, PIC_MASTER_IN+1);
  outb(0xFF, PIC_SLAVE_IN+1);

  asm ("sti\n\t");

  printf("IRQ init done\n");
  return ERROR_NONE;
}


t_error enable_irq(int nb)
{
  if(nb < 8)
    /*  irq on master PIC */
    outb((inb(PIC_MASTER_IN+1) & ~(1 << nb)), PIC_MASTER_IN+1);
    else
    /*  irq on slave PIC */
    outb((inb(PIC_SLAVE_IN+1) & ~(1 << (nb-8))), PIC_SLAVE_IN+1);

  printf("IRQ line #%d enabled\n", nb);
  return ERROR_NONE;
}


t_error disable_irq(int nb)
{
  if(nb < 8)
    /*  irq on master PIC */
    outb((inb(PIC_MASTER_IN+1) | (1 << nb)), PIC_MASTER_IN+1);
  else
    /*  irq on slave PIC */
    outb((inb(PIC_SLAVE_IN+1) | (1 << (nb-8))), PIC_SLAVE_IN+1);

  printf("IRQ line #%d disabled\n", nb);
  return ERROR_NONE;
}

void	end_of_interrupt(int irq)
{
  if (irq <= 7)
    outb(0x60 + irq, PIC_MASTER_IN);
  else if (irq <= 15)
    outb(0x60 + irq - 8, PIC_SLAVE_IN);
}
