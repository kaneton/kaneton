/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/interrupt/interrupt.c
 *
 * created       chiche   [fri feb 11 03:04:40 2005]
 * updated       chiche   [tue jan 31 00:39:03 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * interruption file
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * none
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */


/*
 * This function initializes the interruption manager.
 */
t_error		interrupt_init(void)
{
  // setting IDT - filling 256 entries with default values
  idt_init();

  // binding exceptions with their handlers in asm, which calls a C handler
  exception_init();

  // binding IRQ with their handlers
  irq_init();
  return ERROR_NONE;
}

