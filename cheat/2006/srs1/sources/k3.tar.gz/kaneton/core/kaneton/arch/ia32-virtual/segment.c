/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:29:40 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  file implements dependent  code for  segment manager  on ia32
 * with paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_segment*	segment;
extern t_init*		init;
extern t_asid		kasid;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager interface.
 */

i_segment		segment_interface =
  {
    NULL, NULL,
    NULL, NULL,
    NULL, NULL,
    ia32_segment_read, ia32_segment_write,
    NULL, NULL,
    NULL, NULL,
    NULL, NULL,
    NULL, ia32_segment_init,
    NULL, ia32_segment_fit
  };

/*
 * ---------- functions -------------------------------------------------------
 */

t_error		ia32_segment_init(void)
{
  struct gdt_segment_descriptor* gdt;

  /* allocating space for gdt, after 16Mo */
  gdt = (struct gdt_segment_descriptor*) init->machdep.gdtr;
  /* creating new gdt descriptors */

  /* Kernel code and data */
  set_segment_descriptor(DPL_0, CODE, gdt + 1);
  set_segment_descriptor(DPL_0, DATA, gdt + 2);

  /* Driver code and data */
  set_segment_descriptor(DPL_1, CODE, gdt + 3);
  set_segment_descriptor(DPL_1, DATA, gdt + 4);

  /* Service code and data */
  set_segment_descriptor(DPL_2, CODE, gdt + 5);
  set_segment_descriptor(DPL_2, DATA, gdt + 6);

  /* User program code and data */
  set_segment_descriptor(DPL_3, CODE, gdt + 7);
  set_segment_descriptor(DPL_3, DATA, gdt + 8);

  set_gdt(gdt, 9);

  return ERROR_NONE;
}

/*
 * Return address align to PAGESZ
 */
t_paddr		ia32_segment_fit(t_segid segid, t_psize psize)
{
  return segid + (nbr_page(psize) * PAGESZ);
}

/*
 * Map segment red by independant function
 */
t_error		ia32_segment_read(t_segid segid,t_paddr offs, void* buff, t_psize sz)
{
  o_segment*	oseg;
  t_error	error;

  if ((error = segment_get(segid, &oseg)) != ERROR_NONE)
    {
      cons_msg('!', "segment: ia32_segment_read: impossible to get a segment\n");
      return error;
    }

  if ((error = map_memory_kaneton(oseg->address, oseg->address + sz, init->machdep.kpd, kasid)) != ERROR_NONE)
    {
      cons_msg('!', "region: ia32_segment_read: unable to map segment %qd\n", segid);
      return error;
    }

  memcpy(buff, (const void*)oseg->address + offs, sz);

  if ((error = unmap_memory_kaneton(oseg->address, oseg->address + sz, init->machdep.kpd)) != ERROR_NONE)
    {
      cons_msg('!', "region: ia32_segment_read: unable to unmap segment %qd\n", segid);
      return error;
    }
  return ERROR_NONE;
}

/*
 * Map segment wrote by independant function
 */
t_error		ia32_segment_write(t_segid segid, t_paddr offs, const void* buff, t_psize sz)
{
  o_segment*	oseg;
  t_error	error;

  if ((error = segment_get(segid, &oseg)) != ERROR_NONE)
    {
      cons_msg('!', "segment: ia32_segment_write: impossible to get a segment\n");
      return error;
    }

  if ((error = map_memory_kaneton(oseg->address, oseg->address + sz, init->machdep.kpd, kasid)) != ERROR_NONE)
    {
      cons_msg('!', "region: ia32_segment_write: unable to map segment %qd\n", segid);
      return error;
    }

  memcpy((void*)oseg->address + offs, (const void*)buff, sz);

  if ((error = unmap_memory_kaneton(oseg->address, oseg->address + sz, init->machdep.kpd)) != ERROR_NONE)
    {
      cons_msg('!', "region: ia32_segment_write: unable to unmap segment %qd\n", segid);
      return error;
    }
  return ERROR_NONE;
}
