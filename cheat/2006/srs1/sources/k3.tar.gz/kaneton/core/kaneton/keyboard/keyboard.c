/*
 * File for the keyboard driver
 */

#include <klibc.h>
#include <kaneton.h>

t_uint8		key_table[] =
  {
    0, 0, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
    '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
    0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0,
    '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0, '*', 0, ' ', 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', '8', '9', '-', '4', '5', '6', '+',
    '1', '2', '3', '0', '.', 0, 0
  };


t_uint8		key_table_shift[] =
  {
    0, 0, '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '\b',
    '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\n',
    0, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '\"', '~', 0,
    '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0, '*', 0, ' ', 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', '8', '9', '-', '4', '5', '6', '+',
    '1', '2', '3', '0', '.', 0, 0
  };

/*
 * ---------- functions -------------------------------------------------------
 */

static t_uint8	recv_data(void)
{
  while ((inb(PORT_CTRL) & STATUS_DATA_READY) == 0)
    ;
  return inb(PORT_IO);
}

void		kbd_checkchar(void)
{
  t_uint8	k;

  k = recv_data();

  switch(k)
    {
    case RET_TOO_MANY:
    case RET_BAT_END:
    case RET_ECHO:
    case RET_ACK:
    case RET_BAT_FAILED:
    case RET_RESEND:
    case RET_ERROR:
      break;
    case PAGE_UP:
      {
	console_scroll_up();
	break;
      }
    case PAGE_DOWN:
      {
	console_scroll_down();
	break;
      }
    case BACKSPACE:
      {
	console_backspace();
	break;
      }
    default:
      {
	if (k < sizeof (key_table))
	  printf("%c", key_table[k]);
      }

    }
}

