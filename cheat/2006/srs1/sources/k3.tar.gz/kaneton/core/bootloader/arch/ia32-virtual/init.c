 /*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/bootloader/arch/ia32-virtual/init.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       matthieu bucchianeri   [tue jan 17 22:24:35 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this file contains the functions intended to do the relocation.
 *
 * this file is very important because it does the most important things
 * of the bootloader: computes segments and regions, relocates data, creates
 * the init structure etc..
 *
 * the relocation is based on dynamic allocation. nevertheless, no dynamic
 * allocation is provided. the student so has to setup a very simple dynamic
 * memory allocation algorithm to be able to build the init structure.
 *
 * think about it because some components cannot have a dynamic address. there
 * are some crazy problems to resolve in this context.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"
#include "init.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * init variable, describing the initial memory layout.
 *
 * this structure will be passed to the kernel describing modules,
 * physical memory reserved by the hardware etc.. thus the kernel will
 * be able to initialise its managers: segment manager, module manager etc..
 */

t_init*			init;

t_uint32		adr = RELOCATE_BASE;

/*
 * ---------- functions -------------------------------------------------------
 */

/*Added by Enguerrand and Mad*/

/*
 * Function to alloc the page number calculate
 * with the byte number specified by size
 */
t_uint32 		alloc_pages(t_uint32 size)
{
  t_uint32 res = adr;

  adr += nbr_page(size) * 4096;
  return res;
}

/*
 * Function to dealloc the page number calculate
 * with the byte number specified by size
 */
t_uint32		dealloc(t_uint32 size)
{
  adr -= nbr_page(size) * 4096;
  return adr;
}

/* allocate new page if needed :
** if cur - start > actual nbpages, then alloc
*/
static void check_allocation(void * start, void * cur, t_uint8 * nbpages)
{
      /* if more than 1 page is used, allocate a new one */
      if ((t_uint32) cur - (t_uint32) start > *nbpages * 4096)
      {
	alloc_pages(4096);
	(*nbpages)++;
      }
}

/*
** fonction that moves the kernel
** above 16Mo and returns the size moved
*/
static t_uint32	  move_kernel(multiboot_info_t* mbi)
{
  t_uint32 flags = mbi->flags;
  t_uint32 start;
  t_uint32 end;
  t_uint32 addr;
  t_uint32 location;
  char* label;

  /* mbi->flag[3] = module flag
  ** if set, then modules are activated
  ** see multiboot information on grub website
  */
  if (flags & 0x100)
  {
    addr = mbi->mods_addr;
    /* kernel start address */
    start = (t_uint32) *((t_uint32 *) addr);
    /* kernel end address */
    end = (t_uint32) *((t_uint32 *) (addr + 4));
    /* kernel label */
    label = (char *) *((t_uint32 *) (addr + 8));

    location = alloc_pages(end - start);
    /* kernel copy at location (above 16 Mo) */
    memcpy((void *) location, (void *) start, end - start);

    return end - start;
  }
  return 0;
}

/*
** fonction that moves the modules
** above 16Mo at 'location' and returns the size moved
*/
static t_uint32   move_modules(multiboot_info_t* mbi,
				t_uint32	location)
{
  t_modules* mods = (t_modules *) location;

  t_uint32 flags = mbi->flags;
  t_uint32 start;
  t_uint32 end;
  t_uint32 addr;
  t_module* mod;
  t_uint32 cpt;
  t_uint8 nbpages = 1;
  char * label;
  int i;

  /* mbi->flag[3] = module flag
  ** if set, then modules are activated
  ** see multiboot information on grub website
  */
  if (flags & 0x100)
  {
    mods->nmodules = mbi->mods_count - 1;
    mod = (t_module*) (location + sizeof (t_modules));
    cpt = (t_uint32) mod + sizeof(t_module) * mods->nmodules;

    for (i = 0; i < mods->nmodules; i++)
    {
      check_allocation((void *) mods, (void *) (mod + sizeof (t_module)), &nbpages);
      addr = mbi->mods_addr + (i + 1) * sizeof (module_t);
      /* module start address */
      start = (t_uint32) *((t_uint32 *) addr);
      /* module end address */
      end = (t_uint32) *((t_uint32 *) (addr + 4));
      /* module label pointer */
      label = (char *) *((t_uint32 *) (addr + 8));

      mod->name = (char *) (cpt + (end - start));
      cpt = (t_uint32) mod->name + strlen(label) + 1;
      /* module size */
      mod->size = end - start;
      mod = (t_module *) ((t_uint32) mod + sizeof(t_module));
    }
    check_allocation((void *) mods, (void *) mod, &nbpages);

    for (i = 0; i < mods->nmodules; i++)
    {
      addr = mbi->mods_addr + (i + 1) * sizeof (module_t);
      /* module start address */
      start = (t_uint32) *((t_uint32 *) addr);
      /* module end address */
      end = (t_uint32) *((t_uint32 *) (addr + 4));
      /* module label pointer */
      label = (char *) *((t_uint32 *) (addr + 8));

      /* module copy at location (above 16 Mo) */
      memcpy((void *) mod, (void *) start, end - start);
      mod = (t_module*) (((t_uint32) mod) + end - start);
      check_allocation((void *) mods, (void *) mod, &nbpages);

      memcpy((void *) mod, (void *) label, strlen(label) + 1);
      mod = (t_module*) (((t_uint32) mod) + strlen(label) + 1);
      check_allocation((void *) mods, (void *) mod, &nbpages);
    }
    return nbpages * 4096;
  }
  return 0;
}

/*
 * Fill one segment on t_segment
 * each params fill one field of the structure
 * o_segment
 */
void		fill_one_segment(t_paddr addr, t_psize size, t_perms perms)
{
  o_segment*	osegment;

  osegment = (void*)init->segments + (init->nsegments * sizeof(o_segment));
  osegment->address = addr;
  osegment->size = size;
  osegment->perms = perms;
  ++init->nsegments;
}

/*
 * Initialize t_segments memory area with ten segments
 * describe in k1.pdf
 *
 * Permissions: R->Read, W->Write, E->Exec
 *
 * Null segment nothing
 * ISA segment RW
 * GDT segment R
 * kernel segment RE
 * init segment R
 * t_modules segment R
 * t_segment segment R
 * t_region segment R
 * stack segment RW
 * alloc segment RW
 * PD segment RW
 */
static void	fill_t_segments(t_init* init)
{
  /* Null segment */
  fill_one_segment(0x0, PAGESZ, PERM_READ | PERM_WRITE);

  /* ISA segment */
  fill_one_segment(ISA_START, nbr_page(ISA_SIZE) * PAGESZ, PERM_READ | PERM_WRITE);

  /* GDT segment */
  fill_one_segment(RELOCATE_BASE, PAGESZ, PERM_READ | PERM_WRITE);

  /* kernel segment */
  fill_one_segment(init->kcode, init->kcodesz, PERM_READ | PERM_EXEC);

  /* init segment */
  fill_one_segment(init->init, PAGESZ, PERM_READ);

  /* t_modules segment */
  fill_one_segment((t_paddr)init->modules, init->modulessz, PERM_READ | PERM_WRITE);

  /* t_segments segment */
  fill_one_segment((t_paddr)init->segments, PAGESZ, PERM_READ);

  /* t_regions segment */
  fill_one_segment((t_paddr)init->regions, PAGESZ, PERM_READ);

  /* stack segment */
  fill_one_segment(init->kstack, init->kstacksz, PERM_READ | PERM_WRITE);

  /* alloc segment */
  fill_one_segment(init->alloc, init->allocsz, PERM_READ | PERM_WRITE);

  /* Kernel PD*/
  //fill_one_segment(alloc_pages(0), PAGESZ, PERM_READ | PERM_WRITE);
}

/*
 * Fill one segment on t_segment
 * each params fill one field of the structure
 * o_segment
 */
static void	fill_one_region(t_vaddr addr, t_vsize size, o_region* regions)
{
  regions->address = addr;
  regions->segid = addr;
  regions->offset = 0;
  regions->size = size;
}

/*
 * Initialize t_regions memory area with six segments
 * describe in k1.pdf
 */
static void	fill_t_regions(t_init* init)
{
  o_region*	regions = init->regions;

  /* ISA region */
  fill_one_region(ISA_START, ISA_SIZE, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* GDT region */
  fill_one_region(RELOCATE_BASE, PAGESZ, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* kcode region */
  fill_one_region(init->kcode, init->kcodesz, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* t_init region */
  fill_one_region(init->init, PAGESZ, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* kstack region */
  fill_one_region(init->kstack, init->kstacksz, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* alloc region */
  fill_one_region(init->alloc, init->allocsz, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* PD region */
  fill_one_region((t_vaddr)(((void*) init->alloc) + init->allocsz), PAGESZ, regions);
}

/*
 * Funtion to fill the t_init memory area
 */
void	fill_t_init(multiboot_info_t*	mbi, t_paddr gdt)
{
  t_uint32 kernel_size;
  t_uint32 modules_size;
  t_uint32 modules_start;
  t_uint32 alloc_size;
  t_uint32 alloc_start;

  /* moving kernel code */
  kernel_size = move_kernel(mbi);

  /* allocate t_init area */
  init = (t_init*)alloc_pages(PAGESZ);

  init->machdep.gdtr = gdt;

  modules_start = alloc_pages(PAGESZ);
  /* moving grub modules */
  modules_size = move_modules(mbi, modules_start);

  /* allocate the t_segments area */
  init->segments = (o_segment*)alloc_pages(PAGESZ);

  /* allocate the t_regions area */
  init->regions = (o_region*)alloc_pages(PAGESZ);

  /* allocate the stack */
  init->kstack = (t_paddr) alloc_pages(INIT_KSTACKSZ);
  init->kstacksz = (t_psize) INIT_KSTACKSZ;

  /* allocate alloc for the kernel */
  alloc_size = 0x200000;
  alloc_start = alloc_pages(alloc_size);

  init->mem = mbi->mem_lower;
  init->memsz = nbr_page((mbi->mem_upper - mbi->mem_lower) * 1024) * PAGESZ;

  init->kcode = KCODE_START;
  init->kcodesz = (nbr_page(kernel_size) * PAGESZ);

  init->init = (t_paddr)init;
  init->initsz = PAGESZ;

  init->modules = (t_modules*)modules_start;
  init->modulessz = modules_size;

  init->nsegments = 0;
  init->segmentssz = PAGESZ;

  init->nregions = 7;
  init->regionssz = PAGESZ;

  init->alloc = alloc_start;
  init->allocsz = alloc_size;

  /* Fill the segment t_segments the sizes are multiple of 4096 */
  fill_t_segments(init);

  /* Fill the segment t_regions the sizes are multiple of 4096 */
  fill_t_regions(init);
}
