/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/pmode/pmode.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:31:13 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef IA32_IA32_PMODE_H
#define IA32_IA32_PMODE_H	1

/* segment descriptor
** contains a 64 bit array with information on a gdt segment
*/
struct gdt_segment_descriptor
{
  t_uint16  segment_limit_15_0;
  t_uint16  base_address_15_0;
  t_uint8   base_address_23_16;
  t_uint8   segment_type:4;
  t_uint8   descriptor_type:1;
  t_uint8   dpl:2;
  t_uint8   segment_present:1;
  t_uint8   segment_limit_19_16:4;
  t_uint8   avl:1;
  t_uint8   bit64:1;
  t_uint8   operation_size:1;
  t_uint8   granularity:1;
  t_uint8   base_address_31_24;
} __attribute__ ((packed, aligned (8)));


/* segment register
** contains the limit and base for the gdt
*/
struct gdt_segment_register
{
  t_uint16  limit;
  t_uint32  base;
} __attribute__((packed, aligned(8)));



int   set_gdt();
int   set_pmode();

#endif
