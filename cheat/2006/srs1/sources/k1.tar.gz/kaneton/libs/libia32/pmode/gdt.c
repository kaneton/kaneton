/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/pmode/gdt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:45:19 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:57:21 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage global descriptor table.
 *
 */


/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have  to place here code to manage  gdt. there are no
 * restrictions on prototypes, names etc.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */


static void	set_segment_descriptor(	t_uint8 is_kernel,
					t_uint8 is_code,
					struct gdt_segment_descriptor* sd)
{
  sd->segment_limit_15_0 = 0xFFFF;
  sd->base_address_15_0 = 0x0000;
  sd->base_address_23_16 = 0x00;
  sd->segment_type = (is_code ? 0xb : 0x3);
  sd->descriptor_type = 0x1;
  sd->dpl = (is_kernel ? 0x0 : 0x3);
  sd->segment_present = 0x1;
  sd->segment_limit_19_16 = 0xF;
  sd->avl = 0x0;
  sd->bit64 = 0x0;
  sd->operation_size = 0x1;
  sd->granularity = 0x1;
  sd->base_address_31_24 = 0x00;
  
}

/*
** Sets GDT at address alloc,
** and goes into protected mode
*/
int   set_gdt(t_uint32 alloc)
{
  struct gdt_segment_register gdtr;
  struct gdt_segment_descriptor* gdt;
 
  /* allocating space for gdt, after 16Mo */
  gdt = (struct gdt_segment_descriptor*) alloc;
  
  /* creating gdt descriptors */
  set_segment_descriptor(1, 1, gdt + 1);
  set_segment_descriptor(1, 0, gdt + 2);
  set_segment_descriptor(0, 1, gdt + 3);
  set_segment_descriptor(0, 0, gdt + 4);
  
  /* creating gdtr register */
  gdtr.limit = 40;
  gdtr.base = (t_uint32) gdt;

  /* setting gdt */
  asm("lgdt %0\n\t"
      :
      : "m" (gdtr));

  /* going into protected mode */
  asm (	"mov %%cr0,%%eax\n\t"
	"orl %%eax, 1\n\t"
        "mov %%eax,%%cr0"
      :
      :
      : "eax");

  /* updating segment registers */
  asm(	"ljmp $0x8, $lbl    \n\t"
        "lbl:             \n\t"
	"movw $0x10, %%ax    \n\t"
        "movw %%ax,  %%ss \n\t"
        "movw %%ax,  %%ds \n\t"
        "movw %%ax,  %%es \n\t"
        "movw %%ax,  %%fs \n\t"
        "movw %%ax,  %%gs"
	:
	:
	: "eax" );

  return 0;
}

