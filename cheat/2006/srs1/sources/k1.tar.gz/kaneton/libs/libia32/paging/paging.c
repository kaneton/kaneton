/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/paging.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:05 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:51:57 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage paging.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will have  to fill  this  file with  function related  to
 * paging mode in the cpu: enable, disabling etc.
 *
 * there are no  restrictions about these functions, but  keep in mind
 * that  page-directory management and  page-tables management  are to
 * place in pd.c and pt.c.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */

/*
** create a pd in memory and sets all bit to 0
*/
t_uint32 create_pd(t_uint32 location)
{
  t_uint32* i;

  for (i = (t_uint32 *) location; (t_uint32) i < location + 4096; i++)
    *i = 0;

  return location;
}

/*
** create a pt in memory and sets all bit to 0
*/
t_uint32 create_pt(t_uint32 location)
{
  t_uint32* i;

  for (i = (t_uint32 *) location; (t_uint32) i < location + 4096; i++)
    *i = 0;

  return location;
}


/*
** return the pt that allows to find the address 'p' in memory,
** or -1 if that page table is not available.
*/
t_uint32 get_pt(t_uint32 p, t_uint32 pd)
{
  t_uint32* pde;
  t_uint32 offset;

  offset = (p >> 22) & 0x000003FF;

  /* check if the page table is present */
  pde = (t_uint32 *) pd + offset;
  if (((*pde) & 1) == 0)
    return 0;
  else
      return ((*pde) >> 12) << 12;
}


/*
** Updates the page directory with the entry 'pt', at offset given by 'p'
*/
t_uint32 update_pd(t_uint32 p, t_uint32 pd, t_uint32 pt)
{
  t_uint32* pde;
  t_uint32 offset;

  offset = (p >> 22) & 0x000003FF;
  pde = (t_uint32 *) (pd + (sizeof(t_uint32) * offset));
  /* kernel privilege + read-write + present */
  *pde = ((pt >> 12) << 12) + 3;
  return 0;
}


/*
** Updates the page table with the entry 'p', at offset given by 'p'
*/
t_uint32 update_pt(t_uint32 p, t_uint32 pt)
{
  t_uint32* pte;
  t_uint32 offset;

  offset = ((p & 0x003FF000) >> 12);
  pte = (t_uint32*) pt + offset;
  *pte = ((p >> 12) << 12) + 3;
  return 0;
}


/*
** Sets pagination
*/
t_uint32 install_paging(t_uint32 pd)
{
  t_uint32 tmp = pd;

  asm("movl %0, %%cr3\n\t"
      "movl %%cr0, %%eax\n\t"
      "orl $0x80010000, %%eax\n\t"
      "movl %%eax, %%cr0\n\t"
      :
      : "r" (tmp)
      : "eax");
  return 0;
}

