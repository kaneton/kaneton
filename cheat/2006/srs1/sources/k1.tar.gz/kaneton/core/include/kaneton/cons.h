/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/include/kaneton/cons.h
 *
 * created       julien quintard   [sun jan 19 14:51:33 2005]
 * updated       matthieu bucchianeri   [tue dec  6 00:48:18 2005]
 */
#ifndef KANETON_CONS_H
#define KANETON_CONS_H		1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <kaneton/types.h>

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/cons/cons.c
 */

/*
 * ../../kaneton/cons/cons.c
 */

void	clean_cons(void);

int	t_printf_char(char	c);

void	t_printf_attr(u_int8_t	attr);


/*
 * eop
 */

#endif
