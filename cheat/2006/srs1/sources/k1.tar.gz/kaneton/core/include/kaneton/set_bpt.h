/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/kaneton/set_bpt.h
 *
 * created       julien quintard   [sun jun 19 14:51:33 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:57:18 2006]
 */

#ifndef KANETON_SET_BPT_H
#define KANETON_SET_BPT_H	1


#endif
