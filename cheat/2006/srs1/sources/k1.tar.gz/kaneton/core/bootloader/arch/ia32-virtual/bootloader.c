/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/bootloader.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:23:13 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the bootloader is to install a correct environment for
 * the kernel.
 *
 * the first thing to do is to relocate the different kaneton data structure
 * in order to build the t_init structure. this structure must contain
 * everything the kernel will need.
 *
 * for more information on the relocating, take a look to the kaneton
 * paper which describes the entire kaneton reference.
 *
 * once the init structure was built, the kernel has to be launched.
 *
 * nevertheless, the kernel needs to evolve with the protected mode and
 * paging mode activated, so the bootloader first has to install these.
 *
 * printing some messages is interesting showing the protected mode and
 * paging mode are correctly installed.
 *
 * after all, the bootloader has launch the kernel binary.
 *
 * look at the ld scripts to know where the kernel has to be loaded.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * these three variable are globals to avoid them to be lost when the
 * bootloader changes its stack.
 *
 * indeed, before jumping on the kernel a new stack is created so the local
 * variables will no longer be accessible. putting these variables in
 * globals bypass this problem.
 */

void			(*kernel)(t_init*);

t_reg32			ebp;
t_reg32			esp;


/*
 * ---------- functions -------------------------------------------------------
 */

/*
** debug fct to print multiboot info
*/
/*
static void  show_multiboot_info(multiboot_info_t* mbi)
{
  printf("\nmultiboot_info_t fields :\n");
  printf("  flags : %x\n", mbi->flags);
  printf("  mem_lower   : %d\n", mbi->mem_lower);
  printf("  mem_upper   : %d\n", mbi->mem_upper);
  printf("  boot_device : %d\n", mbi->boot_device);
  printf("  cmdline     : %d\n", mbi->cmdline);
  printf("  mods_count  : %d\n", mbi->mods_count);
  printf("  mods_addr   : %d\n", mbi->mods_addr);
  printf("  mmap_length : %d\n", mbi->mmap_length);
  printf("  mmap_addr   : %d\n", mbi->mmap_addr);
}
*/

static void print_welcome(void)
{
  clean_cons();

  printf("-----*** Kaneton Chiche version branle.1 ***-----\n\n");
  printf("David Lorin\n");
  printf("Enguerrand Raymond\n");
  printf("Stephane Roissard\n\n");
}

int			bootloader(t_uint32			magic,
				   multiboot_info_t*		mbi)
{
  t_uint32 stack_position;
  t_uint32 pd;
  t_uint32 *tmp;

  printf_init(t_printf_char, t_printf_attr);

  /* print welcome message */
  print_welcome();

  printf("Memory size %i MB\n", (mbi->mem_upper / 1024) + 1);

  enter_pmode(alloc_pages(4096));

  /* Function call to fill t_init memory area the sizes are real in byte*/
  fill_t_init(mbi);

  pd = init_pagination();
  map_memory(0x0, 0x100000, pd);
  map_memory(0x200000, 0x300000, pd);
  map_memory(0x1000000, alloc_pages(0), pd);
  set_pagination(pd);

  /* Set the new stack */
  /* We must to set the stck hear because the */
  /* return of the set_stack function bug the prog */
  stack_position = (t_uint32)(init->kstack + init->kstacksz);

  asm("movl %%esp, %0\n\t"
      "movl %%ebp, %1\n\t"
      "movl %2, %%ebp\n\t"
      "movl %%ebp, %%esp\n\t"
      : "=r" (esp), "=r" (ebp)
      : "m" (stack_position)
      );

  /* Jump on the kernel */

  tmp = (t_uint32 *) 0x01001018;
  kernel = (void *)(*tmp);
  (*kernel)(init);

  /* If the kerenl exit, restore the old stack */
  asm("movl %0, %%esp\n\t"
      "movl %1, %%ebp\n\t"
      :
      : "r" (esp), "r" (ebp)
     );
  while(1);
  return (0);
}
