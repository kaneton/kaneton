/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/cons.c
 *
 * created       julien quintard   [sat may 28 18:23:13 2005]
 * updated       matthieu bucchianeri   [tue jan 24 12:44:22 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the student has to fill in this file just to be able to print some
 * debug messages.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * the console variable.
 */

t_cons			cons;

/*
 * ---------- functions -------------------------------------------------------
 */

/* <Fixed by Enguerrand and Mad> */

/*!
** Initialize the global t_cons structure
*/
static void	t_cons_init()
{
      cons.vga = (char *)CONS_ADDR;
      cons.line = 0;
      cons.column = 0;
      cons.attr = CONS_GREEN;
}

/*!
** Clean the console
*/
void	clean_cons(void)
{
  int	i = 0;

  if (cons.vga != (char *)CONS_ADDR)
    t_cons_init();
  for (i = 0; i < 4000 ; ++i)
    cons.vga[i] = 0x0;
}

/*!
** Print the chac c on the console
** @param c : the char to print
** @return : we don't know what to return for the moment (12.02.2006)
*/
int	t_printf_char(char	c)
{
   int i = 0;

   if (cons.vga != (char *)CONS_ADDR)
      t_cons_init();
   if (c == 10)
     {
       ++cons.line;
       cons.column = 0;
     }
   else
     {
       cons.vga[cons.line * (CONS_COLUMNS * 2) + cons.column] = c;
       cons.vga[cons.line * (CONS_COLUMNS * 2) + cons.column + 1] = cons.attr;
       cons.column = (cons.column + 2) % 160;
       if (!cons.column && cons.line != CONS_LINES)
	 ++cons.line;
     }
   if (cons.line == CONS_LINES && !cons.column)
     {
       for (i = 160; i < 4000; ++i)
	 {
	   cons.vga[i - 160] = cons.vga[i];
	   cons.vga[i] = 0;
	 }
       --cons.line;
     }
   return 0;
}

/*!
** Update cons.attr
*/
void	t_printf_attr(u_int8_t	attr)
{
   cons.attr = attr;
}

/* </Fixed by Enguerrand and Mad> */
