/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/paging.c
 *
 * created       julien quintard   [sun may 29 00:38:50 2005]
 * updated       matthieu bucchianeri   [tue jan 24 18:12:26 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * these function just install the paging mode to enable virtual memory
 * which is required by the kaneton kernel.
 *
 * think about mapping everything needed: kernel code, kernel stack, init
 * structure etc..
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*			init;


/*
 * ---------- functions -------------------------------------------------------
 */

t_uint32  init_pagination(void)
{
  t_uint32 pd;

  pd = create_pd(alloc_pages(4096));
  return pd;
}

int   map_memory(t_uint32 start, t_uint32 end, t_uint32 pd)
{
  t_uint32 pt;
  t_uint32 p;
  t_uint32 tmp;

  for (p = start; p < end; p += 4096)
  {
    pt = get_pt(p, pd);
    if (!pt)
    {
      tmp = alloc_pages(0);
      pt = create_pt(alloc_pages(4096));
      update_pd(p, pd, pt);
      map_memory(tmp, alloc_pages(0), pd);
    }
    update_pt(p, pt);
  }
  return 0;
}

int set_pagination(t_uint32 pd)
{
  install_paging(pd);
  return 0;
}

