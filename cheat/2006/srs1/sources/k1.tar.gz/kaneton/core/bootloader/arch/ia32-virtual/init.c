 /*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/bootloader/arch/ia32-virtual/init.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       matthieu bucchianeri   [tue jan 17 22:24:35 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this file contains the functions intended to do the relocation.
 *
 * this file is very important because it does the most important things
 * of the bootloader: computes segments and regions, relocates data, creates
 * the init structure etc..
 *
 * the relocation is based on dynamic allocation. nevertheless, no dynamic
 * allocation is provided. the student so has to setup a very simple dynamic
 * memory allocation algorithm to be able to build the init structure.
 *
 * think about it because some components cannot have a dynamic address. there
 * are some crazy problems to resolve in this context.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * init variable, describing the initial memory layout.
 *
 * this structure will be passed to the kernel describing modules,
 * physical memory reserved by the hardware etc.. thus the kernel will
 * be able to initialise its managers: segment manager, module manager etc..
 */

t_init*			init;

t_uint32		adr = 0x1000000;

/*
 * ---------- functions -------------------------------------------------------
 */

/*Added by Enguerrand*/

/*
 * Function to calculate the page number necessary
 */
t_uint32		nbr_page(t_uint32 size)
{
  t_uint32	nbr_page = size / 4096;

  if ((size % 4096) != 0)
    ++nbr_page;
  return nbr_page;
}

/*Added by Enguerrand and Mad*/

/*
 * Function to alloc the page number calculate
 * with the byte number specified by size
 */
t_uint32 		alloc_pages(t_uint32 size)
{
  t_uint32 res = adr;

  adr += nbr_page(size) * 4096;
  return res;
}

/*
 * Function to dealloc the page number calculate
 * with the byte number specified by size
 */
t_uint32		dealloc(t_uint32 size)
{
  adr -= nbr_page(size) * 4096;
  return adr;
}

/* allocate new page if needed :
** if cur - start > actual nbpages, then alloc
*/
static void check_allocation(void * start, void * cur, t_uint8 * nbpages)
{
      /* if more than 1 page is used, allocate a new one */
      if ((t_uint32) cur - (t_uint32) start > *nbpages * 4096)
      {
	alloc_pages(4096);
	(*nbpages)++;
      }
}

/*
** fonction that moves the kernel
** above 16Mo and returns the size moved
*/
static t_uint32	  move_kernel(multiboot_info_t* mbi)
{
  t_uint32 flags = mbi->flags;
  t_uint32 start;
  t_uint32 end;
  t_uint32 addr;
  t_uint32 location;
  char* label;

  /* mbi->flag[3] = module flag
  ** if set, then modules are activated
  ** see multiboot information on grub website
  */
  if (flags & 0x100)
  {
    addr = mbi->mods_addr;
    /* kernel start address */
    start = (t_uint32) *((t_uint32 *) addr);
    /* kernel end address */
    end = (t_uint32) *((t_uint32 *) (addr + 4));
    /* kernel label */
    label = (char *) *((t_uint32 *) (addr + 8));

    location = alloc_pages(end - start);
    /* kernel copy at location (above 16 Mo) */
    memcpy((void *) location, (void *) start, end - start);

    return end - start;
  }
  return 0;
}

/*
** fonction that moves the modules
** above 16Mo at 'location' and returns the size moved
*/
static t_uint32   move_modules(multiboot_info_t* mbi,
				t_uint32	location)
{
  t_modules* mods = (t_modules *) location;

  t_uint32 flags = mbi->flags;
  t_uint32 start;
  t_uint32 end;
  t_uint32 addr;
  t_module* mod;
  t_uint32 cpt;
  t_uint8 nbpages = 1;
  char * label;
  int i;

  /* mbi->flag[3] = module flag
  ** if set, then modules are activated
  ** see multiboot information on grub website
  */
  if (flags & 0x100)
  {
    mods->nmodules = mbi->mods_count - 1;
    mod = (t_module*) (location + sizeof (t_modules));
     cpt = (t_uint32) mod + sizeof(t_module) * mods->nmodules;

    for (i = 0; i < mods->nmodules; i++)
    {
      check_allocation((void *) mods, (void *) (mod + sizeof (t_module)), &nbpages);
      addr = mbi->mods_addr + (i + 1) * sizeof (module_t);
      /* module start address */
      start = (t_uint32) *((t_uint32 *) addr);
      /* module end address */
      end = (t_uint32) *((t_uint32 *) (addr + 4));
      /* module label pointer */
      label = (char *) *((t_uint32 *) (addr + 8));

      mod->name = (char *) (cpt + (end - start));
      cpt = (t_uint32) mod->name + strlen(label) + 1;
      /* module size */
      mod->size = end - start;
      mod = (t_module *) ((t_uint32) mod + sizeof(t_module));
    }
    check_allocation((void *) mods, (void *) mod, &nbpages);

    for (i = 0; i < mods->nmodules; i++)
    {
      addr = mbi->mods_addr + (i + 1) * sizeof (module_t);
      /* module start address */
      start = (t_uint32) *((t_uint32 *) addr);
      /* module end address */
      end = (t_uint32) *((t_uint32 *) (addr + 4));
      /* module label pointer */
      label = (char *) *((t_uint32 *) (addr + 8));

      /* module copy at location (above 16 Mo) */
      memcpy((void *) mod, (void *) start, end - start);
      mod = (t_module*) (((t_uint32) mod) + end - start);
      check_allocation((void *) mods, (void *) mod, &nbpages);

      memcpy((void *) mod, (void *) label, strlen(label) + 1);
      mod = (t_module*) (((t_uint32) mod) + strlen(label) + 1);
      check_allocation((void *) mods, (void *) mod, &nbpages);
    }
    return nbpages * 4096;
  }
  return 0;
}

/*
 * Fill one segment on t_segment
 * each params fill one field of the structure
 * o_segment
 */
static void	fill_one_segment(t_paddr addr, t_psize size, t_perms perms,
				 o_segment* segments)
{
  segments->address = addr;
  segments->size = size;
  segments->perms = perms;
}

/*
 * Initialize t_segments memory area with ten segments
 * describe in k1.pdf
 *
 * Permissions: R->Read, W->Write, E->Exec
 *
 * Null segment nothing
 * ISA segment RW
 * GDT segment R
 * kernel segment RE
 * init segment R
 * t_modules segment R
 * t_segment segment R
 * t_region segment R
 * stack segment RW
 * alloc segment RW
 * PD segment RW
 */
static void	fill_t_segments(t_init* init)
{
  o_segment*	segments = init->segments;

  /* Null segment */
  fill_one_segment(0x0, 4096, 0, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* ISA segment */
  fill_one_segment(0x1001, 0xff000, PERM_READ | PERM_WRITE, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* GDT segment */
  fill_one_segment(0x1000000, 4096, PERM_READ, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* kernel segment */
  fill_one_segment(init->kcode, init->kcodesz, PERM_READ | PERM_EXEC, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* init segment */
  fill_one_segment(init->init, 4096, PERM_READ, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* t_modules segment */
  fill_one_segment((t_paddr)init->modules, init->modulessz, PERM_READ, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* t_segments segment */
  fill_one_segment((t_paddr)init->segments, 4096, PERM_READ, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* t_regions segment */
  fill_one_segment((t_paddr)init->regions, 4096, PERM_READ, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* stack segment */
  fill_one_segment(init->kstack, init->kstacksz, PERM_READ | PERM_WRITE, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* alloc segment */
  fill_one_segment(init->alloc, init->allocsz, PERM_READ | PERM_WRITE, segments);
  segments = ((void*) segments) + sizeof(o_segment);

  /* segment PD */
  fill_one_segment((t_paddr)(((void*) init->alloc) + init->allocsz), 4096, PERM_READ | PERM_WRITE, segments);
}

/*
 * Fill one segment on t_segment
 * each params fill one field of the structure
 * o_segment
 */
static void	fill_one_region(t_vaddr addr, t_vsize size, o_region* regions)
{
  regions->address = addr;
  regions->offset = 0;
  regions->size = size;
}

/*
 * Initialize t_regions memory area with six segments
 * describe in k1.pdf
 */
static void	fill_t_regions(t_init* init)
{
  o_region*	regions = init->regions;

  /* ISA region */
  fill_one_region(0x1001, 0xff000, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* GDT region */
  fill_one_region(0x1000000, 4096, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* kcode region */
  fill_one_region(init->kcode, init->kcodesz, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* t_init region */
  fill_one_region(init->init, 4096, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* kstack region */
  fill_one_region(init->kstack, init->kstacksz, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* alloc region */
  fill_one_region(init->alloc, init->allocsz, regions);
  regions = ((void*) regions) + sizeof(o_region);

  /* PD region */
  fill_one_region((t_vaddr)(((void*) init->alloc) + init->allocsz), 4096, regions);
}

/*
 * Funtion to fill the t_init memory area
 */
void	fill_t_init(multiboot_info_t*	mbi)
{
  t_uint32 kernel_size;
  t_uint32 modules_size;
  t_uint32 modules_start;
  t_uint32 alloc_size;
  t_uint32 alloc_start;

  /* moving kernel code */
  kernel_size = move_kernel(mbi);

  /* allocate t_init area */
  init = (t_init*)alloc_pages(4096);

  modules_start = alloc_pages(4096);
  /* moving grub modules */
  modules_size = move_modules(mbi, modules_start);

  /* allocate the t_segments area */
  init->segments = (o_segment*)alloc_pages(4096);

  /* allocate the t_regions area */
  init->regions = (o_region*)alloc_pages(4096);

  /* allocate the stack */
  init->kstack = (t_paddr) alloc_pages(INIT_KSTACKSZ);
  init->kstacksz = (t_psize) INIT_KSTACKSZ;

  /* allocate alloc for the kernel */
  alloc_size = 0x10000;
  alloc_start = alloc_pages(alloc_size);

  init->mem = mbi->mem_lower;
  init->memsz = (mbi->mem_upper + 1024) / 1024;

  init->kcode = 0x1001000;
  init->kcodesz = (nbr_page(kernel_size) * 4096);

  init->init = (t_paddr)init;
  init->initsz = 4096;

  init->modules = (t_modules*)modules_start;
  init->modulessz = modules_size;

  init->nsegments = 11;
  init->segmentssz = 4096;

  init->nregions = 7;
  init->regionssz = 4096;

  init->alloc = alloc_start;
  init->allocsz = alloc_size;

  /* Fill the segment t_segments the sizes are multiple of 4096 */
  fill_t_segments(init);

  /* Fill the segment t_regions the sizes are multiple of 4096 */
  fill_t_regions(init);
}
