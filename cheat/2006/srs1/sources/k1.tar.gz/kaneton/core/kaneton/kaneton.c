/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:48:24 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Function to display t_segment area
 */
static void print_seg_reg(void)
{
  int i;
  o_segment* segment = init->segments;
  o_region* region = init->regions;

  for(i = 1; i <= 11; ++i)
    {
      printf("---segment %i addr = 0x%x size = %i\n", i, segment->address, segment->size);
      segment += 1;
    }
  for (i = 1; i <= 7; ++i)
    {
      printf("+++region %i addr = 0x%x size = %i\n", i, region->address, region->size);
      region += 1;
    }
}

/*
 * Function to print the t_module area
 */
static void print_module()
{
  int i;
  t_module* module = (t_module*)((void*)init->modules + sizeof(t_modules));

  printf("--+++ %i modules +++--\n", init->modules->nmodules, module->name);

  for (i = 1; i <= init->modules->nmodules; ++i)
    {
      printf("module %i name : %s size : %i", i, module->name, module->size);
      printf(" address : 0x%x\n", module->name - module->size);
      module = (t_module*)((t_uint32) module + sizeof(t_module));
    }
}

/*
 * Function to print the t_init elements
 */
static void print_t_init()
{
  printf("--+++ t_init +++--\n");
  printf("mem = %i--memsz = %i--kcode = 0x%x--kcodesz = %i\n", init->mem, init->memsz, init->kcode, init->kcodesz);
  printf("init = 0x%x--initsz = %i--modules = 0x%x--modulesz = %i\n", init->init, init->initsz, init->modules, init->modulessz);
  printf("nsegments = %i--segments = 0x%x--segmentssz = %i\n", init->nsegments, init->segments, init->segmentssz);
  printf("nregions = %i--regions = 0x%x--regionssz = %i\n", init->nregions, init->regions, init->regionssz);
  printf("kstack = 0x%x--kstacksz = %i--alloc = 0x%x--allocsz = %i\n", init->kstack, init->kstacksz, init->alloc, init->allocsz);
}

void			kaneton(t_init*				bootloader)
{
  init = bootloader;
  clean_cons();
  printf_init(t_printf_char, t_printf_attr);

  /* Print all segment information of t_segment*/
  /*print_seg_reg();*/

  /* Print all region information of t_region */
  /*print_module();*/

  /* Print all t_init fields */
  print_t_init();

  while (1)
    ;
}

