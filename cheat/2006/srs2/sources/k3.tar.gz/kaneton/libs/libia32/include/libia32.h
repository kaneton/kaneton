/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/libia32.h
 *
 * created       matthieu bucchianeri   [tue dec 20 13:58:56 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:15:42 2006]
 */

#ifndef LIBIA32_H
#define LIBIA32_H

/*
 * ---------- includes --------------------------------------------------------
 */

#include "misc/asm.h"
#include "misc/isa.h"
#include "misc/multiboot.h"
#include "misc/stdarg.h"
#include "misc/types.h"
#include "paging/paging.h"
#include "pmode/pmode.h"

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../pmode/pmode.c
 *      ../pmode/gdt.c
 *      ../pmode/ldt.c
 *      ../paging/paging.c
 *      ../paging/pd.c
 *      ../paging/pt.c
 *      ../paging/tlb.c
 *      ../interrupt/interrupt.c
 *      ../interrupt/idt.c
 */

/*
 * ../pmode/pmode.c
 */


/*
 * ../pmode/gdt.c
 */

void			gdt_activate(void);

void			gdt_init(void);


/*
 * ../pmode/ldt.c
 */


/*
 * ../paging/paging.c
 */

int			check_params(unsigned int address,
				     int offset);

t_error			pag_map_p(unsigned int addr,
				  unsigned int n,
				  unsigned short perms,
				  unsigned int *v_addr);

t_error			pag_map_v(unsigned int addr,
				  int n,
				  unsigned short perms,
				  unsigned int v_addr);

unsigned short		pag_perform_perms(t_perms perms);

t_error			pag_map(unsigned int p_addr,
				unsigned int size,
				int offset,
				t_perms perms,
				unsigned int *v_addr);

unsigned int	get_nbpages(t_psize size);

void		pag_init_mem(void);

int		pag_p_is_empty(unsigned int addr);

int		pag_v_are_empty(unsigned int addr, int n);

int		pag_v_is_empty(unsigned int addr);

unsigned int	pag_new(void);

void		pag_del(unsigned int addr);

void		pag_find_free_entries(int n, int* pd_index, int *pt_index);

void			pag_gen_physical(unsigned int address,
					 int *pd_entry,
					 int *pt_entry,
					 int *offset);

unsigned int		pag_gen_virtual(int pd_index, int pt_index, int offset);

t_error			pag_del_virtual(unsigned int virtual, int pages);


/*
 * ../paging/pd.c
 */

void			pd_add_entry_index(unsigned short flags,
					   unsigned int address,
					   int index);

t_error		pd_del_entry(unsigned int address);

t_error		pd_del_index(int index);

unsigned int		pd_get_pt_addr(unsigned int entry);

int		pd_get_index(unsigned int address);

int		pd_is_entry_empty(int pd_index);


/*
 * ../paging/pt.c
 */

int		pt_find_free_entries(unsigned int pt_address, int n);

void		pt_add_address(unsigned int pt_address,
			       unsigned int address,
			       unsigned short flags,
			       int index);

t_error		pt_del_entry(unsigned int pt_address, unsigned int address);

t_error		pt_del_index(unsigned int pt_address, int index);

int		pt_get_index(unsigned int address);

int		pt_is_entry_empty(int pd_index,
				  int pt_index);

int		pt_is_virtual_empty(unsigned int virtual, int pages);

int		pt_is_empty(unsigned int pt_address);

void		pt_writable(unsigned int address);

void		pt_readable(unsigned int address);


/*
 * ../paging/tlb.c
 */


/*
 * ../interrupt/interrupt.c
 */


/*
 * ../interrupt/idt.c
 */


/*
 * eop
 */

#endif
