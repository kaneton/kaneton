/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/pt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:48 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:54:23 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page tables.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to place here everything dealing with page tables. no
 * restrictions apply on this file.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- variables globales ----------------------------------------------
 */

/*
 * Variables globales
 */


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * INITIALISATION -------------------------------------------------------------
 */
void		pt_init_pt (unsigned int address)
{
  t_pt_entry	*ptr = NULL;

  ptr = (void *) address;
  memset (ptr, (1024 * sizeof (t_pt_entry)), 0);
}


/*
 * RECHERCHE ------------------------------------------------------------------
 */
int		pt_find_free_entries(unsigned int pt_address, int n)
{
  unsigned int	*pt = NULL;
  int		count = 0;
  int		i = 0;

  pt = (void *) pt_address;
  for (i = 0; i < 1024; ++i)
    if (pt[i] == 0)
      {
	count = 0;
	while (((i + count) < 1024) &&
	       ((pt[i + count] == 0) ||
		((i + count == 0) && (pt[0] == PAG_USED))))
	  ++count;
	if (count >= n)
	  return i;
	else
	  i += count;
      }
  return -1;
}

/*
 * AJOUT -----------------------------------------------------------------------
 */
void		pt_add_entry (unsigned int pt_address,
			      unsigned int address,
			      unsigned short flags)
{
  t_pt_entry	*array = NULL;
  t_pt_entry	entry = 0;
  unsigned int	i = 0;

  // recuperer PTE
  i = (address & 0x003FF000) >> 12;
  // addresse dans bits de poids fort 
  entry = address & 0xFFFFF000;
  // on assemble entry + flags
  entry = entry | flags;
  // on place l'entree dans le table
  array = (void *) pt_address;
  array[i] = entry;
} 

void		pt_add_address(unsigned int pt_address,
			       unsigned int address,
			       unsigned short flags,
			       int index)
{
  unsigned int	*pt = NULL;

  pt = (void *) pt_address;
  pt[index] = address | flags;
}

/*
 * SUPPRESION ------------------------------------------------------------------
 */
t_error		pt_del_entry(unsigned int pt_address, unsigned int address)
{
  int		index = 0;

  index = pt_get_index(address);
  return pt_del_index(pt_address, index);
}

t_error		pt_del_index(unsigned int pt_address, int index)
{
  unsigned int	*pt = NULL;

  pt = (void *) pt_address;
  if ((index < 0) || (index > 1023))
    return ERROR_UNKNOWN;
  pt[index] = 0;
  pt[0] = pt[0] | PAG_USED;
  return ERROR_NONE;
}

/*
 * NUMERO D'ENTREE -------------------------------------------------------------
 */
int		pt_get_index(unsigned int address)
{
  return (address & 0x003FF000) >> 12;
}

/*
 * -----------------------------------------------------------------------------
 */
int		pt_is_entry_empty(int pd_index,
				  int pt_index)
{
  unsigned int	*pd = NULL;
  unsigned int	*pt = NULL;

  pd = (void *) pd_get_addr();
  pt = (void *) pd_get_pt_addr(pd[pd_index]);
  return ((pt[pt_index] == 0) || (pt[pt_index] == PAG_USED));
}

int		pt_is_virtual_empty(unsigned int virtual, int pages)
{
  unsigned int	*pd = NULL;
  unsigned int	*pt = NULL;
  int		pd_index = 0;
  int		pt_index = 0;
  int		offset = 0;
  int		i = 0;

  pd = (void *) pd_get_addr();
  pag_gen_physical(virtual, &pd_index, &pt_index, &offset);
  pt = (void *) pd_get_pt_addr(pd[pd_index]);
  for (i = 0; i < pages; ++i)
    if (!((pt[pt_index + i] == 0) || (pt[pt_index + i] == PAG_USED)))
      return 0;
  return 1;
}

/*
 * -----------------------------------------------------------------------------
 */
int		pt_is_empty(unsigned int pt_address)
{
  unsigned int	*pt = NULL;
  int		i = 0;

  pt = (void *) pt_address;
  for (i = 0; i < 1024; ++i)
    if (!((pt[i] == 0) || (pt[i] == PAG_USED)))
      return 0;
  return 1;
}

/*
 * -----------------------------------------------------------------------------
 */
void		pt_writable(unsigned int address)
{
  unsigned int	*pd = NULL;
  unsigned int	*pt = NULL;
  int		pd_entry = 0;
  int		pt_entry = 0;
  int		offset = 0;

  pag_gen_physical(address, &pd_entry, &pt_entry, &offset);
  pd = (void *) pd_get_addr();
  pt = (void *) pd[pd_entry];
  pt[pt_entry] = pt[pt_entry] | PD_READ_WRITE;
}

void		pt_readable(unsigned int address)
{
  unsigned int	*pd = NULL;
  unsigned int	*pt = NULL;
  int		pd_entry = 0;
  int		pt_entry = 0;
  int		offset = 0;

  pag_gen_physical(address, &pd_entry, &pt_entry, &offset);
  pd = (void *) pd_get_addr();
  pt = (void *) pd[pd_entry];
  pt[pt_entry] = pt[pt_entry] & 0xFFFFFFFD;
}
