/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/paging/paging.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:30:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * declares paging structures, defines, etc.
 *
 */

#ifndef IA32_IA32_PAGING_H
# define IA32_IA32_PAGING_H	1


/*
 * ---------- macros ----------------------------------------------------------
 */

/*
 * Macros relatives a la Page Directory: PD_
 */
/*
 * Bit P
 */
# define	PD_PRESENT	0x0001	/*00000001*/
# define	PD_NOT_PRESENT	0x0000	/*00000000*/
/*
 * Bit R/W
 */
# define	PD_READ		0x0000	/*00000010*/
# define	PD_READ_WRITE	0x0002	/*00000000*/
/*
 * Bit U/S
 */
# define	PD_USER		0x0000	/*00000100*/
# define	PD_SUPERVISOR  	0x0004	/*00000000*/
/*
 * Bit PWT
 */
# define	PD_W_THROUGH	0x0008	/*00001000*/
# define	PD_NO_W_THROUGH	0x0000	/*00000000*/
/*
 * Bit PCD
 */
# define	PD_CACHE_ENAB	0x0010	/*00010000*/
# define	PD_CACHE_DISAB	0x0000	/*00000000*/
/*
 * Bit A
 */
# define	PD_ACCESSED	0x0020	/*00100000*/
# define	PD_NOT_ACCESSED	0x0000	/*00000000*/
/*
 * Bit PS
 */
# define	PD_SIZE_4K	0x0000	/*00000000*/
# define	PD_SIZE_NOT_4K	0x0080	/*10000000*/
/*
 * Bit G
 */
# define	PD_GLOBAL	0x0100	/*00000001*/
# define	PD_NOT_GLOBAL	0x0000	/*00000000*/
/*
---------------------------------
 */


/*
 * Macros relatives a la Page Directory: PT_
 */
/*
 * Bit P
 */
# define	PT_PRESENT	0x0001	/*00000001*/
# define	PT_NOT_PRESENT	0x0000	/*00000000*/
/*
 * Bit R/W
 */
# define	PT_READ		0x0000	/*00000010*/
# define	PT_READ_WRITE	0x0002	/*00000000*/
/*
 * Bit U/S
 */
# define	PT_USER		0x0000	/*00000100*/
# define	PT_SUPERVISOR  	0x0004	/*00000000*/
/*
 * Bit PWT
 */
# define	PT_W_THROUGH	0x0008	/*00001000*/
# define	PT_NO_W_THROUGH	0x0000	/*00000000*/
/*
 * Bit PCD
 */
# define	PT_CACHE_ENAB	0x0010	/*00010000*/
# define	PT_CACHE_DISAB	0x0000	/*00000000*/
/*
 * Bit A
 */
# define	PT_ACCESSED	0x0020	/*00100000*/
# define	PT_NOT_ACCESSED	0x0000	/*00000000*/
/*
 * Bit D
 */
# define	PT_DIRTY	0x0040	/*01000000*/
# define	PT_NOT_DIRTY	0x0000	/*00000000*/
/*
 * Bit PAT
 */
# define	PT_ATT_INDEX	0x0080	/*10000000*/
# define	PT_NO_ATT_INDEX	0x0000	/*00000000*/
/*
 * Bit G
 */
# define	PT_GLOBAL	0x0100	/*000100000000*/
# define	PT_NOT_GLOBAL	0x0000	/*000000000000*/
/*
---------------------------------
 */
# define	PAG_USED	0x0800	/*100000000000*/

/*
 * ---------- structures ------------------------------------------------------
 */

/*
 * Entree de la Page Directory (PD)
 * /!\ Ca n'a rien avoir avec un anus !!!
 */
typedef unsigned int	t_pd_entry;

/*
 * Entree de la page table (PT)
 * /!\ Meme remarque que precedemment...
 */
typedef unsigned int	t_pt_entry;


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * \brief Initialise la Page Directory (memoire a 0).
 */
void			pd_init_pd (void);

/*
 * \brief Ajoute d'une entree dans la Page Directory.
 * \param flags Ensemble des flags necessaires a la Page Directory.
 * \param base Adresse de base a entrer dans la Page Directory.
 * \return Retourne la page ajoutee.
 */
t_pd_entry     		pd_add_entry (unsigned short flags,
				      unsigned int base);

/*
 * \brief Acquiert l'adresse de la Page Directory
 * \return Retourne l'adresse de la Page Directory (contenue dans CR3).
 */
unsigned int		pd_get_addr (void);

/*
 * \brief Supprime une entree de la Page Directory.
 * \param entry Entier correspondant au numero de l'entree a supprimer de la
 * Page Directory.
 */
/* void			pd_del_entry(unsigned int address); */


/*
 * \brief Initialise une page table a 0.
 * \param address Adresse de la page a traiter.
 */
void			pt_init_pt (unsigned int address);

/*
 * \brief Ajoute une entree dans la PT. Les flags doivent etre bien places.
 * \param pt_address Adresse de la Page Directory a utiliser.
 * \param address Adresse a mapper.
 * \param flags Flags.
 */
void			pt_add_entry (unsigned int pt_address,
				      unsigned int address,
				      unsigned short flags);

/* void			pt_del_entry (unsigned int pt_address, */
/* 				      unsigned int address); */

t_error			pt_del_index (unsigned int pt_address,
				      int index);

/*
 * \brief Retourne l'adresse de la Page Directory.
 * \return Une addresse alignee, sur 32 bits
 */
unsigned int		pag_get_addr (void);

void			pag_all_mapping (void);

int			pt_is_empty(unsigned int pt_address);

void			pag_mapping (unsigned int address,
				     unsigned short pd_flags,
				     unsigned short pt_flags);

/*
 * \brief Initialise une page (la met a 0).
 * \param address L'adresse de la dite page.
 */
void			pag_init_page (unsigned int address);

/*
 * \brief Mappe une adresse physique dans les PD, PTs.
 * \return Une erreur, de type ERROR_UNKNOWN, est renvoyee en cas d'erreur.
 * ERROR_NONE sinon.
 */


/*
 * \brief Retourne le nombre de pages necessaires pour mapper une taille.
 * \param size La taille.
 * \return Le nombre de pages necessaires pour contenir cette taille.
 */
unsigned int		get_nbpages(t_psize size);

/*
 * \brief Met en place le mode pagine.
 */
void			init_paging (void);

t_error			dep_region_reserve(t_asid asid, t_segid segid, t_paddr offset, t_opts opts,
					   t_vaddr address, t_vsize size, t_regid* regid);

/*
 * ----------------------------------------------------------------------------
 */


#endif
