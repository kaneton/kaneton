/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/pmode/pmode.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:31:13 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 */



/*
 * ----------------------------------------------------------------------------
 */

#ifndef IA32_IA32_PMODE_H
# define IA32_IA32_PMODE_H	1


/*
 * ---------- macros ----------------------------------------------------------
 */

/*
 * Macros relatives a la GDT
 */

# define	GDT_SIZE	8
# define	GDT_START	0x5000


/*
 *
 * Macros pour creer une entree dans la GDT
 *
 */

/*
 * Bit G
 */
# define	GDT_GRANULAR	0x80	/*10000000*/
# define	GDT_NO_GRANULAR	0x00	/*00000000*/
/*
 * Bit D/B
 */
# define	GDT_32		0x40	/*01000000*/
# define	GDT_16		0x00	/*00000000*/
/*
 * Bit L
 */
# define	GDT_L		0x00	/*00000000*/
/*
 * Bit AVL
 */
# define	GDT_AVL		0x10	/*00010000*/
# define	GDT_NO_AVL     	0x00	/*00000000*/

/*
 * Bit P
 */
# define	GDT_PRESENT	0x80	/*10000000*/
# define	GDT_NOT_PRESENT	0x00	/*00000000*/
/*
 * Bits DPL
 */
# define	GDT_DPL3	0x60	/*01100000*/
# define	GDT_DPL2	0x40	/*01000000*/
# define	GDT_DPL1	0x20	/*00100000*/
# define	GDT_DPL0	0x00	/*00000000*/

/*
 * Bit S
 */
# define	GDT_SEGMENT    	0x10	/*00010000*/
# define	GDT_SYSTEME    	0x00	/*00000000*/

/*
 * Bits Type
 */
# define	GDT_CODE	0xa	/*00001011*/
# define	GDT_DATA	0x2	/*00000011*/


/*
 * ---------- structures ------------------------------------------------------
 */

/*
 * GDTR
 */

struct				s_gdtr
{
  unsigned short		limit;
  unsigned int			base;
};


/*
 * Entree de la GDT
 */
struct				s_gdt_entry
{
  /*
   * Adresse de base du segment (0 a 15)
   */
  unsigned short		base;
  /*
   * Limite du segment
   */
  unsigned short		limit;
  /*
   * Adresse de base du segment (16 a 23)
   */
  unsigned char			base16;
  /*
   * Flags S, DPL et P
   */
  unsigned char			flags;
  /*
   * Flags AVL, 0, D/B, G et la limite (16 a 19)
   */
  unsigned char			limit16;
  /*
   * Adresse de base du segment (24 a 31)
   */
  unsigned char			base24;
};


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Initialisation de la GDT, des segments code/data kernel/user.
 * Load du registre GDTR.
 * Mise a 1 du bit PE de CR0.
 */
void			gdt_init(void);

/*
 * Ajoute une entree dans la GDT.
 * \param base Base est l'adresse lineaire du debut de segment (32 bits).
 * \param limit Limit correspond a la longueur du segment (16 bits).
 * \param TYPE_S_DPL_P Flags.
 * \param AVL_L_DB_G Flags.
 * \return Retourne l'offset par rapport au debut de la GDT.
 */
unsigned int short	gdt_add_entry(unsigned int base,
				      unsigned int limit,
				      unsigned char TYPE_S_DPL_P,
				      unsigned char AVL_L_DB_G);

/*
 * Suppression d'une entree de la GDT.
 * \param gdt_entry Gdt_entry correspond a l'entree de la GDT a supprimer.
 */
void			gdt_del_entry(unsigned int gdt_entry);

/*
 * Recherche la premiere entree libre de la GDT.
 * \return Retourne la premiere entree libre dans la GDT.
 */
int			gdt_find_free_entry(void);

void			gdt_activate(void);

/*
 * ----------------------------------------------------------------------------
 */

#endif
