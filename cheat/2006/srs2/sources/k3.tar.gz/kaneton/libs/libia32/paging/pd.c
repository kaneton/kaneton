/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/pd.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:20 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:53:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page directory.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this    file   is    destinated   to    functions    dealing   with
 * page-directories. there are no restrictions about function names or
 * prototype, so feel free.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- variables globales ----------------------------------------------
 */

/*
 * Variables globales
 */
extern t_init		*init;


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * RECHERCHE ------------------------------------------------------------------
 */
unsigned int		pd_get_addr (void)
{
  unsigned int		res = 0;

  asm ("movl	%%cr3,	%0	\n\t"
       : "=r" (res));
  res = res & 0xFFFFF000;
  return res;
}


/*
 * INITIALISATION -------------------------------------------------------------
 */
void			pd_init_pd (void)
{
  t_pd_entry		*pd_entry = NULL;

  pd_entry = (t_pd_entry *) pd_get_addr ();
  memset (pd_entry, ((sizeof (t_pd_entry)) * 1024), 0);
}


/*
 * AJOUT ----------------------------------------------------------------------
 */
t_pd_entry     		pd_add_entry (unsigned short flags,
				      unsigned int address)
{
  unsigned short       	i = 0;
  unsigned int		res = 0;
  t_pd_entry		*pd_entry = NULL;
  t_pd_entry		entry = 0;

  // Recup de l'adresse de debut de la PD (et pas du PD)...
  pd_entry = (void *) pd_get_addr ();
  // Recup de l'entree
  i = (address >> 22) & 0x3FF;
  if (pd_entry[i] == 0)
    {
      /* UPDATE */
      res = pag_new();
      pt_init_pt (res);
      entry = res & 0xFFFFF000;
      entry = entry | flags;
      pd_entry[i] = entry;
    }
  else
    res = pd_entry[i];

  return res & 0xFFFFF000;
}

void			pd_add_entry_index(unsigned short flags,
					   unsigned int address,
					   int index)
{
  unsigned int		*pd = NULL;
  unsigned int		new = 0;

  pd = (void *) pd_get_addr();
  new = address & 0xFFFFF000;
  new = new | flags;
  pd[index] = new;
}

/*
 * SUPPRESION ----------------------------------------------------------------------------
 */
t_error		pd_del_entry(unsigned int address)
{
  int		index = 0;

  index = pd_get_index(address);
  return pd_del_index(index);
}

t_error		pd_del_index(int index)
{
  unsigned int	*pd = NULL;

  pd = (void *) pd_get_addr();
  if ((index < 0) || (index > 1023))
    return ERROR_UNKNOWN;
  pd[index] = 0;
  pd[0] = pd[0] | PAG_USED;
  return ERROR_NONE;
}

/*
 * ADRESSE TABLE FROM ENTRY ---------------------------------------------------
 */
unsigned int		pd_get_pt_addr(unsigned int entry)
{
  return (entry & 0xFFFFF000);
}

/*
 * NUMERO D'ENTREE -----------------------------------------------------------------------
 */
int		pd_get_index(unsigned int address)
{
  return (address >> 22) & 0x3FF;
}

/*
 * -----------------------------------------------------------------------------
 */
int		pd_is_entry_empty(int pd_index)
{
  unsigned int	*pd = NULL;

  pd = (void *) pd_get_addr();
  return ((pd[pd_index] == 0) || (pd[pd_index] == PAG_USED));
}

/*
 * ----------------------------------------------------------------------------
 */
