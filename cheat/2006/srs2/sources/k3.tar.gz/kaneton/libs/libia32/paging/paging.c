/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/paging.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:05 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:51:57 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage paging.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will have  to fill  this  file with  function related  to
 * paging mode in the cpu: enable, disabling etc.
 *
 * there are no  restrictions about these functions, but  keep in mind
 * that  page-directory management and  page-tables management  are to
 * place in pd.c and pt.c.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


extern t_init		*init;


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * INITIALISATION -------------------------------------------------------------
 */
void			pag_init_page (unsigned int address)
{
  void		*ptr = NULL;

  // Recup de l'adresse de debut de la PD (et pas du PD)...
  ptr = (void *) address;
  // Initialisation de la memoire
  memset (ptr, 4096, 0);
/*   memset (ptr, 4096, 0); */
}


/*
 * MAPPING --------------------------------------------------------------------
 */
void			pag_mapping (unsigned int address,
				     unsigned short pd_flags,
				     unsigned short pt_flags)
{
  t_pt_entry	pt_entry = 0;

  pt_entry = pd_add_entry (pd_flags, address);
  pt_add_entry (pt_entry, address, pt_flags);
}

int			check_params(unsigned int address,
				     int offset)
{
  return (((address % PAGESZ) != 0) ||
	  ((offset % PAGESZ) != 0));
}

t_error			pag_map_p(unsigned int addr,
				  unsigned int n,
				  unsigned short perms,
				  unsigned int *v_addr)
{
  t_error		error = ERROR_NONE;
  unsigned short	pd_rw = PD_PRESENT | PD_READ_WRITE | PD_USER;
  int			pd_index = 0;
  int			pt_index = 0;
  unsigned int		*pd = NULL;
  unsigned int		pt = 0;
  int			i = 0;

  pd = (void *) pd_get_addr();
  pag_find_free_entries(n, &pd_index, &pt_index);
  if (pd_index == -1)
    return ERROR_UNKNOWN;
  if (pt_index == -1)
    {
      pt = pag_new();
      pd_add_entry(pd_rw, pt);
      pt_index = 0;
    }
  pt = pd_get_pt_addr(pd[pd_index]);
  if (n == 0)
    ++n;
  for (i = 0; i < n; ++i)
    pt_add_address(pt, (addr + (i * PAGESZ)), perms, (pt_index + i));
  *v_addr = pag_gen_virtual(pd_index, pt_index, 0);
  return error;
}

t_error			pag_map_v(unsigned int addr,
				  int n,
				  unsigned short perms,
				  unsigned int v_addr)
{
  t_error		error = ERROR_NONE;
  unsigned short	pd_rw = PD_PRESENT | PD_READ_WRITE | PD_USER;
  int			pd_index = 0;
  int			pt_index = 0;
  unsigned int		*pd = NULL;
  unsigned int		*pt = NULL;
  int			offset = 0;
  int			i = 0;

  pd = (void *) pd_get_addr();
  pag_gen_physical(v_addr, &pd_index, &pt_index, &offset);
  if ((pd[pd_index] == 0) ||
      (pd[pd_index] == PAG_USED))
    pd_add_entry_index(pd_rw, pag_new(), pd_index);
  pt = (void *) pd_get_pt_addr(pd[pd_index]);
  for (i = 0; i < n; ++i)
    if (!((pt[pt_index + i] == 0) ||
	  (pt[pt_index + i] == PAG_USED)))
      return ERROR_UNKNOWN;
  for (i = 0; i < n; ++i)
    pt_add_address((unsigned int) pt, (addr + (i * PAGESZ)), perms, (pt_index + i));
  return error;
}

unsigned short		pag_perform_perms(t_perms perms)
{
  unsigned short	res = 0;

  res = PT_PRESENT | PT_USER;
  if (perms & PERM_WRITE)
    res = res | PT_READ_WRITE;
  return res;
}

t_error			pag_map(unsigned int p_addr,
				unsigned int size,
				int offset,
				t_perms perms,
				unsigned int *v_addr)
{
  t_error		error = ERROR_NONE;
  unsigned int		n = 0;
  unsigned short	pag_perms = 0;

  pag_perms = pag_perform_perms(perms);
  if (check_params(p_addr, offset) != 0)
    return ERROR_UNKNOWN;
  n = get_nbpages(size);
  if (*v_addr == 0)
    return pag_map_p(p_addr + offset, n, pag_perms, v_addr);
  else
    return pag_map_v(p_addr + offset, n, pag_perms, *v_addr);
  return error;
}

void			pag_all_mapping (void)
{
  o_segment		seg;
  unsigned int		perms = 0;
  unsigned int		i = 0;
  unsigned int		j = 0;
  unsigned short	pd_rw = 0;
  unsigned short	pd_r = 0;
  unsigned short	pt_rw = 0;
  unsigned short	pt_r = 0;
  unsigned int		segsize;

  pd_init_pd ();
  pd_rw = pd_rw | PD_PRESENT | PD_READ_WRITE | PD_SUPERVISOR;
  pd_r = pd_r | PD_PRESENT | PD_READ | PD_SUPERVISOR;
  pt_rw = pt_rw | PT_PRESENT | PT_READ_WRITE | PT_SUPERVISOR;
  pt_r = pt_r | PT_PRESENT | PT_READ | PT_SUPERVISOR;

  for (i = 0; i < 2; ++i)
    {
      seg = init->segments[i];
      segsize = seg.size;
      if (i == 1)
	segsize = 16777216;
      perms = seg.perms;
      for (j = 0; j < segsize; j += PAGESZ)
	if (perms & 0x2)
	  pag_mapping ((seg.address + j), pd_rw, pt_rw);
	else
	  pag_mapping ((seg.address + j), pd_rw, pt_rw);
    }

  j = init->segments[10].size + init->segments[10].address;
  /*  - init->segments[2].address; */
  /*   j += init->segments[2].address; */

  for (i = init->segments[2].address; i < j; i += PAGESZ)
    pag_mapping(i, pd_rw, pt_rw);
}


/*
 * INITIALISATION -------------------------------------------------------------
 */
void		init_paging (void)
{
  pag_init_mem();

  asm ("movl	%0,	%%eax	\n\t"
       "movl	%%eax,	%%cr3	\n\t"
       :
       : "r" (init->segments[10].address & 0xFFFFF000)
       : "%eax");

  /* Possibilite de tester le systeme d'allocation ici. */

  pag_all_mapping ();

  asm ("mov	%cr0,	%eax\n"
       "or	$0x80010000,	%eax\n"
       "mov	%eax,	%cr0\n");
}


/*
 * GESTION DES PAGES ----------------------------------------------------------
 */
unsigned int	get_nbpages(t_psize size)
{
  unsigned int 	nbpages = 42;

  nbpages = size / PAGESZ;
  if (size % PAGESZ != 0)
    nbpages++;
  return nbpages;
}

/*
 * ALLOCATOR SYSTEM -----------------------------------------------------------
 */
unsigned int	pag_get_addr (void)
{
  return (init->segments[10].address & 0xFFFFF000);
}

void		pag_init_mem(void)
{
  void		*ptr = NULL;

  ptr = (void *) pag_get_addr();
  memset(ptr, (4096 * INIT_PAGINGSZ), 0);
}

int		pag_p_is_empty(unsigned int addr)
{
  int		i = 0;
  unsigned int	*page_entry = (void *) addr;

  for (i = 0; i < 1024; ++i)
    if (page_entry[i] != 0)
      return 0;
  return 1;
}

int		pag_v_are_empty(unsigned int addr, int n)
{
  unsigned int	virtual = 0;
  int		pd_entry = 0;
  int		pt_entry = 0;
  int		offset = 0;
  int		i = 0;

  pag_gen_physical(addr, &pd_entry, &pt_entry, &offset);
  for (i = 0; i < n; ++i)
    {
      virtual = 0;
      // TODO : offset
      virtual = pag_gen_virtual(pd_entry, (pt_entry + i), offset);
      if (!pag_v_is_empty(virtual))
	return 0;
    }
  return 1;
}

int		pag_v_is_empty(unsigned int addr)
{
  unsigned int	*pd = NULL;
  unsigned int	*pt = NULL;
  int		pd_entry = 0;
  int		pt_entry = 0;
  int		offset = 0;

  pd = (void *) pd_get_addr();
  pag_gen_physical(addr, &pd_entry, &pt_entry, &offset);
  pt = (void *) pd_get_pt_addr(pd[pd_entry]);
  return ((pt[pt_entry] == 0) || (pt[pt_entry] == PAG_USED));
}

/* A modifier dans init.h */
unsigned int	pag_new(void)
{
  int		i = 0;
  unsigned int	*ptr = NULL;
  unsigned int	pag_addr = 0;

  pag_addr = pag_get_addr() + PAGESZ;
  for (i = 0; i < (INIT_PAGINGSZ - 2); ++i)
    if (pag_p_is_empty(pag_addr))
      {
	ptr = (void *) pag_addr;
	ptr[0] = 0 | PAG_USED;
	return pag_addr;
      }
    else
      pag_addr += PAGESZ;
  printf("CRASH !!! No enough memory for paging !!! Mail radm !!!\n");
  while (1)
    ;
  return 0;
}

/* Supprime le contenu d'une page */
void		pag_del(unsigned int addr)
{
  void		*ptr = (void *) addr;

  memset(ptr, 4096, 0);
}

/* trouve un lieu pour n pages */
void		pag_find_free_entries(int n, int* pd_index, int *pt_index)
{
  unsigned int	*pd = NULL;
  int		pti = 0;
  int		i = 0;

  *pd_index = 0;
  *pt_index = -1;
  pd = (void *) pd_get_addr();
  for (i = 0; i < 1024; ++i)
    if ((pd[i] != 0) &&
	(pd[i] != PAG_USED))
      if ((pti = pt_find_free_entries(pd_get_pt_addr(pd[i]), n)) != -1)
	{
	  *pd_index = i;
	  *pt_index = pti;
	  break;
	}
  if (i == 1023)
    *pd_index = -1;
  if (*pt_index == -1)
    while (pd[*pd_index] != 0)
      (*pd_index)++;
}

void			pag_gen_physical(unsigned int address,
					 int *pd_entry,
					 int *pt_entry,
					 int *offset)
{
  *pd_entry = 0 | (address >> 22);
  *pt_entry = 0 | (address & 0x003FF000) >> 12;
  *offset = 0 | (address & 0xFFF);
}

unsigned int		pag_gen_virtual(int pd_index, int pt_index, int offset)
{
  unsigned int		virtual = 0;

  virtual = virtual | pd_index;
  virtual = virtual << 10;
  virtual = virtual | pt_index;
  virtual = virtual << 12;
  virtual = virtual | offset;
  return virtual;
}

t_error			pag_del_virtual(unsigned int virtual, int pages)
{
  t_error		error = ERROR_NONE;
  unsigned int		pt_address = 0;
  unsigned int		*pd = NULL;
  int			pd_index = 0;
  int			pt_index = 0;
  int			offset = 0;
  int			i = 0;

  pag_gen_physical(virtual, &pd_index, &pt_index, &offset);
  pd = (void *) pd_get_addr();
  pt_address = pd_get_pt_addr(pd[pd_index]);
  for (i = 0; i < pages; ++i)
    if ((error = pt_del_index(pt_address, (pt_index + i))) != ERROR_NONE)
      return error;
  if (pt_is_empty(pt_address))
    error = pd_del_index(pd_index);
  return error;
}
