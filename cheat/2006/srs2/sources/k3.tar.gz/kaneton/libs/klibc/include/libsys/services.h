/*
 * licence kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/klibc/include/libsys/services.h
 *
 * created       julien quintard   [fri feb 11 02:40:57 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:52:53 2006]
 */

#ifndef LIBSYS_SERVICES_H
#define LIBSYS_SERVICES_H	1

/*
 * ---------- defines ---------------------------------------------------------
 */

#define SERVICE_CORE	0x00

#endif
