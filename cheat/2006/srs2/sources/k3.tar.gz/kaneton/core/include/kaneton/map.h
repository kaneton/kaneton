/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/kaneton/as.h
 *
 * created       julien quintard   [fri feb 11 02:19:44 2005]
 * updated       matthieu bucchianeri   [thu jan 26 11:46:54 2006]
 */

#ifndef KANETON_MAP_H
#define KANETON_MAP_H		1

/*
 * ---------- dependencies ----------------------------------------------------
 */

/* #include <arch/machdep/machdep.h> */
#include <kaneton/id.h>
#include <kaneton/types.h>

/*
 * ---------- defines ---------------------------------------------------------
 */

/*
 * ---------- types -----------------------------------------------------------
 */

/*
 * map object
 */

/* typedef struct */
/* { */
/*   t_asid			asid; */

/*   t_tskid			tskid; */

/*   t_setid			segments; */
/*   t_setid			regions; */

/*   machdep_data(o_as); */
/* }				o_as; */

/*
 * map manager
 */

typedef struct
{
  o_id				id;

  t_staid			stats;

/*   machdep_data(m_map); */
}				m_map;

/*
 * the map architecture dependent interface
 */

/* typedef struct */
/* { */
/*   t_error			(*map_reserve)(t_asid, */
/* 					       t_opts, */
/* 					       t_vaddr*, */
/* 					       t_vsize, */
/* 					       t_perms); */
/*   t_error			(*map_release)(t_asid, */
/* 					       t_vaddr); */
/*   t_error			(*map_init)(void); */
/*   t_error			(*map_clean)(void); */
/* }				i_map; */

/*
 * ---------- macros ----------------------------------------------------------
 */

/*
 * check
 */

#define MAP_CHECK(_map_)						\
  {									\
    if ((_map_) == NULL)						\
      return (ERROR_UNKNOWN);						\
  }

/*
 * enter
 */

#define MAP_ENTER(_map_)						\
  {									\
    MAP_CHECK((_map_));							\
									\
    STATS_BEGIN((_map_)->stats);					\
  }

/*
 * leave
 */

#define MAP_LEAVE(_map_, _error_)					\
  {									\
    STATS_END((_map_)->stats, (_error_));				\
									\
    return (_error_);							\
  }

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/map/map.c
 *      ../../kaneton/map/map-test.c
 */

/*
 * ../../kaneton/map/map.c
 */

t_error		map_reserve(t_asid asid, t_opts opts, t_vaddr *addr,
			    t_vsize size, t_perms perms);

t_error		map_release(t_asid asid, t_vaddr addr);

t_error		map_init(void);

t_error		map_clean(void);


/*
 * ../../kaneton/map/map-test.c
 */

t_error		map_test(void);


/*
 * eop
 */

#endif
