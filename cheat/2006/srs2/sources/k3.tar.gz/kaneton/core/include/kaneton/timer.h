/*
** timer.h
** Login : <laroch_e@bastille.epitech.net>
** Started on  Thu Jun 15 22:39:50 2006 emeric laroche
** $Id$
*/

#ifndef   	TIMER_H_
# define   	TIMER_H_

struct t_timer {
  t_id	timer_l;
};

typedef void (timeout_routine)(void);

struct timer_node {
  t_time		timeout;
  timeout_routine	*callback;
};

#define INSERT_END	3

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/interrupts/timer.c
 */

/*
 * ../../kaneton/interrupts/timer.c
 */

t_error timer_init();

t_error timer(t_time time, timeout_routine (*callback));

t_error call_first_node(void);

t_error timer_handler(void);


/*
 * eop
 */

#endif 	    /* !TIMER_H_ */
