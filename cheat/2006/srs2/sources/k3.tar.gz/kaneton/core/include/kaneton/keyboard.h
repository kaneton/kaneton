/*
** keyboard.h
** Login : <laroch_e@bastille.epitech.net>
** Started on  Wed Jun 14 19:18:49 2006 emeric laroche
** $Id$
*/

#ifndef   	KEYBOARD_H_
# define   	KEYBOARD_H_

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <arch/machdep/machdep.h>

/*
 * ---------- declarations ----------------------------------------------------
 */



/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/interrupts/keyboard.c
 */

/*
 * ../../kaneton/interrupts/keyboard.c
 */

void keyboard_handler(void);


/*
 * eop
 */

#endif 	    /* !KEYBOARD_H_ */
