/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/include/arch/machdep/kaneton/kaneton.h
 *
 * created       julien quintard   [sat dec 17 17:13:18 2005]
 * updated       matthieu bucchianeri   [tue jan 10 01:26:32 2006]
 */

#ifndef IA32_KANETON_KANETON_H
#define IA32_KANETON_KANETON_H	1

/*
 * ---------- defines ---------------------------------------------------------
 */

#define ___endian		ENDIAN_LITTLE
#define ___wordsz		WORDSZ_32

#define PAGESZ			4096

/*
 * ---------- includes --------------------------------------------------------
 */

#include <arch/machdep/kaneton/as.h>
#include <arch/machdep/kaneton/debug.h>
#include <arch/machdep/kaneton/init.h>
#include <arch/machdep/kaneton/region.h>
#include <arch/machdep/kaneton/segment.h>
#include <arch/machdep/kaneton/stats.h>
#include <arch/machdep/kaneton/task.h>

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../../../kaneton/arch/machdep/as.c
 *      ../../../../kaneton/arch/machdep/region.c
 *      ../../../../kaneton/arch/machdep/segment.c
 *      ../../../../kaneton/arch/machdep/task.c
 */

/*
 * ../../../../kaneton/arch/machdep/as.c
 */


/*
 * ../../../../kaneton/arch/machdep/region.c
 */

t_error			dep_region_reserve(t_asid asid, t_segid segid, t_paddr offset, t_opts opts,
					   t_vaddr address, t_vsize size, t_regid* regid);

t_error			dep_region_release(t_asid asid, t_regid regid);


/*
 * ../../../../kaneton/arch/machdep/segment.c
 */

void	gdt_reload(void);

t_error		dep_segment_reserve(t_asid asid, t_psize size, t_perms perms, t_segid* segid);

t_error		dep_segment_perms(t_segid segid, t_perms perms);

t_error		dep_segment_resize(t_segid segid, t_psize size, t_segid* new);

t_error		dep_segment_type(t_segid s, t_type type);


/*
 * ../../../../kaneton/arch/machdep/task.c
 */


/*
 * eop
 */

/*
 * ../../../../kaneton/arch/machdep/cons.c
 */
void	init_cons(void);
void	update_attribute(u_int8_t attr);
int	print_char_simple(char c);
void    cons_clear_screen(void);

#endif
