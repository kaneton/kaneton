/*
** segment-test.c
** Login : <meyer_f@bastille.epita.fr>
** Started on  Tue Mar 28 19:05:56 2006 frederick meyer
** $Id$
*/

#include <klibc.h>
#include <kaneton.h>

#ifdef CONF_TEST_SEGMENT

extern t_init*	init;

# define assert(_cond_, _nb_) \
	if (_cond_) {printf("Erreur au test " #_nb_ "\n"); return ERROR_UNKNOWN;}

#define test(_nb_)					\
	printf ("############### TEST " #_nb_ " ####################\n")


t_error	segment_test(void)
{
  t_segid	segid1 = 0;
  t_segid	segid2 = 0;
  t_segid	segid3 = 0;
  t_segid	segid4 = 0;
  t_asid	asid1 = 0;
  t_asid	asid2 = 0;


  test(1);
  assert(as_reserve(0, &asid1) != ERROR_NONE, 1);

  test(2);
  assert(as_reserve(1, &asid2) != ERROR_NONE, 2);

  test(3);
  assert(segment_reserve(asid1, 4096, (PERM_READ | PERM_WRITE), &segid1) != ERROR_NONE, 3);

  test(4);
  assert(segment_reserve(asid1, 8192, (PERM_READ | PERM_WRITE), &segid2) != ERROR_NONE, 4);

  test(5);
  assert(segment_reserve(asid1, 16384, (PERM_READ | PERM_WRITE), &segid3) != ERROR_NONE, 5);

  test(6);
  assert(segment_show(segid1) != ERROR_NONE, 6);

  test(7);
  assert(segment_dump() != ERROR_NONE, 7);

  test(8);
  assert(segment_coalesce(segid1, segid2, &segid4) != ERROR_NONE, 8);

  /* segid3 == 16384 */
  /* segid4 == 12288 */

  test(9);
  assert(segment_split(segid4, 4096, &segid1, &segid2) != ERROR_NONE, 9);

  /* segid1 == 4096 */
  /* segid2 == 8192 */
  /* segid3 == 16384 */

  test(10);
  assert(segment_clone(asid2, segid1, &segid4) != ERROR_NONE, 10);

  /* segid1 == 4096 */
  /* segid2 == 8192 */
  /* segid3 == 16384 */
  /* segid4 == 4096 dans l'as 1 */

  test(11);
  assert(segment_give(segid1, asid2) != ERROR_NONE, 11);

  test(12);
  assert(segment_give(segid3, asid2) != ERROR_NONE, 12);

  /* segid1 == 4096 */
  /* segid2 == 8192 dans l'as 0 */
  /* segid3 == 16384 */
  /* segid4 == 4096 dans l'as 1 */

  test(13);
  assert(segment_resize(segid4, 8192, &segid4) != ERROR_NONE, 13);

  /* segid1 == 4096 */
  /* segid2 == 8192 dans l'as 0 */
  /* segid3 == 16384 */
  /* segid4 == 8192 dans l'as 1 */

  test(14);
  assert(segment_type(segid4, SEGMENT_TYPE_CATCH) != ERROR_NONE, 14);

  test(15);
/*   assert(segment_catch(asid2, segid4) != ERROR_NONE, 15); */

  test(16);
  assert(segment_release(segid2) != ERROR_NONE, 16);

  /* segid1 == 4096 dans l'as 1 */
  /* segid3 == 16384 dans l'as 1 */
  /* segid4 == 8192 dans l'as 1 type CATCH */

  test(17);
  assert(segment_dump() != ERROR_NONE, 17);

  test(18);
  assert(segment_release(segid3) != ERROR_NONE, 18);

  test(19);
  assert(segment_release(segid3) == ERROR_NONE, 19);

  /* segid1 == 4096 dans l'as 1 */
  /* segid4 == 8192 dans l'as 1 type CATCH */

  test(20);
  assert(segment_clone(asid1, segid1, &segid3) != ERROR_NONE, 20);

  test(21);
  assert(segment_clone(asid1, segid4, &segid2) != ERROR_NONE, 21);

  /* segid1 == 4096 dans l'as 1 */
  /* segid2 == 8192 dans l'as 0 type CATCH */
  /* segid3 == 4096 dans l'as 0 */
  /* segid4 == 8192 dans l'as 1 type CATCH */

  test(22);
  assert(segment_flush(asid1) != ERROR_NONE, 22);

  test(23);
  assert(segment_flush(asid2) != ERROR_NONE, 23);

  test(24);
  assert(segment_dump() != ERROR_NONE, 24);

  /* Il n'y a plus de segment. dans aucun AS. */

  test(25);
  assert(segment_flush(asid1) != ERROR_NONE, 25);

  test(26);
  assert(segment_flush(asid2) != ERROR_NONE, 26);

  test(27);
  assert(as_release(asid1) != ERROR_NONE, 27);

  test(28);
  assert(as_release(asid2) != ERROR_NONE, 28);

  return ERROR_NONE;
}


t_error	segment_test_advanced(void)
{
  t_segid	segid1 = 0;
  t_segid	segid2 = 0;
  t_segid	segid3 = 0;
  t_segid	segid4 = 0;
  t_asid	asid1 = 0;

  char		buff[1024];
  const char	space[] = " ";
  const char	chiche[] = "Chiche !!!";
  const char	branle[] = "Branle";
  const char	francis[] = "Paye ta gratte Francis !!!";

  test(1);
  assert(as_reserve(0, &asid1) != ERROR_NONE, 1);

  test(2);
  assert(as_reserve(1, &asid1) != ERROR_NONE, 2);

  test(3);
  assert(segment_reserve(asid1, 4096, (PERM_READ | PERM_WRITE), &segid1) != ERROR_NONE, 3);

  test(4);
  assert(segment_reserve(asid1, 8192, (PERM_READ | PERM_WRITE), &segid2) != ERROR_NONE, 4);

  test(5);
  assert(segment_reserve(asid1, 4096, (PERM_READ | PERM_WRITE), &segid3) != ERROR_NONE, 5);

  test(6);
  assert(segment_reserve(asid1, 16384, (PERM_READ | PERM_WRITE), &segid4) != ERROR_NONE, 6);

  test(7);
  assert(segment_write(segid1, 0, branle, 6) != ERROR_NONE, 7);

  test(8);
  assert(segment_write(segid1, 6, space, 1) != ERROR_NONE, 8);

  test(9);
  assert(segment_write(segid1, 7, chiche, 10) != ERROR_NONE, 9);

  test(10);
  assert(segment_read(segid1, 0, buff, 17) != ERROR_NONE, 10);
  assert(strcmp(buff, "Branle Chiche !!!") != 0, 10);

  test(11);
  assert(segment_write(segid2, 5000, chiche, 10) != ERROR_NONE, 11);

  test(12);
  assert(segment_read(segid2, 5000, buff, 10) != ERROR_NONE, 12);
  buff[10] = 0;
  assert(strcmp(buff, "Chiche !!!") != 0, 12);

  test(13);
  assert(segment_copy(segid3, 100, segid2, 5000, 8) != ERROR_NONE, 13);

  test(14);
  assert(segment_read(segid3, 100, buff, 6) != ERROR_NONE, 14);
  buff[6] = 0;
  assert(strcmp(buff, "Chiche") != 0, 14);

  test(15);
  assert(segment_copy(segid4, 14000, segid1, 7, 10) != ERROR_NONE, 15);

  test(16);
  assert(segment_write(segid4, 14010, space, 1) != ERROR_NONE, 16);

  test(17);
  assert(segment_write(segid4, 14011, francis, 26) != ERROR_NONE, 17);

  test(18);
  assert(segment_read(segid4, 14000, buff, 37) != ERROR_NONE, 18);
  buff[37] = 0;
  assert(strcmp(buff, "Chiche !!! Paye ta gratte Francis !!!") != 0, 18);

  test(19);
  assert(segment_release(segid1) != ERROR_NONE, 19);

  test(20);
  assert(segment_release(segid2) != ERROR_NONE, 20);

  test(21);
  assert(segment_release(segid3) != ERROR_NONE, 21);

  test(22);
  assert(segment_perms(segid4, PERM_READ) != ERROR_NONE, 22);

  test(23);
  assert(segment_write(segid4, 12000, francis, 26) == ERROR_NONE, 23);

  test(24);
  assert(segment_perms(segid4, (PERM_READ | PERM_WRITE)) != ERROR_NONE, 24);

  test(25);
  assert(segment_write(segid4, 12000, francis, 26) != ERROR_NONE, 25);

  test(26);
  assert(segment_release(segid4) != ERROR_NONE, 26);

  test(27);
  assert(segment_flush(asid1) != ERROR_NONE, 27);

  test(28);
  assert(segment_flush(asid1) != ERROR_NONE, 28);

  test(29);
  assert(segment_reserve(asid1, 8192, (PERM_READ | PERM_WRITE), &segid1) != ERROR_NONE, 29);

  test(30);
  assert(segment_write(segid1, 222, francis, 26) != ERROR_NONE, 30);

  test(31);
  assert(segment_read(segid1, 222, buff, 26) != ERROR_NONE, 31);
  buff[26] = 0;
  assert(strcmp(buff, "Paye ta gratte Francis !!!") != 0, 31);

  test(32);
  assert(segment_resize(segid1, 4096, &segid2) != ERROR_NONE, 32);

  test(33);
  assert(segment_read(segid2, 222, buff, 26) != ERROR_NONE, 33);
  buff[26] = 0;
  assert(strcmp(buff, "Paye ta gratte Francis !!!") != 0, 33);

  test(34);
  assert(segment_clone(asid1, segid2, &segid1) != ERROR_NONE, 34);

  test(35);
  assert(segment_read(segid1, 222, buff, 26) != ERROR_NONE, 35);
  buff[26] = 0;
  assert(strcmp(buff, "Paye ta gratte Francis !!!") != 0, 35);

  test(36);
  assert(segment_release(segid1) != ERROR_NONE, 36);

  test(37);
  assert(segment_resize(segid2, 8192, &segid1) != ERROR_NONE, 37);

  test(38);
  assert(segment_release(segid2) == ERROR_NONE, 38);

  test(39);
  assert(segment_read(segid1, 222, buff, 26) != ERROR_NONE, 39);
  buff[26] = 0;
  assert(strcmp(buff, "Paye ta gratte Francis !!!") != 0, 39);

  test(40);
  assert(segment_release(segid1) != ERROR_NONE, 40);

  test(41);
  assert(as_release(asid1) != ERROR_NONE, 41);

  test(42);
  assert(as_release(asid1) == ERROR_NONE, 42);

  return ERROR_NONE;
}


#endif
