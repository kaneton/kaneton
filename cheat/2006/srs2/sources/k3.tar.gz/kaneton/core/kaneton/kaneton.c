/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:48:24 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

void	       	kaneton(t_init*				bootloader)
{
  gdt_reload();
  init = bootloader;
  /* reinit de la console */
  init_cons();
  cons_clear_screen();
  cons_msg('+', "Kaneton Loaddddddddddddddddded in chiche\n\n");

  /* init malloc */
  if (bootloader->allocsz == 0)
    printf("Paye ton boulet\n");
  else
    printf("Taille de l'alloc : %i\n", bootloader->allocsz);
  alloc_init(bootloader->alloc, bootloader->allocsz, ALLOC_FIT);

  /* init id manager */
  id_init();
  cons_msg('+', "Initialisation\tID\t\t\t[OK]\n");

  /* init du set manager */
  set_init();
  cons_msg('+', "Initialisation\tSet\t\t\t[OK]\n");

#ifdef CONF_TEST_SET
  /*  set_memory_test(); */
  printf("TESTS OK\n");
  if (set_test(1) == ERROR_UNKNOWN)
    while (1)
      ;
  set_ordering_test();
/*   alloc_dump(); */
/*   set_test(2); */
#endif

  /* Ini de l'as manager */
  as_init();
  cons_msg('+', "Initialisation\tAs\t\t\t[OK]\n");

  /* init du segment manager */
  segment_init();
  cons_msg('+', "Initialisation\tSegment\t\t\t[OK]\n");

  /* init du region manager */
  region_init(PAGESZ, 4 * 1000 * 1000);
  cons_msg('+', "Initialisation\tRegion\t\t\t[OK]\n");

  /* init du map manager */
  map_init();
  cons_msg('+', "Initialisation\tMap\t\t\t[OK]\n");

  /* init du timer manager */
  timer_init();
  cons_msg('+', "Initialisation\tTimer\t\t\t[OK]\n");
# ifdef CONF_TEST_TIMER
  timer_test();
# endif

#ifdef CONF_TEST_SEGMENT
# ifndef CONF_TEST_SEGMENT_ADVANCED
  if ((segment_test()) != ERROR_NONE)
    while(1);
# else
  if ((segment_test_advanced()) != ERROR_NONE)
    while(1);
# endif
#endif
#ifdef CONF_TEST_AS
  if ((as_test()) != ERROR_NONE)
    while(1);
#endif
#ifdef CONF_TEST_REGION
  if ((region_test()) != ERROR_NONE)
    while(1);
#endif
#ifdef CONF_TEST_MAP
  if ((map_test()) != ERROR_NONE)
    while(1);
#endif


  cons_msg('+', "Initialisation des managers\t\t[OK]\n");

#ifdef SERIAL
  debug_init();
#endif

/*   set_clean(); */
  id_clean();
  segment_clean();
  region_clean();
  map_clean();
  as_clean();

  cons_msg('+', "Destruction des managers\t\t\t[OK]\n");

  cons_msg('+', "Kaneton End\t\t\t\t[OK]\n");
  while (1)
    ;
}
