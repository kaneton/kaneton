/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:29:40 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  file implements dependent  code for  segment manager  on ia32
 * with paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern t_init*		init;
extern m_segment*	segment;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager interface.
 */

i_segment		segment_interface =
  {
    NULL,
    NULL,
    NULL,
    dep_segment_resize,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    dep_segment_reserve,
    NULL,
    NULL,
    dep_segment_perms,
    dep_segment_type,
    NULL,
    NULL,
    NULL
  };

/*
 * ---------- functions -------------------------------------------------------
 */

void	gdt_reload(void)
{
  gdt_del_entry(1);
  gdt_del_entry(2);
  gdt_del_entry(3);
  gdt_del_entry(4);
  //core
  gdt_add_entry (0,
		 0xfffff,
		 GDT_CODE | GDT_SEGMENT | GDT_DPL0 | GDT_PRESENT,
		 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_add_entry (0,
		 0xfffff,
		 GDT_DATA | GDT_SEGMENT | GDT_DPL0 | GDT_PRESENT,
		 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  //dirver
  gdt_add_entry (0,
		 0xfffff,
		 GDT_CODE | GDT_SEGMENT | GDT_DPL1 | GDT_PRESENT,
		 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_add_entry (0,
		 0xfffff,
		 GDT_DATA | GDT_SEGMENT | GDT_DPL1 | GDT_PRESENT,
		 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  //service
  gdt_add_entry (0,
		 0xfffff,
		 GDT_CODE | GDT_SEGMENT | GDT_DPL2 | GDT_PRESENT,
		 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_add_entry (0,
		 0xfffff,
		 GDT_DATA | GDT_SEGMENT | GDT_DPL2 | GDT_PRESENT,
		 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  //program
  gdt_add_entry (0,
		 0xfffff,
		 GDT_CODE | GDT_SEGMENT | GDT_DPL3 | GDT_PRESENT,
		 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_add_entry (0,
		 0xfffff,
		 GDT_DATA | GDT_SEGMENT | GDT_DPL3 | GDT_PRESENT,
		 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  
  // Passage en mode protege: CR0 = 1
  gdt_activate();
}

t_error		dep_segment_reserve(t_asid asid, t_psize size, t_perms perms, t_segid* segid)
{
  t_error	error = ERROR_NONE;
  o_as		*as = NULL;

  SEGMENT_ENTER(segment);
  /* r, rw, rx, rwx */
  if (!((perms == PERM_READ) ||
	(perms == (PERM_READ | PERM_WRITE)) ||
	(perms == (PERM_READ | PERM_EXEC)) ||
	(perms == (PERM_READ | PERM_WRITE | PERM_EXEC))))
    error = ERROR_UNKNOWN;
  else
    if ((size % PAGESZ) != 0)
      error = ERROR_UNKNOWN;
    else
      error = as_get(asid, &as);
  SEGMENT_LEAVE(segment, error);
}

t_error		dep_segment_perms(t_segid segid, t_perms perms)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;

  SEGMENT_ENTER(segment);
  if (!((perms == PERM_READ) ||
	(perms == (PERM_READ | PERM_WRITE)) ||
	(perms == (PERM_READ | PERM_EXEC)) ||
	(perms == (PERM_READ | PERM_WRITE | PERM_EXEC))))
    error = ERROR_UNKNOWN;
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if (perms & PERM_WRITE)
    pt_writable(seg->address);
  else
    pt_readable(seg->address);
  SEGMENT_LEAVE(segment, error);
}

t_error		dep_segment_resize(t_segid segid, t_psize size, t_segid* new)
{
  t_error	error = ERROR_NONE;

  SEGMENT_ENTER(segment);
  if (size % PAGESZ)
    error = ERROR_UNKNOWN;
  SEGMENT_LEAVE(segment, error);
}

t_error		dep_segment_type(t_segid s, t_type type)
{
  t_error	error = ERROR_NONE;

  SEGMENT_ENTER(segment);
  if ((type != SEGMENT_TYPE_CATCH) &&
      (type != SEGMENT_TYPE_MEMORY))
    error = ERROR_UNKNOWN;
  SEGMENT_LEAVE(segment, error);
}
