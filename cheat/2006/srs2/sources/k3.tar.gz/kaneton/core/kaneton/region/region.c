/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/region/region.c
 *
 * created       julien quintard   [wed nov 23 09:19:43 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:44:09 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the region manager manages mapping of segments.
 *
 * reserving a region means to map virtual addresses to a segment.
 *
 * like for  segment, region identifiers are the  virtual address they
 * maps.
 *
 * unlike segments, regions  are proper to an address  space: there is
 * one set of region objects for each address space to prevent collisions.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to develop  entirely this manager, including the code
 * for one architecture (ia32-virtual or ia32-segment).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(region);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the region manager structure.
 */

m_region*		region;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * ----------------------------------------------------------------------------
 */
/* Displays information on a region. */
t_error region_show(t_asid asid, t_regid regid)
{
  t_error	error = ERROR_NONE;
  o_region	*reg = NULL;

  REGION_ENTER(region);
  if ((error = region_get(asid, regid, &reg)) != ERROR_NONE)
    REGION_LEAVE(region, error);
  printf("Adress Space : %qd\n", asid);
  printf("\tRegion %qd, liee au segment %qd\n", regid, reg->segid);
  printf("\t\tAddress : 0x%x\n", reg->address);
  printf("\t\tOffset : %d\n", reg->offset);
  printf("\t\tSize : %d\n", reg->size);
  REGION_LEAVE(region, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Displays information on all regions of the address space. */
t_error region_dump(t_asid asid)
{
  t_error	error = ERROR_NONE;
  o_region	*reg = NULL;
  o_as		*as = NULL;
  t_iterator	i;
  t_state	s;

  REGION_ENTER(region);
  if ((error = as_get(asid, &as)) != ERROR_NONE)
    REGION_LEAVE(region, error);
  set_foreach(SET_OPT_FORWARD, as->regions, &i, s)
    {
      set_object(as->regions, i, (void **) &reg);
      region_show(asid, reg->regid);
    }
  REGION_LEAVE(region, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Injects a pre-reserved region. */
t_error region_inject(t_asid asid, o_region* o)
{
  t_error	error = ERROR_NONE;
  o_as		*as = NULL;

  REGION_ENTER(region);
  if ((error = as_get(asid, &as)) != ERROR_NONE)
    REGION_LEAVE(region, error);
  error = set_add(as->regions, o);
  REGION_LEAVE(region, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Reserves a region given some properties. */
t_error region_reserve(t_asid asid, t_segid segid, t_paddr offset, t_opts opts,
		       t_vaddr address, t_vsize size, t_regid* regid)
{
  t_error	error = ERROR_NONE;
  o_as		*as = NULL;
  o_segment	*seg = NULL;
  t_vsize	rsize = 0;
  t_paddr	roff = 0;
  o_region	reg;

  REGION_ENTER(region);
  if ((error = as_get(asid, &as)) != ERROR_NONE)
    return error;
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    return error;
  rsize = size;
  roff = offset;
  if (opts & REGION_OPT_MAPALL)
    {
      rsize = seg->size;
      roff = 0;
    }
  if ((error = machdep_call(region, region_reserve, asid, segid, roff, opts, address, rsize, &reg.regid)) != ERROR_NONE)
    REGION_LEAVE(region, error);
  reg.segid = segid;
  reg.address = (t_vaddr) reg.regid;
  reg.offset = roff;
  reg.size = rsize;
  error = set_add(as->regions, &reg);
  *regid = reg.regid;
  REGION_LEAVE(region, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Releases a region. */
t_error region_release(t_asid asid, t_regid regid)
{
  t_error	error = ERROR_NONE;
  o_as		*as = NULL;

  REGION_ENTER(region);
  if ((error = machdep_call(region, region_release, asid, regid)) != ERROR_NONE)
    return error;
  if ((error = as_get(asid, &as)) != ERROR_NONE)
    REGION_LEAVE(region, error);
  error = set_remove(as->regions, regid);
  REGION_LEAVE(region, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Removes every region that belongs to the specied address space. */
t_error region_flush(t_asid asid)
{
  t_error	error = ERROR_NONE;
  o_region	*reg = NULL;
  o_as		*as = NULL;
  t_state	s;
  t_iterator	i;

  REGION_ENTER(region);
  if ((error = as_get(asid, &as)) != ERROR_NONE)
    REGION_LEAVE(region, error);
  set_foreach(SET_OPT_FORWARD, as->regions, &i, s)
    {
      if ((error = set_object(as->regions, i, (void **) &reg)) != ERROR_NONE)
	REGION_LEAVE(region, error);
      if ((error = region_release(asid, reg->regid)) != ERROR_NONE)
	REGION_LEAVE(region, error);
    }
  REGION_LEAVE(region, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Looks for and returns a region object. */
t_error region_get(t_asid asid, t_regid regid, o_region** o)
{
  t_error	error = ERROR_NONE;
  o_as		*as = NULL;

  REGION_ENTER(region);
  if ((error = as_get(asid, &as)) != ERROR_NONE)
    REGION_LEAVE(region, error);
  error = set_get(as->regions, regid, (void **) o);
  REGION_LEAVE(region, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Initializes the region manager. */
t_error region_init(t_vaddr start, t_vsize size)
{
  t_error	error = ERROR_NONE;

  region = malloc(sizeof (m_region));

  REGION_ENTER(region);
  STATS_RESERVE("region", &region->stats);
  error = id_build(&region->id);
  region->fit = REGION_FIT;
  region->start = start;
  region->size = size;
  REGION_LEAVE(region, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Cleans the region manager. */
t_error region_clean(void)
{
  t_error	error = ERROR_NONE;

  REGION_ENTER(region);
  STATS_RELEASE(region->stats);
  region->fit = 0;
  region->start = 0;
  region->size = 0;
  error = id_destroy(&region->id);
  REGION_LEAVE(region, error);
}
