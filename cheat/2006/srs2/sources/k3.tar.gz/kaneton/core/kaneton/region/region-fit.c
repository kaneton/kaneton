/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/region/region-fit.c
 *
 * created       matthieu bucchianeri   [tue jan 10 01:28:36 2006]
 * updated       matthieu bucchianeri   [tue jan 31 00:21:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file implements simple  fitting algorithms for virtual memory
 * management.
 *
 * you can define which algorithm to use with the macro REGION_FIT.
 *
 *  - FIT_FIRST: first fit algorithm - the first large enough space is taken
 *  - FIT_BEST: best fit algorithm - the smaller space is taken
 *  - ...
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop at least a first-fit algorithm.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(region);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the region manager structure.
 */

extern m_region*       region;

/*
 * ---------- functions -------------------------------------------------------
 */

/* t_error		region_fit(t_asid asid, t_segid segid, t_paddr offset, t_opts opts, */
/* 			   t_vaddr address, t_vsize size, t_regid *regid) */
/* { */
/*   t_error	error = ERROR_NONE; */
/*   o_segment	*seg = NULL; */
/*   t_vsize	rsize = 0; */

/*   REGION_ENTER(region); */
/*   /\* recup du segment *\/ */
/* /\*   if ((error = segment_get(segid, &seg)) != ERROR_NONE) *\/ */
/* /\*     REGION_LEAVE(region, error); *\/ */
/* /\*   if (address != 0) *\/ */
/* /\*     *ret = address; *\/ */
/* /\*   if (opts & REGION_OPT_MAPALL) *\/ */
/* /\*     rsize = seg->size; *\/ */
/* /\*   else *\/ */
/* /\*     rsize = size; *\/ */
/*   /\* address doit etre alignee *\/ */
/* /\*   if ((error = pag_map(seg->address, rsize, offset, ret)) != ERROR_NONE) *\/ */
/* /\*     return error; *\/ */
/* /\*   machdep_call(pag_map,  *\/ */

/*   REGION_LEAVE(region, error); */
/* } */
