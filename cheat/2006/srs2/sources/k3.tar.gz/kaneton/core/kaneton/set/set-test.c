/*
** set-test.c
** Login : <laroch_e@macwis.epita.fr>
** Started on  Tue Mar 28 19:05:56 2006 emeric laroche
** $Id$
*/

#include <klibc.h>
#include <kaneton.h>

#ifdef CONF_TEST_SET


static t_error test_object_p(t_setid id, t_iterator it, char* str)
{
  char* c;
  if (set_object(id, it, (void**)&c) != ERROR_NONE)
    {
      printf("pb test object\n");
      return ERROR_UNKNOWN;
    }
  else
    if (strcmp(str, c))
      {
	printf("pb test strcmp\n");
	return ERROR_UNKNOWN;
      }
  return ERROR_NONE;
}

#define test_object(_args_...)\
  if (test_object_p(_args_) != ERROR_NONE)\
    return ERROR_UNKNOWN


#define assert(_cond_, _nb_) \
	if (_cond_) {printf("probleme test " #_nb_ "\n"); return ERROR_UNKNOWN;}

#define test(_nb_)					\
	printf ("############### TEST " #_nb_ " ####################\n")

t_error set_test(int type)
{
  t_setid	id = 0;
  t_iterator	it;
  t_setsz	sz = 0;

  switch (type)
    {
    case 1:
     
	test(1 ll);
	assert(set_type(ll, 0) != ERROR_NONE, 1)
	  
	  test(2 ll);
	assert(set_reserve(ll, SET_OPT_ALLOC,
			   sizeof (char) * 10,
			   &id) != ERROR_NONE, 2)
	  set_show_ll(0);
	  test(3 ll);
	assert(set_type(ll, id) != ERROR_NONE, 3 toto)
	  break;
      
    case 2:
      
	test(1 array);
	assert(set_type(array, 0) == ERROR_NONE, 1)
       test(2 array);
	assert(set_reserve(array, SET_OPT_ALLOC, 10,
			   sizeof (char) * 10,
			   &id) != ERROR_NONE, 2)
       
       test(3 array);
     assert(set_type(array, id) != ERROR_NONE, 3)
       break;
      
    }

    test(4 head vide -> erreur);
  assert(set_head(id, &it) == ERROR_NONE, 4)
    test(taille ok ?);
  assert(set_size(id, &sz) != ERROR_NONE, 4)
    assert(sz != 0,4)

    test(5 tail vide -> erreur);
  assert(set_tail(id, &it) == ERROR_NONE, 5)

    test(6 insert_head avec liste vide);
  assert(set_insert_head(id, "toto") != ERROR_NONE, 6)
    assert(set_size(id, &sz) != ERROR_NONE, 6)
    assert(sz != 1,6)

    test(7 head liste a un elt );
  assert(set_head(id, &it) != ERROR_NONE, 7)
    else
      test_object(id, it, "toto");
  // FIXME

  test(8 tail liste a un elt);
  assert(set_tail(id, &it) != ERROR_NONE, 8)
    else
      test_object(id, it, "toto");

  test(9 previous liste a un elt -> erreur);
  assert(set_previous(id, it, &it) == ERROR_NONE, 9)

    test(10 next liste a un elt -> erreur);
  assert (set_next(id, it, &it) == ERROR_NONE, 10)
 
    test(11 insert en queue sur liste non vide => 2 elts);
  assert (set_insert_tail(id, "tata") != ERROR_NONE, 11)
    assert(set_size(id, &sz) != ERROR_NONE, 11)
    assert(sz != 2,11)

    test(12 head list a 2 elts);
  assert (set_head(id, &it) != ERROR_NONE, 12)
  else
    test_object(id, it, "toto");

  test(13 next liste a 2 elts);
  assert (set_next(id, it, &it) != ERROR_NONE, 13)
    else
      test_object(id, it, "tata");

  test(14 tail list a 2 elts -> i[1]);
  assert (set_tail(id, &it) != ERROR_NONE, 14)
  else
    test_object(id, it, "tata");

  test(15 previous liste a 2 elts i[0]);
  assert (set_previous(id, it, &it) != ERROR_NONE, 15)
    else
      test_object(id, it, "toto");

  test(16 previous liste a 2 elts erreur (i[-1]));
  assert (set_previous(id, it, &it) == ERROR_NONE, 16)

    test(17 insert en tete -> 3 elts);
  //insertion en tete sur liste non vide
  assert (set_insert_head(id, "tutu") != ERROR_NONE, 17)

  //test si la liste est dans le bon sens depuis la gauche vers la droite
    test(18);
  assert (set_head(id, &it) != ERROR_NONE, 18)
    else
      {
	test_object(id, it, "tutu");
	assert(set_next(id, it, &it) != ERROR_NONE, 18)
	  test_object(id,it, "toto");
	assert(set_next(id, it, &it) != ERROR_NONE, 18)
	  test_object(id, it, "tata");
	assert(set_next(id, it , &it) == ERROR_NONE, 18)
      }
  // au delete verification de head et tail
  test(19);
  //  assert(set_insert_head(id, "first") != ERROR_NONE, 19)
  assert(set_head(id, &it) != ERROR_NONE, 19)
    assert(set_next(id, it, &it) != ERROR_NONE, 19)
    //on enleve l'element du milieu
    assert(set_delete(id, it) != ERROR_NONE, 19)
    else
      {
	assert(set_size(id, &sz) != ERROR_NONE, 19)
	  assert(sz != 2,19)
	//test avant le debut
	assert(set_head(id, &it) != ERROR_NONE, 19)
	  assert(set_previous(id, it, &it) == ERROR_NONE, 19)
	//test apres la fin
	  assert(set_tail(id, &it) != ERROR_NONE, 19)
	  assert(set_next(id, it, &it) == ERROR_NONE,19)
	  //parcours complet de la liste
	  assert(set_head(id, &it) != ERROR_NONE,19)
	test_object(id, it, "tutu");
	assert(set_next(id, it, &it) != ERROR_NONE, 19)
	  test_object(id, it, "tata");
	assert(set_next(id, it , &it) == ERROR_NONE, 19)
	//test du parcours
      }

  test(20);
  //deletion du premier element
  assert(set_head(id, &it) != ERROR_NONE, 20)
    assert(set_delete(id, it) != ERROR_NONE, 20)
    else
      {
	assert(set_size(id, &sz) != ERROR_NONE, 20)
	  assert(sz != 1,20)

	//test avant le debut
	assert(set_head(id, &it) != ERROR_NONE, 20)
	  assert(set_previous(id, it, &it) == ERROR_NONE, 20)
	  //test apres la fin
	  assert(set_tail(id, &it) != ERROR_NONE, 20)
	  assert(set_next(id, it, &it) == ERROR_NONE,20)
	  //parcours complet de la liste
	  assert(set_head(id, &it) != ERROR_NONE,20)
	  test_object(id, it, "tata");
	assert(set_next(id, it , &it) == ERROR_NONE, 20)
	  //test du parcours

      }
  test(21);
  //deletion du premier element => liste vide
  assert(set_tail(id, &it) != ERROR_NONE, 21_1)
    assert(set_delete(id, it) != ERROR_NONE, 21_2)
    else
      {

	assert(set_size(id, &sz) != ERROR_NONE, 21)
	  assert(sz != 0,21)
	  //test sur le debut
	assert(set_head(id, &it) == ERROR_NONE, 21_3)
	  //test sur la fin
	  assert(set_tail(id, &it) == ERROR_NONE, 21_4)
      }


  test(22);
//insertion en tete sur liste vide
  assert(set_insert_tail(id,"pwet") != ERROR_NONE, 22_1)
     else
     {
	assert(set_size(id, &sz) != ERROR_NONE, 22)
	  assert(sz != 1,22)
       assert(set_tail(id, &it) != ERROR_NONE, 22_2)
	 test_object(id, it, "pwet");
       assert(set_head(id, &it) != ERROR_NONE, 22_3)
	 test_object(id, it, "pwet");
     }

  test(23);
//deletion du dernier element => liste vide
  assert(set_tail(id, &it) != ERROR_NONE, 23)
    assert(set_delete(id, it) != ERROR_NONE, 23)
    else
      {
	assert(set_size(id, &sz) != ERROR_NONE, 23)
	  assert(sz != 0,23)

	  //test sur le debut
	assert(set_head(id, &it) == ERROR_NONE, 23)
	  //test sur la fin
	  assert(set_tail(id, &it) == ERROR_NONE, 23)
      }

  test(24);
  //test du flush
  assert(set_insert_tail(id,"pwet") != ERROR_NONE, 24)
  assert(set_flush_ll(id) != ERROR_NONE, 24)
  assert(set_head(id, &it) == ERROR_NONE, 24)
  assert(set_size(id, &sz) != ERROR_NONE, 24)
  assert(sz != 0,24)


    test(25);
  assert(set_insert_tail(id,"pwet") != ERROR_NONE, 25);
  assert(set_release(id) != ERROR_NONE, 25);
  assert(set_type(ll,id) == ERROR_NONE, 25);

  test(26);
  //test du conteneur trie
    {
      struct temp
      {
	t_id id;
	char s[10];
      };
      assert(set_reserve(ll, SET_OPT_ALLOC | SET_OPT_SORT, sizeof (struct temp), &id) != ERROR_NONE, 26)
      struct temp t;
      t.id = 50;
      strcpy((t.s), "third");

      assert(set_add(id, &t) != ERROR_NONE, 26 1)
	assert (set_head(id, &it) != ERROR_NONE, 26 2)
	t.id = 12;
      strcpy((t.s), "first");
	assert(set_add(id, &t) != ERROR_NONE, 26 3)
	t.id = 18;
      strcpy((t.s), "second");
	assert(set_add(id, &t) != ERROR_NONE, 26 4)
	t.id = 52;
      strcpy((t.s), "last");
	assert(set_add(id, &t) != ERROR_NONE, 26 5)
	  assert (set_head(id, &it) != ERROR_NONE, 26 6)
	  else
	    {
	      struct temp* t2;
	      if (set_object(id, it, (void**)&t2) != ERROR_NONE)
		{
		  printf("pb test object\n");
		  return ERROR_UNKNOWN;
		}
	      else
		if (strcmp("first", t2->s))
		  {
		    printf("pb test strcmp : 1 %s\n", t2->s);
		    return ERROR_UNKNOWN;
		  }
	  assert(set_next(id, it, &it) != ERROR_NONE, 26 7)

	      if (set_object(id, it, (void**)&t2) != ERROR_NONE)
		{
		  printf("pb test object\n");
		  return ERROR_UNKNOWN;
		}
	      else
		if (strcmp("second", t2->s))
		  {
		    printf("pb test strcmp : 2 %s\n", t2->s);
		    return ERROR_UNKNOWN;
		  }
	  assert(set_next(id, it, &it) != ERROR_NONE, 26 8)

	      if (set_object(id, it, (void**)&t2) != ERROR_NONE)
		{
		  printf("pb test object\n");
		  return ERROR_UNKNOWN;
		}
	      else
		if (strcmp("third", t2->s))
		  {
		    printf("pb test strcmp : 2 %s\n", t2->s);
		    return ERROR_UNKNOWN;
		  }
	  assert(set_next(id, it, &it) != ERROR_NONE, 26 9)

	      if (set_object(id, it, (void**)&t2) != ERROR_NONE)
		{
		  printf("pb test object\n");
		  return ERROR_UNKNOWN;
		}
	      else
		if (strcmp("last", t2->s))
		  {
		    printf("pb test strcmp : 2 %s\n", t2->s);
		    return ERROR_UNKNOWN;
		  }
	      assert(set_next(id, it , &it) == ERROR_NONE, 26 10)
		}

	test(27 utilisation de plusieurs sets simultanes);
	  
      assert(set_reserve(ll, SET_OPT_ALLOC | SET_OPT_SORT, sizeof (struct temp), &id) != ERROR_NONE, 27)
      assert(set_head(id, &it) == ERROR_NONE, 27)
      
      assert(set_reserve(ll, 0, sizeof (struct temp), &id) != ERROR_NONE, 27)
      assert(set_head(id, &it) == ERROR_NONE, 27)


	}

  printf("Set tested correctly\n");
  //deletion d'une liste, acces a cette liste
  //flush d'une liste, liste vide ?
  return ERROR_NONE;
}




struct t_test {
  t_setid id;
  char toto[10];
};

t_error set_ordering_test(void)
{
  t_setid	id = 0;
  struct t_test	un = {1, "1"};
  struct t_test	cinq = {5, "5"};
  struct t_test	six = {6, "6"};
  struct t_test	huit = {8, "8"};
  struct t_test	dix = {10, "10"};
  struct t_test	quinze = {15, "15"};
  struct t_test	vingt = {20, "20"};
  struct t_test	vingtcinq = {25, "25"};
  t_iterator	it;

  test(ORDERING);
  test(ONE);
  set_reserve(ll, SET_OPT_SORT, sizeof(struct t_test), &id);
  printf("debut des ajout\n");
  set_add(id, &cinq);
  set_add(id, &quinze);
  set_add(id, &dix);
  set_add(id, &vingt);
  set_add(id, &six);
  set_add(id, &un);
  set_add(id, &huit);
  set_add(id, &vingtcinq);
  set_show(id);
  test(DONE);
  return ERROR_NONE;
}

t_error set_memory_test(void)
{

  /*   t_test t; */
  t_setid	id;
  int test = 1;
  switch(test)
    {
    case 1:
      alloc_dump();
      set_reserve(ll, 0,sizeof (struct t_test), &id);
      set_release(id);
      alloc_dump();
      break;
    case 2:
      
      
      break;
    }
  return 0;
}
#endif
