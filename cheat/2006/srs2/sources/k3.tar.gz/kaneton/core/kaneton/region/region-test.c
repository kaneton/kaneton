/*
** region-test.c
** Login : <meyer_f@bastille.epita.fr>
** Started on  Tue Mar 28 19:05:56 2006 frederick meyer
** $Id$
*/

#include <klibc.h>
#include <kaneton.h>

#ifdef CONF_TEST_REGION

# define assert(_cond_, _nb_) \
	if (_cond_) {printf("Erreur au test " #_nb_ "\n"); return ERROR_UNKNOWN;}

t_error		chk_region(t_regid regid, t_asid asid, t_segid segid,
			   t_vaddr address, t_vsize size, t_paddr offset)
{
  t_error	error = ERROR_NONE;
  o_region	*reg = NULL;

  if ((error = region_get(asid, regid, &reg)) != ERROR_NONE)
    return error;
  if (reg->segid != segid)
    return ERROR_UNKNOWN;
  if (address != -1)
    if (reg->address != address)
      return ERROR_UNKNOWN;
  if (size != -1)
    if (reg->size != size)
      return ERROR_UNKNOWN;
  if (offset != -1)
    if (reg->offset != offset)
      return ERROR_UNKNOWN;
  return error;
}

# define check_region(_regid_, _asid_, _segid_, _address_, _size_, _offset_, _nb_)\
	if (chk_region(_regid_, _asid_, _segid_, _address_, _size_, _offset_) != ERROR_NONE)	\
		{printf("Erreur au test " #_nb_ "\n"); return ERROR_UNKNOWN;}

# define test(_nb_)					\
	printf ("############### TEST " #_nb_ " ####################\n")

/*
 * -----------------------------------------------------------------------------
 */

t_error		region_test(void)
{
  t_error	error = ERROR_NONE;
  t_asid	asid1 = 0;
  t_asid	asid2 = 1;

  t_segid	segid1 = 0;
  t_segid	segid2 = 0;
  t_segid	segid3 = 0;
  t_segid	segid4 = 0;

  t_regid	regid1 = 0;
  t_regid	regid2 = 0;
  t_regid	regid3 = 0;
  t_regid	regid4 = 0;

  o_region	*regptr1 = NULL;
  o_region	reg1 = {42, 42, 42, 42, 42};


  test(1);
  assert(as_reserve(0, &asid1) != ERROR_NONE, 1);

  test(2);
  assert(as_reserve(0, &asid2) != ERROR_NONE, 2);

  test(3);
  assert(segment_reserve(asid1, 4096, (PERM_READ | PERM_WRITE), &segid1) != ERROR_NONE, 3);

  test(4);
  assert(segment_reserve(asid1, 8192, (PERM_READ | PERM_WRITE), &segid2) != ERROR_NONE, 4);

  test(5);
  assert(segment_reserve(asid1, 4096, (PERM_READ | PERM_WRITE), &segid3) != ERROR_NONE, 5);

  test(6);
  assert(segment_reserve(asid1, 16384, (PERM_READ | PERM_WRITE), &segid4) != ERROR_NONE, 6);

  test(7);
  assert(region_reserve(asid1, segid1, 0, REGION_OPT_NONE, 0, 4096, &regid1) != ERROR_NONE, 7);

  test(8);
  assert(region_show(asid1, regid1) != ERROR_NONE, 8);

  test(9);
  check_region(regid1, asid1, segid1, -1, 4096, 0, 9);

  test(10);
  assert(region_reserve(asid1, segid2, 0, REGION_OPT_NONE, 0, 4096, &regid2) != ERROR_NONE, 10);

  test(11);
  assert(region_reserve(asid1, segid2, 4096, REGION_OPT_NONE, 0, 4096, &regid3) != ERROR_NONE, 11);

  test(12);
  assert(region_dump(asid1) != ERROR_NONE, 12);

  test(13);
  assert(region_reserve(asid1, segid4, 0, REGION_OPT_MAPALL, 0, 4096, &regid4) != ERROR_NONE, 13);

  test(14);
  check_region(regid1, asid1, segid1, -1, 4096, 0, 14);

  test(15);
  check_region(regid2, asid1, segid2, -1, 4096, 0, 15);

  test(16);
  check_region(regid3, asid1, segid2, -1, 4096, 4096, 16);

  test(17);
  check_region(regid4, asid1, segid4, -1, 16384, 0, 17);

  /* A ce niveau, toutes les regions reservees sont bonnes. */
  /* L'option OPT_MAPALL fonctionne egalement. */

  test(18);
  assert(region_inject(asid2, &reg1) != ERROR_NONE, 18);

  test(19);
  check_region(42, asid2, 42, 42, 42, 42, 19);

  test(20);
  assert(region_release(asid1, regid1) != ERROR_NONE, 20);

  test(21);
  assert(pt_is_virtual_empty(regid1, 1) != 1, 21);

  test(22);
  assert(region_release(asid1, regid3) != ERROR_NONE, 22);

  test(23);
  assert(pt_is_virtual_empty(regid3, 1) != 1, 23);

  test(24);
  assert(region_get(asid1, regid1, &regptr1) == ERROR_NONE, 24);

  test(25);
  assert(region_get(asid1, regid3, &regptr1) == ERROR_NONE, 25);

  test(26);
  assert(region_get(asid1, regid2, &regptr1) != ERROR_NONE, 26);

  test(27);
  assert(region_get(asid1, regid4, &regptr1) != ERROR_NONE, 27);

  test(28);
  check_region(regid2, asid1, segid2, -1, 4096, 0, 28);

  test(29);
  check_region(regid4, asid1, segid4, -1, 16384, 0, 29);

  test(30);
  assert(region_flush(asid2) != ERROR_NONE, 30);

  test(31);
  assert(region_get(asid2, 42, &regptr1) == ERROR_NONE, 31);

  /* Il ne reste plus que les regids 2 et 4. */

  test(32);
  assert(region_reserve(asid1, segid4, 4096, REGION_OPT_FORCE, 0x0A82A000, 8192, &regid1) != ERROR_NONE, 32);

  test(33);
  check_region(regid1, asid1, segid4, 0x0A82A000, 8192, 4096, 33);

  /* Toutes les options ont ete testees. */

  test(34);
  assert(pt_is_entry_empty(42, 42) == 1, 34);
  assert(pt_is_entry_empty(42, 43) == 1, 34);

  /* L'ajout dans les PT est teste. */

  test(35);
  assert(region_release(asid1, regid1) != ERROR_NONE, 35);

  test(36);
  assert(pd_is_entry_empty(42) == 0, 36);

  test(37);
  assert(region_reserve(asid1, segid4, 4096, REGION_OPT_FORCE | REGION_OPT_MAPALL, 0x0A82A000, 8192, &regid1) != ERROR_NONE, 37);

  test(38);
  check_region(regid1, asid1, segid4, 0x0A82A000, 16384, 0, 38);

  test(39);
  assert(region_release(asid1, regid1) != ERROR_NONE, 39);

  test(40);
  assert(pd_is_entry_empty(42) == 0, 40);

  /* Le combinaison des options est egalement teste. */

  test(41);
  assert(region_flush(asid1) != ERROR_NONE, 41);

  test(42);
  assert(region_flush(asid2) != ERROR_NONE, 42);

  test(43);
  assert(region_dump(asid1) != ERROR_NONE, 43);
  assert(region_dump(asid2) != ERROR_NONE, 43);

  test(44);
  assert(segment_flush(asid1) != ERROR_NONE, 44);

  test(45);
  assert(segment_flush(asid2) != ERROR_NONE, 45);

  test(46);
  assert(as_release(asid1) != ERROR_NONE, 46);

  test(47);
  assert(as_release(asid2) != ERROR_NONE, 47);

  return error;
}

#endif
