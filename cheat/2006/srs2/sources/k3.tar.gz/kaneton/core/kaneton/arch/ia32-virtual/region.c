/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/region.c
 *
 * created       julien quintard   [wed dec 14 07:06:44 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:44:47 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file  implements dependent  code for region  manager on  ia32 with
 * paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_region*	region;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the region manager interface.
 */

i_region		region_interface =
  {
    dep_region_reserve,
    dep_region_release,
    NULL,
    NULL,
    NULL
  };

/*
 * ---------- functions -------------------------------------------------------
 */

t_error			dep_region_reserve(t_asid asid, t_segid segid, t_paddr offset, t_opts opts,
					   t_vaddr address, t_vsize size, t_regid* regid)
{
  t_error		error = ERROR_NONE;
  unsigned int		vaddr = 0;
  o_segment		*seg = NULL;

  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    return error;
  if (opts & REGION_OPT_FORCE)
    vaddr = address;
  if ((error = pag_map(seg->address, size, offset, seg->perms, &vaddr)) != ERROR_NONE)
    return error;
  *regid = (t_regid) vaddr;
  return error;
}

t_error			dep_region_release(t_asid asid, t_regid regid)
{
  t_error		error = ERROR_NONE;
  o_region		*reg = NULL;
  int			pages = 0;

  if ((error = region_get(asid, regid, &reg)) != ERROR_NONE)
    return error;
  pages = (reg->size / PAGESZ);
  return pag_del_virtual(reg->address, pages);
}
