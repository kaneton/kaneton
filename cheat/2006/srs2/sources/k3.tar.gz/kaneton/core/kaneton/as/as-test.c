/*
** set-test.c
** Login : <meyer_f@bastille.epita.fr>
** Started on  Tue Mar 28 19:05:56 2006 frederick meyer
** $Id$
*/

#include <klibc.h>
#include <kaneton.h>

#ifdef CONF_TEST_AS

# define assert(_cond_, _nb_) \
	if (_cond_) {printf("Erreur au test " #_nb_ "\n"); return ERROR_UNKNOWN;}

#define test(_nb_)					\
	printf ("############### TEST " #_nb_ " ####################\n")

t_error		as_chk_region(t_regid regid, t_asid asid, t_segid segid,
			      t_vaddr address, t_vsize size, t_paddr offset)
{
  t_error	error = ERROR_NONE;
  o_region	*reg = NULL;
  
  if ((error = region_get(asid, regid, &reg)) != ERROR_NONE)
    return error;
  if (reg->segid != segid)
    return ERROR_UNKNOWN;
  if (address != -1)
    if (reg->address != address)
      return ERROR_UNKNOWN;
  if (size != -1)
    if (reg->size != size)
      return ERROR_UNKNOWN;
  if (offset != -1)
    if (reg->offset != offset)
      return ERROR_UNKNOWN;
  return error;
}

# define check_region(_regid_, _asid_, _segid_, _address_, _size_, _offset_, _nb_)\
	if (as_chk_region(_regid_, _asid_, _segid_, _address_, _size_, _offset_) != ERROR_NONE)	\
		{printf("Erreur au test " #_nb_ "\n"); return ERROR_UNKNOWN;}

t_error		chk_p_address(t_asid asid, t_segid segid, t_paddr physical, t_vaddr virtual)
{
  t_error	error = ERROR_NONE;
  t_vaddr	vaddr = 0;

  if ((error = as_vaddr(asid, segid, physical, &vaddr)) != ERROR_NONE)
    return error;
  if (vaddr != virtual)
    error = ERROR_UNKNOWN;
  return error;
}

t_error		chk_v_address(t_asid asid, t_regid regid, t_vaddr virtual, t_paddr physical)
{
  t_error	error = ERROR_NONE;
  t_paddr	paddr = 0;

  if ((error = as_paddr(asid, regid, virtual, &paddr)) != ERROR_NONE)
    return error;
  if (paddr != physical)
    error = ERROR_UNKNOWN;
  return error;
}


t_error		as_test(void)
{
  t_asid	asid1 = 42;
  t_asid	asid2 = 42;
  t_asid	asid3 = 42;
  t_asid	asid4 = 42;
  t_asid	asid5 = 42;

  t_segid	segid1 = 0;
  t_segid	segid2 = 0;
  t_segid	segid3 = 0;

  t_regid	regid1 = 0;
  t_regid	regid2 = 0;
  t_regid	regid3 = 0;

  o_region	*reg = NULL;
  o_segment	*seg = NULL;


  test(1);
  assert(as_reserve(0, &asid1) != ERROR_NONE, 1);

  test(2);
  assert(as_reserve(0, &asid2) != ERROR_NONE, 2);

  test(3);
  assert(as_reserve(0, &asid3) != ERROR_NONE, 3);

  test(4);
  assert(as_show(asid3) != ERROR_NONE, 4);

  test(5);
  assert(as_dump() != ERROR_NONE, 5);

  test(6);
  assert(as_clone(1, asid1, &asid4) != ERROR_NONE, 6);

  test(7);
  assert(as_clone(1, asid4, &asid5) != ERROR_NONE, 7);

  test(8);
  assert(as_show(asid1) != ERROR_NONE, 8);

  test(9);
  assert(as_dump() != ERROR_NONE, 9);

  test(10);
  assert(as_release(asid1) != ERROR_NONE, 10);

  test(11);
  assert(as_release(asid3) != ERROR_NONE, 11);

  test(12);
  assert(as_release(asid4) != ERROR_NONE, 12);

  test(13);
  assert(as_dump() != ERROR_NONE, 13);

  test(14);
  assert(as_release(asid2) != ERROR_NONE, 14);

  test(15);
  assert(as_release(asid2) == ERROR_NONE, 15);

  test(16);
  assert(as_release(asid5) != ERROR_NONE, 16);

  test(17);
  assert(as_dump() != ERROR_NONE, 17);

  /* A ce niveau, il n'y a plus d'AS. */

  test(18);
  assert(as_reserve(0, &asid1) != ERROR_NONE, 18);

  test(19);
  assert(as_reserve(0, &asid2) != ERROR_NONE, 19);

  test(20);
  assert(segment_reserve(asid1, 8192, (PERM_READ | PERM_WRITE), &segid1) != ERROR_NONE, 20);

  test(21);
  assert(segment_reserve(asid2, 4096, (PERM_READ | PERM_WRITE), &segid2) != ERROR_NONE, 21);

  test(22);
  assert(segment_reserve(asid2, 16384, (PERM_READ | PERM_WRITE), &segid3) != ERROR_NONE, 22);

  test(23);
  assert(region_reserve(asid1, segid1, 0, REGION_OPT_NONE, 0, 8192,
			&regid1) != ERROR_NONE, 23);

  test(24);
  assert(region_reserve(asid2, segid2, 0, REGION_OPT_MAPALL, 0, 0,
			&regid2) != ERROR_NONE, 24);

  test(25);
  assert(region_reserve(asid2, segid3, 0, REGION_OPT_FORCE | REGION_OPT_MAPALL,
			0x15054000, 4096, &regid3) != ERROR_NONE, 25);

  test(26);
  check_region(regid1, asid1, segid1, -1, 8192, 0, 26);

  test(27);
  check_region(regid2, asid2, segid2, -1, 4096, 0, 27);

  test(28);
  check_region(regid3, asid2, segid3, 0x15054000, 16384, 0, 28);

  /* region1 de taille 8192 liee au segment 1 de taille 8192. */
  /* region2 de taille 4096 liee au segment 2 de taille 4096. */
  /* region3 (0x15054000) de taille 16384 liee au segment 3 de taille 16384. */

  test(29);
  assert(segment_get(segid3, &seg) != ERROR_NONE, 29);
  assert(chk_p_address(asid2, segid3, seg->address, 0x15054000) != ERROR_NONE, 29);

  test(30);
  assert(chk_p_address(asid2, segid3, (seg->address + 42), (0x15054000 + 42)) != ERROR_NONE, 30);

  test(31);
  assert(segment_get(segid2, &seg) != ERROR_NONE, 31);
  assert(region_get(asid2, regid2, &reg) != ERROR_NONE, 31);
  assert(chk_p_address(asid2, segid2, (seg->address + 42), (reg->address + 42)) != ERROR_NONE, 31);

  test(32);
  assert(chk_p_address(asid2, segid2, (seg->address + 5000), (reg->address + 5000)) == ERROR_NONE, 32);

  test(33);
  assert(segment_get(segid1, &seg) != ERROR_NONE, 33);
  assert(region_get(asid1, regid1, &reg) != ERROR_NONE, 33);
  assert(chk_p_address(asid1, segid1, (seg->address + 84), (reg->address + 84)) != ERROR_NONE, 33);

  test(34);
  assert(chk_p_address(asid1, segid1, (seg->address + 9000), (reg->address + 9000)) == ERROR_NONE, 34);

  /* La transcription des adresses physiques vers virtuelles fonctionne. */

  test(35);
  assert(chk_v_address(asid1, regid1, (reg->address + 76), (seg->address + 76)) != ERROR_NONE, 35);

  test(36);
  assert(chk_v_address(asid1, regid1, (reg->address + 9000), (seg->address + 9000)) == ERROR_NONE, 36);

  test(37);
  assert(segment_get(segid2, &seg) != ERROR_NONE, 37);
  assert(region_get(asid2, regid2, &reg) != ERROR_NONE, 37);
  assert(chk_v_address(asid2, regid2, (reg->address + 76), (seg->address + 76)) != ERROR_NONE, 37);

  test(38);
  assert(chk_v_address(asid2, regid2, (reg->address + 9000), (seg->address + 9000)) == ERROR_NONE, 38);

  test(39);
  assert(segment_get(segid3, &seg) != ERROR_NONE, 39);
  assert(region_get(asid2, regid3, &reg) != ERROR_NONE, 39);
  assert(chk_v_address(asid2, regid3, (reg->address + 76), (seg->address + 76)) != ERROR_NONE, 39);

  test(40);
  assert(chk_v_address(asid2, regid3, (reg->address + 19000), (seg->address + 19000)) == ERROR_NONE, 40);

  /* La transcription des adresses virtuelles vers physiquess fonctionne. */

  test(41);
  assert(segment_flush(asid1) != ERROR_NONE, 41);

  test(42);
  assert(segment_flush(asid1) != ERROR_NONE, 42);

  test(43);
  assert(region_flush(asid1) != ERROR_NONE, 43);

  test(44);
  assert(region_flush(asid2) != ERROR_NONE, 44);

  test(45);
  assert(as_release(asid1) != ERROR_NONE, 45);

  test(46);
  assert(as_release(asid2) != ERROR_NONE, 46);

  return ERROR_NONE;
}

#endif
