/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/as/as.c
 *
 * created       julien quintard   [tue dec 13 03:05:27 2005]
 * updated       matthieu bucchianeri   [fri jan 27 18:11:14 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the address space manager manages address spaces.
 *
 * an address space describes process' useable memory. each address space
 * is composed of two sets.
 *
 * the first describes the segments held by this address space, in other
 * words the physical memory.
 *
 * the latter describes the regions, the virtual areas which reference
 * some segments.
 *
 * a task can give its address space to another with as_give.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the address space manager builds address space objects.
 *
 * every address space object is essentially composed of two sets: a
 * set of segments which list the segments held by this address space and
 * a set of regions which describes the useable virtual address ranges.
 *
 * the student just has to write the functions to reserve, release, get etc..
 * an address space.
 *
 * note that the address space does nothing more. indeed, the segment
 * manager and the region manager will add and/or remove the segments/regions
 * to/from the address space by their own.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(as);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the address space manager variable.
 */

m_as*			as = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */

/* This function shows a precise address space displaying information on it.  */
t_error		as_show(t_asid asid)
{
  t_error	error = ERROR_NONE;
  t_segid	*seg = NULL;
  o_as		*a = NULL;
  t_iterator	i;
  t_state	s;

  if ((error = set_get(as->container, asid, (void **) &a)) != ERROR_NONE)
    AS_LEAVE(as, error);
  printf("Address Space %qd:\n", a->asid);
  printf("\t\ttask: %qd\n", a->tskid);
  printf("\t\tSegments de l'AS: ");
  set_foreach(SET_OPT_FORWARD, a->segments, &i, s)
    {
      if ((error = set_object(a->segments, i, (void **) &seg)) != ERROR_NONE)
	AS_LEAVE(as, error);
      printf("%qd, ", *seg);
    }
  printf("\n");
  AS_LEAVE(as, error);
}

/* This function dumps all the address space managed by the address space manager.  */
t_error		as_dump(void)
{
  t_error	error = ERROR_NONE;
  o_as		*a;
  t_iterator	i;
  t_state	s;

  AS_ENTER(as);
  set_foreach(SET_OPT_FORWARD, as->container, &i, s)
    {
      if ((error = set_object(as->container, i, (void **) &a)) != ERROR_NONE)
	AS_LEAVE(as, error);
      if ((error = as_show(a->asid)) != ERROR_NONE)
	AS_LEAVE(as, error);
    }
  AS_LEAVE(as, error);
}

/* This function clones an address space taking care of cloning everything necessary.  */
t_error		as_clone(t_tskid task, t_asid old, t_asid* new)
{
  t_error	error = ERROR_NONE;
  o_as		*oldas = NULL;
  t_state	s;
  t_iterator	i;

  t_segid	*oldsegid = NULL;
  t_segid	newsegid = 0;

  if ((error = set_get(as->container, old, (void **) &oldas)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if ((error = as_reserve(task, new)) != ERROR_NONE)
    AS_LEAVE(as, error);
  set_foreach(SET_OPT_FORWARD, oldas->segments, &i, s)
    {
      if ((error = set_object(oldas->segments, i, (void **) &oldsegid)) != ERROR_NONE)
	AS_LEAVE(as, error);
      if ((error = segment_clone(*new, *oldsegid, &newsegid)) != ERROR_NONE)
	AS_LEAVE(as, error);
    }
  AS_LEAVE(as, error);
}

/* This function reserves an address space object for the task task.  */
t_error		as_reserve(t_tskid task, t_asid* asid)
{
  t_error	error = ERROR_NONE;
  o_as		new;

  AS_ENTER(as);
  if ((error = id_reserve(&as->id, &new.asid)) != ERROR_NONE)
    AS_LEAVE(as, error);
  new.tskid = task;
  if ((error = set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof (t_segid), &new.segments)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if ((error = set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof (o_region), &new.regions)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if ((error = set_add(as->container, &new)) != ERROR_NONE)
    AS_LEAVE(as, error);
  *asid = new.asid;
  AS_LEAVE(as, error);
}

/* This function just releases an address space.  */
t_error		as_release(t_asid asid)
{
  t_error	error = ERROR_NONE;
  o_as		*new = NULL;

  AS_ENTER(as);
  if ((error = set_get(as->container, asid, (void **) &new)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if ((error = set_release(new->regions)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if ((error = set_release(new->segments)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if ((error = set_remove(as->container, asid)) != ERROR_NONE)
    AS_LEAVE(as, error);
  error = id_release(&as->id, asid);
  AS_LEAVE(as, error);
}

/* This function should only be used by the segment and region managers.  */
/* This function just returns the address space object corresponding to the address space  */
/* identifier.  */
t_error		as_get(t_asid asid, o_as** o)
{
  t_error	error = ERROR_NONE;

  AS_ENTER(as);
  if ((error = set_get(as->container, asid, (void **) o)) != ERROR_NONE)
    AS_LEAVE(as, error);
  AS_LEAVE(as, error);
}

/* This function initializes the address space manager.  */
t_error		as_init(void)
{
  t_error	error = ERROR_NONE;

  as = malloc(sizeof (m_as));
  AS_ENTER(as);
  STATS_RESERVE("as", &as->stats);
  if ((error = id_build(&as->id)) != ERROR_NONE)
    AS_LEAVE(as, error);
  set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof (o_as), &as->container);
  AS_LEAVE(as, error);
}

/* This function cleans the address space manager.  */
t_error		as_clean(void)
{
  t_error	error = ERROR_NONE;

  AS_ENTER(as);
  STATS_RELEASE(as->stats);
  if ((error = set_release(as->container)) != ERROR_NONE)
    AS_LEAVE(as, error);
  error = id_destroy(&as->id);
  AS_LEAVE(as, error);
}

/* This function translates a virtual address to a physical address. */
t_error		as_paddr(t_asid asid, t_regid regid, t_vaddr virtual, t_paddr* physical)
{
  t_error	error = ERROR_NONE;
  t_paddr	offset = 0;
  o_region	*reg = NULL;
  o_segment	*seg = NULL;

  AS_ENTER(as);
  if ((error = region_get(asid, regid, &reg)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if ((error = segment_get(reg->segid, &seg)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if (((offset = (virtual - reg->address)) < 0) ||
      (offset > reg->size))
    AS_LEAVE(as, ERROR_UNKNOWN);
  *physical = seg->address + reg->offset + offset;
  AS_LEAVE(as, error);
}

/* This function translates a physical address to a virtual address. */
t_error		as_vaddr(t_asid asid, t_segid segid, t_paddr physical, t_vaddr* virtual)
{
  t_error	error = ERROR_NONE;
  o_as		*aspace = NULL;
  o_region	*reg = NULL;
  o_segment	*seg = NULL;
  t_vaddr	offset = 0;
  t_regid	regid = 0;
  t_iterator	i;
  t_state	s;

  AS_ENTER(as);
  if ((error = set_get(as->container, asid, (void **) &aspace)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    AS_LEAVE(as, error);
  set_foreach(SET_OPT_FORWARD, aspace->regions, &i, s)
    {
      set_object(aspace->regions, i, (void **) &reg);
      if (reg->segid == segid)
	regid = reg->regid;
    }
  if ((error = region_get(asid, regid, &reg)) != ERROR_NONE)
    AS_LEAVE(as, error);
  if (((offset = physical - seg->address) < 0) ||
      (offset > seg->size))
    AS_LEAVE(as, ERROR_UNKNOWN);
  *virtual = reg->address + reg->offset + offset;
  AS_LEAVE(as, error);
}
