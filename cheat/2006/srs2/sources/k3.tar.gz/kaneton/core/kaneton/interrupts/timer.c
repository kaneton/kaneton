/*
** timer.c
** Login : <laroch_e@bastille.epitech.net>
** Started on  Thu Jun 15 22:39:14 2006 emeric laroche
** $Id$
*/

#include <kaneton.h>
struct t_timer	gl_timer;

t_error timer_init()
{
  return set_reserve(ll, SET_OPT_ALLOC,
		     sizeof (struct timer_node),
		     &(gl_timer.timer_l));
}


/*
 * This function find the node which time is just over the given time
 * Send back total timeout for this node
 * Send back a pointer to the timout field of the found node
 */

static t_error find_nearer_node(t_time time, t_iterator *it, t_time *time_from_start, t_time **last_timeout)
{
  *time_from_start = 0;

  
  if (set_head(gl_timer.timer_l, it) != ERROR_NONE)
    return ERROR_UNKNOWN;
  do
    {
      *last_timeout = &(((struct timer_node*)(it->u.ll.node->data))->timeout);
      *time_from_start += **last_timeout;
      if (*time_from_start > time)
	return ERROR_NONE;
      printf("we are on %qd\n",*time_from_start);
    }
  while (set_next(gl_timer.timer_l, *it, it) == ERROR_NONE);
  return INSERT_END;
}

t_error timer(t_time time, timeout_routine (*callback))
{
  struct timer_node	t;
  t_iterator		it;
  t_time		time_to_sub;
  t_time*		last_timeout;
  t_time		tmp;

  t.callback = callback;
  t.timeout = time;
  switch (find_nearer_node(time, &it, &time_to_sub, &last_timeout))
    {
    case ERROR_NONE:
      /*
       * to get the relative timout to the previous timer, we
       * sub to the total time of this timer, the total time of the
       * superior time minus the difference between this big one and 
       * the one near under.
       *
       *             |
       *             |
       *  |----------       reative start time
       *  |
       * ------------------- absolute start time
       *  ^          ^
       * first timer  second timer
       * ...ok well try to think and you will understand
       */
      t.timeout = time - (time_to_sub - *last_timeout);
      printf("adding %qd before %qd\n", time, ((struct timer_node*)it.u.ll.node->data)->timeout);
      tmp = ((struct timer_node*)it.u.ll.node->data)->timeout;
      set_insert_before(gl_timer.timer_l, it, &t);
      *last_timeout -= t.timeout;
      printf("%qd is now %qd\n",tmp, ((struct timer_node*)it.u.ll.node->data)->timeout);
      break;
    case INSERT_END:
      t.timeout = time - time_to_sub;
      printf("adding %qd after %qd (tps cumule is %qd)\n", time, *last_timeout, time_to_sub);
      set_insert_tail(gl_timer.timer_l, &t);
      break;
    case ERROR_UNKNOWN:
    default:
      printf("adding %qd first\n", t.timeout);
      set_add(gl_timer.timer_l, &t);
    }
  return ERROR_NONE;
}


/*
 * TODO : 
 * - le handler qui va calculer le nouveau temps
 * - la fonction qui check si le premier timer a attein son timout et
 * appel la bonne fonction
 * - reflechir a la supression d'un timer
 */

t_error call_first_node(void)
{
  t_iterator it;

  if (set_head(gl_timer.timer_l, &it) == ERROR_UNKNOWN)
    return ERROR_NONE;
  if (--((struct timer_node*)it.u.ll.node->data)->timeout == 0)
    {
      ((struct timer_node*)it.u.ll.node->data)->callback();
      set_delete(gl_timer.timer_l, it);
    }
/*   else */
/*     { */
/*       printf("reste %qd\n", ((struct timer_node*)it.u.ll.node->data)->timeout); */
/*     } */
  return ERROR_NONE;
}

t_error timer_handler(void)
{
  return call_first_node();
}
