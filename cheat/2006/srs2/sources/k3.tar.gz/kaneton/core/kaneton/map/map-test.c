/*
** map-test.c
** Login : <meyer_f@bastille.epita.fr>
** Started on  Tue Mar 28 19:05:56 2006 frederick meyer
** $Id$
*/

#include <klibc.h>
#include <kaneton.h>

#ifdef CONF_TEST_MAP

# define assert(_cond_, _nb_) \
	if (_cond_) {printf("Erreur au test " #_nb_ "\n"); return ERROR_UNKNOWN;}

#define test(_nb_)					\
	printf ("############### TEST " #_nb_ " ####################\n")

t_error		map_test(void)
{
  t_asid	asid1 = 0;

  t_vaddr	vaddr1 = 0;
  t_vaddr	vaddr2 = 0;
  t_vaddr	vaddr3 = 0;
  t_vaddr	vaddr4 = 0;

  test(1);
  assert(as_reserve(42, &asid1) != ERROR_NONE, 1);

  test(2);
  assert(map_reserve(asid1, REGION_OPT_MAPALL, &vaddr1, 4096, (PERM_READ | PERM_WRITE)) != ERROR_NONE, 2);

  test(3);
  assert(map_reserve(asid1, REGION_OPT_NONE, &vaddr2, 4096, (PERM_READ)) != ERROR_NONE, 3);

  test(4);
  assert(map_reserve(asid1, REGION_OPT_NONE, &vaddr3, 4096, (PERM_READ | PERM_WRITE)) != ERROR_NONE, 4);

  test(5);
  assert(map_reserve(asid1, 0, &vaddr4, 5096, (PERM_READ | PERM_WRITE)) == ERROR_NONE, 5);

  test(6);
  assert(map_release(asid1, vaddr4) == ERROR_NONE, 6);

  test(7);
  assert(map_release(asid1, vaddr1) != ERROR_NONE, 7);

  test(8);
  assert(map_release(asid1, vaddr2) != ERROR_NONE, 8);

  test(9);
  assert(map_release(asid1, vaddr3) != ERROR_NONE, 9);

  test(10);
  assert(as_release(asid1) != ERROR_NONE, 10);

  return ERROR_NONE;
}

#endif
