/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/fred/svn/kaneton/core/kaneton/map/map.c
 *
 * created       frederick meyer   [mon may 29 10:33:27 2005]
 * updated       frederick meyer   [mon may 29 10:33:27 2005]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * The map manager is used to manage memory in a simpler way.
 *
 * Indeed, dealing with segments and regions is not very easy when the end user
 * just wants to reserve some memory.
 *
 * A map is an abstract couple of two kaneton objects: a segment ans a region.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

// machdep_include(map);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the map manager variable.
 */

m_map*			map = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * ----------------------------------------------------------------------------
 */
/* Reserves a map. This function will so reserve a segment of the given size */
/* and finally perform the mapping by reserving a region. */
t_error		map_reserve(t_asid asid, t_opts opts, t_vaddr *addr,
			    t_vsize size, t_perms perms)
{
  t_error	error = ERROR_NONE;
  o_region	*reg = NULL;
  t_segid	segid = 0;
  t_regid	regid = 0;

  MAP_ENTER(map);
  if ((error = segment_reserve(asid, size, perms, &segid)) != ERROR_NONE)
    MAP_LEAVE(map, error);
  if ((error = region_reserve(asid, segid, 0, opts, 0, size, &regid)) != ERROR_NONE)
    {
      if ((error = segment_release(segid)) != ERROR_NONE)
	MAP_LEAVE(map, error);
      MAP_LEAVE(map, ERROR_UNKNOWN);
    }
  if ((error = region_get(asid, regid, &reg)) != ERROR_NONE)
    MAP_LEAVE(map, error);
  *addr = reg->address;
  MAP_LEAVE(map, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Releases a map. */
t_error		map_release(t_asid asid, t_vaddr addr)
{
  t_error	error = ERROR_NONE;
  o_region	*reg = NULL;
  o_segment	*seg = NULL;
  o_as		*as = NULL;
  t_state	s;
  t_iterator	i;

  MAP_ENTER(map);
  if ((error = as_get(asid, &as)) != ERROR_NONE)
    MAP_LEAVE(map, error);
  set_foreach(SET_OPT_FORWARD, as->regions, &i, s)
    {
      set_object(as->regions, i, (void **) &reg);
      if (reg->address == addr)
	break;
    }
  if (reg->address != addr)
    {
      error = ERROR_UNKNOWN;
      MAP_LEAVE(map, error);
    }
  if ((error = segment_get(reg->segid, &seg)) != ERROR_NONE)
    MAP_LEAVE(map, error);
  if ((error = segment_release(reg->segid)) != ERROR_NONE)
    MAP_LEAVE(map, error);
  error = region_release(asid, reg->regid);
  MAP_LEAVE(map, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Initializes the map manager. */
t_error		map_init(void)
{
  t_error	error = ERROR_NONE;

  map = malloc(sizeof (m_map));

  MAP_ENTER(map);
  STATS_RESERVE("map", &map->stats);
  error = id_build(&map->id);
  MAP_LEAVE(map, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* Cleans the map manager. */
t_error		map_clean(void)
{
  t_error	error = ERROR_NONE;

  MAP_ENTER(map);
  STATS_RELEASE(map->stats);
  error = id_destroy(&map->id);
  MAP_LEAVE(map, error);
}

/*
 * ----------------------------------------------------------------------------
 */
