/*
** timer-test.c
** Login : <laroch_e@bastille.epitech.net>
** Started on  Fri Jun 16 10:39:17 2006 emeric laroche
** $Id$
*/
#include <kaneton.h>
#ifdef CONF_TEST_TIMER



void first_print(void)
{
  printf("first\n");
}

void second_print(void)
{
  printf("second\n");
}
void third_print(void)
{
  printf("third\n");
}
void fourth_print(void)
{
  printf("fourth\n");
}


t_error timer_test(void)
{
  int i;
  extern struct t_timer  gl_timer;

  printf("insertion des timers 23 - 11 - 13 - 25\n");
  timer((t_time)23, &third_print);
  timer(11, &first_print);
  timer(13, &second_print);
  timer(25, &fourth_print);

  set_show(gl_timer.timer_l);

  for (i = 0; i < 28; i++)
    timer_handler();

  return ERROR_NONE;

}

#endif
