/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/segment/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:39:03 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the segment manager manages physical memory.
 *
 * it  is  able   to  reserve  and  release  memory   areas  (see  the
 * segment-fit.c for  allocation algorithm)  and to operated  on these
 * area: resize, split, copy, etc.
 *
 * a segment  is identified by  a 64 bits identifier  corresponding to
 * its physical  address. so  it is easy  to retrieve  this identifier
 * given the base address of a segment.
 *
 * remember  that  segments are  global:  there  is  only one  set  of
 * segments objects for  the entire kernel. the set  of segments in an
 * address space is just a set of identifiers.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have  to write the entire manager:  this file implementing
 * independent code plus  an architecture dependant file (ia32-virtual
 * or ia32-segment for example).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the init variable, filled by the bootloader, containing in this case
 * the list of segments to mark used.
 */

extern t_init*		init;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

m_segment*		segment;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * ----------------------------------------------------------------------------
 */
/* This function displays information on specified segment.  */
t_error		segment_show(t_segid segid)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;

  SEGMENT_ENTER(segment);
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    return error;
  if (seg->type == SEGMENT_TYPE_MEMORY)
    printf("Segment %qd de type: MEMORY\n", segid);
  if (seg->type == SEGMENT_TYPE_CATCH)
    printf("Segment %qd de type: CATCH\n", segid);
  printf("\t\tbase:\t0x%x\n", seg->address);
  printf("\t\tsize:\t%d\n", seg->size);
  printf("\t\tas:\t%qd\n", seg->asid);
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function displays all segments in the segment container.  */
t_error		segment_dump(void)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;
  t_iterator	i;
  t_state	s;

  SEGMENT_ENTER(segment);
  set_foreach(SET_OPT_FORWARD, segment->container, &i, s)
    {
      set_object(segment->container, i, (void **) &seg);
      segment_show(seg->segid);
    }
  SEGMENT_LEAVE(segment, error);

  return error;
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function clones a segment copying its content.  */
t_error		segment_clone(t_asid asid, t_segid old, t_segid* new)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;

  SEGMENT_ENTER(segment);
  if ((error = segment_get(old, &seg)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = segment_reserve(asid, seg->size, seg->perms, new)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  /* memcpy((void *) addr, (void *) seg->address, seg->size); */
  if ((error = segment_copy(*new, 0, old, 0, seg->size)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function injects a pre-allocated segment in the segment container.  */
/* from one address space to another.  */
t_error		segment_inject(t_asid as, o_segment* o)
{
  t_error	error = ERROR_NONE;
  o_as		*a = NULL;

  SEGMENT_ENTER(segment);
  if ((error = as_get(as, &a)) != ERROR_NONE)
    return error;
  if ((error = set_add(segment->container, o)) != ERROR_NONE)
    return error;
  if ((error = set_add(a->segments, &(o->segid))) != ERROR_NONE)
    return error;
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function gives a segment from one address space to another.  */
t_error		segment_give(t_segid segid, t_asid asid)
{
  t_error	error = ERROR_NONE;
  o_as		*tmpas = NULL;
  o_segment	*seg = NULL;

  SEGMENT_ENTER(segment);
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    return error;
  if ((error = as_get(asid, &tmpas)) != ERROR_NONE)
    return error;
  if ((error = set_add(tmpas->segments, seg)) != ERROR_NONE)
    return error;
  if ((error = as_get(seg->asid, &tmpas)) != ERROR_NONE)
    return error;
  if ((error = set_remove(tmpas->segments, segid)) != ERROR_NONE)
    return error;
  seg->asid = asid;
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function resizes a segment.  */
t_error		segment_resize(t_segid segid, t_psize size, t_segid* new)
{
  t_error	error = ERROR_NONE;
  o_segment	*news = NULL;
  o_segment	*seg = NULL;

  SEGMENT_ENTER(segment);
  if ((error = machdep_call(segment, segment_resize, segid, size, new)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if (size <= seg->size)
    {
      seg->size = size;
      *new = segid;
    }
  else
    {
      if ((error = segment_reserve(seg->asid, size, seg->perms, new)) != ERROR_NONE)
	SEGMENT_LEAVE(segment, error);
      if ((error = segment_get(*new, &news)) != ERROR_NONE)
	return error;
      if ((memcpy((void *) news->address, (void *) seg->address, seg->size)) == NULL)
	SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
/*       if ((error = segment_copy(dst, off, src, off, sz)) != ERROR_NONE) */
/* 	SEGMENT_LEAVE(segment, error); */
      if ((error = segment_release(segid)) != ERROR_NONE)
	SEGMENT_LEAVE(segment, error);
    }
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function split a segment into two segments.  */
t_error		segment_split(t_segid segid, t_psize size, t_segid* left, t_segid* right)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;
  o_as		*as = NULL;
  o_segment	new;

  SEGMENT_ENTER(segment);
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    return error;
  if ((error = as_get(seg->asid, &as)) != ERROR_NONE)
    return error;
  new = *seg;
  new.address = seg->address + size;
  new.size = seg->size - size;
  new.segid = (t_segid) new.address;
  seg->size = size;
  if ((error = set_add(segment->container, &new)) != ERROR_NONE)
    return error;
  if ((error = set_add(as->segments, &new.segid)) != ERROR_NONE)
    return error;
  *left = segid;
  *right = new.segid;
  SEGMENT_LEAVE(segment, error);
  return error;
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function merges two segments into a single one.  */
t_error		segment_coalesce(t_segid left, t_segid right, t_segid* new)
{
  t_error	error = ERROR_NONE;
  o_segment	*rightseg = NULL;
  o_segment	*leftseg = NULL;

  SEGMENT_ENTER(segment);
  if ((error = segment_get(left, &leftseg)) != ERROR_NONE)
    return error;
  if ((error = segment_get(right, &rightseg)) != ERROR_NONE)
    return error;
  if (leftseg->address < rightseg->address)
    {
      leftseg->size += rightseg->size;
      leftseg->segid = (t_segid) leftseg->address;
      segment_release(rightseg->segid);
      *new = leftseg->segid;
    }
  else
    {
      rightseg->size += leftseg->size;
      rightseg->segid = (t_segid) rightseg->address;
      segment_release(leftseg->segid);
      *new = rightseg->segid;
    }
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function reserves a segment of specified size.  */
t_error		segment_reserve(t_asid asid, t_psize size, t_perms perms, t_segid* segid)
{
  t_error	error = ERROR_NONE;
  o_as		*as = NULL;
  t_paddr	addr;

  SEGMENT_ENTER(segment);
  if ((error = machdep_call(segment, segment_reserve, asid, size, perms, segid)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = as_get(asid, &as)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = segment_fit(as, size, perms, &addr)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  *segid = addr;
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function releases a segment.  */
t_error		segment_release(t_segid s)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;
  o_as		*as = NULL;

  SEGMENT_ENTER(segment);
  if ((error = segment_get(s, &seg)) != ERROR_NONE)
    return error;
  if ((error = as_get(seg->asid, &as)) != ERROR_NONE)
    return error;
  if ((error = set_remove(as->segments, s)) != ERROR_NONE)
    return error;
  if ((error = set_remove(segment->container, s)) != ERROR_NONE)
    return error;
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function is used to force a segment to be given to an address space. catcheable  */
/* segments are reserved by the module service for architecture specific servers.  */
/* Catcheable segments are defined in the kaneton.conf file.  */
t_error		segment_catch(t_asid asid, t_segid segid)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;
  o_as		*as = NULL;

  SEGMENT_ENTER(segment);
  if ((error = as_get(asid, &as)) != ERROR_NONE)
    return error;
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    return error;
  if ((error = set_add(as->segments, seg)) != ERROR_NONE)
    return error;
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function changes permissions for a segment.  */
t_error		segment_perms(t_segid segid, t_perms perms)
{
  t_error	error = ERROR_NONE;
  o_segment*	seg = NULL;

  SEGMENT_ENTER(segment);
  if ((error = machdep_call(segment, segment_perms, segid, perms)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    return error;
  seg->perms = perms;
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function changes the type of a segment. */
t_error		segment_type(t_segid segid, t_type type)
{
  t_error	error = ERROR_NONE;
  o_segment*	seg = NULL;

  SEGMENT_ENTER(segment);
  if ((error = machdep_call(segment, segment_type, segid, type)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    return error;
  seg->type = type;
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function removes every segment that belongs to the address space specified.  */
t_error		segment_flush(t_asid as)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;
  t_iterator	it;
  t_state	s;

  SEGMENT_ENTER(segment);
  set_foreach(SET_OPT_FORWARD, segment->container, &it, s)
    {
      if ((error = set_object(segment->container, it, (void **) &seg)) != ERROR_NONE)
	return error;
      if ((error = segment_release(seg->segid)) != ERROR_NONE)
	return error;
    }
  SEGMENT_LEAVE(segment, error);

  return error;
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function gets the segment object associated to a segment identifier.  */
t_error		segment_get(t_segid segid, o_segment** o)
{
  t_error	error = ERROR_NONE;

  SEGMENT_ENTER(segment);
  error = set_get(segment->container, segid, (void **) o);
  SEGMENT_LEAVE(segment, error);

  return error;
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function initializes the segment_manager.  */
t_error		segment_init(void)
{
  t_error	error = ERROR_NONE;

  segment = malloc(sizeof (m_segment));
  STATS_RESERVE("segment", &segment->stats);
  SEGMENT_ENTER(segment);
  if ((error = id_build(&segment->id)) != ERROR_NONE)
    return error;
/*   if ((init->mem % PAGESZ) == 0) */
/*     segment->start = init->mem; */
/*   else */
/*     segment->start = (init->mem + (PAGESZ - (init->mem % PAGESZ))); */
  segment->start = (init->segments[10].address & 0xFFFFF000) +
    (INIT_PAGINGSZ * PAGESZ);
  segment->size = init->memsz;
  segment->fit = SEGMENT_FIT;
  error = set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof(o_segment), &segment->container);
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function cleans the segment manager. */
t_error		segment_clean(void)
{
  t_error	error = ERROR_NONE;

  SEGMENT_ENTER(segment);
  STATS_RELEASE(segment->stats);
  segment->start = 0;
  segment->size = 0;
  segment->fit = 0;
  if ((error = set_release(segment->container)) != ERROR_NONE)
    return error;
  error = id_destroy(&segment->id);
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function reads raw data from a segment into a buffer. */
t_error		segment_read(t_segid segid, t_paddr offs, void* buff, t_psize sz)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;
  o_region	*reg = NULL;
  t_regid	regid = 0;

  SEGMENT_ENTER(segment);
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = region_reserve(seg->asid, segid, 0, REGION_OPT_MAPALL, 0, 0, &regid)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = region_get(seg->asid, regid, &reg)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((buff = memcpy(buff, ((const void *) (reg->address + reg->offset + offs)), sz)) == NULL)
    SEGMENT_LEAVE(segment, error);
  if ((error = region_release(seg->asid, regid)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function writes data to a segment. */
t_error		segment_write(t_segid segid, t_paddr offs, const void* buff, t_psize sz)
{
  t_error	error = ERROR_NONE;
  o_segment	*seg = NULL;
  o_region	*reg = NULL;
  t_regid	regid = 0;

  SEGMENT_ENTER(segment);
  if ((error = segment_get(segid, &seg)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if (!(seg->perms & PERM_WRITE))
    {
      error = ERROR_UNKNOWN;
      SEGMENT_LEAVE(segment, error);
    }
  if ((error = region_reserve(seg->asid, segid, 0, REGION_OPT_MAPALL, 0, 0, &regid)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((error = region_get(seg->asid, regid, &reg)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  if ((memcpy(((void *) (reg->address + reg->offset + offs)), buff, sz)) == NULL)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  if ((error = region_release(seg->asid, regid)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, error);
  SEGMENT_LEAVE(segment, error);
}

/*
 * ----------------------------------------------------------------------------
 */
/* This function copies data from one segment to another. */
t_error		segment_copy(t_segid dst, t_paddr offsd, t_segid src, t_paddr offs, t_psize sz)
{
  t_error	error = ERROR_NONE;
  char		buff[PAGESZ];
  int		n = 0;
  int		i = 0;


  SEGMENT_ENTER(segment);
  n = sz / PAGESZ;
  for (i = 0; i < n; ++i)
    {
      if ((error = segment_read(src, (offs + (i * PAGESZ)), buff, PAGESZ)) != ERROR_NONE)
	SEGMENT_LEAVE(segment, error);
      if ((error = segment_write(dst, (offsd + (i * PAGESZ)), buff, PAGESZ)) != ERROR_NONE)
	SEGMENT_LEAVE(segment, error);
    }
  if (sz % PAGESZ)
    {
      if ((error = segment_read(src, (offs + (i * PAGESZ)), buff, (sz - (i * PAGESZ)))) != ERROR_NONE)
	SEGMENT_LEAVE(segment, error);
      if ((error = segment_write(dst, (offsd + (i * PAGESZ)), buff, (sz - (i * PAGESZ)))) != ERROR_NONE)
	SEGMENT_LEAVE(segment, error);
    }
  SEGMENT_LEAVE(segment, error);
}
