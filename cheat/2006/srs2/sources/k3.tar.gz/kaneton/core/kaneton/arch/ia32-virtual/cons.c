/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/cons.c
 *
 * created       julien quintard   [sat may 28 18:23:13 2005]
 * updated       matthieu bucchianeri   [tue jan 24 12:44:22 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the student has to fill in this file just to be able to print some
 * debug messages.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * the console variable.
 */

t_cons			cons;

/*
 * ---------- functions -------------------------------------------------------
 */

static void	new_line(void)
{
  if (cons.line == 24)
    {
      memcpy(cons.vga, cons.vga + 160, CONS_SIZE - 160);
      bzero(cons.vga + CONS_SIZE - 160, 160);
    }
  else
    cons.line++;
  cons.column = 0;
}

/*
 * write one char (fro printf)
 */
int		print_char_simple(char c)
{
  t_uint16	pos = 160 * cons.line + 2 * cons.column;

  switch(c)
    {
    case('\n'):
      new_line();
      return(0);
    case('\t'):
      cons.column += CONS_TAB - (cons.column % CONS_TAB);
      if (cons.column >= 80)
	new_line();
      return(0);
    }
  cons.vga[pos] = c;
  cons.vga[pos + 1] = cons.attr;
  if (cons.column == 79)
    new_line();
  else
    cons.column++;
  return 0;
}

/*
 * Update console attribute (for printf)
 */
void	update_attribute(u_int8_t attr)
{
  cons.attr = attr;
}

void	cons_clear_screen(void)
{
  int		i = 0;

  for (i = 0; i < (CONS_LINES * CONS_COLUMNS); i++)
    cons.vga[i * 2] = ' ';
}


void	init_cons(void)
{
  cons.line = 0;
  cons.column = 0;
  cons.attr = 0x07;
  cons.vga = (char*)CONS_ADDR;
  printf_init(print_char_simple, update_attribute);
}

