/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/bootloader.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:23:13 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the bootloader is to install a correct environment for
 * the kernel.
 *
 * the first thing to do is to relocate the different kaneton data structure
 * in order to build the t_init structure. this structure must contain
 * everything the kernel will need.
 *
 * for more information on the relocating, take a look to the kaneton
 * paper which describes the entire kaneton reference.
 *
 * once the init structure was built, the kernel has to be launched.
 *
 * nevertheless, the kernel needs to evolve with the protected mode and
 * paging mode activated, so the bootloader first has to install these.
 *
 * printing some messages is interesting showing the protected mode and
 * paging mode are correctly installed.
 *
 * after all, the bootloader has launch the kernel binary.
 *
 * look at the ld scripts to know where the kernel has to be loaded.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * these three variable are globals to avoid them to be lost when the
 * bootloader changes its stack.
 *
 * indeed, before jumping on the kernel a new stack is created so the local
 * variables will no longer be accessible. putting these variables in
 * globals bypass this problem.
 */

void			(*kernel)(t_init*);

/*
 * Sauvegarde de l'ancienne stack
 */ 
t_reg32			ebp;
t_reg32			esp;

/*
 * ---------- functions -------------------------------------------------------
 */


int			bootloader(t_uint32			magic,
				   multiboot_info_t*		mbi)
{
  //initialisation de ce qui est necessaire pour faire de l'affichage
  init_cons();
  clear_screen();
  print_boot("bootloader: Starting\n-> CHICHE <-\n");
  init_init(mbi);
#ifdef CONF_DEBUG
  if (CONF_DEBUG & IA32_DEBUG_INIT)
    {
      //debug_print_init();
    }
#endif

  // FIXME modification de la gdt
#ifdef CONF_DEBUG
  if (CONF_DEBUG & IA32_DEBUG_INIT)
    {
      gdt_init_gdt();
    }
#endif

  gdt_init_gdt();

  relocate_kernel(mbi);
  printf("bootstrap: Relocating\t\t\t\t[OK]\n");

  init_segments(mbi);
  printf("bootstrap: Init des segments\t\t\t[OK]\n");

  init_regions(mbi);
  printf("bootstrap: Init des regions\t\t\t[OK]\n");

  init_paging ();
  printf("bootstrap: Mise en place du mode pagine\t\t[OK]\n");

  asm(	"mov %0, %%esp\n\t"
	"mov %%esp, %%ebp\n\t"
	:
	: "r" (init->kstack + init->kstacksz - 4)
	);
  printf("bootstrap: Mise en place de la pile\t\t[OK]\n");
  
  printf("bootstrap: Saut vers le kernel\n");
  
      // prend l'adresse du debut du kernel
      // l'adresse de l'entry point se situe a l'adresse 18
      // donc en le dereferencant on tombe sur le kernel
      // on recast en void* pour que ca rentre dans notre pointeur sur
      // fonction "kernel"
  kernel = (void*)*((int*)(init->kcode + 0x18));
  // appel du kernel
  kernel(init);
  printf("bootstrap: NE DOIT PAS S'AFFICHER\n");
      
  while (1)
    ;

  return (0);
}
