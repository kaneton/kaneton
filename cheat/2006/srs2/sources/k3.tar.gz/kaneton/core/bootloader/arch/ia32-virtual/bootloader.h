/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/bootloader.h
 *
 * created       julien quintard   [fri feb 11 02:23:53 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:20:27 2006]
 */

#ifndef BOOTLOADER_H
#define BOOTLOADER_H		1

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      bootloader.c
 *      cons.c
 *      init.c
 *      paging.c
 *      pmode.c
 */

/*
 * bootloader.c
 */

int			bootloader(t_uint32			magic,
				   multiboot_info_t*		mbi);


/*
 * cons.c
 */

int		print_char_simple(char c);

void	update_attribute(u_int8_t attr);

void	init_cons(void);

void	debug_print_init(void);

void	print_char(char c, char flags);

void print_num_rec(int n);

void print_nbr(int n);

void print_hexa_rec(unsigned int n);

void print_hexa(unsigned int n);

void	print_boot(char* msg);

void	clear_screen(void);


/*
 * init.c
 */

t_paddr			alloc_page(t_psize size, t_size* octetsize);

t_psize	segments_size(void);

void	init_segment(int num, t_paddr address, t_psize size, t_perms perms);

void	init_segments(multiboot_info_t* mbi);

t_psize region_size(void);

void	init_region(int num, t_paddr address, t_psize size, t_paddr offset);

void	init_regions(multiboot_info_t* mbi);

void	init_init(multiboot_info_t* mbi);

void	create_module(module_t* mod, t_paddr start);

void	relocate_kernel(multiboot_info_t* mbi);


/*
 * paging.c
 */


/*
 * pmode.c
 */

void	gdt_init_gdt(void);


/*
 * eop
 */

#endif
