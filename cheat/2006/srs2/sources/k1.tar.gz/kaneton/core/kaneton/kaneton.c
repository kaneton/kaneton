/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:48:24 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

void	       	kaneton(t_init*				bootloader)
{
  char*	       	vga = (char*)0xB8000;
  char		txt[] = "Kaneton: Loaded!";
  int	       	i = 0;  
  int	       	j = 0;  

  vga += 24*160;
  while (txt[i] != '\0')
    {
      vga[j++] = txt[i++];
      vga[j++] = 5;
    }

  while (1)
    ;
}
