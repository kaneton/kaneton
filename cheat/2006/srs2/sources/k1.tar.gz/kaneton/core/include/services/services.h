/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/services/services.h
 *
 * created       matthieu bucchianeri   [tue jan 24 11:33:29 2006]
 * updated       matthieu bucchianeri   [tue jan 24 11:33:32 2006]
 */

#ifndef SERVICES_SERVICES_H
#define SERVICES_SERVICES_H	1

#endif
