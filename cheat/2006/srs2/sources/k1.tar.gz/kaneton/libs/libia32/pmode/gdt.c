/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/pmode/gdt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:45:19 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:57:21 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage global descriptor table.
 *
 */


/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to place here code to manage gdt. there are no
 * restrictions on prototypes, names etc.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- variables globales ----------------------------------------------
 */

extern t_init		*init;

/*
 * Variables globales
 * La GDT est un tableau d'entrees.
 */
struct s_gdt_entry	*gdt;

/*
 * GDTR contient l'adresse de base et la taille
 */
struct s_gdtr		gdtr;

/*
 * Les segments
 */
unsigned int short	gdt_kernel_code;
unsigned int short	gdt_kernel_data;
unsigned int short	gdt_user_code;
unsigned int short	gdt_user_data;


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * INITIALISATION -------------------------------------------------------------
 */
void			gdt_init_gdt (void)
{
  gdt = (struct s_gdt_entry *) (init->segments[10].address & 0xFFFFF000);
  // Initialisation de la memoire
  memset (gdt, ((sizeof (struct s_gdt_entry)) * GDT_SIZE), 0);

  // Initialisation de la structure GDTR
  gdtr.base = (int) gdt;
  gdtr.limit = (GDT_SIZE * sizeof (struct s_gdt_entry));

  // Load de GDTR
  asm ("lgdt %0\n"
       ::"m" (gdtr));

  // Ajout de 2 segments user et 2 segments kernel de 0 a 4Go
  gdt_kernel_code = gdt_add_entry (0,
				   0xfffff,
				   GDT_CODE | GDT_SEGMENT | GDT_DPL0 | GDT_PRESENT,
				   GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_kernel_data = gdt_add_entry (0,
				   0xfffff,
				   GDT_DATA | GDT_SEGMENT | GDT_DPL0 | GDT_PRESENT,
				   GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_user_code = gdt_add_entry (0,
				 0xfffff,
				 GDT_CODE | GDT_SEGMENT | GDT_DPL3 | GDT_PRESENT,
				 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_user_data = gdt_add_entry (0,
				 0xfffff,
				 GDT_DATA | GDT_SEGMENT | GDT_DPL3 | GDT_PRESENT,
				 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);

  // Passage en mode protege: CR0 = 1
  asm ("mov	%cr0,	%eax\n"
       "or	%ax,	1\n"
       "mov	%eax,	%cr0\n");
}


/*
 * AJOUT ----------------------------------------------------------------------
 */
unsigned int short	gdt_add_entry (unsigned int base,
				       unsigned int limit,
				       unsigned char TYPE_S_DPL_P,
				       unsigned char AVL_L_DB_G)
{
  struct s_gdt_entry	new;
  int			i = 0;

  new.limit = limit;
  new.base = base;
  new.base16 = (base >> 16);
  new.flags = TYPE_S_DPL_P;
  new.limit16 = (limit >> 16) | AVL_L_DB_G;
  new.base24 = (base >> 24);

  i = gdt_find_free_entry ();

  gdt[i] = new;

  return i * 8;
}


/*
 * SUPPRESSION ----------------------------------------------------------------
 */
void			gdt_del_entry (unsigned int gdt_entry)
{
  struct s_gdt_entry	zero;

  zero.base = 0;
  zero.limit = 0;
  zero.base16 = 0;
  zero.flags = 0;
  zero.limit16 = 0;
  zero.base24 = 0;

  gdt[gdt_entry] = zero;
}


/*
 * RECHERCHE ------------------------------------------------------------------
 */
int	gdt_find_free_entry (void)
{
  int	i = 1;

  for (i = 1; gdt[i].base ||
	 gdt[i].base16 ||
	 gdt[i].base24 ||
	 gdt[i].limit ||
	 gdt[i].flags ||
	 gdt[i].limit16
	 ; ++i);
  return i;
}


/*
 * ----------------------------------------------------------------------------
 */
