/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/paging.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:05 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:51:57 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage paging.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will have  to fill  this  file with  function related  to
 * paging mode in the cpu: enable, disabling etc.
 *
 * there are no  restrictions about these functions, but  keep in mind
 * that  page-directory management and  page-tables management  are to
 * place in pd.c and pt.c.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


extern t_init		*init;


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * INITIALISATION -------------------------------------------------------------
 */
void			pag_init_page (unsigned int address)
{
  void		*ptr = NULL;

  // Recup de l'adresse de debut de la PD (et pas du PD)...
  ptr = (void *) address;

  // Initialisation de la memoire
  memset (ptr, 4096, 0);
}


/*
 * MAPPING --------------------------------------------------------------------
 */
void			pag_mapping (unsigned int address,
				     unsigned short pd_flags,
				     unsigned short pt_flags)
{
  t_pt_entry	pt_entry = 0;

  pt_entry = pd_add_entry (pd_flags, address);
  pt_add_entry (pt_entry, address, pt_flags);
}


void			pag_all_mapping (void)
{
  o_segment		seg;
  unsigned int		perms = 0;
  unsigned int		i = 0;
  unsigned int		j = 0;
  unsigned short	pd_rw = 0;
  unsigned short	pd_r = 0;
  unsigned short	pt_rw = 0;
  unsigned short	pt_r = 0;
  unsigned int		segsize;

  pd_init_pd ();
  pd_rw = pd_rw | PD_PRESENT | PD_READ_WRITE | PD_SUPERVISOR;
  pd_r = pd_r | PD_PRESENT | PD_READ | PD_SUPERVISOR;
  pt_rw = pt_rw | PT_PRESENT | PT_READ_WRITE | PT_SUPERVISOR;
  pt_r = pt_r | PT_PRESENT | PT_READ | PT_SUPERVISOR;
  
  for (i = 0; i < 11; ++i)
    {
      seg = init->segments[i];
      segsize = seg.size;
      perms = seg.perms;
      if (i == 2)
	segsize = 77824;
      for (j = 0; j < segsize; j += PAGESZ)
	if (perms & 0x2)
	  pag_mapping ((seg.address + j), pd_rw, pt_rw);
	else
	  pag_mapping ((seg.address + j), pd_r, pt_r);
    }
}


void		init_paging (void)
{
  pag_all_mapping ();

  asm ("mov %0, %%cr3\n\t"
      :
      : "r" (init->segments[10].address & 0xFFFFF000));

  asm ("mov	%cr0,	%eax\n"
       "or	%eax,	0x80000000\n"
       "mov	%eax,	%cr0\n");
}


unsigned int	get_nbpages(t_psize size)
{
  unsigned int 	nbpages = 42;

  nbpages = size / PAGESZ;
  if (size % PAGESZ != 0)
    nbpages++;
  return nbpages;
}

// Allocation des pages alignees.
t_paddr			alloc_page(t_psize size)
{
  static t_paddr	start = INIT_RELOCATE;
  t_paddr		ret = start;
  int			nbpages = 42;

  nbpages = get_nbpages(size);
  start += nbpages * PAGESZ;

  printf("\tNouveau Segment: <0x%x> de taille %i soit %i page(s).\n", ret, size, nbpages);
  return ret;
}
