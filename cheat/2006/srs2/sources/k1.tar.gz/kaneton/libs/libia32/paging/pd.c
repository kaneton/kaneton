/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/pd.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:20 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:53:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page directory.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this    file   is    destinated   to    functions    dealing   with
 * page-directories. there are no restrictions about function names or
 * prototype, so feel free.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- variables globales ----------------------------------------------
 */

/*
 * Variables globales
 */
extern t_init		*init;


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * RECHERCHE ------------------------------------------------------------------
 */
unsigned int		pd_get_addr (void)
{
  return (init->segments[10].address & 0xFFFFF000);
}


/*
 * INITIALISATION -------------------------------------------------------------
 */
void			pd_init_pd (void)
{
  t_pd_entry		*pd_entry = NULL;

  // Recup de l'adresse de debut de la PD (et pas du PD)...
  pd_entry = (t_pd_entry *) pd_get_addr ();

  // Initialisation de la memoire
  memset (pd_entry, ((sizeof (t_pd_entry)) * 1024), 0);
}


/*
 * AJOUT ----------------------------------------------------------------------
 */
t_pd_entry     		pd_add_entry (unsigned short flags,
				      unsigned int address)
{
  unsigned short       	i = 0;
  unsigned int		res = 0;
  t_pd_entry		*pd_entry = NULL;
  t_pd_entry		entry = 0;

  // Recup de l'adresse de debut de la PD (et pas du PD)...
  pd_entry = (void *) pd_get_addr ();

  // Recup de l'entree
  i = (address >> 22) & 0x3FF;

  if (pd_entry[i] == 0)
    {
      //alloc d'une page
      res = alloc_page (4096);
      pt_init_pt (res);
      // referencement dans la PD
      entry = res & 0xfffff000;
      entry = entry | flags;
      pd_entry[i] = entry;
    }
  else
    res = pd_entry[i] & 0xFFFFF000;

  return res;
}


/*
 * SUPPRESSION ----------------------------------------------------------------
 */
void			pd_del_entry (int entry)
{
  t_pd_entry		*pd_entry = NULL;

  if ((entry < 0) || (entry > 1023))
    return;

  // Recup de l'adresse de debut de la PD (et pas du PD)...
  pd_entry = (void *) pd_get_addr ();

  pd_entry[entry] = 0;
}


/*
 * ----------------------------------------------------------------------------
 */
