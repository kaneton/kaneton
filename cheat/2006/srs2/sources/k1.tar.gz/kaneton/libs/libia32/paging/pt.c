/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/pt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:48 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:54:23 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page tables.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to place here everything dealing with page tables. no
 * restrictions apply on this file.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- variables globales ----------------------------------------------
 */

/*
 * Variables globales
 */


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * INITIALISATION -------------------------------------------------------------
 */
void		pt_init_pt (unsigned int address)
{
  t_pt_entry	*ptr = NULL;

  ptr = (void *) address;
  memset (ptr, (1024 * sizeof (t_pt_entry)), 0);
}


/*
 * RECHERCHE ------------------------------------------------------------------
 */


/*
 * AJOUT ----------------------------------------------------------------------
 */

void		pt_add_entry (unsigned int pt_address,
			      unsigned int address,
			      unsigned short flags)
{
  t_pt_entry	*array = NULL;
  t_pt_entry	entry = 0;
  unsigned int	i = 0;

  // recuperer PTE
  i = (address & 0x003FF000) >> 12;
 
  // remplir entry
  // addresse dans bits de poids fort 
  entry = address & 0xFFFFF000;
 
  // on assemble entry + flags
  entry = entry | flags;

  // on place l'entree dans le table
  array = (void *) pt_address;
  array[i] = entry;
} 

/*
 * Xxxxxxxxx ------------------------------------------------------------------
 */

