/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/libia32.h
 *
 * created       matthieu bucchianeri   [tue dec 20 13:58:56 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:15:42 2006]
 */

#ifndef LIBIA32_H
#define LIBIA32_H

/*
 * ---------- includes --------------------------------------------------------
 */

#include "misc/asm.h"
#include "misc/isa.h"
#include "misc/multiboot.h"
#include "misc/stdarg.h"
#include "misc/types.h"
#include "paging/paging.h"
#include "pmode/pmode.h"

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../pmode/pmode.c
 *      ../pmode/gdt.c
 *      ../pmode/ldt.c
 *      ../paging/paging.c
 *      ../paging/pd.c
 *      ../paging/pt.c
 *      ../paging/tlb.c
 *      ../interrupt/interrupt.c
 *      ../interrupt/idt.c
 */

/*
 * ../pmode/pmode.c
 */


/*
 * ../pmode/gdt.c
 */

void			gdt_activate(void);

void			gdt_init(void);


/*
 * ../pmode/ldt.c
 */


/*
 * ../paging/paging.c
 */

unsigned int	get_nbpages(t_psize size);

t_paddr			alloc_page(t_psize size);


/*
 * ../paging/pd.c
 */


/*
 * ../paging/pt.c
 */


/*
 * ../paging/tlb.c
 */


/*
 * ../interrupt/interrupt.c
 */


/*
 * ../interrupt/idt.c
 */


/*
 * eop
 */

#endif
