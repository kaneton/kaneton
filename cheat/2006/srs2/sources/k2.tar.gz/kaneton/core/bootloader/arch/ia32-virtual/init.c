/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/bootloader/arch/ia32-virtual/init.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       matthieu bucchianeri   [tue jan 17 22:24:35 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this file contains the functions intended to do the relocation.
 *
 * this file is very important because it does the most important things
 * of the bootloader: computes segments and regions, relocates data, creates
 * the init structure etc..
 *
 * the relocation is based on dynamic allocation. nevertheless, no dynamic
 * allocation is provided. the student so has to setup a very simple dynamic
 * memory allocation algorithm to be able to build the init structure.
 *
 * think about it because some components cannot have a dynamic address. there
 * are some crazy problems to resolve in this context.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * init variable, describing the initial memory layout.
 *
 * this structure will be passed to the kernel describing modules,
 * physical memory reserved by the hardware etc.. thus the kernel will
 * be able to initialise its managers: segment manager, module manager etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

t_psize	segments_size(void)
{
  // FIXME taille de TOUS les segments !
  return (sizeof (o_segment) * INIT_SEGMENTS);
}

void	init_segment(int num, t_paddr address, t_psize size, t_perms perms)
{
  init->segments[num].address = address;
  init->segments[num].size = size;
  init->segments[num].perms = perms;
}

void	init_segments(multiboot_info_t* mbi)
{
  // FIXME perms ! PERM_READ PERM_WRITE PERM_EXEC
  init_segment(0, 0, PAGESZ, 0); // page nulle 1
  init_segment(1, INIT_ISA_ADDR, INIT_ISA_SIZE, 0); // bus ISA 256
  init_segment(2, init->kcode, init->kcodesz, PERM_EXEC | PERM_READ); // Kernel 19
  init_segment(3, (t_paddr)init, sizeof(t_init), PERM_READ); // t_init 1
  init_segment(4, (t_paddr)init->modules, init->modulessz, PERM_READ); // t_modules 1
  init_segment(5, (t_paddr)init->segments, init->segmentssz, PERM_READ); // t_segments 1
  init_segment(6, (t_paddr)init->regions, init->regionssz, PERM_READ); // t_regions 1
  init_segment(7, init->kstack, init->kstacksz, PERM_READ | PERM_WRITE); // k_stack 1
  init_segment(8, init->alloc, init->allocsz, PERM_READ | PERM_WRITE); // alloc 16
  init_segment(9, init->alloc + init->allocsz,  GDT_SIZE, PERM_READ | PERM_WRITE); // gdt 1
  init_segment(10, init->alloc + init->allocsz + GDT_SIZE,  3 * PAGESZ, PERM_READ | PERM_WRITE); // pd 3
}

t_psize region_size(void)
{
  return (sizeof (o_region) * INIT_REGIONS);
}

void	init_region(int num, t_paddr address, t_psize size, t_paddr offset)
{
  init->regions[num].address = address;
  init->regions[num].size = size;
  init->regions[num].offset = offset;
}

void	init_regions(multiboot_info_t* mbi)
{
  init_region(0, INIT_ISA_ADDR, INIT_ISA_SIZE, 0); // bus ISA
  init_region(1, init->kcode, init->kcodesz, 0); // kernel
  init_region(2, (t_paddr)init, sizeof(t_init), 0); // t_init 8
  init_region(3, init->kstack, init->kstacksz, 0); // k_stack
  init_region(4, init->alloc, init->allocsz, 0); // alloc
  init_region(5, init->alloc + init->allocsz,  GDT_SIZE, 0); // gdt
  init_region(6, init->alloc + init->allocsz + GDT_SIZE,  3 * PAGESZ, 0); // pd
}

void	init_init(multiboot_info_t* mbi)
{
  print_boot("Init: struct t_init\n");
  //calcul de la taille du kernel et allocation
  t_psize kcodesz = ((module_t*)(mbi->mods_addr))->mod_end - ((module_t*)(mbi->mods_addr))->mod_start;
  t_paddr kcode = alloc_page(kcodesz);

  // on place la structure init juste apres le kernel
  init = (t_init*)alloc_page(sizeof(t_init));
  init->initsz = sizeof(t_init);
  init->init = (t_paddr)init; // ??

  init->mem = INIT_RELOCATE; //Debut de la memoire haute (2^20 en hexa)
  init->memsz = mbi->mem_upper * 1024; // stockee en KBytes

  init->kcodesz = kcodesz;
  init->kcode = kcode;

  init->modulessz = 1 * PAGESZ; // a verifier... au pif
  init->modules = (t_modules*)alloc_page(init->modulessz);
  init->modules->nmodules = mbi->mods_count - 1;

  init->nsegments = INIT_SEGMENTS;
  init->segmentssz = segments_size();
  init->segments = (o_segment*)alloc_page(init->segmentssz);

  init->nregions = INIT_REGIONS;
  init->regionssz = region_size();
  init->regions = (o_region*)alloc_page(init->regionssz);

  init->kstacksz = (INIT_KSTACKSZ); // pas sur ??
  init->kstack = alloc_page(init->kstacksz);

  // 16 pages allouees pour malloc
  init->allocsz = 16 * PAGESZ;
  init->alloc = alloc_page(init->allocsz);

  alloc_page(PAGESZ);
  alloc_page(3 * PAGESZ);


  extern t_cons	cons;
  // Addresse de la memoire video.
  memcpy(&(init->machdep.cons), &cons, sizeof cons);
  printf(" Deplacement de la memoire video\t\t[OK]\n");
}

/*
 * Relocate a module
 */
void	create_module(module_t* mod, t_paddr start)
{
  t_module*	new_module = (t_module*)start;

  printf("\tAjout du module: %s <0x%x> de taille %i\n", (char*)mod->string, start, mod->mod_end - mod->mod_start);
  memcpy(new_module->name, (void*)mod->string, strlen((char*)(mod->string)) + 1);
  memcpy(new_module + 1, (void*)mod->mod_start, mod->mod_end - mod->mod_start);
}

void	relocate_kernel(multiboot_info_t* mbi)
{
  module_t*	first_mod = (module_t*)mbi->mods_addr;
  module_t*	addr_mod;
  t_uint32	nb_mods = mbi->mods_count - 1;
  t_paddr	kernel_modules = (t_paddr)(init->modules) + 4;  

  printf("Init: Entering Relocate\n");
  // relocate the kernel (module 1)
  memcpy((void*)(init->kcode), (void*)(first_mod->mod_start), first_mod->mod_end - first_mod->mod_start);
  printf("Init: deplacement du kernel\t\t\t[OK]\n");
  // find all modules and put them in the module section
  addr_mod = first_mod + 1;
  printf("Init: Chargement des modules\n");

  while (nb_mods--)
    {
      create_module(addr_mod, kernel_modules);
      // incrementer kernel_modules et addr_mod 
      addr_mod += 1;
      kernel_modules += (t_paddr)((t_module*)kernel_modules)->name +
	strlen(((t_module*)kernel_modules)->name) + 1;
    }
}
