/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/export_kaneton/kaneton/core/bootloader/arch/ia32-virtual/pmode.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       matthieu bucchianeri   [mon jan 30 20:22:46 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the student just has to setup the protected mode in this file,
 * nothing more.
 *
 * of course, it will be better to provide some debug functions etc..
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"


/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;


/*
 * Les segments
 */
unsigned int short	gdt_kernel_code;
unsigned int short	gdt_kernel_data;
unsigned int short	gdt_user_code;
unsigned int short	gdt_user_data;


/*
 * ---------- functions -------------------------------------------------------
 */

void	gdt_init_gdt(void)
{
  gdt_init();

  // Ajout de 2 segments user et 2 segments kernel de 0 a 4Go
  gdt_kernel_code = gdt_add_entry (0,
				   0xfffff,
				   GDT_CODE | GDT_SEGMENT | GDT_DPL0 | GDT_PRESENT,
				   GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_kernel_data = gdt_add_entry (0,
				   0xfffff,
				   GDT_DATA | GDT_SEGMENT | GDT_DPL0 | GDT_PRESENT,
				   GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_user_code = gdt_add_entry (0,
				 0xfffff,
				 GDT_CODE | GDT_SEGMENT | GDT_DPL3 | GDT_PRESENT,
				 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_user_data = gdt_add_entry (0,
				 0xfffff,
				 GDT_DATA | GDT_SEGMENT | GDT_DPL3 | GDT_PRESENT,
				 GDT_AVL | GDT_L | GDT_32 | GDT_GRANULAR);
  gdt_activate();
}
