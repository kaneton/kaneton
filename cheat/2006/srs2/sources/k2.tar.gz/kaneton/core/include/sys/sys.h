/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/sys/sys.h
 *
 * created       julien quintard   [fri feb 11 02:19:44 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:34:15 2006]
 */

#ifndef SYS_SYS_H
#define SYS_SYS_H		1

/*
 * ---------- includes --------------------------------------------------------
 */

#include <sys/bpt.h>
#include <sys/elf.h>

#endif
