/*
 * licence       Kaneton licence
 *
 * project       kaneton
 *
 * file          /home/rhino/kaneton/core/kaneton/set/set_stack.c
 *
 * created       renaud voltz   [wed jan 25 17:11:05 2006]
 * updated       renaud voltz   [wed jan 25 17:11:05 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this subpart of the set manager is used to build LIFO data structures like
 * stacks.
 *
 * this is actually a front-end using the linked-list manager.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

