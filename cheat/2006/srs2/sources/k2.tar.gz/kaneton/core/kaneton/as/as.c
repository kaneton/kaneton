/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/as/as.c
 *
 * created       julien quintard   [tue dec 13 03:05:27 2005]
 * updated       matthieu bucchianeri   [fri jan 27 18:11:14 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the address space manager manages address spaces.
 *
 * an address space describes process' useable memory. each address space
 * is composed of two sets.
 *
 * the first describes the segments held by this address space, in other
 * words the physical memory.
 *
 * the latter describes the regions, the virtual areas which reference
 * some segments.
 *
 * a task can give its address space to another with as_give.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the address space manager builds address space objects.
 *
 * every address space object is essentially composed of two sets: a
 * set of segments which list the segments held by this address space and
 * a set of regions which describes the useable virtual address ranges.
 *
 * the student just has to write the functions to reserve, release, get etc..
 * an address space.
 *
 * note that the address space does nothing more. indeed, the segment
 * manager and the region manager will add and/or remove the segments/regions
 * to/from the address space by their own.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(as);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the address space manager variable.
 */

m_as*			as = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */

/* This function shows a precise address space displaying information on it.  */
t_error		as_show(t_asid asid)
{
  t_error	error = ERROR_NONE;
  o_as		*a = NULL;

  if ((error = set_get(as->container, asid, (void **) &a)) != ERROR_NONE)
    return error;
/*   printf("Address Space : %d, task : %d\n", */
/* 	 a->asid, a->tskid); */
  printf("Address Space %d:\n", a->asid);
  printf("\t\ttask: %d\n", a->tskid);
  AS_LEAVE(as, error);
}

/* This function dumps all the address space managed by the address space manager.  */
t_error		as_dump(void)
{
  t_error	error = ERROR_NONE;
  o_as		*a;
  t_iterator	i;
  t_state	s;

  AS_ENTER(as);
  set_foreach(SET_OPT_FORWARD, as->container, &i, s)
    {
      if ((error = set_object(as->container, i, (void **) &a)) != ERROR_NONE)
	return error;
      if ((error = as_show(a->asid)) != ERROR_NONE)
	return error;
    }
  AS_LEAVE(as, error);
}

/* This function clones an address space taking care of cloning everything necessary.  */
t_error		as_clone(t_tskid task, t_asid old, t_asid* new)
{
  t_error	error = ERROR_NONE;
  o_as		*oldas = NULL;
  t_state	s;
  t_iterator	i;

  t_segid	*oldsegid = NULL;
  t_segid	newsegid = 0;

  if ((error = set_get(as->container, old, (void **) &oldas)) != ERROR_NONE)
    return error;
  if ((error = as_reserve(task, new)) != ERROR_NONE)
    return error;
  set_foreach(SET_OPT_FORWARD, oldas->segments, &i, s)
    {
      if ((error = set_object(oldas->segments, i, (void **) &oldsegid)) != ERROR_NONE)
	return error;
      if ((error = segment_clone(*new, *oldsegid, &newsegid)) != ERROR_NONE)
	return error;
    }
  return error;
}

/* This function reserves an address space object for the task task.  */
t_error		as_reserve(t_tskid task, t_asid* asid)
{
  t_error	error = ERROR_NONE;
  o_as		new;

  AS_ENTER(as);
  if ((error = id_reserve(&as->id, &new.asid)) != ERROR_NONE)
    return error;
  new.tskid = task;
  if ((error = set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof (t_segid), &new.segments)) != ERROR_NONE)
    return error;
  if ((error = set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof (t_id), &new.regions)) != ERROR_NONE)
    return error;
  if ((error = set_add(as->container, &new)) != ERROR_NONE)
    return error;
  *asid = new.asid;
  AS_LEAVE(as, error);
}

/* This function just releases an address space.  */
t_error		as_release(t_asid asid)
{
  t_error	error = ERROR_NONE;
  o_as		*new = NULL;

  AS_ENTER(as);
  if ((error = set_get(as->container, asid, (void **) &new)) != ERROR_NONE)
    return error;
  if ((error = set_release(new->regions)) != ERROR_NONE)
    return error;
  if ((error = set_release(new->segments)) != ERROR_NONE)
    return error;
  if ((error = set_remove(as->container, asid)) != ERROR_NONE)
    return error;
  if ((error = id_release(&as->id, asid)) != ERROR_NONE)
    return error;
  AS_LEAVE(as, error);
}

/* This function should only be used by the segment and region managers.  */
/* This function just returns the address space ob ject corresponding to the address space  */
/* identifier.  */
t_error		as_get(t_asid asid, o_as** o)
{
  t_error	error = ERROR_NONE;

  AS_ENTER(as);
  if ((error = set_get(as->container, asid, (void **) o)) != ERROR_NONE)
    return error;
  AS_LEAVE(as, error);
}

/* This function initializes the address space manager.  */
t_error		as_init(void)
{
  t_error	error = ERROR_NONE;

  as = malloc(sizeof (m_as));
  AS_ENTER(as);
  if ((error = id_build(&as->id)) != ERROR_NONE)
    return error;
  set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof (o_as), &as->container);
  AS_LEAVE(as, error);
}

/* This function cleans the address space manager.  */
t_error		as_clean(void)
{
  t_error	error = ERROR_NONE;

  AS_ENTER(as);
  if ((error = set_release(as->container)) != ERROR_NONE)
    return error;
  if ((error = id_destroy(&as->id)) != ERROR_NONE)
    return error;
  AS_LEAVE(as, error);
}
