/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/kaneton/set/set_ll.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon dec 19 17:25:13 2005]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this subpart of the set manager is used to build linked-list
 * data structures.
 *
 * note that this data structure is in fact a doubly linked-list.
 *
 * each set of this type can be used in two ways. the first one ask the
 * set manager to allocate and copy each object to add while the second
 * way tells the set manager to simply include the objects in the set.
 *
 * moreover the option free can be used to tell the set manager to call
 * the free() function each time an object is released. this option
 * means that objects passed to the set manager was previously allocated
 * with the malloc() functions suite.
 *
 * moreover, the linked-list data structure can be used either with the
 * sort option or without.
 *
 * the datasz argument of the set_reserve() function is meaningful only in the
 * case the allocate or free options are set.
 *
 * options: SET_OPT_CONTAINER, SET_OPT_SORT, SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire linked-list data structure, nothing
 * less, nothing more.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- macros ----------------------------------------------------------
 */

#define create_node(_result_, _data_, _size_, _alloc_, _next_, _prev_)	\
do {									\
  t_set_ll_node* __t = NULL;						\
  if ((__t = malloc(sizeof (t_set_ll_node))) == NULL)			\
    {									\
      cons_msg('!', "set_ll: unable to retrieve given id\n");		\
      return ERROR_UNKNOWN;						\
    }									\
  if (_alloc_)								\
    if ((__t->data = malloc(_size_)) == NULL)				\
      {									\
        cons_msg('!', "set_ll: unable to retrieve given id\n");		\
        return ERROR_UNKNOWN;						\
      }									\
    else								\
       memcpy(__t->data, _data_, _size_);				\
  else									\
    __t->data = (_data_);						\
  __t->nxt = (_next_);							\
  __t->prv = (_prev_);							\
  (_result_) = __t;							\
} while (0)

/*
 * ---------- functions -------------------------------------------------------
 */



t_error	set_reserve_ll(t_opts opts, t_size datasz, t_setid* u)
{
  o_set*	newset = 0;

  if ((newset = malloc(sizeof (o_set))) == NULL)
    {
      cons_msg('!', "set: cannot allocatememory for the ll "
	       "structure\n");
      return (ERROR_UNKNOWN);
    }

  if (!(opts & SET_OPT_CONTAINER))
    {
      if (id_reserve(&(set->id), &(newset->setid)) != ERROR_NONE)
	{
	  cons_msg('!', "set: unable to reserver id from set id object\n");
	  free(newset);
	  return (ERROR_UNKNOWN);
	}
      else
	*u = newset->setid;
    }
  else
    {
      newset->setid = set->container;
      set->co = newset;
    }
  newset->size = datasz;
  newset->type = SET_TYPE_LL;
  newset->u.ll.opts = opts;
  newset->u.ll.datasz = datasz;
  newset->u.ll.head = NULL;
  newset->u.ll.tail = NULL;
  if (opts & SET_OPT_CONTAINER)
    return ERROR_NONE;
  else
    return set_add(set->container, newset) == ERROR_NONE;
}

t_error		set_type_ll(t_setid u)
{
  o_set*	o_u;

  SET_GET_DESCRIPTOR(u, &o_u);

  return o_u->type != SET_TYPE_LL ? ERROR_UNKNOWN : ERROR_NONE;
}

t_error set_show_ll_p(o_set* o_u)
{
  //  t_iterator	i;

  //  set_foreach(SET_OPT_FORWARD, u, &i)
  //{
      //      cons_msg('#', i.u.ll.node->data)
      // on affiche quoi la ?
  //}
  return ERROR_NONE;
}
t_error set_show_ll(t_setid u)
{
  o_set*	o_u;
  t_iterator	i;
  t_state	s;

  SET_GET_DESCRIPTOR (u, &o_u);

  set_foreach(SET_OPT_FORWARD, u, &i, s)
    {
      //      cons_msg('#', i.u.ll.node->data)
      // on affiche quoi la ?
    }
  return ERROR_NONE;
}

/*
 * This function returns an iterator on the element corresponding to
 * the identifier id.
 *
 * The iterator pointer must be allocated
 */

t_error set_locate_ll_p(o_set* o_u, t_id id, t_iterator* iterator)
{
  t_iterator	i;

  if (set_head_ll_p(o_u, &i) == ERROR_NONE)
    do {
      if (*((t_id*)i.u.ll.node->data) == id)
	{
	  iterator->u.ll.node = i.u.ll.node;
	  return ERROR_NONE;
	}
    } while(set_next_ll_p(o_u, i, &i) == ERROR_NONE);
  cons_msg('!', "set_locate_ll: unable to retrieve given id from ll set\n");
  return ERROR_UNKNOWN;
}

t_error set_locate_ll(t_setid u, t_id id, t_iterator* iterator)
{
  o_set*	o_u;

/*   printf("set_locate : ID = %ld\n"); */
  SET_GET_DESCRIPTOR (u, &o_u);
/*   printf("set_locate : descriptor foud @ : %x\n", o_u); */
  return set_locate_ll_p(o_u, id, iterator);
}

/*
 * This function returns an iterator on the first element of the set.
 */

t_error set_head_ll_p(o_set* o_u, t_iterator* iterator)
{
  if (o_u == NULL || o_u->u.ll.head == NULL)
    return ERROR_UNKNOWN;
  iterator->u.ll.node = o_u->u.ll.head;
  return ERROR_NONE;

}

t_error set_head_ll(t_setid u, t_iterator* iterator)
{
  o_set*	o_u;

  SET_GET_DESCRIPTOR (u, &o_u);
  return set_head_ll_p(o_u, iterator);
}

/*
 * This function returns an iterator on the last element of the set.
 */

t_error set_tail_ll_p(o_set* o_u, t_iterator* iterator)
{
  set_type(ll, o_u->setid);
  if (o_u == NULL || o_u->u.ll.tail == NULL)
    return ERROR_UNKNOWN;
  iterator->u.ll.node = o_u->u.ll.tail;
  return ERROR_NONE;
}

t_error set_tail_ll(t_setid u, t_iterator* iterator)
{
  o_set*	o_u;

  SET_GET_DESCRIPTOR (u, &o_u);

  if (o_u || o_u->u.ll.tail == NULL)
      return ERROR_UNKNOWN;
  iterator->u.ll.node = o_u->u.ll.tail;
  return ERROR_NONE;
}


/*
 * This function returns an iterator on the previous element of the set.
 */
t_error set_prev_ll_p(o_set* o_u, t_iterator current, t_iterator* previous)
{
  o_u = o_u;

  if (current.u.ll.node == NULL)
    return ERROR_UNKNOWN;
  previous->u.ll.node = current.u.ll.node->prv;
  if (previous->u.ll.node == NULL)
    return ERROR_UNKNOWN;
  else
    return ERROR_NONE;
}

t_error set_prev_ll(t_setid u, t_iterator current, t_iterator* previous)
{
  return set_prev_ll_p(NULL, current, previous);
}


/*
 * This function returns an iterator on the next element of the set.
 */
t_error set_next_ll_p(o_set* o_u, t_iterator current, t_iterator* next)
{
  if (current.u.ll.node == NULL)
    return ERROR_UNKNOWN;
  next->u.ll.node = current.u.ll.node->nxt;
  if (next->u.ll.node == NULL)
    return ERROR_UNKNOWN;
  else
    return ERROR_NONE;
}

t_error set_next_ll(t_setid u, t_iterator current, t_iterator* next)
{
  return set_next_ll_p(NULL, current, next);
}


/*
 * This function inserts an object at the head of the set.
 */
static t_error set_insert_head_ll_p_sort(o_set* o_u, void* data)
{
  struct s_set_ll_node*		t = o_u->u.ll.head;
  
  create_node(o_u->u.ll.head, data, o_u->size, o_u->u.ll.opts & SET_OPT_ALLOC, t, NULL);
  if (o_u->u.ll.head->nxt != NULL)
    o_u->u.ll.head->nxt->prv = o_u->u.ll.head;
  else
    o_u->u.ll.tail = o_u->u.ll.head; // si pas de next, liste vide
  return ERROR_NONE;
}

t_error set_insert_head_ll_p(o_set* o_u, void* data)
{  
  if (o_u->u.ll.opts & SET_OPT_SORT)
    return ERROR_UNKNOWN;

  return set_insert_head_ll_p_sort(o_u, data);
}

t_error set_insert_head_ll(t_setid u, void* data)
{
  o_set*			o_u = NULL;

  SET_GET_DESCRIPTOR (u, &o_u);

  return set_insert_head_ll_p(o_u, data);
}

/*
 * This function inserts an object at the tail of the set.
 */
t_error set_insert_tail_ll_p(o_set* o_u, void* data)
{
  struct s_set_ll_node*		t = o_u->u.ll.tail;

  if (o_u->u.ll.opts & SET_OPT_SORT)
    return ERROR_UNKNOWN;

  create_node(o_u->u.ll.tail, data, o_u->size, o_u->u.ll.opts & SET_OPT_ALLOC, NULL, t);
  if (t == NULL)
    o_u->u.ll.head = o_u->u.ll.tail; // si t == NULL alors liste vide
  else
    t->nxt = o_u->u.ll.tail;

  return ERROR_NONE;
}
t_error set_insert_tail_ll(t_setid u, void* data)
{
  o_set*	o_u;

  SET_GET_DESCRIPTOR (u, &o_u);

  return set_insert_tail_ll_p(o_u, data);
}

/*
 * This function inserts an object before the one specified by the iterator.
 */

t_error set_insert_before_ll_p(o_set* o_u, t_iterator iterator, void* data)
{

  if (o_u->u.ll.opts & SET_OPT_SORT)
    return ERROR_UNKNOWN;

  if (iterator.u.ll.node != NULL)
    {
      t_set_ll_node* p = iterator.u.ll.node;

      create_node(iterator.u.ll.node->prv, data, o_u->size, o_u->u.ll.opts & SET_OPT_ALLOC, iterator.u.ll.node, p);
      p->nxt = iterator.u.ll.node->prv;
      if (o_u->u.ll.head == p)
	o_u->u.ll.head = p->prv;
    }
  else
    return ERROR_UNKNOWN;
  return ERROR_NONE;
}

/*
 * This function inserts an object after the one specified by the iterator.
 */
t_error set_insert_before_ll(t_setid u, t_iterator iterator, void* data)
{
  o_set*	o_u;

  SET_GET_DESCRIPTOR (u, &o_u);
  return set_insert_before_ll_p(o_u, iterator, data);
}

static t_error set_insert_after_ll_p_sort(o_set* o_u, t_iterator iterator, void* data)
{
  if (iterator.u.ll.node != NULL)
    {
      t_set_ll_node* n = iterator.u.ll.node->nxt;

      create_node(iterator.u.ll.node->nxt, data, o_u->size, o_u->u.ll.opts & SET_OPT_ALLOC, n, iterator.u.ll.node);
      n->prv = iterator.u.ll.node->nxt;
      if (o_u->u.ll.tail == n)
	o_u->u.ll.tail = n->nxt;
    }
  else
    return ERROR_UNKNOWN;
  return ERROR_NONE;
}
/*
 * This function inserts an object after the one specified by the iterator.
 */
t_error set_insert_after_ll_p(o_set* o_u, t_iterator iterator, void* data)
{
  if (o_u->u.ll.opts & SET_OPT_SORT)
    return ERROR_UNKNOWN;

  return set_insert_after_ll_p_sort(o_u, iterator,data);
}

t_error set_insert_after_ll(t_setid u, t_iterator iterator, void* data)
{
  o_set*	o_u;

  SET_GET_DESCRIPTOR (u, &o_u);

  return set_insert_after_ll_p(o_u, iterator, data);
}

/*
 * This function adds a data ob ject in the set.
 */
t_error		set_add_ll_p(o_set* o_u, void* data)
{
  t_state	s;
  t_iterator	it;
  t_id		id = 0;

  if (o_u->u.ll.opts & SET_OPT_SORT)
    {
      if (set_head_ll_p(o_u, &it) == ERROR_NONE)
	do {
	  if (it.u.ll.node->nxt == NULL)
	    if (*((t_id*)(data)) < *((t_id*)(it.u.ll.node->data)))
	      return set_insert_head_ll_p_sort(o_u, data);
	    else
	      return set_insert_after_ll_p_sort(o_u, it, data);
	  else
	    {
	      if (*((t_id*)(data)) < *((t_id*)(it.u.ll.node->nxt->data)))
		break;
	    }
	  
	} while (set_next_ll_p(o_u, it, &it));
      else
	{
	  return set_insert_head_ll_p_sort(o_u, data);
	}
      if (it.u.ll.node == NULL)
	return ERROR_UNKNOWN;
      else
	return set_insert_after_ll_p_sort(o_u, it, data);
      return ERROR_UNKNOWN;
    }
  else
    return set_insert_head_ll_p_sort(o_u, data);

}
t_error set_add_ll(t_setid u, void* data)
{
  return set_insert_head_ll(u, data);
}


/*
 * This function removes an object identified by id from the set u.
 */

t_error set_remove_ll_p(o_set* o_u, t_id id)
{
 t_iterator	i;

 if (set_head_ll_p(o_u, &i) == ERROR_NONE)
   do {
     if (*((t_id*)i.u.ll.node->data) == id)
       return set_delete_ll_p(o_u, i);
   } while (set_next_ll_p(o_u, i, &i));
 return ERROR_UNKNOWN;
}

t_error set_remove_ll(t_setid u, t_id id)
{
  o_set*	o_u;

  SET_GET_DESCRIPTOR (u, &o_u);

  return set_remove_ll_p(o_u, id);
}


/*
 * Internal function wich take a pointer on the set insted of an id
 * CAREFULL: the iterator is invalid after deleting the element
 */
t_error set_delete_ll_p(o_set* o_u, t_iterator iterator)
{

  if (!iterator.u.ll.node)
    return ERROR_UNKNOWN;
  if (iterator.u.ll.node->nxt)
    iterator.u.ll.node->nxt->prv = iterator.u.ll.node->prv;
  if (iterator.u.ll.node->prv)
    iterator.u.ll.node->prv->nxt = iterator.u.ll.node->nxt;
  if (o_u->u.ll.head == iterator.u.ll.node)
    o_u->u.ll.head = o_u->u.ll.head->nxt;
  if (o_u->u.ll.tail == iterator.u.ll.node)
    o_u->u.ll.tail = o_u->u.ll.tail->prv;
  if (o_u->u.ll.opts & (SET_OPT_FREE | SET_OPT_ALLOC))
    free (iterator.u.ll.node->data);
  free(iterator.u.ll.node);
  return ERROR_NONE;
}

/*
 * This function deletes the object corresponding to the iterator.
 */

t_error set_delete_ll(t_setid u, t_iterator iterator)
{
  o_set*        o_u;

  SET_GET_DESCRIPTOR (u, &o_u);
  return set_delete_ll_p(o_u, iterator);
}

/*
 * This function removes every object stored in the set.
 */

t_error set_flush_ll_p(o_set* o_u)
{
  struct s_set_ll_node* crt;
  struct s_set_ll_node* tmp;

  crt = o_u->u.ll.head;
  while (crt != NULL)
    {
      tmp = crt;
      crt = crt->nxt;
      if (o_u->u.ll.opts & (SET_OPT_FREE | SET_OPT_ALLOC))
	free(tmp->data);
      free(tmp);
    }
  o_u->u.ll.head = NULL;
  o_u->u.ll.tail = NULL;
  return ERROR_NONE;
}

t_error set_flush_ll(t_setid u)
{
  o_set*        o_u;

  SET_GET_DESCRIPTOR (u, &o_u);
  return set_flush_ll_p(o_u);
}

/*
 * This function removes the next object of a FIFO or LIFO structure.
 */
t_error set_pop_ll_p(o_set* o_u)
{
  return ERROR_UNKNOWN;
}
t_error set_pop_ll(t_setid u)
{
  return ERROR_UNKNOWN;
}

/*
 * This function returns the next object of a FIFO or LIFO structure without deleting
 * it.
 */
t_error set_pick_ll_p(o_set* o_u, void** data)
{
  return ERROR_UNKNOWN;
}
t_error set_pick_ll(t_setid u, void** data)
{
  return ERROR_UNKNOWN;
}
/*
 * This function releases a set.
 */

t_error set_release_ll_p(o_set* o_u)
{
  t_error e;

  if ((e = set_flush_ll_p(o_u)) != ERROR_NONE)
    return e;
  if ((e = id_release(&(set->id), o_u->setid)) != ERROR_NONE)
    return e;
  return set_remove(set->container, o_u->setid);

}

t_error set_release_ll(t_setid u)
{
  t_error e;

  if ((e = set_flush(u)) != ERROR_NONE)
    return e;
  if ((e = id_release(&(set->id), u)) != ERROR_NONE)
    return e;
  return set_remove(set->container, u);
}


/*
 * this function returns the data object from the given iterator
 */

t_error set_object_ll_p(o_set* o_u, t_iterator i, void** data)
{
  if (!(i.u.ll.node && i.u.ll.node->data))
    return ERROR_UNKNOWN;

  *data = i.u.ll.node->data;
  return ERROR_NONE;

}

t_error set_object_ll(t_setid u, t_iterator i, void** data)
{
  if (!(i.u.ll.node && i.u.ll.node->data))
    return ERROR_UNKNOWN;

  *data = i.u.ll.node->data;
  return ERROR_NONE;

}
