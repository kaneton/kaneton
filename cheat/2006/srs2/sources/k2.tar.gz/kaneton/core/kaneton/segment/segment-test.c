/*
** set-test.c
** Login : <meyer_f@bastille.epita.fr>
** Started on  Tue Mar 28 19:05:56 2006 frederick meyer
** $Id$
*/

#include <klibc.h>
#include <kaneton.h>

#ifdef CONF_TEST_SEGMENT

# define assert(_cond_, _nb_) \
	if (_cond_) {printf("Erreur au test " #_nb_ "\n"); return ERROR_UNKNOWN;}

#define test(_nb_)					\
	printf ("############### TEST " #_nb_ " ####################\n")

t_error	segment_test(void)
{
  t_segid	segid1 = 0;
  t_segid	segid2 = 0;
  t_segid	segid3 = 0;
  t_segid	segid4 = 0;
  t_asid	asid1 = 0;
  t_asid	asid2 = 0;

  test(1);
  assert(as_reserve(0, &asid1) != ERROR_NONE, 1);

  test(2);
  assert(as_reserve(1, &asid2) != ERROR_NONE, 2);

  test(3);
  assert(segment_reserve(asid1, 21, 0, &segid1) != ERROR_NONE, 3);

  test(4);
  assert(segment_reserve(asid1, 42, 0, &segid2) != ERROR_NONE, 4);

  test(5);
  assert(segment_reserve(asid1, 84, 0, &segid3) != ERROR_NONE, 5);

  test(6);
  assert(segment_show(segid1) != ERROR_NONE, 6);

  test(7);
  assert(segment_dump() != ERROR_NONE, 7);

  test(8);
  assert(segment_coalesce(segid1, segid2, &segid4) != ERROR_NONE, 8);

  /* segid3 == 84 */
  /* segid4 == 63 */

  test(9);
  assert(segment_split(segid4, 21, &segid1, &segid2) != ERROR_NONE, 9);

  /* segid1 == 21 */
  /* segid2 == 42 */
  /* segid3 == 84 */

  test(10);
  assert(segment_clone(asid2, segid1, &segid4) != ERROR_NONE, 10);

  /* segid1 == 21 dans l'as 0 */
  /* segid2 == 42 dans l'as 0 */
  /* segid3 == 84 dans l'as 0 */
  /* segid4 == 21 dans l'as 1 */

  test(11);
  assert(segment_give(segid1, asid2) != ERROR_NONE, 11);

  test(12);
  assert(segment_give(segid3, asid2) != ERROR_NONE, 12);

  /* segid1 == 21 dans l'as 1 */
  /* segid2 == 42 dans l'as 0 */
  /* segid3 == 84 dans l'as 1 */
  /* segid4 == 21 dans l'as 1 */

  test(13);
  assert(segment_resize(segid4, 42, &segid4) != ERROR_NONE, 13);

  /* segid1 == 21 dans l'as 1 */
  /* segid2 == 42 dans l'as 0 */
  /* segid3 == 84 dans l'as 1 */
  /* segid4 == 42 dans l'as 1 */

  test(14);
  assert(segment_type(segid4, SEGMENT_TYPE_CATCH) != ERROR_NONE, 14);

  test(15);
  assert(segment_catch(asid2, segid4) != ERROR_NONE, 15);

  test(16);
  assert(segment_release(segid2) != ERROR_NONE, 16);

  test(17);
  assert(segment_dump() != ERROR_NONE, 17);

  test(18);
  assert(segment_release(segid3) != ERROR_NONE, 18);

/*   test(19); */
/*   assert(segment_release(segid3) == ERROR_NONE, 19); */

  test(20);
  assert(segment_flush(asid1) != ERROR_NONE, 20);

  test(21);
  assert(segment_flush(asid2) != ERROR_NONE, 21);

  test(22);
  assert(segment_dump() != ERROR_NONE, 22);

  return ERROR_NONE;
}

#endif
