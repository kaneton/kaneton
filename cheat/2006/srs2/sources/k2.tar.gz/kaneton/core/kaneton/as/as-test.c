/*
** set-test.c
** Login : <meyer_f@bastille.epita.fr>
** Started on  Tue Mar 28 19:05:56 2006 frederick meyer
** $Id$
*/

#include <klibc.h>
#include <kaneton.h>

#ifdef CONF_TEST_AS

# define assert(_cond_, _nb_) \
	if (_cond_) {printf("Erreur au test " #_nb_ "\n"); return ERROR_UNKNOWN;}

#define test(_nb_)					\
	printf ("############### TEST " #_nb_ " ####################\n")

t_error	as_test(void)
{
  t_asid	asid1 = 42;
  t_asid	asid2 = 42;
  t_asid	asid3 = 42;
  t_asid	asid4 = 42;
  t_asid	asid5 = 42;

  test(1);
  assert(as_reserve(0, &asid1) != ERROR_NONE, 1);

  test(2);
  assert(as_reserve(0, &asid2) != ERROR_NONE, 2);

  test(3);
  assert(as_reserve(0, &asid3) != ERROR_NONE, 3);

  test(4);
  assert(as_show(asid3) != ERROR_NONE, 4);

  test(5);
  assert(as_dump() != ERROR_NONE, 5);

  test(6);
  assert(as_clone(1, asid1, &asid4) != ERROR_NONE, 6);

  test(7);
  assert(as_clone(1, asid4, &asid5) != ERROR_NONE, 7);

  test(8);
  assert(as_show(asid1) != ERROR_NONE, 8);

  test(9);
  assert(as_dump() != ERROR_NONE, 9);

  test(10);
  assert(as_release(asid1) != ERROR_NONE, 10);

  test(11);
  assert(as_release(asid3) != ERROR_NONE, 11);

  test(12);
  assert(as_release(asid4) != ERROR_NONE, 12);

  test(13);
  assert(as_dump() != ERROR_NONE, 13);

  test(14);
  assert(as_release(asid2) != ERROR_NONE, 14);

  test(15);
  assert(as_release(asid2) == ERROR_NONE, 15);

  test(16);
  assert(as_release(asid5) != ERROR_NONE, 16);

  test(17);
  assert(as_dump() != ERROR_NONE, 17);

  return ERROR_NONE;
}

#endif
