/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/set/set_array.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 24 19:50:54 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  subpart  of the  set  manager is  used  to  build array  data
 * structures.
 *
 * there  are two  way  to use  the  arrays :  with  pointers or  with
 * objects.    the  first   method   is  the   default  one   (without
 * SET_OPT_ALLOC) : it only  stores pointers refering to objects.  The
 * second method (used with  SET_OPT_ALLOC) makes copies of objects in
 * the set,  using memcpy. with  SET_OPT_FREE, objects are  freed when
 * they   are  removed   from  the   array  or   when  the   array  is
 * flushed/released.
 *
 * the option ORGANISE is used to keep the array as small as possible,
 * but  some operation  requires to  shift entire  parts of  the array
 * (loss of performances).
 *
 * when an array set is cloned, data are reorganised in. it means than
 * when a  clone operation occurs,  the array is reduced  clearing the
 * empty/unused places.
 *
 * options:    SET_OPT_CONTAINER,    SET_OPT_SORT,   SET_OPT_ORGANISE,
 * SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire array data structure.
 *
 * this data structure is very useful to contain very little objects like
 * identifiers.
 *
 * the address space objects, the task objects etc.. use it widely.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * This function just returns an error if the set corresponding to u
 * is not of the type t_setid
 * FIXED
 */
t_error		set_type_array(t_setid u)
{
  SET_ENTER(set);
  o_set*	o_u;

  SET_GET_DESCRIPTOR(u, &o_u);

  if (o_u->type != SET_TYPE_ARRAY)
    {
      cons_msg('#', "pb de type !\n");
      return ERROR_UNKNOWN;
    }
/*   printf("type = array\n"); */
  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function displays an entire set.
 * FIXME affichage du tableau
 */
t_error		set_show_array(t_setid u)
{
  SET_ENTER(set);
  o_set*	o_u;
  t_iterator	iterator;
  t_state	s;

  SET_GET_DESCRIPTOR (u, &o_u);

/*   cons_msg('#', "Show Array: ", o_u->setid, " \n"); */
  set_foreach(SET_OPT_FORWARD, u, &iterator, s)
    {
      if (o_u->u.array.array[iterator.u.array.i] != NULL)
	printf("array[%i]\n", iterator.u.array.i);
    }

  SET_LEAVE(set, ERROR_NONE);
}


/*
 * This function returns an iterator on the first element of the set.
 * FIXED
 */
t_error		set_head_array(t_setid u, t_iterator* iterator)
{
  o_set*	o_u;
 
  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

/*   printf("set_head size=%d\n", o_u->size); */
  if (o_u->size == 0)
    {
      /* le tableau est vide */
      iterator->u.array.i = 0;
      SET_LEAVE(set, ERROR_UNKNOWN);
    }
  if (iterator == NULL)
    {
      printf("set_head: iterator null\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }
  else
    iterator->u.array.i = 0;

  do
    {
      if (o_u->u.array.array[iterator->u.array.i] != NULL)
	{
	  /* Elt non null trouve => on retourne l iterateur */
	  printf("set_head_array trouve [%i]\n", iterator->u.array.i);
	  SET_LEAVE(set, ERROR_NONE);
	}
      iterator->u.array.i++;
    }
  while (o_u->u.array.arraysz > iterator->u.array.i);

  /* On a rien trouve */
  printf("set_head_array pas trouve\n");
  SET_LEAVE(set, ERROR_UNKNOWN);
}

/*
 * This function returns an iterator on the last element of the set.
 * FIXED
 */
t_error		set_tail_array(t_setid u, t_iterator* iterator)
{
  o_set*	o_u;
  unsigned int  i = 0;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

  if (o_u->size == 0)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (!(o_u->u.array.opts & SET_OPT_ORGANISE))
    {
      for (i = o_u->size; i > 0;)
	if (o_u->u.array.array[--i] != NULL)
	  {
	    /* Dernier elt trouve */
	    iterator->u.array.i = i;
	    SET_LEAVE(set, ERROR_NONE);
	  }
    }
  iterator->u.array.i = o_u->size - 1;
  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function returns an iterator on the previous element of the set.
 * FIXED
 */
t_error set_prev_array(t_setid u, t_iterator current, t_iterator* previous)
{
  o_set*	o_u;
  unsigned int  i = 0;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

/*   printf("next_array: %d %d\n", current.u.array.i, o_u->size); */
  /* erreurs */
  if (current.u.array.i == 0)
    return ERROR_UNKNOWN;
  if (current.u.array.i >= o_u->size)
    return ERROR_UNKNOWN;
  i = current.u.array.i;
  while (i > 0)
    {
      if (o_u->u.array.array[i - 1] != NULL)
	{
	  previous->u.array.i = i - 1;
	  SET_LEAVE(set, ERROR_NONE);
	}
      i--;
    }
  SET_LEAVE(set, ERROR_UNKNOWN);
}

/*
 * This function returns an iterator on the next element of the set.
 * FIXED
 */
t_error set_next_array(t_setid u, t_iterator current, t_iterator* next)
{
  unsigned int  i = 0;
  o_set*	o_u;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

  /* si on est deja a la fin du tableau => erreur */
/*   printf("next_array: %d %d\n", current.u.array.i, o_u->size); */
  if (current.u.array.i >= o_u->size)
    return ERROR_UNKNOWN;
  if (current.u.array.i == o_u->size - 1)
    return ERROR_UNKNOWN;

  i = current.u.array.i + 1;
  while (i < o_u->size)
    {
      if (o_u->u.array.array[i] != NULL)
	{
	  /* trouve */
	  next->u.array.i = i;
	  SET_LEAVE(set, ERROR_NONE);
	}
      i++;
    }
  /* pas trouve */
  SET_LEAVE(set, ERROR_UNKNOWN);
}

/*
 * This function inserts an object at the head of the set.
 */
t_error set_insert_head_array(t_setid u, void* data)
{
  t_iterator	iterator;

  SET_ENTER(set);
  set_head_array(u, &iterator);
  SET_LEAVE(set, set_insert_before_array(u, iterator, data));
}

/*
 * This function inserts an object at the tail of the set.
 */
t_error set_insert_tail_array(t_setid u, void* data)
{
  t_iterator		iterator;

  SET_ENTER(set);
  set_tail_array(u, &iterator);
  SET_LEAVE(set, set_insert_after_array(u, iterator, data));
}

/*
 * This function inserts an object before the one specified by the iterator.
 */
t_error		set_insert_before_array(t_setid u, t_iterator iterator, void* data)
{
  t_setsz		i, j;
  o_set			*o_u;
  void			*newdata;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

  /* Erreurs */
  if (o_u->size != 0 && iterator.u.array.i >= o_u->size)
    SET_LEAVE(set, ERROR_UNKNOWN);

/*   printf("insert_array_before: adding %s\n", data); */
  i = iterator.u.array.i;
  if (i > 0 && o_u->u.array.array[i - 1] == NULL)
    i--; // i - 1 est dispo pour l insertion
  else
    {
      if (o_u->size == o_u->u.array.arraysz)
	{
	  /* on agrandit le tableau */
	  o_u->u.array.array = realloc(o_u->u.array.array, o_u->u.array.arraysz + o_u->u.array.initsz);
	  memset(o_u->u.array.array + (o_u->size * sizeof (void *)), 0, o_u->u.array.initsz);
	  o_u->u.array.arraysz += o_u->u.array.initsz;
	}
      /* on decale */
      for (j = o_u->u.array.arraysz; j >= iterator.u.array.i; j--)
	{
	  o_u->u.array.array[j] = o_u->u.array.array[j - 1];
	}
    }
  
  if (o_u->u.array.opts & SET_OPT_ALLOC)
    {
      /* malloc et memcpy */
      if ((newdata = malloc(o_u->u.array.datasz)) == NULL)
	SET_LEAVE(set, ERROR_UNKNOWN);
      memcpy(newdata, data, o_u->u.array.datasz);
      o_u->u.array.array[iterator.u.array.i] = newdata;
    }
  else /* on utilise le pointeur */
    o_u->u.array.array[iterator.u.array.i] = data;
  o_u->size++;
  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function inserts an ob ject after the one specified by the iterator.
 */
t_error set_insert_after_array(t_setid u, t_iterator iterator, void* data)
{
  o_set			*o_u;
  unsigned int		j;
  void			*newdata;
  t_iterator		it;

  /* printf("entering insert after: %d %d\n", iterator.u.array.i, o_u->size); */

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

  /* erreurs */
  if (o_u->size != 0 && iterator.u.array.i >= o_u->size)
    SET_LEAVE(set, ERROR_UNKNOWN);

  /* Recherche d espace dispo apres l iterateur */
  if (iterator.u.array.i + 1 <= o_u->size && o_u->u.array.array[iterator.u.array.i + 1] == NULL)
    iterator.u.array.i++; 
  else
    {
      if (o_u->size == o_u->u.array.arraysz)
	{ /* Besoin de reallouer le tableau */
	  o_u->u.array.array = realloc(o_u->u.array.array, o_u->u.array.arraysz + o_u->u.array.initsz);
	  memset(o_u->u.array.array + (o_u->u.array.arraysz * sizeof (void *)), 0, o_u->u.array.initsz);
	  o_u->u.array.arraysz += o_u->u.array.initsz;
	}
      /* On decale */
      for (j = o_u->u.array.arraysz - 1; j >= iterator.u.array.i; j--)
	{
	  o_u->u.array.array[j] = o_u->u.array.array[j - 1];
	}
      if (set_head_array(u, &it) != ERROR_UNKNOWN)
	iterator.u.array.i++;
    }
  if (o_u->u.array.opts & SET_OPT_ALLOC)
   {
     if ((newdata = malloc(o_u->u.array.datasz)) == NULL)
       SET_LEAVE(set, ERROR_UNKNOWN);
      memcpy(newdata, data, o_u->u.array.datasz);
      o_u->u.array.array[iterator.u.array.i] = newdata;
   }
  else
    o_u->u.array.array[iterator.u.array.i] = data;
  o_u->size++;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function adds a data object in the set.
 */
t_error set_add_array(t_setid u, void* data)
{
  o_set*	o_u;
  t_iterator	iterator;
  t_state	state;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

  /* on verif si ya assez d espace, si non on realloc, ensuite on decale et on insere */
  if (o_u->size >= o_u->u.array.arraysz)
    {
      o_u->u.array.array = realloc(o_u->u.array.array, o_u->u.array.arraysz + o_u->u.array.initsz);
    }
  set_foreach(SET_OPT_FORWARD, u, &iterator, state)
    {
      if (o_u->u.array.array[iterator.u.array.i] == NULL)
	{
	  if (o_u->u.array.opts & SET_OPT_ALLOC)
	    {
	      /* on malloc et on memcopy */
	      o_u->u.array.array[iterator.u.array.i] = malloc(o_u->u.array.datasz);
	      memcpy(o_u->u.array.array[iterator.u.array.i], data, sizeof(data));
	    }
	  else
	    {
	      /* on utilise le pointeur sur data */
	      o_u->u.array.array[iterator.u.array.i] = data;
	    }
	  o_u->u.array.arraysz += 1;
	  SET_LEAVE(set, ERROR_NONE);
	}
    }
  /* a pas pu inserer l element .. */
  SET_LEAVE(set, ERROR_UNKNOWN);
}

/*
 * This function removes an object identified by id from the set u.
 */
t_error set_remove_array(t_setid u, t_id id)
{
  o_set*	o_u;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);


  //FIXME
  if (o_u->u.array.opts & SET_OPT_FREE)
    {
      /* On free les Objs */
      free(o_u->u.array.array);
      o_u->u.array.array = NULL;
      /*set_foreach() free ..*/
      ;
    }
  else
    {
      /* On free pas les Objs */
      o_u->u.array.array = NULL;
    }

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function deletes the object corresponding to the iterator.
 * FIXED?
 */
t_error set_delete_array(t_setid u, t_iterator iterator)
{
  o_set*	o_u;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

  /* Gestion des erreurs */
  if (o_u->u.array.arraysz <= 0)
    return ERROR_UNKNOWN;

  if (o_u->u.array.opts & SET_OPT_FREE)
    {
      /* On free les Objs */
      free(o_u->u.array.array[iterator.u.array.i]);
    }
  else
    {
      /* On free pas les Objs */
      ;
    }
  o_u->u.array.array[iterator.u.array.i] = NULL;
  /* on ne decremente pas car la case est toujours presente */
  /*   o_u->u.array.arraysz--; */
  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function removes every object stored in the set.
 * FIXED?
 */
t_error set_flush_array(t_setid u)
{
  o_set         *o_u = NULL;
  t_iterator    iterator;
  t_state	state;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

  iterator.u.ll.node = NULL;

  set_foreach(SET_OPT_FORWARD, u, &iterator, state)
    {
      if (set_delete_ll(u, iterator) != ERROR_NONE)
        {
          cons_msg('!', "set_flush_array: error in set_delete\n");
          SET_LEAVE(set, ERROR_UNKNOWN);
        }
    }
  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function returns an iterator on the element corresponding to the identifier id.
 * FIXED?
 */
t_error		set_locate_array(t_setid u, t_id id, t_iterator* iterator)
{
  o_set*	o_u;
  unsigned int	i = 0;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);
  if (iterator == NULL)
    return ERROR_UNKNOWN;

  for (i = 0; i < o_u->u.array.arraysz; i++)
    {
      if (o_u->u.array.array[i] != NULL &&
          *((t_id *)o_u->u.array.array[i]) == id)
        {
          iterator->u.array.i = i;
          SET_LEAVE(set , ERROR_NONE);
        }
    }
  /* id pas trouve */
  SET_LEAVE(set, ERROR_UNKNOWN);
}

/*
 * This function returns the data object corresponding to the iterator.
 * FIXED?
 */
t_error set_object_array(t_setid u, t_iterator iterator, void** data)
{
  o_set*	o_u;

  SET_ENTER(set);
  SET_GET_DESCRIPTOR (u, &o_u);

  /* Gestion des erreurs */
  if (iterator.u.array.i >= o_u->u.array.arraysz)
    return ERROR_UNKNOWN;

  *data = o_u->u.array.array[iterator.u.array.i];

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * This function adds an ob ject to a FIFO or LIFO structure.
 * FIXED
 */
t_error set_push_array(t_setid u, void* data)
{
  /* Nothing to do here */
  return ERROR_NOT_AVAILABLE;
}

/*
 * This function removes the next ob ject of a FIFO or LIFO structure.
 * FIXED
 */
t_error set_pop_array(t_setid u)
{
  /* Nothing to do here */
  return ERROR_NOT_AVAILABLE;
}

/*
 * This function returns the next ob ject of a FIFO or LIFO structure without deleting
 * it.
 * FIXED
 */
t_error set_pick_array(t_setid u, void** data)
{
  /* Nothing to do here */
  return ERROR_NOT_AVAILABLE;
}


/*
 * This function releases a set.
 * The two last functions are described more specificaly since they have different prototypes.
 * FIXED
 */
t_error set_release_array(t_setid u)
{
  SET_ENTER(set);
  set_destroy(u);
  SET_LEAVE(set, ERROR_NONE);
}


/*
 * This function reserves an array set with options opts. This set will contain ob jects
 * of datasz size and will initialy be composed of initsz unused elements.
 * FIXME init initz elts of datasz ?
 */
t_error		set_reserve_array(t_opts	opts,
				  t_setsz	initsz,
				  t_size	datasz,
				  t_setid*	u)
{
  o_set*	newset = NULL;

  if ((newset = malloc(sizeof (o_set))) == NULL)
    {
      cons_msg('!', "set: cannot allocate memory for the array struct\n");
      return (ERROR_UNKNOWN);
    }

  if (id_reserve(&(set->id), &(newset->setid)) != ERROR_NONE)
    {
      cons_msg('!', "set: unable to reserve from set_id object\n");
      return (ERROR_UNKNOWN);
    }

  *u = newset->setid;
  newset->size = 0;
  newset->type = SET_TYPE_ARRAY;
  newset->u.array.opts = opts;
  newset->u.array.datasz = datasz;
  newset->u.array.initsz = initsz;
  newset->u.array.arraysz = initsz;
  /* FIXME pas sur du malloc .. */
  if ((newset->u.array.array = malloc(newset->u.array.initsz * sizeof (void *))) == NULL)
    {
      cons_msg('!', "set: cannot allocate memory for the array struct\n");
      return (ERROR_UNKNOWN);
    }

  if (opts & SET_OPT_CONTAINER)
    return ERROR_NONE;
  else
      return set_insert_head(set->container, newset) == ERROR_NONE;
}

