/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:48:24 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

void	       	kaneton(t_init*				bootloader)
{
  gdt_reload();
  /* reinit de la console */
  init_cons();
  cons_clear_screen();
  cons_msg('+', "Kaneton Loaddddddddddddddddded in chiche\n\n");

  /* init malloc */
  alloc_init(bootloader->alloc, bootloader->allocsz, FIT_FIRST);

  /* init id manager */
  id_init();
  cons_msg('+', "Initialisation\tID\t\t\t[OK]\n");

  /* init du set manager */
  set_init();
  cons_msg('+', "Initialisation\tSet\t\t\t[OK]\n");
#ifdef CONF_TEST_SET
  set_test(1);
/*   set_test(2); */
#endif

  /* init de l'as manager */
  as_init();
  cons_msg('+', "Initialisation\tAs\t\t\t[OK]\n");

  /* init du segment manager */
  segment_init();
  cons_msg('+', "Initialisation\tSegment\t\t\t[OK]\n");

#ifdef CONF_TEST_SEGMENT
  segment_test();
#endif
#ifdef CONF_TEST_AS
  as_test();
#endif

  cons_msg('+', "Initialisation des managers\t\t[OK]\n");

  id_clean();
  cons_msg('+', "Kaneton End\t\t\t\t[OK]\n");
  while (1)
    ;
}
