/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/segment/segment-fit.c
 *
 * created       matthieu bucchianeri   [tue jan 10 01:03:46 2006]
 * updated       matthieu bucchianeri   [tue jan 31 00:20:33 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file implements simple  fitting algorithms for physical memory
 * management.
 *
 * you can define which algorithm to use with the macro SEGMENT_FIT.
 *
 *  - FIT_FIRST: first fit algorithm - the first large enough space is taken
 *  - FIT_BEST: best fit algorithm - the smaller space is taken
 *  - ...
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  have  to develop  at  least  the  first-fit algorithm  to
 * allocate physical memory.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

extern m_segment*	segment;

/*
 * ---------- functions -------------------------------------------------------
 */

static o_segment	segment_new(t_asid asid, t_paddr addr, t_psize size, t_perms perms)
{
  o_segment	new;

  new.segid = (t_segid) addr;
  new.asid = asid;
  new.type = SEGMENT_TYPE_MEMORY;
  new.address = addr;
  new.size = size;
  new.perms = perms;

  return new;
}


/* This function searchs the given address space for a segment of given size. */
t_error		segment_fit(o_as* as, t_psize size, t_perms perms, t_paddr* address)
{
  o_segment	*olds = NULL;
  o_segment	*curs = NULL;
  t_error	error = 0;
  o_segment	new;
  t_iterator	old;
  t_iterator	i;
  t_state	s;

  SEGMENT_ENTER(segment);
  if ((error = set_head(segment->container, &old)) == ERROR_NONE)
    {
      if ((error = set_object(segment->container, old, (void **) &olds)) != ERROR_NONE)
	return error;
      set_foreach(SET_OPT_FORWARD, segment->container, &i, s)
	  {
	    if ((error = set_object(segment->container, i, (void **) &curs)) != ERROR_NONE)
	      return error;
	    if ((olds == curs) || ((olds->address + olds->size + size) < curs->address))
	      break;
	    olds = curs;
	  }
      new = segment_new(as->asid, olds->address + olds->size, size, perms);
    }
  else
    new = segment_new(as->asid, segment->start, size, perms);
  if ((error = segment_inject(as->asid, &new)) != ERROR_NONE)
    return error;
  *address = new.address;
  SEGMENT_LEAVE(segment, error);
}
