#!/bin/sh
## licence       kaneton licence
##
## project       kaneton
##
## file          /home/pouya/kaneton/export/export.sh
##
## created       pouya mohtacham   [sun feb 26 14:49:19 2006]
## updated       pouya mohtacham   [sun feb 26 23:27:28 2006]
##

groupe="srs6"
echo "exporting the tarball of groupe [$groupe] for kaneton"
cd ..
make clear
find . -name '*~' | xargs rm
find . -name 'CVS' | xargs rm -rf
find . -name '.o~' | xargs rm -rf
rm -rf kaneton.img
cd ..
date=`date '+%D-%R'`
date=`echo $date | sed 's/\//-/g'`
date=`echo $date | sed 's/:/h/g'`
tar czvf "kaneton-${groupe}-${date}.tar" kaneton/