/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/kaneton/libs/libia32/paging/pd.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:20 2005]
 * updated       pouya mohtacham   [sun feb 26 02:36:58 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page directory.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this    file   is    destinated   to    functions    dealing   with
 * page-directories. there are no restrictions about function names or
 * prototype, so feel free.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */


#define		PD_SIZE 1024


/* initialize a pd entry */
void		init_pd_entry(unsigned int *pd_entry)
{
  *pd_entry = 0;

}

/* create a page directory entry with the page table location  */
unsigned int	create_pd_entry(unsigned int pt_addr)
{
  unsigned int	entry = 0;

  /*   catch the 31-12 bits for addr */
  entry = pt_addr & 0xFFFFF000;
  /*   put the 1st bit for the present flag to 1 */
  /*   put the 2nd bit for r/w privileges to 1 */
  entry = entry | 0x00000003;
  return entry;
}

/* create the page directory and initialize everything to 0 */
int		create_pd(unsigned int here)
{
  unsigned int	i = 0;
  unsigned int	pd[PD_SIZE];

  for (i = 0; i < PD_SIZE; ++i)
    init_pd_entry(pd + i);

  memcpy((unsigned int *)here, pd, sizeof(unsigned int) * PD_SIZE);
  return sizeof(unsigned int) * PD_SIZE;
}

