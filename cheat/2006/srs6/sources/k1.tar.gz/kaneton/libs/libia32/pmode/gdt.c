/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workplace/kaneton/libs/libia32/pmode/gdt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:45:19 2005]
 * updated       pouya mohtacham   [sun feb 26 23:05:45 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage global descriptor table.
 *
 */


/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have  to place here code to manage  gdt. there are no
 * restrictions on prototypes, names etc.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include "../include/pmode/pmode.h"

/*
 * ---------- functions -------------------------------------------------------
 */

gdt_descriptor		my_gdt[GDT_SIZE];
unsigned int		gdt_ptr = 1;
gdt_registry		gdtr;


int			init_gdt_descriptor(u_int32_t base, \
					    u_int32_t limit, \
					    u_int8_t access, \
					    u_int8_t other, \
					    gdt_descriptor* desc)
{
  desc->limit0_15 = (limit & 0xffff);
  desc->base0_15 = (base & 0xffff);
  desc->base16_23 = (base & 0xff0000)>>16;
  desc->access = access;
  desc->limit16_19 = (limit & 0xf0000)>>16;
  desc->other = (other & 0xf);
  desc->base24_31 = (base & 0xff000000)>>24;
  return 0;
}

int			init_code_seg_descriptor(u_int32_t base, \
						u_int32_t limit, \
						gdt_descriptor* desc)
{
  init_gdt_descriptor(base, limit, 0x9B, 0x0D, desc);
  return 0;
}

int			init_data_seg_descriptor(u_int32_t base, \
						u_int32_t limite, \
						gdt_descriptor* desc)
{
  init_gdt_descriptor(base, limite, 0x93, 0x0D, desc);
  return 0;
}

int			add_gdt_descriptor(gdt_descriptor descriptor)
{
  my_gdt[gdt_ptr] = descriptor;
  gdt_ptr++;
  return 0;
}

int			gdt_create(unsigned int the_gdt_addr)
{
  gdt_descriptor	code_seg;
  gdt_descriptor	data_seg;
  gdt_descriptor	stack_seg;

  /*
   * segments descriptors initialization *
   */

  init_code_seg_descriptor(0x0, 0xFFFFF, &code_seg);
  init_data_seg_descriptor(0x0, 0xFFFFF, &data_seg);
  init_gdt_descriptor(0, 0x10, 0x97, 0x0D, &stack_seg);
  add_gdt_descriptor(code_seg);
  add_gdt_descriptor(data_seg);
  add_gdt_descriptor(stack_seg);

  /*
   * GDTR initialization *
   */

  gdtr.limit = GDT_SIZE*8;
  gdtr.base = the_gdt_addr;

  /*
   * GDT copy * in memory
   */
  memcpy(&gdtr.base, my_gdt, gdtr.limit);

  /*
   * GDT loading and protected mode activation *
   */

  asm ("lgdt %0"::"m" (gdtr));
  asm ("mov %cr0,%eax\n\t"
       "or %ax,1\n\t"
       "mov %eax,%cr0");

  /*
  asm ("lgdt (gdtr)\n\t"
       "mov %eax,%cr0\n\t"
       "or %ax,1\n\t"
       "mov %cr0,%eax\n\t");
  */

  return 0;
}

