/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/kaneton/libs/libia32/paging/pt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:48 2005]
 * updated       pouya mohtacham   [sun feb 26 02:37:10 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page tables.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to place here everything dealing with page tables. no
 * restrictions apply on this file.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


#define		PT_SIZE 1024


/* initialize a pt entry */
void		init_pt_entry(unsigned int *pt_entry)
{
  *pt_entry = 0;
}

/* init the entry by his own adress, and put the presence flag to 1 also r/w flag to */
/*   1, for more details looj to pd.c */
void		init_pt_identity(unsigned int *pt, unsigned int pd_entry)
{
  unsigned int	i = 0;
  unsigned int	mem_addr = pd_entry * 1024 * 4096;

  for (i = 0; i < PT_SIZE; ++i)
    {
      pt[i] = (unsigned int)mem_addr & 0xFFFFF000;
      pt[i] = pt[i] | 0x00000003;
      mem_addr += 4096;
    }
}



/* create the page table and initialize everything to 0 */
int		create_pt(unsigned int here)
{
  unsigned int	i = 0;
  unsigned int	pt[PT_SIZE];

  for (i = 0; i < PT_SIZE; ++i)
    init_pt_entry(pt + i);

  memcpy((unsigned int *)here, pt, sizeof(unsigned int) * PT_SIZE);
  return sizeof(unsigned int) * PT_SIZE;
}

