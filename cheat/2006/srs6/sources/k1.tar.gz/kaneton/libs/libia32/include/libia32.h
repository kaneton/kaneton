/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/libia32.h
 *
 * created       matthieu bucchianeri   [tue dec 20 13:58:56 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:15:42 2006]
 */

#ifndef LIBIA32_H
#define LIBIA32_H

/*
 * ---------- includes --------------------------------------------------------
 */

#include "misc/asm.h"
#include "misc/isa.h"
#include "misc/multiboot.h"
#include "misc/stdarg.h"
#include "misc/types.h"
#include "paging/paging.h"
#include "pmode/pmode.h"

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../pmode/pmode.c
 *      ../pmode/gdt.c
 *      ../pmode/ldt.c
 *      ../paging/paging.c
 *      ../paging/pd.c
 *      ../paging/pt.c
 *      ../paging/tlb.c
 *      ../interrupt/interrupt.c
 *      ../interrupt/idt.c
 */

/*
 * ../pmode/pmode.c
 */


/*
 * ../pmode/gdt.c
 */

int			init_gdt_descriptor(u_int32_t base, \
					    u_int32_t limit, \
					    u_int8_t access, \
					    u_int8_t other, \
					    gdt_descriptor* desc);

int			init_code_seg_descriptor(u_int32_t base, \
						u_int32_t limit, \
						gdt_descriptor* desc);

int			init_data_seg_descriptor(u_int32_t base, \
						u_int32_t limite, \
						gdt_descriptor* desc);

int			add_gdt_descriptor(gdt_descriptor descriptor);

int			gdt_create(unsigned int the_gdt_addr);


/*
 * ../pmode/ldt.c
 */


/*
 * ../paging/paging.c
 */

unsigned int	active_paging_mode(unsigned int pd_addr);


/*
 * ../paging/pd.c
 */

void		init_pd_entry(unsigned int *pd_entry);

unsigned int	create_pd_entry(unsigned int pt_addr);

int		create_pd(unsigned int here);


/*
 * ../paging/pt.c
 */

void		init_pt_entry(unsigned int *pt_entry);

void		init_pt_identity(unsigned int *pt, unsigned int pd_entry);

int		create_pt(unsigned int here);


/*
 * ../paging/tlb.c
 */


/*
 * ../interrupt/interrupt.c
 */


/*
 * ../interrupt/idt.c
 */


/*
 * eop
 */

#endif
