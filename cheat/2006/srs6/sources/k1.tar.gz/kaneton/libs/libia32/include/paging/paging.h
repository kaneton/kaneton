/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/kaneton/libs/libia32/include/paging/paging.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       pouya mohtacham   [sat feb 25 23:30:28 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * declares paging structures, defines, etc.
 *
 */

#ifndef IA32_IA32_PAGING_H
#define IA32_IA32_PAGING_H	1

/* paging.c */
unsigned int	active_paging_mode(unsigned int pd_addr);


/* page directory page pd.c */

int		create_pd(unsigned int here);
unsigned int	create_pd_entry(unsigned int pt_addr);

/* page tables page pt.c */
void		init_pt_identity(unsigned int *pt, unsigned int pd_entry);
int		create_pt(unsigned int here);

#endif
