/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workplace/kaneton/libs/libia32/include/pmode/pmode.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       pouya mohtacham   [sun feb 26 23:05:55 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef IA32_IA32_PMODE_H
#define IA32_IA32_PMODE_H	1

#include <libsys/types.h>

/*
 *  number of descriptors
 */

#define GDT_SIZE	255

/*
 * segment descriptor
*/

  typedef struct
  {
    u_int16_t		limit0_15;
    u_int16_t		base0_15;
    u_int8_t		base16_23;
    u_int8_t		access;
    u_int8_t		limit16_19 : 4;
    u_int8_t		other : 4;
    u_int8_t		base24_31;
  }			gdt_descriptor;

/*
 * GDT Register
*/
  typedef struct
  {
    u_int32_t		base ;
    u_int16_t           limit ;
  }			gdt_registry;

int			init_gdt_descriptor(u_int32_t base, \
					    u_int32_t limit, \
					    u_int8_t access, \
					    u_int8_t other, \
					    gdt_descriptor* desc);
int			init_code_seg_descriptor(u_int32_t base, \
						 u_int32_t limit, \
						 gdt_descriptor* desc);
int			init_data_seg_descriptor(u_int32_t base, \
						 u_int32_t limite, \
						 gdt_descriptor* desc);

int			add_gdt_descriptor(gdt_descriptor desc);
int			gdt_create(unsigned int);

#endif
