/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workplace/kaneton/libs/libia32/paging/paging.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:05 2005]
 * updated       pouya mohtacham   [sun feb 26 16:51:17 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage paging.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will have  to fill  this  file with  function related  to
 * paging mode in the cpu: enable, disabling etc.
 *
 * there are no  restrictions about these functions, but  keep in mind
 * that  page-directory management and  page-tables management  are to
 * place in pd.c and pt.c.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libconsole.h>

/*
 * ---------- functions -------------------------------------------------------
 */




/* activate the paging mode */
unsigned int	active_paging_mode(unsigned int pd_addr)
{
  unsigned int	cr0 = 0;
  unsigned int	cr3 = 0;

  /*   put pd_addr in cr3 */
  pd_addr &= 0xFFFFF000;
  pd_addr = pd_addr | 0x0000000C;
  __asm__ __volatile__("movl %0,%%cr3": :"r" (pd_addr));

  /*   load cr0 */
  __asm__ ("movl %%cr0, %0" :"=r" (cr0));

  /*   apply the activation mask */
  cr0 = cr0 | 0x80000000;

  /*   put new cr0 in the register */
  __asm__ __volatile__("movl %0,%%cr0": :"r" (cr0));

  return cr3;
}
