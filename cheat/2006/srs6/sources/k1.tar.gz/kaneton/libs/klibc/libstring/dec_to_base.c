/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/kaneton/libs/klibc/libstring/dec_to_base.c
 *
 * created       pouya mohtacham   [fri feb 24 08:17:34 2006]
 * updated       pouya mohtacham   [sun feb 26 18:42:30 2006]
 */
#include <klibc.h>


/* #define BASE_HEXA "0123456789abcdef" */

char		*dec_to_base(unsigned long nb, char *base, char *buffer)
{
  unsigned int	bsize = 0;
  unsigned int	i = 0;
  unsigned int	j = 0;
  char		tmp;

/*   buffer[0] = '0'; */
/*   buffer[1] = 'x'; */

  bsize = strlen(base);
  while(nb >= bsize)
    {
      buffer[i] = base[nb % bsize];
      nb /= bsize;
      ++i;
    }
  buffer[i] = base[nb % bsize];

  for (j = 0; j < (i + 1) / 2; ++j)
    {
      tmp = buffer[j];
      buffer[j] = buffer[i - j];
      buffer[i - j] = tmp;
    }
  buffer[i + 1] = '\0';
  return buffer;
}



/* int		main(void) */
/* { */
/*   unsigned int	number = 32; */
/*   char		buffer[16]; */
/*   char		*hexnb = NULL; */
/*   int		i = 0; */

/*   for (i = 1; i < 5335325; i += number) */
/*     { */
/*       number = i; */
/*       hexnb = dec_to_base(number, BASE_HEXA, buffer); */
/*       printf("%d, %x, %s\n", number, number, hexnb); */
/*     } */
/*   return 0; */
/* } */
