/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/kaneton/libs/klibc/libstring/main.c
 *
 * created       pouya mohtacham   [sat feb 25 14:29:24 2006]
 * updated       pouya mohtacham   [sat feb 25 14:37:07 2006]
 */

#include <stdio.h>
#include "../include/klibc.h"


#define BASE_HEXA "0123456789abcdef"

