/*
 * licence       kaneton licence
 *
 * project
 *
 * file          /home/pouya/kaneton/libs/libconsole/src/libconsole.c
 *
 * created       pouya mohtacham   [fri feb 24 01:52:59 2006]
 * updated       pouya mohtacham   [fri feb 24 18:51:20 2006]
 */

#include <klibc.h>
#include "../include/libconsole.h"

#define CONSOLE_X 80
#define CONSOLE_Y 25


/* global var for the cursor */
struct s_cursor gcursor;



void			clear_console(struct s_cursor *cursor)
{
  unsigned int		i = 0;
  unsigned char		*addr = 0;

  for (i = 0; i < CONSOLE_Y * CONSOLE_X; ++i)
    {
      addr = (unsigned char *)(0xb0000 + i * 0x02);
      *addr = '\0';
    }
}


/* my strlen */
size_t		my_strlen(char *s)
{
  size_t	size = 0;

  for(; *s != '\0'; ++s)
    size++;
  return size;
}


/* Initialize the cursor */
void		cursor_init(struct s_cursor *cursor)
{
  cursor->x = 0;
  cursor->y = 0;
}


void		move_up(void)
{
  unsigned int	i = 0;
  unsigned char	*addr_src = 0;
  unsigned char	*addr_dest = 0;

  for (i = 0; i < CONSOLE_X * CONSOLE_Y - CONSOLE_X; ++i)
    {
      addr_src = (unsigned char *)(0xb8000 + (i + CONSOLE_X) * 0x02);
      addr_dest = (unsigned char *)(addr_src - CONSOLE_X * 0x02);
      *addr_dest = *addr_src;
    }
}

/* clear a line from the from argument */
void		clear_line(unsigned int line, unsigned int from)
{
  unsigned int	i = 0;
  unsigned char	*addr = 0;

  for (i = 0; i < CONSOLE_X - from; ++i)
    {
      addr = (unsigned char *)(0xb8000 + (line * CONSOLE_X * 0x02) +
			       from * 0x02 +
			       i * 0x02);
      *addr = '\0';
    }

}

/* make a new line and delete the content of the new line */
void		new_line(struct s_cursor *cursor)
{
  cursor->x = 0;
  cursor->y++;
  if (cursor->y >= CONSOLE_Y)
    {
      move_up();
      cursor->y--;
    }
  clear_line(cursor->y, 0);
}


/* update the current position of the cursor  */
void		check_cursor_pos(struct s_cursor *cursor)
{
  if (cursor->x >= CONSOLE_X)
    {
      new_line(cursor);
    }
  if (cursor->y >= CONSOLE_Y)
    {
      move_up();
    }
}


/* give the addr of the cursor on the screen */
char		*cursor_addr(struct s_cursor *cursor)
{
  return (unsigned char *)(0xb8000 +
			   cursor->y * (CONSOLE_X * 0x02) +
			   (cursor->x * 0x02));
}

/* display on screen */
int		display_console(char *string)
{
  unsigned int	i = 0;
  unsigned char	*addr = 0;
  t_size	size = 0;


  clear_line(gcursor.y, gcursor.x);
  size = my_strlen(string);
  for (i = 0; i < size; ++i)
    {
      if (string[i] == '\n')
	{
	  new_line(&gcursor);
	}
      else
	{
	  check_cursor_pos(&gcursor);
	  addr = cursor_addr(&gcursor);
	  *(addr) = string[i];
	  gcursor.x++;
	}
      check_cursor_pos(&gcursor);
    }
  return 0;
}

void		display_console_ln(char *string)
{
  display_console(string);
  display_console("\n");
}

