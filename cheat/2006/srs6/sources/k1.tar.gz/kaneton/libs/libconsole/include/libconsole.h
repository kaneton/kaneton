/*
 * licence       kaneton licence
 *
 * project
 *
 * file          /home/pouya/kaneton/libs/libconsole/include/libconsole.h
 *
 * created       pouya mohtacham   [fri feb 24 01:53:17 2006]
 * updated       pouya mohtacham   [fri feb 24 06:39:44 2006]
 */

#ifndef LIBCONSOLE_H_
 #define LIBCONSOLE_H_

#include <klibc.h>

struct		s_cursor
{
  unsigned int	x;
  unsigned int	y;
};

int		display_console(char *string);
void		cursor_init(struct s_cursor *cursor);
char		*cursor_addr(struct s_cursor *cursor);
size_t		my_strlen(char *s);
void		clear_console(struct s_cursor *cursor);
void		check_cursor_pos(struct s_cursor *cursor);
void		new_line(struct s_cursor *cursor);
void		move_up(void);
void		clear_line(unsigned int line, unsigned int from);
void		display_console_ln(char *string);

#endif /* ! LIBCONSOLE_H_ */
