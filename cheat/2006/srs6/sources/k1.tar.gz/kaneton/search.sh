#!/bin/sh
find ~/kaneton -name '*.[hc]'  | xargs grep -nH $1
find ~/kaneton -name '.*.mk'  | xargs grep -nH $1
find ~/kaneton -name 'Makefile'  | xargs grep -nH $1