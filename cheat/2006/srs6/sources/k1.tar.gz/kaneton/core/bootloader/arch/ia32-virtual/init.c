/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/kaneton/core/bootloader/arch/machdep/init.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       pouya mohtacham   [fri feb 24 08:36:20 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this file contains the functions intended to do the relocation.
 *
 * this file is very important because it does the most important things
 * of the bootloader: computes segments and regions, relocates data, creates
 * the init structure etc..
 *
 * the relocation is based on dynamic allocation. nevertheless, no dynamic
 * allocation is provided. the student so has to setup a very simple dynamic
 * memory allocation algorithm to be able to build the init structure.
 *
 * think about it because some components cannot have a dynamic address. there
 * are some crazy problems to resolve in this context.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libconsole.h>


#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * init variable, describing the initial memory layout.
 *
 * this structure will be passed to the kernel describing modules,
 * physical memory reserved by the hardware etc.. thus the kernel will
 * be able to initialise its managers: segment manager, module manager etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */


void		init_t_init(t_init *my_init)
{
  char		buffer[BUF_SIZE];

  display_console("you are erasing the t_init table @ ");
  display_console_ln(itoa((unsigned int)my_init, buffer));

  my_init->mem = 0;
  my_init->memsz = 0;
  my_init->kcode = 0;
  my_init->kcodesz = 0;
  my_init->init = 0;
  my_init->initsz = 0;
  my_init->modules = NULL;
  my_init->modulessz = 0;
  my_init->nsegments = 0;
  my_init->segments = NULL;
  my_init->segmentssz = 0;
  my_init->nregions = 0;
  my_init->regions = NULL;
  my_init->regionssz = 0;
  my_init->kstack = 0;
  my_init->kstacksz = 0;
  my_init->alloc = 0;
  my_init->allocsz = 0;
}

void		display_init(t_init *my_init)
{
  char		buffer[BUF_SIZE];

  display_console("you are printing the t_init table @ ");
  display_console_ln(itoa((unsigned int)my_init, buffer));

  display_console(" mem: ");
  display_console_ln(itoa(my_init->mem, buffer));

  display_console(" memsz: ");
  display_console_ln(itoa(my_init->memsz, buffer));


  display_console(" kcode: ");
  display_console_ln(itoa(my_init->kcode, buffer));

  display_console(" kcodesz: ");
  display_console_ln(itoa(my_init->kcodesz, buffer));


  display_console(" init: ");
  display_console_ln(itoa(my_init->init, buffer));

  display_console(" initsz: ");
  display_console_ln(itoa(my_init->initsz, buffer));


  display_console(" modules: ");
  display_console_ln(dec_to_base((unsigned int)my_init->modules, BASE_HEXA, buffer));

  display_console(" modulessz: ");
  display_console_ln(itoa(my_init->modulessz, buffer));


  display_console(" nsegments: ");
  display_console_ln(itoa(my_init->nsegments, buffer));

  display_console(" segments: ");
  display_console_ln(dec_to_base((unsigned int)my_init->segments,
				 BASE_HEXA, buffer));

  display_console(" segmentssz: ");
  display_console_ln(itoa(my_init->segmentssz, buffer));


  display_console(" nregions: ");
  display_console_ln(itoa(my_init->nregions, buffer));

  display_console(" regions: ");
  display_console_ln(dec_to_base((unsigned int)my_init->regions,
				 BASE_HEXA, buffer));

  display_console(" regionssz: ");
  display_console_ln(itoa(my_init->regionssz, buffer));


  display_console(" kstack: ");
  display_console_ln(itoa(my_init->kstack, buffer));

  display_console(" kstacksz: ");
  display_console_ln(itoa(my_init->kstacksz, buffer));


  display_console(" alloc: ");
  display_console_ln(itoa(my_init->alloc, buffer));

  display_console(" allocsz: ");
  display_console_ln(itoa(my_init->allocsz, buffer));

  display_console_ln("end printing t_init table");
}
