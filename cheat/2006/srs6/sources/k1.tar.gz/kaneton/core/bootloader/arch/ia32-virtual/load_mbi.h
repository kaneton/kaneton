/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workplace/kaneton/core/bootloader/arch/machdep/load_mbi.h
 *
 * created       pouya mohtacham   [fri feb 24 03:39:07 2006]
 * updated       pouya mohtacham   [sun feb 26 21:07:23 2006]
 */

#ifndef LOAD_MBI_H_
# define LOAD_MBI_H_

#include <kaneton.h>
#include <klibc.h>
#include <libconsole.h>
#include <libia32.h>
#include "bootloader.h"
#include "segments.h"
#include "regions.h"

t_init		*load_mbi(multiboot_info_t *mbi);
void		display_int(unsigned int);
void		display_int_ln(unsigned int);
unsigned int	bootloader_malloc(unsigned int size);
unsigned int	memory_in_page(unsigned int size);
void		init_bootloader(s_bootloader *bl);
t_psize		put_modules_in_mem(multiboot_info_t *mbi);
#define UI_TIMES_1024 1024 * sizeof(unsigned int)

#endif /* !LOAD_MBI_H_ */
