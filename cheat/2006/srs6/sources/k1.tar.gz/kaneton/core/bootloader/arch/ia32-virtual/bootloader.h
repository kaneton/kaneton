/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workplace/kaneton/core/bootloader/arch/machdep/bootloader.h
 *
 * created       julien quintard   [fri feb 11 02:23:53 2005]
 * updated       pouya mohtacham   [sun feb 26 22:02:13 2006]
 */

#ifndef BOOTLOADER_H
#define BOOTLOADER_H		1

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      bootloader.c
 *      cons.c
 *      init.c
 *      paging.c
 *      pmode.c
 */

/*
 * bootloader.c
 */

int			bootloader(t_uint32			magic,
				   multiboot_info_t*		mbi);


/*
 * cons.c
 */


/*
 * init.c
 */

void		display_init(t_init *my_init);
void		init_t_init(t_init *my_init);

/*
 * paging.c
 */

unsigned int	init_paging_mode(unsigned int pd_addr);

/*
 * pmode.c
 */


/*
 * eop
 */


/* this struct contains informations for the bootloader to be loaded. */
typedef struct
{
  unsigned int	mem_current_pos;
  t_init	*t_init;
  unsigned int	gdt_addr;
  unsigned int	pd_addr;
} s_bootloader;

void			jump_to_kernel(t_init	*init);

#define	MEM_BEGIN 16777216 /* 16 * 1024 * 1024 */
#define BUF_SIZE 16
#define BASE_HEXA "0123456789abcdef"
#define KERNEL_STACK_SZ	16
#define ALLOC_SZ 32
#endif
