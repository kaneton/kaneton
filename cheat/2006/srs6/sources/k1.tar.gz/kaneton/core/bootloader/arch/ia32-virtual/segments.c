/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workplace/kaneton/core/bootloader/arch/machdep/segments.c
 *
 * created       pouya mohtacham   [sat feb 25 15:03:03 2006]
 * updated       pouya mohtacham   [sun feb 26 20:48:52 2006]
 */


#include <klibc.h>
#include <libconsole.h>
#include "segments.h"
#include "bootloader.h"
#include "load_mbi.h"

void		put_in_segment(o_segment *segment, unsigned int address,
			       unsigned int size, unsigned int perms)
{
  segment->segid = address;
  segment->address = address;
  segment->size = size;
  segment->perms = perms;
}


void		create_segments_table(s_bootloader *bl_conf)
{
  o_segment	segments[16];
  t_init	*init;

  init = bl_conf->t_init;

  display_console_ln("creating the segments table...");

  /*   creating each segment */


  /*   first page in memory */
  put_in_segment(&segments[0], 0, memory_in_page(PAGESZ), 0);

  /*   the isa segment */
  put_in_segment(&segments[1], 1 * PAGESZ, memory_in_page(1024 * 1024 - PAGESZ), 0);

  /*   put the kernel */
  put_in_segment(&segments[2], init->kcode, memory_in_page(init->kcodesz),
		 0);

  /*   the t_init structure */
  put_in_segment(&segments[3], init->init, memory_in_page(init->initsz),
		 0);
  /*   the modules segment */
  put_in_segment(&segments[4], (unsigned int)init->modules,
		 memory_in_page(init->modulessz), 0);

  /*   the segment of segment table */
  put_in_segment(&segments[5], (unsigned int)init->segments,
		 memory_in_page(init->segmentssz), 0);

  /*   the regions table segment */
  put_in_segment(&segments[6], (unsigned int)init->regions,
		 memory_in_page(init->regionssz), 0);

  /*   the kernet stack segment */
  put_in_segment(&segments[7], init->kstack, memory_in_page(init->kstacksz),
		 0);

  /*   the alloc survey area */
  put_in_segment(&segments[8], init->alloc, memory_in_page(init->allocsz),
		 0);

  /*   the gdt segment */
  put_in_segment(&segments[9], bl_conf->gdt_addr, memory_in_page(PAGESZ),
		 0);

  /*   the page directory segment */
  put_in_segment(&segments[10], bl_conf->pd_addr, memory_in_page(UI_TIMES_1024),
		 0);

  /*   the first page table */
  put_in_segment(&segments[11], bl_conf->pd_addr + 1 * UI_TIMES_1024,
		 memory_in_page(UI_TIMES_1024), 0);
  /*   the second page table */
  put_in_segment(&segments[12], bl_conf->pd_addr + 2 * UI_TIMES_1024,
		 memory_in_page(UI_TIMES_1024), 0);

  /* copy the segments table in the memory */
/*   display_int_ln(init->nsegments); */
/*   display_int_ln(init->segments); */
/*   display_int_ln(segments); */
/*   display_int_ln(init->segmentssz); */
  memcpy(init->segments, segments, init->segmentssz);
}


/* create all the segment table and put it in the memory */
void		reserve_segments(t_init	*init)
{
  unsigned int	segments_size = 0;
  unsigned int	segments_memory_need = 0;
/*   unsigned int  *write_here = NULL; */


  segments_size = 13;
  init->nsegments = segments_size;

  display_console("there is ");
  display_int(segments_size);
  display_console_ln(" segments to create.");

  /*   calcul how much memory is need
       for the segment table, and reserve in the memory  */
  segments_memory_need = segments_size * sizeof(o_segment);
  init->segmentssz = segments_memory_need;
  display_console("for segments table ");
  init->segments = (o_segment *)bootloader_malloc(segments_memory_need);
}
