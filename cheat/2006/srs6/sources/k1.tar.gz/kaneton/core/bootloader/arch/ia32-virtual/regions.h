/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workplace/kaneton/core/bootloader/arch/machdep/regions.h
 *
 * created       pouya mohtacham   [sat feb 25 16:07:53 2006]
 * updated       pouya mohtacham   [sun feb 26 19:04:51 2006]
 */

#ifndef REGIONS_H_
# define REGIONS_H_

#include <kaneton.h>
#include <klibc.h>
#include <libconsole.h>
#include "load_mbi.h"

void		create_regions_table(s_bootloader *bl_conf);
void		reserve_regions(t_init	*init);
void		put_in_region(o_region *region, unsigned int segid,
			      unsigned int offset, unsigned int size);

#endif /* !REGIONS_H_ */
