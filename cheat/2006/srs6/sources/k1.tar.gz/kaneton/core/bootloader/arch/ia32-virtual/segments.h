/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workplace/kaneton/core/bootloader/arch/machdep/segments.h
 *
 * created       pouya mohtacham   [sat feb 25 15:03:16 2006]
 * updated       pouya mohtacham   [sun feb 26 19:05:02 2006]
 */

#ifndef SEGMENTS_H_
# define SEGMENTS_H_

#include <kaneton.h>
#include "bootloader.h"

void		reserve_segments(t_init	*init);
void		put_in_segment(o_segment *segment, unsigned int address,
			       unsigned int size, unsigned int perms);
void		create_segments_table(s_bootloader *bl_conf);


#endif /* !SEGMENTS_H_ */
