/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/shloukmou/boulot/misc/kaneton/core/bootloader/arch/machdep/bootloader.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       etienne gaschet   [sun feb 26 23:51:02 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the bootloader is to install a correct environment for
 * the kernel.
 *
 * the first thing to do is to relocate the different kaneton data structure
 * in order to build the t_init structure. this structure must contain
 * everything the kernel will need.
 *
 * for more information on the relocating, take a look to the kaneton
 * paper which describes the entire kaneton reference.
 *
 * once the init structure was built, the kernel has to be launched.
 *
 * nevertheless, the kernel needs to evolve with the protected mode and
 * paging mode activated, so the bootloader first has to install these.
 *
 * printing some messages is interesting showing the protected mode and
 * paging mode are correctly installed.
 *
 * after all, the bootloader has launch the kernel binary.
 *
 * look at the ld scripts to know where the kernel has to be loaded.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libconsole.h>

#include "bootloader.h"
#include "load_mbi.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * these three variable are globals to avoid them to be lost when the
 * bootloader changes its stack.
 *
 * indeed, before jumping on the kernel a new stack is created so the local
 * variables will no longer be accessible. putting these variables in
 * globals bypass this problem.
 */

void			(*kernel)(t_init*);

t_reg32			ebp;
t_reg32			esp;

/*
 * ---------- functions -------------------------------------------------------
 */

static char * welcome_msg = "welcome to our bootloader\n";


void			jump_to_kernel(t_init	*init)
{
  unsigned int		kaddr = 0;

  /* change eip to the kernel address */
  display_console("kernel addr: ");
  kaddr = init->kcode + 0x94;
  display_int_ln(kaddr);
  memcpy(init->kstack, init, sizeof(t_init));
  __asm__ __volatile__("movl %0, %%esp;" :  : "r" (init->kstack));
  __asm__ __volatile__("jmp *%0;" :  : "r" (kaddr));
}


int			bootloader(t_uint32			magic,
				   multiboot_info_t*		mbi)
{
  t_init		*init = NULL;

  display_console(welcome_msg);
  if ((init = load_mbi(mbi)) != 0)
    jump_to_kernel(init);
  while(1) ;
  return (0);
}

