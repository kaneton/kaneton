/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/kaneton/core/bootloader/arch/machdep/paging.c
 *
 * created       julien quintard   [sun may 29 00:38:50 2005]
 * updated       pouya mohtacham   [sun feb 26 02:38:22 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * these function just install the paging mode to enable virtual memory
 * which is required by the kaneton kernel.
 *
 * think about mapping everything needed: kernel code, kernel stack, init
 * structure etc..
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libconsole.h>
#include "bootloader.h"
#include "load_mbi.h"
/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*			init;


/*
 * ---------- functions -------------------------------------------------------
 */

/* here we will try to map all address' needed for the paging mode to */
/* survive, first page table(pt) in the beggining of te memory, and */
/* the second pt for the kernel zone, we will write first in the memory and  */
/* tell how much place we need to the bootloader, and he will reserve it for */
/* us that's why we use cur_addr  */

unsigned int	init_paging_mode(unsigned int pd_addr)
{
  unsigned int	cur_addr = pd_addr;
  unsigned int	pt_begin_addr = 0;
  unsigned int	pt_kernel_addr = 0;
  unsigned int  *pd = (unsigned int *)pd_addr;

  /*   we create the page directory */
  cur_addr += create_pd(cur_addr);
  display_console("page directory is at addr @");
  display_int_ln(pd_addr);

  /*   we create the first page table for the beginning of the memory */
  pt_begin_addr = cur_addr;
  display_console("page table 1 is at addr @");
  display_int_ln(pt_begin_addr);
  cur_addr += create_pt(cur_addr);

  /*   we create the page table for the kernel zone to be mapped */
  pt_kernel_addr = cur_addr;
  display_console("page table 2 is at addr @");
  display_int_ln(pt_kernel_addr);
  cur_addr += create_pt(cur_addr);

  /*   we change the entrys of the page directory to tell him that the pages tables exists */
  pd[0] = create_pd_entry(pt_begin_addr);
  pd[4] = create_pd_entry(pt_kernel_addr);

  /*   create the entry's in the page tables */
  /*   we will use the identity mapping technique here, */
  /*   each addresse will map him self in this 2 pages tables */
  init_pt_identity((unsigned int *)pt_begin_addr, 0);
  init_pt_identity((unsigned int *)pt_kernel_addr, 4);


  return cur_addr - pd_addr;
}
