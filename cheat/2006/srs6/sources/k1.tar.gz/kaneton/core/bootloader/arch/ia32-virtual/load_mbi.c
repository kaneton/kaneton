#include "load_mbi.h"


t_init*			init;



/* global variable for the bootloader */
s_bootloader	*bl_conf;


/* init the bootlader struct */
void		init_bootloader(s_bootloader *bl)
{
  bl->mem_current_pos = MEM_BEGIN;
  bl->t_init = 0;
}

/* calcul a new number which can be divide by the page size 4096 */
unsigned int	memory_in_page(unsigned int size)
{
  unsigned int	page_number = 0;

  if (!(page_number = (size / PAGESZ)))
    page_number = 1;
  return page_number * PAGESZ;
}


/* reserve an area in the memory and give the addr of the begining */
unsigned int	bootloader_malloc(unsigned int size)
{
/*   char		buffer[BUF_SIZE]; */
  unsigned int	old_pos = bl_conf->mem_current_pos;
  unsigned int	page_number = 0;

  bl_conf->mem_current_pos += memory_in_page(size);
  page_number = memory_in_page(size) / PAGESZ;
  display_console("you are asking for ");
  display_int(page_number);
  display_console(" new page(s)\n");
  return old_pos;
}


/* load modules from the mbi, organize the structure and put them */
/* in the good place in the physical memorie */
t_psize		put_modules_in_mem(multiboot_info_t *mbi)
{
  t_modules	modules;
  t_module	module;
  module_t	mbi_module;
  unsigned int	i = 1;
  unsigned int	memory_place = bl_conf->mem_current_pos;
  unsigned int	modules_mem_size = 0;

  /* remove the kernel from the modules numbers */
  modules.nmodules = mbi->mods_count - 1;

  /* put t_modules in memory */
  memcpy((unsigned char *)memory_place, &modules, sizeof(modules));
  modules_mem_size += sizeof(modules);

  /*   put each t_module in the memory */
  for (i = 1; i < mbi->mods_count; ++i)
    {
      /* load the module from mbi*/
      memcpy(&mbi_module,
	     (unsigned char *)(mbi->mods_addr + i * sizeof(module_t)),
	     sizeof(module_t));
      /* create t_module from loaded infromations */
      module.size = mbi_module.mod_end - mbi_module.mod_start;

      /* put in the name the next place of name */
      module.name = (char *)(memory_place +
			     modules_mem_size +
			     sizeof(t_module) + module.size);
      /* put the name in the t_module */
      memcpy(module.name, (unsigned char *)mbi_module.string,
	     strlen((char *)mbi_module.string));
      display_console("this module is now added in memory: ");
      display_console_ln(module.name);

      /* copy the data */
      memcpy((unsigned char *)(memory_place +
			       modules_mem_size + sizeof(t_module)),
	     (unsigned char *)mbi_module.mod_start, module.size);
      modules_mem_size += sizeof(t_module) +
	module.size + (strlen(module.name) + 1) * sizeof(char);
    }

  display_console("all modules have been loaded correctly\n");
  display_console("for all modules ");
  bootloader_malloc(modules_mem_size);
  return modules_mem_size;
}




/* load all information from the mbi and put them in the memory */
t_init		*load_mbi(multiboot_info_t *mbi)
{
  module_t	module;
  unsigned int	module_size = 0;
  s_bootloader	local_bl;
  t_init	my_init;
  unsigned int	*addr = 0;


  init_bootloader(&local_bl);
  bl_conf = (s_bootloader *)&local_bl;
  init_t_init(&my_init);

  my_init.mem = mbi->mem_lower;
  my_init.memsz = mbi->mem_upper - mbi->mem_lower;


  display_console("loading mbi :\n");
  display_console("now mem addr is ");
  display_int_ln(bl_conf->mem_current_pos);
  display_console("moving the kernel...\n");

  /*   load the kernel to 16mb, kernel is the first module*/
  if (mbi->mods_count > 0)
    {
      memcpy(&module,
	     (unsigned char *)(mbi->mods_addr + 0 * sizeof(module_t)),
	     sizeof(module_t));
      module_size = module.mod_end - module.mod_start;
      my_init.kcodesz = module_size;

      display_console("kernel size : ");
      display_int_ln(module_size);
      display_console("for the kernel ");

      addr = (unsigned int *)bootloader_malloc(module_size);
      my_init.kcode = (t_paddr)addr;
      memcpy(addr,
	     (unsigned char *)module.mod_start, module_size);
    }
  else
    {
      /*       exit if there is not enough module */
      display_console_ln("can not find the kernel in modules.");
      return 0;
    }
  display_console("now mem addr is ");
  display_int_ln(bl_conf->mem_current_pos);

  /*   reserve the place of t_init inside the memory */
  display_console("for t_init ");
  bl_conf->t_init = (t_init *)bootloader_malloc(sizeof(t_init));

  /* put the t_init in the memory from my_init*/
  display_console_ln("copying the local init to the memory");
  memcpy((unsigned char *)bl_conf->t_init,
	 (unsigned char *)&my_init,
	 sizeof(t_init));

  /*   init is the global var in the tarball */
  init = bl_conf->t_init;
  display_console("t_init is now at @");
  display_int_ln((unsigned int)init);

  init->init = (t_paddr)bl_conf->t_init;
  init->initsz = sizeof(t_init);


  init->modules = (t_modules *)bl_conf->mem_current_pos;
  init->modulessz = put_modules_in_mem(mbi);

  /*   create the segment table and fill t_init struct for segments
       but don't put the segment table in the memory, we don't have all our
       informations yet */
  reserve_segments(init);

  /*   same that create segments but for regions */
  reserve_regions(init);

  /*   reserve KERNEL_STACK_SZ (bootloader.h) pages for the kernel stack */
  init->kstacksz = KERNEL_STACK_SZ * PAGESZ;
  display_console("for kstack ");
  init->kstack =
    (unsigned int)bootloader_malloc(memory_in_page(init->kstacksz));

  /*   reserve ALLOC_SZ pages for the kernel stack */
  init->allocsz = ALLOC_SZ * PAGESZ;
  display_console("for alloc (survey area) ");
  init->alloc =
    (unsigned int)bootloader_malloc(memory_in_page(init->allocsz));


  /*   reserve 1 page in the memory for the GDT
       and install the new gdt */
  display_console("for GDT ");
  bl_conf->gdt_addr = (unsigned int)bootloader_malloc(memory_in_page(PAGESZ));
  gdt_create(bl_conf->gdt_addr);
  display_console_ln("new gdt is now activated");

  display_console("creatin the page descriptor @");
  display_int_ln(bl_conf->mem_current_pos);
  create_pd(bl_conf->mem_current_pos);

  /*   init the pagining mode, create page directory, 2 pages
       tables for maping the survive zones	    */
  display_console_ln("initializing paging mode");
  init_paging_mode(bl_conf->mem_current_pos);

  /*   we have all informations for creating the segment table now, */
  /*   so we will fill all places we reserved earlier */

  create_segments_table(bl_conf);

  /*   /\* same for the region table *\/ */
  create_regions_table(bl_conf);

  /* activate the paging mode */
  bl_conf->pd_addr = active_paging_mode(bl_conf->mem_current_pos);
  display_console_ln("paginig mode activated");

  display_console_ln("homework done.");
  display_console_ln("ready for jumping to the kernel ... ");
  return init;
}


/* display an integer in the console by using libconsole */
void	display_int(unsigned int nb)
{
  char	buffer[BUF_SIZE];

  display_console(itoa(nb, buffer));
  display_console("[0x");
  display_console(dec_to_base(nb, BASE_HEXA, buffer));
  display_console("]");
}

/* display an integer in the console by using libconsole
   and put a \n*/
void	display_int_ln(unsigned int nb)
{
  display_int(nb);
  display_console("\n");
}
