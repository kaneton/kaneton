/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workplace/kaneton/core/bootloader/arch/machdep/regions.c
 *
 * created       pouya mohtacham   [sat feb 25 16:07:38 2006]
 * updated       pouya mohtacham   [sun feb 26 21:20:52 2006]
 */

#include "regions.h"


/* for filling one regions */
void		put_in_region(o_region *region, unsigned int segid,
			      unsigned int offset, unsigned int size)
{
  region->segid = segid;
  region->address = segid;
  region->offset = offset;
  region->size = size;
}


/* put the region table in the memory */
void		create_regions_table(s_bootloader *bl_conf)
{
  o_region	regions[16];
  t_init	*init = bl_conf->t_init;

  display_console_ln("creating the regions table...");
  /*   places in memory those will be mapped */

  /*   vga memory */
  put_in_region(&regions[0], 1, 0xB8000 - PAGESZ, 80 * 25 * 2);

  /*   the kernel code  */
  put_in_region(&regions[1], 2, init->kcode, memory_in_page(init->kcodesz));

  /*   the t_init structure */
  put_in_region(&regions[2], 3, init->init, memory_in_page(init->initsz));

  /*   the kernel stack */
  put_in_region(&regions[3], 7, init->kstack, memory_in_page(init->kstacksz));

  /*   the alloc survey area */
  put_in_region(&regions[4], 8, init->alloc, memory_in_page(init->allocsz));

  /*   the gdt */
  put_in_region(&regions[5], 9, bl_conf->gdt_addr, memory_in_page(PAGESZ));

  /*   the page directory */
  put_in_region(&regions[6], 10, bl_conf->pd_addr, memory_in_page(UI_TIMES_1024));

  /*   the first page table */
  put_in_region(&regions[7], 11, bl_conf->pd_addr + 1 * UI_TIMES_1024,
		memory_in_page(UI_TIMES_1024));

  /*   the second page table */
  put_in_region(&regions[8], 12, bl_conf->pd_addr + 2 * UI_TIMES_1024,
		memory_in_page(UI_TIMES_1024));

/*   finally copy the regions struct in the memory at
     the reserved place*/
  memcpy(init->regions, regions, init->regionssz);
}


/* reserve the memory for the region table and fill init */
void		reserve_regions(t_init	*init)
{
  unsigned int	regions_size = 7;

  display_console("there is ");
  display_int(regions_size);
  display_console_ln(" regions to create.");

  init->nregions = regions_size;
  init->regionssz = sizeof(o_region) * init->nregions;

  display_console("for regions table ");
  init->regions = (o_region *)bootloader_malloc(init->regionssz);
}
