/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /usr/home/ohmer/projects/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu michaud   [wed feb 15 14:09:17 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- defines ---------------------------------------------------------
 */

#define CONS_ADDR		0xb8000
#define CONS_SIZE		0xfa0
#define CONS_LINES		25
#define CONS_COLUMNS		80
#define CONS_BPC		2
#define CONS_TAB		8

#define CONS_FLI		(1 << 7)
#define CONS_INT		(1 << 3)

#define CONS_BLACK		0x0
#define CONS_BLUE		0x1
#define CONS_GREEN		0x2
#define CONS_CYAN		0x3
#define CONS_RED		0x4
#define CONS_MAGENTA		0x5
#define CONS_YELLOW		0x6
#define CONS_WHITE		0x7


#ifndef CONS_DEFAULT_ATTR
#define CONS_DEFAULT_ATTR CONS_FRONT(CONS_WHITE) | CONS_BACK(CONS_BLACK)
#endif

/*
 * ---------- macros ----------------------------------------------------------
 */

#define CONS_FRONT(_color_)	(_color_)
#define CONS_BACK(_color_)	(_color_ << 4)

/*
 * ---------- functions -------------------------------------------------------
 */

/*
** Kernel
*/
void			kaneton(t_init*				bootloader)
{
  char *chiche_vga = (char *) 0xB8000;
  char* header  = "Kernel:";
  char* canard1 = "       ,~~.";
  char* canard2 = "      (  ^ )   ";
  char* bec1    = "-_,";
  char* canard3 = " (\\___ )=='   ";
  char* bec2    = "-' ";
  char* canard4 = "  \\ .   ) )   ";
  char* canard5 = "   \\ `-' /    ";
  char* canard6 = "~'`~'`~'`~'`~  ";

  int i = 0;

  int j = 0;
  int where = 2 * (12 * 80 + 43);
  for (i = where; i < where + 14; i++, j++)
    if ((i % 2))
      chiche_vga[i] = CONS_FRONT(CONS_BLUE | CONS_INT);
    else
      chiche_vga[i] = *(header + (j / 2));

  j = 0;
  where = 2 * (14 * 80 + 43);
  for (i = where; i < where + 22; i++, j++)
    if ((i % 2))
      chiche_vga[i] = CONS_FRONT(CONS_YELLOW | CONS_INT);
    else
      chiche_vga[i] = *(canard1 + (j / 2));

  j = 0;
  where = 2 * (15 * 80 + 43);
  for (i = where; i < where + 30; i++, j++)
    if ((i % 2))
      chiche_vga[i] = CONS_FRONT(CONS_YELLOW | CONS_INT);
    else
      chiche_vga[i] = *(canard2 + (j / 2));

  j = 0;
  where = 2 * (16 * 80 + 43);
  for (i = where; i < where + 30; i++, j++)
    if ((i % 2))
      chiche_vga[i] = CONS_FRONT(CONS_YELLOW | CONS_INT);
    else
      chiche_vga[i] = *(canard3 + (j / 2));


  j = 0;
  where = 2 * (17 * 80 + 43);
  for (i = where; i < where + 30; i++, j++)
    if ((i % 2))
      chiche_vga[i] = CONS_FRONT(CONS_YELLOW | CONS_INT);
    else
      chiche_vga[i] = *(canard4 + (j / 2));


  j = 0;
  where = 2 * (18 * 80 + 43);
  for (i = where; i < where + 30; i++, j++)
    if ((i % 2))
      chiche_vga[i] = CONS_FRONT(CONS_YELLOW | CONS_INT);
    else
      chiche_vga[i] = *(canard5 + (j / 2));


  j = 0;
  where = 2 * (19 * 80 + 43);
  for (i = where; i < where + 30; i++, j++)
    if ((i % 2))
      chiche_vga[i] = CONS_FRONT(CONS_CYAN | CONS_INT);
    else
      chiche_vga[i] = *(canard6 + (j / 2));


  j = 0;
  where = 2 * (15 * 80 + 55);
  for (i = where; i < where + 6; i++, j++)
    if ((i % 2))
      chiche_vga[i] = CONS_FRONT(CONS_YELLOW);
    else
      chiche_vga[i] = *(bec1 + (j / 2));


  j = 0;
  where = 2 * (16 * 80 + 54);
  for (i = where; i < where + 6; i++, j++)
    if ((i % 2))
      chiche_vga[i] = CONS_FRONT(CONS_YELLOW);
    else
      chiche_vga[i] = *(bec2 + (j / 2));

  while (1)
    ;
}
