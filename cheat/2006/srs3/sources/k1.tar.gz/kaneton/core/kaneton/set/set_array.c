/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/set/set_array.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 24 19:50:54 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  subpart  of the  set  manager is  used  to  build array  data
 * structures.
 *
 * there  are two  way  to use  the  arrays :  with  pointers or  with
 * objects.    the  first   method   is  the   default  one   (without
 * SET_OPT_ALLOC) : it only  stores pointers refering to objects.  The
 * second method (used with  SET_OPT_ALLOC) makes copies of objects in
 * the set,  using memcpy. with  SET_OPT_FREE, objects are  freed when
 * they   are  removed   from  the   array  or   when  the   array  is
 * flushed/released.
 *
 * the option ORGANISE is used to keep the array as small as possible,
 * but  some operation  requires to  shift entire  parts of  the array
 * (loss of performances).
 *
 * when an array set is cloned, data are reorganised in. it means than
 * when a  clone operation occurs,  the array is reduced  clearing the
 * empty/unused places.
 *
 * options:    SET_OPT_CONTAINER,    SET_OPT_SORT,   SET_OPT_ORGANISE,
 * SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire array data structure.
 *
 * this data structure is very useful to contain very little objects like
 * identifiers.
 *
 * the address space objects, the task objects etc.. use it widely.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

