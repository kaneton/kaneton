/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /usr/home/ohmer/projects/kaneton/core/bootloader/arch/machdep/bootloader.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu michaud   [wed feb 15 13:24:15 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the bootloader is to install a correct environment for
 * the kernel.
 *
 * the first thing to do is to relocate the different kaneton data structure
 * in order to build the t_init structure. this structure must contain
 * everything the kernel will need.
 *
 * for more information on the relocating, take a look to the kaneton
 * paper which describes the entire kaneton reference.
 *
 * once the init structure was built, the kernel has to be launched.
 *
 * nevertheless, the kernel needs to evolve with the protected mode and
 * paging mode activated, so the bootloader first has to install these.
 *
 * printing some messages is interesting showing the protected mode and
 * paging mode are correctly installed.
 *
 * after all, the bootloader has launch the kernel binary.
 *
 * look at the ld scripts to know where the kernel has to be loaded.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * these three variable are globals to avoid them to be lost when the
 * bootloader changes its stack.
 *
 * indeed, before jumping on the kernel a new stack is created so the local
 * variables will no longer be accessible. putting these variables in
 * globals bypass this problem.
 */

void			(*kernel)(t_init*);

t_reg32			ebp;
t_reg32			esp;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
** main bootloader fonction
*/
int			bootloader(t_uint32			magic,
				   multiboot_info_t*		mbi)
{
  cons_setup(); //init the console
  cons_clean(CONS_DEFAULT_ATTR); //clean it
  cons_printf(0,32,"%#..::%#KANETON%#::..%#",
	      CONS_FRONT(CONS_YELLOW | CONS_INT),
	      CONS_FRONT(CONS_RED | CONS_INT) ,
	      CONS_FRONT(CONS_YELLOW | CONS_INT),
	      CONS_DEFAULT_ATTR);

  cons_printf(3,43,"%#Steps:%#",
	      CONS_FRONT(CONS_BLUE | CONS_INT),
	      CONS_DEFAULT_ATTR);

  //set GDT
  cons_printf(4,43,"Setting GDT");
  cons_printf(4,60,"[%#KO%#]",CONS_FRONT(CONS_RED | CONS_INT), CONS_DEFAULT_ATTR);
  gdt_init(computeGDTAdress(mbi));
  cons_printf(4,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);

  //initialize t_init
  //relocating datas
  cons_printf(5,43,"Setting Init          ");
  cons_printf(5,60,"[%#KO%#]",CONS_FRONT(CONS_RED | CONS_INT), CONS_DEFAULT_ATTR);
  initTask(mbi);
  cons_printf(5,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);

  //paggin
  cons_printf(6,43,"Setting Paging        ");
  cons_printf(6,60,"[%#KO%#]",CONS_FRONT(CONS_RED | CONS_INT), CONS_DEFAULT_ATTR);

  unsigned int pd_addr= computePDAdress(mbi);
  pd_new((void*) pd_addr);
  pt_init(0, pd_addr + PAGESZ);			//first 4M
  pt_init(0x1000, pd_addr + 5 * PAGESZ);	//4M from 0x1000000
  paging_enable((void*) pd_addr);
  cons_printf(6,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);

  //init stack
  // (MUST be done directly in the fonction)
  cons_printf(7,43,"Setting KStack         ");
  cons_printf(7,60,"[%#KO%#]",CONS_FRONT(CONS_RED | CONS_INT), CONS_DEFAULT_ATTR);
  t_reg32* stack_save  = (t_reg32*) (init->kstack + init->kstacksz);
  stack_save--;
  *stack_save = ebp;
  stack_save--;
  *stack_save = esp;
  stack_save--;
  ebp = *((t_reg32*) (init->kstack + init->kstacksz));
  esp = *((t_reg32*) (stack_save));
  cons_printf(7,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);

  //calling kernel
  // (use the elf header to retrieve the entry point addresse)
  cons_printf(8,43,"calling Kernel       ");
  void** tmp = (void**)(init->kcode + 0x18);
  kernel = *tmp;
  cons_printf(8,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);
  kernel(init);

  //SI RETOUR : branler un message d'erreur
  // (ecran bleu, un peu windows style ...
  cons_clean(CONS_FRONT(CONS_CYAN) | CONS_BACK(CONS_CYAN));
  cons_printf(15, 34, "%#Kaneton error%#",
	      CONS_FRONT(CONS_BLUE | CONS_INT) | CONS_BACK(CONS_RED),
	      CONS_DEFAULT_ATTR);

  for(;;);

  return (0);
}

/*
** test the console
** code by Ohmer
*/
void			test_console(void)
{
  int i;

  cons_setup();

#define INT_MAX 2000000

  for (;;)
    {
      cons_clean(CONS_DEFAULT_ATTR);
      for (i = 0; i < INT_MAX; ++i);

      cons_printf(0, 0, "test 0x0");
      for (i = 0; i < INT_MAX; ++i);

      cons_printf(5, 7, "normal %#red on blue%# normal",
		  CONS_FRONT(CONS_RED) | CONS_BACK(CONS_BLUE),
		  CONS_DEFAULT_ATTR);

      cons_printf(23, 76, "test@23x76");

      cons_printf(16, 20, "test line 1\r\n test line 2");

      cons_printf(3, 3, "test 3x3");
      for (i = 0; i < INT_MAX; ++i);

      cons_printf(100, 20, "test 100x20");
      for (i = 0; i < INT_MAX; ++i);

      cons_clean(CONS_FRONT(CONS_BLUE) | CONS_BACK(CONS_BLUE));
      for (i = 0; i < INT_MAX; ++i);
    }
}
