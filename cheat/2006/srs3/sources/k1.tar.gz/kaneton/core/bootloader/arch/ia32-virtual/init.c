/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/bootloader/arch/ia32-virtual/init.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       matthieu bucchianeri   [tue jan 17 22:24:35 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this file contains the functions intended to do the relocation.
 *
 * this file is very important because it does the most important things
 * of the bootloader: computes segments and regions, relocates data, creates
 * the init structure etc..
 *
 * the relocation is based on dynamic allocation. nevertheless, no dynamic
 * allocation is provided. the student so has to setup a very simple dynamic
 * memory allocation algorithm to be able to build the init structure.
 *
w * think about it because some components cannot have a dynamic address. there
 * are some crazy problems to resolve in this context.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * init variable, describing the initial memory layout.
 *
 * this structure will be passed to the kernel describing modules,
 * physical memory reserved by the hardware etc.. thus the kernel will
 * be able to initialise its managers: segment manager, module manager etc..
 */
t_init*			init;

/*
** added by moon
** the current adresse in the memory
** starting @ 0x1000000 (16M)
*/
int			cur_addr = INIT_RELOCATE;


/*
 * ---------- functions -------------------------------------------------------
 */

// All code has been Added by Moon

//////////////////////////////////////////////////////////////////////////
//Note importante From Moon :						//
//									//
//	Les sizes sont la taille effectives des structures et pas	//
// le nombre de pages.							//
//	Pour calculer le nombre de page : utiliser computeNPage(size)	//
//									//
//////////////////////////////////////////////////////////////////////////

/*
** call the other init task
*/
void			initTask(multiboot_info_t*	mbi)
{
  module_t*		mod;

  mod = (module_t*) mbi->mods_addr;

  //compute de la place de la ou init doit etre
  void * tmp = (void *) INIT_RELOCATE + PAGESZ * (computeNPage(getKernelSz(mbi->mods_addr)));
  init = (t_init*) tmp;

  // initialize t_init structure
  initializeInit(mbi);

  // copy kernel code
  copyTo(mod->mod_start, init->kcode, init->kcodesz);

  // relocate modules from grub's one to kaneton one
  relocateModules(mbi);

  // relocate segments
  createSegmentsArray(mbi);

  // relocate regions
  createRegionArray(mbi);

  // nothing to do to init stack now

  // nothing to do for the alloc zone

}

/*
** copy from "from" to "to" on "size" words
*/
void			copyTo(unsigned int		from,
			       unsigned int		to,
			       unsigned int		size)
{
  int	i;
  char*	fromstr = (char*) from;
  char* tostr = (char*) to;

  for (i = 0; i < size / sizeof(char); ++i)
    {
      tostr[i] = fromstr[i];
    }
}

/*
** Filling the init structure
** based on the multiboot_info
*/
void			initializeInit(multiboot_info_t*	mbi)
{
  cons_printf(3,0,"%#Dump of t_init:%#",
	      CONS_FRONT(CONS_BLUE | CONS_INT),
	      CONS_DEFAULT_ATTR,
	      init);

  init->mem		= (t_paddr) mbi->mem_lower;
  init->memsz		= (t_psize) mbi->mem_upper - mbi->mem_lower;
  cons_printf(4,0,"mem          0x%p", init->mem);
  cons_printf(5,0,"memsz        0x%x", init->memsz);

  init->kcodesz		= getKernelSz(mbi->mods_addr);		//TO CHECK
  init->kcode		= allocPage(init->kcodesz);
  cons_printf(6,0,"kcode        0x%p", init->kcode);
  cons_printf(7,0,"kcodesz      0x%x", init->kcodesz);

  init->initsz		= sizeof(*init);
  init->init		= allocPage(init->initsz);
  cons_printf(8,0,"init         0x%p", init->init);
  cons_printf(9,0,"initsz       0x%x", init->initsz);

  init->modulessz	= computeModulesSz(mbi);		//TO CHECK
  init->modules		= (t_modules*)allocPage(init->modulessz);
  cons_printf(10,0,"modules      0x%p", init->modules);
  cons_printf(11,0,"modulessz    0x%x", init->modulessz);

  init->nsegments	= INIT_SEGMENTS;
  init->segmentssz	= INIT_SEGMENTS * sizeof(o_segment);	//TO CHECK
  init->segments	= (o_segment*)allocPage(init->segmentssz);
  cons_printf(12,0,"nsegments    %d", init->nsegments);
  cons_printf(13,0,"segments     0x%p", init->segments);
  cons_printf(14,0,"segmentssz   0x%x", init->segmentssz);

  init->nregions	= INIT_REGIONS;
  init->regionssz	= INIT_REGIONS * sizeof(o_region);	//TO CHECK
  init->regions		= (o_region*)allocPage(init->regionssz);
  cons_printf(15,0,"nregions     %d", init->nregions);
  cons_printf(16,0,"regions      0x%p", init->regions);
  cons_printf(17,0,"regionssz    0x%x", init->regionssz);

  init->kstacksz	= INIT_KSTACKSZ;			//From file
  init->kstack		= allocPage(init->kstacksz);
  cons_printf(18,0,"kstack       0x%p", init->kstack);
  cons_printf(19,0,"kstacksz     0x%x", init->kstacksz);

  init->allocsz		= 16 * PAGESZ;				//From K1.pdf
  init->alloc		= allocPage(init->allocsz);
  cons_printf(20,0,"alloc        0x%p", init->alloc);
  cons_printf(21,0,"allocsz      0x%x", init->allocsz);

  allocPage(PAGESZ);						//FOR the Gdt
}

/*
** compute the address of the GDT
*/
unsigned int		computeGDTAdress(multiboot_info_t*	mbi)
{
  unsigned int		res = 0;

  res =  INIT_RELOCATE;
  res += computeNPage(getKernelSz(mbi->mods_addr)) * PAGESZ;
  res += computeNPage(sizeof(t_init)) * PAGESZ;
  res += computeNPage(computeModulesSz(mbi)) * PAGESZ;
  res += computeNPage(INIT_SEGMENTS * sizeof(o_segment)) * PAGESZ;
  res += computeNPage(INIT_REGIONS * sizeof(o_region)) * PAGESZ;
  res += computeNPage(INIT_KSTACKSZ) * PAGESZ;
  res += 16 * PAGESZ;

  return res;
}

/*
** compute the address of the PD
*/
unsigned int		computePDAdress(multiboot_info_t*	mbi)
{
  unsigned int		res = 0;

  res = computeGDTAdress(mbi) + PAGESZ;

  return res;
}

/*
** compute modulessz
** based on the multiboot_info
*/
int			computeModulesSz(multiboot_info_t*	mbi)
{
  int			globalSize;
  int			i;
  module_t*		mod = (module_t*) mbi->mods_addr;

  globalSize = sizeof(t_modules);

  ++mod;					// premier module : kernel

  for (i = 1; i < mbi->mods_count; ++i)
    {
      ++mod;
      globalSize += sizeof(t_module);			//header
      globalSize += mod->mod_end - mod->mod_start;	//data
      globalSize += strlen((char*) mod->string);	//name
      ++globalSize;					// \0
    }

  return globalSize;
}

/*
** copy grub modules to kaneton modules
*/
void			relocateModules(multiboot_info_t*	mbi)
{
  int			i;
  int			size;
  unsigned int		current;
  module_t*		grubMod;
  t_module*		kanMod;
  t_modules*		headerKanMod;

  grubMod = (module_t*) mbi->mods_addr;

  headerKanMod = init->modules;
  headerKanMod->nmodules = mbi->mods_count - 1;
  current = (unsigned int) ++headerKanMod;

  ++grubMod; // skip kernel's module

  for (i = 1; i < mbi->mods_count; ++i)
    {
      ++grubMod;

      // allocPageating  header
      kanMod = (t_module*) current;
      current += sizeof(t_module);

      // copying data
      size = grubMod->mod_end -grubMod->mod_start;
      copyTo(grubMod->mod_start, current, size);
      current += size;

      // copying name;
      size = strlen((char*) grubMod->string);
      copyTo(grubMod->string, current, size);

      // setting kanMod
      kanMod->size = size;
      kanMod->name = (char*) current;

      // finalizing
      current += size;
      current = '\0';
      current += sizeof(char);
    }
}

/*
** Create the o_segments
** Loading from the init struct
**
** PERMS CAN BE A SOURCE OF BUG !
**
** (note from Moon : perms setter par raisonnement rapide)
** (=> je suis sur de rien :D {d'ou les TO CHECK}	 )
*/
void			createSegmentsArray(multiboot_info_t*	mbi)
{
  o_segment*		current;

  current = init->segments;

  // Segment NULL
  current->address = 0;
  current->size = PAGESZ;
  current->perms = 0;
  ++current;

  // Segment ISA
  current->address = PAGESZ;
  current->size = 0x0100000 - PAGESZ;
  current->perms = PERM_READ;			//TO CHECK
  ++current;

  // Segment Kernel
  current->address = init->kcode;
  current->size = init->kcodesz;
  current->perms = PERM_READ | PERM_EXEC;	//TO CHECK
  ++current;

  // Segment init
  current->address = init->init;
  current->size = init->initsz;
  current->perms = PERM_READ;			//TO CHECK
  ++current;

  // Segment Modules
  current->address = (t_paddr) init->modules;
  current->size = init->modulessz;
  current->perms = PERM_READ | PERM_EXEC;	//TO CHECK
  ++current;

  // Segment Segments
  current->address = (t_paddr) init->segments;
  current->size = init->segmentssz;
  current->perms = PERM_READ;			//TO CHECK
  ++current;

  // Segment Regions
  current->address = (t_paddr) init->regions;
  current->size = init->regionssz;
  current->perms = PERM_READ;			//TO CHECK
  ++current;

  // Segment Kernel Stack
  current->address = init->kstack;
  current->size = init->kstacksz;
  current->perms = PERM_READ | PERM_WRITE;	//TO CHECK
  ++current;

  // Segment AllocPage
  current->address = init->alloc;
  current->size = init->allocsz;
  current->perms = PERM_READ | PERM_WRITE;	//TO CHECK
  ++current;

  // Segment GDT
  current->address = computeGDTAdress(mbi);
  current->size = PAGESZ;
  current->perms = PERM_READ;			//TO CHECK
  ++current;

  // Segment PD
  current->address = computeGDTAdress(mbi) + PAGESZ;
  current->size = 5 * PAGESZ;			//TO CHECK
  current->perms = PERM_READ | PERM_WRITE;	//TO CHECK
  ++current;
}

/*
** Create the o_region
** init from the the init structure
*/
void			createRegionArray(multiboot_info_t*	mbi)
{
  o_region*		current;

  current = init->regions;

  // Region ISA
  current->address = PAGESZ;
  current->size = 0x0100000 - PAGESZ;
  current->offset = 0;
  ++current;

  // region Kernel
  current->address = init->kcode;
  current->size = init->kcodesz;
  current->offset = 0;
  ++current;

  // Region init
  current->address = init->init;
  current->size = init->initsz;
  current->offset = 0;
  ++current;

  // Region Kernel Stack
  current->address = init->kstack;
  current->size = init->kstacksz;
  current->offset = 0;
  ++current;

  // Region AllocPage
  current->address = init->alloc;
  current->size = init->allocsz;
  current->offset = 0;
  ++current;

  // Region GDT
  current->address = computeGDTAdress(mbi);
  current->size = PAGESZ;
  current->offset = 0;
  ++current;

  // Region PD
  current->address = computeGDTAdress(mbi) + PAGESZ;
  current->size = 5 * PAGESZ;					//FIXME
  current->offset = 0;
  ++current;
}

/*
** get the kernel's grub module size
** param mods_addr est le champ mods_addr de mbi
*/
int			getKernelSz(unsigned int		mods_addr)
{
  module_t*		mod;

  mod = (module_t*) mods_addr;
  return (mod->mod_end - mod->mod_start);
}

/*
** Compute the humber of page required for a size
*/
int			computeNPage(int			size)
{
  int npages = size / PAGESZ;

  if (size % PAGESZ != 0)
    ++npages;

  return npages;
}

/*
** return the adresse of the memory tu use
** size = number of bits needed
*/
int			allocPage(int				size)
{
  int cur = cur_addr;

  cur_addr += PAGESZ * computeNPage(size);

  return cur;
}
