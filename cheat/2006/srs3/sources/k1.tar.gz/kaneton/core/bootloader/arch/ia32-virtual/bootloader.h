/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /usr/home/ohmer/projects/kaneton/core/bootloader/arch/ia32-virtual/bootloader.h
 *
 * created       julien quintard   [fri feb 11 02:23:53 2005]
 * updated       matthieu michaud   [wed feb 15 14:09:04 2006]
 */

#ifndef BOOTLOADER_H
#define BOOTLOADER_H		1

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      bootloader.c
 *      cons.c
 *      init.c
 *      paging.c
 *      pmode.c
 */

/*
 * bootloader.c
 */

int			bootloader(t_uint32			magic,
				   multiboot_info_t*		mbi);

void			test_console(void);


/*
 * cons.c
 */

int				 cons_printf_char(char c);

void				 cons_printf_attr(unsigned char attr);

void				 cons_setup(void);

void				 cons_clean(unsigned char attr);

int				 cons_printf(unsigned char row, unsigned char col, const char *fmt, ...);


/*
 * init.c
 */

void			initTask(multiboot_info_t*	mbi);

void			copyTo(unsigned int		from,
			       unsigned int		to,
			       unsigned int		size);

void			initializeInit(multiboot_info_t*	mbi);

unsigned int		computeGDTAdress(multiboot_info_t*	mbi);

unsigned int		computePDAdress(multiboot_info_t*	mbi);

int			computeModulesSz(multiboot_info_t*	mbi);

void			relocateModules(multiboot_info_t*	mbi);

void			createSegmentsArray(multiboot_info_t*	mbi);

void			createRegionArray(multiboot_info_t*	mbi);

int			getKernelSz(unsigned int		mods_addr);

int			computeNPage(int			size);

int			allocPage(int				size);


/*
 * paging.c
 */


/*
 * pmode.c
 */


/*
 * eop
 */

#endif
