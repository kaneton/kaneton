/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/bootloader/arch/ia32-virtual/cons.c
 *
 * created       julien quintard   [sat may 28 18:23:13 2005]
 * updated       matthieu michaud   [tue feb 14 00:02:12 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the student has to fill in this file just to be able to print some
 * debug messages.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * the console variable.
 */

t_cons			cons;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * declare a console usable t_printf_char_fn callback ...
 */
int				 cons_printf_char(char c)
{
  unsigned		 offs = cons.line * CONS_COLUMNS + cons.column;

  if (offs > CONS_COLUMNS * CONS_LINES)
	 return 1;
  (*cons.vga)[offs].character = c;
  (*cons.vga)[offs].attribute = cons.attr;
  ++cons.column;
  return 0;
}

/*
 * ... and a t_printf_attr_fn
 */
void				 cons_printf_attr(unsigned char attr)
{
  cons.attr = attr;
}

void				 cons_setup(void)
{
  /* hide cursor */
  outb(0x0a, 0x3d4);
  outb(1 << 5, 0x3d5);

  /* init memory struct */
  cons.attr = CONS_DEFAULT_ATTR;
  cons.vga = (volatile t_cons_vga*)CONS_ADDR;

  /* init klibc printf */
  printf_init(cons_printf_char, cons_printf_attr);
}


void				 cons_clean(unsigned char attr)
{
  int i;

  for (i = 0; i < CONS_LINES * CONS_COLUMNS; ++i) {
	 (*cons.vga)[i].character = 0;
	 (*cons.vga)[i].attribute = attr;
  }
}

int				 cons_printf(unsigned char row, unsigned char col, const char *fmt, ...)
{
  unsigned int	 written;
  va_list args;

  cons.line = row;
  cons.column = col;

  va_start(args, fmt);
  written = vprintf(fmt, args);
  va_end(args);

  return written;
}
