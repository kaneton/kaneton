/*
 * licence       
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/include/arch/machdep/kaneton/kaneton.h
 *
 * created       julien quintard   [sat dec 17 17:13:18 2005]
 * updated       matthieu michaud   [mon feb 13 23:32:29 2006]
 */

#ifndef IA32_KANETON_KANETON_H
#define IA32_KANETON_KANETON_H	1

/*
 * ---------- defines ---------------------------------------------------------
 */

#define ___endian		ENDIAN_LITTLE
#define ___wordsz		WORDSZ_32

#define PAGESZ			4096


/* This macro allows to write to an I/O port */
#define outb(value, port)                                       \
  __asm__ volatile (                                            \
        "outb %b0,%w1"                                          \
        ::"a" (value),"Nd" (port)                               \
        )                                                       \

// read one byte from port
#define inb(port)                                               \
({                                                              \
  unsigned char _v;                                             \
  __asm__ volatile (                                            \
        "inb %w1,%0"                                            \
        :"=a" (_v)                                              \
        :"Nd" (port)                                            \
        );                                                      \
  _v;                                                           \
})


/*
 * ---------- includes --------------------------------------------------------
 */

#include <arch/machdep/kaneton/as.h>
#include <arch/machdep/kaneton/debug.h>
#include <arch/machdep/kaneton/init.h>
#include <arch/machdep/kaneton/region.h>
#include <arch/machdep/kaneton/segment.h>
#include <arch/machdep/kaneton/stats.h>
#include <arch/machdep/kaneton/task.h>

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../../../kaneton/arch/machdep/as.c
 *      ../../../../kaneton/arch/machdep/region.c
 *      ../../../../kaneton/arch/machdep/segment.c
 *      ../../../../kaneton/arch/machdep/task.c
 */

/*
 * ../../../../kaneton/arch/machdep/as.c
 */


/*
 * ../../../../kaneton/arch/machdep/region.c
 */


/*
 * ../../../../kaneton/arch/machdep/segment.c
 */


/*
 * ../../../../kaneton/arch/machdep/task.c
 */


/*
 * eop
 */

#endif
