/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/pmode/gdt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:45:19 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:57:21 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage global descriptor table.
 *
 */


/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have  to place here code to manage  gdt. there are no
 * restrictions on prototypes, names etc.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

//followed added by PY

/*
 * defines
 */

#define GDT_ADDR 0x20000
#define GDT_SIZE 256

// flags
#define GDT_AVAILABLE 0x1
#define GDT_USE32 0x4
#define GDT_GRANULAR 0x8

//type
#define GDT_VALID 0x80
#define GDT_DPL3 0x60
#define GDT_DPL2 0x40
#define GDT_DPL1 0x20
#define GDT_DPL0 0x00
#define GDT_SYST 0x10
#define GDT_CODE 0x0a
#define GDT_DATA 0x02

typedef struct                  s_gdt_segment
{
  unsigned short                limit_00_15;
  unsigned short                base_00_15;
  unsigned char                 base_16_23;
  unsigned char                 type;
  /*  type:
   *  bit 0: segment accessed, set by processor
   *  bit 1-3: segment type (r/w data=001, code=101)
   *  bit 4: 0=system, 1=user
   *  bit 5-6: DPL
   *  bit 7: 1=segment is valid
   */
  unsigned char                 limit_16_19 : 4;
  unsigned char                 flags : 4;
  /* flags:
   * bit 0: available
   * bit 1: reserved
   * bit 2: 32 bits mode
   * bit 3: granularity (0= 1b -> 1Mb, 1= 4Kb -> 4Gb)
   */
  unsigned char                 base_24_31;
}                               __attribute__ ((packed)) t_gdt;

typedef struct                  s_gdtr
{
  unsigned short                size;
  unsigned int                  address;
}                               __attribute__ ((packed)) t_gdtr;


t_gdt* gdt;
unsigned short entry = 0;

static t_gdtr gdtr;
static unsigned short cs;
static unsigned short ds;
static unsigned short ucs;
static unsigned short uds;

/*
 * ---------- functions -------------------------------------------------------
 */


//set up a new gdt segment


unsigned short	gdt_new_segment(unsigned int base, unsigned int limit,
				unsigned char type, unsigned char flags)
{
  ++entry;
  gdt[entry].limit_00_15 = limit & 0xffff;
  limit >>= 16;
  gdt[entry].limit_16_19 = limit & 0x0f;
  gdt[entry].base_00_15 = base & 0xffff;
  base >>= 16;
  gdt[entry].base_16_23 = base & 0xff;
  base >>= 8;
  gdt[entry].base_24_31 = base;
  gdt[entry].type = type;
  gdt[entry].flags = flags & 0x0f;
  return entry;
}

void		gdt_del_segment(unsigned int entry)
{
  memset(gdt + entry, 0x0, sizeof (t_gdt));
}

static void	gdt_update_cpu_segments(unsigned int new_code,
					unsigned int new_data)
{
  asm volatile ("pushl %0\n"
		"pushl $cs_jump\n"
		"lret\n"
		"cs_jump:\n"
		"mov %1, %%eax\n"
		"mov %%ax, %%ds\n"
		"mov %%ax, %%es\n"
		"mov %%ax, %%fs\n"
		"mov %%ax, %%gs\n"
		"mov %%ax, %%ss"
		: : "g" (new_code), "g" (new_data));
}

void		gdt_init(unsigned int gdt_addr)
{
  gdt = (t_gdt*) gdt_addr;

  memset(gdt, 0x0, GDT_SIZE * sizeof (t_gdt));
  gdtr.address = (unsigned int)gdt;
  gdtr.size = GDT_SIZE;

  gdt_new_segment(0x0, 0x0, 0x0, 0x0); //first null entry

  cs = gdt_new_segment(0x0, 0xfffff,
		       GDT_CODE | GDT_SYST | GDT_VALID,
		       GDT_GRANULAR | GDT_USE32);
  ds = gdt_new_segment(0x0, 0xfffff,
		       GDT_DATA | GDT_SYST | GDT_VALID,
		       GDT_GRANULAR | GDT_USE32);
  ucs = gdt_new_segment(0x0, 0xfffff,
			GDT_CODE | GDT_SYST | GDT_VALID,
			GDT_GRANULAR | GDT_USE32);
  uds = gdt_new_segment(0x0, 0xfffff,
			GDT_DATA | GDT_SYST | GDT_VALID,
			GDT_GRANULAR | GDT_USE32);

  asm volatile("cli\n"
	       "lgdt %0":: "m" (gdtr));
  asm ("mov %cr0,%eax\n"
       "or $1, %ax\n"
       "mov %eax, %cr0");

  gdt_update_cpu_segments(cs * 8, ds * 8);
}

unsigned short get_kernel_code_segment(void)
{
  return (cs * 8);
}

unsigned short get_kernel_data_segment(void)
{
  return (ds * 8);
}
