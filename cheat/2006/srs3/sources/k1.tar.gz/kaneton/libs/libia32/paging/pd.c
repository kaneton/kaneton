/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/pd.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:20 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:53:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page directory.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this    file   is    destinated   to    functions    dealing   with
 * page-directories. there are no restrictions about function names or
 * prototype, so feel free.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */

/*
** creer la pd
*/

void	pd_new(void        *pd_addr)
{
  t_pd_entry* page_dir;

  page_dir = (t_pd_entry*)pd_addr;

  pd_add_entry(pd_addr + 1 * PAGESZ, PDE_SYSTEM, PDE_RW, page_dir + 0);
  pd_add_entry(pd_addr + 5 * PAGESZ, PDE_SYSTEM, PDE_RW, page_dir + 4);
}


/*   31	       	       	       	       	 12    	8 7 6 5	4 3 2 1	0
 *  +------------------------------------------------------------+
 *  |                                      |   | | | | | | | | | |
 *  |                                      | A | |P| | |P|P|U|R| |
 *  |           Page Table Address         | V |G|G|0|A|C|W|\|\|P|
 *  |                                      | L | |S| | |D|T|S|W| |
 *  |  	       	       	       	       	   |   | | | | | | | | | |
 *  +------------------------------------------------------------+
 */

/*
** Ajouter une entree
*/

void	pd_add_entry(void *addr, char user, char perm, t_pd_entry *ent)
{
  unsigned int flags = 0x301;
  flags |= user << 2;
  flags |= perm << 1;

  unsigned int* tmp;
  tmp = (unsigned int *) ent;
  *tmp = (unsigned int) addr;
  *tmp |= flags;
}
