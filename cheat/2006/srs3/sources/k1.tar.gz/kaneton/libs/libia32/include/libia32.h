/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/libia32.h
 *
 * created       matthieu bucchianeri   [tue dec 20 13:58:56 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:15:42 2006]
 */

#ifndef LIBIA32_H
#define LIBIA32_H

/*
 * ---------- includes --------------------------------------------------------
 */

#include "misc/asm.h"
#include "misc/isa.h"
#include "misc/multiboot.h"
#include "misc/stdarg.h"
#include "misc/types.h"
#include "paging/paging.h"
#include "pmode/pmode.h"

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../pmode/pmode.c
 *      ../pmode/gdt.c
 *      ../pmode/ldt.c
 *      ../paging/paging.c
 *      ../paging/pd.c
 *      ../paging/pt.c
 *      ../paging/tlb.c
 *      ../interrupt/interrupt.c
 *      ../interrupt/idt.c
 */

/*
 * ../pmode/pmode.c
 */


/*
 * ../pmode/gdt.c
 */

unsigned short	gdt_new_segment(unsigned int base, unsigned int limit,
				unsigned char type, unsigned char flags);

void		gdt_del_segment(unsigned int entry);

void		gdt_init(unsigned int gdt_addr);

unsigned short get_kernel_code_segment(void);

unsigned short get_kernel_data_segment(void);


/*
 * ../pmode/ldt.c
 */


/*
 * ../paging/paging.c
 */

void	paging_enable(void *pd_addr);

int	get_pt_entry(unsigned int addr);

int	get_pd_entry(unsigned int addr);


/*
 * ../paging/pd.c
 */

void	pd_new(void        *pd_addr);

void	pd_add_entry(void *addr, char user, char perm, t_pd_entry *ent);


/*
 * ../paging/pt.c
 */

void	pt_init(unsigned int from, unsigned int pt_addr);

void	pt_add_entry(unsigned int page_addr, char user, char perm, unsigned int addr);


/*
 * ../paging/tlb.c
 */


/*
 * ../interrupt/interrupt.c
 */


/*
 * ../interrupt/idt.c
 */


/*
 * eop
 */

#endif
