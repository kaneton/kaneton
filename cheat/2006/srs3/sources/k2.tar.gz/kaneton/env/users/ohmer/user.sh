#!/bin/sh
## licence       kaneton licence
##
## project       kaneton
##
## file          /home/ohmer/projects/kaneton/env/users/ohmer/user.sh
##
## created       matthieu bucchianeri   [tue dec 13 21:02:30 2005]
## updated       matthieu michaud   [wed feb 15 14:16:07 2006]
##

#
# ---------- information ------------------------------------------------------
#
# this file contains specific user shell variables, functions etc..
#

#
# VIEW
#
# this function opens and displays a document.
#
view()
{
  document=$1

  evince $document
}
