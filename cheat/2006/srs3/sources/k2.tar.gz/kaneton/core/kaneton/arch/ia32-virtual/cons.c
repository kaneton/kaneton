/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/kaneton/arch/machdep/cons.c
 *
 * created       julien quintard   [sat may 28 18:23:13 2005]
 * updated       matthieu michaud   [wed mar 29 00:52:07 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the student has to fill in this file just to be able to print some
 * debug messages.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the console variable.
 */

t_cons			kcons;

/*
 * ---------- functions -------------------------------------------------------
 */

/* static void		 kcons_get_cursor(unsigned char* row, unsigned char* col) */
/* { */
/*   outb(CRT_REG_INDEX, 0x0e); */
/*   *row = inb(CRT_REG_DATA); */
/*   outb(CRT_REG_INDEX, 0x0f); */
/*   *col = inb(CRT_REG_DATA); */
/* } */

#if !defined(BOCHS_HACK)
static void		 kcons_set_cursor(unsigned char row, unsigned char col)
{
  outb(CRT_REG_INDEX, 0x0e);
  outb(CRT_REG_DATA, row);
  outb(CRT_REG_INDEX, 0x0f);
  outb(CRT_REG_DATA, col);
}


/* static void		 kcons_show_cursor(void) */
/* { */
/*   outb(CRT_REG_INDEX, 0x0a); */
/*   outb(CRT_REG_DATA, 0 << 5); */
/* } */

static void		 kcons_hide_cursor(void)
{
  outb(CRT_REG_INDEX, 0x0a);
  outb(CRT_REG_DATA, 1 << 5);
}

/*
 * scroll one line down
 */
static void		 kcons_scroll_up(void)
{
  int i;

  for (i = 0; i < CONS_COLUMNS * (CONS_LINES - 1); ++i) {
	 (*kcons.vga)[i].character = (*kcons.vga)[i + CONS_COLUMNS].character;
	 (*kcons.vga)[i].attribute = (*kcons.vga)[i + CONS_COLUMNS].attribute;
  }
  for (; i < CONS_COLUMNS * CONS_LINES; ++i) {
	 (*kcons.vga)[i].character = 0;
	 (*kcons.vga)[i].attribute = kcons.attr;
  }
}

/*
 * clear all screen
 */
void				 kcons_clear(unsigned char attr)
{
  int i;

  for (i = 0; i < CONS_LINES * CONS_COLUMNS; ++i) {
	 (*kcons.vga)[i].character = 0;
	 (*kcons.vga)[i].attribute = attr;
  }
  kcons.column = kcons.line = 0;
  kcons_set_cursor(kcons.line, kcons.column);

}
#endif

/*
 * init the console
 */
void				 kcons_setup(void)
{
  /* init klibc printf */
  printf_init(kcons_printf_char, kcons_printf_attr);
  
  /* init memory struct */
  kcons.attr = CONS_DEFAULT_ATTR;
  kcons.vga = (volatile t_cons_vga*)CONS_ADDR;

#if !defined(BOCHS_HACK)
  kcons_hide_cursor();
  kcons_clear(CONS_DEFAULT_ATTR);
#endif
}

/*
 * declare a console usable t_printf_char_fn callback ...
 */
int				 kcons_printf_char(char c)
{
#if defined(BOCHS_HACK)
  outb(BOCHS_PORT, c);
#else
  int				 i;

  switch (c) {
  case '\b':
	 if (kcons.column > 0) {
		--kcons.column;
		kcons_printf_char(' ');
	 }
	 break;
  case '\n':
	 kcons.column = 0;
	 ++kcons.line;
	 if (kcons.line > 24) {
		kcons_scroll_up();
		--kcons.line;
	 }
	 break;
  case '\r':
	 kcons.column = 0;
	 break;
  case '\t':
	 for (i = 0; i < CONS_TAB; ++i)
		kcons_printf_char(' ');
	 break;
  default:
	 i = kcons.line * CONS_COLUMNS + kcons.column;

	 (*kcons.vga)[i].character = c;
	 (*kcons.vga)[i].attribute = kcons.attr;	 

	 ++kcons.column;
	 if (kcons.column > 79) {
		kcons.column = 0;
		++kcons.line;
	 }
	 if (kcons.line > 24) {
		kcons.column = 0;
		kcons_scroll_up();
		--kcons.line;
	 }
  }
#endif
  return 0;
}

/*
 * ... and a t_printf_attr_fn
 */
void				 kcons_printf_attr(unsigned char attr)
{
#if !defined(BOCHS_HACK)
  kcons.attr = attr;
#endif
}


/*
 * printf on kernel console
 */
int				 kcons_printf(const char *fmt, ...)
{
  unsigned int	 written;
  va_list args;

  va_start(args, fmt);
  written = vprintf(fmt, args);
  va_end(args);

  return written;
}


