/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/kaneton/segment/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu michaud   wed mar 29 16:10:29 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the segment manager manages physical memory.
 *
 * it  is  able   to  reserve  and  release  memory   areas  (see  the
 * segment-fit.c for  allocation algorithm)  and to operated  on these
 * area: resize, split, copy, etc.
 *
 * a segment  is identified by  a 64 bits identifier  corresponding to
 * its physical  address. so  it is easy  to retrieve  this identifier
 * given the base address of a segment.
 *
 * remember  that  segments are  global:  there  is  only one  set  of
 * segments objects for  the entire kernel. the set  of segments in an
 * address space is just a set of identifiers.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have  to write the entire manager:  this file implementing
 * independent code plus  an architecture dependant file (ia32-virtual
 * or ia32-segment for example).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <kaneton.h>
#include <klibc.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the init variable, filled by the bootloader, containing in this case
 * the list of segments to mark used.
 */

extern t_init*		init;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

m_segment*		segment;

/*
 * ---------- functions -------------------------------------------------------
 */


/*
 * Permet de recup un segment a partir de son id :D
 */
t_error segment_get(t_segid u, o_segment** o)
{
  t_iterator	it;

  SEGMENT_ENTER(segment);

  set_locate(segment->container, u, &it);

  *o = it.u.ll.node->data;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Imprime les info relative a un segment
 */
t_error segment_show(t_segid u)
{
  o_segment *o;

  SEGMENT_ENTER(segment);

  kcons_printf("Segment_show : u = %qd\n", u);

  segment_get(u, &o);

  kcons_printf("             : start : %p ; size : %d\n",
	       o->address, o->size);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * En gros, fais un segment_show de tout les segment
 */
t_error segment_dump(void)
{
  t_iterator it;
  t_state state;
  o_set* container;

  SEGMENT_ENTER(segment);

  if (set_descriptor(segment->container, &container) != ERROR_NONE)
    {
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    };

  set_foreach(SET_OPT_FORWARD, container->setid, &it, state) {
    segment_show(((o_segment*)it.u.ll.node->data)->segid);
  }

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * la fonction segment_clone() duplique un segment. autrement dit elle
 * reserve un nouveau segment ayant les meme propriete que le precedent.
 * l identifiant du nouveau segment est retourne dans la variable new.
 *
 * l'argument asid specifie le proprietaire du segment clone. autrement
 * dit, une fois le segment clone, la fonction va enregistrer l'identifiant
 * de ce nouveau segment dans l'ensemble segments de l'object as ayant
 * l'identifiant asid.
 *
 * Ne pas oublier de copier aussi le contenu du segment (enfin je crois)
 */
t_error segment_clone(t_asid as, t_segid old, t_segid* new)
{
  o_segment *o;

  SEGMENT_ENTER(segment);

  if (segment_get(old, &o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_ELT_MISSING);

  if (segment_reserve(as, o->size, o->perms, new) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Inject un segment dans le as
 *
 * la boucle se fais dans kaneton.c
 */
t_error segment_inject(t_asid as, o_segment* o)
{
  o_as* oas;

  SEGMENT_ENTER(segment);

  //ajout au manager de segment
  set_add(segment->container, o);

  //add segment to as
  as_get(as, &oas);
  set_add(oas->segments, &(o->segid));

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * donne le segment id U a l'as designe par l'id.
 * Penser a virer le segment en question de l'as d'ou il viens
 */
t_error segment_give(t_segid u, t_asid as)
{
  o_segment *oseg;
  o_as* oas_old;
  o_as* oas_new;
  t_setid* id;

  SEGMENT_ENTER(segment);

  id = malloc(sizeof(t_setid));
  if (id == 0)
    SEGMENT_LEAVE(segment, ERROR_NO_MEM);

  *id = u;

  if (segment_get(u, &oseg) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_ELT_MISSING);

  if (as_get(oseg->asid, &oas_old) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_ELT_MISSING);

  if (as_get(as, &oas_new) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_ELT_MISSING);

  set_add(oas_new->segments, id);
  set_remove(oas_old->segments, u);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Resize implik bouger le segment si necessaire
 */
t_error segment_resize(t_segid u, t_psize size, t_segid* new)
{
 o_segment *o;

  SEGMENT_ENTER(segment);

  if (segment_get(u, &o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_ELT_MISSING);

  if (segment_reserve(o->asid, size, o->perms, new) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function split a segment into two segments.
 */
t_error segment_split(t_segid u, t_psize size, t_segid* left, t_segid* right)
{
  o_segment *cur;

  SEGMENT_ENTER(segment);

  if (segment_get(u, &cur) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_ELT_MISSING);

  if (segment_reserve(cur->asid,
		  cur->size - size,
		  cur->perms,
		  right) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  cur->size = size;

  *left = u;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function merges two segments into a single one
 */
t_error segment_coalesce(t_segid left, t_segid right, t_segid* u)
{
  o_segment *oseg_left;
  o_segment *oseg_right;

  SEGMENT_ENTER(segment);

  segment_get(left, &oseg_left);
  segment_get(right, &oseg_right);

  if ((oseg_right->perms != oseg_left->perms) ||
      (oseg_right->asid != oseg_left->asid))
     SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  segment_reserve(oseg_right->asid,
		  oseg_right->size + oseg_left->size,
		  oseg_right->perms,
		  u);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 *This function reserves a segment of specified size
 */
t_error segment_reserve(t_asid		as,
			t_psize		size,
			t_perms		perms,
		        t_segid*	u)
{
  o_segment* o;

  SEGMENT_ENTER(segment);

  //remplissage de la struct
  o = (o_segment *)malloc(sizeof(o_segment));

  if (o == 0)
    SEGMENT_LEAVE(segment, ERROR_NO_MEM);

  o->size = size;
  o->perms = perms;
  o->asid = as;

  //id et recherche
  if (segment_fit(size, (t_paddr*)u) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  o->segid = *u;

  segment_inject(as, o);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * relache le segment :P
 */
t_error segment_release(t_segid u)
{
  o_segment *oseg;
  o_as *oas;

  SEGMENT_ENTER(segment);

  if ((segment_get(u, &oseg) != ERROR_NONE) ||
      (as_get(oseg->asid, &oas) != ERROR_NONE))
    SEGMENT_LEAVE(segment, ERROR_ELT_MISSING);

  set_remove(oas->segments, u);
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function is used to force a segment to be given to an address space.
 * catcheable segments are reserved by the module service for architecture specific
 * servers. Catcheable segments are defined in the kaneton.conf file.
 */
t_error segment_catch(t_asid as, t_segid u)
{
  SEGMENT_ENTER(segment);

  //From Mycure : "tu t'en BRANLES !"

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Change les perms
 */
t_error segment_perms(t_segid u, t_perms perms)
{
  o_segment *o;

  SEGMENT_ENTER(segment);

  if (segment_get(u, &o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_ELT_MISSING);

  o->perms = perms;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function changes the type of a segment.
 */
t_error segment_type(t_segid u, t_type type)
{
  o_segment *o;

  SEGMENT_ENTER(segment);

  segment_get(u, &o);

  o->type = type;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function removes every segment that belongs to the address space specified
 */
t_error segment_flush(t_asid as)
{
  o_as* o;
  t_iterator it;
  t_state state;
  o_set* container;

  SEGMENT_ENTER(segment);

  if (as_get(as, &o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_ELT_MISSING);;

  if (set_descriptor(o->segments, &container) != ERROR_NONE)
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  set_foreach(SET_OPT_FORWARD, container->setid, &it, state) {
    segment_release(((o_segment *)(it.u.ll.node->data))->segid);
  }

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * init la chose
 */
t_error segment_init(t_fit fit)
{

  if ((segment = malloc(sizeof (m_segment))) == NULL) {
	 cons_msg('!', "segment: connot allocate memory for segment manager structure\n");
	 return (ERROR_UNKNOWN);
  }

  memset(segment, 0x0, sizeof (m_segment));

/* les id de segments doivent etre identiques aux adresses physiques */
//cf segment_reserve

  STATS_RESERVE("segment", &segment->stats);

  if (set_reserve(ll, SET_OPT_ALLOC | SET_OPT_SORT, sizeof (o_segment), &segment->container) != ERROR_NONE) {
	 cons_msg('!', "segment: unable to reserve the segment container");
	 return (ERROR_UNKNOWN);
  }

#if (DEBUG & DEBUG_SEGMENT)
  set_dump();
#endif

  return (ERROR_NONE);
}

/*
 * Nettoyage :)
 */
t_error segment_clean(void)
{

  free(segment);

  return (ERROR_NONE);
}
