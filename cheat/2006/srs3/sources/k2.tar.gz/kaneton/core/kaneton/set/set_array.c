/*
 * licence
 *
 * project       kaneton
 *
 * file          /usr/home/ohmer/projects/kaneton/core/kaneton/set/set_array.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated          [sun mar 26 21:30:18 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  subpart  of the  set  manager is  used  to  build array  data
 * structures.
 *
 * there  are two  way  to use  the  arrays :  with  pointers or  with
 * objects.    the  first   method   is  the   default  one   (without
 * SET_OPT_ALLOC) : it only  stores pointers refering to objects.  The
 * second method (used with  SET_OPT_ALLOC) makes copies of objects in
 * the set,  using memcpy. with  SET_OPT_FREE, objects are  freed when
 * they   are  removed   from  the   array  or   when  the   array  is
 * flushed/released.
 *
 * the option ORGANISE is used to keep the array as small as possible,
 * but  some operation  requires to  shift entire  parts of  the array
 * (loss of performances).
 *
 * when an array set is cloned, data are reorganised in. it means than
 * when a  clone operation occurs,  the array is reduced  clearing the
 * empty/unused places.
 *
 * options:    SET_OPT_CONTAINER,    SET_OPT_SORT,   SET_OPT_ORGANISE,
 * SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire array data structure.
 *
 * this data structure is very useful to contain very little objects like
 * identifiers.
 *
 * the address space objects, the task objects etc.. use it widely.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#define SET_INIT(set) SET_ENTER(set); \
                      if (set_descriptor(u, &o) != ERROR_NONE) \
                         { \
                          SET_LEAVE(set, ERROR_UNKNOWN);\
                         }
#define SET_ARRAY_BUF_SZ 20

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

t_error set_type_array(t_setid u)
{
  o_set	*o;

  SET_INIT(set);
  o->type = SET_TYPE_ARRAY;
  if (o->type != SET_TYPE_ARRAY)
    SET_LEAVE(set, ERROR_TYPE)
  else
    SET_LEAVE(set, ERROR_NONE);
}

t_error set_show_array(t_setid u)
{
  t_iterator    it;
  t_state	state;
  o_set		*o;

  SET_ENTER(set);
  //  set_descriptor(u, &o);
  kcons_printf("-----------Show array------------------\n");
  set_foreach(SET_OPT_FORWARD, u , &it, state)
    {
      if (set_object(u, it, (void **)&o) != ERROR_NONE)
	  {
	    kcons_printf("Error: object not found\n");
	    SET_LEAVE(set, ERROR_UNKNOWN);
	  }
      kcons_printf("--> 0x%p: data = %x [%d]\n", (t_id *)o, *((t_id *)o), it);
    }
  kcons_printf("-----------Show array end--------------\n");
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_head_array(t_setid u, t_iterator* iterator)
{
  o_set* o;
  t_setsz i;
  t_set_array a;

  SET_INIT(set);
  a = o->u.array;
  for (i = 0; i < a.arraysz && !a.array[i]; ++i)
    ;
  iterator->u.array.i = i;
  if (i == a.arraysz)
    SET_LEAVE(set, ERROR_ELT_MISSING);
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_tail_array(t_setid u, t_iterator* iterator)
{
  o_set* o;
  t_setsz i;
  t_set_array a;

  SET_INIT(set);
  a = o->u.array;
  for (i = a.arraysz; i > -1 && !a.array[i]; --i)
    ;
  iterator->u.array.i = i;
  if (!o->u.array.array)
    SET_LEAVE(set, ERROR_ELT_MISSING);
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_prev_array(t_setid u, t_iterator current, t_iterator* previous)
{
  o_set* o;
  t_setsz i;
  t_set_array a;

  SET_INIT(set);
  a = o->u.array;
  for (i = current.u.array.i - 1; i > -1 && !a.array[i]; --i)
    ;
  previous->u.array.i = i;
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_next_array(t_setid u, t_iterator current, t_iterator* next)
{
 t_setsz i;
  o_set* o;
  t_set_array *a;

  SET_INIT(set);
  a = &(o->u.array);
  for (i = current.u.array.i + 1; i < a->arraysz && !a->array[i]; ++i)
    ;
  if (i == a->arraysz)
    {
      next->u.array.i = -1;
      SET_LEAVE(set, ERROR_ELT_MISSING);
    }
  next->u.array.i = i;
  SET_LEAVE(set, ERROR_NONE);


}

t_error set_insert_head_array(t_setid u, void* data)
{
  t_setsz i;
  o_set* o;
  t_set_array *a;

  SET_INIT(set);
  a = &(o->u.array);
  if (a->array[0])
    {
      for (i = 0; i < a->arraysz && a->array[i]; ++i)
        ;
      if (i == a->arraysz)
        {
          a->arraysz += SET_ARRAY_BUF_SZ;
          a->array = realloc(a->array, a->arraysz);
          memset(a->array[i], 0, SET_ARRAY_BUF_SZ);
        }
      for (; i > 0; --i)
        a->array[i] = a->array[i - 1];
    }
  if (a->opts & SET_OPT_ALLOC)
    {
      if ((a->array[0] = malloc(a->datasz)) == NULL)
	SET_LEAVE(set, ERROR_NO_MEM);
      memcpy(a->array[0], data, a->datasz);
    }
  else
    a->array[0] = data;
  ++(o->size);
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_insert_tail_array(t_setid u, void* data)
{
  t_setsz i;
  o_set* o;
  t_set_array *a;

  SET_INIT(set);
  a = &(o->u.array);
  for (i = a->arraysz - 1; i >= 0 && a->array[i] == NULL; i--)
    ;
  if (i == a->arraysz - 1)
	{
	  a->arraysz += SET_ARRAY_BUF_SZ * a->datasz;
	  a->array = realloc(a->array, a->arraysz);
	  memset(a->array[i + 1], 0, a->datasz * SET_ARRAY_BUF_SZ);
	}
  if (a->opts & SET_OPT_ALLOC)
    {
      if ((a->array[i + 1] = malloc(a->datasz)) == NULL)
        SET_LEAVE(set, ERROR_NO_MEM);
      memcpy(a->array[i + 1], data, a->datasz);
    }
  else
    a->array[i + 1] = data;
  ++(o->size);
  SET_LEAVE(set, ERROR_NONE);

}

t_error set_insert_before_array(t_setid u, t_iterator iterator, void* data)
{

  t_setsz i;
  o_set* o;
  t_set_array *a;
  void	*tmp;

  SET_INIT(set);
  a = &(o->u.array);
  if (a->opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);

  if (a->opts & SET_OPT_ALLOC)
    {
      if ((tmp = malloc(a->datasz)) == NULL)
	SET_LEAVE(set, ERROR_NO_MEM);
      memcpy(tmp, data, a->datasz);
    }
  if (!a->array[iterator.u.array.i - 1])
    a->array[iterator.u.array.i - 1] = data;
  else
    {
      for (i = iterator.u.array.i; i < a->arraysz && a->array[i]; ++i)
        ;
      if (i == a->arraysz)
        {
          a->arraysz += SET_ARRAY_BUF_SZ;
          a->array = realloc(a->array, a->arraysz);
          memset(a->array[i], 0, SET_ARRAY_BUF_SZ);
        }
      for (; i > iterator.u.array.i; --i)
        a->array[i] = a->array[i - 1];
      a->array[i] = data;
    }
  ++(o->size);
  SET_LEAVE(set, ERROR_NONE);

}

t_error set_insert_after_array(t_setid u, t_iterator iterator, void* data)
{
  o_set* o;
  t_set_array a;
  t_setsz i;

  SET_INIT(set);
  a = o->u.array;
  if (a.opts & SET_OPT_SORT)
    SET_LEAVE(set, ERROR_SORT);

  if (iterator.u.array.i + 1 == a.arraysz)
    {
      a.arraysz += SET_ARRAY_BUF_SZ;
      a.array = realloc(a.array, a.arraysz);
      memset(a.array[i + 1], 0, SET_ARRAY_BUF_SZ);
    }
  for (i = iterator.u.array.i + 1; i < a.arraysz && a.array[i]; ++i)
    ;
  for (; i > iterator.u.array.i + 1; --i)
    a.array[i] = a.array[i - 1];
  a.array[i] = data;
  ++(o->size);
  SET_LEAVE(set, ERROR_NONE);


}

t_error set_add_array(t_setid u, void* data)
{
  t_setsz i;
  t_state state;
  t_iterator iterator;
  o_set* o;
  t_set_array *a;
  void * tmp;

  SET_INIT(set);
  a = &(o->u.array);
  if (a->opts & SET_OPT_SORT)
    {
      set_foreach(SET_OPT_FORWARD, u, &iterator, state)
      {
        if (set_object(u, iterator, (void**)&tmp) != ERROR_NONE)
        {
          kcons_printf("could not find set object\n");
          SET_LEAVE(set, ERROR_UNKNOWN);
        }
        if (*((t_id *)data) < *((t_id *)tmp))
          break;
      }
      if (iterator.u.array.i == a->arraysz)
        {
          a->arraysz += SET_ARRAY_BUF_SZ;
          a->array = realloc(a->array, a->arraysz);
          memset(a->array[iterator.u.array.i], 0, SET_ARRAY_BUF_SZ);
        }
      if (!a->array[iterator.u.array.i - 1])
        a->array[iterator.u.array.i - 1] = data;
      else
        {
          for (i = iterator.u.array.i; i < a->arraysz && a->array[i]; ++i)
            ;
          for (; i > iterator.u.array.i; --i)
            a->array[i] = a->array[i - 1];
          a->array[i] = data;
        }
    }
  else
    {
      for (i = 0; i < a->arraysz && a->array[i]; ++i)
        ;
      if (i == a->arraysz)
        {
          a->arraysz += SET_ARRAY_BUF_SZ;
          a->array = realloc(a->array, a->arraysz);
          memset(a->array[i], 0, SET_ARRAY_BUF_SZ);
        }
      a->array[i] = data;
    }
  ++(o->size);
  SET_LEAVE(set, ERROR_NONE);


}

t_error set_remove_array(t_setid u, t_id id)
{
 t_iterator iterator;

  SET_ENTER(set);

  if (set_locate_array(u, id, &iterator) == ERROR_NOT_FOUND)
    SET_LEAVE(set, ERROR_NOT_FOUND)


  SET_LEAVE(set, set_delete_array(u, iterator));
}

t_error set_delete_array(t_setid u, t_iterator iterator)
{
  o_set* o;
  t_set_array *a;
  t_setsz i;


  SET_INIT(set);
  a = &(o->u.array);
  if (a->opts & SET_OPT_FREE || a->opts & SET_OPT_ALLOC)
    free(a->array[iterator.u.array.i]);
  if (a->opts & SET_OPT_ORGANISE)
    {
      for (i = iterator.u.array.i + 1; i < a->arraysz && a->array[i]; ++i)
	a->array[i - 1] = a->array[i];
      a->array[i - 1] = NULL;
    }
  else
    a->array[iterator.u.array.i] = NULL;
  --(o->size);
  SET_LEAVE(set, ERROR_NONE);

}

t_error set_flush_array(t_setid u)
{
  t_state state;
  o_set* o;
  t_iterator i;

  SET_ENTER(set);
  set_foreach(SET_OPT_FORWARD, u, &i, state)
    {
      if (set_object(u, i, (void**)&o) != ERROR_NONE)
        {
          kcons_printf("could not find the set object");
          SET_LEAVE(set, ERROR_UNKNOWN);
        }
      set_delete(u, i);
    }
  SET_LEAVE(set, ERROR_NONE);

}

t_error set_locate_array(t_setid u, t_id id, t_iterator* iterator)
{
  t_setsz i;
  o_set* o;
  t_set_array *a;
  t_id id_test;
  int	exist = 0;

  SET_INIT(set);
  a = &(o->u.array);
  for (i = 0; !exist && i < a->arraysz; ++i)
    {
      id_test = *((t_id *)(a->array[i]));
      if (id_test == id)
        exist = 1;
    }
  iterator->u.array.i = i - 1;
  if (!exist)
    SET_LEAVE(set, ERROR_NOT_FOUND);
  SET_LEAVE(set, ERROR_NONE);

}

t_error set_object_array(t_setid u, t_iterator iterator, void** data)
{
  o_set* o;
  t_set_array *a;

  SET_INIT(set);
  a = &(o->u.array);
  *data = a->array[iterator.u.array.i];
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_push_array(t_setid u, void* data)
{
  return ERROR_NOT_AVAILABLE;
}

t_error set_pop_array(t_setid u)
{
  return ERROR_NOT_AVAILABLE;
}

t_error set_pick_array(t_setid u, void** data)
{
  return ERROR_NOT_AVAILABLE;
}

t_error set_reserve_array(t_opts opts, t_setsz initsz, t_size datasz, t_setid* u)
{
  o_set o;
  t_set_array *a;

  SET_ENTER(set);

  if (opts & SET_OPT_CONTAINER)
	 *u = set->container;
  else
	 id_reserve(&set->id, u);

  o.setid = *u;
  o.size = 0;
  o.type = SET_TYPE_ARRAY;

  a = &(o.u.array);
  a->opts = opts;
  a->datasz = datasz;
  a->initsz = initsz;
  a->arraysz = initsz;
  set_new(&o);
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_release_array(t_setid u)
{
  o_set* o;

  SET_ENTER(set);
  if (set_descriptor(u, &o) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  free(o->u.array.array);
  free(o);
  SET_LEAVE(set, ERROR_NONE);
}
