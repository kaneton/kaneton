/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/kaneton/as/as.c
 *
 * created       julien quintard   [tue dec 13 03:05:27 2005]
 * updated       matthieu michaud   [wed mar 29 23:49:57 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the address space manager manages address spaces.
 *
 * an address space describes process' useable memory. each address space
 * is composed of two sets.
 *
 * the first describes the segments held by this address space, in other
 * words the physical memory.
 *
 * the latter describes the regions, the virtual areas which reference
 * some segments.
 *
 * a task can give its address space to another with as_give.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the address space manager builds address space objects.
 *
 * every address space object is essentially composed of two sets: a
 * set of segments which list the segments held by this address space and
 * a set of regions which describes the useable virtual address ranges.
 *
 * the student just has to write the functions to reserve, release, get etc..
 * an address space.
 *
 * note that the address space does nothing more. indeed, the segment
 * manager and the region manager will add and/or remove the segments/regions
 * to/from the address space by their own.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <kaneton.h>
#include <klibc.h>

machdep_include(as);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the address space manager variable.
 */

m_as*			as = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */


t_error as_get(t_asid id, o_as** o)
{
  t_iterator	it;

  AS_ENTER(as);

  set_locate(as->container, id, &it);

  *o = it.u.ll.node->data;

  AS_LEAVE(as, ERROR_NONE);
}

t_error as_show(t_asid u)
{
  o_as *o;

  AS_ENTER(as);

  as_get(u, &o);

  kcons_printf("As_show : u = %qd, taskid = %qd\n", u, o->tskid);

  kcons_printf("        : segments : %qd ; regions : %qd\n",
					o->segments, o->regions);

  AS_LEAVE(as, ERROR_NONE);
}

/*
 * as_show de tout les segment de as
 */
t_error as_dump(void)
{
  t_iterator it;
  t_state state;
  o_set *container;

  AS_ENTER(as);
  if (set_descriptor(as->container, &container) != ERROR_NONE)
    AS_LEAVE(as, ERROR_UNKNOWN);
  set_foreach(SET_OPT_FORWARD, container->setid, &it, state) {
    as_show(((o_segment*)it.u.ll.node->data)->asid);
  }
  AS_LEAVE(as, ERROR_NONE);
}

/*
 * For K3

t_error as_give(t_asid id,
					 t_tskid tsk)
{
  AS_ENTER(as);

  AS_LEAVE(as, ERROR_NONE);
}

t_error as_vaddr(t_asid id,
		 t_segid seg,
		 t_paddr paddr,
		 t_vaddr* vaddr)
{
  AS_ENTER(as);

  AS_LEAVE(as, ERROR_NONE);
}

t_error as_paddr(t_asid id,
		 t_regid reg,
		 t_vaddr vaddr,
		 t_paddr* paddr)
{
  AS_ENTER(as);

  AS_LEAVE(as, ERROR_NONE);
}
*/

t_error as_clone(t_tskid tsk,
					  t_asid old,
					  t_asid* new)
{
  o_as	*a;
  o_as	*b;

  AS_ENTER(as);
  as_get(old, &a);
  as_reserve(tsk, new);
  as_get(*new, &b);
  b->segments = a->segments;
  b->regions = a->regions;
  AS_LEAVE(as, ERROR_NONE);
}

t_error as_reserve(t_tskid tsk,
						 t_asid* id)
{
  o_as a;

  AS_ENTER(as);

  id_reserve(&(as->id), &(a.asid));

  a.tskid = tsk;

  set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof (t_segid), &(a.segments));
  set_reserve(ll, SET_OPT_SORT | SET_OPT_ALLOC, sizeof (t_id), &(a.regions));

  set_add(as->container, &a);

  AS_LEAVE(as, ERROR_NONE);
}

t_error as_release(t_asid id)
{
  o_as * oas;

  AS_ENTER(as);

  as_get(id, &oas);

  set_flush(oas->segments);
  set_flush(oas->regions);
  set_remove(as->container, id);

  AS_LEAVE(as, ERROR_NONE);
}

t_error as_init(void)
{
  //cf machdep as.c file
  return machdep_call(as, as_init);
}

t_error as_clean(void)
{
  //cf machdep as.c file
  return machdep_call(as, as_clean);
}

