/*
 * licence       
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/kaneton/set/set_bpt.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu michaud   [wed mar 22 17:14:46 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this subpart of the set manager is used to build balanced+ tree data
 * structures.
 *
 * this set type is build over the header file bpt.h developed by julien
 * quintard. this header file was develop to provide an easy way to build
 * specific balanced+ trees.
 *
 * note that the sort option must be provided because a non-sorted tree
 * is not conceivable.
 *
 * the datasz argument of the set_reserve() function is needed only if the
 * allocate option is set.
 *
 * options: SET_OPT_CONTAINER, SET_OPT_SORT, SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students should not develop anything here.
 *
 * this data structure is reserved to the reference kaneton project.
 *
 * nevertheless if the students really want to include a powerful data
 * structure into their kaneton implementation, take a look to the
 * bpt.h header file develop by myself:
 *
 *      core/include/sys/bpt.h
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */
