/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/kaneton/arch/machdep/bochs.c
 *
 * created       matthieu michaud   [thu mar 23 03:37:11 2006]
 * updated       matthieu michaud   [thu mar 23 04:30:28 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * don't worry, be happy.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

#ifdef BOCHS_HACK

int				 bochs_printf_char(char c)
{
  outb(BOCHS_IOPORT, c);
  return 0;
}

int				 bochs_printf_attr(unsigned char attr)
{
  return 0;
}

int				 bochs_setup(void)
{
  return 0;
}

int				 bochs_printf(const char *fmt, ...)
{
  unsigned int	 written;
  va_list args;

  va_start(args, fmt);
  written = vprintf(fmt, args);
  va_end(args);

  return written;
}

#endif
