/*
 * licence
 *
 * project       kaneton
 *
 * file          /usr/home/ohmer/projects/kaneton/core/kaneton/arch/machdep/as.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated          [sun mar 26 17:20:02 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file  implements dependent  code for as  manager on  ia32 with
 * paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

/* #include <klibc.h> */
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_as*		as;
extern t_tskid		ktask;
extern t_init*		init;

/*
 * ---------- globals ---------------------------------------------------------
 */



/*
 * the address space manager interface.
 */

i_as			as_interface =
  {
    ia32v_as_init,
    ia32v_as_clean
  };

/*
 * ---------- functions -------------------------------------------------------
 */

/*
  t_error ia32v_as_give(t_asid id,
  t_tskid tsk)
  {
  AS_ENTER(as);

  AS_LEAVE(as, ERROR_NONE);
  }

  t_error ia32v_as_vaddr(t_asid id,
  t_segid seg,
  t_paddr paddr,
  t_vaddr* vaddr)
  {
  AS_ENTER(as);

  AS_LEAVE(as, ERROR_NONE);
  }

  t_error ia32v_as_paddr(t_asid id,
  t_regid reg,
  t_vaddr vaddr,
  t_paddr* paddr)
  {
  AS_ENTER(as);

  AS_LEAVE(as, ERROR_NONE);
  }

  t_error ia32v_as_clone(t_tskid tsk,
  t_asid old,
  t_asid* new)
  {
  AS_ENTER(as);

  AS_LEAVE(as, ERROR_NONE);
  }

  t_error ia32v_as_reserve(t_tskid tsk,
  t_asid* id)
  {
  AS_ENTER(as);

  AS_LEAVE(as, ERROR_NONE);
  }

  t_error ia32v_as_release(t_asid id)
  {
  AS_ENTER(as);

  AS_LEAVE(as, ERROR_NONE);
  }
*/

t_error ia32v_as_init(void)
{
  as = malloc(sizeof(m_as));
  if (as == NULL)
    return ERROR_NO_MEM;

  if (id_build(&as->id) != ERROR_NONE) {
	 cons_msg('!', "as: unable to initialise the identifier object\n");
	 return (ERROR_UNKNOWN);
  }

  if (id_reserve(&as->id, &as->container) != ERROR_NONE) {
    cons_msg('!', "as: unable to reserve an identifier\n");
    return (ERROR_UNKNOWN);
  }

#if (DEBUG & DEBUG_AS)
  as_dump();
#endif

  return ERROR_NONE;
}

t_error ia32v_as_clean(void)
{
  set_flush(as->container);
  free(as);
  return ERROR_NONE;
}
