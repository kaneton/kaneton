/*
 * licence       
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/include/arch/machdep/kaneton/kaneton.h
 *
 * created       julien quintard   [sat dec 17 17:13:18 2005]
 * updated       matthieu michaud   [wed mar 29 19:41:47 2006]
 */

#ifndef IA32_KANETON_KANETON_H
#define IA32_KANETON_KANETON_H	1

/*
 * ---------- defines ---------------------------------------------------------
 */

#define ___endian		ENDIAN_LITTLE
#define ___wordsz		WORDSZ_32

#define PAGESZ			4096


static inline unsigned char	  inb(unsigned short port)
{
	unsigned char data;

	__asm__ volatile ("inb %1,%0" : "=a" (data) : "id" (port));
	return (data);
}

static inline void				  outb(unsigned short port, unsigned char data)
{
	__asm__ volatile ("outb %0,%1" : : "a" (data), "id" (port));
}

static inline void				  cli(void)
{
  __asm__ volatile ("cli" : : : "memory");
}

static inline void				  sti(void)
{
  __asm__ volatile ("sti");
}

/*
 * ---------- includes --------------------------------------------------------
 */

#include <arch/machdep/kaneton/segment.h>
#include <arch/machdep/kaneton/as.h>
#include <arch/machdep/kaneton/debug.h>
#include <arch/machdep/kaneton/init.h>
#include <arch/machdep/kaneton/region.h>
#include <arch/machdep/kaneton/stats.h>
#include <arch/machdep/kaneton/task.h>

/*
 *----------- forward declarations --------------------------------------------
 */

typedef struct s_segment o_segment;
typedef struct s_as o_as;

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../../../kaneton/arch/machdep/as.c
 *      ../../../../kaneton/arch/machdep/region.c
 *      ../../../../kaneton/arch/machdep/segment.c
 *      ../../../../kaneton/arch/machdep/task.c
 *      ../../../../kaneton/arch/machdep/cons.c
 *		  ../../../../kaneton/arch/machdep/bochs.c
 */

/*
 * ../../../../kaneton/arch/machdep/as.c
 */

t_error ia32v_as_init(void);

t_error ia32v_as_clean(void);


/*
 * ../../../../kaneton/arch/machdep/region.c
 */


/*
 * ../../../../kaneton/arch/machdep/segment.c
 */

t_error ia32v_segment_clone(t_asid as, t_segid old, t_segid* new);

t_error ia32v_segment_inject(o_segment* o, t_asid as);

t_error ia32v_segment_give(t_segid u, t_asid as);

t_error ia32v_segment_resize(t_segid u, t_psize size, t_segid* new);

t_error ia32v_segment_split(t_segid u, t_psize size, t_segid* left, t_segid* rigth);

t_error ia32v_segment_coalesce(t_segid left, t_segid right, t_segid* u);

t_error ia32v_segment_reserve(t_asid as, t_psize size, t_perms perms, t_segid* u);

t_error ia32v_segment_release(t_segid u);

t_error ia32v_segment_catch(t_asid as, t_segid u);

t_error ia32v_segment_perms(t_segid u, t_perms perms);

t_error ia32v_segment_type(t_segid u, t_type type);

t_error ia32v_segment_flush(t_asid as);

t_error ia32v_segment_get(t_segid u, o_segment** o);

t_error ia32v_segment_init(void);

t_error ia32v_segment_clean(void);


/*
 * ../../../../kaneton/arch/machdep/task.c
 */


/*
 * ../../../../kaneton/arch/machdep/cons.c
 */

void				 kcons_clear(unsigned char attr);

void				 kcons_setup(void);

int				 kcons_printf_char(char c);

void				 kcons_printf_attr(unsigned char attr);

int				 kcons_printf(const char *fmt, ...);


/*
 * ../../../../kaneton/arch/machdep/bochs.c
 */

int				 bochs_printf_char(char c);

int				 bochs_printf_attr(unsigned char attr);

int				 bochs_setup(void);

int				 bochs_printf(const char *fmt, ...);


/*
 * eop
 */

#endif
