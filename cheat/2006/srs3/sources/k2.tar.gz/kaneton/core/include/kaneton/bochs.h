/*
 * licence       
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/include/kaneton/bochs.h
 *
 * created       matthieu michaud   [thu mar 23 03:43:43 2006]
 * updated       matthieu michaud   [thu mar 23 04:17:36 2006]
 */

#ifndef KANETON_BOCHS_H
#define KANETON_BOCHS_H			  1

#ifndef BOCHS_HACK

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <arch/machdep/machdep.h>
#include <kaneton/types.h>

/*
 * ---------- defines ---------------------------------------------------------
 */

#define BOCHS_IOPORT 0xe9

#endif

#endif
