/*
 * licence       
 *
 * project       kaneton
 *
 * file          /usr/home/ohmer/projects/kaneton/core/bootloader/arch/machdep/bootloader.h
 *
 * created       julien quintard   [fri feb 11 02:23:53 2005]
 * updated          [sat mar 25 22:30:13 2006]
 */

#ifndef BOOTLOADER_H
#define BOOTLOADER_H		1

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      bootloader.c
 *      cons.c
 *      init.c
 *      paging.c
 *      pmode.c
 */

/*
 * bootloader.c
 */

int			bootloader(t_uint32					magic,
							  multiboot_info_t*		mbi);


/*
 * cons.c
 */

int				 bcons_printf_char(char c);

void				 bcons_printf_attr(unsigned char attr);

void				 bcons_setup(void);

void				 bcons_clean(unsigned char attr);

int				 bcons_printf(unsigned char row, unsigned char col, const char *fmt, ...);


/*
 * init.c
 */

void			initTask(multiboot_info_t*	mbi);

void			copyTo(unsigned int		from,
			       unsigned int		to,
			       unsigned int		size);

void			initializeInit(multiboot_info_t*	mbi);

unsigned int		computeGDTAdress(multiboot_info_t*	mbi);

unsigned int		computePDAdress(multiboot_info_t*	mbi);

int			computeModulesSz(multiboot_info_t*	mbi);

void			relocateModules(multiboot_info_t*	mbi);

void			createSegmentsArray(multiboot_info_t*	mbi);

void			createRegionArray(multiboot_info_t*	mbi);

int			getKernelSz(unsigned int		mods_addr);

int			computeNPage(int			size);

int			allocPage(int				size);


/*
 * paging.c
 */


/*
 * pmode.c
 */


/*
 * eop
 */

#endif
