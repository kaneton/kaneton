/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/pt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:48 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:54:23 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page tables.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to place here everything dealing with page tables. no
 * restrictions apply on this file.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

/*
** Rempli une PT
*/

void	pt_init(unsigned int from, unsigned int pt_addr)
{
  int	i;

  for(i = 0; i < 1024; ++i)
    {
      pt_add_entry((from + i) * PAGESZ, PDE_SYSTEM, PDE_RW, pt_addr + i * sizeof (t_pt_entry));
    }
}


/*   31	       	       	       	       	 12    	8 7 6 5	4 3 2 1	0
 *  +------------------------------------------------------------+
 *  |                                      |   | | | | | | | | | |
 *  |                                      | A | |P| | |P|P|U|R| |
 *  |           Page Address               | V |G|G|D|A|C|W|\|\|P|
 *  |                                      | L | |S| | |D|T|S|W| |
 *  |  	       	       	       	       	   |   | | | | | | | | | |
 *  +------------------------------------------------------------+
 */

/*
** Ajouter une entree
*/

void	pt_add_entry(unsigned int page_addr, char user, char perm, unsigned int addr)
{
  unsigned int flags = 0x301;
  flags |= user << 2;
  flags |= perm << 1;

  unsigned int* tmp;
  tmp = (unsigned int *) addr;
  *tmp = page_addr;
  *tmp |= flags;
}




