/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/klibc/libsys/perror.c
 *
 * created       julien quintard   [fri feb 11 03:08:53 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:59:11 2006]
 */
