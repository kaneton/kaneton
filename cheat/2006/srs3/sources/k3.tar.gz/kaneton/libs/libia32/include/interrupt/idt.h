/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/py/work/kaneton/libs/libia32/include/interrupt/idt.h
 *
 * created       julien quintard   [tue nov 29 21:32:05 2005]
 * updated       matthieu bucchianeri   [sun jan 15 18:20:29 2006]
 */


#ifndef _IDT_H
#define _IDT_H

/*
 * defines
 */

#define IDT_SIZE 0x100

#define IDT_PRESENT 0x8000           /* 10000000 00000000 */
#define IDT_TRAPGATE 0x0700          /* 00000111 00000000 : used for system calls */
#define IDT_INTGATE 0x600            /* 00000110 00000000 : used for interruptions */
#define IDT_TASKGATE 0x500           /* 00000101 00000000 : used for task switching */
#define IDT_32 0x0800                /* 00001000 00000000 */
#define IDT_DPL0 0x0000              /* 00000000 00000000 */
#define IDT_DPL1 0x2000              /* 00100000 00000000 */
#define IDT_DPL2 0x4000              /* 01000000 00000000 */
#define IDT_DPL3 0x6000              /* 01100000 00000000 */

/*
 * structures / types
 */

typedef struct _s_idt
{
  unsigned short __offset;
  unsigned short _segment;
  unsigned short _type;
  unsigned short _offset;
} __attribute__ ((packed)) _t_idt;

typedef struct _s_idtr
{
  unsigned short _size;
  unsigned int _addr;
} __attribute__ ((packed)) _t_idtr;

/*
 * prototypes
 */

void k_disable_irq(unsigned short irq);
void k_enable_irq(unsigned short irq);
void k_idt_new_interrupt(unsigned short entry, unsigned int offset,
			 unsigned short segment, unsigned short type,
			 unsigned short level);
void k_init_idt(void);

void _k_null_int(void);
void _k_int_00(void);
void _k_int_01(void);
void _k_int_02(void);
void _k_int_03(void);
void _k_int_04(void);
void _k_int_05(void);
void _k_int_06(void);
void _k_int_07(void);
void _k_int_08(void);
void _k_int_09(void);
void _k_int_10(void);
void _k_int_11(void);
void _k_int_12(void);
void _k_int_13(void);
void _k_int_14(void);
void _k_int_15(void);
void _k_int_16(void);
void _k_int_17(void);
void _k_int_18(void);
void _k_int_19(void);

void _k_irq_00(void);
void _k_irq_01(void);
void _k_irq_02(void);
void _k_irq_03(void);
void _k_irq_04(void);
void _k_irq_05(void);
void _k_irq_06(void);
void _k_irq_07(void);
void _k_irq_08(void);

void _k_irq_14(void);
void _k_irq_15(void);

#endif
