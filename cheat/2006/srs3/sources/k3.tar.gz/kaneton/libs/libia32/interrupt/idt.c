/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/interrupt/idt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:47:59 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:48:35 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage interrupt descriptor table.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will  place  here   the  function  they  need  to  manage
 * idt. prototypes are not imposed.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include "../include/interrupt/idt.h"
#include "../../core/include/kaneton/keyboard.h"


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * global variables
 */

_t_idt _idt[IDT_SIZE];
_t_idtr idtr;

/*
 * static variables
 */

/*
 * static functions
 */

static void k_init_pic();

/*
 * Initialize Programmable Interrupt Controller
 */

static void k_init_pic()
{

  /*
   * installer un mask des interruptions par defaut
   */

  // avec ICW4 + seul ?
  outb(PIC1_IN, 0x11);
  // @ du vect
  outb(PIC1_OUT, 0x20);
  // on rattache a l'esclave
  outb(PIC1_OUT, 0x04);
  // obligatoire
  outb(PIC1_OUT, 0x01);
  // On accepte toutes les interruptions
  outb(PIC1_OUT, 0xff);
  // avec ICW4 + seul ?
  outb(PIC2_IN, 0x11);
  // @ du vect (clavier?)
  outb(PIC2_OUT, 0x70);
  // on rattache au maitre
  outb(PIC2_OUT, 0x02);
  // obligatoire
  outb(PIC2_OUT, 0x01);
  // On accepte toutes les interruptions
  outb(PIC2_OUT, 0xFF);

  // Demasquage des irqs
  outb(PIC1_OUT, 0x0);
  outb(PIC2_OUT, 0x0);
}

/*
 * Disable An IRQ
 */

void k_disable_irq(unsigned short irq)
{

}

/*
 * Enable An IRQ
 */

void k_enable_irq(unsigned short irq)
{

}

/*
 * Add An Entry To Interrupt Descriptor Table
 */

void k_idt_new_interrupt(unsigned short entry, unsigned int offset,
			 unsigned short segment, unsigned short type,
			 unsigned short level)
{
  _idt[entry].__offset = 0xffff & offset;
  _idt[entry]._segment = segment;
  _idt[entry]._type = type | level;
  _idt[entry]._offset = (offset >> 16) & 0xffff;
}


void _k_int_00(void)
{
  asm("call k_keyboard_isr");
  asm("mov $0x20, %al");
  asm("out %al, $0x20");
  asm("iret");
}

void _k_irq_00(void)
{
  //toto
}

void _k_irq_01(void)
{
  asm("call k_keyboard_isr");
  asm("mov $0x20, %al");
  asm("out %al, $0x20");
  asm("iret");
}

/*
 * Initiliaze And Load Interrupt Descriptor Table
 */

void k_init_idt(void)
{

  memset(_idt, 0, sizeof(_t_idt) * IDT_SIZE);


  // INTERRUPTIONS
  //divide 0
  k_idt_new_interrupt(0, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  //debug
  k_idt_new_interrupt(1, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // NMI (non maskable int)
  k_idt_new_interrupt(2, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // Breakpoint
  k_idt_new_interrupt(3, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_TRAPGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // Overflow
  k_idt_new_interrupt(4, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_TRAPGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // bound exception
  k_idt_new_interrupt(5, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // invalid opcode
  k_idt_new_interrupt(6, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // FPU Not avaiable
  k_idt_new_interrupt(7, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // double fault
  k_idt_new_interrupt(8, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // coprocessor segment overrun
  k_idt_new_interrupt(9, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // invalid TSS
  k_idt_new_interrupt(10, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // segement not present
  k_idt_new_interrupt(11, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // stack except
  k_idt_new_interrupt(12, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // general protection
  k_idt_new_interrupt(13, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // page fault
  k_idt_new_interrupt(14, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // 15 reserved !!!
  // floating point error
  k_idt_new_interrupt(16, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // align check
  k_idt_new_interrupt(17, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // machine check
  k_idt_new_interrupt(18, (unsigned int) _k_int_00, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // IRQS
  // timer
  k_idt_new_interrupt(32, (unsigned int) _k_irq_01, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // keyboard
  k_idt_new_interrupt(33, (unsigned int) _k_irq_01, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // cascade des pic
  k_idt_new_interrupt(34, (unsigned int) _k_irq_01, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // second port serie
  k_idt_new_interrupt(35, (unsigned int) _k_irq_01, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // premier port serie
  k_idt_new_interrupt(36, (unsigned int) _k_irq_01, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  // lecteur de disquette
  k_idt_new_interrupt(38, (unsigned int) _k_irq_01, get_kernel_code_segment(),
		      IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0);
  /* // horloge sys */
  /* k_idt_new_interrupt(40, _k_irq_08, get_kernel_code_segment(), */
  /* IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0); */
  /* // interface reseau */
  /* k_idt_new_interrupt(43, _k_irq_11, get_kernel_code_segment(), */
  /* IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0); */
  /* // souris PS/2 */
  /* k_idt_new_interrupt(44, _k_irq_12, get_kernel_code_segment(), */
  /* IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0); */
  /* // coproc arith */
  /* k_idt_new_interrupt(45, _k_irq_13, get_kernel_code_segment(), */
  /* IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0); */
  /* // controleur de disque 1 */
  /* k_idt_new_interrupt(46, _k_irq_14, get_kernel_code_segment(), */
  /* IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0); */
  /* // controleur de disque 2 */
  /* k_idt_new_interrupt(47, _k_irq_15, get_kernel_code_segment(), */
  /* IDT_INTGATE | IDT_PRESENT | IDT_32, IDT_DPL0); */


  idtr._size = IDT_SIZE * sizeof(_t_idt);
  idtr._addr = (unsigned int) _idt;

  asm("lidtl (idtr)");
  k_init_pic();
  sti;
}
