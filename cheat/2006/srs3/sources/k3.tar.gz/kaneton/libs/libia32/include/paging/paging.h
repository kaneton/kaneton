/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/paging/paging.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:30:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * declares paging structures, defines, etc.
 *
 */

#ifndef IA32_IA32_PAGING_H
#define IA32_IA32_PAGING_H	1

//Added by P-Y

#define PDE_USER 1
#define PDE_SYSTEM 0

#define PDE_RO 0
#define PDE_RW 1

typedef struct			s_pd_entry
{
  unsigned char			present : 1;
  unsigned char			read_write : 1;
  unsigned char			user_system : 1;
  unsigned char			pwt : 1; //for internal cache
  unsigned char			pcd : 1; //for internal cache
  unsigned char			accessed : 1;
  unsigned char			must_be_0 : 1;
  unsigned char			pagesize : 1;
  unsigned char                 global  : 1;
  unsigned char			available : 2;
  unsigned int			address : 20;
}				__attribute__ ((packed)) t_pd_entry;

typedef struct			s_pt_entry
{
  unsigned char			present : 1;
  unsigned char			read_write : 1;
  unsigned char			user_system : 1;
  unsigned char			pwt : 1; //for internal cache
  unsigned char			pcd : 1; //for internal cache
  unsigned char			accessed : 1;
  unsigned char			dirty : 1;
  unsigned char			pagesize : 1;
  unsigned char                 global  : 1;
  unsigned char			available : 2;
  unsigned int			address : 20;
}				__attribute__ ((packed)) t_pt_entry;

#endif
