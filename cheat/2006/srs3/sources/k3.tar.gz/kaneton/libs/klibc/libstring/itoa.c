/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workspace/kaneton/libs/klibc/libstring/itoa.c
 *
 * created       etienne gaschet   [fri feb 11 02:56:44 2005]
 * updated       pouya mohtacham   [fri jun  2 15:09:05 2006]
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>

/*
 * ---------- functions -------------------------------------------------------
 */

static unsigned int	nb_chiffers(unsigned int number)
{
  unsigned int		res = 0;

  if (number == 0)
    return 1;
  while (number != 0)
    {
      number /= 10;
      res++;
    }
  return res;
}



char		*itoa(unsigned int nb, char *buffer)
{
  unsigned int	i = 0;
  unsigned int	nb_size = 0;

  nb_size = nb_chiffers(nb);
  /*   buffer = malloc((nb + 1) * sizeof(char)); */
  for (i = 0; i < nb_size; ++i)
    {
      buffer[nb_size - i - 1] = '0' + (nb % 10);
      nb /= 10;
    }
  buffer[nb_size] = '\0';
  return buffer;
}


