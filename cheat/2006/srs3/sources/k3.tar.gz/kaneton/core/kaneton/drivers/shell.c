#include "../../../libs/klibc/include/klibc.h"
#include "../../include/kaneton/shell.h"
#include "../../include/kaneton/keyboard.h"

/*
 * Print Shell Help
 */

void k_shell_about(void)
{
  /*
   * affiche l'aide
   */
  kcons_setup();
  kcons_printf("               #############################################                    ");
  kcons_printf("               ############__---~~~~~|~~~~~--__#############                    ");
  kcons_printf("               ########.-~~          |          ~~-.########                    ");
  kcons_printf("               #####.-~     .-~~~~-. |              ~-.#####                    ");
  kcons_printf("               ####/       {  o     }|                 \\###                    ");
  kcons_printf("               ###/        /       / |                  \\##                    ");
  kcons_printf("               ##|        `--r'   {  | ,___.-',          |##                    ");
  kcons_printf("               ##|          /      ~-|         ',        |##                    ");
  kcons_printf("               ##|---------{---------|----------'--------|##                    ");
  kcons_printf("               ##|          \\        |         /         |#                    ");
  kcons_printf("               ##|           \\       |        /          |#                    ");
  kcons_printf("               ###\\         ~ ~~~~~~~|~~~~~~~~~ ~       /##                    ");
  kcons_printf("               ####\\       ~ ~ ~ ~ ~ | ~ ~ ~ ~ ~ ~     /###                    ");
  kcons_printf("               #####`-_     ~ ~ ~ ~ ~|~ ~ ~ ~ ~ ~    _-'####                    ");
  kcons_printf("               ########`-__    ~ ~ ~ | ~ ~ ~ ~   __-'#######                    ");
  kcons_printf("               ############~~---_____|_____---~~############                    ");
  kcons_printf("               #############################################                    ");
  kcons_printf("                              Kaneton v 1.0                                     ");
  kcons_printf("                               developers:                                      ");
  kcons_printf("                           * Pierre-Yves Rofes-Vernis                           ");
  kcons_printf("                           * Matthieu Michaud                                   ");
  kcons_printf("                           * Germain Bauvin                                     ");
  kcons_printf("                           * Pouya Mohtacham                                    ");
}


/*
 * static variables
 */

static _t_cmds commands[] =
{
  { "about", k_shell_about },
/*   { "clear", kcons_setup }, */
  { (void *) 0, (void *) 0 }
};



void k_exec_cmd(char* cmd)
{
  int i = 0;

  while (commands[i].command != 0)
    {
      if (!strcmp(cmd, commands[i].command))
	  commands[i].function(cmd);
      ++i;
    }
}

/*
 * Demonstration Shell
 */
void k_shell(void)
{
  char cmd[2048];

  kcons_printf("42sh$");
  while(1) {
    k_keyboard_isr();
/*     k_get_string(cmd, 2048); */
    k_exec_cmd(cmd);
    k_flush_keyboard_buffer();
  }
}
