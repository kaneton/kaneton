/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workspace/kaneton/core/kaneton/set/set_ll.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       pouya mohtacham   [fri jun  2 18:19:46 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this subpart of the set manager is used to build linked-list
 * data structures.
 *
 * note that this data structure is in fact a doubly linked-list.
 *
 * each set of this type can be used in two ways. the first one ask the
 * set manager to allocate and copy each object to add while the second
 * way tells the set manager to simply include the objects in the set.
 *
 * moreover the option free can be used to tell the set manager to call
 * the free() function each time an object is released. this option
 * means that objects passed to the set manager was previously allocated
 * with the malloc() functions suite.
 *
 * moreover, the linked-list data structure can be used either with the
 * sort option or without.
 *
 * the datasz argument of the set_reserve() function is meaningful only in the
 * case the allocate or free options are set.
 *
 * options: SET_OPT_CONTAINER, SET_OPT_SORT, SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire linked-list data structure, nothing
 * less, nothing more.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

static t_set_ll_node*	 set_new_ll(t_set_ll* ll, void* data)
{
  t_set_ll_node* new;

  //  kcons_printf("creating a new set_new_ll\n");

  if ((new = malloc(sizeof (t_set_ll_node))) == NULL)
    return NULL;

  if (ll->opts & SET_OPT_ALLOC) {
    if ((new->data = malloc(ll->datasz)) == NULL) {
      free(new);
      return NULL;
    }
    memcpy(new->data, data, ll->datasz);
  }
  else
    new->data = data;

  return new;
}

static t_set_ll_node*	set_free_ll(t_set_ll* ll, t_iterator iter)
{
  if (iter.u.ll.node == NULL)
	 return NULL;

  if (ll->opts & (SET_OPT_ALLOC | SET_OPT_FREE))
	 free((iter.u.ll.node)->data);

  return (iter.u.ll.node);
}

t_error set_type_ll(t_setid u)
{
  o_set *o;

  SET_ENTER(set);
  set_descriptor(u, &o);

  if (o->type == SET_TYPE_LL)
	 SET_LEAVE(set, ERROR_NONE);

  SET_LEAVE(set, ERROR_UNKNOWN);
}

t_error set_show_ll(t_setid u)
{
  t_iterator iter;
  t_state state;
  o_set *o;

  SET_ENTER(set);

  /*   kcons_printf("set_show_ll: u = %qd\n", u); */

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  /*   kcons_printf("set_show_ll: o = %p\n", o); */

  /*   TODO : remettre la bonne fonction celle ne marche que pour les data = char */

  set_foreach(SET_OPT_FORWARD, u, &iter, state)
    {
      o_id *oid = id_from_data((iter.u.ll.node)->data);
      printf("set_show_ll: node @ %p (data @ %p), id = %d\n",
	     &iter,
	     (iter.u.ll.node)->data,
	     oid->id);
    }
/*   printf("size of o_id = %d\n", sizeof(o_id)); */


  SET_LEAVE(set, ERROR_NONE);
}

t_error set_head_ll(t_setid u,
						  t_iterator* iter)
{
  o_set *o;

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  iter->u.ll.node = o->u.ll.head;

  if (iter->u.ll.node == NULL)
	 SET_LEAVE(set, ERROR_NOT_FOUND);

  SET_LEAVE(set, ERROR_NONE);
}

t_error set_tail_ll(t_setid u,
						  t_iterator* iter)
{
  o_set *o;

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  iter->u.ll.node = o->u.ll.tail;

  if (iter->u.ll.node == NULL)
	 SET_LEAVE(set, ERROR_NOT_FOUND);

  SET_LEAVE(set, ERROR_NONE);
}

t_error set_prev_ll(t_setid u,
						  t_iterator current,
						  t_iterator* prev)
{
  SET_ENTER(set);

  prev->u.ll.node = (current.u.ll.node)->prv;

  if (prev->u.ll.node == NULL)
	 SET_LEAVE(set, ERROR_NOT_FOUND);

  SET_LEAVE(set, ERROR_NONE);
}

t_error set_next_ll(t_setid u,
						  t_iterator current,
						  t_iterator* next)
{
  SET_ENTER(set);

  next->u.ll.node = (current.u.ll.node)->nxt;

  if (next->u.ll.node == NULL)
	 SET_LEAVE(set, ERROR_NOT_FOUND);

  SET_LEAVE(set,  ERROR_NONE);
}

t_error set_insert_head_ll(t_setid u,
									void* data)
{
  t_set_ll_node *new;
  t_set_ll* ll;
  o_set *o;

  /*   kcons_printf("__try to add a node in the head of set_ll\n"); */

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

/*   if (o->u.ll.opts & SET_OPT_SORT) */
/* 	 SET_LEAVE(set, ERROR_UNKNOWN); */

  ll = &(o->u.ll);

  if ((new = set_new_ll(ll, data)) == NULL)
    SET_LEAVE(set, ERROR_NO_MEM);

  new->prv = NULL;

  if (ll->head == NULL) { // empty list
    //kcons_printf("__new list, create the first node\n");
    new->nxt = NULL;
    ll->head = ll->tail = new;
  }
  else {
    //kcons_printf("__add a node in the head of the list\n");
    new->nxt = ll->head;
    ll->head->prv = new;
    ll->head = new;
  }

  ++(o->size);

  SET_LEAVE(set, ERROR_NONE);
}

t_error set_insert_tail_ll(t_setid u,
									void* data)
{
  t_set_ll_node* new;
  t_set_ll* ll;
  o_set *o;

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

/*   if (o->u.ll.opts & SET_OPT_SORT) */
/* 	 SET_LEAVE(set, ERROR_UNKNOWN); */

  ll = &(o->u.ll);

  if ((new = set_new_ll(ll, data)) == NULL)
    SET_LEAVE(set, ERROR_NO_MEM);

  new->nxt = NULL;

  if (ll->head == NULL) { // empty list
    new->prv = NULL;
    ll->head = ll->tail = new;
  }
  else {
    new->prv = ll->tail;
    ll->tail->nxt = new;
    ll->tail = new;
  }

  ++(o->size);

  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_before_ll(t_setid u,
					     t_iterator iterator,
					     void* data)
{
  t_set_ll_node		*new;
  t_set_ll_node		*cur;
  t_set_ll		*ll;
  o_set			*o;


  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

/*   if (o->u.ll.opts & SET_OPT_SORT) */
/*     SET_LEAVE(set, ERROR_UNKNOWN); */

  if ((cur = iterator.u.ll.node) == NULL)
    {
/*       kcons_printf("ERROR : current is null man!!!\n"); */
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  ll = &(o->u.ll);
  if ((new = set_new_ll(ll, data)) == NULL)
    {
/*       kcons_printf("ERROR : echec de creation de new !!!\n"); */
      SET_LEAVE(set, ERROR_NO_MEM);
    }



/*   kcons_printf("bob marley is great man!\n"); */

  new->nxt = cur;
  new->prv = cur->prv;
  if (cur->prv != NULL)
	 cur->prv->nxt = new;
  cur->prv = new;
  if (ll->head == cur)
    {
      ll->head = new;
    }



/*   kcons_printf("size of the set : %d\n", o->size); */
  ++(o->size);

  SET_LEAVE(set, ERROR_NONE);
}

t_error set_insert_after_ll(t_setid u,
									 t_iterator iterator,
									 void* data)
{
  t_set_ll_node *new, *cur;
  o_set *o;

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  if (o->u.ll.opts & SET_OPT_SORT)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  if ((cur = iterator.u.ll.node) == NULL)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  if ((new = set_new_ll(&(o->u.ll), data)))
    SET_LEAVE(set, ERROR_NO_MEM);

  new->prv = cur;
  new->nxt = cur->nxt;
  if (cur->nxt != NULL)
	 cur->nxt->prv = new;
  cur->nxt = new;

  ++(o->size);

  SET_LEAVE(set, ERROR_NONE);
}



static t_error	set_add_ll_with_sort(t_setid u,
				     void *data)
 {
   t_error	e = -1;
   o_set		*o;
   o_id		*oid;
   o_id		*temp_oid;
   t_iterator	iter;
   t_state	state;

   SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

      //      kcons_printf("OPT_SORT Is active Dude!:\n");
  oid = id_from_data(data);
  /*       kcons_printf("want to add object with id  : %d\n", oid->id); */
  set_foreach(SET_OPT_FORWARD, u, &iter, state)
    {
      /* 	  if (&iter == NULL) */
      /* 	    kcons_printf("...iter == nULl dude!!\n"); */
      temp_oid = id_from_data((iter.u.ll.node)->data);
      /* 	  kcons_printf("temp_oid == %d\n", temp_oid->id); */
      if (oid->id > temp_oid->id && iter.u.ll.node == o->u.ll.tail)
	{
	  /* 	      kcons_printf("i will add this one from the tail man!!\n"); */
	  e = set_insert_tail_ll(u, data);
	  break;
	}
      if (oid->id > temp_oid->id)
	continue;
      else
	{
	  /* 	      kcons_printf("USING SORT\n"); */
	  e = set_insert_before_ll(u, iter, data);
	  break;
	}
    }
  if (e == -1)
    {
      /* 	  	kcons_printf("WARNING : unable to SORT\n"); */
      e = set_insert_head_ll(u, data);
    }
  SET_LEAVE(set, e);
}



t_error		set_add_ll(t_setid u,
			   void* data)
{
  t_error	e = -1;
  o_set		*o;

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (o->u.ll.opts & SET_OPT_SORT)
    e = set_add_ll_with_sort(u, data);
  else
    e = set_insert_head_ll(u, data);

  SET_LEAVE(set, e);
}

t_error set_remove_ll(t_setid u,
							 t_id id)
{
  t_iterator iter;

  SET_ENTER(set);

  if (set_locate_ll(u, id, &iter) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_NOT_FOUND);

  set_delete_ll(u, iter);

  SET_LEAVE(set, ERROR_NONE);
}

t_error set_delete_ll(t_setid u,
							 t_iterator iter)
{
  t_set_ll_node *node;
  o_set *o;

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  if ((node = set_free_ll(&(o->u.ll), iter)) == NULL)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  if (node->prv != NULL)
	 node->prv->nxt = node->nxt;
  else
	 o->u.ll.head = node->nxt;

  if (node->nxt != NULL)
	 node->nxt->prv = node->prv;
  else
	 o->u.ll.tail = node->prv;

  --(o->size);

  SET_LEAVE(set, ERROR_NONE);
}

t_error set_flush_ll(t_setid u)
{
  t_iterator iter;
  t_state state;
  o_set *o;

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);


  set_foreach(SET_OPT_BACKWARD, u, &iter, state)
	 set_free_ll(&(o->u.ll), iter);

  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_locate_ll(t_setid u,
				      t_id id,
				      t_iterator* iter)
{
  t_set_ll_node		*node;
  t_id			*cur_id;
  o_set			*o;

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  for (node = o->u.ll.head; node != NULL; node = node->nxt) {
	 cur_id = (t_id*)(node->data);
	 if (*cur_id == id) {
		iter->u.ll.node = node;
		SET_LEAVE(set, ERROR_NONE);
	 }
  }

  SET_LEAVE(set, ERROR_NOT_FOUND);
}

t_error set_object_ll(t_setid u,
							 t_iterator iter,
							 void** data)
{
  SET_ENTER(set);

/*   kcons_printf("set_object_ll: iterator = %p\n", iterator); */
/*   kcons_printf("set_object_ll: node = %p\n", iterator.u.ll.node); */
/*   kcons_printf("set_object_ll: data = %p\n", (iterator.u.ll.node)->data); */

  if (iter.u.ll.node == NULL)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  *data = (iter.u.ll.node)->data;

  SET_LEAVE(set, ERROR_NONE);
}

t_error set_push_ll(t_setid u,
						  void* data)
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_NOT_AVAILABLE);
}

t_error set_pop_ll(t_setid u)
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_NOT_AVAILABLE);
}

t_error set_pick_ll(t_setid u,
						  void** data)
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_NOT_AVAILABLE);
}

t_error set_release_ll(t_setid u)
{
  o_set *o;

  SET_ENTER(set);

  if (set_descriptor(u, &o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  if (set_flush_ll(u) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  free(o);

  SET_LEAVE(set, ERROR_NOT_AVAILABLE);
}

/*
 * reserve a new object in container identified by u with opts opts
 * and element size datasz.
 */
t_error set_reserve_ll(t_opts opts,
		       t_size datasz,
		       t_setid* u)
{
  o_set o;
/*   char	buffer[64]; */

  SET_ENTER(set);

/*   if (opts & SET_OPT_CONTAINER) */
/*     kcons_printf("OPTS : SET_OPT_CONTAINER is SET\n"); */
/*   if (opts & SET_OPT_ALLOC) */
/*     kcons_printf("OPTS : SET_OPT_ALLOC is SET\n"); */
/*   if (opts & SET_OPT_SORT) */
/*     kcons_printf("OPTS : SET_OPT_SORT is SET\n"); */


  if (opts & SET_OPT_CONTAINER)
    *u = set->container;
  else if (id_reserve(&set->id, u) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  o.setid = *u;
  o.size = 0;
  o.type = SET_TYPE_LL;

  // opts & datasz not generic ?
  o.u.ll.opts = opts;
  o.u.ll.datasz = datasz;
  o.u.ll.head = NULL;
  o.u.ll.tail = NULL;

  if (set_new(&o) != ERROR_NONE)
	 SET_LEAVE(set, ERROR_UNKNOWN);

  SET_LEAVE(set, ERROR_NONE);
}
