/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workspace/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       pouya mohtacham   [fri jun  2 18:20:15 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include "../include/kaneton/shell.h"
#include "../../libs/libia32/include/interrupt/idt.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- defines ---------------------------------------------------------
 */

/*
 * ---------- macros ----------------------------------------------------------
 */

#define PRINT_INIT_RESULT(r, subsys) \
  kcons_printf("%s: init %s\n", subsys, ((r) == ERROR_NONE) ? "succeed" : "failed");

/*
 * ---------- functions -------------------------------------------------------
 */





/*
** kernel
*/
void			kaneton(t_init*				bootloader)
{
  char duck[] = "\n"
    "       ..---..\n"
    "     .'  _    `.\n"
    "__..'  (o)     :\n"
    "`..__          ;\n"
    "     `.       /\n"
    "      ;       `..---...___\n"
    "     .'                   `~-. .-')\n"
    "    .                         ' _.'\n"
    "   :     GNU/Kaneton          :\n"
    "   \\     2.6.14-grsec-nokbd   '\n"
    "    +                         J\n"
    "     `._                   _.'\n"
    "        `~--....___...---~'\n";

  t_asid kernel_as;

  init = bootloader;

  kcons_setup();

  kcons_printf("%s\n", duck);

  PRINT_INIT_RESULT(alloc_init(init->alloc, init->allocsz, ALLOC_FIT), "alloc");
  PRINT_INIT_RESULT(id_init(), "id");
  PRINT_INIT_RESULT(set_init(), "set");
  PRINT_INIT_RESULT(as_init(), "as");
  PRINT_INIT_RESULT(segment_init(SEGMENT_FIT), "segment");


  //Do Not Remove (used for notation)
#ifdef SERIAL
  debug_init();
#endif

  k_init_idt();


   k_shell();
   for (;;);


  /*
   * Reserve an address space for kernel
   */

  as_reserve(0, &kernel_as);

  /*
   * inject pre-allocated segment in segment manager
   */
  /*   for (i = 0; i < init->nsegments; ++i) */
  /* 	 segment_inject(kernel_as, &(init->segments[i])); */

  /*
   * clean managers
   */

  segment_clean();
  as_clean();
  set_clean();
  id_clean();
}
