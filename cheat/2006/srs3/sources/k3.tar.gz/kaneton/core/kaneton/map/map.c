/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/moon/workspace/kaneton/core/kaneton/map/map.c
 *
 * created       germain bauvin    [sun jun 11 03:04:40 2006]
 * updated       germain bauvin    [sun jun 11 03:04:40 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * The map manager is used to manager memory in a simpler way.
 * Indeed, dealing with segments and regions is not very easy when the end user just wants
 * to reserve some memory.
 * A map is an abstract couple of two kaneton objects: a segment and a region.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have  to write the entire manager.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <kaneton.h>
#include <klibc.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the map manager structure.
 */

m_map*		map;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Reserves a map. This function will so reserve a segment of the given
 * size and finally perform the mapping by reserving a region
 */
t_error map_reserve(t_asid asid, t_opts opts, t_vaddr* addr,
		    t_vsize size, t_perms perms)
{
  t_regid regid;
  t_segid segid;

  MAP_ENTER(map);

  if (segment_reserve(asid, size, perms, &segid) != ERROR_NONE)
    return (ERROR_UNKNOWN);

  if (region_reserve(asid, segid, 0, opts, *addr, size, &regid) != ERROR_NONE)
    return (ERROR_UNKNOWN);

  MAP_LEAVE(map,ERROR_NONE);
}

/*
 * Release a map
 */
t_error map_release(t_asid asid, t_vaddr addr)
{
  o_region* oreg;
  t_regid regid = (t_regid)addr;

  MAP_ENTER(map);

  if (region_get(asid, regid, &oreg) != ERROR_NONE)
    MAP_LEAVE(map, ERROR_ELT_MISSING);

  if (segment_release(oreg->segid) != ERROR_NONE)
    MAP_LEAVE(map, ERROR_ELT_MISSING);

  if (region_release(asid, regid) != ERROR_NONE)
    MAP_LEAVE(map, ERROR_ELT_MISSING);

  MAP_LEAVE(map,ERROR_NONE);
}

/*
 * Initialize the map manager
 */
t_error map_init(void)
{

  if ((map = malloc(sizeof (m_map))) == NULL) {
	 cons_msg('!', "map: connot allocate memory for map manager structure\n");
	 return (ERROR_UNKNOWN);
  }

  memset(map, 0x0, sizeof (m_map));

  STATS_RESERVE("map", &map->stats);

  return (ERROR_NONE);
}

/*
 * cleans the manager
 */
t_error map_clean(void)
{
  free(map);

  return (ERROR_NONE);
}
