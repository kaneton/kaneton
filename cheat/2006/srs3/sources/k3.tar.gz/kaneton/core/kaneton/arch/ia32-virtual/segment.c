/*
 * licence       
 *
 * project       kaneton
 *
 * file          /usr/home/ohmer/projects/kaneton/core/kaneton/arch/machdep/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated          [sun mar 26 17:44:28 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  file implements dependent  code for  segment manager  on ia32
 * with paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

/* #include <klibc.h> */
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_segment*	segment;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager interface.
 */

i_segment		segment_interface =
  {
/* 	 ia32v_segment_clone, */
/* 	 ia32v_segment_inject, */
/* 	 ia32v_segment_give, */
/* 	 ia32v_segment_resize, */
/* 	 ia32v_segment_split, */
/* 	 ia32v_segment_coalesce, */
/* 	 ia32v_segment_reserve, */
/* 	 ia32v_segment_release, */
/* 	 ia32v_segment_catch, */
/* 	 ia32v_segment_perms, */
/* 	 ia32v_segment_type, */
/* 	 ia32v_segment_flush, */
/* 	 ia32v_segment_get, */
/* 	 ia32v_segment_init, */
/* 	 ia32v_segment_clean */
  };

/*
 * ---------- functions -------------------------------------------------------
 */

t_error ia32v_segment_clone(t_asid as, t_segid old, t_segid* new)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_inject(o_segment* o, t_asid as)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_give(t_segid u, t_asid as)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_resize(t_segid u, t_psize size, t_segid* new)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_split(t_segid u, t_psize size, t_segid* left, t_segid* rigth)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_coalesce(t_segid left, t_segid right, t_segid* u)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_reserve(t_asid as, t_psize size, t_perms perms, t_segid* u)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_release(t_segid u)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_catch(t_asid as, t_segid u)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_perms(t_segid u, t_perms perms)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_type(t_segid u, t_type type)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_flush(t_asid as)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_get(t_segid u, o_segment** o)
{
  SEGMENT_ENTER(segment);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

t_error ia32v_segment_init(void)
{
  return ERROR_NONE;
}

t_error ia32v_segment_clean(void)
{
  return ERROR_NONE;
}
