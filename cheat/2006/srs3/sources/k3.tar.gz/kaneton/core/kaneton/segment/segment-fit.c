/*
 * licence
 *
 * project       kaneton
 *
 * file          /usr/home/ohmer/projects/kaneton/core/kaneton/segment/segment-fit.c
 *
 * created       matthieu bucchianeri   [tue jan 10 01:03:46 2006]
 * updated          [sun mar 26 16:39:40 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file implements simple  fitting algorithms for physical memory
 * management.
 *
 * you can define which algorithm to use with the macro SEGMENT_FIT.
 *
 *  - FIT_FIRST: first fit algorithm - the first large enough space is taken
 *  - FIT_BEST: best fit algorithm - the smaller space is taken
 *  - ...
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  have  to develop  at  least  the  first-fit algorithm  to
 * allocate physical memory.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

extern m_segment*	segment;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Compute the humber of page required for a size
 */
int			computeNPage(int			size)
{
  int npages = size / PAGESZ;

  if (size % PAGESZ != 0)
    npages++;

  return npages;
}

/*
 * This function searchs the given address space for a segment of given size.
 */
t_error segment_fit(/*o_as*	as,*/ //vir'e sur avis de MyCure, pas utile
       		    t_psize	size,
		    t_paddr*	address)
{
  t_iterator it;
  t_state state;
  o_set* container;
  t_paddr possible_addr_in_pagsz;

  SEGMENT_ENTER(segment);

  if (set_descriptor(segment->container, &container) != ERROR_NONE)
    {
      *address = 0;
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    };

  set_foreach(SET_OPT_FORWARD, container->setid, &it, state) {
    if (it.u.ll.node->nxt == 0)
      break;
    possible_addr_in_pagsz = computeNPage(((o_segment*)(it.u.ll.node->data))->segid + ((o_segment*)(it.u.ll.node->data))->size);
    if ((computeNPage(((o_segment*)(it.u.ll.node->nxt->data))->segid) -
	 possible_addr_in_pagsz) * PAGESZ > computeNPage(size) * PAGESZ)
      {
	*address = possible_addr_in_pagsz * PAGESZ;
	SEGMENT_LEAVE(segment, ERROR_NONE);
      }
  }

  SEGMENT_LEAVE(segment, ERROR_NO_MEM);
}
