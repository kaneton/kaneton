/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/region/region.c
 *
 * created       julien quintard   [wed nov 23 09:19:43 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:44:09 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the region manager manages mapping of segments.
 *
 * reserving a region means to map virtual addresses to a segment.
 *
 * like for  segment, region identifiers are the  virtual address they
 * maps.
 *
 * unlike segments, regions  are proper to an address  space: there is
 * one set of region objects for each address space to prevent collisions.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to develop  entirely this manager, including the code
 * for one architecture (ia32-virtual or ia32-segment).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(region);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the region manager structure.
 */

m_region*		region;

/*
 * ---------- functions -------------------------------------------------------
 */

  //
  // MEGA TODO/TO CODE partie dependante
  //

/*
 * Display information on a specific region
 */
t_error region_show(	t_asid asid, t_regid regid)
{
  o_region *o;

  REGION_ENTER(region);

  kcons_printf("Region_show  : regid  = %qd (asid = %qd)\n",
	       regid, asid);

  region_get(asid, regid, &o);

  kcons_printf("             | segid  = %qd\n", o->segid);
  kcons_printf("             | vaddr  = %p\n", o->address);
  kcons_printf("             | offset = %p\n", o->offset);
  kcons_printf("             \\ size   = %d\n", o->size);

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Displays information on all regions of the address space
 */
t_error region_dump(	t_asid asid)
{
  t_iterator it;
  t_state state;
  o_set* container;

  REGION_ENTER(region);

  if (set_descriptor(asid, &container) != ERROR_NONE)
    {
      REGION_LEAVE(region, ERROR_UNKNOWN);
    };

  set_foreach(SET_OPT_FORWARD, container->setid, &it, state) {
    region_show(asid, ((o_region*)it.u.ll.node->data)->regid);
  }

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Injects a pre-reserved region
 */
t_error region_inject(	t_asid as, o_region* o)
{
  o_as* oas;

  REGION_ENTER(region);

  //ajout au manager de region
  //set_add(??, o); //TODO CHECK

  //add region to as
  as_get(as, &oas);
  set_add(oas->regions, &(o->regid));

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Reserves a region given some properties //TO CODE / TO FINISH
 */
t_error region_reserve(	t_asid asid, t_segid segid, t_paddr offset,
			t_opts opts, t_vaddr address, t_vsize size,
			t_regid* regid)
{
  o_region * o;

  REGION_ENTER(region);

  //remplissage de la structure
  o = (o_region *)malloc(sizeof(o_region));

  if (o == 0)
    REGION_LEAVE(region, ERROR_NO_MEM);

  o->segid = segid;
  o->offset = offset;
  o->size = size;

  if (opts & REGION_OPT_FORCE)
    o->address = address;
  else
    {
      //
      // TODO : REGION FITTING;
      //      : PD/PT business
      //
    }

  // setter l'id en fonction de l'adresse
  o->regid = o->address;

  region_inject(asid, o);

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Release a region //TO CODE / TO FINISH
 */
t_error region_release(	t_asid asid, t_regid regid)
{
  o_region *oreg;
  o_as *oas;

  REGION_ENTER(region);

  if ((region_get(asid, regid, &oreg) != ERROR_NONE) ||
      (as_get(asid, &oas) != ERROR_NONE))
    REGION_LEAVE(region, ERROR_ELT_MISSING);

  //TODO : PD/PT Business

  set_remove(oas->regions, regid);

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Removes every region that belongs to the specified address space.
 */
t_error region_flush(t_asid as)
{
  o_as* o;
  t_iterator it;
  t_state state;
  o_set* container;

  REGION_ENTER(region);

  if (as_get(as, &o) != ERROR_NONE)
    REGION_LEAVE(region, ERROR_ELT_MISSING);;

  if (set_descriptor(o->regions, &container) != ERROR_NONE)
      REGION_LEAVE(region, ERROR_UNKNOWN);

  set_foreach(SET_OPT_FORWARD, container->setid, &it, state) {
    region_release(as,((o_region *)(it.u.ll.node->data))->regid);
  }

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Looks for and return a region object
 */
t_error region_get(t_asid asid, t_regid regid, o_region**o)
{
  t_iterator	it;

  REGION_ENTER(region);

  set_locate(asid, regid, &it);

  *o = it.u.ll.node->data;

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Initialize the region manager // TO CODE / TO FINISH
 */
t_error region_init(t_vaddr start, t_vsize size)
{
  if ((region = malloc(sizeof (m_region))) == NULL) {
	 cons_msg('!', "region: connot allocate memory for segment manager structure\n");
	 return (ERROR_UNKNOWN);
  }

  memset(region, 0x0, sizeof (m_region));

  STATS_RESERVE("region", &region->stats);

  region->fit = FIT_FIRST;
  //  region->start = ? //TODO
  //  region->size = ? //TODO

  //TODO give an id to segment

  return (ERROR_NONE);
}

/*
 * Cleans the region manager
 */
t_error region_clean(void)
{
  free(region);

  return (ERROR_NONE);
}
