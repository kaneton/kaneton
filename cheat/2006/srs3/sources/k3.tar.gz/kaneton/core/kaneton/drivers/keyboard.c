#include "../../../libs/klibc/include/klibc.h"
#include "../../include/kaneton/keyboard.h"
#include "../../include/arch/machdep/kaneton/kaneton.h"

/*
 * global variables
 */

_t_keyboard _keyboard;

/*
 * extern variables
 */

extern unsigned char _keyboard_qwerty_table[];
extern unsigned char _keyboard_azerty_table[];
extern unsigned char _keyboard_num_table[];

/*
 * Keyboard Handler
 */

void k_keyboard_isr(void)
{
  unsigned char key;

  /*
   * ici vous etes cense lire sur le controller clavier pour
   * recuperer le code de la touche en question.
   * attention il y a un piege, je vous conseille de bien regarder
   * le fichier drivers/keyboard_languages.h notamment les lignes de fin
   * qui sont en commentaires.
   */

  do {
    key = inb(KEYBOARD_STATUS_REGISTER);
  } while (!(key & 0x01));
  key = inb(KEYBOARD_DATA_REGISTER);
/*   kcons_printf("%d\n", key); */

  k_get_char(&key);
}

/*
 * Init keyboard
 */

void k_init_keyboard(void)
{

  /*
   * pensez a bien initialiser la structure keyboard.
   */
  _keyboard._keyboard_table = _keyboard_qwerty_table;
  _keyboard._ptr = 0;
  _keyboard._character = 0;
  _keyboard._buffer[0] = 0;
  _keyboard._shift = 0;
}

void k_flush_keyboard_buffer(void)
{
  int i;

  for (i = 0; i < KEYBOARD_BUFFER_SIZE; ++i)
    _keyboard._buffer[i] = 0;
}

/*
 * Get A Printable Character
 */

void k_get_char(unsigned char *c)
{
  if (_keyboard._ptr && _keyboard._buffer[_keyboard._ptr - 1] == '\n')
    _keyboard._ptr = 0;

  if (*c == KEYBOARD_LEFT_SHIFT || *c == KEYBOARD_RIGHT_SHIFT)
    {
      _keyboard._shift = 1;
      return;
    }
  if (*c == KEYBOARD_CAPS_LOCK)
    _keyboard._shift = 2;
  if (*c > 0x80)
    return;
  _keyboard._buffer[_keyboard._ptr++] = _keyboard._keyboard_table[*c*2+ (_keyboard._shift & 0x1)];

  kcons_printf_char(_keyboard._keyboard_table[*c*2+ (_keyboard._shift & 0x1)]);
  if (_keyboard._shift == 1)
    _keyboard._shift = 0;
}

/*
 * Get A Printable String
 */

unsigned int k_get_string(unsigned char *buffer, unsigned int len)
{

  /*
   * boucle active tant que le caractere n'est pas '\n'
   */
  kcons_printf("Entree k_get_string\n");
  while (!_keyboard._ptr || _keyboard._buffer[_keyboard._ptr - 1] != '\n')
    ;
  strncpy(buffer, _keyboard._buffer, (len > KEYBOARD_BUFFER_SIZE) ? KEYBOARD_BUFFER_SIZE : len);
  buffer[_keyboard._ptr - 1] = '\0';
  _keyboard._ptr = 0;
  kcons_printf("Sortie\n");
  return (_keyboard._ptr);
}
