unsigned char _keyboard_qwerty_table[] = {                 /* 0x00 - 0x4e */
  0x00, 0x00,
  0x00, 0x00,                                              /* Escape      */
  '1', '!',
  '2', '@',
  '3', '#',
  '4', '$',
  '5', '%',
  '6', '^',
  '7', '&',
  '8', '*',
  '9', '(',
  '0', ')',
  '-', '_',
  '=', '+',
  0x00, 0x00,                                              /* Backspace   */
  '\t', '\t',                                              /* Tabulation  */
  'q', 'Q',
  'w', 'W',
  'e', 'E',
  'r', 'R',
  't', 'T',
  'y', 'Y',
  'u', 'U',
  'i', 'I',
  'o', 'O',
  'p', 'P',
  '[', '{',
  ']', '}',
  '\n', '\n',                                              /* Left Enter  */
  0x00, 0x00,                                              /* Left Ctrl   */
  'a', 'A',
  's', 'S',
  'd', 'D',
  'f', 'F',
  'g', 'G',
  'h', 'H',
  'j', 'J',
  'k', 'K',
  'l', 'L',
  ';', ':',
  '\'', '\"',
  '`', '~',
  0x00, 0x00,                                              /* Left Shift  */
  '\\', '|',
  'z', 'Z',
  'x', 'X',
  'c', 'C',
  'v', 'V',
  'b', 'B',
  'n', 'N',
  'm', 'M',
  ',', '<',
  '.', '>',
  '/', '?',
  0x00, 0x00,                                              /* Right Shift */
  '*', '*',
  0x00, 0x00,                                              /* Left Alt    */
  ' ', ' ',                                                /* Space       */
  0x00, 0x00,                                              /* Caps Lock   */
  0x00, 0x00,                                              /* F1          */
  0x00, 0x00,                                              /* F2          */
  0x00, 0x00,                                              /* F3          */
  0x00, 0x00,                                              /* F4          */
  0x00, 0x00,                                              /* F5          */
  0x00, 0x00,                                              /* F6          */
  0x00, 0x00,                                              /* F7          */
  0x00, 0x00,                                              /* F8          */
  0x00, 0x00,                                              /* F9          */
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  '-', '-',
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  '+', '+',
};

unsigned char _keyboard_azerty_table[] = {                 /* 0x00 - 0x4e */
  0x00, 0x00,
  0x00, 0x00,                                              /* Escape      */
  '&', '1',
  '�', '2',
  '\"', '3',
  '\'', '4',
  '(', '5',
  '-', '6',
  '�', '7',
  '_', '8',
  '�', '9',
  '�', '0',
  ')', '�',
  '=', '+',
  0x00, 0x00,                                              /* Backspace   */
  '\t', '\t',                                              /* Tabulation  */
  'a', 'A',
  'z', 'Z',
  'e', 'E',
  'r', 'R',
  't', 'T',
  'y', 'Y',
  'u', 'U',
  'i', 'I',
  'o', 'O',
  'p', 'P',
  '^', '\"',
  '$', '�',
  '\n', '\n',                                              /* Left Enter  */
  0x00, 0x00,                                              /* Left Ctrl   */
  'q', 'Q',
  's', 'S',
  'd', 'D',
  'f', 'F',
  'g', 'G',
  'h', 'H',
  'j', 'J',
  'k', 'K',
  'l', 'L',
  'm', ':',
  '�', '\"',
  '�', '~',
  0x00, 0x00,                                              /* Left Shift  */
  'u', '*',
  'w', 'W',
  'x', 'X',
  'c', 'C',
  'v', 'V',
  'b', 'B',
  'n', 'N',
  ',', '?',
  ';', '.',
  ':', '/',
  '!', '�',
  0x00, 0x00,                                              /* Right Shift */
  '*', '*',
  0x00, 0x00,                                              /* Left Alt    */
  ' ', ' ',                                                /* Space       */
  0x00, 0x00,                                              /* Caps Lock   */
  0x00, 0x00,                                              /* F1          */
  0x00, 0x00,                                              /* F2          */
  0x00, 0x00,                                              /* F3          */
  0x00, 0x00,                                              /* F4          */
  0x00, 0x00,                                              /* F5          */
  0x00, 0x00,                                              /* F6          */
  0x00, 0x00,                                              /* F7          */
  0x00, 0x00,                                              /* F8          */
  0x00, 0x00,                                              /* F9          */
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  '-', '-',
  0x00, 0x00,
  0x00, 0x00,
  0x00, 0x00,
  '+', '+',
};

unsigned char _keyboard_num_table[] = {                     /* 0x47 - 0x53 */
  '7',                                                     /* Home        */
  '8',                                                     /* Up          */
  '9',                                                     /* Page Up     */
  0x00,
  '4',                                                     /* Left        */
  '5',
  '6',                                                     /* Right       */
  0x00,
  '1',                                                     /* End         */
  '2',                                                     /* Down        */
  '3',                                                     /* Page Down   */
  '0',                                                     /* Insert      */
  '.'                                                      /* Delete      */
};

/*
  PAUSE = 0xe1

  ESCAPE          =   0x01 0x81
  F1              =   0x3b 0xbb
  F2              =   0x3c 0xbc
  F3              =   0x3d 0xbd
  F4              =   0x3e 0xbe
  F5              =   0x3f 0xbf
  F6              =   0x40 0xc0
  F7              =   0x41 0xc1
  F8              =   0x42 0xc2
  F9              =   0x43 0xc3
  F10             =   0x57 0xd7
  F11             =   0x58 0xd8
  F12             =   
  PRINT_SCREEN    =   0xe0 0x37 0xe0 0xb7
  SROLL_LOCK      =   0x46 0xc6
  PAUSE           =   0xe1 0x1d 0x45 0xe1 0x9d 0xc5

  `               =   0x29 0xa9
  1               =   0x02 0x82
  2               =   0x03 0x83
  3               =   0x04 0x84
  4               =   0x05 0x85
  5               =   0x06 0x86
  6               =   0x07 0x87
  7               =   0x08 0x88
  8               =   0x09 0x89
  9               =   0x0a 0x8a
  0               =   0x0b 0x8b
  -               =   0x0c 0x8c
  =               =   0x0d 0x8d
  \               =   0x2b 0xab
  BACKSPACE       =   0x0e 0x8e

  TAB             =   0x0f 0x8f
  q               =   0x10 0x90
  w               =   0x11 0x91
  e               =   0x12 0x92
  r               =   0x13 0x93
  t               =   0x14 0x94
  y               =   0x15 0x95
  u               =   0x16 0x96
  i               =   0x17 0x97
  o               =   0x18 0x98
  p               =   0x19 0x99
  [               =   0x1a 0x9a
  ]               =   0x1b 0x9b
  LEFT ENTER      =   0x1c 0x9c

  CAPS LOCK       =   0x3a 0xba
  a               =   0x1e 0x9e
  s               =   0x1f 0x9f
  d               =   0x20 0xa0
  f               =   0x21 0xa1
  g               =   0x22 0xa2
  h               =   0x23 0xa3
  j               =   0x24 0xa4
  k               =   0x25 0xa5
  l               =   0x26 0xa6
  ;               =   0x27 0xa7
  '               =   0x28 0xa8

  LEFT SHIFT      =   0x2a 0xaa
  z               =   0x2c 0xac
  x               =   0x2d 0xad
  c               =   0x2e 0xae
  v               =   0x2f 0xaf
  b               =   0x30 0xb0
  n               =   0x31 0xb1
  m               =   0x32 0xb2
  ,               =   0x33 0xb3
  .               =   0x34 0xb4
  /               =   0x35 0xb5
  RIGHT SHIFT     =   0x36 0xb6

  LEFT CTRL       =   0x1d 0x9d
  LEFT ALT        =   0x38 0xb8
  SPACE           =   0x39 0xb9
  RIGHT ALT GR    =   0xe0 0x38 0xe0 0xb8
  RIGHT CTRL      =   0xe0 0x1d 0xe0 0x9d

  INSERT          =   0xe0 0x52 0xe0 0xd2
  HOME            =   0xe0 0x47 0xe0 0xc7
  PAGE UP         =   0xe0 0x49 0xe0 0xc9
  DELETE          =   0xe0 0x53 0xe0 0xd3
  END             =   0xe0 0x4f 0xe0 0xcf
  PAGE DOWN       =   0xe0 0x51 0xe0 0xd1

  UP              =   0xe0 0x48 0xe0 0xc8
  LEFT            =   0xe0 0x4b 0xe0 0xcb
  DOWN            =   0xe0 0x50 0xe0 0xd0
  RIGHT           =   0xe0 0x4d 0xe0 0xcd

  NUM LOCK        =   0x45 0xc5
  /               =   0xe0 0x35 0xe0 0xb5
  *               =   0x37 0xb7
  -               =   0x4a 0xca
  7               =   0x47 0xc7
  8               =   0x48 0xc8
  9               =   0x49 0xc9
  4               =   0x4b 0xcb
  5               =   0x4c 0xcc
  6               =   0x4d 0xcd
  +               =   0x4e 0xce
  1               =   0x4f 0xcf
  2               =   0x50 0xd0
  3               =   0x51 0xd1
  0               =   0x52 0xd2
  .               =   0x53 0xd3
  RIGHT ENTER     =   0xe0 0x1c 0xe0 0x9c

 */
