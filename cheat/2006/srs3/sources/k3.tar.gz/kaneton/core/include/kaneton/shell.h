#ifndef _SHELL_H
#define _SHELL_H

/*
 * ---------- types -----------------------------------------------------------
 */

typedef struct _s_cmds
{
  char *command;
  void (*function)(unsigned char *cmd);
} _t_cmds;


/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/drivers/shell.c
 */

/*
 * ../../kaneton/drivers/shell.c
 */

void k_shell_about(void);

void k_exec_cmd(char* cmd);

void k_shell(void);


/*
 * eop
 */
#endif
