/*
 * licence       
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/include/kaneton/error.h
 *
 * created       julien quintard   [fri feb 11 02:19:11 2005]
 * updated       matthieu michaud   [sat mar 25 19:46:57 2006]
 */

#ifndef KANETON_ERROR_H
#define KANETON_ERROR_H		1

/*
 * ---------- defines ---------------------------------------------------------
 */

#define ERROR_NONE		(1 << 0)
#define ERROR_UNKNOWN		(1 << 1)
#define ERROR_TYPE              (1 << 2)
#define ERROR_NOT_AVAILABLE     (1 << 3)
#define ERROR_ELT_MISSING       (1 << 4)
#define ERROR_SORT              (1 << 5)
#define ERROR_NOT_FOUND         (1 << 6)
#define ERROR_NO_MEM            (1 << 7)

/*
 * the other values are reserved for the specific managers use.
 */

#endif
