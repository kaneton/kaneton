/*
 * licence       
 *
 * project       kaneton
 *
 * file          /home/ohmer/projects/kaneton/core/include/arch/machdep/services/services.h
 *
 * created       julien quintard   [sat dec 17 17:16:19 2005]
 * updated       matthieu michaud   [thu mar 23 04:07:47 2006]
 */

#ifndef IA32_SERVICES_SERVICES_H
#define IA32_SERVICES_SERVICES_H	1

/*
 * ---------- includes --------------------------------------------------------
 */

#include <arch/machdep/services/cons.h>
#include <arch/machdep/services/bochs.h>

#endif
