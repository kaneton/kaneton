/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/moon/workspace/kaneton/core/include/kaneton/map/map.h
 *
 * created       germain bauvin    [sun jun 11 03:04:40 2006]
 * updated       germain bauvin    [sun jun 11 03:04:40 2006]
 */
#ifndef KANETON_MAP_H
#define KANETON_MAP_H	1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <arch/machdep/machdep.h>
#include <kaneton/id.h>
#include <kaneton/types.h>

/*
 * ---------- defines ---------------------------------------------------------
 */


/*
 * ---------- types -----------------------------------------------------------
 */

typedef struct
{
  t_staid			stats;
} m_map;

/*
 * ---------- macros ----------------------------------------------------------
 */

/*
 * check
 */

#define MAP_CHECK(_map_)					\
  {									\
    if ((_map_) == NULL)						\
      return (ERROR_UNKNOWN);						\
  }

/*
 * enter
 */

#define MAP_ENTER(_map_)					\
  {									\
    MAP_CHECK((_map_));						\
									\
    STATS_BEGIN((_map_)->stats);					\
  }

/*
 * leave
 */

#define MAP_LEAVE(_map_, _error_)				\
  {									\
    STATS_END((_map_)->stats, (_error_));				\
									\
    return (_error_);							\
  }

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/map/map.c
 */

/*
 * ../../kaneton/map/map.c
 */

t_error map_reserve(t_asid asid, t_opts opts, t_vaddr* addr,
		    t_vsize size, t_perms perms);

t_error map_release(t_asid asid, t_vaddr addr);

t_error map_init(void);

t_error map_clean(void);


/*
 * eop
 */

#endif
