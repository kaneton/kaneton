/*
 * licence
 *
 * project       kaneton
 *
 * file          /home/pouya/workspace/kaneton/core/bootloader/arch/machdep/bootloader.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       pouya mohtacham   [wed may 31 14:29:29 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the bootloader is to install a correct environment for
 * the kernel.
 *
 * the first thing to do is to relocate the different kaneton data structure
 * in order to build the t_init structure. this structure must contain
 * everything the kernel will need.
 *
 * for more information on the relocating, take a look to the kaneton
 * paper which describes the entire kaneton reference.
 *
 * once the init structure was built, the kernel has to be launched.
 *
 * nevertheless, the kernel needs to evolve with the protected mode and
 * paging mode activated, so the bootloader first has to install these.
 *
 * printing some messages is interesting showing the protected mode and
 * paging mode are correctly installed.
 *
 * after all, the bootloader has launch the kernel binary.
 *
 * look at the ld scripts to know where the kernel has to be loaded.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * these three variable are globals to avoid them to be lost when the
 * bootloader changes its stack.
 *
 * indeed, before jumping on the kernel a new stack is created so the local
 * variables will no longer be accessible. putting these variables in
 * globals bypass this problem.
 */

void			(*kernel)(t_init*);

t_reg32			ebp;
t_reg32			esp;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
** main bootloader fonction
*/
int			bootloader(t_uint32					magic,
							  multiboot_info_t*		mbi)
{
  bcons_setup(); //init the console
  bcons_clean(CONS_DEFAULT_ATTR); //clean it
  bcons_printf(0,32,"%#..::%#KANETON%#::..%#",
	      CONS_FRONT(CONS_YELLOW | CONS_INT),
	      CONS_FRONT(CONS_RED | CONS_INT) ,
	      CONS_FRONT(CONS_YELLOW | CONS_INT),
	      CONS_DEFAULT_ATTR);

  bcons_printf(3,43,"%#Steps:%#",
	      CONS_FRONT(CONS_BLUE | CONS_INT),
	      CONS_DEFAULT_ATTR);

  //set GDT
  bcons_printf(4,43,"Setting GDT");
  bcons_printf(4,60,"[%#KO%#]",CONS_FRONT(CONS_RED | CONS_INT), CONS_DEFAULT_ATTR);
  gdt_init(computeGDTAdress(mbi));
  bcons_printf(4,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);

  //initialize t_init
  //relocating datas
  bcons_printf(5,43,"Setting Init          ");
  bcons_printf(5,60,"[%#KO%#]",CONS_FRONT(CONS_RED | CONS_INT), CONS_DEFAULT_ATTR);
  initTask(mbi);
  bcons_printf(5,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);

  //paggin
  bcons_printf(6,43,"Setting Paging        ");
  bcons_printf(6,60,"[%#KO%#]",CONS_FRONT(CONS_RED | CONS_INT), CONS_DEFAULT_ATTR);

  unsigned int pd_addr= computePDAdress(mbi);
  pd_new((void*) pd_addr);
  pt_init(0, pd_addr + PAGESZ);			//first 4M
  pt_init(0x1000, pd_addr + 2 * PAGESZ);	//4M from 0x1000000
  paging_enable((void*) pd_addr);
  bcons_printf(6,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);

  //init stack
  // (MUST be done directly in the fonction)
  bcons_printf(7,43,"Setting KStack         ");
  bcons_printf(7,60,"[%#KO%#]",CONS_FRONT(CONS_RED | CONS_INT), CONS_DEFAULT_ATTR);

  /*   ebp = ((T_reg32*) (init->kstack + init->kstacksz)); */
  /*   esp = ((t_reg32*) (stack_save)); */

  t_uint32 stack_position = (t_uint32)(init->kstack + init->kstacksz);

  asm("movl %%esp, %0\n\t"
      "movl %%ebp, %1\n\t"
      "movl %2, %%ebp\n\t"
      "movl %%ebp, %%esp\n\t"
      : "=r" (esp), "=r" (ebp)
      : "m" (stack_position)
      );

  bcons_printf(7,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);


  //calling kernel
  // (use the elf header to retrieve the entry point addresse)
  bcons_printf(8,43,"calling Kernel       ");
  void** tmp = (void**)(init->kcode + 0x18);
  kernel = *tmp;
  bcons_printf(8,60,"[%#OK%#]",CONS_FRONT(CONS_GREEN | CONS_INT), CONS_DEFAULT_ATTR);
  kernel(init);

  //SI RETOUR : ne pas utiliser ce genre de mots!!!->branler(to branle) un message d'erreur
  // (ecran bleu, un peu windows style ...
  bcons_clean(CONS_FRONT(CONS_CYAN) | CONS_BACK(CONS_CYAN));
  bcons_printf(15, 34, "%#Kaneton error%#",
	      CONS_FRONT(CONS_BLUE | CONS_INT) | CONS_BACK(CONS_RED),
	      CONS_DEFAULT_ATTR);

  for(;;);

  return (0);
}

