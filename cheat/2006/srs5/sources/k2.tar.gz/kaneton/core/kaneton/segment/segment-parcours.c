/**
 * Permet de parcourir l'ensemble des segments d'un gestionnaire de segments
 * auteur: Emmanuel Reynaud
 * version: 1,0
 * date: 28/3/2006
 */

#include <klibc.h>
#include <kaneton.h>
#include "kaneton/segment-parcours.h"
machdep_include(segment);

static t_error _seg_it_f_1(pt_fonction_1_os pf1, t_iterator *it);
static t_error _seg_it_f_2(pt_fonction_2_os pf1, t_iterator *it);

extern m_segment*	segment;

/**
 * Permet d'effectuer un traitement sur chaque segment
 * @param fonction: traite un segment
 */
t_error		segment_iterateur_fonction_1(pt_fonction_1_os pf1)
{
  t_iterator	*it = NULL;

  return _seg_it_f_1(pf1, it);
}

/**
 * Permet de faire le travail de _segment_iterateur proprement dit
 * @param pf: definie le traitement a effectuer
 * @param it: l'ensemble a parcourir
 */
static t_error _seg_it_f_1(pt_fonction_1_os pf1, t_iterator *it)
{
  o_segment	*o = NULL;
  t_error	sortie_erreur = ERROR_NONE;

  set_head(segment->container, it);
  set_object(segment->container, *it, (void **) &o);

  sortie_erreur = pf1(o);//traitement de l'element courant
  if (sortie_erreur != ERROR_NONE)
    return sortie_erreur;

  sortie_erreur = set_next(segment->container, *it, it);
  if (sortie_erreur != ERROR_NONE)
    return sortie_erreur;

      //fin de parcours
  if ((((it->u).ll.node)->nxt) == NULL)
    return ERROR_NONE;

  return _seg_it_f_1(pf1, it);//appel recursif
}

/**
 * Permet d'effectuer un traitement sur chaque couple de segments consecutifs
 * @param fonction: traite deux segments consecutifs
 */
t_error		segment_iterateur_fonction_2(pt_fonction_2_os pf2)
{
  t_iterator	*it = NULL;

  return _seg_it_f_2(pf2, it);
}


/**
 * Permet de faire le travail de _segment_iterateur proprement dit
 * @param pf: definie le traitement a effectuer
 * @param it: pointeur sur l'ensemble a parcourir
 * precondition: l'ensemble est non vide
 */
static t_error _seg_it_f_2(pt_fonction_2_os pf2, t_iterator *it)
{
  o_segment	*o_seg_courant = NULL;
  o_segment	*o_seg_suivant = NULL;
  t_error	sortie_erreur = ERROR_NONE;

  //recuperation du segment courant
  sortie_erreur = set_head(segment->container, it);
  if (sortie_erreur != ERROR_NONE)
    return sortie_erreur;

  sortie_erreur = set_object(segment->container, *it,
			     (void **) &o_seg_courant);
  if (sortie_erreur != ERROR_NONE)
    return sortie_erreur;

  //fin de parcours: il n'y a rien apres
  if ((((it->u).ll.node)->nxt) == NULL)
    return pf2(o_seg_courant, o_seg_suivant);


  //on passe au segment suivant
  sortie_erreur = set_next(segment->container, *it, it);
  if (sortie_erreur != ERROR_NONE)
    return sortie_erreur;

  sortie_erreur = set_object(segment->container, *it,
			     (void **) &o_seg_suivant);
  if (sortie_erreur != ERROR_NONE)
    return sortie_erreur;

  pf2(o_seg_courant, o_seg_suivant);//traitement des deux segments

  return _seg_it_f_2(pf2, it);//appel recursif
}
