/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/set/set_array.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 24 19:50:54 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  subpart  of the  set  manager is  used  to  build array  data
 * structures.
 *
 * there  are two  way  to use  the  arrays :  with  pointers or  with
 * objects.    the  first   method   is  the   default  one   (without
 * SET_OPT_ALLOC) : it only  stores pointers refering to objects.  The
 * second method (used with  SET_OPT_ALLOC) makes copies of objects in
 * the set,  using memcpy. with  SET_OPT_FREE, objects are  freed when
 * they   are  removed   from  the   array  or   when  the   array  is
 * flushed/released.
 *
 * the option ORGANISE is used to keep the array as small as possible,
 * but  some operation  requires to  shift entire  parts of  the array
 * (loss of performances).
 *
 * when an array set is cloned, data are reorganised in. it means than
 * when a  clone operation occurs,  the array is reduced  clearing the
 * empty/unused places.
 *
 * options:    SET_OPT_CONTAINER,    SET_OPT_SORT,   SET_OPT_ORGANISE,
 * SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire array data structure.
 *
 * this data structure is very useful to contain very little objects like
 * identifiers.
 *
 * the address space objects, the task objects etc.. use it widely.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

static t_error		_insert_data(void**		new,
				     void*		data,
				     t_opts		opts,
				     t_size		datasz)
{
  if (opts & SET_OPT_ALLOC)
    {
      *new = malloc(datasz);
      if (*new == NULL)
	return (ERROR_UNKNOWN);
      memcpy(*new, data, datasz);
    }
  else
      *new = data;
  return (ERROR_NONE);
}

static t_error		_remove_data(void**		data,
				     t_opts		opts)
{
  if (opts & SET_OPT_FREE)
    free(*data);
  else
    ((o_id*)(*data))->id = ID_UNUSED;
  return (ERROR_NONE);
}

static t_error		_set_organize(t_setid		setid)
{
  void**		newdata;
  o_set*		s;
  int			i, j;

  if (set_descriptor(setid, &s) != ERROR_NONE)
    return (ERROR_UNKNOWN);

  newdata = malloc(s->size * sizeof(void*));
  if (newdata == NULL)
    return (ERROR_UNKNOWN);
  for (i = 0, j = 0;
       i < s->u.array.arraysz && j < s->size;
       ++i)
    {
      if (s->u.array.array[i] != NULL &&
	  ((o_id*)(s->u.array.array[i]))->id != ID_UNUSED)
	{
	  newdata[j] = s->u.array.array[i];
	  ++j;
	}
      else
	free(s->u.array.array[i]);
    }
  return (ERROR_NONE);
}

static t_error		_set_sort(t_setid		setid)
{
  o_set*		s;
  void*			tmp;
  int			i;
  int			nbperm;

  if (set_descriptor(setid, &s) != ERROR_NONE)
    return (ERROR_UNKNOWN);

  for (nbperm = 1; nbperm;)
    {
      for (i = 0, nbperm = 0; i < (s->u.array.arraysz - 1); ++i)
	if (s->u.array.array[i] == NULL ||
	    ((o_id*)(s->u.array.array[i]))->id == ID_UNUSED ||
	    (((o_id*)(s->u.array.array[i]))->id >
	     ((o_id*)(s->u.array.array[i + 1]))->id))
	  {
	    tmp = s->u.array.array[i];
	    s->u.array.array[i] = s->u.array.array[i + 1];
	      s->u.array.array[i + 1] = tmp;
	      ++nbperm;
	  }
    }
  return ERROR_NONE;
}

t_error			set_type_array(t_setid		setid)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  s->type = SET_TYPE_ARRAY;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_show_array(t_setid		setid)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  printf("Set id: %#%i%# -- Set type: %#ARRAY%# -- Set size: %#%i%# bytes\n",
	 CONS_BLUE, s->setid, CONS_WHITE,
	 CONS_BLUE, CONS_WHITE,
	 CONS_BLUE, s->size, CONS_WHITE);
  printf("Set opts: %#%i%# -- Set data size: %#%i%# -- Initsz%#%i%# -"
	 "- Array: %#%p%# -- Arraysz: %#%i%#\n",
	 CONS_BLUE, s->u.array.opts, CONS_WHITE,
	 CONS_BLUE, s->u.array.datasz, CONS_WHITE,
	 CONS_BLUE, s->u.array.initsz, CONS_WHITE,
	 CONS_BLUE, s->u.array.array, CONS_WHITE,
	 CONS_BLUE, s->u.array.arraysz, CONS_WHITE);
  SET_LEAVE(set, ERROR_NONE);
}


t_error			set_head_array(t_setid		setid,
				       t_iterator*	iterator)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  iterator->u.array.i = 0;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_tail_array(t_setid		setid,
				       t_iterator*	iterator)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  iterator->u.array.i = s->u.array.arraysz - 1;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_prev_array(t_setid		setid,
				       t_iterator	current,
				       t_iterator*	previous)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (current.u.array.i == 0)
    SET_LEAVE(set, ERROR_UNKNOWN);
  previous->u.array.i = current.u.array.i - 1;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_next_array(t_setid		setid,
				       t_iterator	current,
				       t_iterator*	next)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (current.u.array.i >= (s->u.array.arraysz - 1))
    SET_LEAVE(set, ERROR_UNKNOWN);
  next->u.array.i = current.u.array.i + 1;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_head_array(t_setid	setid,
					      void*	data)
{
  o_set*		s;
  void**		newarray;
  int			i;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if ((s->u.array.opts & SET_OPT_ORGANISE) ||
      (s->u.array.opts & SET_OPT_SORT))
    SET_LEAVE(set, set_add_array(setid, data));

  if (s->size >= s->u.array.arraysz)
    {
      newarray = realloc(s->u.array.array, s->u.array.arraysz * 2);
      if (newarray == NULL)
	SET_LEAVE(setid, ERROR_UNKNOWN);
      s->u.array.array = newarray;
      s->u.array.arraysz *= 2;
      s->u.array.array = newarray;
    }
  for (i = s->u.array.arraysz - 1; i; --i)
    s->u.array.array[i] = s->u.array.array[i - 1];
  s->u.array.array[i] = data;
  s->size++;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_tail_array(t_setid	setid,
					      void*	data)
{
  o_set*		s;
  void**		newarray;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if ((s->u.array.opts & SET_OPT_ORGANISE) ||
      (s->u.array.opts & SET_OPT_SORT))
    SET_LEAVE(set, set_add_array(setid, data));
  if (s->size >= s->u.array.arraysz)
    {
      newarray = realloc(s->u.array.array, s->u.array.arraysz * 2);
      if (newarray == NULL)
	SET_LEAVE(setid, ERROR_UNKNOWN);
      s->u.array.array = newarray;
      s->u.array.arraysz *= 2;
    }
  s->u.array.array[s->u.array.arraysz - 1] = data;
  s->size++;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_before_array(t_setid	setid,
					     t_iterator	iterator,
						void*	data)
{
  o_set*		s;
  void**		newarray;
  int			i;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if ((s->u.array.opts & SET_OPT_ORGANISE) ||
      (s->u.array.opts & SET_OPT_SORT))
    SET_LEAVE(set, set_add_array(setid, data));

  if (s->size >= s->u.array.arraysz)
    {
      newarray = realloc(s->u.array.array, s->u.array.arraysz * 2);
      if (newarray == NULL)
	SET_LEAVE(setid, ERROR_UNKNOWN);
      s->u.array.array = newarray;
      s->u.array.arraysz *= 2;
      s->u.array.array = newarray;
    }
  for (i = s->u.array.arraysz - 1; i >= iterator.u.array.i; --i)
    s->u.array.array[i] = s->u.array.array[i - 1];
  s->u.array.array[i] = data;
  s->size++;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_after_array(t_setid	setid,
					    t_iterator	iterator,
					       void*	data)
{
  o_set*		s;
  void**		newarray;
  int			i;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if ((s->u.array.opts & SET_OPT_ORGANISE) ||
      (s->u.array.opts & SET_OPT_SORT))
    SET_LEAVE(set, set_add_array(setid, data));

  if (s->size >= s->u.array.arraysz)
    {
      newarray = realloc(s->u.array.array, s->u.array.arraysz * 2);
      if (newarray == NULL)
	SET_LEAVE(setid, ERROR_UNKNOWN);
      s->u.array.array = newarray;
      s->u.array.arraysz *= 2;
      s->u.array.array = newarray;
    }
  for (i = s->u.array.arraysz - 1; i > iterator.u.array.i; --i)
    s->u.array.array[i] = s->u.array.array[i - 1];
  s->u.array.array[i] = data;
  s->size++;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_add_array(t_setid		setid,
				      void*		data)
{
  o_set*		s;
  void**		newarray;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (s->size >= s->u.array.arraysz)
    {
      newarray = realloc(s->u.array.array, s->u.array.arraysz * 2);
      if (newarray == NULL)
	SET_LEAVE(setid, ERROR_UNKNOWN);
      s->u.array.array = newarray;
      s->u.array.arraysz *= 2;
    }
  if (ERROR_UNKNOWN == _insert_data(s->u.array.array + s->size - 1, data,
				    s->u.array.opts, s->u.array.datasz))
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (s->u.array.opts & SET_OPT_ORGANISE)
    if (ERROR_UNKNOWN == _set_organize(setid))
      SET_LEAVE(set, ERROR_UNKNOWN);
  if (s->u.array.opts & SET_OPT_SORT)
    if (ERROR_UNKNOWN == _set_sort(setid))
      SET_LEAVE(set, ERROR_UNKNOWN);
  s->size++;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_remove_array(t_setid	setid,
					 t_id		id)
{
  o_set*		s;
  int			i;
  t_iterator		it;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  for (i = 0; i < s->u.array.arraysz; ++i)
    if (s->u.array.array[i] != NULL)
      if (((o_id*)(s->u.array.array[i]))->id == id)
	{
	  it.u.array.i = i;
	  SET_LEAVE(setid, set_delete_array(setid, it));
	  break;
	}
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_delete_array(t_setid	setid,
					 t_iterator	iterator)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (ERROR_UNKNOWN == _remove_data(&s->u.array.array[iterator.u.array.i],
				    s->u.array.opts))
    SET_LEAVE(set, ERROR_UNKNOWN);
  --s->size;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_flush_array(t_setid		setid)
{
  // FIXME
  o_set*		s;
  int			i;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  for (i = 0; i < s->u.array.arraysz; ++i)
    if (ERROR_UNKNOWN == _remove_data(&s->u.array.array[i], s->u.array.opts))
      SET_LEAVE(set, ERROR_UNKNOWN);
  s->size = 0;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_locate_array(t_setid	setid,
					 t_id		id,
					 t_iterator*	iterator)
{
  o_set*		s;
  int			i;
  t_iterator		it;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  for (i = 0; i < s->u.array.arraysz; ++i)
    if (s->u.array.array[i] != NULL)
      if (((o_id*)(s->u.array.array[i]))->id == id)
	{
	  it.u.array.i = i;
	  *iterator = it;
	  break;
	}
  if (((o_id*)(s->u.array.array[i]))->id != id)
    SET_LEAVE(set, ERROR_UNKNOWN);
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_object_array(t_setid	setid,
					 t_iterator	iterator,
					 void**		data)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (iterator.u.array.i == ID_UNUSED)
    SET_LEAVE(set, ERROR_UNKNOWN);
  *data = s->u.array.array[iterator.u.array.i];
  SET_LEAVE(set, ERROR_NONE);
}

/* t_error			set_push_array(t_setid		setid, */
/* 				    void*		data) */
/* { */
/*   // Push should have no sense with array set */
/*   // We allow it to be used as set_insert_head */
/*   SET_ENTER(set); */
/*   SET_LEAVE(set, set_insert_head(setid, data)); */
/* } */

/* t_error			set_pop_array(t_setid		setid) */
/* { */
/*   // FIXME: TODO */
/*   // Pop should have no sense with array set */
/*   // We use it to remove the head of the linked list (usefull to flush the set) */
/*   o_set*		s; */
/*   t_id			del; */

/*   SET_ENTER(set); */
/*   if (set_descriptor(setid, &s) != ERROR_NONE) */
/*     SET_LEAVE(set, ERROR_UNKNOWN); */

/*   if (s->u.array.head == NULL) */
/*     SET_LEAVE(set, ERROR_NONE); */
/*   del = ((o_id*)(s->u.array.head->data))->id; */
/*   SET_LEAVE(set, set_remove_array(setid, del)); */
/* } */

/* t_error			set_pick_array(t_setid		setid, */
/* 				    void**		data) */
/* { */
/*   // Has no sense with array set */
/*   SET_ENTER(set); */
/*   SET_LEAVE(set, ERROR_UNKNOWN); */
/* } */

t_error			set_release_array(t_setid	setid)
{
  // FIXME
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (ERROR_UNKNOWN == set_flush_array(setid))
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (ERROR_UNKNOWN == set_remove(set->container, setid))
    SET_LEAVE(set, ERROR_UNKNOWN);
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_reserve_array(t_opts	opts,
					  t_setsz	initsz,
					  t_size	datasz,
					  t_setid*	setid)
{
  o_set*		s;

  SET_ENTER(set);
  if ((s = malloc(sizeof(o_set))) == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  id_reserve(&(set->id), setid);
  s->setid = *setid;
  s->type = SET_TYPE_ARRAY;
  s->size = 0;
  s->u.array.opts = opts;
  s->u.array.datasz = datasz;
  s->u.array.initsz = initsz;
  s->u.array.arraysz = initsz;
  s->u.array.array = malloc(initsz * sizeof(void*));
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_clone_array(t_setid		setid,
					t_setid*	cloneid)
{
  o_set*		clone;
  o_set*		s;
  int			i;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  /*
   * 1)
   */
  if (set_reserve_array(SET_OPT_ORGANISE | SET_OPT_ALLOC,
			s->u.array.initsz,
			s->u.array.datasz,
			cloneid) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  /*
   * 2)
   */
  if (set_descriptor(*cloneid, &clone) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  /*
   * 3)
   */
  for (i = 0; i < s->u.array.arraysz; ++i)
    if (s->u.array.array[i] != NULL &&
	((o_id*)(s->u.array.array[i]))->id != ID_UNUSED)
      if(set_add_array(*cloneid, s->u.array.array[i]) != ERROR_NONE)
	SET_LEAVE(set, ERROR_UNKNOWN);
  /*
   * 4)
   */
  clone->u.array.opts = s->u.array.opts;
  SET_LEAVE(set, ERROR_NONE);
}
