/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/segment/segment-fit.c
 *
 * created       matthieu bucchianeri   [tue jan 10 01:03:46 2006]
 * updated       matthieu bucchianeri   [tue jan 31 00:20:33 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file implements simple  fitting algorithms for physical memory
 * management.
 *
 * you can define which algorithm to use with the macro SEGMENT_FIT.
 *
 *  - FIT_FIRST: first fit algorithm - the first large enough space is taken
 *  - FIT_BEST: best fit algorithm - the smaller space is taken
 *  - ...
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  have  to develop  at  least  the  first-fit algorithm  to
 * allocate physical memory.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <kaneton/segment-parcours.h>//Rajoute par reynau_e.

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

extern m_segment*	segment;

static t_error	_segment_first_fit(o_segment *os_courant,
				   o_segment *os_suivant);


/*
 * ---------- variables globales ----------------------------------------------
 */
t_asid		asid;
t_psize		taille_requise;
t_paddr*	adr;

/*
 * ---------- functions -------------------------------------------------------
 */

/* This function searchs the given address space for a segment of given size.
   This function must be placed in a separated file: take a look at the SEGMENT FILE
   variable in you user.conf file.
   As there can be more than one algorithm available, do not forget to use the SEGMENT
   FIT define in your conf.h file.
   More values can be added in core/include/kaneton/kaneton.h
*/
t_error		segment_fit(o_as* as, t_psize size,
			    t_paddr* address)
{
  asid = as->asid;
  taille_requise = size;
  adr = address;

  SEGMENT_ENTER(segment);

  switch (SEGMENT_FIT)
    {
      // ici pour rajouter d'autres algorithmes
    default:
    case FIT_FIRST:
      SEGMENT_LEAVE(segment, segment_iterateur_fonction_2(&_segment_first_fit));
    }
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/**
 * Permet d'ajouter un o_segment selon l'algorithme
 * de la premiere place libre suffisante.
 * precondition: os_courant est non NULL
 * @return sortie_errreur: vaut ERROR_NONE si et seulement si le
 */
static t_error	_segment_first_fit(o_segment *os_courant,
				   o_segment *os_suivant)
{
  t_psize	espace_libre = 0;
  t_paddr	adresse_suivant_as_courant = 0;
  //  o_segment	*os_ajoute = NULL;

  adresse_suivant_as_courant = os_courant->address + os_courant->size;

  if (os_suivant->asid == ID_UNUSED)//fin de l'espace d'adressage
    {
      espace_libre = (segment->start + segment->size)
	- adresse_suivant_as_courant;
      if (taille_requise <= espace_libre)
	{
	  adr = &adresse_suivant_as_courant;
	  return ERROR_NONE;
	}
      else
	{//On a parcouru tout l'espace d'adressage, et il
	  //n'y a plus assez de place.
	  return ERROR_UNKNOWN;
	}
    }
  else
    {//On regarde l'espce libre entre deux segments
      espace_libre = os_suivant->address - adresse_suivant_as_courant;
      if (taille_requise <= espace_libre)
	{
	  adr = &adresse_suivant_as_courant;
	  return ERROR_NONE;
	}
      else
	{
	  //Il n'y a pas assez d'espace libre
	  return ERROR_UNKNOWN;
	}
    }
}
