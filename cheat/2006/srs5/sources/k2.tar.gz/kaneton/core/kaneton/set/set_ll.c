/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/kaneton/set/set_ll.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon dec 19 17:25:13 2005]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this subpart of the set manager is used to build linked-list
 * data structures.
 *
 * note that this data structure is in fact a doubly linked-list.
 *
 * each set of this type can be used in two ways. the first one ask the
 * set manager to allocate and copy each object to add while the second
 * way tells the set manager to simply include the objects in the set.
 *
 * moreover the option free can be used to tell the set manager to call
 * the free() function each time an object is released. this option
 * means that objects passed to the set manager was previously allocated
 * with the malloc() functions suite.
 *
 * moreover, the linked-list data structure can be used either with the
 * sort option or without.
 *
 * the datasz argument of the set_reserve() function is meaningful only in the
 * case the allocate or free options are set.
 *
 * options: SET_OPT_CONTAINER, SET_OPT_SORT, SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire linked-list data structure, nothing
 * less, nothing more.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

static t_error		_insert_data(void**		new,
				     void*		data,
				     t_opts		opts,
				     t_size		datasz)
{
  if (opts & SET_OPT_ALLOC)
    {
      *new = malloc(datasz);
      if (*new == NULL)
	return ERROR_UNKNOWN;

      memcpy(*new, data, datasz);
    }
  else
      *new = data;
  return ERROR_NONE;
}

static t_error		_remove_data(void*		data,
				     t_opts		opts)
{
  if (opts & SET_OPT_FREE)
    free(data);
  return ERROR_NONE;
}

t_error			set_type_ll(t_setid		setid)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  s->type = SET_TYPE_LL;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_show_ll(t_setid		setid)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  printf("%p\n", s);
  printf("Set id: %i -- Set address: 0x%p -- Set type: LL -- Set size: %i\n",
	 s->setid, s, s->size);
  printf("Set opts: %i -- Set data size: %i -- Head: 0x%p -- Tail: 0x%p\n",
	 s->u.ll.opts, s->u.ll.datasz, s->u.ll.head, s->u.ll.tail);
  SET_LEAVE(set, ERROR_NONE);
}


t_error			set_head_ll(t_setid		setid,
				    t_iterator*		iterator)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  iterator->u.ll.node = s->u.ll.head;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_tail_ll(t_setid		setid,
				    t_iterator*		iterator)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  iterator->u.ll.node = s->u.ll.tail;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_prev_ll(t_setid		setid,
				    t_iterator		current,
				    t_iterator*		previous)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  previous->u.ll.node = current.u.ll.node->prv;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_next_ll(t_setid		setid,
				    t_iterator		current,
				    t_iterator*		next)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  next->u.ll.node = current.u.ll.node->nxt;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_head_ll(t_setid	setid,
					   void*	data)
{
  o_set*		s;
  t_set_ll_node*	new;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  new = malloc(sizeof(t_set_ll_node));
  if (new == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (ERROR_UNKNOWN == _insert_data(&new->data, data, s->u.ll.opts, s->u.ll.datasz))
    SET_LEAVE(set, ERROR_UNKNOWN);
  new->prv = NULL;
  new->nxt = s->u.ll.head;
  s->u.ll.head = new;
  if (s->u.ll.head != NULL)
    s->u.ll.head->prv = new;
  s->size++;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_tail_ll(t_setid	setid,
					   void*	data)
{
  o_set*		s;
  t_set_ll_node*	new;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  new = malloc(sizeof(t_set_ll_node));
  if (new == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (ERROR_UNKNOWN == _insert_data(&new->data, data, s->u.ll.opts, s->u.ll.datasz))
    SET_LEAVE(set, ERROR_UNKNOWN);
  new->prv = s->u.ll.tail;
  new->nxt = NULL;
  s->u.ll.tail = new;
  if (s->u.ll.tail != NULL)
  s->u.ll.tail->nxt = new;
  s->size++;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_before_ll(t_setid	setid,
					     t_iterator	iterator,
					     void*	data)
{
  o_set*		s;
  t_set_ll_node*	new;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (iterator.u.ll.node == s->u.ll.head)
    SET_LEAVE(set, set_insert_head_ll(setid, data));
  new = malloc(sizeof(t_set_ll_node));
  if (new == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (ERROR_UNKNOWN == _insert_data(&new->data, data, s->u.ll.opts, s->u.ll.datasz))
    SET_LEAVE(set, ERROR_UNKNOWN);
  new->prv = iterator.u.ll.node->prv;
  new->nxt = iterator.u.ll.node;
  iterator.u.ll.node->prv = new;
  if (iterator.u.ll.node->prv != NULL)
    iterator.u.ll.node->prv->nxt = new;
  s->size++;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_after_ll(t_setid	setid,
					    t_iterator	iterator,
					    void*	data)
{
  o_set*		s;
  t_set_ll_node*	new;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (iterator.u.ll.node == s->u.ll.tail)
    SET_LEAVE(set, set_insert_tail_ll(setid, data));
  new = malloc(sizeof(t_set_ll_node));
  if (new == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (ERROR_UNKNOWN == _insert_data(&new->data, data, s->u.ll.opts, s->u.ll.datasz))
    SET_LEAVE(set, ERROR_UNKNOWN);
  new->prv = iterator.u.ll.node;
  new->nxt = iterator.u.ll.node->nxt;
  iterator.u.ll.node->nxt = new;
  if (iterator.u.ll.node->nxt)
    iterator.u.ll.node->nxt->prv = new;
  s->size++;
  SET_LEAVE(set, ERROR_NONE);
}


t_error			set_add_ll(t_setid		setid,
				   void*		data)
{
  void*			d;
  o_set*		s;
  t_iterator		i;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (s->u.ll.opts & SET_OPT_SORT)
    {
      for (i.u.ll.node = s->u.ll.head;
	   i.u.ll.node;
	   i.u.ll.node = i.u.ll.node->nxt)
	{
	  if (set_object(set->container, i, (void**)&d) != ERROR_NONE)
	    {
	      cons_msg('!', "set: cannot find the set object "
		       "corresponding to its identifier\n");

	      SET_LEAVE(set, ERROR_UNKNOWN);
	    }
	  if (((o_id*)(data))->id > ((o_id*)(d))->id)
	    SET_LEAVE(setid, set_insert_after_ll(setid, i, data));
	}
      SET_LEAVE(set, set_insert_tail_ll(setid, data));
    }
  SET_LEAVE(set, set_insert_head_ll(setid, data));
}

t_error			set_remove_ll(t_setid		setid,
				      t_id		id)
{
  // FIXME: TODO
  o_set*		s;
  t_state		state;
  void*			data;
  t_iterator		i;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  set_foreach(SET_OPT_FORWARD, set->container, &i, state)
    {
      if (set_object_ll(setid, i, (void**)&data) != ERROR_NONE)
	{
	  cons_msg('!', "set: cannot find the object "
		   "corresponding to its identifier\n");

	  return ERROR_NONE;
	  SET_LEAVE(set, ERROR_UNKNOWN);
	}

      if (ERROR_UNKNOWN == _remove_data(i.u.ll.node->data, s->u.ll.opts))
	SET_LEAVE(set, ERROR_UNKNOWN);
    }
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_delete_ll(t_setid		setid,
				      t_iterator	iterator)
{
  o_set*		s;
  t_set_ll_node*	del;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  del = iterator.u.ll.node;
  if (del == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (del->prv != NULL)
    del->prv->nxt = del->nxt;
  if (del->nxt != NULL)
    del->nxt->prv = del->prv;
  _remove_data(del->data, s->u.ll.opts);
  free(del);
  --s->size;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_flush_ll(t_setid		setid)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  while (s->size)
      if (ERROR_UNKNOWN == set_pop_ll(setid))
	SET_LEAVE(set, ERROR_UNKNOWN);
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_locate_ll(t_setid		setid,
				      t_id		id,
				      t_iterator*	iterator)
{
  // FIXME: TODO
  o_set*		s;
  t_state		state;
  void*			data;
  t_iterator		i;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  set_foreach(SET_OPT_FORWARD, set->container, &i, state)
    {
      if (set_object_ll(setid, i, (void**)&data) != ERROR_NONE)
	{
	  cons_msg('!', "set: cannot find the set object "
		   "corresponding to its identifier\n");

	  SET_LEAVE(set, ERROR_UNKNOWN);
	}

      if (((o_id*)(i.u.ll.node->data))->id == id)
	{
	  *iterator = i;
	  break;
	}
    }
  if (((o_id*)(i.u.ll.node->data))->id != id)
    SET_LEAVE(set, ERROR_UNKNOWN);
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_object_ll(t_setid		setid,
				      t_iterator	iterator,
				      void**		data)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (iterator.u.ll.node == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  *data = iterator.u.ll.node->data;
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_push_ll(t_setid		setid,
				    void*		data)
{
  // Push should have no sense with ll set
  // We allow it to be used as set_insert_head
  SET_ENTER(set);
  SET_LEAVE(set, set_insert_head(setid, data));
}

t_error			set_pop_ll(t_setid		setid)
{
  // FIXME: TODO
  // Pop should have no sense with ll set
  // We use it to remove the head of the linked list (usefull to flush the set)
  o_set*		s;
  t_id			del;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (s->u.ll.head == NULL)
    SET_LEAVE(set, ERROR_NONE);
  del = ((o_id*)(s->u.ll.head->data))->id;
  SET_LEAVE(set, set_remove_ll(setid, del));
}

t_error			set_release_ll(t_setid		setid)
{
  o_set*		s;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (ERROR_UNKNOWN == set_flush_ll(setid))
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (ERROR_UNKNOWN == set_remove(set->container, setid))
    SET_LEAVE(set, ERROR_UNKNOWN);
  SET_LEAVE(set, ERROR_NONE);
}

static t_error		_set_reserve_container(t_opts	opts,
					       t_size	datasz)
{
  o_set*		s;
  t_set_ll_node*	n;

  SET_ENTER(set);
  if ((set->co = malloc(sizeof(o_set))) == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  s = set->co;
  memset(s, 0x0, sizeof(o_set));
  if ((n = malloc(sizeof(t_set_ll_node))) == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  n->data = s;
  n->prv = NULL;
  n->nxt = NULL;
  printf("data: %p, n->data: %p, nxt: %d, prv: %d\n",
	 s, n->data, n->nxt, n->prv);
  s->setid = set->container;
  s->type = SET_TYPE_LL;
  s->size = 1;
  s->u.ll.opts = opts;
  s->u.ll.datasz = datasz;
  s->u.ll.head = n;
  s->u.ll.tail = n;
  printf("\n");
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_reserve_ll(t_opts		opts,
				       t_size		datasz,
				       t_setid*		setid)
{
  o_set*		s;

  SET_ENTER(set);
  if (opts & SET_OPT_CONTAINER)
    SET_LEAVE(set, _set_reserve_container(opts, datasz));
  s = malloc(sizeof(o_set));
  if (s == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (id_reserve(&(set->id), setid) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);
  s->setid = *setid;
  s->type = SET_TYPE_LL;
  s->size = 0;
  s->u.ll.opts = opts;
  s->u.ll.datasz = datasz;
  s->u.ll.head = NULL;
  s->u.ll.tail = NULL;
  set_add_ll(set->container, s);
  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_clone_ll(t_setid		setid,
				     t_setid*		cloneid)
{
  o_set*		clone;
  o_set*		s;
  t_iterator		i;

  SET_ENTER(set);
  if (set_descriptor(setid, &s) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  /*
   * 1)
   */
  if (set_reserve_ll(SET_OPT_ORGANISE | SET_OPT_ALLOC,
		     s->u.ll.datasz,
		     cloneid) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  /*
   * 2)
   */
  if (set_descriptor(*cloneid, &clone) != ERROR_NONE)
    SET_LEAVE(set, ERROR_UNKNOWN);

  /*
   * 3)
   */
  for (i.u.ll.node = s->u.ll.head;
       i.u.ll.node != NULL;
       i.u.ll.node = i.u.ll.node->nxt)
    if(set_add_ll(*cloneid, i.u.ll.node->data) != ERROR_NONE)
      SET_LEAVE(set, ERROR_UNKNOWN);
  /*
   * 4)
   */
  clone->u.ll.opts = s->u.ll.opts;
  SET_LEAVE(set, ERROR_NONE);
}
