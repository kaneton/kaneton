/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/as/as.c
 *
 * created       julien quintard   [tue dec 13 03:05:27 2005]
 * updated       matthieu bucchianeri   [fri jan 27 18:11:14 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the address space manager manages address spaces.
 *
 * an address space describes process' useable memory. each address space
 * is composed of two sets.
 *
 * the first describes the segments held by this address space, in other
 * words the physical memory.
 *
 * the latter describes the regions, the virtual areas which reference
 * some segments.
 *
 * a task can give its address space to another with as_give.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the address space manager builds address space objects.
 *
 * every address space object is essentially composed of two sets: a
 * set of segments which list the segments held by this address space and
 * a set of regions which describes the useable virtual address ranges.
 *
 * the student just has to write the functions to reserve, release, get etc..
 * an address space.
 *
 * note that the address space does nothing more. indeed, the segment
 * manager and the region manager will add and/or remove the segments/regions
 * to/from the address space by their own.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(as);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the address space manager variable.
 */

m_as*			as = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */


/**
 * This function shows a precise address space displaying information on it.
 */
t_error		as_show(t_asid asid)
{
  t_error	ret = ERROR_NONE;
  o_as*		o = NULL;


  AS_ENTER(as);
  if ((o = malloc(sizeof (o_as))) == NULL)
    AS_LEAVE(as, ERROR_UNKNOWN);

  if ((ret = as_get(asid, &o)) != ERROR_UNKNOWN)
    AS_LEAVE(as, ret);
  printf(" +--\n | as numero : %i\n", o->asid);
  printf(" | appartient a la task : %i\n", o->tskid);
  printf(" | contient le segment : %i\n", o->segments);
  printf(" | detail du segment :\n");
  set_show(o->segments);
  printf(" | contient la region : %i\n", o->segments);
  printf(" | detail de la region :\n");
  set_show(o->regions);
  printf(" | as numero : %i END\n +--\n", o->asid);

  AS_LEAVE(as, ret);
}

/**
 * This function dumps all the address space managed by the address space manager.
 * +get the iterator of the first element of the list
 *
 * +get the o_as from the iterator
 * +as_show the o_as->asid
 * +get the next element of the list and loop
 */
t_error		as_dump(void)
{
  void**	data = NULL;
  o_as*		ocur = NULL;
  t_error	ret = ERROR_NONE;
  t_error	loop = ERROR_NONE;
  t_iterator*	it = NULL;
  t_iterator*	itnext = NULL;

  AS_ENTER(as);

  if ((loop = set_head(as->container, it)) != ERROR_NONE)
    AS_LEAVE(as, ERROR_UNKNOWN);
  printf("+--\n| AS DUMP\n");
  while (loop == ERROR_NONE)
    {
      if ((loop = set_object(as->container, *it, data)) != ERROR_NONE)
	AS_LEAVE(as, loop);
      ocur = (o_as *) data;
      if ((ret = as_show(ocur->asid)) != ERROR_NONE)
	AS_LEAVE(as, ret);
      if ((loop = set_next(as->container, *it, itnext)) != ERROR_NONE)
	AS_LEAVE(as, loop);
      it = itnext;
    }
  printf("| AS DUMP END\n+--\n");
  AS_LEAVE(as, ret);
}

/**
 * This function clones an address space taking care of cloning everything necessary.
 * -- For k2, you don't have to deal with tasks, so you must ignore the task arguments.
 * +create old o_as and new o_as
 * +fill old o_as
 * +reserve new o_as in as manager
 * +clone old segments set
 * +clone old regions set
 * +apply as to task
 */
t_error		as_clone(t_tskid tskid, t_asid old, t_asid* new)
{
  o_as*		orig = NULL;
  o_as*		clone = NULL;
  t_error	ret = ERROR_NONE;

  AS_ENTER(as);
  if ((orig = malloc(sizeof (o_as))) == NULL)
    AS_LEAVE(as, ERROR_UNKNOWN);
  if ((clone = malloc(sizeof (o_as))) == NULL)
    AS_LEAVE(as, ERROR_UNKNOWN);

  if ((ret = as_get(old, &orig)) != ERROR_UNKNOWN)
    AS_LEAVE(as, ret);

  if ((ret = as_reserve(tskid, new)) != ERROR_UNKNOWN)
    AS_LEAVE(as, ret);
  clone->asid = *new;

  if ((ret = set_clone(orig->segments, &clone->segments)) != ERROR_UNKNOWN)
    AS_LEAVE(as, ret);

  if ((ret = set_clone(orig->regions, &clone->regions)) != ERROR_UNKNOWN)
    AS_LEAVE(as, ret);

  clone->tskid = tskid;

  AS_LEAVE(as, ret);
}

/**
 * This function reserves an address space object for the task task.
 * +create a new o_as
 * +get a new id for this o_as
 * +apply to the task
 * +reserve segments set
 * +reserve regions set
 * +add this o_as in the as container
 */
t_error		as_reserve(t_tskid tskid, t_asid* asid)
{
  o_as		*o = NULL;
  t_error	ret = ERROR_NONE;

  AS_ENTER(as);
  if ((o = malloc(sizeof (o_as))) == NULL)
    AS_LEAVE(as, ERROR_UNKNOWN);
  if ((ret = id_reserve(&as->id, &o->asid)) != ERROR_NONE)
    AS_LEAVE(as, ERROR_NONE);

  o->tskid = tskid;
  if ((ret = set_reserve(ll, SET_OPT_CONTAINER,
			 sizeof (o_segment)/*AS_SEGMENTS_INITSZ*/, &o->segments)) != ERROR_NONE)
    AS_LEAVE(as, ERROR_NONE);
  if ((ret = set_reserve(ll, SET_OPT_CONTAINER,
			 sizeof (o_region)/*AS_SEGMENTS_INITSZ*/, &o->regions)) != ERROR_NONE)
    AS_LEAVE(as, ERROR_NONE);

  if ((ret = set_add(as->container, o)) != ERROR_NONE)
    AS_LEAVE(as, ret);

  AS_LEAVE(as, ret);
}

/**
 * This function just releases an address space.
 */
t_error		as_release(t_asid asid)
{
  t_error	ret = ERROR_NONE;

  AS_ENTER(as);
  if ((ret = set_remove(as->container, asid)) != ERROR_NONE)
    AS_LEAVE(as, ret);
  AS_LEAVE(as, ret);
}

/**
 * This function should only be used by the segment and region managers.
 * This function just returns the address space ob ject corresponding to the address space
 * identifier.
 */
t_error		as_get(t_asid asid, o_as** o)
{
  t_error	ret = ERROR_NONE;

  AS_ENTER(as);
  if ((ret = set_get(as->container, asid, (void **) o)) != ERROR_NONE)
    AS_LEAVE(as, ret);
  AS_LEAVE(as, ret);
}

/**
 * This function initializes the address space manager.
 * +malloc an as manager
 * +create an as manager identifier
 * +create a set
 */
t_error		as_init(void)
{
  t_error	ret = ERROR_NONE;

  AS_ENTER(as);
  if ((as = malloc(sizeof (m_as))) == NULL)
    AS_LEAVE(as, ERROR_UNKNOWN);

  if ((ret = id_build(&as->id)) != ERROR_UNKNOWN)
    AS_LEAVE(as, ret);

  if ((ret = set_reserve(ll, SET_OPT_CONTAINER, sizeof (o_as), &as->container))
      != ERROR_NONE)
    AS_LEAVE(as, ERROR_UNKNOWN);

  /* ya un truc a remplir au d�part ? */
  AS_LEAVE(as, ret);
}

/**
 * This function cleans the address space manager.
 * -remove container set contents
 * -remove container set
 * -remove as manager identifier
 */
t_error		as_clean(void)
{
  t_error	ret = ERROR_NONE;

  AS_ENTER(as);
  if ((ret = set_flush(as->container)) != ERROR_NONE)
    AS_LEAVE(as, ERROR_UNKNOWN);

  if ((ret = set_release(as->container)) != ERROR_NONE)
    AS_LEAVE(as, ret);

  if ((ret = id_destroy(&as->id)) != ERROR_NONE)
    AS_LEAVE(as, ret);

  free(as);
  AS_LEAVE(as, ret);
}
