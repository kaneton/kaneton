/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:48:24 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */


/* static void		_koin(void) */
/* { */
/*   char *coin = \ */
/* "           ,-.\n\ */
/*        ,--' ~.).\n\ */
/*      ,'         `.\n\ */
/*     ; (((__   __)))            ____________________\n\ */
/*     ;  ( (#) ( (#)            /                   /\n\ */
/*     |   \\_/___\\_/|          /  KOIN KOIN KOIN ! /\n\ */
/*    ,\"  ,-'    `__\".-------/___________________/\n\ */
/*   (   ( ._   ____`.)--._        _\n\ */
/*    `._ `-.`-' \\(`-'  _  `-. _,-' `-/`.\n\ */
/*     ,')   `.`._))  ,' `.   `.  ,','  ;\n\ */
/*   .'  .     `--'  /     ).   `.      ;\n\ */
/*  ;     `-        /     '  )         ;\n\ */
/*  \\                       ')       ,'\n\ */
/*   \\                     ,'       ;\n\ */
/*    \\               `~~~'       ,'\n\ */
/*     `.                      _,'\n\ */
/*       `.                ,--'\n\ */
/*         `-._________,--'\n\ */
/* \n\ */
/* \n\ */
/* gonnar_j\n\ */
/* nguyen_g\n\ */
/* reynau_e\n"; */

static void		_Startup(void)
{
  t_error		ok;
  // Feed the malloc with survey area
  alloc_init(init->alloc, init->allocsz, FIT_FIRST);
  // Printing is usefull, init the console and printf
  cons_init();
  printf_init((t_printf_char_fn)cons_print_char,
	      (t_printf_attr_fn)cons_set_attr);
  // Print smt about the kernel
  printf("kaneton: %#%s%#\n", CONS_RED, version, CONS_WHITE);

  // Init the id manager
  ok = id_init();
  printf("\t- ID Manager %#%s%#\n",
	 ok == ERROR_NONE ? CONS_GREEN : CONS_RED,
	 ok == ERROR_NONE ? "initiated" : "failed",
	 CONS_WHITE);

  // Init the set manager
  ok = set_init();
  printf("\t- SET Manager %#%s%#\n",
	 ok == ERROR_NONE ? CONS_GREEN : CONS_RED,
	 ok == ERROR_NONE ? "initiated" : "failed",
	 CONS_WHITE);

  // Init the segment manager
/*   ok = segment_init(FIT_FIRST); */
/*   printf("\t- SEGMENT Manager %#%s%#\n", */
/* 	 ok == ERROR_NONE ? CONS_GREEN : CONS_RED, */
/* 	 ok == ERROR_NONE ? "initiated" : "failed", */
/* 	 CONS_WHITE); */

/*   // Init the as manager */
/*   ok = as_init(); */
/*   printf("\t- AS Manager %#%s%#\n", */
/* 	 ok == ERROR_NONE ? CONS_GREEN : CONS_RED, */
/* 	 ok == ERROR_NONE ? "initiaded" : "failed", */
/* 	 CONS_WHITE); */
}

static void		_Shutdown(void)
{
  as_clean();
  segment_clean();
  set_clean();
  id_clean();
}

static void		_Tests(void)
{
  t_id			setid;

  set_show(0);
/*   set_reserve(ll, SET_OPT_ALLOC, sizeof(char*), &setid); */
/*   set_show(0); */
/*   set_reserve(ll, SET_OPT_ALLOC, sizeof(char*), &setid); */
/*   set_show(0); */
}


void			kaneton(t_init*				bootloader)
{
  /*
   * 1) Startup
   */
  // First of all, init the init struct ;-)
  init = bootloader;
  _Startup();

  /*
   * 2) Let's have fun
   */
  _Tests();
  /*   _koin(); */
/*   printf("---POUET---\n"); */
/*   segment_dump(); */
/*   printf("---!POUET---\n"); */

  while (1) ;
  /*
   * Last) Shutdown
   */
  _Shutdown();
}
