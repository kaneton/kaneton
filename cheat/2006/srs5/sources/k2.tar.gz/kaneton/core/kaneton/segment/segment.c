/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/segment/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:39:03 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the segment manager manages physical memory.
 *
 * it  is  able   to  reserve  and  release  memory   areas  (see  the
 * segment-fit.c for  allocation algorithm)  and to operated  on these
 * area: resize, split, copy, etc.
 *
 * a segment  is identified by  a 64 bits identifier  corresponding to
 * its physical  address. so  it is easy  to retrieve  this identifier
 * given the base address of a segment.
 *
 * remember  that  segments are  global:  there  is  only one  set  of
 * segments objects for  the entire kernel. the set  of segments in an
 * address space is just a set of identifiers.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have  to write the entire manager:  this file implementing
 * independent code plus  an architecture dependant file (ia32-virtual
 * or ia32-segment for example).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include "kaneton/segment-parcours.h"

machdep_include(segment);



/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the init variable, filled by the bootloader, containing in this case
 * the list of segments to mark used.
 */

extern t_init*		init;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

m_segment*		segment;


/**
 * Prototype des pointeurs sur fonctions traitant un o_segment
 */
typedef		t_error (*pt_fonction)(o_segment*);


/*
 * ---------- functions -------------------------------------------------------
 */
static t_error	_ajoute_segments_noyau(void);
static t_error	_segment_affiche(o_segment* o);




/**
 * Permet d'initialiser la gestion des segments
 */
t_error		segment_init(t_fit algo_malloc)
{
  //  t_asid	asid_noyau = 0;

    /*
   * 1)
   */

  if (NULL == (segment = malloc(sizeof(m_segment))))
    {
      cons_msg('!', "set: cannot allocate memory for the segment manager "
	       "structure\n");

      return (ERROR_UNKNOWN);
    }

  memset(segment, 0x0, sizeof(m_segment));

  /*
   * 2)
   */

  if (id_build(&(segment->id)) != ERROR_NONE)
    {
      cons_msg('!', "segment: unable to initialise the identifier object\n");

      return (ERROR_UNKNOWN);
    }

  /*
   * 3)
   */

  if (id_reserve(&segment->id, &segment->container) != ERROR_NONE)
    {
      cons_msg('!', "segment: unable to reserve an identifier\n");

      return (ERROR_UNKNOWN);
    }

  /*
   * 4)
   */

  STATS_RESERVE("segment", &segment->stats);


  /*
   * 5)
   */

  if (set_reserve(ll,
		  SET_OPT_ALLOC,
		  sizeof (o_segment),
		  &(segment->container)) != ERROR_NONE)
    {
      cons_msg('!', "segment: unable to reserve the set container\n");

      return (ERROR_UNKNOWN);
    }
  segment->start = init->mem;
  segment->size = init->memsz;
  segment->fit = algo_malloc;


  /*
   * 6)
   */

  /*Remplissage segment->container avec le noyau*/
  if (_ajoute_segments_noyau() != ERROR_NONE)
    {
      cons_msg('!', "segment: unable to add kernel segments\n");

      return (ERROR_UNKNOWN);
    }

  /*
   * 7)
   */

#if (DEBUG & DEBUG_SEGMENT)
  segment_dump();
#endif

  return (ERROR_NONE);
}

/**
 * Permet d'initialiser le gestionnaire de segments avec ceux du noyau.
 */
static t_error	_ajoute_segments_noyau(void)
{
  o_segment	*o = NULL;
  o_segment	*fin = NULL;

  SEGMENT_ENTER(segment);
   //adresse du premier segment (pour NULL)
  o = init->segments;
    //adresse suivant le dernier segment
  fin = o + init->segmentssz;
    while(o < fin)
    {
      //On donne un identifiant a chaque segment
      if (id_reserve(&(segment->id), &(o->segid)) != ERROR_NONE)
	{
	  cons_msg('!', "segment: ajout de segment: reservation d'id failed\n");
	  SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
	}
      //puis on l'ajoute avec le bon identifiant d'espace d'adressage
      if (segment_inject(o->segid, o) != ERROR_NONE)
	{
	  cons_msg('!', "segment: ajout de segment: segment injection failed\n");
	  SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
	}
      ++o;
    }
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/**
 * Permet d'effacer le gestionnaire de segments
 */
t_error		segment_clean(void)
{

  SEGMENT_ENTER(segment);
  if (set_flush(segment->container) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (id_destroy(&(segment->id)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (id_destroy(&(segment->id)) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  free(segment);
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/**
 * Permet d'obtenir des informations sur un segment.
 * C'est a dire asid, type, address, size et perms.
 * @param segid: identifiant de segment
 */
t_error		segment_show(t_segid segid)
{
  o_segment*	o = NULL;

  SEGMENT_ENTER(segment);
  if (segment_get(segid, &o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  _segment_affiche(o);	//fait le vrai boulot

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/**
 * Permet d'afficher les informations concernant un segment.
 * Precondition: o est non NULL.
 * @param o: le segment dont on affiche les informations
 */
static t_error	_segment_affiche(o_segment* o)
{
  printf("--\nsegment numero %i:\n", o->segid);
  printf("appartient a l'espace d'adressage %i:\n", o->asid);

  if (o->type == SEGMENT_TYPE_MEMORY)
    printf("type: SEGMENT_TYPE_MEMORY\n");
  else
    printf("type: SEGMENT_TYPE_CATCH\n");

  printf("adresse: %i\n", o->address);
  printf("taille (en octet): %i\n", o->size);
  printf("permissions:\n");

  if (o->perms & PERM_READ)
    printf("\t\t\tlecture\n");
  if (o->perms & PERM_WRITE)
    printf("\t\t\tecriture\n");
  if (o->perms & PERM_EXEC)
    printf("\t\t\texecution\n");

  printf("--\n");
  return (ERROR_NONE);
}

/**
 * Permet d'afficher l'ensemble des segments geres.
 */
t_error		segment_dump(void)
{
  t_iterator	*it = NULL;

  // Prevents strange warning
  it = it;
  SEGMENT_ENTER(segment);
  if (set_head(segment->container, it) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  printf("-----\n");
  printf("Ensemble des segments:\n");

  //le travail a proprement parle

  if (segment_iterateur_fonction_1(_segment_affiche) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  printf("-----\n");
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/**
 * Permet de faire une copie d'un segment.
 * @param as:
 * @param original: l'identifiant du segment a copie
 * @param pt_copie: l'adresse de l'identifiant de la copie
 */
t_error		segment_clone(t_asid as, t_segid original,
			      t_segid* pt_copie)
{
  o_segment	*o = NULL;
  o_segment	*or = NULL;

  SEGMENT_ENTER(segment);
  if (NULL == (o = malloc(sizeof (o_segment))))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (segment_get(original, &or) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  id_reserve(&(segment->id), &(o->segid));

  o->asid = as;
  o->type = or->type;
  o->address = or->address;
  o->size = or->size;
  o->perms = or->perms;

  pt_copie = &(o->segid);
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/**
 * Permet de mettre un segment pre_alloue dans le conteneur.
 * @param as: numeoro d'identifiant du gestionnaire d'espace
 *		d'adressage correspondant au segment pointe
 * @param o: pointeur sur le segment a ajouter
 */
t_error		segment_inject(t_asid as, o_segment *o)
{

  SEGMENT_ENTER(segment);
  o->asid = as;
  if (set_add(segment->container, (void*) o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/**
 * Permet de changer un segment d'epace d'adressage.
 * @param sid: identificateur du segment
 * @param as: identificateur de l'espace d'adressage.
 */
t_error		segment_give(t_segid segid, t_asid asid)
{
  o_segment	*o = NULL;

  SEGMENT_ENTER(segment);
  if (segment_get(segid, &o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  o->asid = asid;
  SEGMENT_LEAVE(segment, ERROR_NONE);
}


/* This function resizes a segment. */
/**
 * Permet de redimensionner un segment
 */
t_error		segment_resize(t_segid segid, t_psize size, t_segid *new)
{
  /* pb de taille si tailled est plus petite pb de donn�e */
  o_segment*	ocur = NULL;
  o_segment*	onew = NULL;
  t_iterator*	it = NULL;
  t_iterator*	next = NULL;
  void**	data = NULL;
  o_segment*	onext = NULL;

  SEGMENT_ENTER(segment);
  if (segment_get(segid, &ocur) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (size <= ocur->size)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  /* pb si adresse deja utilis� */
  /* recupere le segment suivant et test si on tape dans la memoire */
  if (set_locate(segment->container, segid, it) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (set_next(segment->container, *it, next) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (set_object(segment->container, *next, data) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  onext = (o_segment *) data;
  if (onext->address < onew->address + size)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (NULL == (onew = malloc(sizeof (o_segment))))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (id_reserve(&segment->id, new) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  onew->segid = *new;
  onew->asid = ocur->asid;
  onew->type = ocur->type;
  onew->address = ocur->address;
  onew->size = size;
  onew->perms = ocur->perms;
  if (set_insert_before(segment->container, *it, (void *) onew) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  /* lib�ration de segid */
  if (segment_release(segid) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/* This function split a segment into two segments. */
/**
 * Permet de couper un segment en 2
 */
t_error		segment_split(t_segid segid,
			      t_psize size,
			      t_segid* left,
			      t_segid* right)
{
  o_segment*	ocur = NULL;
  o_segment*	oleft = NULL;
  o_segment*	oright = NULL;
  t_iterator*	it = NULL;

  SEGMENT_ENTER(segment);
  if (segment_get(segid, &ocur) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  if (ocur->size < 2)
    if (set_object(segment->container, *it, (void **) &ocur) != ERROR_NONE)
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  /* creation de left */
  if (NULL == (oleft = malloc(sizeof (o_segment))))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  if (id_reserve(&segment->id, left) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  oleft->segid = *left;
  oleft->asid = ocur->asid;
  oleft->type = ocur->type;
  oleft->address = ocur->address;
  oleft->size = ocur->size - size;
  oleft->perms = ocur->perms;

  /* creation de right */
  if (NULL == (oright = malloc(sizeof (o_segment))))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (id_reserve(&segment->id, left) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  oright->segid = *right;
  oright->asid = ocur->asid;
  oright->type = ocur->type;
  oright->address = ocur->address + ocur->size - size;
  oright->size = ocur->size + size;
  oright->perms = ocur->perms;

  if (set_locate(segment->container, segid, it) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  //  set_object(segment->container, it, (void **) &o);
  if (set_insert_before(segment->container, *it, (void *) oleft) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (set_insert_after(segment->container, *it, (void *) oright) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  /* lib�ration de segid */
  if (segment_release(segid) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/* This function merges two segments into a single one. */
/**
 * Permet de fusionner 2 segments en 1 seul segment si ils sont adjacents
 */
t_error		segment_coalesce(t_segid left, t_segid right,
				 t_segid* segid)
{
  o_segment*	_left = NULL;
  o_segment*	_right = NULL;
  //o_segment*	_new = NULL;

  SEGMENT_ENTER(segment);
  segment_get(left, &_left);
  segment_get(right, &_right);

  /* test si la fusion est possible */
  if (_left->asid != _right->asid ||
      _left->type != _right->type ||
      _left->perms != _right->perms)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (_left->address + _left->size != _right->address)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  /* importance de l'ordre ? */
  _left->size += _right->size;
  segid = &left;
  /* lib�re le segment de droite */
  if (segment_release(right) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/* This function reserves a segment of specified size. */
/**
 * Permet de r�server un segment d'une taille donn�e
 */
t_error		segment_reserve(t_asid asid, t_psize size,
				t_perms perms, t_segid* segid)
{
  o_segment	*o = NULL;
  o_as*		as;

  SEGMENT_ENTER(segment);
  if (NULL == (o = malloc(sizeof (o_segment))))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (id_reserve(&segment->id, segid) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  o->segid = *segid;
  o->asid = asid;
  //  o->type =
  if (as_get(asid, &as) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  if (segment_fit(as, size , &o->address) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  o->perms = perms;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/* This function releases a segment. */
/**
 * Permet de lib�rer un segment
 */
t_error		segment_release(t_segid segid)
{

  SEGMENT_ENTER(segment);
  if (set_remove(segment->container, segid) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/* This function is used to force a segment to be given to an address space. catcheable
 * segments are reserved by the module service for architecture specific servers.
 * Catcheable segments are defined in the kaneton.conf file.
 */
/**
 * Permet de forcer le don d'un segment a un autre espace d'adressage
 */
t_error		segment_catch(t_asid asid, t_segid segid)
{

  //o_segment** o;
  SEGMENT_ENTER(segment);

  /* modifie le type de segment en SEGMENT_TYPE_CATCH */
  if (segment_type(segid, SEGMENT_TYPE_CATCH) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  /* donne le segment a un autre espace d'adressage */
  if (segment_give(segid, asid) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  SEGMENT_LEAVE(segment, ERROR_NONE);
}


/*
 * This function changes permissions for a segment.
 */
t_error		segment_perms(t_segid segid, t_perms perms)
{
  o_segment*	o = NULL;

  SEGMENT_ENTER(segment);
  if (set_get(segment->container, segid, (void**)&o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  o->perms =perms;
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/* This function changes the type of a segment. */
/**
 * Permet de changer le type d'un segment donn�.
 */
t_error		segment_type(t_segid segid, t_type type)
{
  o_segment*	o = NULL;

  if (NULL == (o = malloc(sizeof (o_segment))))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_ENTER(segment);
  if (set_get(segid, segment->container, (void**)&o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  o->type = type;
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/* This function removes every segment that belongs to the address space specified. */
/**
 * Permet de supprimer tous les segments qui appartiennent a un espace
 * d'adressage sp�cifi�
 */
t_error		segment_flush(t_asid asid)
{
  t_iterator	first, cur;

  SEGMENT_ENTER(segment);
  if (set_head(segment->container, &first) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  /* test error */
  /* flush a faire */
  //  segment_iterator(first, &cur, segment_flushing);
  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/* This function gets the segment object associated to a segment identifier. */
/**
 * Permet de r�cup�rer l'objet segment associ� a un identifiant de segment
 */
t_error		segment_get(t_segid segid, o_segment** o)
{
  SEGMENT_ENTER(segment);
  /* a tester me retour de set_get */
  if (set_get(segment->container, segid, (void**)o) != ERROR_NONE)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
  SEGMENT_LEAVE(segment, ERROR_NONE);
}
