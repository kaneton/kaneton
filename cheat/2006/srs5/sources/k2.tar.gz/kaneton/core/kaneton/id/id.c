/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/id/id.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 01:10:52 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the kaneton kernel uses 64-bit identifier.
 *
 * from this fact, we do not care about identifier recycling.
 *
 * the best example of this fact is located in the id_release()
 * function. indeed the function does nothing, meaning that the
 * identifier released will not be recycled.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the id manager is simply to generate identifier.
 *
 * this is the simpler manager of the kaneton kernel.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the id manager structure.
 */

m_id*			id = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */


/*
 * this function reserves an identifier in an identifier object
 */

t_error			id_reserve(o_id*			o,
				   t_id*			i)
{
  ID_ENTER(id);

  o->id++;
  *i = o->id;

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function releases an identifier from an identifier object.
 */

t_error			id_release(o_id*			o,
				   t_id				i)
{
  ID_ENTER(id);

  // The id manager does not take care of id recycling
  // Do nothing here

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function initialises an id object.
 */

t_error			id_build(o_id*				o)
{
  ID_ENTER(id);

  if (o == NULL)
    ID_LEAVE(id, ERROR_UNKNOWN);
  o->id = ID_UNUSED;

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function cleans an id object.
 */

t_error			id_destroy(o_id*			o)
{
  ID_ENTER(id);

  if (o == NULL)
    ID_LEAVE(id, ERROR_UNKNOWN);
  o->id = ID_UNUSED;

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function just displays an id object's state
 */
t_error			id_show(o_id*				o)
{
  ID_ENTER(id);

  if (o == NULL)
    ID_LEAVE(id, ERROR_UNKNOWN);
  printf("Object: %x, id: %i\n", o, o ? o->id : ID_UNUSED);

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function duplicates an id object using the o identifier object
 */
t_error			id_clone(o_id*				o,
				 t_id				old,
				 t_id*				new)
{
  ID_ENTER(id);

  if (o == NULL)
    ID_LEAVE(id, ERROR_UNKNOWN);
  o->id = old;
  *new = o->id;

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function just initializes the id manager
 */
t_error			id_init(void)
{
  if (!id)
    id = malloc(sizeof(m_id));

  if (id == NULL)
    return (ERROR_UNKNOWN);
  STATS_RESERVE("id", &id->stats);

  return (ERROR_NONE);
}

/*
 * this function just cleans the id manager
 */
t_error			id_clean(void)
{
  STATS_RELEASE(id->stats);

  free(id);

  return (ERROR_NONE);
}
