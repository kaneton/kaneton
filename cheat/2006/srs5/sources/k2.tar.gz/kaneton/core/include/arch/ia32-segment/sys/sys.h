/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/mycure/kaneton/core/include/arch/ia32-virtual/sys/sys.h
 *
 * created       julien quintard   [sat dec 17 17:17:16 2005]
 * updated       julien quintard   [sat dec 17 17:17:18 2005]
 */

#ifndef IA32_SYS_SYS_H
#define IA32_SYS_SYS_H		1

/*
 * ---------- includes --------------------------------------------------------
 */

#include <arch/machdep/sys/elf.h>

#endif
