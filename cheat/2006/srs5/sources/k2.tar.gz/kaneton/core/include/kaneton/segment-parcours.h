/**
 * Permet de parcourir l'ensemble des segments
 * d'un gestionnaire de segments de manieres iterative
 * projet: Kaneton (K2)
 * auteur: Emmanuel Reynaud; reynau_e
 * version: 1,0
 * date: 27/3/2006
 */

#ifndef KANETON_SEGMENT_PARCOURS_H
# define KANETON_SEGMENT_PARCOURS_H

# include "segment.h"


/**
 * Prototype des pointeurs sur fonctions traitant un o_segment
 */
typedef		t_error (*pt_fonction_1_os)(o_segment*);

/**
 * Prototype des pointeurs sur fonctions traitant deux o_segment
 */
typedef		t_error (*pt_fonction_2_os)(o_segment*, o_segment*);


/**
 * Permet d'effectuer un traitement sur chaque o_segment du gestionnaire
 * de segments
 * @param pf1: traite un o_segment
 */
t_error		segment_iterateur_fonction_1(pt_fonction_1_os pf1);

/**
 * Permet d'effectuer un traitement sur deux o_segment successifs du gestionnaire
 * de segments
 * @param pf2: traite deux o_segment consecutifs
 */
t_error		segment_iterateur_fonction_2(pt_fonction_2_os pf2);

#endif /* !KANETON_SEGMENT_PARCOURS_H*/
