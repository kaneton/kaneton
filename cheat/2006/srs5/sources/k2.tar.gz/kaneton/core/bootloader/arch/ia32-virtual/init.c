/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/kaneton/core/bootloader/arch/ia32-virtual/init.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       matthieu bucchianeri   [tue jan 17 22:24:35 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this file contains the functions intended to do the relocation.
 *
 * this file is very important because it does the most important things
 * of the bootloader: computes segments and regions, relocates data, creates
 * the init structure etc..
 *
 * the relocation is based on dynamic allocation. nevertheless, no dynamic
 * allocation is provided. the student so has to setup a very simple dynamic
 * memory allocation algorithm to be able to build the init structure.
 *
 * think about it because some components cannot have a dynamic address. there
 * are some crazy problems to resolve in this context.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

#include "stdio.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * init variable, describing the initial memory layout.
 *
 * this structure will be passed to the kernel describing modules,
 * physical memory reserved by the hardware etc.. thus the kernel will
 * be able to initialise its managers: segment manager, module manager etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * ---------- statics ---------------------------------------------------------
 */


static void		_k_init(multiboot_info_t* mbi)
{
  int			k_size;
  module_t		*kernel;

  kernel = (module_t*)mbi->mods_addr;
  k_size = kernel->mod_end - kernel->mod_start;
  memcpy((char*)INIT_RELOCATE, (char*)kernel->mod_start, k_size);
}

static void		_t_init_init(multiboot_info_t* mbi)
{
  module_t		*kernel;
  int			k_size;

  // init addr computing
  kernel = (module_t*)mbi->mods_addr;
  k_size = kernel->mod_end - kernel->mod_start;
  init = (t_init*)(INIT_RELOCATE + ALIGN(k_size));

  // filling init structure
  //init->mem = NULL;			// FIXME: que faut-il vraiment
  init->memsz = mbi->mem_upper;		//	  mettre ici?

  init->kcode = (t_paddr)INIT_RELOCATE;
  init->kcodesz = k_size;

  init->init = (t_paddr)init;
  init->initsz = sizeof(t_init);

  cons_init_init();			// fill the init->cons field
}

static void		_t_modules_init(multiboot_info_t* mbi)
{
  init->modules = (t_modules*)(ALIGN(init->init + init->initsz));
  init->modulessz = sizeof(t_modules);
  init->modules->nmodules = mbi->mods_count;
}

static void		_t_module_init(multiboot_info_t* mbi)
{
  module_t		*mod;
  t_module		*current;
  char			*module;
  int			i;

  mod = (module_t *)(mbi->mods_addr);
  for (i = 0, current = (t_module*)(init->modules + sizeof(t_modules));
       i < init->modules->nmodules;
       ++i, current = current + 1, ++mod)
    {
      current->size = (t_psize)(mod->mod_end - mod->mod_start);
      init->modulessz += sizeof(t_module);
    }
  mod = (module_t *)(mbi->mods_addr);
  for (i = 0, current = (t_module*)(init->modules + sizeof(t_modules));
       i < init->modules->nmodules;
       ++i, current = current + 1, ++mod)
    {
      module = (char*)(init->modules + init->modulessz);
      memcpy(module, (char*)mod->mod_start, current->size);
      memcpy(module + current->size, (char*)mod->string, strlen((char*)(mod->string)) + 1);
      current->name = module + current->size;
      init->modulessz += current->size + strlen(current->name) + 1;
    }
}


static void		_t_segments_init(void)
{
  init->nsegments = INIT_SEGMENTS;
  init->segments = (o_segment*)(ALIGN(init->modules + init->modulessz));
  init->segmentssz = INIT_SEGMENTS * sizeof(o_segment);
}

static void		_segments_init(void)
{
  // FIXME: determiner les perms
  o_segment*		seg;

  // null segment
  seg = init->segments;
  seg->address = (t_paddr)NULL;
  seg->size = PAGESZ;
  seg->perms = !PERM_READ | !PERM_WRITE | !PERM_EXEC;

  // ISA segment
  ++seg;
  seg->address = (t_paddr)NULL + PAGESZ;
  seg->size = 256 * PAGESZ;
  seg->perms = PERM_READ | PERM_WRITE;

  // Kcode segment
  ++seg;
  seg->address = INIT_RELOCATE;
  seg->size = init->kcodesz;
  seg->perms = PERM_READ | PERM_WRITE | PERM_EXEC;

  // Init segment
  ++seg;
  seg->address = init->init;
  seg->size = init->initsz;
  seg->perms = PERM_READ | PERM_WRITE;

  // Modules segment
  ++seg;
  seg->address = (t_paddr)init->modules;
  seg->size = init->initsz;
  seg->perms = PERM_READ | PERM_WRITE;

  // Segments segment
  ++seg;
  seg->address = (t_paddr)init->segments;
  seg->size = init->segmentssz;
  seg->perms = PERM_READ | PERM_WRITE;

  // Regions segment
  ++seg;
  seg->address = (t_paddr)init->regions;
  seg->size = init->initsz;
  seg->perms = PERM_READ | PERM_WRITE;

  // Kstack segment
  ++seg;
  seg->address = init->kstack;
  seg->size = init->kstacksz;
  seg->perms = PERM_READ | PERM_WRITE;

  // Alloc segment
  ++seg;
  seg->address = init->alloc;
  seg->size = init->allocsz;
  seg->perms = PERM_READ | PERM_WRITE;

  // GDT segment
  ++seg;
  seg->address = init->alloc + init->allocsz;
  seg->size = PAGESZ;
  seg->perms = PERM_READ | PERM_WRITE;

  // PD segment
  ++seg;
  seg->address = init->alloc + init->allocsz + PAGESZ;
  seg->size = 3 * PAGESZ;
  seg->perms = PERM_READ | PERM_WRITE;
}

static void		_t_regions_init(void)
{
  // there are INIT_REGIONS regions
  init->nregions = INIT_REGIONS;
  init->regions = (o_region*)(ALIGN(init->segments + init->segmentssz));
  init->regionssz = INIT_REGIONS * sizeof(o_region);
}

static void		_regions_init(void)
{
  // FIXME: offset ?
  o_region*		reg;

  // ISA region
  reg = init->regions;
  reg->address = PAGESZ;
  reg->offset = 0;
  reg->size = 256 * PAGESZ;

  // Kcode region
  ++reg;
  reg->address = INIT_RELOCATE;
  reg->offset = 0;
  reg->size = init->kcodesz;

  // Init region
  ++reg;
  reg->address = init->init;
  reg->offset = 0;
  reg->size = init->initsz;

  // Kstack region
  ++reg;
  reg->address = init->kstack;
  reg->offset = 0;
  reg->size = init->kstacksz;

  // Alloc region
  ++reg;
  reg->address = init->alloc;
  reg->offset = 0;
  reg->size = init->allocsz;

  // GDT region
  ++reg;
  reg->address = init->alloc + init->allocsz;
  reg->offset = 0;
  reg->size = PAGESZ;

  // PD region
  ++reg;
  reg->address = init->alloc + init->allocsz + PAGESZ;
  reg->offset = 0;
  reg->size = 3 * PAGESZ;
}

static void		_kstack_init(void)
{
  // taille => INIT_KSTACKSZ
  init->kstack = (t_paddr)(ALIGN(init->regions + init->regionssz));
  init->kstacksz = INIT_KSTACKSZ;
}

static void		_alloc_init(void)
{
  // alloc is a 16 pages size memory space
  init->alloc = (t_paddr)(ALIGN(init->kstack + init->kstacksz));
  init->allocsz = 16 * PAGESZ;
}


/*
 * ---------- publics ---------------------------------------------------------
 */


/*
 * 16 MB => 0x1000000
 * penser a aligner sur 4k (une page)
 */
void			init_init(multiboot_info_t* mbi)
{
  // placer K a 0xFFFFFF
  _k_init(mbi);

  // placer t_init a 0xFFFFFF + sizeof kernel
  _t_init_init(mbi);

  // placer t_modules a (init + sizeof init)
  _t_modules_init(mbi);

  // placer les n t_module a (t_modules + sizeof t_modules)
  _t_module_init(mbi);

  //
  _t_segments_init();

  //
  _t_regions_init();

  //
  _kstack_init();

  //
  _alloc_init();

  //
  _segments_init();

  //
  _regions_init();

}

void			init_dump(void)
{
  my_printf("Memory: Addr: %A%p%A, Size: %A%i%A bytes\n",
	    CONS_BLUE, init->mem, CONS_WHITE,
	    CONS_BLUE, init->memsz, CONS_WHITE);
  my_printf("Kernel Code: Addr: %A%p%A, Size: %A%i%A bytes\n",
	    CONS_BLUE, init->kcode, CONS_WHITE,
	    CONS_BLUE, init->kcodesz, CONS_WHITE);
  my_printf("Init structure: Addr: %A%p%A, Size: %A%i%A bytes\n",
	    CONS_BLUE, init->init, CONS_WHITE,
	    CONS_BLUE, init->initsz, CONS_WHITE);
  my_printf("Modules: Addr: %A%p%A, Size: %A%i%A bytes\n",
	    CONS_BLUE, init->modules, CONS_WHITE,
	    CONS_BLUE, init->modulessz, CONS_WHITE);
  my_printf("Segments: Nb: %A%i%A, Addr: %A%p%A, Size: %A%i%A bytes\n",
	    CONS_BLUE, init->nsegments, CONS_WHITE,
	    CONS_BLUE, init->segments, CONS_WHITE,
	    CONS_BLUE, init->segmentssz, CONS_WHITE);
  my_printf("Regions: Nb: %A%i%A, Addr: %A%p%A, Size: %A%i%A bytes\n",
	    CONS_BLUE, init->nregions, CONS_WHITE,
	    CONS_BLUE, init->regions, CONS_WHITE,
	    CONS_BLUE, init->regionssz, CONS_WHITE);
  my_printf("Kernel Stack: Addr: %A%p%A, Size: %A%i%A bytes\n",
	    CONS_BLUE, init->kstack, CONS_WHITE,
	    CONS_BLUE, init->kstacksz, CONS_WHITE);
  my_printf("Alloc: Addr: %A%p%A, Size: %A%i%A bytes\n",
	    CONS_BLUE, init->alloc, CONS_WHITE,
	    CONS_BLUE, init->allocsz, CONS_WHITE);
}

