/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/bootloader.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:23:13 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the bootloader is to install a correct environment for
 * the kernel.
 *
 * the first thing to do is to relocate the different kaneton data structure
 * in order to build the t_init structure. this structure must contain
 * everything the kernel will need.
 *
 * for more information on the relocating, take a look to the kaneton
 * paper which describes the entire kaneton reference.
 *
 * once the init structure was built, the kernel has to be launched.
 *
 * nevertheless, the kernel needs to evolve with the protected mode and
 * paging mode activated, so the bootloader first has to install these.
 *
 * printing some messages is interesting showing the protected mode and
 * paging mode are correctly installed.
 *
 * after all, the bootloader has launch the kernel binary.
 *
 * look at the ld scripts to know where the kernel has to be loaded.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"
#include "stdio.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * these three variable are globals to avoid them to be lost when the
 * bootloader changes its stack.
 *
 * indeed, before jumping on the kernel a new stack is created so the local
 * variables will no longer be accessible. putting these variables in
 * globals bypass this problem.
 */

void			(*kernel)(t_init*);

t_reg32			ebp;
t_reg32			esp;

/*
 * ---------- functions -------------------------------------------------------
 */
static void		_kernel_env(void);
static void		_bootloader_env(void);

int			bootloader(t_uint32		magic,
				   multiboot_info_t*	mbi)
{
  // Cons init
  cons_init();
  my_printf("%AConsole initialisee !%A\n", CONS_RED, CONS_WHITE);

  // init()
  init_init(mbi);
  my_printf("%AInit done !%A\n", CONS_RED, CONS_WHITE);
  init_dump();

  // PMode
  pmode_init();
  my_printf("%APMode initialise%A\n", CONS_RED, CONS_WHITE);


  // Paging
  paging_init();
  my_printf("%Amode virtuel !!!! Youpi%A\n", CONS_RED, CONS_WHITE);
  init_dump();

  // loop for instance
  kernel = (void*)(*(t_paddr*)(init->kcode + 0x18));
  my_printf("\nPret a charger le kernel\n");

  // sauvegarde esp et ebp et installation de la nouvelle stack
  _kernel_env();
  // Jump to kernel
  (*kernel)(init);
  // restauration esp et ebp
  _bootloader_env();
  // Should not be here, print an error message
  cons_panic("The kernel failed, please debug it !");
  while (1);
  return (0);
}

static void		_kernel_env(void)
{
  asm volatile("mov %%ebp, %0		\n\t"
	       "mov %%esp, %1		\n\t"
	       "mov %2, %%eax		\n\t"
	       "mov %%eax, %%esp	\n\t"
	       : "=r" (ebp), "=r" (esp)
	       : "r" (init->kstack)
	       : "%eax");
}

static void		_bootloader_env(void)
{
  asm volatile("mov %0, %%eax		\n\t"
	       "mov %%eax, %%ebp	\n\t"
	       "mov %1, %%eax		\n\t"
	       "mov %%eax, %%esp	\n\t"
	       :
	       : "m" (ebp), "m" (esp)
	       : "%eax");
}
