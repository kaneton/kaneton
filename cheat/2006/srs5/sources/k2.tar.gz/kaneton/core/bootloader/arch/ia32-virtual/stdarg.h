#ifndef		__STDARG_H__
# define	__STDARG_H__

# ifdef BLAH

typedef char	*valist;

#  define	_varounded_size(type)					\
	(((sizeof (type) + sizeof (int) - 1) / sizeof (int)) * sizeof (int))

#  define	vastart(ap, pn)					\
	(ap = ((char *) & pn + _varounded_size(pn)))

#  define	vaarg(ap, type)					\
	(ap += _varounded_size(type),					\
	* ((type *) (ap - _varounded_size(type))))

extern void	vaend(valist);

#  define	vaend(ap)	/* nothing */

# else

typedef char	*valist[1];

#  define	vastart(ap, pn)					\
	((ap)[0] = (char *) & pn + ((sizeof (pn) + sizeof (int) - 1)	\
	& ~ (sizeof (int) - 1)), (void) 0)
#  define	vaarg(ap, type)					\
	((ap)[0] += ((sizeof (type) + sizeof (int) - 1)			\
	& ~(sizeof (int) - 1)), (*(type *)((ap)[0] - ((sizeof (type) +	\
	sizeof (int) - 1) & ~(sizeof (int) - 1)))))
#  define	vaend(ap)	((ap)[0] = 0, (void) 0)

# endif

#endif		/* !__STDARG_H__ */
