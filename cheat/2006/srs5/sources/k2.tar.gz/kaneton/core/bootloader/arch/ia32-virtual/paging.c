/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/paging.c
 *
 * created       julien quintard   [sun may 29 00:38:50 2005]
 * updated       matthieu bucchianeri   [tue jan 24 18:12:26 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * these function just install the paging mode to enable virtual memory
 * which is required by the kaneton kernel.
 *
 * think about mapping everything needed: kernel code, kernel stack, init
 * structure etc..
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"
#include "stdio.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*			init;

void				paging_init(void)
{
  lib_paging_init();
}

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Prints a virtual address and its physical translation
 *
 * @param addr: the virtual address to translate
 */
void		paging_translate_va(t_paddr addr)
{
  t_paddr	pdi, pti, offset;
  t_paddr	pde, pte;
  t_paddr*	pd = NULL;
  t_paddr*	pt = NULL;
  t_paddr	pa;

  pdi = addr >> 22;
  pti = (addr << 10) >> 22;
  offset = (addr << 20) >> 20;

  pd = (t_paddr*)((init->alloc + init->allocsz) + 1 * PAGESZ);
  pde = *(pd + pdi);
  pt = (t_paddr*)((pde >> 12) << 12);
  pte = *(pt + pti);
  pa = ((pte >> 12) << 12) + offset;
  my_printf("va: %p => pa: %p\n", addr, pa);
}
