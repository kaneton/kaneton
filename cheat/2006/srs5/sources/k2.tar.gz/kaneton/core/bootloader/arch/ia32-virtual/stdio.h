#ifndef _STDIO_H_
# define _STDIO_H_

# include "stdarg.h"


/*
** D�finitions
*/

/*
** Structures et Types
*/

struct		printf_s
{
  char		*pattern;
  void		(*func)(valist	*args);
};

typedef struct printf_s	printf_t;

/*
** Tableaux statiques
*/

/*
** Prototypes
*/

// Interfaces publiques
int		my_printf(const char *format, ...);
int		my_putchar(int c);
int		my_puts(const char *s);
int		my_putnbr(int n);
int		my_putunnbr(unsigned int n);
int		my_putunnbr_base(unsigned int n, const char *base);

#endif /* !_STDIO_H_ */
