/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/pmode/gdt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:45:19 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:57:21 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage global descriptor table.
 *
 */


/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have  to place here code to manage  gdt. there are no
 * restrictions on prototypes, names etc.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */

/*
** Variables Globales
*/
gdt_t		*_gdt;
gdtr_t		_gdtr;

/*
** Variables Statiques
*/
static t_uint16	_kcode_segment;
static t_uint16	_kdata_segment;
static t_uint16	_ucode_segment;
static t_uint16	_udata_segment;

/*
** Fonctions Statiques
*/
static t_uint8	_gdt_new_segment(t_uint32	base,
				 t_uint32	limit,
				 t_uint32	type,
				 t_uint32	dpl);
static int	_is_gdt_free(gdt_t *gdt);
static void	_gdt_update_cpu_segments(t_uint8 cs, t_uint8 ds);
static void	_init_gdtr(void);
static void	_load_gdtr(void);

/*
** Initialise et charge la GDT (Global Descriptor Table)
**
** cf. manuel intel Val.3 p.68 pour les TI flages
*/
void			gdt_init(t_paddr gdtaddr)
{
  _gdt = (gdt_t*)(ALIGN(gdtaddr));

  // R�initialise la GDT
  memset(_gdt, '\0', sizeof (_gdt));

  // Cr�e les segments
  // premi�re entr�e: NULL entry
  // 2-nde entr�e: Code Kernel
  _kcode_segment = _gdt_new_segment(0x0,
					  0xFFFFF,
					  GDT_DPL0,
					  GDT_XO);
  // 3-�me entr�e: Donn�es Kernel
  _kdata_segment = _gdt_new_segment(0x0,
					  0xFFFFF,
					  GDT_DPL0,
					  GDT_RW);
  // 4-�me entr�e: Code User
  _ucode_segment = _gdt_new_segment(0x0,
					0xFFFFF,
					GDT_DPL3,
					GDT_XO);
  // 5-�me entr�e: Donn�es User
  _udata_segment = _gdt_new_segment(0x0,
					0xFFFFF,
					GDT_DPL3,
					GDT_RW);

  // Initialise et Charge la GDTR
  _init_gdtr();
  _load_gdtr();

  // Update CPU registers
  _gdt_update_cpu_segments(_kcode_segment, _kdata_segment);
}

/*
** Cette fonction ajoute une entr�e dans la GDT au premier emplacement libre.
**
** @param base	L'adresse de d�but
** @param limit	La taille de la zone m�moire
** @param type	Le type de descripteur
** @param dpl	Le Descriptor Privilege Level
*/
static t_uint8	_gdt_new_segment(t_uint32	base,
				 t_uint32	limit,
				 t_uint32	type,
				 t_uint32	dpl)
{
  static t_uint8	_first_free = 1;
  t_uint16		i;

  // Recherche de la premi�re entr�e libre
  for (i = _first_free; i < GDT_SIZE; ++i)
    if (_is_gdt_free(& _gdt[i]) == TRUE)
      break ;

  // Dans le cas o� toutes les entr�es sont prises ...
  if (i == GDT_SIZE)
    // TODO: errno
    return -1;

  // On remplit la structure
  // base
  _gdt[i]._base15_0 = (base & 0x0000ffff);
  _gdt[i]._base23_16 = (base & 0x00ff0000) >> 16;
  _gdt[i]._base31_24 = (base & 0xff000000) >> 24;
  // limit
  _gdt[i]._limit = (limit & 0x0000ffff);
  _gdt[i]._flags |= (limit & 0x00ff0000) >> 16;
  // type
  _gdt[i]._type |= (type & 0x0f);
  // dpl
  _gdt[i]._type |= dpl;
  // Traitement des valeurs par defaut
  // bit 43: S = 1
  _gdt[i]._type |= GDT_SYSTEM;
  // bit 46: 1
  _gdt[i]._type |= GDT_TYPE_1;
  // bit 52: AVL
  // bit 53: 0
  // bit 54: B
  _gdt[i]._flags |= GDT_USE32;
  // bit 55: G
  _gdt[i]._flags |= GDT_GRANULAR;

  // On tiens � jour _first_free
  _first_free = i + 1;

  return i;
}

/*
** Cette fonction v�rifie si l'entree est vide ou non.
*/
static int	_is_gdt_free(gdt_t *gdt)
{
  if (gdt->_limit != 0)
    return FALSE;
  if (gdt->_base15_0 != 0)
    return FALSE;
  if (gdt->_base23_16 != 0)
    return FALSE;
  if (gdt->_type != 0)
    return FALSE;
  if (gdt->_flags != 0)
    return FALSE;
   if (gdt->_base31_24 != 0)
    return FALSE;
  return TRUE;
}

/*
** Cette fonction met � jour les registres de segment du CPU.
*/
static void	_gdt_update_cpu_segments(t_uint8 cs, t_uint8 ds)
{
  asm volatile(" pushl %0		\n\t"
	       " pushl $cs_jump		\n\t"
	       " lret			\n\t"
	       "cs_jump:		\n\t"
	       " mov %1, %%eax		\n\t"
	       " mov %%ax, %%ds		\n\t"
	       " mov %%ax, %%es		\n\t"
	       " mov %%ax, %%fs		\n\t"
	       " mov %%ax, %%gs		\n\t"
	       " mov %%ax, %%ss"
	       :
	       : "g" (cs << 3), "g" (ds << 3)
	       : "%ax", "%eax");
}

/*
** Cette fonction initialise la GDTR.
*/
static void	_init_gdtr(void)
{
  _gdtr._addr = (t_uint32) _gdt;
  _gdtr._size = GDT_SIZE * sizeof (gdt_t);
}

/*
** Cette fonction charge la GDTR.
*/
static void	_load_gdtr(void)
{
  asm volatile("lgdt %0			\n\t"
	       "mov %%cr0, %%eax	\n\t"
	       "or %1, %%eax		\n\t"
	       "mov %%eax, %%cr0"
	       :
	       : "m" (_gdtr), "g" (1)
	       : "%eax");
}
