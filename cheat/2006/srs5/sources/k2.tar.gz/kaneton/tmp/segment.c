/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file         /home/buckman/kaneton/core/kaneton/segment/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:39:03 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the segment manager manages physical memory.
 *
 * it  is  able   to  reserve  and  release  memory   areas  (see  the
 * segment-fit.c for  allocation algorithm)  and to operated  on these
 * area: resize, split, copy, etc.
 *
 * a segment  is identified by  a 64 bits identifier  corresponding to
 * its physical  address. so  it is easy  to retrieve  this identifier
 * given the base address of a segment.
 *
 * remember  that  segments are  global:  there  is  only one  set  of
 * segments objects for  the entire kernel. the set  of segments in an
 * address space is just a set of identifiers.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have  to write the entire manager:  this file implementing
 * independent code plus  an archi1tecture dependant file (ia32-virtual
 * or ia32-segment for example).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the init variable, filled by the bootloader, containing in this case
 * the list of segments to mark used.
 */

extern t_init*		init;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

m_segment*		segment;


/**
 * Prototype des pointeurs sur fonctions traitant un o_segment
 */
typedef		t_error (*pt_fonction)(o_segment*);


/*
 * ---------- functions -------------------------------------------------------
 */

/**
 * Permet d'initialiser la gestion des segments
 */
t_error		segment_init(void)
{


  if (NULL == (segment = malloc(sizeof(m_segment))))
      return ERROR_UNKNOWN;

  id_build(&segment->id);
/*id_build(&m_A->id);
...
id_reserve(&m_A->id, &Aid1);
id_reserve(&m_A->id, &Aid2);
id_reserve(&m_A->id, &Aid3);*/

/* On verra plus tard
  segment->stats = ;//t_staid*/

  segment->start = init->mem;
  segment->size = init->memsz;
  segment->fit = FIT_FIRST;

  id_build(&(segment->container));
  set_reserve(*SET_TYPE_LL/*ou ll*/,
	      sizeof (o_segment), &segment->container);

  /*Remplissage segment->container*/

  return ERROR_NONE;
}

/**
 * Permet d'effacer le gestionnaire de segments
 */
t_error		segment_clean(void)
{
  set_flush(segment->container);
  id_destroy(&segment->container);
  id_destroy(&segment->id);
  free(segment);
  return ERROR_NONE;
}

/**
 * Permet d'obtenir des informations sur un segment.
 * C'est a dire asid, type, address, size et perms.
 * @param segid: identifiant de segment
 */
t_error		segment_show(t_segid segid)
{
  o_segment*	o;

  segment_get(segid, (void **) &o);
  segment_affiche(o);

  return ERROR_NONE;
}

/**
 * Permet d'afficher les informations concernant un segment.
 * Precondition: o est non NULL.
 * @param o: le segment dont on affiche les informations
 */
void		_segment_affiche(o_segment* o)
{

  cons_msg("--");
  cons_msg("segment numero %q:\n", o->segid);

  cons_msg("appartient a l'espace d'adressage %q:\n",
	   o->asid);

  if (o->type == SEGMENT_TYPE_MEMORY)
    cons_msg("type: SEGMENT_TYPE_MEMORY\n");
  else
    cons_msg("type: SEGMENT_TYPE_CATCH\n");

  cons_msg("adresse: %i\n", o->address);
  cons_msg("taille (en octet): %i\n", o->size);

  cons_msg("permissions: ");
  if (o->perms & PERM_READ)
    cons_msg("             lecture");
  if (o->perms & PERM_WRITE)
    cons_msg("             ecriture");
  if (o->perms & PERM_EXE)
    cons_msg("             execution");

  cons_msg("--");

}

/**
 * Permet d'afficher l'ensemble des segments geres.
 */
t_error		segment_dump(void)
{
  t_iterator	*it = NULL;


  set_head_ll(segment->container, it);

  cons_msg("-----");
  cons_msg("Ensemble des segments:\n");

  _segment_iterateur(&segment_affiche);

  cons_msg("-----");

  return ERROR_NONE;
}

/**
 * Permet d'effectuer un traitement sur chaque segment
 * @param fonction: traite un element
 */
static t_error	_segment_iterateur(pt_fontion pf)
{
  t_iterator	*it = NULL;

  _seg_it(pf, it);
}

/**
 * Permet de faire le travail de _segment_iterateur proprement dit
 * @param pf: definie le traitement a effectuer
 * @param it: la structure a parcourir
 */
static t_error _seg_it(pt_fonction pf, t_iterator *it)
{
  o_segment	*o = NULL;
  t_error	retour_d_erreur = ERROR_NONE;

  set_head(segment->container, it);
  set_object(segment->container, *it, (void **) &o);

  retour_d_erreur = pf(o);//traitement de l'element courant
  if(retour_d_erreur != ERROR_NONE)
    return retour_d_erreur;

  set_next(segment->container, *it, it);

  if (*it == ITERATOR_STATE_UNUSED)//fin de parcours
    return retour_d_erreur;

  _seg_it(pf, it);//appel recursif
}

/**
 * Permet de faire une copie d'un segment.
 * @param as:
 * @param original: l'identifiant du segment a copie
 * @param pt_copie: l'adresse de l'identifiant de la copie
 */
t_error		segment_clone(t_asid as, t_segid original,
		      t_segid* pt_copie)
{
  o_segment	*o = NULL;
  t_error	sortie = ERROR_NONE;

  if (NULL == (o = malloc(sizeof (o_segment))))
    return ERROR_UNKNOWN;

  sortie = segment_get(original, (void **) &o);
  if (sortie !=	ERROR_NONE)
    return sortie;

  id_reserve(&(segment->id), &(original->segid))
  o->asid = as;
  original->type = o->segid;
  original->address = o->address;
  original->size = o->size;
  original->perms = o->perms;

  pt_copie = &(original->segid);

  return sortie;
}

/**
 * Permet de mettre un segment pre_alloue dans le conteneur.
 * @param as:
 * @param o:
 */
t_error	segment_inject(t_asid as, o_segment *o)
{
  o->asid = as;
  return set_add(segment->container, (void*) o);
  return ERROR_NONE;
}

/**
 * Permet de changer un segment d'epace d'adressage.
 * @param sid: identificateur du segment
 * @param as: identificateur de l'espace d'adressage.
 */
t_error		segment_give(t_segid sid, t_asid asid)
{
  o_segment	*o = NULL;
  t_error	sortie = ERROR_NONE;

  sortie = segment_get(segid, (void **) &o);
  if(sortie !=	ERROR_NONE)
    return sortie;

  o->asid = asid;
  return sortie;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}
