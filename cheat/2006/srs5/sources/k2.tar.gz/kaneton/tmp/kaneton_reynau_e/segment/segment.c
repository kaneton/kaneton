/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file         /home/buckman/kaneton/core/kaneton/segment/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:39:03 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the segment manager manages physical memory.
 *
 * it  is  able   to  reserve  and  release  memory   areas  (see  the
 * segment-fit.c for  allocation algorithm)  and to operated  on these
 * area: resize, split, copy, etc.
 *
 * a segment  is identified by  a 64 bits identifier  corresponding to
 * its physical  address. so  it is easy  to retrieve  this identifier
 * given the base address of a segment.
 *
 * remember  that  segments are  global:  there  is  only one  set  of
 * segments objects for  the entire kernel. the set  of segments in an
 * address space is just a set of identifiers.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have  to write the entire manager:  this file implementing
 * independent code plus  an architecture dependant file (ia32-virtual
 * or ia32-segment for example).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the init variable, filled by the bootloader, containing in this case
 * the list of segments to mark used.
 */

extern t_init*		init;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

m_segment*		segment;

/*
 * ---------- functions -------------------------------------------------------
 */

/**
 * Permet d'initialiser la gestion des segments
 */
t_error		segment_init(void)
{


  if (NULL == (segment = malloc(sizeof(m_segment))))
      return ERROR_UNKNOWN;

  id_build(&segment->id);
/*id_build(&m_A->id);
...
id_reserve(&m_A->id, &Aid1);
id_reserve(&m_A->id, &Aid2);
id_reserve(&m_A->id, &Aid3);*/

/* On verra plus tard
  segment->stats = ;//t_staid*/

  segment->start = init->mem;
  segment->size = init->memsz;
  segment->fit = FIT_FIRST;

  id_build(&segment->container);
  set_reserve_ll(/*options*/, INIT_SEGMENTS,
		 sizeof(segment), &segment->container);

  return ERROR_NONE;
}

/**
 * Permet d'effacer le gestionnaire de segments
 */
t_error		segment_clean(void)
{
  id_destroy(&segment->id);
  free(segment);
  return ERROR_NONE;
}

/**
 * Permet d'obtenir des informations sur un segment.
 * C'est a dire asid, type, address, size et perms.
 */
t_error		segment_show(t_segid id)
{
  o_segment	*o;

  set_get(id, segment->container, &o);
  cons_msg("--");
  cons_msg("segment numero %q:\n", id);

  cons_msg("appartient a l'espace d'adressage %q:\n",
	   o->asid);

  if (o->type == SEGMENT_TYPE_MEMORY)
    cons_msg("type: SEGMENT_TYPE_MEMORY\n");
  else
    cons_msg("type: SEGMENT_TYPE_CATCH\n");

  cons_msg("adresse: %i\n", o->address);
  cons_msg("taille (en octet): %i\n", o->size);

  cons_msg("permissions: ");
  if (o->perms & PERM_READ)
    cons_msg("             lecture");
  if (o->perms & PERM_WRITE)
    cons_msg("             ecriture");
  if (o->perms & PERM_EXE)
    cons_msg("             execution");

  cons_msg("--");

  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}

/**
 * Permet de.
 */
t_error	segment_()
{
  return ERROR_NONE;
}
