/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/as/as.c
 *
 * created       julien quintard   [tue dec 13 03:05:27 2005]
 * updated       matthieu bucchianeri   [fri jan 27 18:11:14 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the address space manager manages address spaces.
 *
 * an address space describes process' useable memory. each address space
 * is composed of two sets.
 *
 * the first describes the segments held by this address space, in other
 * words the physical memory.
 *
 * the latter describes the regions, the virtual areas which reference
 * some segments.
 *
 * a task can give its address space to another with as_give.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the address space manager builds address space objects.
 *
 * every address space object is essentially composed of two sets: a
 * set of segments which list the segments held by this address space and
 * a set of regions which describes the useable virtual address ranges.
 *
 * the student just has to write the functions to reserve, release, get etc..
 * an address space.
 *
 * note that the address space does nothing more. indeed, the segment
 * manager and the region manager will add and/or remove the segments/regions
 * to/from the address space by their own.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(as);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the address space manager variable.
 */

m_as*			as = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */

/**
 * Permet d'initialiser le gestionnaire d'espace d'adressage.
 */
t_error as_init(void)
{
    
}

/**
 * Permet de nettoyer le gestionnaire d'espace d'adressage.
 */
t_error as_init(void)
{
    
}

/**
 * Permet d'avoir des informations sur un espace d'adressage.
 * @param 
 */
t_error as_show(u_as u)
{

}

/**
 * Permet d'obtenir tout l'espace g�r�.
 */
t_error as_dump(void)
{

}

/**
 * Permet de r�alier une copie d'un gestionnaire.
 * @param task: non g�r� dans k2
 * @param old: original
 * @param new: copie
 */
t_error as_clone(u_task task, u_as old, u_as* new )
{

}
  
/**
 * Permet d'enlever un espace d'adressage.
 * @param u: identifiant de l'espace d'adressage � enlever
 */
t_error as_release(u_as u)
{
}

/**
 * Permet d'obtenir l'objet correspondant � l'identifiant.
 * @param u: l'identifiant d'espace d'adressage
 * @param o: l'adresse du pointeur sur l'objet correspondant
 */
t_error as_get(u as u, o as** o)
{

}