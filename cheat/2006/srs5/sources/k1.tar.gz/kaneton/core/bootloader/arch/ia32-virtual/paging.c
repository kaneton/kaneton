/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/paging.c
 *
 * created       julien quintard   [sun may 29 00:38:50 2005]
 * updated       matthieu bucchianeri   [tue jan 24 18:12:26 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * these function just install the paging mode to enable virtual memory
 * which is required by the kaneton kernel.
 *
 * think about mapping everything needed: kernel code, kernel stack, init
 * structure etc..
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"
#include "stdio.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*			init;



/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * ---------- statics -------------------------------------------------------
 */

static void	_paging_pd_init(void);
static void	_paging_isa_pt(void);
static void	_paging_kernel_pt(void);
static void	_paging_pt_init(t_paddr		ptaddr,
				t_paddr		baseaddr,
				t_opts		flags);

/*
 * Install bootloader page directory
 */
static void	_paging_pd_init(void)
{
  int		i;
  t_paddr*	pde = NULL;
  t_paddr	pt_isa;
  t_paddr	pt_k;
  t_opts	flags;
  t_paddr	gdt_addr;

  gdt_addr = init->alloc + init->allocsz;
  for (i = 0, pde = (t_paddr*)(gdt_addr + 1 * PAGESZ);
       i < PDSZ;
       ++i)
    pde[i] = 0;
  pt_isa = gdt_addr + 2 * PAGESZ;
  pt_k = gdt_addr + 3 * PAGESZ;
  flags = PD_G | PD_PCD | PD_PWT | PD_RW | PD_P;

  pde[PD_INDEX(MEMSTART)] = pt_isa | flags;
  pde[PD_INDEX(INIT_RELOCATE)] = pt_k | flags;
}

/*
 * Install bootloader ISA page table
 */
static void	_paging_isa_pt(void)
{
  t_paddr	ptaddr;
  t_paddr	baseaddr;
  t_opts	flags;

  ptaddr = (init->alloc + init->allocsz) + 2 * PAGESZ;
  baseaddr = MEMSTART;
  flags = PT_G | PT_PCD | PT_PWT | PT_RW | PT_P;
  _paging_pt_init(ptaddr, baseaddr, flags);
}

/*
 * Install bootloader Kernel page table
 */
static void	_paging_kernel_pt(void)
{
  t_paddr	ptaddr;
  t_paddr	baseaddr;
  t_opts	flags;

  ptaddr = (init->alloc + init->allocsz) + 3 * PAGESZ;
  baseaddr = INIT_RELOCATE;
  flags = PT_G | PT_PCD | PT_PWT | PT_RW | PT_P;
  _paging_pt_init(ptaddr, baseaddr, flags);
}

/*
 * Install a page table following parameters
 *
 * @param ptaddr: page table address
 * @param baseaddr: page base address
 * @param flags: page options
 *
 */
static void	_paging_pt_init(t_paddr		ptaddr,
				t_paddr		baseaddr,
				t_opts		flags)
{
  int		i;
  t_paddr*	pte = NULL;

  for (i = 0, pte = (t_paddr*)ptaddr;
       i < PTSZ;
       ++i)
      pte[i]= (((baseaddr + (i * PAGESZ)) >> 12) << 12) | flags;
  if (baseaddr == MEMSTART)
    pte[0] = 0;
}

/*
 * ---------- publics -------------------------------------------------------
 */

/*
 * Installs paging mode for bootloader
 */
void		paging_bootloader_init(void)
{
  t_paddr	pd_addr;

  _paging_pd_init();
  _paging_isa_pt();
  _paging_kernel_pt();

  pd_addr = (init->alloc + init->allocsz) + 1 * PAGESZ;
  asm volatile ("mov %1, %%eax		\n\t"
		"mov %%eax, %%cr3	\n\t"
		"mov %%cr0, %%eax	\n\t"
		"or %0, %%eax		\n\t"
		"mov %%eax, %%cr0	\n\t"
		:
		: "g" (1 << 31), "g" (pd_addr)
		: "%eax");
}

/*
 * Prints a virtual address and its physical translation
 *
 * @param addr: the virtual address to translate
 */
void		paging_translate_va(t_paddr addr)
{
  t_paddr	pdi, pti, offset;
  t_paddr	pde, pte;
  t_paddr*	pd = NULL;
  t_paddr*	pt = NULL;
  t_paddr	pa;

  pdi = addr >> 22;
  pti = (addr << 10) >> 22;
  offset = (addr << 20) >> 20;

  pd = (t_paddr*)((init->alloc + init->allocsz) + 1 * PAGESZ);
  pde = *(pd + pdi);
  pt = (t_paddr*)((pde >> 12) << 12);
  pte = *(pt + pti);
  pa = ((pte >> 12) << 12) + offset;
  my_printf("va: %p => pa: %p\n", addr, pa);
}
