/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/cons.c
 *
 * created       julien quintard   [sat may 28 18:23:13 2005]
 * updated       matthieu bucchianeri   [tue jan 24 12:44:22 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the student has to fill in this file just to be able to print some
 * debug messages.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * the console variable.
 */

t_cons			cons;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Initialize Console: cursor, video memory, color attributs
 */

void			cons_init(void)
{
  cons_clear_screen();
  cons.vga = (char *)CONS_ADDR;
  cons.line = 0;
  cons.column = 0;
  cons.attr = CONS_WHITE;
}

/*
 * fill screen with black
 */
void			cons_clear_screen(void)
{
  char			*video = (char *) CONS_ADDR;
  int			i;

  for (i = 0; i < CONS_SIZE; i += 2)
    {
      video[i] = '\0';
      video[i + 1] = CONS_WHITE; // non important
      /* without intensity or 0x0f with */
    }
}

/*
 * Print a String to the Console Screen
 */

void			cons_print_string(char *string)
{
  int			i;

  for (i = 0; string[i]; ++i)
    cons_print_char(string[i]);
}

/*
 *  Print a Number to the Console Screen
 */

void			cons_print_number(int number)
{
  cons_print_number_base(number, "0123456789");
}

void			cons_print_number_base(int number, char* base)
{
  int			i;
  char			revnbr[32];

  if (number < 0)
    cons_print_char('-');
  if (number)
    {
      for (i = 0; number; ++i)
	{
	  revnbr[i] = base[(number % strlen(base))];
	  number /= strlen(base);
	}
      for (--i; i >= 0; --i)
	cons_print_char(revnbr[i]);
    }
  else
    cons_print_char(base[0]);
}

/*
 * Print a Char to the Console Screen
 */

void			cons_print_char(char c)
{
  int			i;
  int			long_tab = 8;
  int			i_pixel;

  if (c == '\t')
    {
      i = 0;
      while (((cons.column + i) < CONS_COLUMNS) &&
	     (i < long_tab))
	{
	  cons_print_char(' ');
	  ++i;
	}
    }
  else if (c == '\n')
    {
      cons.column = 0;
      cons.line = (cons.line + 1) % CONS_LINES;
    }
  else
    {
      i_pixel = (cons.line * CONS_COLUMNS +
		 cons.column) * 2;
      cons.vga[i_pixel] = c;
      cons.vga[i_pixel + 1] = cons.attr;

      ++cons.column;
      if (cons.column == CONS_COLUMNS)
	{
	  cons.column = 0;
	  cons.line = (cons.line + 1)  % CONS_LINES;
	}
    }
}

/*
 * Print A Panic Message
 */

void			cons_panic(char *message)
{
  unsigned char		tmp;

  tmp = cons.attr;
  cons_set_attr(CONS_RED | CONS_BACK_BLUE);
  cons_print_string("KERNEL PANIC!!! => ");
  cons_print_string(message);
  cons_set_attr(tmp);
}

/*
 * Change _attr
 */
void			cons_set_attr(t_uint8 attr)
{
  cons.attr = attr;
}

/*
 * Save console into init structure
 */
void			cons_init_init(void)
{
  init->machdep.cons = cons;
}
