#include "stdio.h"
#include "stdarg.h"

#include <kaneton.h>


#define		BUFFSIZE 4096

static void	_flush(void);
static void	_putc(valist	*args);
static void	_puts(valist	*args);
static void	_putdi(valist	*args);
static void	_puto(valist	*args);
static void	_putu(valist	*args);
static void	_putx(valist	*args);
static void	_putX(valist	*args);
static void	_putp(valist	*args);
static void	_putattr(valist	*args);

char		_buff[BUFFSIZE + 1];
int		_pos = -1;


/*
** Tableaux statiques
*/

static const printf_t	tab[] =
{
  {"c", _putc},
  {"s", _puts},
  {"d", _putdi},
  {"i", _putdi},
  {"o", _puto},
  {"u", _putu},
  {"x", _putx},
  {"X", _putX},
  {"p", _putp},
  {"A", _putattr},
  {0, 0}
};

/*
** Cette fonction affiche la cha�ne format�e sur la sortie standard.
*/
int		my_printf(const char *format, ...)
{
  valist	args;
  int		size = 0;
  unsigned int	i;
  unsigned int	j;

  if (_pos == -1)
    for (i = 0, _pos = 0; i < BUFFSIZE; ++i)
      _buff[i] = 0;

  vastart(args, format);
  for (i = 0; format[i] != '\0'; ++i)
    {
      if (format[i] == '%')
	{
	  for (j = 0; tab[j].pattern; ++j)
	    if (!strncmp(tab[j].pattern, format + i + 1, strlen(tab[j].pattern)))
	      {
		tab[j].func(&args);
		break;
	      }
	  if (!tab[j].pattern)
	    my_putchar(format[i + 1]);
	  ++i;;
	}
      else
	my_putchar(format[i]);
    }
  vaend(args);
  return size;
}

/*
** Cette fonction affiche un caract�re sur la sortie standard.
*/
int		my_putchar(int c)
{
  _buff[_pos] = c;
  ++_pos;
  if (c == '\n')
    _flush();
  if (_pos == BUFFSIZE)
    _flush();
  return 1;
}

/*
** Cette fonction affiche une cha�ne de caract�res sur la sortie standard.
*/
int		my_puts(const char *s)
{
  if (s[0] == '\0')
    return 0;
  return my_putchar(s[0]) + my_puts(s + 1);
}

/*
** Cette fonction affiche un nombre sur la sortie standard.
*/
int		my_putnbr(int n)
{
  if (n < 0)
  {
    if (my_putchar('-') != 1)
      return -1;
    return my_putunnbr(-n) + 1;
  }
  return my_putunnbr(n);
}

/*
** Cette fonction affiche un nombre sur la sortie standard.
*/
int		my_putunnbr(unsigned int n)
{
  return my_putunnbr_base(n, "0123456789");
}

/*
** Cette fonction affiche un nombre sur la sortie standard dans la base pass�e
** en argument.
*/
int		my_putunnbr_base(unsigned int n, const char *base)
{
  int		baselen;
  char		snbr[32];
  int		i, cpt;

  if (!n)
    {
      my_putchar(base[0]);
      return 1;
    }
  baselen = strlen(base);
  for (i = 0; n; ++i)
    {
      snbr[i] = base[n % baselen];
      n /= baselen;
    }
  for (cpt = 0; i; --i, ++cpt)
    my_putchar(snbr[i - 1]);
  return cpt;
}


// printf_functions
static void	_putc(valist	*args)
{
  my_putchar(vaarg(*args, char));
}

static void	_puts(valist	*args)
{
  my_puts(vaarg(*args, char *));
}

static void	_putdi(valist	*args)
{
  my_putnbr(vaarg(*args, int));
}

static void	_puto(valist	*args)
{
  my_putunnbr_base(vaarg(*args, unsigned int), "01234567");
}

static void	_putu(valist	*args)
{
  my_putunnbr(vaarg(*args, unsigned int));
}

static void	_putx(valist	*args)
{
  my_putunnbr_base(vaarg(*args, unsigned int), "0123456789abcdef");
}

static void	_putX(valist	*args)
{
  my_putunnbr_base(vaarg(*args, unsigned int), "0123456789ABCDEF");
}

static void	_putp(valist	*args)
{
  my_puts("0x");
  my_putunnbr_base((unsigned int) vaarg(*args, void *), "0123456789abcdef");
}

static void	_putattr(valist	*args)
{
  _flush();
  cons_set_attr(vaarg(*args, char));
}

static void	_flush(void)
{
  // write(STDOUT_FILENO, _buff, _pos)
  _buff[_pos] = 0;
  cons_print_string(_buff);
  for (_pos = 0; _pos < BUFFSIZE; ++_pos)
    _buff[_pos] = 0;
  _pos = 0;
}
