/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/bootloader.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:23:13 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the bootloader is to install a correct environment for
 * the kernel.
 *
 * the first thing to do is to relocate the different kaneton data structure
 * in order to build the t_init structure. this structure must contain
 * everything the kernel will need.
 *
 * for more information on the relocating, take a look to the kaneton
 * paper which describes the entire kaneton reference.
 *
 * once the init structure was built, the kernel has to be launched.
 *
 * nevertheless, the kernel needs to evolve with the protected mode and
 * paging mode activated, so the bootloader first has to install these.
 *
 * printing some messages is interesting showing the protected mode and
 * paging mode are correctly installed.
 *
 * after all, the bootloader has launch the kernel binary.
 *
 * look at the ld scripts to know where the kernel has to be loaded.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"
#include "stdio.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * these three variable are globals to avoid them to be lost when the
 * bootloader changes its stack.
 *
 * indeed, before jumping on the kernel a new stack is created so the local
 * variables will no longer be accessible. putting these variables in
 * globals bypass this problem.
 */

void			(*kernel)(t_init*);

t_reg32			ebp;
t_reg32			esp;

/*
 * ---------- functions -------------------------------------------------------
 */


int			bootloader(t_uint32		magic,
				   multiboot_info_t*	mbi)
{
  // Cons init
  cons_init();
  my_printf("%AConsole initialisee !%A\n", CONS_RED, CONS_WHITE);

  // init()
  init_init(mbi);
  my_printf("%AInit done !%A\n", CONS_RED, CONS_WHITE);
  init_dump();

  // PMode
  pmode_init();
  my_printf("%APMode initialise%A\n", CONS_RED, CONS_WHITE);


  // Paging
  paging_bootloader_init();
  my_printf("%Amode virtuel !!!! Youpi%A\n", CONS_RED, CONS_WHITE);
  init_dump();

  // loop for instance
  kernel = (void*)(*(t_paddr*)(init->kcode + ENTRY_POINT_POS));
  my_printf("\nPret a charger le kernel\n");

  // FIXME: sauvegarde stack
  (*kernel)(init);
  // FIXME: restauration stack
  while (1);
  return (0);
}

