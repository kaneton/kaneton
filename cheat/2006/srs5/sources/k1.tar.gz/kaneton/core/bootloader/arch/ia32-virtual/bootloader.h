/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/bootloader.h
 *
 * created       julien quintard   [fri feb 11 02:23:53 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:20:27 2006]
 */

#ifndef BOOTLOADER_H
#define BOOTLOADER_H		1

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      bootloader.c
 *      cons.c
 *      init.c
 *      paging.c
 *      pmode.c
 */

/*
 * bootloader.c
 */

# define	ENTRY_POINT_POS	24	// ENTRY POINT position in Elf Header

int		bootloader(t_uint32			magic,
			   multiboot_info_t*		mbi);


/*
 * cons.c
 */


/*
 * init.c
 */

/*
 * paging.c
 */


/*
 * pmode.c
 */


/*
 * eop
 */

#endif
