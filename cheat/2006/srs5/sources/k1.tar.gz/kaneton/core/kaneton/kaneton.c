/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:48:24 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

void			kaneton(t_init*				bootloader)
{

  char *ptr;
  int i, j;
  char *coin = \
"           ,-.\n\
       ,--' ~.).\n\
     ,'         `.\n\
    ; (((__   __)))            ____________________\n\
    ;  ( (#) ( (#)            /                   /\n\
    |   \\_/___\\_/|          /  KOIN KOIN KOIN ! /\n\
   ,\"  ,-'    `__\".-------/___________________/\n\
  (   ( ._   ____`.)--._        _\n\
   `._ `-.`-' \\(`-'  _  `-. _,-' `-/`.\n\
    ,')   `.`._))  ,' `.   `.  ,','  ;\n\
  .'  .     `--'  /     ).   `.      ;\n\
 ;     `-        /     '  )         ;\n\
 \\                       ')       ,'\n\
  \\                     ,'       ;\n\
   \\               `~~~'       ,'\n\
    `.                      _,'\n\
      `.                ,--'\n\
        `-._________,--'\n\
\n\
\n\
gonnar_j\n\
nguyen_g\n\
reynau_e\n";

  ptr = (char*)CONS_ADDR;
  for (i = 0; i < (CONS_COLUMNS * CONS_LINES * 2); ++i)
    ptr[i] = 0;
  for (i = 0, j = 0; coin[i] != 0; ++i, ++j)
    {
      if (coin[i] == '\n')
	for (; j % CONS_COLUMNS; ++j)
	  {
	    ptr[j * 2] = ' ';
	    ptr[j * 2 + 1] = 0;
	  }
      else
	{
	  ptr[j * 2] = coin[i];
      	  ptr[j * 2 + 1] = CONS_YELLOW;
	}
    }
  while (1) ;
}
