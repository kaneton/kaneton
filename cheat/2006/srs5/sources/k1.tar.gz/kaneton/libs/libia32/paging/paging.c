/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/paging/paging.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:05 2005]
 * updated       matthieu bucchianeri   [mon jan 30 23:51:57 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage paging.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will have  to fill  this  file with  function related  to
 * paging mode in the cpu: enable, disabling etc.
 *
 * there are no  restrictions about these functions, but  keep in mind
 * that  page-directory management and  page-tables management  are to
 * place in pd.c and pt.c.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- functions -------------------------------------------------------
 */

