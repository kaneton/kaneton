/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/paging/paging.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:30:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * declares paging structures, defines, etc.
 *
 */

#ifndef IA32_IA32_PAGING_H
#define IA32_IA32_PAGING_H	1

/*
 * Virtual addr
 *
 *  31                  21                  11                     0
 *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  |       PDI         |       PTI         |        Offset         |
 *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *  PDI: Page Directory Index, points to a PDE in Page Directory
 *  PTI: Page Table Index, points to a PTE in the Page Table corresponding
 *       to the PDE
 *  Offset: Index in the Memory Page mapped by PTE
 *
 */


/*
 *  PDE
 *
 *  31                                      11     8 7 6 5 4 3 2 1 0
 *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  |                                       |     | | | | | | | | | |
 *  |                                       |     | |P| | |P|P|U|R| |
 *  |        PAGE TABLE BASE ADDRESS        |AVAIL|G| |0|A|C|W|/|/|P|
 *  |                                       |     | |S| | |D|T|S|W| |
 *  |                                       |     | | | | | | | | | |
 *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *
 *
 */

/*
 *  PTE
 *
 *  31                                      11     8 7 6 5 4 3 2 1 0
 *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  |                                       |     | | | | | | | | | |
 *  |                                       |     | |P| | |P|P|U|R| |
 *  |          PAGE   BASE ADDRESS          |AVAIL|G|A|D|A|C|W|/|/|P|
 *  |                                       |     | |T| | |D|T|S|W| |
 *  |                                       |     | | | | | | | | | |
 *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *
 */

/*
 * defines
 *
 */

# define	MEMSTART	0

# define	PD_INDEX(addr)	((addr) >> 22)

# define	PDSZ		1024
# define	PTSZ		1024

# define	PD_G		(1 << 8)
# define	PD_PS		(1 << 7)
# define	PD_A		(1 << 5)
# define	PD_PCD		(1 << 4)
# define	PD_PWT		(1 << 3)
# define	PD_US		(1 << 2)
# define	PD_RW		(1 << 1)
# define	PD_P		(1 << 0)

# define	PT_G		(1 << 8)
# define	PT_PAT		(1 << 7)
# define	PT_D		(1 << 6)
# define	PT_A		(1 << 5)
# define	PT_PCD		(1 << 4)
# define	PT_PWT		(1 << 3)
# define	PT_US		(1 << 2)
# define	PT_RW		(1 << 1)
# define	PT_P		(1 << 0)


/*
 * Functions
 *
 */

void		paging_bootloader_init(void);

void		paging_translate_va(t_paddr addr);

#endif
