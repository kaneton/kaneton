/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/libia32/include/pmode/pmode.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [mon jan 30 22:31:13 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef IA32_IA32_PMODE_H
#define IA32_IA32_PMODE_H	1

/*
 * D�finitions
 *
 *
 * GDT: Segment Descriptor
 *
 *  63                                                            32
 *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  |               | | | | |       | |   | |       |               |
 *  |               | |D| |A| LIMIT | | D | |       |               |
 *  |  BASE  31:24  |G|/|0|V|       |P| P |S| TYPE  |  BASE  23:16  |
 *  |               | |B| |L| 19:16 | | L | |       |               |
 *  |               | | | | |       | |   | |       |               |
 *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  |                               |                               |
 *  |                               |                               |
 *  |          BASE  15:0           |         LIMIT  15:0           |
 *  |                               |                               |
 *  |                               |                               |
 *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  31                                                             0
 *
 *
 *  BASE:	32bits address.
 *		Linear address of the memory segment
 *  LIMIT:	16 bits.
 *		Segment lenght (in bytes if G is set to 0, else in pages (4k))
 *  G:		1: 4k mode, 0: 1byte mode
 *  TYPE:	Code/Data/Stack
 *  S:		1: Segment descriptor/0: system descriptor
 *  DPL:	Descriptor Privilege Level (kernel, user, ...)
 *  P:		Present
 *  D/B:	Data/Instruction length => 1: 32bits
 *  AVL:	Available
 *
 *
*/

// Informations G�n�rales relatives � la GDT
# define	GDT_SIZE	0x5

// Flags de la GDT
// _type: cf manuel intel Vol.3 p.73
# define	GDT_RW		0x02	// segment de donn�es
# define	GDT_CONFORM	0x04	//
# define	GDT_XO		0x08	// segment de code (Execute Only)

# define	GDT_DPL0	0x00	// 0000 0000
# define	GDT_SYSTEM	0x10	// 0001 0000
# define	GDT_DPL1	0x20	// 0010 0000
# define	GDT_DPL2	0x40	// 0100 0000
# define	GDT_DPL3	0x60	// 0110 0000
# define	GDT_TYPE_1	0x80	// 1000 0000
// _flags
# define	GDT_AVL		0x10	// 0001 0000
# define	GDT_FLAGS_0	0x20	// 0010 0000
# define	GDT_USE32	0x40	// 0100 0000
# define	GDT_GRANULAR	0x80	// 1000 0000

/*
** Structures et Types
*/

struct		gdt_s
{
  t_uint16	_limit;
  t_uint16	_base15_0;
  t_uint8	_base23_16;
  t_uint8	_type;
  t_uint8	_flags;
  t_uint8	_base31_24;
} __attribute__ ((packed));

typedef struct	gdt_s	gdt_t;

struct		gdtr_s
{
  t_uint16	_size;
  t_uint32	_addr;
} __attribute__ ((packed));

typedef struct	gdtr_s	gdtr_t;

// functions
void		pmode_init(void);

#endif
