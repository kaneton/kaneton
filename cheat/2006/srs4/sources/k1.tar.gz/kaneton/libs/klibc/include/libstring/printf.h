/*
 * licence kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/libs/klibc/include/libstring/printf.h
 *
 * created       julien quintard   [fri feb 11 02:40:57 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:53:20 2006]
 */

#ifndef LIBSTRING_PRINTF_H
#define LIBSTRING_PRINTF_H	1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <libsys/types.h>

/*
 * ---------- defines ---------------------------------------------------------
 */

#define PRINTF_LADJUST		0x1
#define PRINTF_ZPAD		0x2
#define PRINTF_DOT		0x4

/*
 * ---------- macros ----------------------------------------------------------
 */

#define PRINTF_SWAP(_i1_, _i2_)						\
  {									\
    int		_tmp_;							\
									\
    _tmp_ = (_i1_);							\
    (_i1_) = (_i2_);							\
    (_i2_) = _tmp_;							\
  }

/* XXX */
#define fprintf(_stream_, _args_...) printf(_args_)
/* XXX */

/*
 * ---------- types -----------------------------------------------------------
 */

typedef int			(*t_printf_char_fn)(char	c);
typedef void			(*t_printf_attr_fn)(u_int8_t	attr);

/*
 * Escape supply for color
 */
# define ESCAPE_SEQ		"\\033"

/*
 * Macro for the color
 */

# define BLACK				0
# define BLUE				1
# define GREEN				2
# define CYAN				3
# define RED				4
# define PINK				5
# define YELLOW				6
# define WHITE				7

# define STRING(_STR_)			#_STR_

# define ICOLOR_STRING(BG, FG)		"\\033[1;4" STRING(BG) \
					";3" STRING(FG) "m"

# define COLOR_STRING(BG, FG)		"\\033[4" STRING(BG) \
					";3" STRING(FG) "m"


# define COLOR(_X_)			COLOR_STRING(0, _X_)

# define ICOLOR(_X_)			ICOLOR_STRING(0, _X_)

# define BCOLOR(_X_, _Y_)		COLOR_STRING(_X_, _Y_)

# define BICOLOR(_X_, _Y_)		ICOLOR_STRING(_X_, _Y_)

#endif
