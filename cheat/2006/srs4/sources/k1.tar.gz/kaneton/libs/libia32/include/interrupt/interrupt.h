/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/include/interrupt/interrupt.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [tue feb 21 07:27:07 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef IA32_IA32_INTERRUPT_H
#define IA32_IA32_INTERRUPT_H	1

/*
 * ---------- definitions -----------------------------------------------------
 */


#define IDT_DPL_KERN		0x9 // 1001 (P=1, DPL = 0, S = 1)
#define IDT_DPL_USER		0xf // 1111 (P=1, DPL = 3, S = 1)

#define IDT_TASK_FLAGS		0x8500 // 1..0 0101 .... ....
#define IDT_INTERRUPT_FLAGS	0x8e00 // 1..0 1110 000. ....
#define IDT_TRAP_FLAGS		0x8f00 // 1..0 1111 000. ....

#define IDT_MAX_ENTRY		256

typedef t_uint16 t_idt_pos;

typedef struct
{
  t_uint16		offset_0;
  t_uint16		seg_select;
  t_uint16		flags;
  t_uint16		offset_16;

} __attribute__((__packed__)) t_idt;

typedef struct
{
  t_uint16			limit;
  t_uint32			base;
} __attribute__((__packed__))	d_idtr;

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *
 *	../../interrupt/interrupt.c
 *	../../interrupt/idt.c
 *
 */

/*
 * ../../interrupt/interrupt.c
 */

void		ia32_activate_interruptions(d_idtr		*idtr);

void		ia32_desactivate_interruptions(void);

t_uint8		ia32_is_interruption_active(void);

t_paddr		ia32_no_error_code_exception_handler(void);

t_paddr		ia32_error_code_exception_handler(void);

t_paddr		ia32_master_irq_handler(void);

t_paddr		ia32_slave_irq_handler(void);


/*
 * ../../interrupt/idt.c
 */

void		ia32_idt_init(t_uint32			idt,
			      d_idtr			*idtr);

t_gdt_pos	ia32_idt_edit_entry(t_gdt_pos		pos,
				    t_uint32		offset,
				    t_uint16		segment,
				    t_uint16		flags,
				    t_uint8		dpl,
				    d_idtr		*idtr);

t_idt_pos	ia32_idt_remove_entry(t_idt_pos		pos,
				    d_idtr		*idtr);

void		ia32_debug_idt_print(d_idtr		*idtr);


/*
 * eop
 */

/* t_paddr		_low_level_divide_error_handler; */
/* t_paddr		_low_level_debug_handler; */
/* t_paddr		_low_level_nmi_interrupt_handler; */
/* t_paddr		_low_level_breakpoint_handler; */
/* t_paddr		_low_level_overflow_handler; */
/* t_paddr		_low_level_bound_range_exceeded_handler; */
/* t_paddr		_low_level_invalid_opcode_handler; */
/* t_paddr		_low_level_device_not_available_handler; */
/* t_paddr		_low_level_coprocessor_segment_overrun; */
/* t_paddr		_low_level_invalid_tss_handler; */
/* t_paddr		_low_level_segment_not_present_handler; */
/* t_paddr		_low_level_stack_segment_fault_handler; */
/* t_paddr		_low_level_general_protection_handler; */
/* t_paddr		_low_level_page_fault_handler; */
/* t_paddr		_low_level_intel_reserved_1_handler; */
/* t_paddr		_low_level_alignement_check_handler; */
/* t_paddr		_low_level_floating_point_error_handler; */
/* t_paddr		_low_level_machine_check_handler; */
/* t_paddr		_low_level_intel_reserved_2_handler; */
/* t_paddr		_low_level_intel_reserved_3_handler; */
/* t_paddr		_low_level_intel_reserved_4_handler; */
/* t_paddr		_low_level_intel_reserved_5_handler; */
/* t_paddr		_low_level_intel_reserved_6_handler; */
/* t_paddr		_low_level_intel_reserved_7_handler; */
/* t_paddr		_low_level_intel_reserved_8_handler; */
/* t_paddr		_low_level_intel_reserved_9_handler; */
/* t_paddr		_low_level_intel_reserved_10_handler; */
/* t_paddr		_low_level_intel_reserved_11_handler; */
/* t_paddr		_low_level_intel_reserved_12_handler; */
/* t_paddr		_low_level_intel_reserved_13_handler; */
/* t_paddr		_low_level_intel_reserved_14_handler; */
/* t_paddr		_low_level_irq_0_handler; */
/* t_paddr		_low_level_irq_1_handler; */
/* t_paddr		_low_level_irq_2_handler; */
/* t_paddr	        _low_level_irq_3_handler; */
/* t_paddr	        _low_level_irq_4_handler; */
/* t_paddr	        _low_level_irq_5_handler; */
/* t_paddr	        _low_level_irq_6_handler; */
/* t_paddr	        _low_level_irq_7_handler; */
/* t_paddr	        _low_level_irq_8_handler; */
/* t_paddr	        _low_level_irq_9_handler; */
/* t_paddr	        _low_level_irq_10_handler; */
/* t_paddr	        _low_level_irq_11_handler; */
/* t_paddr	        _low_level_irq_12_handler; */
/* t_paddr	        _low_level_irq_13_handler; */
/* t_paddr	        _low_level_irq_14_handler; */
/* t_paddr	        _low_level_irq_15_handler; */


#endif
