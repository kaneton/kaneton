/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/include/paging/paging.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat feb 18 04:56:16 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * declares paging structures, defines, etc.
 *
 */

#ifndef IA32_IA32_PAGING_H
# define IA32_IA32_PAGING_H

# define IA32_PAGING_PAGE_SIZE			(1 << 12)

/*
 * Entries of the tables
 */
typedef t_uint32	t_paging_entry;
typedef t_paging_entry	t_pd_entry;
typedef t_paging_entry	t_pt_entry;

# define IA32_PAGING_ENTRY_SIZE			(sizeof (t_paging_entry))
# define IA32_PAGING_PDE_SIZE			(sizeof (t_pd_entry))
# define IA32_PAGING_PTE_SIZE			(sizeof (t_pt_entry))

/*
 * Page table and directory flags
 */

typedef t_uint32	t_flags;

# define IA32_PAGING_PAGE_NO_PRESENT		(0)
# define IA32_PAGING_PAGE_PRESENT		(1)
# define IA32_PAGING_PAGE_PRESENT_BIT_MASK	(0)


# define IA32_PAGING_PAGE_RDONLY		(0)
# define IA32_PAGING_PAGE_RDWR			(1 << 1)
# define IA32_PAGING_PAGE_RDWR_BIT_MASK		(1)

# define IA32_PAGING_PAGE_SUPERVISOR		(0)
# define IA32_PAGING_PAGE_USER			(1 << 2)
# define IA32_PAGING_PAGE_PL_BIT_MASK		(2)

# define IA32_PAGING_PAGE_WRITE_BACK		(0)
# define IA32_PAGING_PAGE_WRITE_THROUGH		(1 << 3)
# define IA32_PAGING_PAGE_WBT_BIT_MASK		(3)

# define IA32_PAGING_PAGE_CACHED		(0)
# define IA32_PAGING_PAGE_NO_CACHED		(1 << 4)
# define IA32_PAGING_PAGE_CACHED_BIT_MASK	(4)

# define IA32_PAGING_PAGE_NO_ACCESSED		(0)
# define IA32_PAGING_PAGE_ACCESSED		(1 << 5)
# define IA32_PAGING_PAGE_ACCESSED_BIT_MASK	(5)

# define IA32_PAGING_PAGE_NO_DIRTY		(0)
# define IA32_PAGING_PAGE_DIRTY			(1 << 6)
# define IA32_PAGING_PAGE_DIRTY_BIT_MASK	(6)

# define IA32_PAGING_PAGE_SIZE_4K		0
# define IA32_PAGING_PAGE_SIZE_4M		(1 << 7)
# define IA32_PAGING_PAGE_SIZE_BIT_MASK		(7)

# define IA32_PAGING_PAGE_NO_GLOBAL		(0)
# define IA32_PAGING_PAGE_GLOBAL		(1 << 8)
# define IA32_PAGING_PAGE_GLOBAL_BIT_MASK	(8)

# define IA32_PAGING_PAGE_FREE			(0)
# define IA32_PAGING_PAGE_IN_USE		(1 << 9)
# define IA32_PAGING_PAGE_FREE_BIT_MASK		(9)


# define SET_BIT(_X_, _BIT_MASK_)		(_X_ | (1 << _BIT_MASK_))
# define UNSET_BIT(_X_, _BIT_MASK_)		(_X_ & (~(1 << _BIT_MASK_)))

//===============================================================
# define SET_PAGE_PRESENT(_X_)					\
		SET_BIT(_X_, IA32_PAGING_PAGE_PRESENT_BIT_MASK)

# define UNSET_PAGE_PRESENT(_X_)				\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_PRESENT_BIT_MASK)

# define GET_PAGE_PRESENT_STATUS(_X_)				\
		(1 == (_X_ & (1 << IA32_PAGING_PAGE_PRESENT_BIT_MASK)))

//===============================================================
# define SET_PAGE_RDONLY(_X_)					\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_RDWR_BIT_MASK)

# define SET_PAGE_RDWR(_X_)					\
		SET_BIT(_X_, IA32_PAGING_PAGE_RDWR_BIT_MASK)

# define GET_PAGE_RDWR_STATUS(_X_)				\
		(0 != (_X_ & (1 << IA32_PAGING_PAGE_RDWR_BIT_MASK)))
//===============================================================
# define SET_PAGE_SUPERVISOR(_X_)				\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_PL_BIT_MASK)

# define SET_PAGE_USER(_X_)					\
		SET_BIT(_X_, IA32_PAGING_PAGE_PL_BIT_MASK)

# define GET_PAGE_USER_STATUS(_X_)				\
		(0 != (_X_ & (1 << IA32_PAGING_PAGE_PL_BIT_MASK)))

# define GET_PAGE_SUPERUSER_STATUS(_X_)				\
		(0 == (_X_ & (1 << IA32_PAGING_PAGE_PL_BIT_MASK)))

//===============================================================
# define SET_PAGE_WRITE_BACK(_X_)				\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_WBT_BIT_MASK)

# define SET_PAGE_WRITE_THROUGH(_X_)				\
		SET_BIT(_X_, IA32_PAGING_PAGE_WBT_BIT_MASK)

//===============================================================
# define SET_PAGE_CACHED(_X_)					\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_CACHED_BIT_MASK)

# define UNSET_PAGE_CACHED(_X_)					\
		SET_BIT(_X_, IA32_PAGING_PAGE_CACHED_BIT_MASK)

//===============================================================
# define SET_PAGE_ACCESSED(_X_)					\
		SET_BIT(_X_, IA32_PAGING_PAGE_ACCESSED_BIT_MASK)

# define UNSET_PAGE_ACCESSED(_X_)				\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_ACCESSED_BIT_MASK)

//===============================================================
# define SET_PAGE_DIRTY(_X_)					\
		SET_BIT(_X_, IA32_PAGING_PAGE_DIRTY_BIT_MASK)

# define UNSET_PAGE_DIRTY(_X_)					\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_DIRTY_BIT_MASK)

//===============================================================
# define SET_PAGE_SIZE_4K(_X_)					\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_SIZE_BIT_MASK)

# define SET_PAGE_SIZE_4M(_X_)					\
		SET_BIT(_X_, IA32_PAGING_PAGE_SIZE_BIT_MASK)

//===============================================================
# define SET_PAGE_GLOBAL(_X_)					\
		SET_BIT(_X_, IA32_PAGING_PAGE_GLOBAL_BIT_MASK)

# define UNSET_PAGE_GLOBAL(_X_)					\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_GLOBAL_BIT_MASK)

//===============================================================
# define SET_PAGE_FREE(_X_)					\
		UNSET_BIT(_X_, IA32_PAGING_PAGE_FREE_BIT_MASK)

# define UNSET_PAGE_FREE(_X_)					\
		SET_BIT(_X_, IA32_PAGING_PAGE_FREE_BIT_MASK)

# define GET_PAGE_FREE_STATUS(_X_)				\
		(0 == (_X_ & (1 << IA32_PAGING_PAGE_FREE_BIT_MASK)))

//===============================================================
# define GET_PDE_INDEX(_X_)					\
		((_X_ >> 22) & 0x3FF)
# define GET_PTE_INDEX(_X_)					\
		((_X_ >> 12) & 0x3FF)

/*
 * t_error :
 *	0 - Ok, so far, so good
 *	1 - Unknown error
 */
# define ERR_UNKNOWN_ERROR			  1
# define ERR_PAGE_ALREADY_IN_USE		101
# define ERR_PAGE_ALREADY_FREE			102
# define ERR_PAGE_NB_MAX_REACHED		 67

// ugly but for this time...
# define assert(...)				((void *) 0)

// define for ia32_paging_table_alloc
# define ERR_PAGE_ALLOC				((t_paddr*)0xFFFFFFFF)


/*
 * Debug
 */
# define PAGING_DEBUG_ALL			42
# define PAGING_DEBUG_USE			34
# define PAGING_DEBUG_FREE			87

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *
 *	../../paging/paging.c
 *	../../paging/pd.c
 *	../../paging/pt.c
 */

/*
 * ../../paging/paging.c
 */

void		ia32_paging_init(t_paddr *paging_area_paddr,
				 t_size  paging_area_size);

t_error		ia32_paging_alloc_page(t_vaddr  vaddr,
				       t_paddr  paddr,
				       t_flags  flags);

t_error		ia32_paging_alloc_pages(t_vaddr  vaddr,
					t_paddr  paddr,
					t_size   size,
					t_flags  flags);

t_paddr			*ia32_paging_table_alloc(void);

t_error			ia32_paging_free_pages(t_vaddr vaddr, t_size size);

void		ia32_paging_debug(void);


/*
 * ../../paging/pd.c
 */

void		ia32_paging_pd_init(t_pd_entry *p_addr);

t_error		ia32_paging_pde_alloc(t_pd_entry* pd_paddr,
				      t_vaddr vaddr,
				      t_paddr paddr,
				      t_flags flags);

t_error		ia32_paging_pde_free(t_pd_entry* pd_paddr,
				     t_vaddr     vaddr);

void		ia32_paging_pd_debug(t_pd_entry *pde_paddr);


/*
 * ../../paging/pt.c
 */

void 		ia32_paging_pt_init(t_pt_entry* pt_paddr);

t_error		ia32_paging_pte_alloc(t_pt_entry* pt_paddr,
				      t_vaddr vaddr,
				      t_paddr paddr,
				      t_flags flags);

t_error		ia32_paging_pte_free(t_pt_entry* pt_paddr,
				     t_vaddr vaddr);

void		ia32_paging_pt_debug(t_pt_entry *pte_paddr, t_uint32 pde_ind);


/*
 * eop
 */

#endif
