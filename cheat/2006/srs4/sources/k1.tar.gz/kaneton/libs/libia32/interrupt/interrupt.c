/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/interrupt/interrupt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [tue feb 21 07:32:22 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage interrupt controller.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will use this file to place functions they wrote to manage
 * the pic. students may write as many functions as they whant without
 * any restrictions.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libia32.h>

/*
 * ---------- functions -------------------------------------------------------
 */

void		ia32_activate_interruptions(d_idtr		*idtr)
{
}

void		ia32_desactivate_interruptions(void)
{
}

t_uint8		ia32_is_interruption_active(void)
{
  return 0;
}

t_paddr		ia32_no_error_code_exception_handler(void)
{
  return 0;
}

t_paddr		ia32_error_code_exception_handler(void)
{
  return 0;
}

t_paddr		ia32_master_irq_handler(void)
{
  return 0;
}

t_paddr		ia32_slave_irq_handler(void)
{
  return 0;
}
