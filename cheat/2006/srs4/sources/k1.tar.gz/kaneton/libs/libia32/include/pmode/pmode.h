/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/include/pmode/pmode.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [fri feb 17 06:31:01 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef IA32_IA32_PMODE_H
#define IA32_IA32_PMODE_H	1

/*
 * ---------- definitions -----------------------------------------------------
 */


#define GDT_DPL_KERN		0x9 // 1001 (P=1, DPL = 0, S = 1)
#define GDT_DPL_USER		0xf // 1111 (P=1, DPL = 3, S = 1)

#define GDT_TYPE_D_RO		0x0 // 0000 (type = 0)
#define GDT_TYPE_D_RW		0x2 // 0010 (type = 2)
#define GDT_TYPE_D_RO_EXP	0x4 // 0100 (type = 4)
#define GDT_TYPE_D_RW_EXP	0x6 // 0110 (type = 6)
#define GDT_TYPE_C_X		0x8 // 1000 (type = 8)
#define GDT_TYPE_C_RX		0xa // 1010 (type = 10)
#define GDT_TYPE_C_X_EXP	0xc // 1100 (type = 12)
#define GDT_TYPE_C_RX_EXP	0xe // 1110 (type = 14)

#define GDT_FLAGS_G		(1 << 3) // 1000
#define GDT_FLAGS_D_B		(1 << 2) // 0100
#define GDT_FLAGS_L		(1 << 1) // 0010
#define GDT_FLAGS_AVL		(1 << 0) // 0001
#define GDT_FLAGS_STD		GDT_FLAGS_G | GDT_FLAGS_D_B

typedef t_uint16 t_gdt_pos;

typedef struct
{
  t_uint16		limit_0;
  t_uint16		base_0;
  t_uint8		base_16;
  t_uint8		dpl_type;
  t_uint8	        flags_limit_16;
  t_uint8		base_24;
} __attribute__((__packed__)) t_gdt;

typedef struct
{
  t_uint16			limit;
  t_uint32			base;
} __attribute__((__packed__))	d_gdtr;

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *
 *	../../pmode/pmode.c
 *	../../pmode/gdt.c
 *	../../pmode/ldt.c
 */

/*
 * ../../pmode/pmode.c
 */

void		ia32_enter_pmode(d_gdtr			*gdtr);

void		ia32_pmode_update_segments(t_uint8 cs, t_uint8 ds);

void		ia32_leave_pmode(void);

t_uint8		ia32_is_pmode(void);


/*
 * ../../pmode/gdt.c
 */

void		ia32_gdt_init(t_uint32			gdt,
			      d_gdtr			*gdtr);

void		ia32_gdt_build_ia32_virtual(d_gdtr		*gdtr);

t_gdt_pos	ia32_gdt_new_entry(t_uint32		base,
				   t_uint32		limit,
				   t_uint8		dpl,
				   t_uint8		type,
				   t_uint8		flags,
				   d_gdtr		*gdtr);

t_gdt_pos	ia32_gdt_edit_entry(t_gdt_pos		pos,
				    t_uint32		base,
				    t_uint32		limit,
				    t_uint8		dpl,
				    t_uint8		type,
				    t_uint8		flags,
				    d_gdtr		*gdtr);

t_gdt_pos	ia32_gdt_remove_entry(t_gdt_pos		pos);

void		ia32_debug_gdt_print(d_gdtr		*gdtr);


/*
 * ../../pmode/ldt.c
 */


/*
 * eop
 */

#endif
