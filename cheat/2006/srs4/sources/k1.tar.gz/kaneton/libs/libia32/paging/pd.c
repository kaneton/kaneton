/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/paging/pd.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:20 2005]
 * updated       Jerome Herbault   [sat feb 18 05:11:06 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page directory.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this    file   is    destinated   to    functions    dealing   with
 * page-directories. there are no restrictions about function names or
 * prototype, so feel free.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "paging/paging.h"
/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Initialisation of the page directory
 * p_addr is the physic address of the page
 */
void		ia32_paging_pd_init(t_pd_entry *p_addr)
{
  t_uint32	ind = 0;
  t_uint32	entry_nb = IA32_PAGING_PAGE_SIZE
			    / IA32_PAGING_PDE_SIZE;


  *p_addr = UNSET_PAGE_FREE(*p_addr);

  for (; ind < entry_nb; ++ind, ++p_addr)
    *p_addr = UNSET_PAGE_PRESENT(*p_addr);

}

/*
 * Fill the page directory entry for an allocation
 */
t_error		ia32_paging_pde_alloc(t_pd_entry* pd_paddr,
				      t_vaddr vaddr,
				      t_paddr paddr,
				      t_flags flags)
{
  t_pd_entry	*pde_addr = 0;
  t_paddr	*pt_addr = 0;

  assert(FALSE == GET_PAGE_FREE_STATUS(*pt_paddr));

  pde_addr = pd_paddr + GET_PDE_INDEX(vaddr);

  if (FALSE == GET_PAGE_PRESENT_STATUS(*pde_addr))
    {
      if (ERR_PAGE_ALLOC ==
	  (pt_addr = ((t_paddr*)ia32_paging_table_alloc ())))
	return ERR_PAGE_NB_MAX_REACHED;
      ia32_paging_pt_init(pt_addr);
      *pde_addr = ((t_uint32)pt_addr & 0xFFFFF000)
		| (*pt_addr & 0xE00);
      *pde_addr |= (flags & 0x01FF);
      *pde_addr = SET_PAGE_PRESENT(*pde_addr);
    }
  else
    pt_addr = (t_paddr*)(*pde_addr & 0xFFFFF000);

  return ia32_paging_pte_alloc((t_pt_entry *) pt_addr, vaddr, paddr, flags);
}

/*
 * Free a physic page
 */
t_error		ia32_paging_pde_free(t_pd_entry* pd_paddr,
				     t_vaddr     vaddr)
{
  t_pt_entry	*pt_paddr = 0;
  t_pd_entry	*pde_paddr = pd_paddr;

  pde_paddr += GET_PDE_INDEX(vaddr);

  if (FALSE == GET_PAGE_PRESENT_STATUS(*pde_paddr))
    return ERR_PAGE_ALREADY_FREE;
  else
    pt_paddr = (t_pt_entry*)(*pde_paddr & 0xFFFFF000);

  return ia32_paging_pte_free(pt_paddr, vaddr);
}

/*
 * Debug
 */
void		ia32_paging_pd_debug(t_pd_entry *pde_paddr)
{
  t_uint32	ind = 0;
  t_pt_entry	*pt_paddr = 0;
  t_uint32	entry_nb = IA32_PAGING_PAGE_SIZE
			    / IA32_PAGING_PDE_SIZE;

  for (; ind < entry_nb; ++ind, ++pde_paddr)
    {
      if (TRUE == GET_PAGE_PRESENT_STATUS(*pde_paddr))
	{
	  pt_paddr = (t_pt_entry*)(*pde_paddr & 0xFFFFF000);
	  ia32_paging_pt_debug (pt_paddr, ind);
	}
    }
}
