/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/include/arch/ia32-virtual/kaneton/kaneton.h
 *
 * created       julien quintard   [sat dec 17 17:13:18 2005]
 * updated       Jerome Herbault   [tue feb 21 11:02:09 2006]
 */

#ifndef IA32_KANETON_KANETON_H
#define IA32_KANETON_KANETON_H	1

/*
 * ---------- defines ---------------------------------------------------------
 */

#define ___endian		ENDIAN_LITTLE
#define ___wordsz		WORDSZ_32

#define PAGESZ			4096

/*
 * ---------- includes --------------------------------------------------------
 */

#include <arch/machdep/kaneton/as.h>
#include <arch/machdep/kaneton/debug.h>
#include <arch/machdep/kaneton/init.h>
#include <arch/machdep/kaneton/region.h>
#include <arch/machdep/kaneton/segment.h>
#include <arch/machdep/kaneton/stats.h>
#include <arch/machdep/kaneton/task.h>

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../../../kaneton/arch/machdep/as.c
 *      ../../../../kaneton/arch/machdep/region.c
 *      ../../../../kaneton/arch/machdep/segment.c
 *      ../../../../kaneton/arch/machdep/task.c
 *	../../../../kaneton/arch/machdep/cons.c
 *
 */

/*
 * ../../../../kaneton/arch/machdep/as.c
 */


/*
 * ../../../../kaneton/arch/machdep/region.c
 */


/*
 * ../../../../kaneton/arch/machdep/segment.c
 */


/*
 * ../../../../kaneton/arch/machdep/task.c
 */


/*
 * ../../../../kaneton/arch/machdep/cons.c
 */

void				k_clearscreen(void);

void				k_debug_console(void);

int			k_console_print_char_simple(char	c);

void			k_console_update_attribute(u_int8_t	attr);

void			k_console_init(t_cons *p_cons);


/*
 * eop
 */

#endif
