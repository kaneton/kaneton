/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/mycure/kaneton/core/include/arch/ia32-virtual/services/services.h
 *
 * created       julien quintard   [sat dec 17 17:16:19 2005]
 * updated       julien quintard   [sat dec 17 17:16:22 2005]
 */

#ifndef IA32_SERVICES_SERVICES_H
#define IA32_SERVICES_SERVICES_H	1

/*
 * ---------- includes --------------------------------------------------------
 */

#include <arch/machdep/services/cons.h>

#endif
