/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/export_kaneton/kaneton/core/bootloader/arch/ia32-virtual/pmode.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       matthieu bucchianeri   [mon jan 30 20:22:46 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the student just has to setup the protected mode in this file,
 * nothing more.
 *
 * of course, it will be better to provide some debug functions etc..
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"


/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * ---------- functions -------------------------------------------------------
 */

