/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/bootloader/arch/ia32-virtual/bootloader.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [tue feb 21 11:44:19 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the bootloader is to install a correct environment for
 * the kernel.
 *
 * the first thing to do is to relocate the different kaneton data structure
 * in order to build the t_init structure. this structure must contain
 * everything the kernel will need.
 *
 * for more information on the relocating, take a look to the kaneton
 * paper which describes the entire kaneton reference.
 *
 * once the init structure was built, the kernel has to be launched.
 *
 * nevertheless, the kernel needs to evolve with the protected mode and
 * paging mode activated, so the bootloader first has to install these.
 *
 * printing some messages is interesting showing the protected mode and
 * paging mode are correctly installed.
 *
 * after all, the bootloader has launch the kernel binary.
 *
 * look at the ld scripts to know where the kernel has to be loaded.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*		init;

/*
 * these three variable are globals to avoid them to be lost when the
 * bootloader changes its stack.
 *
 * indeed, before jumping on the kernel a new stack is created so the local
 * variables will no longer be accessible. putting these variables in
 * globals bypass this problem.
 */

typedef void (*t_kernel_jump) (t_init*) ;
void			(*kernel)(t_init*);


t_reg32			ebp;
t_reg32			esp;

/*
 * ---------- functions -------------------------------------------------------
 */

/* ***************** STUDENT CODE START HERE ** (herbau_j) ******************/


int			bootloader(t_uint32			magic,
				   multiboot_info_t*		mbi)
{
  bl_init_init(mbi);
  bl_console_init();
  bl_debug_print_init();
  bl_debug_print_module();
  printf("===| Console Initialised |===\n");
  /*
   * Reconfiguration du mode prot�g�.
   */
  d_gdtr *p_gdtr = &(init->machdep.gdtr);
  ia32_gdt_init(init->machdep.gdt, p_gdtr);
  ia32_gdt_build_ia32_virtual(p_gdtr);
  // ia32_debug_gdt_print();
  // ia32_is_pmode();
  ia32_enter_pmode(p_gdtr);
  ia32_pmode_update_segments(1, 2);
  //_debug_multiboot_info(mbi);


  /*
   * Configuration des interruptions
   */
  d_idtr *p_idtr = &(init->machdep.idtr);
  ia32_idt_init(init->machdep.idt, p_idtr);
  //ia32_debug_idt_print(p_idtr);



  /*
   * Pre-gestion  des Interuptions (Optionel)
   */

  // copy du bootloader (Optionel)
  // address du grub : 0x200000

  /*
   * Construction des tableaux d�crivant les segments et les regions
   */

  if ((init->nsegments = install_segment_form_init()) != INIT_SEGMENTS)
    printf(COLOR(RED)"ERROR : "COLOR(WHITE)" %i segments instead of %i\n",
	   init->nsegments, INIT_SEGMENTS);
  if ((init->nregions = install_region_from_init()) != INIT_REGIONS)
    printf(COLOR(RED)"ERROR : "COLOR(WHITE)" %i regions instead of %i\n",
	   init->nregions, INIT_SEGMENTS);

  /*
   * Configuration et passage en mode Pagin�
   */

  // Construire PD et les PTs
  bl_paging_init((t_paddr*)(init->machdep.paging), init->machdep.pagingsz);
  printf(COLOR(GREEN)"Trying virtual mode\n"COLOR(WHITE));
  // Passer en mode Pagin�
  bl_paging_activate();

  /*
   * Preparation au passage au kernel
   */

  // initialiser kalloc.
  // initialiser kstack.
  kernel = (t_kernel_jump) *((int *)(init->kcode + 0x18));
  printf("Kernel addr : 0x%x\n", kernel);

  asm("movl %0, %%eax\n\t"
      "movl %%eax, %%esp\n\t"
      "movl %%eax, %%ebp\n\t"

      //"movl  $8, %%eax\n\t"
      //"pushl %%eax\n\t"
      //"pushl %1\n\t"
      //"lret\n\t"
      :
      : "g"(init->kstack + init->kstacksz - 4), "g" (kernel)
      : "%eax"
      );
  // copy de la stack du bootloader (Optionel,  Utile ???)
  // appel du kernel.
  // void                    (*kernel)(t_init*);
  kernel(init);

  printf(COLOR(RED)"Returned from hell\n"COLOR(WHITE));

  while(1);

  return (0);
}

int			_debug_multiboot_info(multiboot_info_t*		mbi)
{
  printf("===| Multiboot Information |===\n");
  printf("flags\t\t: O%b\n", mbi->flags);
  if((mbi->flags & 0x1) == 0x1)
    {
      printf("mem_lower \t: 0x%x\n", mbi->mem_lower);
      printf("mem_upper \t: 0x%x\n", mbi->mem_upper);
    }
  if((mbi->flags & 0x2) == 0x2)
    printf("boot_device \t: 0x%x\n", mbi->boot_device);
  if((mbi->flags & 0x4) == 0x4)
    printf("cmdline \t: 0x%x(%s)\n", mbi->cmdline, (mbi->cmdline));
  if((mbi->flags & 0x8) == 0x8)
    {
      printf("mod_count \t: 0x%x\n", mbi->mods_count);
      printf("mod_addr \t: 0x%x\n", mbi->mods_addr);

      int i;
      for(i = 0; i != mbi->mods_count; i++)
	{
	  module_t *mod = (module_t *)(mbi->mods_addr + i * sizeof (module_t));
	  printf("******(0x%x)\n", mod);
	  printf("**mod_start : %x\n", mod->mod_start);
	  printf("**mod_end : %x\n", mod->mod_end);
	  printf("**string : %s\n", mod->string);
	  printf("**reserved : %x\n", mod->reserved);
	}
    }
  if((mbi->flags & 0x40) == 0x40)
    {
      printf("mmap_length  \t: Ox%x\n", mbi->mmap_length);
      printf("mmap_addr  \t: Ox%x\n", mbi->mmap_addr);
    }
/*   printf("drives_length \t: Ox%x\n", mbi->drives_length); */
/*   printf("drives_addr \t: Ox%x\n", mbi->drives_addr); */
/*   printf("config_table \t: Ox%x\n", mbi->config_table); */
/*   printf("boot_loader_name: Ox%x\n", mbi->boot_loader_name); */
/*   printf("apm_table \t: Ox%x\n", mbi->apm_table); */
/*   printf("vbe_control_info: Ox%x\n", mbi->vbe_control_info); */
/*   printf("vbe_mode_info \t: Ox%x\n", mbi->vbe_mode_info); */
  return 0;
}

/* ***************** STUDENT CODE STOP HERE ** (herbau_j) ******************/
