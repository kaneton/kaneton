/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [tue feb 21 12:10:41 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <kaneton_ascii.h>
/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

static void			_debug_print_bootloader_init(t_init *init)
{
  printf("===| Debug : Printing Init |===\n");

  printf(COLOR(GREEN)"mem :"COLOR(WHITE)"\t\t0x%p\t\t", init->mem);
  printf(COLOR(GREEN)"memsz :"COLOR(WHITE)"\t\t%dMo\n", init->memsz / 0x100000);

  printf(COLOR(GREEN)"init :"COLOR(WHITE)"\t\t0x%x\t", init->init);
  printf(COLOR(GREEN)"initsz :"COLOR(WHITE)"\t0x%x\n", init->initsz);

  printf(COLOR(GREEN)"kcode :"COLOR(WHITE)"\t\t0x%x\t", init->kcode);
  printf(COLOR(GREEN)"kcodesz :"COLOR(WHITE)"\t0x%x\n", init->kcodesz);

  printf(COLOR(GREEN)"modules :"COLOR(WHITE)"\t0x%x\t", init->modules);
  printf(COLOR(GREEN)"modulessz :"COLOR(WHITE)"\t0x%x\n", init->modulessz);

  printf(COLOR(GREEN)"segments :"COLOR(WHITE)"\t0x%x\t", init->segments);
  printf(COLOR(GREEN)"segmentssz :"COLOR(WHITE)"\t0x%x\t", init->segmentssz);
  printf(COLOR(GREEN)"nsegments :"COLOR(WHITE)"\t%d\n", init->nsegments);

  printf(COLOR(GREEN)"regions :"COLOR(WHITE)"\t0x%x\t", init->regions);
  printf(COLOR(GREEN)"regionssz :"COLOR(WHITE)"\t0x%x\t", init->regionssz);
  printf(COLOR(GREEN)"nregions :"COLOR(WHITE)"\t%d\n", init->nregions);

  printf(COLOR(GREEN)"kstack :"COLOR(WHITE)"\t0x%x\t", init->kstack);
  printf(COLOR(GREEN)"kstacksz :"COLOR(WHITE)"\t0x%x\n", init->kstacksz);

  printf(COLOR(GREEN)"alloc :"COLOR(WHITE)"\t\t0x%x\t", init->alloc);
  printf(COLOR(GREEN)"allocsz :"COLOR(WHITE)"\t0x%x\n", init->allocsz);

  printf(COLOR(GREEN)"gdt :"COLOR(WHITE)"\t\t0x%x\t", init->machdep.gdt);
}

void			kaneton(t_init*	bootloader)
{
  int i;
  long j = 13;

  k_console_init(&(bootloader->machdep.cons));
  printf(COLOR(CYAN)"LAUNCH KERNEL SUCCESSFULL\n"COLOR(WHITE));

  _debug_print_bootloader_init(bootloader);

  printf(KANETON);
 /*  while (1) */
/*     { */
/*       for (i = 0; i < 1000000; i++, j = j * j) */
/* 	; */
/*       k_clearscreen(); */
/*       printf(KANETON); */
/*       for (i = 0; i < 1000000; i++, j = j * j) */
/* 	; */
/*       k_clearscreen(); */
/*       printf(KANETON2); */
/*     } */

  while (1);
}



