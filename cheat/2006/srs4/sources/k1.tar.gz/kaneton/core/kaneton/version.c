#include <klibc.h>
#include <kaneton.h>

const char version[] = "kaneton-0.0.1   Sun Feb 19 19:08:14 CET 2006 tempus@";
