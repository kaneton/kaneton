/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/arch/ia32-virtual/cons.c
 *
 * created       julien quintard   [sat may 28 18:23:13 2005]
 * updated       Jerome Herbault   [tue feb 21 11:28:17 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the student has to fill in this file just to be able to print some
 * debug messages.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

/*
 * the console variable.
 */

/* ***************** STUDENT CODE START HERE ** (herbau_j) ******************/
static t_cons		*cons;
/* ***************** STUDENT CODE STOP  HERE ** (herbau_j) ******************/

/*
 * ---------- functions -------------------------------------------------------
 */

/* ***************** STUDENT CODE START HERE ** (herbau_j) ******************/

/*
 * Private : clear console screen
 */
static void			_console_clear_sreen(void)
{
  int i;

  for(i = 0; i < CONS_SIZE; i += 2)
    {
      cons->vga[i] = ' ';
      cons->vga[i + 1] = cons->attr;
    }
}

static t_uint16		_console_compute_screen_pos(t_uint16	line,
						     t_uint16	column)
{
  return (160 * line + 2 * column);
}

static void			_console_new_line(void)
{
      if (cons->line == 24)
	{
	  memcpy(cons->vga, cons->vga + 160, CONS_SIZE - 160);
	  bzero(cons->vga + CONS_SIZE - 160, 160);
	}
      else
	cons->line++;
      cons->column = 0;
}

void				k_clearscreen(void)
{
  cons->line = 0;
  cons->column = 0;
  cons->attr = 0x07;
  cons->vga = (char *) CONS_ADDR;
  //  _console_clear_sreen();
}

void				k_debug_console(void)
{
  printf("===| Debugging Console |==\n");
  printf("line\t%d\n", cons->line);
  printf("column\t%d\n", cons->column);
  printf("attr\t%d\n", cons->attr);
  printf("vga\t%x\n", cons->vga);

}

/*
 * Public : writing one char (simple version)
 */

int			k_console_print_char_simple(char	c)
{
  t_uint16	pos = _console_compute_screen_pos(cons->line, cons->column);
  switch(c)
    {
    case('\n'):
      _console_new_line();
      return(0);
    case('\t'):
      cons->column += CONS_TAB - (cons->column % CONS_TAB);
      if (cons->column >= 80)
	_console_new_line();
      return(0);
    }
  cons->vga[pos] = c;
  cons->vga[pos + 1] = cons->attr;

  if (cons->column == 79)
    _console_new_line();
  else
    cons->column++;

  return 0;
}

/*
 * Public : updating console attribute
 */

void			k_console_update_attribute(u_int8_t	attr)
{
  cons->attr = attr;
}

/*
 * Public : initialize the console
 */

void			k_console_init(t_cons *p_cons)
{
  cons = p_cons;

  cons->line = 0;
  cons->column = 0;
  cons->attr = 0x07;
  cons->vga = (char *) CONS_ADDR;

  _console_clear_sreen();

  printf_init(k_console_print_char_simple, k_console_update_attribute);
}

/* ***************** STUDENT CODE STOP HERE ** (herbau_j) ******************/
