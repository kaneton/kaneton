_VIEWER_DVI_="xdvi"
_WHICH_="which"
_CORE_DEBUG_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/debug"
_LD_FLAGS_=""
_C_FLAGS_=""
_BOOTMODE_="floppy-image"
_CORE_SEGMENT_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/segment"
_KLIBC_A_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/klibc/klibc.a"
_USER_SH_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/users/igal.cohen-hadria/user.sh"
_IMAGE_="/Users/tempus/kaneton.img"
_PROGRAMS_DEP_=""
_CC_="/opt/local/i386-elf/bin/gcc"
_DRIVERS_DEP_=""
_CORE_ID_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/id"
_ADDRESS_=""
_VERSION_="0.0.1"
_CONSOLE_FILE_="cons-text.c"
_CORE_KANETON_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton"
_CHECK_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/check"
_KLIBC_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/klibc"
_SIGNATURE_="kaneton"
_REGION_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/region/region.lo"
_USER_MK_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/users/igal.cohen-hadria/user.mk"
_MBL_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/tools/mbl"
_CORE_AS_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/as"
_LN_="ln -s -f"
_HIDDEN_=""
_READ_="read"
_MBL_="grub"
_BOOTSTRAP_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/bootstrap/bootstrap"
_USER_CONF_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/users/igal.cohen-hadria/user.conf"
_CRT_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/crt"
_EXPORT_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/export"
_PROTO_TOOL_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/tools/proto/mkp.py"
_ENV_CONF_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/.env.conf"
_TAIL_="tail"
_MACHINES_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/machines"
_TASK_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/task/task.lo"
_MACHDEP_KANETON_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/arch/machdep"
_SCHEDULE_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/schedule/schedule.lo"
_MAKEFILE_MK_=".makefile.mk"
_LD_="/opt/local/i386-elf/bin/ld"
_REGION_FILE_="region-fit.c"
_TITLE_="kaneton"
_MACHDEP_LDS_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/tools/ld/arch/machdep"
_DATE_="date"
_CORE_STATS_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/stats"
_MAKE_FLAGS_=""
_USER_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/users/igal.cohen-hadria"
_MODULES_="core/bootloader/bootloader core/kaneton/kaneton env/.kaneton.conf"
_KANETON_CONF_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/.kaneton.conf"
_CHECK_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/check/check.lo"
_TFTP_DIRECTORY_=""
_CORE_DEP_="bootloader kaneton"
_MDEVICE_="a:"
_CORE_INCLUDE_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/include"
_USER_="igal.cohen-hadria"
_ENV_SH_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/.env.sh"
_MACHINE_SH_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/machines/macos-i386/machine.sh"
_MACHINE_MK_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/machines/macos-i386/machine.mk"
_TOUCH_="touch"
_RM_="rm -f"
_CORE_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core"
_SRC_DEP_="core env"
_USER_MODULES_CONF_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/users/igal.cohen-hadria/modules.conf"
_PURGE_="rm -f *~ .*~ #* .#*"
_UDEVICE_="/dev/fd0"
_PROTO_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/tools/proto"
_FORMAT_="pdf"
_SET_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/set/set.lo"
_SED_="gnused -r"
_VIEWER_PDF_="xpdf"
_VERBOSE_=""
_KANETON_FLAGS_=""
_MACHDEP_INCLUDE_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/include/arch/machdep"
_AR_="/opt/local/i386-elf/bin/ar cq"
_CORE_REGION_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/region"
_CORE_SCHEDULE_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/schedule"
_PWD_="pwd"
_MKDIR_="mkdir"
_CMODE_TEX_=".cmode.tex"
_MACHINE_CONF_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/machines/macos-i386/machine.conf"
_CRT_A_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/crt/crt.a"
_SRC_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton"
_THREAD_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/thread/thread.lo"
_LDS_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/tools/ld"
_CORE_BOOTSTRAP_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/bootstrap"
_MAKE_="gmake"
_KLIBC_INCLUDE_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/klibc/include"
_BOOTLOADER_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/bootloader/bootloader"
_CORE_CONF_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/conf"
_CORE_TASK_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/task"
_VIEWER_PS_="gv"
_CORE_BOOTLOADER_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/bootloader"
_WC_="wc"
_DEBUG_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/debug/debug.lo"
_LIBS_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs"
_LDFLAGS_="-nostdinc -nostdlib -I/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/include -I/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/klibc/include -I/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/libia32/include "
_LS_="ls"
_FIND_="find"
_MACHDEP_BOOTSTRAP_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/bootstrap/arch/machdep"
_SERVICES_DEP_=""
_MACHINE_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/machines/macos-i386"
_PDFLATEX_="pdflatex"
_MAKEFLAGS_=""
_MTOOLS_="mtools"
_ID_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/id/id.lo"
_CPP_FLAGS_=""
_GREP_="grep"
_NASM_="nasm"
_KANETON_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/kaneton"
_MACHDEP_BOOTLOADER_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/bootloader/arch/machdep"
_MCOPY_="mcopy"
_MACHDEP_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/arch/machdep/machdep.lo"
_AS_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/as/as.lo"
_ARCHITECTURE_="ia32-virtual"
_CPPFLAGS_=""
_INCLUDES_="-I/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/include -I/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/klibc/include -I/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/libia32/include"
_SEGMENT_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/segment/segment.lo"
_SHELL_="/bin/bash"
_VIEW_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/view"
_CFLAGS_="-D___kaneton -nostdinc -nostdlib -fno-builtin -O0 -I/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/include -I/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/klibc/include -I/Users/tempus/Documents/compil/kaneton-epita/kaneton/libs/libia32/include -Wimplicit -Wparentheses -Wreturn-type -Wswitch -Wswitch-enum -Wunused-function -Wunused-variable -Wmissing-prototypes -Wmissing-declarations  "
_ENV_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env"
_USER_KANETON_CONF_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/users/igal.cohen-hadria/kaneton.conf"
_DISPLAY_="color"
_CD_="cd"
_CORE_SET_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/set"
_ECHO_="echo"
_EXPORT_SCRIPT_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/export/export.sh"
_CP_="cp"
_MV_="mv"
_RANLIB_="/opt/local/i386-elf/bin/ranlib"
_VIEW_SCRIPT_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/view/view.sh"
_ENV_MK_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/.env.mk"
_MACHINE_="macos-i386"
_TFTP_ADDRESS_=""
_TOOLS_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/tools"
_CORE_THREAD_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/thread"
_PDFVIEWER_="xpdf"
_MKTEMP_="mktemp /tmp/kanetonXXX"
_STATS_LO_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/core/kaneton/stats/stats.lo"
_CPP_="/opt/local/bin/cpp-dp-4.1"
_CAT_="cat"
_EXPORT_=""
_SEGMENT_FILE_="segment-fit.c"
_TAR_="tar"
_USERS_DIR_="/Users/tempus/Documents/compil/kaneton-epita/kaneton/env/users"
#!/bin/bash
## licence       kaneton licence
##
## project
##
## file          /home/buckman/kaneton/kaneton/env/machines/unix/machine.sh
##
## created       julien quintard   [fri feb 11 02:08:31 2005]
## updated       matthieu bucchianeri   [sun dec 18 15:54:37 2005]
##

#
# ---------- information ------------------------------------------------------
#
# this file is composed of functions needed by the kaneton shell scripts.
#

#
# ---------- functions --------------------------------------------------------
#

#
# PRINT
#
# prints a message using the user variable _DISPLAY_.
#
# ${1}:		color
# ${2}:		text
# ${3}:		options
#
print()
{
  local color
  local text
  local options

  color="${1}"
  text="${2}"
  for opt in ${3}; do
      case "${opt}" in
	  "--no-newline")
	      options="${options} -n"
	      ;;
	  "--flickering")
	      text="\E[5m${text}\033[0m"
	      ;;
	  *)
	      ;;
      esac
  done

  if [ "${_DISPLAY_}" = "color" ] ; then
    case "$color" in
      "red")
        ${_ECHO_} -e ${options} '\E[;31m'"\033[1m${text}\033[0m"
        ;;

      "green")
        ${_ECHO_} -e ${options} '\E[;32m'"\033[1m${text}\033[0m"
        ;;

      "yellow")
        ${_ECHO_} -e ${options} '\E[;33m'"\033[1m${text}\033[0m"
        ;;

      "blue")
        ${_ECHO_} -e ${options} '\E[;34m'"\033[1m${text}\033[0m"
        ;;

      "white")
        ${_ECHO_} -e ${options} '\E[;37m'"\033[1m${text}\033[0m"
        ;;

      *)
        ${_ECHO_} -e ${options} "${text}"
        ;;
    esac
  else
    ${_ECHO_} -e ${options} "${text}"
  fi
}



#
# CONTENTS
#
# gets the contents of a file.
#
# ${1}:         file
# ${2}:		options
#
contents()
{
  local file

  file="${1}"
  for opt in ${2}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_CAT_} ${file}
}



#
# TEMPFILE
#
# gives an unique temporary file name.
#
# ${1}:		options
#
tempfile()
{
  for opt in ${1}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_MKTEMP_}
}



#
# WORKING-DIRECTORY
#
# prints working directory
#
# ${1}:		options
#
working-directory()
{
  for opt in ${1}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_PWD_}
}



#
# LOCATE-PROG
#
# locates a program on the system.
#
# ${1}:         program
# ${2}:		options
#
locate-prog()
{
  local program

  program=${1}
  for opt in ${2}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_WHICH_} ${program}
}



#
# SUBSTITUTE
#
# substitute matches with another one (like sed 's').
#
# ${1}:		to substitute
# ${2}:		substitute string
# ${3}:		options
#
substitute()
{
  local old
  local new

  old="${1}"
  new="${2}"

  case "${3}" in
      "all")
	  opt="g"
	  ;;
      "[1-9]+")
	  opt="${3}"
	  ;;
      *)
	  opt=""
	  ;;
  esac

  ${_SED_} "s/${old}/${new}/${opt}"
}



#
# DISPLAY
#
# displays a message with a header.
#
# ${1}:		message
# ${2}:		header
#
display()
{
  local message
  local header

  message="${1}"
  header="${2}"

  case "${header}" in
    "+")
      print "blue" "[" "--no-newline"
      print "green" "+" "--no-newline"
      print "blue" "]" "--no-newline"
      ;;

    "!")
      print "blue" "[" "--no-newline"
      print "red" "!" "--no-newline"
      print "blue" "]" "--no-newline"
      ;;

    "?")
      print "blue" "[" "--no-newline"
      print "yellow" "?" "--no-newline --flickering"
      print "blue" "]" "--no-newline"
      ;;

    *)
      ;;
  esac

  print "white" "${message}" ""
}



#
# WAIT KEY
#
# this function just waits for a key.
#
# ${1}:		options
#
wait-key()
{
  local needless

  for opt in ${1}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_READ_} needless
}



#
# LAUNCH
#
# this function just launches a new program, script etc..
#
# ${1}:		file
# ${2}:		arguments
# ${3}:		options
#
launch()
{
  local file
  local arguments
  local options

  file="${1}"
  arguments="${2}"
  options="${3}"

  ${_SHELL_} ${options} ${file} ${arguments}
}



#
# MAKEFILE
#
# launches a makefile.
#
# ${1}:		options
#
makefile()
{
  local options

  options="${1}"

  ${_MAKE_} ${_MAKEFLAGS_} ${options}
}



#
# COPY
#
# this function copies a file.
#
# ${1}:		source file
# ${2}:		destination file
# ${3}:		options
#
copy()
{
  local source
  local destination

  source="${1}"
  destination="${2}"
  for opt in ${3}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_CP_} ${source} ${destination}
}



#
# LINK
#
# this function performs a link between two files.
#
# ${1}:		source file
# ${2}:		destination file
# ${3}:		options
#
link()
{
  local source
  local destination

  source="${1}"
  destination="${2}"
  for opt in ${3}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_LN_} ${destination} ${source}
}



#
# REMOVE
#
# this function just removes a file.
#
# ${1}:		files
# ${2}:		options
#
remove()
{
  local files
  local options

  local f

  files="${1}"
  options="${2}"
  for opt in ${2}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  for f in ${files} ; do
    if [ -d ${f} ] ; then
      ${_RM_} ${options} -Rf ${f}
    else
      ${_RM_} ${options} -f ${f}
    fi
  done
}



#
# LIST
#
# this function returns the list of the directory entries.
#
# ${1}:		directory
# ${2}:		options
#
list()
{
  local directory

  directory="${1}"
  for opt in ${2}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_LS_} ${directory}
}



#
# CHANGE DIRECTORY
#
# this function just changes the current working directory.
#
# ${1}:		directory
# ${2}:		options
#
change-directory()
{
  local directory

  directory="${1}"
  for opt in ${2}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_CD_} ${directory}
}



#
# LOCATE
#
# this function tries to locate an element in an array.
#
# ${1}:		the array
# ${2}:		the element looked for
# ${3}:		options
#
locate()
{
  array="${1}"
  element="${2}"
  for opt in ${3}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  for e in ${array} ; do
    ${_ECHO_} ${e} | ${_GREP_} ${element} 2>/dev/null 1>/dev/null

    if [ ${?} -eq 0 ] ; then
      ${_ECHO_} ${e}
      return 0
    fi
  done

  return -1
}



#
# PREPROCESS
#
# this function preprocess a file
#
# ${1}:		file to process
# ${2}:		additional include
# ${3}:		tag start
# ${4}:		tag end
# ${5}:		options
#
preprocess()
{
  local source
  local options
  local includes
  local tags
  local tage

  source="${1}"
  tags="${3}"
  tage="${4}"
  for opt in ${5}; do
      case "${opt}" in
	  "--no-markers")
	      options="${options} -P"
	      ;;
	  *)
	      ;;
      esac
  done

  for inc in ${2}; do
      includes="${includes} -include ${inc}"
  done

  ${_CPP_} ${_INCLUDES_} ${options} ${includes} ${source} |		\
    ${_SED_} -n "/^${tags}$/,/^${tage}$/p" |				\
    ${_SED_} '/^!.*$/d'

}



#
# FIND-FILES
#
# find files given a pattern
#
# ${1}:		place to search for
# ${2}:		files to match
# ${3}:		options
#
find-files()
{
  local source
  local pattern
  local options

  source="${1}"
  pattern="${2}"
  for opt in ${3}; do
      case "${opt}" in
	  "--file")
	      options="${options} -type f"
	      ;;
	  *)
	      ;;
      esac
  done

  ${_FIND_} ${source} -name "${pattern}" ${options}
}



#
# TAGS CLEAN
#
# this function removes tags from the source code files.
#
# ${1}:		files
#
tags-clean()
{
  local files
  local temp
  local f

  files="${1}"

  temp=$(tempfile)

  for f in ${files} ; do
    ${_CAT_} ${f} | ${_SED_} "/^.*\[cut\].*$/ d" > ${temp}
    ${_CP_} ${temp} ${f}
  done
}



#
# PACK
#
# this function creates a package from a source directory.
#
# ${1}:		directory
# ${2}:		destination file
#
pack()
{
  local directory
  local file

  directory="${1}"
  file="${2}"

  ${_TAR_} -czf ${file} ${directory}
}



#
# UNPACK
#
# this function unpackages a file.
#
# ${1}:		directory
# ${2}:		destination file
#
unpack()
{
  local directory
  local file

  directory="${1}"
  file="${2}"

  if [ -n ${directory} ] ; then
    ${_TAR_} -xzf ${file} -C ${directory}
  else
    ${_TAR_} -xzf ${file}
  fi
}



#
# MAKE DIRECTORY
#
# this function creates a directory.
#
# ${1}:		directory
#
make-directory()
{
  local directory

  directory="${1}"

  ${_MKDIR_} ${directory}
}



#
# DEVICE-COPY
#
# copies a file on a device (normally a floppy).
#
# ${1}:		source file
# ${2}:		destination device or image
# ${3}:		destination path
# ${4}:		options
#
device-copy()
{
  local source
  local device
  local dest

  source="${1}"
  device="${2}"
  dest="${3}"

  case "${4}" in
      "--image")
	  ${_MCOPY_} -o -n -i ${device} ${source} ::/${dest}
	  ;;
      *)
	  ${_MCOPY_} -o -n ${source} ${device}/${dest}
	  ;;
  esac
}



#
# FORMAT-DATE
#
# this function return current date formatted
#
# ${1}:		format
# ${2}:		options
#
format-date()
{
  local format

  format="${1}"
  for opt in ${2}; do
      case "${opt}" in
	  *)
	      ;;
      esac
  done

  ${_DATE_} +${format}
}



#
# CUT-CODE
#
# cut code for exporting.
#
# ${1}:		stage
#
cut-code()
{
  local stage

  stage="${1}"
  ${_SED_} -e "/^.*\[cut\].*${stage}.*$/,/^.*\[cut\].*\/${stage}.*$/ \
                      { /^.*\[cut\].*${stage}.*$/ !d }"
}



#
# SVN CLEAN
#
# this function cleans the svn contol directories.
#
# ${1}:		directory
#
svn-clean()
{
  ${_RM_} -Rf `${_FIND_} ./ -type d -name .svn`
}
#!/bin/sh
## licence       kaneton licence
##
## project       kaneton
##
## file          /home/buckman/kaneton/env/users/matthieu.bucchianeri/user.sh
##
## created       matthieu bucchianeri   [tue dec 13 21:02:30 2005]
## updated       matthieu bucchianeri   [mon jan 23 20:10:30 2006]
##

#
# ---------- information ------------------------------------------------------
#
# this file contains specific user shell variables, functions etc..
#

#
# VIEW
#
# this function opens and displays a document.
#
view()
{
  document=$1

  xpdf $document
}
