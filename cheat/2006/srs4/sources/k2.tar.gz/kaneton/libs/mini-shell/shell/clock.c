/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/mini-shell/shell/clock.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [sun mar 26 07:14:19 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <mini-shell.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

char		*ms_str_dayofweek[7] =
  {
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  };

char		*ms_str_month[12] =
  {
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  };

static inline t_uint8		_read_cmos(t_uint8	reg)
{
  t_uint8	high, low;

   outb(0x70, reg);
   high = low = inb(0x71);
   // convert from BCD to binary
   high >>= 4;
   high &= 0x0f;
   low &= 0x0f;
   return 10 * high + low;
}

t_time				ms_gettime(void)
{
  t_time	time;

  // Wait
  outb(0x70, 11);
  while (inb(0x71) & 128);

  time.sec = _read_cmos(0);
  time.min = _read_cmos(2);
  time.hour = _read_cmos(4);
  return time;
}

t_date				ms_getdate(void)
{
  t_date	date;

  // Wait
  outb(0x70, 11);
  while (inb(0x71) & 128);

  date.dayofweek = _read_cmos(6);
  date.day = _read_cmos(7);
  date.month = _read_cmos(8);
  date.year = _read_cmos(9);
  if (date.year >= 70)
  {
    date.year += 1900;
  }
  else
  {
    date.year += 2000;
    //    printf("dayofweek: %d\n", date.dayofweek);
    //   date.dayofweek = ((date.dayofweek - 3) % 7) + 1;
    //   printf("dayofweek: %d\n", date.dayofweek);
      }
  return date;
}

