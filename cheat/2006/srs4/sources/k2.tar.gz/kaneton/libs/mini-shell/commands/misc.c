/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/mini-shell/commands/misc.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [sun mar 26 07:11:58 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <mini-shell.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

t_uint16		ms_cmd_now(int			argc)
{
  t_time	time = ms_gettime();
  t_date	date = ms_getdate();

  printf("%s, %s %d %d %d:%d:%d.\n",
	 ms_str_dayofweek[date.dayofweek],
	 ms_str_month[date.month - 1],
	 date.day, date.year,
	 time.hour, time.min, time.sec);

  return 0;
}

t_uint16		ms_cmd_loadkeys(int		argc,
					char		*map_str)
{
  t_error	err;

  if (argc != 1)
    {
      printf("loadkeys: Usage: loadkeys keymap.\n");
      return ERROR_INVALID_ARGS;
    }
 err = k_loadkeys(map_str);
  if (err == ERROR_NONE)
    printf("Keymap \"%s\" succefully loaded.\n", map_str);
  else if (err == ERROR_KEYB_INVALID_MAP)
    printf("loadkey: unknown keymap \"%s\"\n", map_str);
  return err;
}
