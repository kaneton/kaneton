/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/mini-shell/shell/readline.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [wed mar 22 03:40:58 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <mini-shell.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */


void		ms_shell_readline(char *line)
{
  t_bool	end = FALSE;
  t_uint16	line_pos = 0;
  t_uint16	last_pos = 0;
  char		curr_char;

  memset(line, '\0', MS_MAX_LINE_SIZE);

  while (!end)
    {

      k_console_fseek(- last_pos);
      printf("%s", line);
      last_pos = line_pos;
      // getting one char
      curr_char = k_getchar();

      if (curr_char == '')
	{
	  curr_char = k_getchar();
	  curr_char = k_getchar();
	  // | do something interesting with it
	}
      else if (curr_char != '\0')
	{
	  switch(curr_char)
	    {
	    case '\n':
	      end = TRUE;
	      break;
	    case '\t':
	    case '\b':
	      if (line_pos == 0)
		break;
	      line_pos--;
	      line[line_pos] = '\0';
	      k_console_fseek(-1);
	      printf(" ");
	      break;
	    default:
	      if (line_pos < MS_MAX_LINE_SIZE - 1)
		line[line_pos++] = curr_char;
	      break;
	    }
	}
    }
  printf("\n");
}
