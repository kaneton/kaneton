/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/mini-shell/include/shell/clock.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat mar 25 06:43:02 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef MINI_SHElL_CLOCK_H
#define MINI_SHELL_CLOCK_H	1

/*
 * ---------- definitions -----------------------------------------------------
 */

char		*ms_str_dayofweek[7];
char		*ms_str_month[12];

typedef struct
{
  t_uint8	sec;
  t_uint8	min;
  t_uint8	hour;
} t_time;

typedef struct
{
  t_uint8	dayofweek;
  t_uint8	day;
  t_uint8	month;
  t_uint16	year;
} t_date;

#endif


