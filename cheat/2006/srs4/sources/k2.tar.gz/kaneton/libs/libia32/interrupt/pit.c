/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/interrupt/pit.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [mon mar 20 14:28:48 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage pic see pic.h for more informations.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will use this file to place functions they wrote to manage
 * the pic. students may write as many functions as they whant without
 * any restrictions.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libia32.h>


/*
 * ---------- d�finitions statiques -------------------------------------------
 */

static t_uint64		_ticks;

/*
 * ---------- functions -------------------------------------------------------
 */

static t_bool	_set_timer(t_uint32	frequency)
{
  t_uint32	internal_frequency;

  if (frequency == 0)
    return FALSE;

  internal_frequency = IA32_PIT_BASE_FREQUENCY / frequency;

  //debug here

  if (internal_frequency > 65536 || internal_frequency == 0)
    return FALSE;

  if (internal_frequency == 65536)
    internal_frequency = 0;

  //initialisation du MODE CONTROL REGISTER
  outb(IA32_PIT_CONTROL_BUS, IA32_PIT_MCB);

  //Envois les bits de poids faible (LSB)
  outb(IA32_PIT_TIMER0_BUS, internal_frequency & 0xff);
  //Envois les bits de poids fort (MSB)
  outb(IA32_PIT_TIMER0_BUS, (internal_frequency >> 8) & 0xff);
  return TRUE;
}

t_bool		ia32_pit_init(t_uint32	frequency)
{
  _ticks = 0;
  if (!_set_timer(frequency))
    return FALSE;
  ia32_pic_enable(0);
  return TRUE;
}

t_uint64	ia32_pit_get_ticks(void)
{
  return	_ticks;
}

void		ia32_timer_isr(void)
{
  // ToDO : penser � realiser une gestion de compteurs pour gerer l'heure
  //        ainsi que d'autres timers
  _ticks += 1;
  //  if (_ticks % 20 == 0)
  // printf("irq 0 catched : ticks %d\n", _ticks / 20);
}
