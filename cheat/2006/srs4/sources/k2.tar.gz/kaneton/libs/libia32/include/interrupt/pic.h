/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/include/interrupt/pic.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat mar  4 12:10:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef IA32_IA32_PIC_H
#define IA32_IA32_PIC_H	1

/*
 * ---------- definitions -----------------------------------------------------
 */

/*
 *  ICW1  (Initialization Command Word 1) ==> 20h (a0h)
 *
 *  |7|6|5|4|3|2|1|0|
 *   | | | | | | | |
 *   | | | | | | | -- 1=Besoin de ICW4
 *   | | | | | | ---- 1=un seul pic, 0=deux en cascade
 *   | | | | | ------ 1=vecteur de 4 bytes, 0=8 bytes
 *   | | | | -------- 1="level trigger", 0="edge trig."
 *   | | | ---------- toujours 1 pour ICW1
 *   ---------------- toujours 0 pour les PC
 *
 *  |0|0|0|1|0|0|0|1|  => 11h
 *
 */

#define IA32_PIC_ICW1		0x11

/*
 *  ICW2  (Initialization Command Word 2) ==> 21h (a1h)
 *
 *  |7|6|5|4|3|2|1|0|
 *   | | | | | | | |
 *   | | | | | ------ toujours 0 pour les PC
 *   | | | | |		        (offset du vecteur d'interuption, irq)
 *   ---------------- bits 7 � 3 du vecteur d'interruption
 *
 *  |0|0|1|0|0|0|0|0|  => 20h (master)
 *  |0|0|1|0|1|0|0|0|  => 28h (salve)
 *
 */

#define IA32_PIC_ICW2_MASTER	0x20
#define IA32_PIC_ICW2_SLAVE	0x28

/*
 *  ICW3  (Initialization Command Word 3) ==> 21h (a1h)
 *
 *  master :
 *
 *  |7|6|5|4|3|2|1|0|
 *   | | | | | | | |
 *   | | | | | ------ IRQ utilis�e par le slave
 *   ---------------- unused ( mettre � 0 )
 *
 *  |0|0|0|0|0|1|0|0|  => 04h
 *
 *
 *  slave :
 *  |7|6|5|4|3|2|1|0|
 *   | | | | | | | |
 *   | | | | | ------ IRQ utilis�e pour 'parler' au master
 *   ---------------- unused ( mettre � 0 )
 *
 *  |0|0|0|0|0|0|1|0|  => 02h
 *
 */

#define IA32_PIC_ICW3_MASTER	0x04
#define IA32_PIC_ICW3_SLAVE	0x02

/*
 *  ICW4  (Initialization Command Word 4) => 21h (a1h)
 *
 *  |7|6|5|4|3|2|1|0|
 *   | | | | | | | |
 *   | | | | | | | -- 1 pour les 80x86
 *   | | | | | | ---- 0=normal EOI, 1=auto EOI
 *   | | | | -------- 1="buffered", 0=normal
 *   | | | ---------- 1="fully nested mode", 0=normal
 *   ---------------- unused
 *
 *  |0|0|0|0|0|0|0|1|  => 01h
 *
 */

#define IA32_PIC_ICW4		0x01

/*
 *  OCW1  (Operation Control Word 1)
 *
 *  |7|6|5|4|3|2|1|0|
 *   | | | | | | | |
 *   ---------------- Interrupt Mask register (bit N � 1 pour masquer IRQ N)
 *
 */

#define IA32_PIC_OCW2_NORMAL_EOI 0x20


#define IA32_PIC_MASTER		0x20
#define IA32_PIC_SLAVE		0xa0
#define IA32_IMR_MASTER		0x21
#define IA32_IMR_SLAVE		0xa1

#endif
