/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/interrupt/io.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat mar  4 15:34:37 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * fonction d'access
 *
 */

/*
 * ---------- definitions -----------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libia32.h>


inline void	outb(t_uint16 port, t_uint8 data)
{
  asm volatile ("outb %%al, %%dx"::"d" (port), "a" (data));
}

inline void	outw(t_uint16 port, t_uint16 data)
{
  asm volatile ("outw %%ax, %%dx"::"d" (port), "a" (data));
}

inline void	outl(t_uint16 port, t_uint32 data)
{
  asm volatile ("outl %%eax, %%dx"::"d" (port), "a" (data));
}

inline t_uint8	inb(t_uint16 port)
{
  t_uint8		data;

  asm volatile ("inb %%dx, %%al" : "=a" (data) : "d" (port));
  return data;
}

inline t_uint16	inw(t_uint16 port)
{
  t_uint16		data;

  asm volatile ("inw %%dx, %%ax" : "=a" (data) : "d" (port));
  return data;
}

inline t_uint32	inl(t_uint16 port)
{
  t_uint32		data;

  asm volatile ("inl %%dx, %%eax" : "=a" (data) : "d" (port));
  return data;
}
