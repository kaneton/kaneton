/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/interrupt/idt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:47:59 2005]
 * updated       Jerome Herbault   [mon mar 20 22:00:39 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage interrupt descriptor table.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will  place  here   the  function  they  need  to  manage
 * idt. prototypes are not imposed.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

static void	_idt_edit_entry_offset(t_idt		*idt,
				       t_uint32		offset)
{
  idt->offset_0 = offset & 0xffff;
  idt->offset_16 = (offset >> 16) & 0xffff;
}

static void	_idt_edit_entry_segment(t_idt		*idt,
					t_uint16	segment)
{
  idt->seg_select = segment;
}

static void	_idt_edit_entry_flags(t_idt		*idt,
				      t_uint16		flags)
{
  idt->flags |= (flags & 0x9fff); // 1001 11..
}

static void	_idt_edit_entry_dpl(t_idt		*idt,
				    t_uint8		dpl)
{
  idt->flags |= ((dpl & 0x3) << 13) & 0x6000;
}

static void	_idt_edit_entry(t_idt			*idt,
				t_uint32		offset,
				t_uint16		segment,
				t_uint16		flags,
				t_uint8			dpl)
{
  _idt_edit_entry_offset(idt, offset);
  _idt_edit_entry_segment(idt, segment);
  _idt_edit_entry_flags(idt, flags);
  _idt_edit_entry_dpl(idt, dpl);
}

static t_uint32	_idt_get_entry_offset(t_idt		*idt)
{
  return (idt->offset_16 << 16) | idt->offset_0;
}

static t_uint16	_idt_get_entry_segment(t_idt		*idt)
{
  return idt->seg_select;
}

static t_uint16	_idt_get_entry_flags(t_idt		*idt)
{
  return idt->flags & 0x9fff;
}

static t_uint8	_idt_get_entry_dpl(t_idt		*idt)
{
  return (idt->flags >> 13) & 0x3;
}

void		ia32_idt_init(t_uint32			idt,
			      d_idtr			*idtr)
{
  idtr->base = (t_uint32) idt;
  idtr->limit = 48 * sizeof(t_idt);
  bzero((void *) idtr->base, idtr->limit);
}

t_gdt_pos	ia32_idt_edit_entry(t_gdt_pos		pos,
				    t_uint32		offset,
				    t_uint16		segment,
				    t_uint16		flags,
				    t_uint8		dpl,
				    d_idtr		*idtr)
{
  t_idt		*idt;

  if (pos >= (idtr->limit / 0x8))
    return 0;

  idt = (t_idt *) (idtr->base + ((t_uint32) pos * sizeof (t_idt)));

  _idt_edit_entry(idt, offset, segment, flags, dpl);
  return pos;
}

t_idt_pos	ia32_idt_remove_entry(t_idt_pos		pos,
				    d_idtr		*idtr)
{
  t_idt		*idt;

  if (pos >= (idtr->limit / 0x8) || pos <= 0)
    return -1;

  idt = (t_idt *) (idtr->base + ((t_uint32) pos * sizeof (t_idt)));
  return pos;
}

void		ia32_debug_idt_print(d_idtr		*idtr)
{
  int i = 0;

  for(i = 0; i < idtr->limit / 0x8; i++)
    {
      t_idt	*idt = (t_idt *) (idtr->base + (i * 0x8));
      t_uint16 flags = _idt_get_entry_flags(idt);
       char msg[2][10];

      if ((flags & 0x8000) == 0)
	continue;
      switch (_idt_get_entry_dpl(idt))
	{
	case IDT_DPL_KERN:
	  strcpy(msg[0], "KERNEL");
	  break;
	case IDT_DPL_USER:
	  strcpy(msg[0], "USER  ");
	  break;
	default:
	  strcpy(msg[0], "ERROR ");
	  break;
	}
      switch (_idt_get_entry_flags(idt))
	{
	case IDT_TASK_FLAGS:
	  strcpy(msg[1], "TASK");
	  break;
	case IDT_INTERRUPT_FLAGS:
	  strcpy(msg[1], "INTERRUPT");
	  break;
	case IDT_TRAP_FLAGS:
	  strcpy(msg[1], "TRAP");
	  break;
	default:
	  strcpy(msg[1], "ERROR");
	  break;
	}
    }
}

