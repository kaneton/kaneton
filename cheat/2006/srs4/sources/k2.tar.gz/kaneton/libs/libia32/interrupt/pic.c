/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/interrupt/pic.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [mon mar 20 16:59:23 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage pic see pic.h for more informations.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will use this file to place functions they wrote to manage
 * the pic. students may write as many functions as they whant without
 * any restrictions.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libia32.h>


/*
 * ---------- d�finitions statiques -------------------------------------------
 */

static t_uint8		_master_interrupt_mask;
static t_uint8		_slave_interrupt_mask;

/*
 * ---------- functions -------------------------------------------------------
 */

void		ia32_pic_init(void)
{
  outb(IA32_PIC_MASTER, IA32_PIC_ICW1);
  outb(IA32_PIC_SLAVE, IA32_PIC_ICW1);

  outb(IA32_IMR_MASTER, IA32_PIC_ICW2_MASTER);
  outb(IA32_IMR_SLAVE, IA32_PIC_ICW2_SLAVE);

  outb(IA32_IMR_MASTER, IA32_PIC_ICW3_MASTER);
  outb(IA32_IMR_SLAVE, IA32_PIC_ICW3_SLAVE);

  outb(IA32_IMR_MASTER, IA32_PIC_ICW4);
  outb(IA32_IMR_SLAVE, IA32_PIC_ICW4);

  // initialisation des masks d'interruption (tous les irqs sont bloqu�s)
  _master_interrupt_mask = 0xff;
  _slave_interrupt_mask = 0xff;
  outb(IA32_IMR_MASTER, _master_interrupt_mask);
  outb(IA32_IMR_SLAVE, _slave_interrupt_mask);
}

void		ia32_pic_disable(t_uint16	irq)
{
  if (irq < 8)
    {
      _master_interrupt_mask |= ~(1 << irq);
      outb(IA32_IMR_MASTER, _master_interrupt_mask);
    }
  else
    {
      _slave_interrupt_mask |= ~(1 << (irq - 8));
      outb(IA32_IMR_SLAVE, _slave_interrupt_mask);
    }
}

void		ia32_pic_enable(t_uint16	irq)
{
  if (irq < 8)
    {
      _master_interrupt_mask &= ~(1 << irq);
      outb(IA32_IMR_MASTER, _master_interrupt_mask);
    }
  else
    {
      _slave_interrupt_mask &= ~(1 << (irq - 8));
      outb(IA32_IMR_SLAVE, _slave_interrupt_mask);
    }
}

inline void	ia32_pic_activate(void)
{
  asm volatile ("sti\n");
}

inline void	ia32_pic_desactivate(void)
{
  asm volatile ("cli\n");
}
