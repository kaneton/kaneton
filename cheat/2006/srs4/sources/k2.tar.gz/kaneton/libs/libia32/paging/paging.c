/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/paging/paging.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:05 2005]
 * updated       Jerome Herbault   [sat feb 18 05:12:47 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage paging.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will have  to fill  this  file with  function related  to
 * paging mode in the cpu: enable, disabling etc.
 *
 * there are no  restrictions about these functions, but  keep in mind
 * that  page-directory management and  page-tables management  are to
 * place in pd.c and pt.c.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

// Physical address of the area which containts
// the page directory and page tables
static t_paddr		*ia32_paging_area_phys_addr = 0;

// The size of the previous area
static t_uint32		ia32_paging_area_size = 0;

/*
 * ri is the first free index of a page free
 */
static t_uint32		ri = 0;

/*
 * pd_int is the index of the current page directory
 */
static t_pd_entry	*cur_pd_paddr = 0;

/*
 * Initialisation of all the tables
 */
void		ia32_paging_init(t_paddr *paging_area_paddr,
				 t_size  paging_area_size)
{
  t_paddr	*paddr = ia32_paging_area_phys_addr;
  t_uint32	ind = 0;
  t_uint32	table_nb = ia32_paging_area_size
			    / IA32_PAGING_PAGE_SIZE;

  ia32_paging_area_phys_addr = paging_area_paddr;
  ia32_paging_area_size = paging_area_size;

  for (; ind < table_nb; ++ind, ++paddr)
    *paddr = IA32_PAGING_PAGE_FREE;

  cur_pd_paddr = (t_pd_entry*) ia32_paging_area_phys_addr;

  ri++;

  ia32_paging_pd_init (cur_pd_paddr);
}

/*
 * Alloc one physic page to one table
 */
t_error		ia32_paging_alloc_page(t_vaddr  vaddr,
				       t_paddr  paddr,
				       t_flags  flags)
{
  assert((0 == vaddr % IA32_PAGING_PAGE_SIZE));
  assert((0 == paddr % IA32_PAGING_PAGE_SIZE));

  return ia32_paging_pde_alloc(cur_pd_paddr, vaddr, paddr, flags);
}

/*
 * Alloc enough pages for a space area size
 */
t_error		ia32_paging_alloc_pages(t_vaddr  vaddr,
					t_paddr  paddr,
					t_size   size,
					t_flags  flags)
{
  t_error	errno = 0;
  t_uint32	pg_nb = 0;

  pg_nb = size / IA32_PAGING_PAGE_SIZE;
  if (0 != (size % IA32_PAGING_PAGE_SIZE))
    ++pg_nb;

  assert((0 == vaddr % IA32_PAGING_PAGE_SIZE));
  assert((0 == paddr % IA32_PAGING_PAGE_SIZE));

  printf("vaddr:%08x paddr:%08x sz:%08x pg:%08x\n",
	 vaddr, paddr, size, pg_nb);
  for (; pg_nb != 0; --pg_nb)
    {
      if (0 != (errno = ia32_paging_alloc_page(vaddr, paddr, flags)))
	break;
      vaddr += IA32_PAGING_PAGE_SIZE;
      paddr += IA32_PAGING_PAGE_SIZE;
    }
  if (0 != errno)
    printf(" =>  ERROR %i\n", errno);
  return errno;
}

/*
 * Find a free table
 */
t_paddr			*ia32_paging_table_alloc(void)
{
  t_paddr		*paddr = ia32_paging_area_phys_addr;
  t_paddr		*table_paddr = paddr;
  t_uint32		ind = ri + 1;
  t_uint32		table_nb = ia32_paging_area_size
					/ IA32_PAGING_PAGE_SIZE;

  if (ri >= table_nb)
    return ERR_PAGE_ALLOC;

  table_paddr = (t_paddr*)((char*)table_paddr + ri * IA32_PAGING_PAGE_SIZE);

  /*
   * ri is the index of the new table
   * now find the next free table for update ri
   */
  paddr = (t_paddr*)((char*)paddr + ind * IA32_PAGING_PAGE_SIZE);

  for (; ind < table_nb; ++ind)
    {
      if (TRUE == GET_PAGE_FREE_STATUS(*paddr))
	break;
      paddr = (t_paddr*)((char*)paddr + IA32_PAGING_PAGE_SIZE);
    }
  ri = ind;

  return table_paddr;
}

/*
 * Free the page of physic addr vaddr
 */
static t_error		ia32_paging_free_page(t_vaddr  vaddr)
{
  return ia32_paging_pde_free(cur_pd_paddr, vaddr);
}

/*
 * Free the pages of space area vaddr
 */
t_error			ia32_paging_free_pages(t_vaddr vaddr, t_size size)
{
  t_error		errno = 0;

  assert((0 == vaddr % IA32_PAGING_PAGE_SIZE));

  while (size > 0)
    {
      if (0 != (errno = ia32_paging_free_page(vaddr)))
	break;
      vaddr += IA32_PAGING_PAGE_SIZE / sizeof(t_vaddr);
      size -= IA32_PAGING_PAGE_SIZE;
    }
  return errno;
}


/*
 * Debug
 */
void		ia32_paging_debug(void)
{
  printf(ICOLOR(GREEN)"-== [ PAGING DEBUG ] ==-\n"COLOR(WHITE));

  ia32_paging_pd_debug(cur_pd_paddr);
}
