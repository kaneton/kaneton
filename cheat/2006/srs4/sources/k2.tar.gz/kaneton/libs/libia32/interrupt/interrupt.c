/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/interrupt/interrupt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [mon mar 20 22:11:45 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage interrupt controller.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will use this file to place functions they wrote to manage
 * the pic. students may write as many functions as they whant without
 * any restrictions.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libia32.h>

typedef struct
{
  t_uint32	interrupt_id;
  void		(* low_level_handler)(void);
}		s_idt_info;

static s_idt_info	idt_info_tab[] =
  {
    { 0, _low_level_divide_error_handler },
    { 1, _low_level_debug_handler },
    { 2, _low_level_nmi_interrupt_handler },
    { 3, _low_level_breakpoint_handler },
    { 4, _low_level_overflow_handler },
    { 5, _low_level_bound_range_exceeded_handler },
    { 6, _low_level_invalid_opcode_handler },
    { 7, _low_level_device_not_available_handler },
    { 8, _low_level_double_fault_handler },
    { 9, _low_level_coprocessor_segment_overrun_handler },
    { 10, _low_level_invalid_tss_handler },
    { 11, _low_level_segment_not_present_handler },
    { 12, _low_level_stack_segment_fault_handler },
    { 13, _low_level_general_protection_handler },
    { 14, _low_level_page_fault_handler },
    { 15, _low_level_intel_reserved_1_handler },
    { 16, _low_level_alignement_check_handler },
    { 17, _low_level_floating_point_error_handler },
    { 18, _low_level_machine_check_handler },
    { 19, _low_level_intel_reserved_2_handler },
    { 20, _low_level_intel_reserved_3_handler },
    { 21, _low_level_intel_reserved_4_handler },
    { 22, _low_level_intel_reserved_5_handler },
    { 23, _low_level_intel_reserved_6_handler },
    { 24, _low_level_intel_reserved_7_handler },
    { 25, _low_level_intel_reserved_8_handler },
    { 26, _low_level_intel_reserved_9_handler },
    { 27, _low_level_intel_reserved_10_handler },
    { 28, _low_level_intel_reserved_11_handler },
    { 29, _low_level_intel_reserved_12_handler },
    { 30, _low_level_intel_reserved_13_handler },
    { 31, _low_level_intel_reserved_14_handler },
    { 32, _low_level_irq_0_handler },
    { 33, _low_level_irq_1_handler },
    { 34, _low_level_irq_2_handler },
    { 35, _low_level_irq_3_handler },
    { 36, _low_level_irq_4_handler },
    { 37, _low_level_irq_5_handler },
    { 38, _low_level_irq_6_handler },
    { 39, _low_level_irq_7_handler },
    { 40, _low_level_irq_8_handler },
    { 41, _low_level_irq_9_handler },
    { 42, _low_level_irq_10_handler },
    { 43, _low_level_irq_11_handler },
    { 44, _low_level_irq_12_handler },
    { 45, _low_level_irq_13_handler },
    { 46, _low_level_irq_14_handler },
    { 47, _low_level_irq_15_handler }
 };

#define _SIZEOF_IDT_INFO_TABLE		48

static char		*exception_strings[] =
{
  "divide_error",
  "debug",
  "nmi_interrupt",
  "breakpoint",
  "overflow",
  "bound_range_exceeded",
  "invalid_opcode",
  "device_not_available",
  "double_fault",
  "coprocessor_segment_overrun",
  "invalid_tss",
  "segment_not_present",
  "stack_segment_fault",
  "general_protection",
  "page_fault",
  "intel_reserved_1",
  "alignement_check",
  "floating_point_error",
  "machine_check",
  "intel_reserved_2",
  "intel_reserved_3",
  "intel_reserved_4",
  "intel_reserved_5",
  "intel_reserved_6",
  "intel_reserved_7",
  "intel_reserved_8",
  "intel_reserved_9",
  "intel_reserved_10",
  "intel_reserved_11",
  "intel_reserved_12",
  "intel_reserved_13",
  "intel_reserved_14"
};

/*
 * ---------- functions -------------------------------------------------------
 */

static void	_hang_up_processor(void)
{
  while(1);
}

t_error		ia32_build_standart_idt(d_idtr			*idtr)
{
  int i, result = 0;

  for (i = 0; i < _SIZEOF_IDT_INFO_TABLE; i++)
    {
      if (ia32_idt_edit_entry(idt_info_tab[i].interrupt_id,
			      (t_uint32) idt_info_tab[i].low_level_handler,
			      0x8,
			      IDT_INTERRUPT_FLAGS,
			      IDT_DPL_KERN,
			      idtr) == idt_info_tab[i].interrupt_id)
	  result++;
    }
  if (_SIZEOF_IDT_INFO_TABLE != result)
    return ERROR_UNKNOWN;
  return ERROR_NONE;
}

void		ia32_activate_interruptions(d_idtr		*idtr)
{
  asm (" lidt (%0)			\n\t" // loading idt
       " pushfl				\n\t"
       " andl $0xffffbfff, (%%esp)	\n\t" // no nested interrupts
        " popfl				\n\t" // a �tudier plsu tard
       //       " sti				\n\t"
      //" toto: jmp toto \n\t"
       :
       : "r" (idtr));
}

void		ia32_desactivate_interruptions(void)
{
}

t_uint8		ia32_is_interruption_active(void)
{
  return 0;
}

t_cpustate	*ia32_no_error_code_exception_handler(t_uint32	int_code,
						     t_cpustate *cpu_state)
{
  printf("\n\n Exception Catched: %s (no errcode)\n", exception_strings[int_code]);
  printf("******************************\n");
  printf("  cs: 0x%p  ss: 0x%x  ds: 0x%x\n",
	 cpu_state->cs, cpu_state->ss, cpu_state->ds);
  printf("  es: 0x%x  fs: 0x%x  gs: 0x%x\n",
	 cpu_state->es, cpu_state->fs, cpu_state->gs);
  printf("  eax: 0x%x  ebx: 0x%x\n", cpu_state->eax, cpu_state->ebx);
  printf("  ecx: 0x%x  edx: 0x%x\n", cpu_state->ecx, cpu_state->edx);
  printf("  edi: 0x%x  esi: 0x%x\n", cpu_state->edi, cpu_state->esi);
  printf("  ebp: 0x%x\n", cpu_state->ebp);
  printf("  eip: 0x%x\n",  cpu_state->eip);
  printf("  cr0: 0x%x  cr2: 0x%x\n", cpu_state->cr0, cpu_state->cr2);
  printf("  cr3: 0x%x  cr4: 0x%x\n", cpu_state->cr3, cpu_state->cr4);
  printf("******************************\n");

  _hang_up_processor();

  return cpu_state;
}

t_cpustate	*ia32_error_code_exception_handler(t_uint32	int_code,
						  t_cpustate	*cpu_state)
{
  printf("\n\n Exception Catched: %s\n", exception_strings[int_code]);
  printf("******************************\n");
  printf("  cs: 0x%x  ss: 0x%x  ds: 0x%x\n",
	 cpu_state->cs, cpu_state->ss, cpu_state->ds);
  printf("  es: 0x%x  fs: 0x%x  gs: 0x%x\n",
	 cpu_state->es, cpu_state->fs, cpu_state->gs);
  printf("  eax: 0x%x  ebx: 0x%x\n", cpu_state->eax, cpu_state->ebx);
  printf("  ecx: 0x%x  edx: 0x%x\n", cpu_state->ecx, cpu_state->edx);
  printf("  edi: 0x%x  esi: 0x%x\n", cpu_state->edi, cpu_state->esi);
  printf("  ebp: 0x%x\n", cpu_state->ebp);
  printf("  error code : 0x%x      \n", cpu_state->error_code);
  printf("  eip: 0x%x\n",  cpu_state->eip);
  printf("  cr0: 0x%x  cr2: 0x%x\n", cpu_state->cr0, cpu_state->cr2);
  printf("  cr3: 0x%x  cr4: 0x%x\n", cpu_state->cr3, cpu_state->cr4);
  printf("******************************\n");

  _hang_up_processor();

  return cpu_state;
}

void		ia32_master_irq_handler(t_uint32		int_code)
{
  int_code -= INT_IRQ_VECTOR;

  switch(int_code)
    {
    case(0):
      ia32_timer_isr();
      break;
    case(1):
      ia32_keyboard_isr();
      break;
    default:
      printf("Not initialized irq catched: irq_%d\n", int_code);
      break;
    }
}

void		ia32_slave_irq_handler(t_uint32		int_code)
{
   int_code -= INT_IRQ_VECTOR + 8;

  switch(int_code)
    {
    default:
      printf("Not initialized irq catched: irq_%d\n", int_code);
      break;
    }
}

