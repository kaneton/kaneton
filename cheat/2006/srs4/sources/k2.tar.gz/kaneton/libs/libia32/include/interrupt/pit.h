/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/include/interrupt/pit.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [mon mar  6 10:36:43 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef IA32_IA32_PIT_H
#define IA32_IA32_PIT_H	1

/*
 * ---------- definitions -----------------------------------------------------
 */

#define IA32_PIT_TIMER0_BUS	0x40
#define IA32_PIT_TIMER1_BUS	0x41
#define IA32_PIT_TIMER2_BUS	0x42
#define IA32_PIT_CONTROL_BUS 	0x43

/*
 * MODE CONTROL REGISTER
 *
 *      |7|6|5|4|3|2|1|0|
 *	 | | | | | | | |
 *	 | | | | | | | ----- 0 = binary counter
 *	 | | | | ----------- conter mode bits ( here Mode 2 : 010 )
 *	 | | --------------- read/write/latch format bit(11b: R/W LSB=>W RSB
 *	 ------------------- conter select bits (TIMER 0 selected: 00)
 *
 *	|0|0|1|1|0|1|0|0| => 34h
 */

#define IA32_PIT_MCB		0x34


#define IA32_PIT_BASE_FREQUENCY 1193180



#endif
