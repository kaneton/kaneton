/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/pmode/gdt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:45:19 2005]
 * updated       Jerome Herbault   [fri feb 17 06:41:46 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage global descriptor table.
 *
 */


/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have  to place here code to manage  gdt. there are no
 * restrictions on prototypes, names etc.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

static void	_gdt_edit_entry_base(t_gdt		*gdt,
				     t_uint32		base)
{
  gdt->base_0 = base & 0xffff;
  gdt->base_16 = (base >> 16) & 0xff;
  gdt->base_24 = (base >> 24) & 0xff;
}

static void	_gdt_edit_entry_limit(t_gdt		*gdt,
				      t_uint32		limit)
{
  gdt->limit_0 = limit & 0xffff;
  gdt->flags_limit_16 |= (limit >> 16) & 0xf;
}

static void	_gdt_edit_entry_dpl(t_gdt		*gdt,
				     t_uint8		dpl)
{
  gdt->dpl_type |= (dpl & 0xf) << 4;
}

static void	_gdt_edit_entry_type(t_gdt		*gdt,
				     t_uint32		type)
{
  gdt->dpl_type |= (type & 0xf);
}

static void	_gdt_edit_entry_flags(t_gdt		*gdt,
				     t_uint32		flags)
{
  gdt->flags_limit_16 |= (flags & 0xf) << 4;
}

static void	_gdt_edit_entry(t_gdt			*gdt,
				t_uint32		base,
				t_uint32		limit,
				t_uint8			dpl,
				t_uint8			type,
				t_uint8			flags)
{
  _gdt_edit_entry_base(gdt, base);
  _gdt_edit_entry_limit(gdt, limit);
  _gdt_edit_entry_dpl(gdt, dpl);
  _gdt_edit_entry_type(gdt, type);
  _gdt_edit_entry_flags(gdt, flags);
}

static t_uint32	_gdt_get_entry_base(t_gdt		*gdt)
{
  return (gdt->base_24 << 24) | (gdt->base_16 << 16) | gdt->base_0;
}

static t_uint32	_gdt_get_entry_limit(t_gdt		*gdt)
{
  return ((gdt->flags_limit_16 & 0xf) << 16) | gdt->limit_0;
}

static t_uint8	_gdt_get_entry_dpl(t_gdt		*gdt)
{
  return (gdt->dpl_type >> 4) & 0xf;
}

static t_uint8	_gdt_get_entry_type(t_gdt		*gdt)
{
  return gdt->dpl_type & 0xf;
}

static t_uint8	_gdt_get_entry_flags(t_gdt		*gdt)
{
  return (gdt->flags_limit_16 >> 4) & 0xf;
}

void		ia32_gdt_init(t_uint32			gdt,
			      d_gdtr			*gdtr)

{
  gdtr->limit = 0x8;
  gdtr->base = (t_uint32) gdt;
  _gdt_edit_entry((t_gdt *) gdtr->base, 0, 0, 0, 0, 0);
}

void		ia32_gdt_build_ia32_virtual(d_gdtr		*gdtr)
{
  ia32_gdt_new_entry
    (0, 0xfffff, GDT_DPL_KERN, GDT_TYPE_C_RX, GDT_FLAGS_STD, gdtr);
  ia32_gdt_new_entry
    (0, 0xfffff, GDT_DPL_KERN, GDT_TYPE_D_RW, GDT_FLAGS_STD, gdtr);
  ia32_gdt_new_entry
    (0, 0xfffff, GDT_DPL_USER, GDT_TYPE_C_RX, GDT_FLAGS_STD, gdtr);
  ia32_gdt_new_entry
    (0, 0xfffff, GDT_DPL_USER, GDT_TYPE_D_RW, GDT_FLAGS_STD, gdtr);
}

t_gdt_pos	ia32_gdt_new_entry(t_uint32		base,
				   t_uint32		limit,
				   t_uint8		dpl,
				   t_uint8		type,
				   t_uint8		flags,
				   d_gdtr		*gdtr)
{
  t_gdt_pos	pos;

  pos = gdtr->limit / 0x8;
  gdtr->limit += 0x8;
  if (ia32_gdt_edit_entry (pos, base, limit, dpl, type, flags, gdtr) != pos)
    {
      gdtr->limit -= 0x8;
      return 0;
    }
  return pos;
}

t_gdt_pos	ia32_gdt_edit_entry(t_gdt_pos		pos,
				    t_uint32		base,
				    t_uint32		limit,
				    t_uint8		dpl,
				    t_uint8		type,
				    t_uint8		flags,
				    d_gdtr		*gdtr)
{
  t_gdt		*gdt;

  if (pos >= (gdtr->limit / 0x8) || pos <= 0)
    return 0;

  gdt = (t_gdt *) (gdtr->base + ((t_uint32) pos * sizeof (t_gdt)));

  _gdt_edit_entry(gdt, base, limit, dpl, type, flags);
  return pos;
}

t_gdt_pos	ia32_gdt_remove_entry(t_gdt_pos		pos)
{
  return 0;
}

void		ia32_debug_gdt_print(d_gdtr		*gdtr)
{
  int i = 0;

  printf("===| DEBUG GDT PRINT |===\n");
  printf("gdt     base: 0x%x, limit: 0x%x\n", gdtr->base, gdtr->limit );
  for(i = 0; i < gdtr->limit / 0x8; i++)
    {
      t_uint16	*s = (t_uint16 *) (gdtr->base + (i * 0x8));
      t_gdt	*gdt = (t_gdt *) s;
      char	msg[3][20];
      t_uint8	flags;

      printf("***** pos: %x ***** entry: (( %x %x %x %x )) ********\n",
	    gdt, s[3], s[2], s[1], s[0]);
      printf("====> base: 0x%x,\t limit: 0x%x\n",
	     _gdt_get_entry_base(gdt), _gdt_get_entry_limit(gdt));
      switch (_gdt_get_entry_dpl(gdt))
	{
	case GDT_DPL_KERN:
	  strcpy(msg[0], "KERNEL");
	  break;
	case GDT_DPL_USER:
	  strcpy(msg[0], "USER  ");
	  break;
	default:
	  strcpy(msg[0], "ERROR ");
	  break;
	}
      switch (_gdt_get_entry_type(gdt))
	{
	case GDT_TYPE_D_RO:
	case GDT_TYPE_D_RO + 1:
	  strcpy(msg[1], "D_RO     ");
	  break;
	case GDT_TYPE_D_RW:
	case GDT_TYPE_D_RW + 1:
	  strcpy(msg[1], "D_RW     ");
	  break;
	case GDT_TYPE_D_RO_EXP:
	case GDT_TYPE_D_RO_EXP + 1:
	  strcpy(msg[1], "D_RO_EXP ");
	  break;
	case GDT_TYPE_D_RW_EXP:
	case GDT_TYPE_D_RW_EXP + 1:
	  strcpy(msg[1], "D_RW_EXP ");
	  break;
	case GDT_TYPE_C_X:
	case GDT_TYPE_C_X + 1:
	  strcpy(msg[1], "C_X      ");
	  break;
	case GDT_TYPE_C_RX:
	case GDT_TYPE_C_RX + 1:
	  strcpy(msg[1], "C_RX     ");
	  break;
	case GDT_TYPE_C_X_EXP:
	case GDT_TYPE_C_X_EXP + 1:
	  strcpy(msg[1], "C_X_EXP  ");
	  break;
	case GDT_TYPE_C_RX_EXP:
	case GDT_TYPE_C_RX_EXP + 1:
	  strcpy(msg[1], "C_RX_EXP ");
	  break;
	default:
	  strcpy(msg[1], "ERROR    ");
	  break;
	}
      strcpy(msg[2], "P S ");
      flags = _gdt_get_entry_flags(gdt);
      printf("*** flags := %x ***\n", flags);
      if ((flags >> 3) & 1)
	strcat(msg[2], "G ");
      if ((flags >> 2) & 1)
	strcat(msg[2], "D/B ");
      if ((flags >> 1) & 1)
	strcat(msg[2], "L ");
      if ((flags >> 0) & 1)
	strcat(msg[2], "AVL ");
      printf("====> dpl: %s,\t type: %s, flags: %s\n\n", msg[0], msg[1], msg[2]);
    }
}

