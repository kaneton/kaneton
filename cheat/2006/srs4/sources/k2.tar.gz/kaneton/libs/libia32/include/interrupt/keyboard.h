/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/include/interrupt/keyboard.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [wed mar 15 13:34:36 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef IA32_IA32_KEYBOARD_H
#define IA32_IA32_KEYBOARD_H	1

/*
 * ---------- definitions -----------------------------------------------------
 */

#define RELEASED(key)	((key) | 0x80)

#define IA32_KEYB_CONTROL_SHIFT		(1 << 0)
#define IA32_KEYB_CONTROL_CTRL_LEFT	(1 << 1)
#define IA32_KEYB_CONTROL_CTRL_RIGHT	(1 << 2)
#define IA32_KEYB_CONTROL_ALT		(1 << 3)
#define IA32_KEYB_CONTROL_ALT_GR	(1 << 4)

#define IA32_KEYB_LEFT_CTRL		0x1d
#define IA32_KEYB_RIGHT_CTRL		0x11d
#define IA32_KEYB_LEFT_ALT		0x38
#define IA32_KEYB_RIGHT_ALT		0x138
#define IA32_KEYB_LEFT_SHIFT		0x2a
#define IA32_KEYB_RIGHT_SHIFT		0x36

#define IA32_KEYB_BUFFER_SIZE		1024
#define IA32_KEYB_READ_PORT		0x60

#define IA32_KEYMAP_FR			0x00
#define IA32_KEYMAP_US			0x01
/*
 * ----------- declarations ---------------------------------------------------
 */

typedef struct
{
  char		normal[4];
  char		shift[4];
  char		alt[4];
  char		special[4];
} __attribute__ (( __packed__ )) t_keycode_translator;



typedef struct
{
  t_keycode_translator		*key_map;
  char				buffer[IA32_KEYB_BUFFER_SIZE];
  t_uint16			start;
  t_uint16			end;
} t_keyboard_info;

#endif
