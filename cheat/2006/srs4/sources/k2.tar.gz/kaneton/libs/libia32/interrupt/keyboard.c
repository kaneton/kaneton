/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/interrupt/keyboard.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [sun mar 19 17:14:44 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage interrupt controller.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will use this file to place functions they wrote to manage
 * the pic. students may write as many functions as they whant without
 * any restrictions.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>
#include <libia32.h>
#include "../include/interrupt/keyboard_map.h"

/*
 * ---------- declerations statiques ------------------------------------------
 */

static t_uint8		_control_status = 0;
static t_uint8		_is_special_key = 0;

static t_keyboard_info	_keyinfo;


/*
 * ---------- functions -------------------------------------------------------
 */

static t_uint8	_can_add(void)
{
  t_uint16	next = _keyinfo.end + 1;

  if (next == IA32_KEYB_BUFFER_SIZE)
    next = 0;
  if (next == _keyinfo.start)
    return 0;
  return 1;
}

static t_uint8	_can_get(void)
{
  if (_keyinfo.start == _keyinfo.end)
    return 0;
  return 1;
}

static t_uint8	_put_keycode(t_uint8 keycode)
{
  char		decoded_key[4];
  int		i;
  // decode
  if (_control_status & IA32_KEYB_CONTROL_SHIFT)
    strcpy(decoded_key, _keyinfo.key_map[keycode].shift);
  else if (_control_status & IA32_KEYB_CONTROL_ALT_GR)
    strcpy(decoded_key, _keyinfo.key_map[keycode].alt);
  else
    strcpy(decoded_key, _keyinfo.key_map[keycode].normal);

  if (strcmp(decoded_key, "") == 0)
    return 1;

  // write in buffer
  for (i = 0; (i < 3) && (decoded_key[i] != '\0'); i++)
    if (_can_add())
      _keyinfo.buffer[_keyinfo.end++] = decoded_key[i];
    else
      return 2;
  return 0;
}

t_uint8		ia32_keyboard_select_keymap(t_uint16	keymap_code)
{
  switch(keymap_code)
    {
    case(IA32_KEYMAP_FR):
      _keyinfo.key_map = _keymap_fr;
      return 0;
    case(IA32_KEYMAP_US):
      _keyinfo.key_map = _keymap_us;
      return 0;
    default:
      return 1;
    }
}

void		ia32_keyboard_init(void)
{
  _keyinfo.start = 0;
  _keyinfo.end = 0;

  ia32_keyboard_select_keymap(IA32_KEYMAP_FR);

  ia32_pic_enable(1);
}

t_bool		ia32_keyboard_get_key(char		*key)
{
  if (_can_get() == 0)
    return FALSE;

  *key = _keyinfo.buffer[_keyinfo.start++];
  if (_keyinfo.start == IA32_KEYB_BUFFER_SIZE)
    _keyinfo.start = 0;

  return TRUE;
}

void		ia32_keyboard_isr(void)
{
  t_uint16	keycode;

  // Lecture de la touche
  keycode = inb(0x60) & 0xff; //KEYBOARD_READ_PORT);

  if (keycode == 0xe0)
    {
      _is_special_key = 1;
      return;
    }
  if (_is_special_key != 0)
    {
      _is_special_key = 0;
      keycode |= 0x100;
    }

if ((keycode & 0xff) > 0x80)
  switch(keycode)
    {
    case(RELEASED(IA32_KEYB_LEFT_CTRL)):
      _control_status &= ~IA32_KEYB_CONTROL_CTRL_LEFT;
      return;
    case(RELEASED(IA32_KEYB_RIGHT_CTRL)):
      _control_status &= ~IA32_KEYB_CONTROL_CTRL_RIGHT;
      return;
    case(RELEASED(IA32_KEYB_LEFT_ALT)):
      _control_status &= ~IA32_KEYB_CONTROL_ALT;
      return;
    case(RELEASED(IA32_KEYB_RIGHT_ALT)):
      _control_status &= ~IA32_KEYB_CONTROL_ALT_GR;
      return;
    case(RELEASED(IA32_KEYB_LEFT_SHIFT)):
    case(RELEASED(IA32_KEYB_RIGHT_SHIFT)):
      _control_status &= ~IA32_KEYB_CONTROL_SHIFT;
      return;
    default:
      return;
    }
 switch(keycode)
   {
   case(IA32_KEYB_LEFT_CTRL):
     _control_status |= IA32_KEYB_CONTROL_CTRL_LEFT;
     break;
   case(IA32_KEYB_RIGHT_CTRL):
     _control_status |= IA32_KEYB_CONTROL_CTRL_RIGHT;
     break;
   case(IA32_KEYB_LEFT_ALT):
     _control_status |= IA32_KEYB_CONTROL_ALT;
     break;
   case(IA32_KEYB_RIGHT_ALT):
     _control_status |= IA32_KEYB_CONTROL_ALT_GR;
     break;
   case(IA32_KEYB_LEFT_SHIFT):
   case(IA32_KEYB_RIGHT_SHIFT):
     _control_status |= IA32_KEYB_CONTROL_SHIFT;
     break;
   }

 _put_keycode(keycode & 0xff);

}
