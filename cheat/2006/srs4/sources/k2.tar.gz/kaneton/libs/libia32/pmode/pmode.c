/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/pmode/pmode.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:15 2005]
 * updated       Jerome Herbault   [fri feb 17 06:32:16 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage protected mode.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  must  write  here  function related  to  protected  mode:
 * entering, leaving etc.
 *
 * but  be careful: everything  that deals  with gdt  and ldt  must be
 * placed in the corresponding file, not here.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

extern t_init*	    init;


/*
 * ---------- functions -------------------------------------------------------
 */

void		ia32_enter_pmode(d_gdtr			*gdtr)
{
  printf("*** gdtr = %x ***\n", gdtr);

  asm ("lgdt	(%0)\r\n"
       "movl	%%cr0, %%eax\r\n"
       "or	%%eax, 1\r\n"
       "movl	%%eax, %%cr0\r\n"
       :
       : "r" (gdtr)
       : "%eax");
}

void		ia32_pmode_update_segments(t_uint8 cs, t_uint8 ds)
{
  asm volatile (" movl %1, %%edx        \r\n"
		" mov %%dx, %%ds        \r\n"
		" mov %%dx, %%es        \r\n"
		" mov %%dx, %%fs        \r\n"
		" mov %%dx, %%gs        \r\n"
		" mov %%dx, %%ss	\r\n"
		" movl %0, %%edx        \r\n"
		" pushl %%edx		\r\n"
		" pushl $cs_jump  	\r\n"
		" lret			\r\n"
		"cs_jump:"
		:
		: "g" (cs << 3), "g" (ds << 3), "i" (0xda8ec289)
		: "%edx");
 }


void		ia32_leave_pmode(void)
{
}

t_uint8		ia32_is_pmode(void)
{
  t_uint32		cr_0;

  asm  (" movl %%cr0, %0	\r\n"
       : "+r" (cr_0));

  return cr_0 & 1;
}
