<?
$strbase = "
############__---~~~~~|~~~~~--__#############
########.-~~          | herbau_j ~~-.########
#####.-~     .-~~~~-. | selari_m     ~-.#####
####/       {  o     }| cohen-_i        \####
###/        /       / |                  \###
##|        `--r'   {  | ,___.-',          |##
##|          /      ~-|         ',        |##
##|---------{---------|----------'--------|##
##|          \        |         /         |##
##|           \       |        /          |##
###\         ~ ~~~~~~~|~~~~~~~~~ ~       /###
####\       ~ ~ ~ ~ ~ | ~ ~ ~ ~ ~ ~     /####
#####`-_     ~ ~ ~ ~ ~|~ ~ ~ ~ ~ ~    _-'####
########`-__    ~ ~ ~ | ~ ~ ~ ~   __-'#######
############~~---_____|_____---~~############
";

$mask = "
#############################################
#############################################
#############.-~~~~-.########################
############{##o#####}#######################
############/#######/########################
###########`--r'###{####,___.-',#############
#############/######~-##########',###########
############{####################'###########
#############\##################/############
##############\################/#############
#############################################
#############################################
#############################################
#############################################
";

$str = $strbase;
$str2 = $strbase;

/*PREMIER k*/
for ($j=0, $i = 0; $i < strlen($mask); $i++, $j++)
{
  $char = substr($mask, $i, 1);
  if ($char != "#" && $char != "\n" && $char != "\r" && $char != " ")
  {
	$av  = substr($str, 0, $j);
	$mi = "\"COLOR(YELLOW)\"".$char."\"COLOR(WHITE)\"";
	//$mi = $char;
	$end = substr($str, $j + 1);
	$str = $av.$mi.$end;
	$j = $j + strlen("\"COLOR(YELLOW)\"") + strlen("\"COLOR(WHITE)\"");
  }
}

$str = str_replace("\r", "\n", $str);
$str = str_replace("\\", "\\\\", $str);
$str = str_replace("\n", "\\n\\\n          ", $str);
$str = str_replace("          \\n\\", "\\n\\", $str);
$str = str_replace("#", "\"COLOR(CYAN)\"#\"COLOR(WHITE)\"", $str);
$str = str_replace(" ~ ", "\"COLOR(BLUE)\" ~ \"COLOR(WHITE)\"", $str);


/*SECOND k*/
for ($j=0, $i = 0; $i < strlen($mask); $i++, $j++)
{
  $char = substr($mask, $i, 1);
  if ($char != "#" && $char != "\n" && $char != "\r" && $char != " ")
  {
        $av  = substr($str2, 0, $j);
        $mi = "\"COLOR(YELLOW)\"".$char."\"COLOR(WHITE)\"";
        //$mi = $char;
        $end = substr($str2, $j + 1);
        $str2 = $av.$mi.$end;
        $j = $j + strlen("\"COLOR(YELLOW)\"") + strlen("\"COLOR(WHITE)\"");
  }
}

$str2 = str_replace("\r", "\n", $str2);
$str2 = str_replace("\\", "\\\\", $str2);
$str2 = str_replace("\n", "\\n\\\n          ", $str2);
$str2 = str_replace("          \\n\\", "\\n\\", $str2);
$str2 = str_replace("#", "\"COLOR(CYAN)\".\"COLOR(WHITE)\"", $str2);
$str2 = str_replace(" ~ ", "\"COLOR(BLUE)\" ~ \"COLOR(WHITE)\"", $str2);






echo "#define KANETON \"";
echo $str;
echo "\"";
echo "\n";


echo "#define KANETON2 \"";
echo $str2;
echo "\"";
echo "\n";


?>