/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/include/kaneton/error.h
 *
 * created       julien quintard   [fri feb 11 02:19:11 2005]
 * updated       Jerome Herbault   [sat apr  1 08:22:32 2006]
 */

#ifndef KANETON_ERROR_H
#define KANETON_ERROR_H		1

/*
 * ---------- defines ---------------------------------------------------------
 */

#define ERROR_NONE		(1 << 0)
#define ERROR_UNKNOWN		(1 << 1)

/*
 * the other values are reserved for the specific managers use.
 */

/*
 * ========== interrupts ======================================================
 */

/*
 * Interrupt Manager
 */
#define ERROR_INT_INIT			ERROR_UNKNOWN + 1

/*
 * PIC Manager
 */
#define ERROR_PIC_INIT			ERROR_INT_INIT + 1
#define ERROR_PIC_INVALID_IRQ		ERROR_PIC_INIT + 1
/*
 * TIMER Manager
 */

#define ERROR_TIMER_INIT		ERROR_PIC_INVALID_IRQ + 1
#define ERROR_TIMER_NOT_INIT		ERROR_TIMER_INIT + 1
#define ERROR_TIMER_INVALID_DURATION	ERROR_TIMER_NOT_INIT + 1
/*
 * KEYBOARD Manager
 */
#define ERROR_KEYB_INIT			ERROR_TIMER_INVALID_DURATION + 1
#define ERROR_KEYB_INVALID_MAP		ERROR_KEYB_INIT + 1
/*
 * SET manager
*/
#define ERROR_SET_INIT			ERROR_KEYB_INIT + 1
#define ERROR_NOT_AVALABLE		ERROR_SET_INIT + 1
#define ERROR_NOT_FOUND			ERROR_NOT_AVALABLE + 1
/*
 * ALLOC Manager
 */

#define ERROR_ALLOC_UNKNOWN_FIT		ERROR_KEYB_INVALID_MAP + 1
#define ERROR_MALLOC			ERROR_ALLOC_UNKNOWN_FIT + 1


/*
 * ----------- Mini-shell ----------------------------------------------------
 */

/*
 * Generic error
 */

#define ERROR_INVALID_ARGS		ERROR_MALLOC + 1
#define ERROR_EMPTY			ERROR_INVALID_ARGS + 1
#define ERROR_INVALID_OBJECT_TYPE	ERROR_EMPTY + 1
#endif
