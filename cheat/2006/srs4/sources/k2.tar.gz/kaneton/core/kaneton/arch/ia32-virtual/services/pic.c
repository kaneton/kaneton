/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/arch/ia32-virtual/services/pic.c
 *
 * created       julien quintard   [sat dec 17 17:16:19 2005]
 * updated       Jerome Herbault   [mon mar 20 20:29:37 2006]
 */


/*
 * ------ Includes ------------------------------------------------------------
 */

#include <kaneton.h>

/*
 * ------ Functions -----------------------------------------------------------
 */


t_error		k_init_pic(void)
{
  ia32_pic_init();
  ia32_pic_activate();
  return ERROR_NONE;
}

t_error		k_pic_enable(t_uint16		irq)
{
  if (irq == 2 || irq == 12 || irq >= 16)
    return ERROR_PIC_INVALID_IRQ;
  ia32_pic_enable(irq);
  return ERROR_NONE;
}

t_error		k_pic_disable(t_uint16		irq)
{
  if (irq == 2 || irq == 12 || irq >= 16)
    return ERROR_PIC_INVALID_IRQ;
  ia32_pic_disable(irq);
  return ERROR_NONE;
}
