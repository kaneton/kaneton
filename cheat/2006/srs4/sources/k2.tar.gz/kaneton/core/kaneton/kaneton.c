/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat apr  1 08:40:42 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <mini-shell.h>
#include <kaneton.h>
#include <kaneton_ascii.h>
/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;
extern t_asid		kasid;
/*
 * ---------- definitions statiques -------------------------------------------
 */

static t_uint32		_init_str_len = 0;

/*
 * ---------- functions -------------------------------------------------------
 */


static void			_halt(void)
{
  printf("Kernel Halted !!\n");
  while(1);
}

static void			_print_init_str(const char	*str)
{
  _init_str_len = strlen(str);

  printf("%s", str);
}

static void			_print_init_str_result(t_bool	res)
{
  if (_init_str_len == 0 && res > 1)
    return;
  k_console_fseek(65 - _init_str_len);
  if (res == TRUE)
    printf("[ "COLOR(GREEN)"OK"COLOR(WHITE)" ]\n");
  else
    printf("[ "COLOR(RED)"KO"COLOR(WHITE)" ]\n");
  _init_str_len = 0;

}


void			kaneton(t_init*	bootloader)
{
  init = bootloader;
  k_console_init(&(bootloader->machdep.cons));

  printf(COLOR(CYAN)"KERNEL SUCCESSFULLY LAUCHED\n\n"COLOR(WHITE));

  printf("Kernel Initialisation.\n-----\n\n\n");

  printf("Initializing interrupt based managers.\n-----\n");
  /*
   * Configuration des interruptions
   */

  INIT_CMD_PANIKABLE(k_init_interrupts(bootloader),
		     "  Interrupt manager initialization.",
		     "\tFailed to initialize interrupt manager")

  /*
   * Configuration du pic
   */

  INIT_CMD_PANIKABLE(k_init_pic(),
		     "  PIC manager initilization.",
		     "\tFailed to initialize PIC manager");

  /*
   * Configuration du pit
   */
  INIT_CMD_PANIKABLE(k_timer_init(20, FALSE),
		     "  Timers manager initilization.",
		     "\tFailed to initialize timers manager");

  /*
   * Initialisation du clavier
   */

  INIT_CMD(k_init_keyb(),
	   "  Keyboard manager initilization.");

  /*
   * Initialisation de la memoire
   */

  printf("\nInitializing memory managers.\n-----\n");

  INIT_CMD_PANIKABLE(alloc_init(bootloader->alloc,
				bootloader->allocsz,
				FIT_FIRST),
		     "  Initializing malloc.",
		     "\tFailed to initialize malloc");


  /*
   * Initialisation des managers
   */
  printf("\nInitializing Managers.\n-----\n");

  STATS_INIT();

  INIT_CMD_PANIKABLE(id_init(),
		     "  Initializing identifier manager.",
		     "\tFailed to initialize identifier manager");

  INIT_CMD_PANIKABLE(set_init(),
		     "  Initializing set manager.",
		     "\tFailed to initialize set manager");

  INIT_CMD_PANIKABLE(as_init(),
		     "  Initializing address space manager.",
		     "\tFailed to initialize address space manager");

  INIT_CMD_PANIKABLE(segment_init(),
		     "  Initializing segment manager.",
		     "\tFailed to initialize segment manager.");






  INIT_CMD_PANIKABLE(segment_clean(),
		     "  Clean segment manager.",
		     "\tFailed to clean segment manager");

  INIT_CMD_PANIKABLE(as_clean(),
		     "  Clean as manager.",
		     "\tFailed to clean as manager");

  INIT_CMD_PANIKABLE(set_clean(),
		     "  Clean set manager.",
		     "\tFailed to clean set manager");

  printf(COLOR(CYAN)"\nKERNEL SUCCESSFULLY INITIALIZED\n\n"COLOR(WHITE));


   ms_mini_shell();

}



