/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/as.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:27:59 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file  implements dependent  code for as  manager on  ia32 with
 * paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_as*		as;
extern t_tskid		ktask;
extern t_asid		kasid;
extern t_init*		init;

/*
 * ---------- globals ---------------------------------------------------------
 */



/*
 * the address space manager interface.
 */

i_as			as_interface =
  {
    NULL,			//    as_give
    NULL,			//    as_vaddr
    NULL,			//    as_paddr
    NULL,			//    as_clone
    NULL,			//    as_reserve
    NULL,			//    as_release
    NULL,			//    as_init
    NULL			//    as_clean
  };

/*
 * ---------- functions -------------------------------------------------------
 */

