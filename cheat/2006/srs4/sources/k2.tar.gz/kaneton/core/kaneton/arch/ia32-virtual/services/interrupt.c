/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/arch/ia32-virtual/services/interrupt.c
 *
 * created       julien quintard   [sat dec 17 17:16:19 2005]
 * updated       Jerome Herbault   [mon mar 20 22:20:27 2006]
 */


/*
 * ------ Includes ------------------------------------------------------------
 */

#include <kaneton.h>

/*
 * ------ Functions -----------------------------------------------------------
 */

t_error		k_init_interrupts(void*		bl)
{
  t_init	*bootloader = (t_init *) bl;
  t_error	errcode;

  d_idtr *p_idtr = &(bootloader->machdep.idtr);
  ia32_idt_init(bootloader->machdep.idt, p_idtr);
  errcode = ia32_build_standart_idt(p_idtr);
  if (errcode != ERROR_NONE)
    return ERROR_INT_INIT;
  ia32_activate_interruptions(p_idtr);
  return ERROR_NONE;
}
