/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/set/set_array.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat apr  1 09:09:32 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  subpart  of the  set  manager is  used  to  build array  data
 * structures.
 *
 * there  are two  way  to use  the  arrays :  with  pointers or  with
 * objects.    the  first   method   is  the   default  one   (without
 * SET_OPT_ALLOC) : it only  stores pointers refering to objects.  The
 * second method (used with  SET_OPT_ALLOC) makes copies of objects in
 * the set,  using memcpy. with  SET_OPT_FREE, objects are  freed when
 * they   are  removed   from  the   array  or   when  the   array  is
 * flushed/released.
 *
 * the option ORGANISE is used to keep the array as small as possible,
 * but  some operation  requires to  shift entire  parts of  the array
 * (loss of performances).
 *
 * when an array set is cloned, data are reorganised in. it means than
 * when a  clone operation occurs,  the array is reduced  clearing the
 * empty/unused places.
 *
 * options:    SET_OPT_CONTAINER,    SET_OPT_SORT,   SET_OPT_ORGANISE,
 * SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire array data structure.
 *
 * this data structure is very useful to contain very little objects like
 * identifiers.
 *
 * the address space objects, the task objects etc.. use it widely.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

t_error set_type_array(t_setid u)
{
  o_set			*o = NULL;
  t_error		err = 0;

  SET_ENTER(set);

  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
     {
       SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
     }
  o->type = SET_TYPE_ARRAY;

  SET_LEAVE(set, ERROR_NONE);
}

/*
 * Display content of a set object 'u'
 *
 */
t_error set_show_array(t_setid u)
{
  t_setsz		i = 0;
  o_set			*o = NULL;
  t_iterator		iterator;
  t_state		state ;
  t_error		err = 0;

  SET_ENTER(set);

  printf("showing elements for set_array %qd\n", u);
  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  //  set_foreach(SET_OPT_FORWARD, u, &iterator, state)
  for (i = 0; i < o->u.array.arraysz; i++)
    {
      printf("  %qx:\t", i);
      if (o->u.array.array[i] != NULL)
	printf("%qd\n", *((t_id *) o->u.array.array[i]));
      else
	printf("NuLL\n");
    }

  SET_LEAVE(set, ERROR_NONE);
}

t_error set_head_array(t_setid u, t_iterator* iterator)
{
  t_setsz		i;
  o_set			*o = NULL;
  t_setsz	        array_size = 0;
  t_error		err;

  SET_ENTER(set);

  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  array_size = o->u.array.arraysz;

  if (array_size == 0)
    {
      iterator->u.array.i = 0;
      SET_LEAVE(set, ERROR_EMPTY);
    }

  if (!(o->u.array.opts & SET_OPT_ORGANISE))
    {
      for (i = 0; i < array_size; i++)
	if (o->u.array.array[i] != NULL)
	  {
	    iterator->u.array.i = i;
	    SET_LEAVE(set, ERROR_NONE);
	  }
    }
  iterator->u.array.i = 0;

  printf("set_head_array: out\n");
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_tail_array(t_setid u, t_iterator* iterator)
{
  t_setsz		i;
  o_set			*o;
  t_setsz	        array_size;
  t_error		err;

  SET_ENTER(set);

  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  array_size = o->u.array.arraysz;

  if (array_size == 0)
    {
      iterator->u.array.i = 0;
      SET_LEAVE(set, ERROR_EMPTY);
    }
  if (!(o->u.array.opts & SET_OPT_ORGANISE))
    {
      for (i= array_size;
	   i > 0;)
	if (o->u.array.array[--i] != NULL)
	  {
	    iterator->u.array.i = i;
	    SET_LEAVE(set, ERROR_NONE);
	  }
    }
  iterator->u.array.i = array_size - 1;
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_prev_array(t_setid u, t_iterator current, t_iterator* previous)
{
  t_setsz		i;
  o_set			*o;
  t_setsz	        array_size;
  t_error		err;

  SET_ENTER(set);
  // printf("set_prev_array: begin\n");
  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  array_size = o->u.array.arraysz;

  if (current.u.array.i >= array_size || current.u.array.i == 0)
    {
      SET_LEAVE(set, ERROR_UNKNOWN);
    }
  i = current.u.array.i;
  while (i > 0)
    {
      if (o->u.array.array[i - 1] != NULL)
	{
	  previous->u.array.i = i - 1;
	  SET_LEAVE(set, ERROR_NONE);
	}
      i--;
    }
  set_head(u, previous);
  SET_LEAVE(set, ERROR_NOT_FOUND);
}

t_error set_next_array(t_setid u, t_iterator current, t_iterator* next)
{
  t_setsz		i;
  o_set			*o;
  t_setsz	        array_size;
  t_error		err;

  //  printf("set_next_array: begin\n");
  SET_ENTER(set);

  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  array_size = o->u.array.arraysz;
  if (current.u.array.i >= array_size || current.u.array.i == array_size - 1)
    {
      // printf("set_next_array: end: NONE\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }
  i = current.u.array.i + 1;
  while (i < array_size)
    {
      if (o->u.array.array[i] != NULL)
	{
	  next->u.array.i = i;
	  SET_LEAVE(set, ERROR_NONE);
	}
      i++;
    }
  set_tail(u, next);
  //printf("set_next_array: end: NONE\n");
  SET_LEAVE(set, ERROR_NOT_FOUND);
}

t_error set_insert_head_array(t_setid u, void* data)
{
  t_iterator		it;

  SET_ENTER(set);
  set_head_array(u, &it);
  SET_LEAVE(set, set_insert_before_array(u, it, data));
}

t_error set_insert_tail_array(t_setid u, void* data)
{
  t_iterator		it;

  SET_ENTER(set);
  printf("error ?? %d\n", set_tail_array(u, &it));
  printf("it: %qd\n", it.u.array.i);
  SET_LEAVE(set, set_insert_after_array(u, it, data));
}

static void* _reverse_memcpy(void*			dest,
			     const void*		src,
			     size_t			n)
{
  char*			d = dest;
  const char*		s = src;
  u_int			i;

  if ((n == 0) || (src == dest))
    return (NULL);


  for (i = n; i > 0; i--)
    d[i - 1] = s[i - 1];

  return (d);
}

static t_error _set_shift_array(t_uint32		options,
				t_iterator		it,
				t_uint32		array_size,
				void**			array)
{
  t_uint32		length;
  int			negative;

  if ((!(options & SET_SHIFT_INCLUDE_CURRENT)))
    it.u.array.i++;
  if (it.u.array.i > array_size)
    length = 0;
  else
    length = array_size - it.u.array.i;
  if (length == 0)
    return ERROR_NONE;
  if (options & SET_SHIFT_RIGHT)
    negative = 1;
  else
    negative = -1;
  _reverse_memcpy(array + ((it.u.array.i + (1 * negative))),
	 array + (it.u.array.i),
	 length * sizeof (void *));
  return ERROR_NONE;
}

t_error set_insert_before_array(t_setid u, t_iterator iterator, void* data)
{
  t_setsz		i;
  o_set			*o;
  t_setsz	        array_size;
  void			*new_data;
  t_error		err;

  SET_ENTER(set);
  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  array_size = o->u.array.arraysz;
  if (array_size != 0 && iterator.u.array.i >= array_size)
    SET_LEAVE(set, ERROR_UNKNOWN);
  i = iterator.u.array.i;
  if (i > 0 && o->u.array.array[i - 1] == NULL)
    i--;
  else
    {
      if (array_size == o->size)
	{
	  o->u.array.array = realloc(o->u.array.array,
				     o->size + SET_ARRAY_EXPAND_SIZE);
	  memset(o->u.array.array + (o->size * sizeof (void *)),
		 0,
		 SET_ARRAY_EXPAND_SIZE);
	  o->size += SET_ARRAY_EXPAND_SIZE;
	}
      _set_shift_array(SET_SHIFT_INCLUDE_CURRENT | SET_SHIFT_RIGHT,
		       iterator, array_size, o->u.array.array);
      o->u.array.arraysz++;
    }
  if (o->u.array.opts & SET_OPT_ALLOC)
    {
      new_data = malloc(o->u.array.datasz);
      if (new_data == NULL)
	SET_LEAVE(set, ERROR_MALLOC);
      memcpy(new_data, data, o->u.array.datasz);
      o->u.array.array[iterator.u.array.i] = new_data;
    }
  else
    o->u.array.array[iterator.u.array.i] = data;
  printf("set_insert_array: before: added %qd to %qd at pos %qd (%0x%p)\n",
	 *((t_id *)o->u.array.array[iterator.u.array.i]), u,
	 iterator.u.array.i,
	 (o->u.array.array + iterator.u.array.i * o->u.array.datasz));
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_insert_after_array(t_setid u, t_iterator iterator, void* data)
{
  o_set			*o;
  t_setsz	        array_size;
  void			*new_data;
  t_error		err;
  t_iterator		it;

  printf("i am here: %qd\n", u);
  SET_ENTER(set);
  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  array_size = o->u.array.arraysz;

  if (array_size != 0 && iterator.u.array.i >= array_size)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (iterator.u.array.i + 1 < array_size &&
      o->u.array.array[iterator.u.array.i + 1] == NULL)
    iterator.u.array.i++;
  else
    {
      if (array_size == o->size)
	{
	 o->u.array.array = realloc(o->u.array.array,
				     o->size + SET_ARRAY_EXPAND_SIZE);
	  memset(o->u.array.array + (o->size * sizeof (void *)),
		 0,
		 SET_ARRAY_EXPAND_SIZE);
	  o->size += SET_ARRAY_EXPAND_SIZE;
	}
      _set_shift_array(SET_SHIFT_RIGHT,
		       iterator, array_size, o->u.array.array);
      if (set_head_array(u, &it) != ERROR_EMPTY)
	iterator.u.array.i++;
      o->u.array.arraysz++;
    }
  if (o->u.array.opts & SET_OPT_ALLOC)
   {
      new_data = malloc(o->u.array.datasz);
      if (new_data == NULL)
	SET_LEAVE(set, ERROR_MALLOC);

      memcpy(new_data, data, o->u.array.datasz);
      o->u.array.array[iterator.u.array.i] = new_data;
   }
  else
    o->u.array.array[iterator.u.array.i] = data;
  printf("set_insert_array: after: added %qd to %qd at pos %d (%0x%p)\n",
	 *((t_id *)o->u.array.array[iterator.u.array.i]), u,
	 iterator.u.array.i,
	 (o->u.array.array + iterator.u.array.i * o->u.array.datasz));
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_add_array(t_setid u, void* data)
{
  o_set			*o;
  t_setsz	        array_size;
  t_iterator		it;
  t_state		state;
  t_error		err;

  SET_ENTER(set);
  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  array_size = o->u.array.arraysz;

  if (o->u.array.opts & SET_OPT_SORT)
    {
      t_setsz		i;
      set_foreach (SET_OPT_FORWARD, u, &it, state)
	{
	  printf("foreach : %qd / %qd\n",
		 *((t_id *) o->u.array.array[it.u.array.i]),
		 *((t_id *) data));
	  if (*((t_id *) o->u.array.array[it.u.array.i]) > *((t_id *) data))
	    break;
	}
      printf("done: %qd == %qd\n", it.u.array.i, array_size - 1);
      if (it.u.array.i == array_size - 1)
	{
	  if (*((t_id *) o->u.array.array[it.u.array.i]) > *((t_id *) data))
	    {
	      printf("before\n");
	      SET_LEAVE(set, set_insert_before_array(u, it, data));
	    }
	  else
	    {
	      printf("after\n");
	      SET_LEAVE(set, set_insert_after_array(u, it, data));
	    }
	}
      else
	{
	  printf("before\n");
	  SET_LEAVE(set, set_insert_before_array(u, it, data));
	}
    }
  else
    SET_LEAVE(set, set_insert_tail_array(u, data));
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_remove_array(t_setid u, t_id id)
{
  t_error		err;
  t_iterator		it;

  printf("id = %qd\n", id);
  SET_ENTER(set);
  err = set_locate_array(u, id, &it);
  if (err == ERROR_NOT_FOUND)
    SET_LEAVE(set, ERROR_NOT_FOUND);
  printf("YAhhhhhoooouuu\n");
  SET_LEAVE(set, set_delete_array(u, it));
}

t_error set_delete_array(t_setid u, t_iterator iterator)
{
  o_set			*o;
  t_setsz	        array_size;
  t_error		err;
  t_iterator		it;

  SET_ENTER(set);
  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  array_size = o->u.array.arraysz;

  if (iterator.u.array.i >= array_size)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if (o->u.array.array[iterator.u.array.i] == NULL)
    SET_LEAVE(set, ERROR_UNKNOWN);
  if ((o->u.array.opts & SET_OPT_FREE) || (o->u.array.opts & SET_OPT_ALLOC))
    free(o->u.array.array[iterator.u.array.i]);
  o->u.array.array[iterator.u.array.i] = NULL;
  if (o->u.array.opts & SET_OPT_ORGANISE)
    {
      if (iterator.u.array.i != array_size - 1)
	{
	  _set_shift_array(SET_SHIFT_LEFT,
			   iterator, array_size, o->u.array.array);
	  o->u.array.array[array_size - 1] == NULL;
	}
      // shifter a gauch;
      // mettre a null le dernier element
      o->u.array.arraysz -= 1;
    }
  else
    if (iterator.u.array.i == array_size - 1)
      {
	err = set_prev_array(u, iterator, &it);
	if (err != ERROR_NONE)
	  o->u.array.arraysz = 0;
	else
	  {
	    printf("reducing arraysz by %qd\n", iterator.u.array.i - it.u.array.i);
	    o->u.array.arraysz -= (iterator.u.array.i - it.u.array.i);
	  }
      }
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_flush_array(t_setid u)
{
  t_iterator		it;
  t_state		state;

  SET_ENTER(set);
  set_foreach(SET_OPT_FORWARD, u, &it, state)
    set_delete_array(u, it);
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_locate_array(t_setid u, t_id id, t_iterator* iterator)
{
  int i;
  o_set			*o;
  t_iterator		it;
  t_state		state;
  t_error		err;

  SET_ENTER(set);
  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  for (i = 0; i < o->u.array.arraysz; i++)
    {
      if (o->u.array.array[i] != NULL &&
	  *((t_id *)o->u.array.array[i]) == id)
	{
	  iterator->u.array.i = i;
	  SET_LEAVE(set , ERROR_NONE);
	}
    }
  SET_LEAVE(set, ERROR_NOT_FOUND);
}

t_error set_object_array(t_setid u, t_iterator iterator, void** data)
{
  o_set		*o;
  t_error		err;

  SET_ENTER(set);

  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }

  *data = o->u.array.array[iterator.u.array.i];
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_push_array(t_setid u, void* data)
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_NOT_AVALABLE);
}

t_error set_pop_array(t_setid u)
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_NOT_AVALABLE);
}

t_error set_pick_array(t_setid u, void** data)
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_NOT_AVALABLE);
}

t_error set_release_array(t_setid u)
{
  o_set			*o;
  t_iterator		it;
  t_state		state;
  t_error		err;

  SET_ENTER(set);
  err = set_descriptor(u, &o);
  if (err != ERROR_NONE)
    {
      SET_LEAVE(set, ERROR_INVALID_OBJECT_TYPE);
    }
  if (u == set->container)
    {
      set_foreach(SET_OPT_FORWARD, u, &it, state)
	set_release_array(*((t_id *)o->u.array.array[it.u.array.i]));
      free(set->co->u.array.array);
      set->co->u.array.array == NULL;
      free(set->co);
      set->co = NULL;
      set->container == NULL;
    }
  else
    {
      set_flush(u);
      free(o->u.array.array);
      o->u.array.array = NULL;
      set_destroy(u);
    }
  SET_LEAVE(set, ERROR_NONE);
}

t_error set_reserve_array(t_opts opts, t_size datasz, t_setid* u)
{
  o_set			new_set;
  o_set			*new_container;

  SET_ENTER(set);
  if (opts & SET_OPT_CONTAINER)
    {
      new_container = malloc (sizeof (o_set));
      if (new_container == NULL)
	SET_LEAVE(set, ERROR_MALLOC);
      new_container->setid = set->container;
      new_container->size = SET_ARRAY_INIT_SIZE;
      new_container->type = SET_TYPE_ARRAY;
      new_container->u.array.opts = opts;
      new_container->u.array.datasz = datasz;
      new_container->u.array.initsz = SET_ARRAY_INIT_SIZE;
      new_container->u.array.arraysz = 0;
      new_container->u.array.array =
	malloc(new_container->u.array.initsz * sizeof (void *));
      if (new_container->u.array.array == NULL)
	{
	  free(new_container);
	  SET_LEAVE(set, ERROR_MALLOC);
	}
     set_new(new_container);
    }
  else
    {
      id_reserve(&(set->id), &(new_set.setid));
      new_set.size = SET_ARRAY_INIT_SIZE;
      new_set.type = SET_TYPE_ARRAY;
      new_set.u.array.opts = opts;
      new_set.u.array.datasz = datasz;
      new_set.u.array.initsz = SET_ARRAY_INIT_SIZE;
      new_set.u.array.arraysz = 0;
      new_set.u.array.array =
	malloc(new_set.u.array.initsz * sizeof (void *));
      if (new_set.u.array.array == NULL)
	SET_LEAVE(set, ERROR_MALLOC);
      set_new(&new_set);
      *u = new_set.setid;
    }
  SET_LEAVE(set, ERROR_NONE);
}
