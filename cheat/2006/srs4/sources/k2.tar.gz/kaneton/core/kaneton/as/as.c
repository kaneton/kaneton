/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/as/as.c
 *
 * created       julien quintard   [tue dec 13 03:05:27 2005]
 * updated       Jerome Herbault   [tue mar 28 17:31:41 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the address space manager manages address spaces.
 *
 * an address space describes process' useable memory. each address space
 * is composed of two sets.
 *
 * the first describes the segments held by this address space, in other
 * words the physical memory.
 *
 * the latter describes the regions, the virtual areas which reference
 * some segments.
 *
 * a task can give its address space to another with as_give.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the address space manager builds address space objects.
 *
 * every address space object is essentially composed of two sets: a
 * set of segments which list the segments held by this address space and
 * a set of regions which describes the useable virtual address ranges.
 *
 * the student just has to write the functions to reserve, release, get etc..
 * an address space.
 *
 * note that the address space does nothing more. indeed, the segment
 * manager and the region manager will add and/or remove the segments/regions
 * to/from the address space by their own.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(as);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the address space manager variable.
 */

m_as*			as = NULL;

/*
 * the kernel address space identifier
 */
t_asid			kasid = 0;

extern t_tskid		ktask;
/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Shows a precise address space displaying information on it.
 */
t_error			as_show(t_asid	asid)
{
  o_as			*asobj = NULL;

  AS_ENTER(as);

  if (ERROR_NONE != as_get(asid, &asobj))
    {
      cons_msg('!', "as_show : cannot get the address space\n");
      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  printf("asid: %qd  taskid: %qd  segsetid: %qd regsetid: %qd\n",
	 asobj->asid, asobj->tskid, asobj->segments, asobj->regions);

  AS_LEAVE(as, ERROR_NONE);
}

/*
 * Dumps all the address space managed by the address space manager.
 */
t_error			as_dump(void)
{
  t_iterator		iterator;
  t_state		state = ITERATOR_STATE_UNUSED;
  o_as*			asobj = NULL;

  AS_ENTER(as);

  iterator.u.ll.node = NULL;

  set_foreach(SET_OPT_FORWARD, as->container, &iterator, state)
    {
      if (ERROR_NONE != set_object(as->container, iterator, (void**)&asobj))
	{
	  cons_msg('!', "as : cannot get an address space object\n");
	  AS_LEAVE(as, ERROR_UNKNOWN);
	}

      if (ERROR_NONE != as_show(asobj->asid))
	AS_LEAVE(as, ERROR_UNKNOWN);
    }
  AS_LEAVE(as, ERROR_NONE);
}

/*
 * Clones an address space taking care of cloning everything necessary.
 */
t_error			as_clone(t_tskid	task,
				 t_asid		old,
				 t_asid*	new)
{
  o_as			*old_as;
  o_as			*new_as;

  AS_ENTER(as);

  if (ERROR_NONE != as_get(old, &old_as))
    {
      cons_msg('!', "as_clone : cannot get the source address space\n");
      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != as_reserve(task, new))
    {
      cons_msg('!', "as_clone : cannot alloc the new address space\n");
      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != as_get(*new, &new_as))
    {
      cons_msg('!', "as_clone : cannot get the new address space\n");
      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  new_as->segments = old_as->segments;
  new_as->regions = old_as->regions;

  if (ERROR_NONE != machdep_call(as, as_clone, task, old, new))
    AS_LEAVE(as, ERROR_UNKNOWN);

  AS_LEAVE(as, ERROR_NONE);
}

/*
 * Reserves an address space object for the task.
 */
t_error			as_reserve(t_tskid	task,
				   t_asid*	asid)
{
  o_as			obj;

  AS_ENTER(as);

  memset(&obj, 0, sizeof (o_as));

  if (ERROR_NONE != id_reserve(&(as->id), asid))
    {
      cons_msg('!', "as : cannot reserve the address space\n");
      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  obj.asid = *asid;
  obj.tskid = task;

  if (ERROR_NONE != set_reserve(ll,
				SET_OPT_ALLOC,
				sizeof (t_segid),
				&(obj.segments)))
    {
      cons_msg('!', "as_reserved : cannot reserved a set for the segment\n");
      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_add(as->container, &obj))
    {
      cons_msg('!', "as : cannot add the address space object\n");
      id_release(&(as->id), *asid);

      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != machdep_call(as, as_reserve, task, asid))
    AS_LEAVE(as, ERROR_UNKNOWN);

  AS_LEAVE(as, ERROR_NONE);
}

/*
 * Releases an address space.
 */
t_error			as_release(t_asid	asid)
{
  AS_ENTER(as);

  if (ERROR_NONE != machdep_call(as, as_release, asid))
      AS_LEAVE(as, ERROR_UNKNOWN);

  if (ERROR_NONE != set_remove(as->container, asid))
    {
      cons_msg('!', "as : cannot release the address space\n");
      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  AS_LEAVE(as, ERROR_NONE);
}

/*
 * Returns the address space object corresponding
 * to the address space identifier.
 */
t_error			as_get(t_asid	asid,
			       o_as**	o)
{
  AS_ENTER(as);

  if (ERROR_NONE != set_get(as->container, asid, (void**)o))
    {
      cons_msg('!', "as : cannot get the address space object\n");

      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  AS_LEAVE(as, ERROR_NONE);
}

/*
 * Initializes the address space manager
 */
t_error			as_init(void)
{
  if (NULL == (as = malloc(sizeof(m_as))))
    {
      cons_msg('!', "as : cannot allocate memory for the"
	       " address space manager structure\n");
      return (ERROR_UNKNOWN);
    }

  memset(as, 0x0, sizeof(m_as));

  if (ERROR_NONE != id_build(&as->id))
    {
      cons_msg('!', "as : unable to initialize the identifier object\n");
      return (ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_reserve(ll,
				SET_OPT_ALLOC,
				sizeof(o_as),
				&as->container))
    {
      cons_msg('!', "as : unable to reserve a set\n");
      return (ERROR_UNKNOWN);
    }

  if (ERROR_NONE != as_reserve(ktask, &kasid))
    {
      cons_msg('!', "as : unable to initialize the kernel address space\n");
      return (ERROR_UNKNOWN);
    }

  if (ERROR_NONE != machdep_call(as, as_init))
    {
      cons_msg('!', "as : unable to initialize the machine dependant part\n");
      return (ERROR_UNKNOWN);
    }

  STATS_RESERVE("as", &as->stats);

  return (ERROR_NONE);
}

/*
 * Cleans the address space manager.
 */
t_error			as_clean(void)
{
  if (ERROR_NONE != machdep_call(as, as_clean))
    {
      cons_msg('!', "as : unable to initialize the machine dependant part\n");
      return (ERROR_UNKNOWN);
    }

  if (ERROR_NONE != as_release(kasid))
    {
      cons_msg('!', "as : unable to release the kernel address space\n");
      return (ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_flush(as->container))
    {
      cons_msg('!', "as : cannot flush every address space object\n");
      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_release(as->container))
    {
      cons_msg('!', "as : cannot release the container of the "
	       "address space manager\n");
      AS_LEAVE(as, ERROR_UNKNOWN);
    }

  STATS_RELEASE(as->stats);

  if (ERROR_NONE != id_destroy(&as->id))
    {
      cons_msg('!', "as : unable to destroy the identifier object\n");
      return (ERROR_UNKNOWN);
    }

  free(as);

  return (ERROR_NONE);
}
