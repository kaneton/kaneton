/*
 * licence       Kaneton licence
 *
 * project       kaneton
 *
 * file          /home/rhino/kaneton/core/kaneton/set/set_pipe.c
 *
 * created       renaud voltz   [wed jan 25 17:11:05 2006]
 * updated       renaud voltz   [wed jan 25 17:11:05 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this subpart of the set manager is used to build FIFO data structures like
 * pipes.
 *
 * this is actually a front-end using the linked-list manager.
 */

/*
 * ---------- assignments -----------------------------------------------------
 * XXX
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */

