/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/arch/ia32-virtual/services/timer.c
 *
 * created       julien quintard   [sat dec 17 17:16:19 2005]
 * updated       Jerome Herbault   [mon mar 20 20:45:48 2006]
 */


/*
 * ------ Includes ------------------------------------------------------------
 */

#include <kaneton.h>

/*
 * ------ Definitions statiques -----------------------------------------------
 */

static t_bool		_timer_init = FALSE;
static t_uint32		_freq = 0;

/*
 * ------ Functions -----------------------------------------------------------
 */

t_bool		k_timer_init(t_uint32		frequency,
			     t_bool		force)
{
  if (_timer_init && (!force))
    return ERROR_TIMER_INIT;
  if (!ia32_pit_init(frequency))
    return ERROR_TIMER_INIT;
  _freq = frequency;
  _timer_init = TRUE;
  return ERROR_NONE;
}

t_bool		k_sleep(t_uint32	mil_sec_length)
{
  t_uint32	one_tick_length;
  t_uint64	l;

  if (!_timer_init)
    return ERROR_TIMER_NOT_INIT;

  one_tick_length = 1000 / _freq;
  if (one_tick_length >  mil_sec_length)
    return ERROR_TIMER_INVALID_DURATION;

  l = mil_sec_length / one_tick_length;
  l += ia32_pit_get_ticks();

  while (ia32_pit_get_ticks() != l);

  return ERROR_NONE;
}
