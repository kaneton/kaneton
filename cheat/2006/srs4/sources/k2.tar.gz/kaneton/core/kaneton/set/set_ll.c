/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/set/set_ll.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat apr  1 09:25:15 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this subpart of the set manager is used to build linked-list
 * data structures.
 *
 * note that this data structure is in fact a doubly linked-list.
 *
 * each set of this type can be used in two ways. the first one ask the
 * set manager to allocate and copy each object to add while the second
 * way tells the set manager to simply include the objects in the set.
 *
 * moreover the option free can be used to tell the set manager to call
 * the free() function each time an object is released. this option
 * means that objects passed to the set manager was previously allocated
 * with the malloc() functions suite.
 *
 * moreover, the linked-list data structure can be used either with the
 * sort option or without.
 *
 * the datasz argument of the set_reserve() function is meaningful only in the
 * case the allocate or free options are set.
 *
 * options: SET_OPT_CONTAINER, SET_OPT_SORT, SET_OPT_ALLOC, SET_OPT_FREE
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students must develop the entire linked-list data structure, nothing
 * less, nothing more.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ---------------------------------------------------------
 */

extern m_set*		set;

/*
 * ---------- functions -------------------------------------------------------
 */


t_error		set_type_ll(t_setid u)
{
  o_set		*o = NULL;

  SET_ENTER(set);

  if (ERROR_NONE != set_descriptor(u, &o))
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (o->type != SET_TYPE_LL)
    SET_LEAVE(set, ERROR_UNKNOWN);

  SET_LEAVE(set, ERROR_NONE);
}


t_error		set_show_ll(t_setid u)
{
  int		i = 0;
  t_iterator	iterator;
  t_state	state = ITERATOR_STATE_UNUSED;

  SET_ENTER(set);

  iterator.u.ll.node = NULL;

  set_foreach(SET_OPT_FORWARD, u, &iterator, state)
    {
      if (NULL != iterator.u.ll.node)
	printf("Node %d\n"
	       " +-> addr :  %p\n"
	       " +-> data :  %p\n"
	       " +-> prv  :  %p\n"
	       " +-> next :  %p\n",
	       i++,
	       iterator.u.ll.node,
	       iterator.u.ll.node->data,
	       iterator.u.ll.node->prv,
	       iterator.u.ll.node->nxt);
      k_getchar();
    }

  SET_LEAVE(set, ERROR_NONE);
}


t_error		set_head_ll(t_setid u, t_iterator* iterator)
 {
   o_set	*o = NULL;

   SET_ENTER(set);

   if (ERROR_NONE != set_descriptor(u, &o))
     {
       cons_msg('!', "set_head_ll : set descriptor not found\n");
       SET_LEAVE(set, ERROR_UNKNOWN);
     }

   if (NULL == iterator || NULL == o->u.ll.head)
     SET_LEAVE(set, ERROR_UNKNOWN);

   iterator->u.ll.node = o->u.ll.head;

   SET_LEAVE(set, ERROR_NONE);
}

t_error		set_tail_ll(t_setid u, t_iterator* iterator)
{
  o_set		*o = NULL;

  SET_ENTER(set);

  if (ERROR_NONE != set_descriptor(u, &o))
    SET_LEAVE(set, ERROR_UNKNOWN);

   if (NULL == iterator || o->u.ll.tail)
     SET_LEAVE(set, ERROR_UNKNOWN);

  iterator->u.ll.node = o->u.ll.tail;

  SET_LEAVE(set, ERROR_NONE);
}

t_error		set_prev_ll(t_setid	u,
			    t_iterator	current,
			    t_iterator	*previous)
{
  SET_ENTER(set);

  if (NULL == current.u.ll.node)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (NULL == previous)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (NULL == (previous->u.ll.node = current.u.ll.node->prv))
    SET_LEAVE(set, ERROR_UNKNOWN);

  SET_LEAVE(set, ERROR_NONE);
}

t_error		set_next_ll(t_setid	u,
			    t_iterator	current,
			    t_iterator* next)
{
  SET_ENTER(set);

  if (NULL ==current.u.ll.node)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (NULL == next)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (NULL == (next->u.ll.node = current.u.ll.node->nxt))
    SET_LEAVE(set, ERROR_UNKNOWN);

  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_head_ll(t_setid	u,
					   void		*data)
{
  t_set_ll_node*	new_node = NULL;
  o_set*		o = NULL;

  SET_ENTER(set);

  if (ERROR_NONE != set_descriptor(u, &o))
    {
      cons_msg('!', "set_insert_head_ll : cannot find the set descriptor\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  if (NULL == (new_node = malloc(sizeof (t_set_ll_node))))
    {
      cons_msg('!', "set_insert_head_ll : cannot alloc a new node\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  memset(new_node, 0, sizeof(t_set_ll_node));

  if (ERROR_NONE != set_alloc_object(u, &data))
    {
      cons_msg('!', "set_insert_head_ll : cannot initialize the new node\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  new_node->data = data;
  new_node->prv = NULL;
  new_node->nxt = NULL;
  o->size++;

  if (o->u.ll.head == NULL)
    {
      o->u.ll.tail = new_node;
      o->u.ll.head = new_node;
      SET_LEAVE(set, ERROR_NONE);
    }

  new_node->nxt = o->u.ll.head;
  o->u.ll.head->prv = new_node;
  o->u.ll.head = new_node;

  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_tail_ll(t_setid	u,
					   void		*data)
{
  t_set_ll_node		*new_node = NULL;
  o_set			*o = NULL;

  SET_ENTER(set);

  if (ERROR_NONE != set_descriptor(u, &o))
      SET_LEAVE(set, ERROR_UNKNOWN);

  if (NULL == (new_node = malloc(sizeof (t_set_ll_node))))
    SET_LEAVE(set, ERROR_UNKNOWN);

  memset(new_node, 0, sizeof(t_set_ll_node));

  if (ERROR_NONE != set_alloc_object(u, &data))
    SET_LEAVE(set, ERROR_UNKNOWN);

  new_node->data = data;
  new_node->prv = NULL;
  new_node->nxt = NULL;
  o->size++;

  if (o->u.ll.tail == NULL)
    {
      o->u.ll.tail = new_node;
      o->u.ll.head = new_node;
      SET_LEAVE(set, ERROR_NONE);
    }

  new_node->prv = o->u.ll.tail;
  o->u.ll.tail->nxt = new_node;
  o->u.ll.tail = new_node;

  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_before_ll(t_setid	u,
					     t_iterator iterator,
					     void	*data)
{
  t_set_ll_node*        new_node = NULL;
  o_set			*o = NULL;

  SET_ENTER(set);

  if (NULL == iterator.u.ll.node)
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (ERROR_NONE != set_descriptor(u, &o))
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (NULL == (new_node = malloc(sizeof (t_set_ll_node))))
    {
      cons_msg('!', "set_insert_before_ll : cannot malloc a new node\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  memset(new_node, 0, sizeof(t_set_ll_node));

  if (ERROR_NONE != set_alloc_object(u, &data))
    SET_LEAVE(set, ERROR_UNKNOWN);

  new_node->data = data;
  new_node->prv = iterator.u.ll.node->prv;
  new_node->nxt = iterator.u.ll.node;
  o->size++;

  if (iterator.u.ll.node->prv == NULL)
    {
      o->u.ll.head = new_node;
      iterator.u.ll.node->prv = new_node;
      SET_LEAVE(set, ERROR_NONE);
    }
  iterator.u.ll.node->prv->nxt = new_node;
  iterator.u.ll.node->prv = new_node;

  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_insert_after_ll(t_setid	u,
					    t_iterator	iterator,
					    void	*data)
{
  t_set_ll_node		*new_node = NULL;
  o_set			*o = NULL;

  SET_ENTER(set);

  if (ERROR_NONE != set_descriptor(u, &o))
    SET_LEAVE(set, ERROR_UNKNOWN);

  if (NULL != (new_node = malloc(sizeof (t_set_ll_node))))
    {
      cons_msg('!', "set_insert_after_ll : cannot malloc a new node\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  memset(new_node, 0, sizeof (t_set_ll_node));

  if (ERROR_NONE != set_alloc_object(u, &data))
    SET_LEAVE(set, ERROR_UNKNOWN);

  new_node->data = data;
  new_node->nxt = iterator.u.ll.node->nxt;
  new_node->prv = iterator.u.ll.node;
  o->size++;

  if (iterator.u.ll.node->nxt == NULL)
    {
      o->u.ll.tail = new_node;
      iterator.u.ll.node->nxt = new_node;
      SET_LEAVE(set, ERROR_NONE);
    }

  iterator.u.ll.node->nxt->prv = new_node;
  iterator.u.ll.node->nxt = new_node;

  SET_LEAVE(set, ERROR_NONE);
}

t_error		set_add_ll(t_setid u, void* data)
{
  t_iterator    iterator;
  t_id*         curid;
  t_id*         dataid;
  t_state	state = ITERATOR_STATE_UNUSED;
  o_set*	o;

  SET_ENTER(set);

  /* -- FIXE ME : CHECK SORTED -- */
  if (ERROR_NONE != set_descriptor(u, &o))
    {
      cons_msg('!', "set_add_ll: unable to find the set descriptor\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  if ((o->u.ll.opts & SET_OPT_SORT) == 0)
    SET_LEAVE(set, set_insert_head_ll(u, data));

  dataid = data;

  set_foreach(SET_OPT_FORWARD, u, &iterator, state)
    {
      if (ERROR_NONE != set_object(u, iterator, (void**)&curid))
	{
	  cons_msg('!', "set_add_ll : cannot get object\n");
	  SET_LEAVE(set, ERROR_UNKNOWN);
	}
      if (*curid > *dataid)
	{
	  SET_LEAVE(set, set_insert_before_ll(u, iterator, data));
	}
    }

  SET_LEAVE(set, set_insert_tail_ll(u, data));
}

t_error			set_remove_ll(t_setid u, t_id id)
{
  t_iterator		iterator;

  iterator.u.ll.node = NULL;

  SET_ENTER(set);

  if (ERROR_NONE != set_locate_ll(u, id, &iterator))
    {
      cons_msg('!', "set_remove_ll : cannot locate the object with "
	       "such identifier\n");
      SET_LEAVE(set, ERROR_NOT_FOUND);
    }

  if (ERROR_NONE != set_delete_ll(u, iterator))
    {
      cons_msg('!', "set_remove_ll : cannot delete the object from the set\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  SET_LEAVE(set, ERROR_NONE);
}

t_error			set_free_object(t_setid u, void *data)
{
  o_set			*o = NULL;

  if (ERROR_NONE != set_descriptor(u, &o))
    return ERROR_UNKNOWN;

  if (((o->u.ll.opts & SET_OPT_FREE) != 0 )
      || ((o->u.ll.opts & SET_OPT_ALLOC) != 0))
    free(data);

  return ERROR_NONE;
}

t_error		set_alloc_object(t_setid u, void **data)
{
  o_set*	o = NULL;
  void*		new_data = NULL;

  if (ERROR_NONE != set_descriptor(u, &o))
    return ERROR_UNKNOWN;

  if (NULL == data || NULL == *data)
    return ERROR_UNKNOWN;

  if ((o->u.ll.opts & SET_OPT_ALLOC) != 0)
    {
      if (NULL == (new_data = malloc(o->u.ll.datasz)))
	return ERROR_UNKNOWN;
      memcpy(new_data, *data, o->u.ll.datasz);
      *data = new_data;
    }
  return ERROR_NONE;
}

t_error			set_delete_ll(t_setid u, t_iterator iterator)
{
  o_set*		o = NULL;
  t_set_ll_node*        ex_node = NULL;

  SET_ENTER(set);

  if (NULL == iterator.u.ll.node
      || ERROR_NONE != set_descriptor(u, &o))
    SET_LEAVE(set, ERROR_UNKNOWN);

  ex_node = iterator.u.ll.node;
  o->size--;

  if (NULL == ex_node->prv)
    o->u.ll.head = (NULL == ex_node->nxt ? NULL : ex_node->nxt);
  else
    ex_node->prv->nxt = (NULL == ex_node->nxt ? NULL : ex_node->nxt);

  if (NULL == ex_node->nxt)
    o->u.ll.tail = (NULL == ex_node->prv ? NULL : ex_node->prv);
  else
    ex_node->nxt->prv = (NULL == ex_node->prv ? NULL : ex_node->prv);

  set_free_object(u, ex_node->data);
  free(ex_node);

  SET_LEAVE(set, ERROR_NONE);
}

t_error		set_flush_ll(t_setid u)
{
  t_state	state = ITERATOR_STATE_UNUSED;
  t_iterator    iterator;
  o_set		*obj = NULL;

  SET_ENTER(set);

  iterator.u.ll.node = NULL;

  if (ERROR_NONE != set_descriptor(u, &obj))
    {
      cons_msg('!', "set_flush_ll : cannot find this set\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  if (0 == obj->size)
    SET_LEAVE(set, ERROR_NONE);

  set_foreach(SET_OPT_FORWARD, u, &iterator, state)
    {
      if (ERROR_NONE != set_delete_ll(u, iterator))
	{
	  cons_msg('!', "set_flush_ll : cannot flush the set\n");
	  SET_LEAVE(set, ERROR_UNKNOWN);
	}
    }

  SET_LEAVE(set, ERROR_NONE);
}

t_error		set_locate_ll(t_setid u, t_id id, t_iterator* iterator)
{
  o_set*	data = NULL;
  t_state	state = ITERATOR_STATE_UNUSED;

  SET_ENTER(set);

  if (NULL == iterator)
    SET_LEAVE(set, ERROR_UNKNOWN);

  iterator->u.ll.node = NULL;

  set_foreach(SET_OPT_FORWARD, u, iterator, state)
    {
      if (ERROR_NONE != set_object_ll(u, *iterator, (void **)&data))
	SET_LEAVE(set, ERROR_UNKNOWN);

      if (id == data->setid)
	SET_LEAVE(set, ERROR_NONE);
    }

  SET_LEAVE(set, ERROR_NOT_FOUND);
  // FIXE ME : SORTED
}

t_error		set_object_ll(t_setid u, t_iterator iterator, void** data)
{
  SET_ENTER(set);

  if (NULL == iterator.u.ll.node)
    SET_LEAVE(set, ERROR_UNKNOWN);

  *data = iterator.u.ll.node->data;

  SET_LEAVE(set, ERROR_NONE);
}

t_error		set_push_ll(t_setid u, void* data)
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_NOT_AVALABLE);
}

t_error		set_pop_ll(t_setid u)
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_NOT_AVALABLE);
}

t_error		set_pick_ll(t_setid u, void** data)
{
  SET_ENTER(set);
  SET_LEAVE(set, ERROR_NOT_AVALABLE);
}

t_error		set_release_ll(t_setid u)
{
  o_set*	obj;

  SET_ENTER(set);

  if (ERROR_NONE != set_descriptor(u, &obj))
    SET_LEAVE(set, ERROR_UNKNOWN);

  if ((0 != obj->size) && (ERROR_NONE != set_flush_ll(u)))
    {
      cons_msg('!', "set_release_ll : cannot flush the set\n");
      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  if (set->container == u)
    SET_LEAVE(set, ERROR_NONE);

  if (ERROR_NONE != set_remove_ll(set->container, u))
    {
      cons_msg('!', "set_release_ll : unable to remove this descriptor "
	       "from the set container\n");

      SET_LEAVE(set, ERROR_UNKNOWN);
    }

  SET_LEAVE(set, ERROR_NONE);
}

t_error		set_reserve_ll(t_opts opts, t_size datasz, t_setid* u)
{
  o_set		new_set;

  SET_ENTER(set);

  memset(&new_set, 0, sizeof(o_set));

  if ((SET_OPT_CONTAINER & opts) > 0)
    new_set.setid = set->container;
  else
    id_reserve(&set->id, &(new_set.setid));
  *u = new_set.setid;
  new_set.type = SET_TYPE_LL;
  new_set.size = 0;
  new_set.u.ll.datasz = datasz;
  new_set.u.ll.opts = opts;
  if (ERROR_NONE != set_new(&new_set))
    SET_LEAVE(set, ERROR_UNKNOWN);

  SET_LEAVE(set, ERROR_NONE);
}
