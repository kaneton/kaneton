/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/segment/segment-fit.c
 *
 * created       matthieu bucchianeri   [tue jan 10 01:03:46 2006]
 * updated       matthieu bucchianeri   [tue jan 31 00:20:33 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file implements simple  fitting algorithms for physical memory
 * management.
 *
 * you can define which algorithm to use with the macro SEGMENT_FIT.
 *
 *  - FIT_FIRST: first fit algorithm - the first large enough space is taken
 *  - FIT_BEST: best fit algorithm - the smaller space is taken
 *  - ...
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  have  to develop  at  least  the  first-fit algorithm  to
 * allocate physical memory.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

extern m_segment*	segment;

/*
 * ---------- functions -------------------------------------------------------
 */


#define	PAGEMASK	(PAGESZ - 1)

#define	ALIGN(_x_)	((_x_ + PAGEMASK) & ~(PAGEMASK))

/*
 * Search the given address space for a segment of given size
 */
t_error			segment_fit(t_psize	size,
				    t_paddr*	address)
{
  t_state		state = ITERATOR_STATE_UNUSED;
  t_iterator		it;

  o_segment		*seg1 = NULL;
  o_segment		*seg2 = NULL;

  SEGMENT_ENTER(segment);

  *address = 0;

  if (ERROR_NONE != set_head(segment->container, &it))
    {
      /* 0 element */
      if (size > segment->size)
	{
	  cons_msg('!', "segment_fit : no enough memory\n");
	  SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
	}
      *address = ALIGN(segment->start);
      SEGMENT_LEAVE(segment, ERROR_NONE);
    }

  set_foreach(SET_OPT_FORWARD, segment->container, &it, state)
    {
      if (ERROR_NONE != set_object(segment->container, it, (void**)&seg2))
	{
	  cons_msg('!', "segment_fit : cannot get the object\n");
	  SEGMENT_LEAVE(segment, ERROR_NONE);
	}
      if (NULL == seg1)
	{
	  /* Some space before the first elm ? */
	  if (size <= seg2->address - ALIGN(segment->start))
	    {
	      *address = ALIGN(segment->start);
	      SEGMENT_LEAVE(segment, ERROR_NONE);
	    }
	}
      else
	{
	  /* Some space between seg1 and seg2 ? */
	  if (size <= seg2->address - seg1->address - ALIGN(seg1->size))
	    {
	      *address = ALIGN(seg1->address) + ALIGN(seg1->size);
	      SEGMENT_LEAVE(segment, ERROR_NONE);
	    }
	}
      seg1 = seg2;
    }

  /* Some space after the last segment ? */
  if (size <= ALIGN(segment->start) + segment->size
      - ALIGN(seg2->address) - ALIGN(seg2->size))
    {
      *address = ALIGN(seg2->address) + ALIGN(seg2->size);
      SEGMENT_LEAVE(segment, ERROR_NONE);
    }

  SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
}
