/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/bootloader/arch/ia32-virtual/bootloader.h
 *
 * created       julien quintard   [fri feb 11 02:23:53 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:20:27 2006]
 */

#ifndef BOOTLOADER_H
#define BOOTLOADER_H		1

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      bootloader.c
 *      cons.c
 *      init.c
 *      paging.c
 *      pmode.c
 */

/*
 * bootloader.c
 */

int			bootloader(t_uint32			magic,
				   multiboot_info_t*		mbi);

int			_debug_multiboot_info(multiboot_info_t*		mbi);


/*
 * cons.c
 */

void				bl_debug_console(void);

void			bl_console_init(void);

int			bl_console_print_char_simple(char	c);

void			bl_console_update_attribute(u_int8_t	attr);

t_uint8			k_console_fseek(short		shift);


/*
 * init.c
 */

t_segid                 install_segment_form_init(void);

t_regid                 install_region_from_init(void);

int			bl_init_init(multiboot_info_t*		mbi);

void			bl_debug_print_module(void);

void			bl_debug_print_init(void);


/*
 * paging.c
 */

void		bl_paging_init(t_paddr *paging_area_paddr,
			       t_size  paging_area_size);

void		bl_paging_activate(void);

void		bl_paging_region_fill(void);


/*
 * pmode.c
 */


/*
 * eop
 */

#endif
