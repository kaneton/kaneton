/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/bootloader/arch/ia32-virtual/paging.c
 *
 * created       julien quintard   [sun may 29 00:38:50 2005]
 * updated       Jerome Herbault   [tue feb 21 10:45:34 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * these function just install the paging mode to enable virtual memory
 * which is required by the kaneton kernel.
 *
 * think about mapping everything needed: kernel code, kernel stack, init
 * structure etc..
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the init variable.
 */

extern t_init*			init;


/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Initialisation of the paging in the bootloader
 */
void		bl_paging_init(t_paddr *paging_area_paddr,
			       t_size  paging_area_size)
{
  printf(COLOR(RED)"-== [ PAGING INIT ] ==-\n"COLOR(WHITE));

  ia32_paging_init(paging_area_paddr, paging_area_size);

  bl_paging_region_fill();

  //  ia32_paging_debug();
}

void		bl_paging_activate(void)
{
  // Passer en mode Pagin�
  asm("movl %0, %%eax		\n\t"
      "movl %%eax, %%cr3	\n\t"

      "movl %%cr0, %%eax	\n\t"
      "orl $0x80000000, %%eax	\n\t"
      "movl %%eax, %%cr0	\n\t"
      :
      : "g"(init->machdep.paging)
      : "%eax"
      );


}

/*
 * Alloc and fill up the page directory
 * and page tables thanks to the regions definitions
 */
void		bl_paging_region_fill(void)
{
  o_segment	*psegment = 0;
  t_uint32	nsegments = 0;
  t_uint32	i = 0;
  t_flags	flags = 0;

  psegment = init->segments;
  nsegments = init->nsegments;

  flags = IA32_PAGING_PAGE_RDWR | IA32_PAGING_PAGE_SUPERVISOR;

  for (; i < nsegments; ++i, ++psegment)
    {
      ia32_paging_alloc_pages(psegment->address,
			      psegment->address,
			      psegment->size,
			      flags);
    }
}
