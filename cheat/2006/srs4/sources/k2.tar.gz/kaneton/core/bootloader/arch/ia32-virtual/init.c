/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/bootloader/arch/ia32-virtual/init.c
 *
 * created       julien quintard   [mon jul 19 20:43:14 2004]
 * updated       Jerome Herbault   [fri mar 24 04:49:50 2006]
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this file contains the functions intended to do the relocation.
 *
 * this file is very important because it does the most important things
 * of the bootloader: computes segments and regions, relocates data, creates
 * the init structure etc..
 *
 * the relocation is based on dynamic allocation. nevertheless, no dynamic
 * allocation is provided. the student so has to setup a very simple dynamic
 * memory allocation algorithm to be able to build the init structure.
 *
 * think about it because some components cannot have a dynamic address. there
 * are some crazy problems to resolve in this context.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "bootloader.h"

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * init variable, describing the initial memory layout.
 *
 * this structure will be passed to the kernel describing modules,
 * physical memory reserved by the hardware etc.. thus the kernel will
 * be able to initialise its managers: segment manager, module manager etc..
 */

t_init*			init;

/*
 * ---------- functions -------------------------------------------------------
 */

/* ***************** STUDENT CODE START HERE ** (herbau_j) ******************/

static t_psize		_init_kmove(multiboot_info_t*		mbi,
				    t_paddr			kcode)
{
  module_t		*kernel_mod	= (module_t *) mbi->mods_addr;
  t_psize		sz		= (t_psize) kernel_mod->mod_end - (t_psize) kernel_mod->mod_start;

  memcpy((char *) kcode,
	 (char *) kernel_mod->mod_start,
	 sz);
  return sz;
}

static t_psize		_init_modmove(multiboot_info_t*		mbi,
				      t_paddr			modules_start)
{
  unsigned int		strsz;
  unsigned int		i;
  module_t              *mod     = (module_t *) mbi->mods_addr;
  t_modules		*modules = (t_modules *) modules_start;
  t_module		*module  = (t_module *) (modules_start + sizeof (t_modules));
  char			*modzone = NULL;

  modules->nmodules = mbi->mods_count - 1;
  modzone = (char *) (modules_start + sizeof (t_modules) + modules->nmodules * sizeof (t_module));
  mod++; /*ignore kernel*/
  for (i = 1; i < mbi->mods_count; i++)
    {
      strsz = strlen((char *) mod->string);
      module->size = mod->mod_end - mod->mod_start;
      module->name = (char *) (modzone + module->size);
      /*Copying mod data*/
      memcpy((char *) modzone, (char *) mod->mod_start, module->size);
      /*Copying name data*/
      memcpy((char *) module->name, (char *) mod->string, strsz + 1);
      /*setting new step values*/
      modzone = modzone + module->size + strsz + 1; /*moving to next module zone*/
      mod++; /*seek for next grub module*/
      module++; /*moving to next module descriptor*/
    }

  return (t_psize) (modzone - modules_start);
}

/* ---- BEGIN OF SEGMENT INIT ---- */
/*
** Find out for all permissions
**
**
*/
static t_segid          segment_fit_nullpage(o_segment *segments,
                                             t_segid segid,
                                             t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = 0;
  segments->size     = IA32_PAGING_PAGE_SIZE;
  segments->perms    = 0;
  return segid + 1;
}

static t_segid          segment_fit_ISA(o_segment *segments,
                                        t_segid segid,
                                        t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = 0x1000;
  segments->size     = 0xff000;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}

/* static t_segid          segment_fit_VGA(o_segment *segments, */
/*                                         t_segid segid, */
/*                                         t_asid asid) */
/* { */
/*   segments->segid    = segid; */
/*   segments->asid     = asid; */
/*   segments->type     = 0; */
/*   segments->address  = 0xB8000; */
/*   segments->size     = 2 * 80 * 25; */
/*   segments->perms    = PERM_READ | PERM_WRITE; */
/*   return segid + 1; */
/* } */

static t_segid          segment_fit_bootloader(o_segment *segments,
					       t_segid segid,
					       t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = 0x200000;
  segments->size     = 0x200000;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}


static t_segid          segment_fit_kcode(o_segment *segments,
                                          t_segid segid,
                                          t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = init->kcode;
  segments->size     = init->kcodesz;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}

static t_segid          segment_fit_init(o_segment *segments,
                                         t_segid segid,
                                         t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = init->init;
  segments->size     = init->initsz;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}


static t_segid          segment_fit_modules(o_segment *segments,
                                            t_segid segid,
                                            t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = (t_paddr) init->modules;
  segments->size     = (t_psize) init->modulessz;
  segments->perms    = PERM_READ;
  return segid + 1;
}

static t_segid          segment_fit_segments(o_segment *segments,
                                             t_segid segid,
                                             t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = (t_paddr) init->segments;
  segments->size     = (t_psize) init->segmentssz;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}

static t_segid          segment_fit_regions(o_segment *segments,
                                            t_segid segid,
                                            t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = (t_paddr) init->regions;
  segments->size     = (t_psize) init->regionssz;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}

static t_segid          segment_fit_kstack(o_segment *segments,
                                           t_segid segid,
                                           t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = (t_paddr) init->kstack;
  segments->size     = (t_psize) init->kstacksz;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}

static t_segid          segment_fit_alloc(o_segment *segments,
                                          t_segid segid,
                                          t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = init->alloc;
  segments->size     = init->allocsz;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}

static t_segid          segment_fit_gdt(o_segment *segments,
                                        t_segid segid,
                                        t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = init->machdep.gdt;
  segments->size     = init->machdep.gdtr.limit;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}

static t_segid          segment_fit_idt(o_segment *segments,
                                        t_segid segid,
                                        t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = init->machdep.idt;
  segments->size     = init->machdep.idtr.limit;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}

static t_segid          segment_fit_pd(o_segment *segments,
                                       t_segid segid,
                                       t_asid asid)
{
  segments->segid    = segid;
  segments->asid     = asid;
  segments->type     = 0;
  segments->address  = init->machdep.paging;
  segments->size     = init->machdep.pagingsz;
  segments->perms    = PERM_READ | PERM_WRITE;
  return segid + 1;
}


/* ---- END OF SEGMENT INIT ---- */
/* ---- BEGIN OF REGION INIT ---- */

static t_regid          region_fit_ISA(o_region *regions,
                                       t_regid regid,
                                       t_segid segid)
{
  regions->regid        = regid;
  regions->segid        = segid;
  regions->address      = 0x1000;
  regions->offset       = 0x1000;
  regions->size         = 0xff000;
  return regid + 1;
}

/* static t_regid          region_fit_VGA(o_region *regions, */
/*                                        t_regid regid, */
/*                                        t_segid segid) */
/* { */
/*   regions->regid        = regid; */
/*   regions->segid        = segid; */
/*   regions->address      = 0xB8000; */
/*   regions->offset       = 2 * 80 * 25; */
/*   regions->size         = 0x100000; */
/*   return regid + 1; */
/* } */

static t_segid          region_fit_bootloader(o_region *regions,
                                               t_regid regid,
                                               t_segid segid)
{
  regions->regid        = regid;
  regions->segid        = segid;
  regions->address      = (t_vaddr) 0x200000;
  regions->offset       = regions->address;
  regions->size         = 0x200000;
  return regid + 1;
}


static t_regid             region_fit_kcode(o_region *regions,
                                            t_regid regid,
                                            t_segid segid)
{
  regions->regid        = regid;
  regions->segid        = segid;
  regions->address      = (t_vaddr) init->kcode;
  regions->offset       = regions->address;
  regions->size         = init->kcodesz;
  return regid + 1;
}

static t_regid             region_fit_init(o_region *regions,
                                           t_regid regid,
                                           t_segid segid)
{
  regions->regid        = regid;
  regions->segid        = segid;
  regions->address      = (t_vaddr) init->init;
  regions->offset       = regions->address;
  regions->size         = init->initsz;
  return regid + 1;
}

static t_regid             region_fit_kstack(o_region *regions,
                                             t_regid regid,
                                             t_segid segid)
{
  regions->regid        = regid;
  regions->segid        = segid;
  regions->address      = (t_vaddr) init->kstack;
  regions->offset       = regions->address;
  regions->size         = init->kstacksz;
  return regid + 1;
}

static t_regid             region_fit_alloc(o_region *regions,
                                            t_regid regid,
                                            t_segid segid)
{
  regions->regid        = regid;
  regions->segid        = segid;
  regions->address      = (t_vaddr) init->alloc;
  regions->offset       = regions->address;
  regions->size         = init->allocsz;
  return regid + 1;
}

static t_regid             region_fit_gdt(o_region *regions,
                                          t_regid regid,
                                          t_segid segid)
{
  regions->regid        = regid;
  regions->segid        = segid;
  regions->address      = init->machdep.gdt;
  regions->offset       = regions->address;
  regions->size         = init->machdep.gdtr.limit;
  return regid + 1;
}


static t_regid             region_fit_idt(o_region *regions,
                                          t_regid regid,
                                          t_segid segid)
{
  regions->regid        = regid;
  regions->segid        = segid;
  regions->address      = init->machdep.idt;
  regions->offset       = regions->address;
  regions->size         = init->machdep.idtr.limit;
  return regid + 1;
}

static t_regid             region_fit_pd(o_region *regions,
                                         t_regid regid,
                                         t_segid segid)
{
  regions->regid        = regid;
  regions->segid        = segid;
  regions->address      = init->machdep.paging;
  regions->offset       = regions->address;
  regions->size         = init->machdep.pagingsz;
  return regid + 1;
}



/* static t_regid             region_fit_modules(o_region *regions, */
/* 					      t_regid regid, */
/* 					      t_segid segid) */
/* { */
/*   regions->regid        = regid; */
/*   regions->segid        = segid; */
/*   regions->address      = (t_vaddr)init->modules; */
/*   regions->offset       = regions->address; */
/*   regions->size         = init->modulessz; */
/*   return regid + 1; */
/* } */

/* static t_regid             region_fit_segments(o_region *regions, */
/* 					       t_regid regid, */
/* 					       t_segid segid) */
/* { */
/*   regions->regid        = regid; */
/*   regions->segid        = segid; */
/*   regions->address      = (t_vaddr)init->segments; */
/*   regions->offset       = regions->address; */
/*   regions->size         = init->segmentssz; */
/*   return regid + 1; */
/* } */

/* static t_regid             region_fit_regions(o_region *regions, */
/* 					     t_regid regid, */
/* 					     t_segid segid) */
/* { */
/*   regions->regid        = regid; */
/*   regions->segid        = segid; */
/*   regions->address      = (t_vaddr)init->regions; */
/*   regions->offset       = regions->address; */
/*   regions->size         = init->regionssz; */
/*   return regid + 1; */
/* } */

t_segid                 install_segment_form_init(void)
{
  t_segid               i = 0;
  o_segment             *segments = init->segments;

  i = segment_fit_bootloader    (&segments[i], i, 0);
  //i = segment_fit_VGA		(&segments[i], i, 0);
  i = segment_fit_nullpage      (&segments[i], i, 0);
  i = segment_fit_ISA           (&segments[i], i, 0);
  i = segment_fit_kcode         (&segments[i], i, 0);
  i = segment_fit_init          (&segments[i], i, 0);
  i = segment_fit_modules       (&segments[i], i, 0);
  i = segment_fit_segments      (&segments[i], i, 0);
  i = segment_fit_regions       (&segments[i], i, 0);
  i = segment_fit_kstack        (&segments[i], i, 0);
  i = segment_fit_alloc         (&segments[i], i, 0);
  i = segment_fit_gdt           (&segments[i], i, 0);
  i = segment_fit_idt           (&segments[i], i, 0);
  i = segment_fit_pd            (&segments[i], i, 0);
  return i /*- 1 maggouille a cause du booloader ...11->12 seg*/;
}

t_regid                 install_region_from_init(void)
{
  t_regid               i = 0;
  o_region              *regions = init->regions;

  i = region_fit_bootloader	(&regions[i], i, 0);
  //i = region_fit_VGA		(&regions[i], i, 0);
  /* ADDED un respectfully */
/*   i = region_fit_modules        (&regions[i], i, 0); */
/*   i = region_fit_segments       (&regions[i], i, 0); */
/*   i = region_fit_regions        (&regions[i], i, 0); */

  i = region_fit_ISA		(&regions[i], i, 0);
  i = region_fit_kcode		(&regions[i], i, 0);
  i = region_fit_init		(&regions[i], i, 0);
  i = region_fit_kstack		(&regions[i], i, 0);
  i = region_fit_alloc		(&regions[i], i, 0);
  i = region_fit_gdt		(&regions[i], i, 0);
  i = region_fit_idt		(&regions[i], i, 0);
  i = region_fit_pd		(&regions[i], i, 0);
  return i;
}


/* ---- END OF REGION INIT ---- */


int			bl_init_init(multiboot_info_t*		mbi)
{
  init = (t_init *) (0x1000000);

  init->mem = mbi->mem_lower * 0x400;
  init->memsz = ((mbi->mem_upper + 0X400) * 0x400) - init->mem;

  init->init = 0x1000000;
  init->initsz = sizeof(t_init);

  init->kcode = init->init + (((init->initsz -1) / 4096) + 1) * 4096;
  init->kcodesz = _init_kmove(mbi, init->kcode);

  init->modules =
    (t_modules *)
    (init->kcode + (((init->kcodesz -1) / 4096) + 1) * 4096);
  init->modulessz = _init_modmove(mbi, (t_paddr) init->modules);

  init->nsegments = INIT_SEGMENTS;
  init->segments =
    (o_segment *)
    (((t_paddr)init->modules) + (((init->modulessz -1) / 4096) + 1) * 4096);
  init->segmentssz = init->nsegments * sizeof(o_segment);

  init->nregions = INIT_REGIONS;
  init->regions =
    (o_region *)
    (((t_paddr)init->segments) + (((init->segmentssz -1) / 4096) + 1) * 4096);
  init->regionssz = init->nregions * sizeof(o_region);

  init->kstack =
    (((t_paddr)init->regions) + (((init->regionssz -1) / 4096) + 1) * 4096);
  init->kstacksz = INIT_KSTACKSZ; // = 1 page : Don't know if right

  init->alloc =
    init->kstack + (((init->kstacksz -1) / 4096) + 1) * 4096;
  init->allocsz = INIT_ALLOCSZ; // = 1 page : Don't know if right

  init->machdep.gdt = init->alloc + ((((init->allocsz - 1) / 4096) + 1)* 4096);
  // la gdt ne peut pas prendre plus d'une page
  init->machdep.idt = init->machdep.gdt + 4096;

  // la idt ne peut pas prendre plus d'une page
  init->machdep.paging = init->machdep.idt + 4096;
  init->machdep.pagingsz = 0x5000; /* Taille de 5 pages : arbitraire ... resize a prevoire FIXEME*/

  return 0;
}

void			bl_debug_print_module(void)
{
  int			i;
  t_module		*mod = (t_module *) (((int) init->modules) + sizeof (t_modules));

  printf("===| Debug : Printing module |===\n");
  printf("modules :\t0x%x\n", init->modules);
  printf("modulessz :\t0x%x\n", init->modulessz);
  printf("module numbers :\t%i\n", init->modules->nmodules);
  for (i = 0; i < init->modules->nmodules; i++)
    {
      printf("[%i] module name : %s (%d)\n",
	     i, mod[i].name, mod[i].size);
    }
}


void			bl_debug_print_init(void)
{
  printf("===| Debug : Printing Init |===\n");

  printf("mem :\t\t0x%p\t\t", init->mem);
  printf("memsz :\t\t%dMo\n", init->memsz / 0x100000);

  printf("init :\t\t0x%x\t", init->init);
  printf("initsz :\t0x%x\n", init->initsz);

  printf("kcode :\t\t0x%x\t", init->kcode);
  printf("kcodesz :\t0x%x\n", init->kcodesz);

  printf("modules :\t0x%x\t", init->modules);
  printf("modulessz :\t0x%x\n", init->modulessz);

  printf("segments :\t0x%x\t", init->segments);
  printf("segmentssz :\t0x%x\t", init->segmentssz);
  printf("nsegments :\t%d\n", init->nsegments);

  printf("regions :\t0x%x\t", init->regions);
  printf("regionssz :\t0x%x\t", init->regionssz);
  printf("nregions :\t%d\n", init->nregions);

  printf("kstack :\t0x%x\t", init->kstack);
  printf("kstacksz :\t0x%x\n", init->kstacksz);

  printf("alloc :\t\t0x%x\t", init->alloc);
  printf("allocsz :\t0x%x\n", init->allocsz);

  printf("gdt :\t\t0x%x\t", init->machdep.gdt);
}


/* ***************** STUDENT CODE STOP  HERE ** (herbau_j) ******************/
