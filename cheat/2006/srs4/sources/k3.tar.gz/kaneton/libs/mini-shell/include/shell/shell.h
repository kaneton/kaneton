/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/mini-shell/include/shell/shell.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [fri mar 24 02:52:49 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef MINI_SHElL_SHELL_H
#define MINI_SHELL_SHELL_H	1

#include <shell/clock.h>

/*
 * ---------- definitions -----------------------------------------------------
 */

#define		MS_MAX_LINE_SIZE		256


#
/*
 * ---------- prototypes ------------------------------------------------------
 *
 *	../../shell/shell.c
 *	../../shell/readline.c
 *	../../shell/clock.c
 *
 */

/*
 * ../../shell/shell.c
 */

void				ms_mini_shell(void);


/*
 * ../../shell/readline.c
 */

void		ms_shell_readline(char *line);


/*
 * ../../shell/clock.c
 */

t_time				ms_gettime(void);

t_date				ms_getdate(void);


/*
 * eop
 */

#endif
