/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/mini-shell/commands/commands.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [sat mar 25 15:16:25 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <mini-shell.h>
#include <kaneton.h>

static t_ms_commands		_cmd_tab[] =
  {
    {
      "default",
      0,
      "Mini-shell helper V1.0\n"
      "Commands categories:\n"
      "  Managers\n"
      "  Services \n"
      "  Misc\n"
    },
    {
      "help",
      ms_cmd_help,
      "Usage: help <category|command>\n"
      "Display help for the selected category or command\n"
    },
    {
      "loadkeys",
      ms_cmd_loadkeys,
      "Change the current system keyboard's keymap\n"
    },
    {
      "now",
      ms_cmd_now,
      "Display current time.\n"
    },
    {
      "", 0, ""
    }
  };

/*
 * ---------- functions -------------------------------------------------------
 */

t_uint16		ms_exec_cmd(t_uint8		argc,
				    const char		*cmd,
				    t_uint16		last_return_code)
{
  int i;

  for (i = 0; strlen(_cmd_tab[i].cmd) != 0; i++)
    {
      if (strcmp(cmd, _cmd_tab[i].cmd) == 0)
	return _cmd_tab[i].func(argc, cmd + 256, cmd + 512, cmd + 768);
    }
  printf("%s: Command not Found.\n", cmd);
  return last_return_code;
}


t_uint16		ms_cmd_help(int			argc,
				    const char		*cat)
{
  int i;

  if (argc == 0)
    {
      printf("%s", _cmd_tab[0].help_msg);
      return 0;
    }
  else if (argc > 1)
    return 1;

  for (i = 0; strlen(_cmd_tab[i].cmd) != 0; i++)
    {
      if (strcmp(cat, _cmd_tab[i].cmd) == 0)
	{
	  printf("%s", _cmd_tab[i].help_msg);
	  return 0;
	}
    }
  printf("help: No entry for this category.");
    return 1;
}
