/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/mini-shell/include/commands/commands.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat mar 25 06:06:36 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef MINI_SHElL_COMMANDS_H
#define MINI_SHELL_COMMANDS_H	1

/*
 * ---------- definitions -----------------------------------------------------
 */

typedef struct
{
  char			cmd[256];
  t_uint16		(*func)(int argc, ...);
  char			help_msg[764];
} __attribute__ ((__packed__)) t_ms_commands;


#
/*
 * ---------- prototypes ------------------------------------------------------
 *
 *	../../commands/commands.c
 *      ../../commands/misc.c
 *
 */

/*
 * ../../commands/commands.c
 */

t_uint16		ms_exec_cmd(t_uint8		argc,
				    const char		*cmd,
				    t_uint16		last_return_code);

t_uint16		ms_cmd_help(int			argc,
				    const char		*cat);


/*
 * ../../commands/misc.c
 */

t_uint16		ms_cmd_now(int			argc);

t_uint16		ms_cmd_loadkeys(int		argc,
					char		*map_str);


/*
 * eop
 */

#endif
