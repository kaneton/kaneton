/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/mini-shell/shell/shell.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:44:58 2005]
 * updated       Jerome Herbault   [sat mar 25 03:21:42 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <mini-shell.h>
#include <kaneton.h>

static t_uint16		_return_code = 0;
static t_bool		_is_done = FALSE;

/*
 * ---------- functions -------------------------------------------------------
 */

static void			_print_time(void)
{
  t_time		now;

  now = ms_gettime();

  printf("%d:%d:%d", now.hour, now.min, now.sec);
}

static void			_print_prompt(void)
{
  printf("[Kaneton][");
  _print_time();
  printf("]$ ");
}


static t_uint8			_decode_cmd(const char		*cmd_line,
					    char		*cmds)
{
  t_uint16	i, j, k;

  if (strlen(cmd_line) == 0)
    return 0;
     memset(cmds, '\0', MS_MAX_LINE_SIZE * 4);
  for (i = 0, j = 0;
       j < 5 && i < MS_MAX_LINE_SIZE && cmd_line[i] != '\0';
       j++)
    {
      k = 0;
      while (cmd_line[i] == ' ' || cmd_line[i] == '\t')
	i++;
      while (cmd_line[i] != ' ' && cmd_line[i] != '\t' )
	if (cmd_line[i] == '\0')
	    break;
	else
	  if (k < 255)
	    cmds[j * MS_MAX_LINE_SIZE + k++] = cmd_line[i++];
    }
  return j;
}

static void			_exec(const char		*cmd_line)
{
  char		cmds[1024];
  t_uint8	argc;

  argc = _decode_cmd(cmd_line, cmds);
  if (argc == 0)
    return;
  else
    _return_code = ms_exec_cmd(argc - 1, cmds, _return_code);
}


void				ms_mini_shell(void)
{
  char		cmd_line[256];

  while (!_is_done)
    {
      memset(cmd_line, 0, 256);
      _print_prompt();
      ms_shell_readline(cmd_line);
      _exec(cmd_line);
    }
  _is_done = FALSE;
}
