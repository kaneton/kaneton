/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/mini-shell/include/mini-shell.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [wed mar 22 08:47:16 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef MINI_SHELL_H
#define MINI_SHELL_H	1

/*
 * ---------- includes --------------------------------------------------------
 */

#include <shell/shell.h>
#include <commands/commands.h>

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *
 */

/*
 * eop
 */

#endif
