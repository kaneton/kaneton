/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/klibc/libstring/strcat.c
 *
 * created       julien quintard   [fri feb 11 02:56:44 2005]
 * updated       Jerome Herbault   [sat feb 11 11:30:42 2006]
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>

/*
 * ---------- functions -------------------------------------------------------
 */

char*			strcat(char*				s,
			       const char*			append)
{
  u_int			i;

  for (i = 0; s[i]; i++)
    ;

  for (; *append; i++, append++)
    s[i] = *append;
  s[i] = 0;

  return (s);
}
