/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/paging/pt.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:48 2005]
 * updated       Jerome Herbault   [sat feb 18 05:01:14 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page tables.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to place here everything dealing with page tables. no
 * restrictions apply on this file.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * Init a page table
 */
void 		ia32_paging_pt_init(t_pt_entry* pt_paddr)
{
  t_uint32	ind = 0;
  t_uint32	entry_nb = PAGESZ / IA32_PAGING_PTE_SIZE;

  *pt_paddr = UNSET_PAGE_FREE(*pt_paddr);

  for (; ind < entry_nb; ++ind, ++pt_paddr)
    *pt_paddr = UNSET_PAGE_PRESENT(*pt_paddr);

}

/*
 * Clean a page table
 */
void 		ia32_paging_pt_clean(t_pt_entry* pt_paddr)
{
  t_uint32	ind = 0;
  t_uint32	entry_nb = PAGESZ / IA32_PAGING_PTE_SIZE;

  for (; ind < entry_nb; ++ind, ++pt_paddr)
    *pt_paddr = 0;
}

/*
 * alloc a new page
 * if the table does not exist, this
 * function create it
 */
t_error		ia32_paging_pte_alloc(t_pt_entry* pt_paddr,
				      t_vaddr vaddr,
				      t_paddr paddr,
				      t_flags flags)
{
  t_pt_entry	*pte_addr = 0;

  if (TRUE == GET_PAGE_FREE_STATUS(*pt_paddr))
    ia32_paging_pt_init (pt_paddr);

  pte_addr = pt_paddr + GET_PTE_INDEX(vaddr);

  if (TRUE == GET_PAGE_PRESENT_STATUS(*pte_addr))
    return ERROR_UNKNOWN;

  *pte_addr = (paddr & 0xFFFFF000)|(*pte_addr & 0x0E00);
  *pte_addr |= (flags & 0x01FF);
  *pte_addr = SET_PAGE_PRESENT(*pte_addr);

  return ERROR_NONE;
}

/*
 * Free the page of physic address vaddr
 */
t_error		ia32_paging_pte_free(t_pt_entry* pt_paddr,
				     t_vaddr vaddr)
{
  t_pt_entry	*pte_addr = 0;

  if (TRUE == GET_PAGE_FREE_STATUS(*pt_paddr))
    return ERROR_UNKNOWN;

  pte_addr = pt_paddr + GET_PTE_INDEX(vaddr);

  if (FALSE == GET_PAGE_PRESENT_STATUS(*pte_addr))
    return ERROR_UNKNOWN;

  *pte_addr = UNSET_PAGE_PRESENT(*pte_addr);
  return ERROR_NONE;
}

/*
 * Debug
 */
void		ia32_paging_pt_debug(t_pt_entry *pte_paddr, t_uint32 pde_ind)
{
  t_uint32	ind = 0;
  t_uint32	entry_nb = PAGESZ / IA32_PAGING_PDE_SIZE;

  t_vaddr	vaddr = 0;
  t_paddr	paddr = 0;
  char		dpl   = '?';
  char		rw    = '?';
  char		intensity = 0;

  char head[] =
    "+----------+----------+------+------+----------+-----+-----+";

  printf(COLOR(WHITE)"%s\n", head);
  printf(COLOR(WHITE)"|"ICOLOR(WHITE)"  VADDR   "COLOR(WHITE)"|"
	 ICOLOR(WHITE)"   PADDR  "COLOR(WHITE)"|"ICOLOR(WHITE)
	 "  PDE "COLOR(WHITE)"|"ICOLOR(WHITE)"  PTE "COLOR(WHITE)
	 "|"ICOLOR(WHITE)" PTE ADDR "COLOR(WHITE)"|"ICOLOR(WHITE)
	 " U/S "COLOR(WHITE)"|"ICOLOR(WHITE)" R/W "COLOR(WHITE)"|\n");
  printf("%s\n", head);

  for (; ind < entry_nb; ++ind, ++pte_paddr)
    {
      if (TRUE == GET_PAGE_PRESENT_STATUS(*pte_paddr))
	{
	  paddr = (t_paddr)(*pte_paddr & 0xFFFFF000);
	  vaddr = (t_vaddr)((pde_ind << 22)|(ind << 12));
	  dpl = (GET_PAGE_USER_STATUS(*pte_paddr) ? 'U' : 'S');
	  rw = (GET_PAGE_RDWR_STATUS(*pte_paddr) ? 'W' : 'R');
	  if (0 == (++intensity % 2))
	    {
	      printf(COLOR(WHITE)"|"ICOLOR(WHITE)" %08x "COLOR(WHITE)"|"
		     ICOLOR(WHITE)" %08x "COLOR(WHITE)"|"ICOLOR(WHITE)" %4i "
		     COLOR(WHITE)"|"ICOLOR(WHITE)" %4i "COLOR(WHITE)"|"
		     ICOLOR(WHITE)" %08x "COLOR(WHITE)"|"ICOLOR(WHITE)
		     "  %c  "COLOR(WHITE)"|"ICOLOR(WHITE)"  %c  "COLOR(WHITE)"|\n",
		     vaddr, paddr, pde_ind, ind, pte_paddr, dpl, rw);
	    }
	  else
	    {
	      printf(COLOR(WHITE)"| %08x | %08x | %4i | %4i | %08x |  %c  |  %c  |\n",
		     vaddr, paddr, pde_ind, ind, pte_paddr, dpl, rw);
	    }
	  printf("%s\n", head);
	}
    }
}
