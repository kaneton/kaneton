/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/include/interrupt/interrupt.h
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [wed mar  8 11:15:09 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * protected mode structures and defines.
 *
 */

#ifndef IA32_IA32_INTERRUPT_H
#define IA32_IA32_INTERRUPT_H	1

/*
 * ---------- definitions -----------------------------------------------------
 */


#define IDT_DPL_KERN		0x0 // 00 (P=1, DPL = 0, S = 1)
#define IDT_DPL_USER		0x3 // 11 (P=1, DPL = 3, S = 1)

#define IDT_TASK_FLAGS		0x8500 // 1..0 0101 .... ....
#define IDT_INTERRUPT_FLAGS	0x8e00 // 1..0 1110 000. ....
#define IDT_TRAP_FLAGS		0x8f00 // 1..0 1111 000. ....

#define IDT_MAX_ENTRY		256

#define INT_IRQ_VECTOR		0x20

typedef t_uint16 t_idt_pos;

typedef struct
{
  t_uint16		offset_0;
  t_uint16		seg_select;
  t_uint16		flags;
  t_uint16		offset_16;

} __attribute__((__packed__)) t_idt;

typedef struct
{
  t_uint16			limit;
  t_uint32			base;
} __attribute__((__packed__))	d_idtr;


typedef struct
{
  t_uint32	cr4;
  t_uint32	cr3;
  t_uint32	cr2;
  t_uint32	cr0;
  t_uint32	gs;
  t_uint32	fs;
  t_uint32	es;
  t_uint32	ds;
  t_uint32	ss;
  t_uint32	eax;
  t_uint32	ebx;
  t_uint32	ecx;
  t_uint32	edx;
  t_uint32	esi;
  t_uint32	edi;
  t_uint32	ebp;
  t_uint32	error_code;
  t_uint32	eip;
  t_uint16	cs;
  t_uint16	nothing_2;
} __attribute__ ((__packed__))	t_cpustate;

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *
 *	../../interrupt/interrupt.c
 *	../../interrupt/idt.c
 *	../../interrupt/pic.c
 *	../../interrupt/io.c
 *	../../interrupt/pit.c
 *	../../interrupt/keyboard.c
 *
 */

/*
 * ../../interrupt/interrupt.c
 */

t_error		ia32_build_standart_idt(d_idtr			*idtr);

void		ia32_activate_interruptions(d_idtr		*idtr);

void		ia32_desactivate_interruptions(void);

t_uint8		ia32_is_interruption_active(void);

t_cpustate	*ia32_no_error_code_exception_handler(t_uint32	int_code,
						     t_cpustate *cpu_state);

t_cpustate	*ia32_error_code_exception_handler(t_uint32	int_code,
						  t_cpustate	*cpu_state);

void		ia32_master_irq_handler(t_uint32		int_code);

void		ia32_slave_irq_handler(t_uint32		int_code);


/*
 * ../../interrupt/idt.c
 */

void		ia32_idt_init(t_uint32			idt,
			      d_idtr			*idtr);

t_gdt_pos	ia32_idt_edit_entry(t_gdt_pos		pos,
				    t_uint32		offset,
				    t_uint16		segment,
				    t_uint16		flags,
				    t_uint8		dpl,
				    d_idtr		*idtr);

t_idt_pos	ia32_idt_remove_entry(t_idt_pos		pos,
				    d_idtr		*idtr);

void		ia32_debug_idt_print(d_idtr		*idtr);


/*
 * ../../interrupt/pic.c
 */

void		ia32_pic_init(void);

void		ia32_pic_disable(t_uint16	irq);

void		ia32_pic_enable(t_uint16	irq);

inline void	ia32_pic_activate(void);

inline void	ia32_pic_desactivate(void);


/*
 * ../../interrupt/io.c
 */

inline void	outb(t_uint16 port, t_uint8 data);

inline void	outw(t_uint16 port, t_uint16 data);

inline void	outl(t_uint16 port, t_uint32 data);

inline t_uint8	inb(t_uint16 port);

inline t_uint16	inw(t_uint16 port);

inline t_uint32	inl(t_uint16 port);


/*
 * ../../interrupt/pit.c
 */

t_bool		ia32_pit_init(t_uint32	frequency);

t_uint64	ia32_pit_get_ticks(void);

void		ia32_timer_isr(void);


/*
 * ../../interrupt/keyboard.c
 */

t_uint8		ia32_keyboard_select_keymap(t_uint16	keymap_code);

void		ia32_keyboard_init(void);

t_bool		ia32_keyboard_get_key(char		*key);

void		ia32_keyboard_isr(void);


/*
 * eop
 */

void		_low_level_divide_error_handler(void);
void		_low_level_debug_handler(void);
void		_low_level_nmi_interrupt_handler(void);
void		_low_level_breakpoint_handler(void);
void		_low_level_overflow_handler(void);
void		_low_level_bound_range_exceeded_handler(void);
void		_low_level_invalid_opcode_handler(void);
void		_low_level_device_not_available_handler(void);
void		_low_level_double_fault_handler(void);
void		_low_level_coprocessor_segment_overrun_handler(void);
void		_low_level_invalid_tss_handler(void);
void		_low_level_segment_not_present_handler(void);
void		_low_level_stack_segment_fault_handler(void);
void		_low_level_general_protection_handler(void);
void		_low_level_page_fault_handler(void);
void		_low_level_intel_reserved_1_handler(void);
void		_low_level_alignement_check_handler(void);
void		_low_level_floating_point_error_handler(void);
void		_low_level_machine_check_handler(void);
void		_low_level_intel_reserved_2_handler(void);
void		_low_level_intel_reserved_3_handler(void);
void		_low_level_intel_reserved_4_handler(void);
void		_low_level_intel_reserved_5_handler(void);
void		_low_level_intel_reserved_6_handler(void);
void		_low_level_intel_reserved_7_handler(void);
void		_low_level_intel_reserved_8_handler(void);
void		_low_level_intel_reserved_9_handler(void);
void		_low_level_intel_reserved_10_handler(void);
void		_low_level_intel_reserved_11_handler(void);
void		_low_level_intel_reserved_12_handler(void);
void		_low_level_intel_reserved_13_handler(void);
void		_low_level_intel_reserved_14_handler(void);
void		_low_level_irq_0_handler(void);
void		_low_level_irq_1_handler(void);
void		_low_level_irq_2_handler(void);
void	        _low_level_irq_3_handler(void);
void	        _low_level_irq_4_handler(void);
void	        _low_level_irq_5_handler(void);
void	        _low_level_irq_6_handler(void);
void	        _low_level_irq_7_handler(void);
void	        _low_level_irq_8_handler(void);
void	        _low_level_irq_9_handler(void);
void	        _low_level_irq_10_handler(void);
void	        _low_level_irq_11_handler(void);
void	        _low_level_irq_12_handler(void);
void	        _low_level_irq_13_handler(void);
void	        _low_level_irq_14_handler(void);
void	        _low_level_irq_15_handler(void);

#endif
