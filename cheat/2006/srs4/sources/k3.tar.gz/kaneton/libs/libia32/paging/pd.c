/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/paging/pd.c
 *
 * created       matthieu bucchianeri   [tue dec 20 19:56:20 2005]
 * updated       Jerome Herbault   [sat feb 18 05:11:06 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage page directory.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * this    file   is    destinated   to    functions    dealing   with
 * page-directories. there are no restrictions about function names or
 * prototype, so feel free.
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

#include "paging/paging.h"
/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Initialisation of the page directory
 * p_addr is the physic address of the page
 */
t_error		ia32_paging_pd_init(t_pd_entry *p_addr)
{
  t_uint32	ind = 0;
  t_uint32	entry_nb = PAGESZ / IA32_PAGING_PDE_SIZE;


  if ((t_vaddr)p_addr % PAGESZ)
    return ERROR_UNKNOWN;

  *p_addr = UNSET_PAGE_FREE(*p_addr);

  for (; ind < entry_nb; ++ind, ++p_addr)
    *p_addr = UNSET_PAGE_PRESENT(*p_addr);

  return ERROR_NONE;
}


/*
 * Clean of the page directory
 */
t_error		ia32_paging_pd_clean(t_pd_entry *p_addr)
{
  t_uint32	ind = 0;
  t_uint32	entry_nb = PAGESZ
			    / IA32_PAGING_PDE_SIZE;


  if ((t_vaddr)p_addr % PAGESZ)
    return ERROR_UNKNOWN;

  for (; ind < entry_nb; ++ind, ++p_addr)
    {
      ia32_paging_pt_clean((t_pt_entry*)(*p_addr & 0xFFFFF000));
      *p_addr = 0;
    }

  return ERROR_NONE;
}

/*
 * Fill the page directory entry for an allocation
 */
t_error		ia32_paging_pde_alloc(t_pd_entry* pd_paddr,
				      t_vaddr vaddr,
				      t_paddr paddr,
				      t_flags flags)
{
  t_pd_entry	*pde_addr = NULL;
  t_paddr	*pt_addr = NULL;

  if (TRUE == GET_PAGE_FREE_STATUS(*pd_paddr))
    return ERROR_UNKNOWN;

  pde_addr = pd_paddr + GET_PDE_INDEX(vaddr);

  if (FALSE == GET_PAGE_PRESENT_STATUS(*pde_addr))
    {
      if (ERROR_NONE != ia32_paging_table_alloc (&pt_addr))
	return ERROR_UNKNOWN;

      ia32_paging_pt_init(pt_addr);
      *pde_addr = ((t_uint32)pt_addr & 0xFFFFF000)
		| (*pt_addr & 0xE00);
      *pde_addr |= (flags & 0x01FF);
      *pde_addr = SET_PAGE_PRESENT(*pde_addr);
    }
  else
    pt_addr = (t_paddr*)(*pde_addr & 0xFFFFF000);

  return ia32_paging_pte_alloc((t_pt_entry *) pt_addr, vaddr, paddr, flags);
}

/*
 * Free a physic page
 */
t_error		ia32_paging_pde_free(t_pd_entry* pd_paddr,
				     t_vaddr     vaddr)
{
  t_error	err = ERROR_NONE;
  t_pt_entry	*pt_paddr = 0;
  t_pd_entry	*pde_paddr = pd_paddr;
  t_uint32	ind = 0;
  t_uint32	entry_nb = PAGESZ / IA32_PAGING_PTE_SIZE;

  pde_paddr += GET_PDE_INDEX(vaddr);

  if (FALSE == GET_PAGE_PRESENT_STATUS(*pde_paddr))
    return ERROR_UNKNOWN;
  else
    pt_paddr = (t_pt_entry*)(*pde_paddr & 0xFFFFF000);

  if (0 == (err = ia32_paging_pte_free(pt_paddr, vaddr)))
    {
      // Check if the pt use any entry
      for (; ind < entry_nb; ++ind)
	if (TRUE == GET_PAGE_PRESENT_STATUS((*pt_paddr + ind)))
	    break;
      if (ind == entry_nb)
	/* All entry is free, so the pt is useless */
	ia32_paging_pt_clean(pt_paddr);
    }

  return err;
}

/*
 * Debug
 */
void		ia32_paging_pd_debug(t_pd_entry *pde_paddr)
{
  t_uint32	ind = 0;
  t_pt_entry	*pt_paddr = 0;
  t_uint32	entry_nb = PAGESZ / IA32_PAGING_PDE_SIZE;

  for (; ind < entry_nb; ++ind, ++pde_paddr)
    {
      if (TRUE == GET_PAGE_PRESENT_STATUS(*pde_paddr))
	{
	  pt_paddr = (t_pt_entry*)(*pde_paddr & 0xFFFFF000);
	  ia32_paging_pt_debug (pt_paddr, ind);
	}
    }
}
