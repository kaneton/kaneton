/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/libs/libia32/paging/paging.c
 *
 * created       matthieu bucchianeri   [tue dec 20 13:45:05 2005]
 * updated       Jerome Herbault   [sat feb 18 05:12:47 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * manage paging.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students  will have  to fill  this  file with  function related  to
 * paging mode in the cpu: enable, disabling etc.
 *
 * there are no  restrictions about these functions, but  keep in mind
 * that  page-directory management and  page-tables management  are to
 * place in pd.c and pt.c.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- functions -------------------------------------------------------
 */

// Physical address of the area which containts
// the page directory and page tables
static t_paddr		*ia32_paging_area_phys_addr = NULL;

// The size of the area
static t_uint32		ia32_paging_area_size = 0;



/*
 * Initialisation of all the tables
 */
t_error		ia32_paging_init(t_paddr *paging_area_paddr,
				 t_size  paging_area_size,
				 t_uint32 clean)
{
  t_paddr	*paddr = NULL;
  t_uint32	ind = 0;
  t_uint32	table_nb = 0;

  if (paging_area_size % PAGESZ || (t_paddr)paging_area_paddr % PAGESZ)
    return ERROR_UNKNOWN;

  ia32_paging_area_phys_addr = paging_area_paddr;
  ia32_paging_area_size = paging_area_size;

  paddr = ia32_paging_area_phys_addr;
  table_nb = ia32_paging_area_size / PAGESZ;

  if (TRUE == clean)
    for (; ind < table_nb; ++ind, ++paddr)
      *paddr = IA32_PAGING_PAGE_FREE;

  return ERROR_NONE;
}


/*
 * Alloc enough pages for a space area size
 */
t_error		ia32_paging_alloc_pages(t_pd_entry	*cur_pd_paddr,
					t_vaddr		vaddr,
					t_paddr		paddr,
					t_size		size,
					t_flags		flags)
{
  t_uint32	pg_nb = size / PAGESZ;

  if (0 != (size % PAGESZ)
      || 0 != vaddr % PAGESZ
      || 0 != paddr % PAGESZ)
    return ERROR_UNKNOWN;

  for (; pg_nb != 0; --pg_nb)
    {
      if (ERROR_NONE != ia32_paging_pde_alloc(cur_pd_paddr, vaddr,
					      paddr, flags))
	return ERROR_UNKNOWN;

      vaddr += PAGESZ;
      paddr += PAGESZ;
    }

  return (ERROR_NONE);
}

/*
 * Find a free table
 */
t_error			ia32_paging_table_alloc(t_paddr **addr)
{
  t_paddr		*paddr = NULL;
  t_uint32		ind = 0;
  t_uint32		table_nb = ia32_paging_area_size
					/ PAGESZ;

  if (NULL == addr)
    return ERROR_UNKNOWN;

  paddr = ia32_paging_area_phys_addr;

  for (; ind < table_nb; ++ind)
    {
      if (TRUE == GET_PAGE_FREE_STATUS(*paddr))
	{
	  *addr = paddr;
	  return ERROR_NONE;
	}
      paddr = (t_paddr*)((char*)paddr + PAGESZ);
    }
  return ERROR_UNKNOWN;
}

/*
 * Free the page of physic addr vaddr
 */
static t_error		ia32_paging_free_page(t_pd_entry	*cur_pd_paddr,
					      t_vaddr		vaddr)
{
  t_error	err = ERROR_NONE;
  t_pd_entry	*cr3 = NULL;

  err = ia32_paging_pde_free(cur_pd_paddr, vaddr);

  __asm__("movl %%cr3, %%eax	\n\t"
	  "movl %%eax, %0	\n\t"
	  : "=g"(cr3)
	  :
	  : "%eax"
	  );

  if (cr3 == cur_pd_paddr)
    __asm__ __volatile__("invlpg %0": :"m" (*(char *) vaddr));

  return err;
}

/*
 * Free the pages of space area vaddr
 */
t_error			ia32_paging_free_pages(t_pd_entry	*cur_pd_paddr,
					       t_vaddr		vaddr,
					       t_size		size)
{
  if (0 != vaddr % PAGESZ || 0 != size % PAGESZ)
    return ERROR_UNKNOWN;

  while (size > 0)
    {
      if (ERROR_NONE != ia32_paging_free_page(cur_pd_paddr, vaddr))
	return ERROR_UNKNOWN;

      vaddr += PAGESZ;
      size -= PAGESZ;
    }
  return ERROR_NONE;
}


/*
 * Debug
 */
void		ia32_paging_debug(t_pd_entry	*cur_pd_paddr)
{
  printf(ICOLOR(GREEN)"-== [ PAGING DEBUG ] ==-\n"COLOR(WHITE));

  ia32_paging_pd_debug(cur_pd_paddr);
}
