
#include <kaneton.h>

void		test_as(void)
{
  t_tskid	tskid1 = 23;
  t_asid	asid1 = 0;
  t_tskid	tskid2 = 46;
  t_asid	asid2 = 0;
  t_tskid	tskid3 = 4645;
  t_asid	asid3= 0;

  t_asid	asid4 = 0;

  TEST(ERROR_NONE != as_reserve(tskid1, NULL));
  TEST(as_reserve(tskid1, &asid1));
  {
    o_as	*pas = NULL;

    TEST(as_get(asid1, &pas));
    TEST(ERROR_NONE != as_get(0xFFFFFFF, &pas));
    TEST(ERROR_NONE != as_get(asid1, NULL));
  }
  TEST(as_show(asid1));
  TEST(as_reserve(tskid2, &asid2));
  TEST(as_show(asid2));
  TEST(as_reserve(tskid3, &asid3));
  TEST(as_show(asid3));
  TEST(as_dump());
  TEST(as_release(asid1));
  TEST(as_dump());
  TEST(ERROR_NONE != as_clone(tskid3, 0xFFFFFF, &asid4));
  TEST(ERROR_NONE != as_clone(tskid3, asid3, NULL));
  TEST(as_clone(tskid3, asid3, &asid4));
  TEST(as_dump());
  TEST(as_release(asid2));
  TEST(as_release(asid3));
  TEST(ERROR_NONE != as_release(asid3));
  TEST(ERROR_NONE != as_release(0xFFFFFFFF));
}
