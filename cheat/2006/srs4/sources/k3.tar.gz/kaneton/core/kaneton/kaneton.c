/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/kaneton.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat apr  8 10:15:32 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file is the entry point of the kaneton microkernel.
 *
 * from the kaneton() function, every managers will be called to initialise
 * them.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the students just have to write some code to initialise and clean
 * the different managers.
 *
 * finally some critical services will be launched.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <mini-shell.h>
#include <kaneton.h>
#include <kaneton_ascii.h>
/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * this variable is generated when the kernel is compiled, indicating
 * the current kernel version.
 */

extern const char	version[];

/*
 * init variable received from the bootloader specifying segments, regions,
 * physical memory layout etc..
 */

t_init*			init;
extern t_asid		kasid;
extern t_tskid		ktask;

/*
 * ---------- definitions statiques -------------------------------------------
 */

/*
 * ---------- functions -------------------------------------------------------
 */

static t_error		kernel_init(void);

#ifdef KANETON_PRINT_BOOTLOADER
static void			_debug_print_bootloader_init(t_init *init)
{
  printf("===| Debug : Printing Init |===\n");

  printf(COLOR(GREEN)"mem :"COLOR(WHITE)"\t\t0x%p\t\t", init->mem);
  printf(COLOR(GREEN)"memsz :"COLOR(WHITE)"\t\t%dMo\n", init->memsz / 0x100000);

  printf(COLOR(GREEN)"init :"COLOR(WHITE)"\t\t0x%x\t", init->init);
  printf(COLOR(GREEN)"initsz :"COLOR(WHITE)"\t0x%x\n", init->initsz);

  printf(COLOR(GREEN)"kcode :"COLOR(WHITE)"\t\t0x%x\t", init->kcode);
  printf(COLOR(GREEN)"kcodesz :"COLOR(WHITE)"\t0x%x\n", init->kcodesz);

  printf(COLOR(GREEN)"modules :"COLOR(WHITE)"\t0x%x\t", init->modules);
  printf(COLOR(GREEN)"modulessz :"COLOR(WHITE)"\t0x%x\n", init->modulessz);

  printf(COLOR(GREEN)"segments :"COLOR(WHITE)"\t0x%x\t", init->segments);
  printf(COLOR(GREEN)"segmentssz :"COLOR(WHITE)"\t0x%x\t", init->segmentssz);
  printf(COLOR(GREEN)"nsegments :"COLOR(WHITE)"\t%d\n", init->nsegments);

  printf(COLOR(GREEN)"regions :"COLOR(WHITE)"\t0x%x\t", init->regions);
  printf(COLOR(GREEN)"regionssz :"COLOR(WHITE)"\t0x%x\t", init->regionssz);
  printf(COLOR(GREEN)"nregions :"COLOR(WHITE)"\t%d\n", init->nregions);

  printf(COLOR(GREEN)"kstack :"COLOR(WHITE)"\t0x%x\t", init->kstack);
  printf(COLOR(GREEN)"kstacksz :"COLOR(WHITE)"\t0x%x\n", init->kstacksz);

  printf(COLOR(GREEN)"alloc :"COLOR(WHITE)"\t\t0x%x\t", init->alloc);
  printf(COLOR(GREEN)"allocsz :"COLOR(WHITE)"\t0x%x\n", init->allocsz);

  printf(COLOR(GREEN)"gdt :"COLOR(WHITE)"\t\t0x%x\t", init->machdep.gdt);
}
#endif // KANETON_PRINT_BOOTLOADER




/*
 * Entry point of our wonderful kernel
 */
void			kaneton(t_init*	bootloader)
{
  init = bootloader;
  k_console_init(&(bootloader->machdep.cons));

#ifdef KANETON_PRINT_BOOTLOADER
  _debug_print_bootloader_init(init);
#endif // KANETON_PRINT_BOOTLOADER

  /*
   * Initialisation de la memoire
   */

  INIT_CMD_PANIKABLE(alloc_init(bootloader->alloc,
				bootloader->allocsz,
				FIT_FIRST),
		     "Initializing malloc",
		     "Failed to initialize malloc");


  /*
   * Initialisation des managers
   */
  STATS_INIT();

  INIT_CMD_PANIKABLE(id_init(),
		     "Initializing identifier manager",
		     "Failed to initialize identifier manager");

  INIT_CMD_PANIKABLE(set_init(),
		     "Initializing set manager",
		     "Failed to initialize set manager");

  INIT_CMD_PANIKABLE(as_init(),
		     "Initializing address space manager",
		     "Failed to initialize address space manager");

  INIT_CMD_PANIKABLE(map_init(),
		     "Initializing map manager",
		     "Failed to initialize map manager");

  INIT_CMD_PANIKABLE(region_init(PAGESZ, REGION_VMEM_MAX),
		     "Initializing region manager",
		     "Failed to initialize region manager");

  INIT_CMD_PANIKABLE(segment_init(),
		     "Initializing segment manager",
		     "Failed to initialize segment manager");


  /*
   * Kernel initialisation
   */
  INIT_CMD_PANIKABLE(kernel_init(),
		     "Initializing the kernel",
		     "Failed to initialize the kernel");
    /*
     * Interruption initialisation
     */

    /*
     * Configuration des interruptions
     */
    INIT_CMD_PANIKABLE(k_init_interrupts(),
  		     "Interrupt manager initialization",
  		     "Failed to initialize interrupt manager")

    /*
     * Configuration du pic
     */

    INIT_CMD_PANIKABLE(k_init_pic(),
  		     "PIC manager initilization",
  		     "Failed to initialize PIC manager");

    /*
     * Configuration du pit
     */
    INIT_CMD_PANIKABLE(k_timer_init(20, FALSE),
  		     "Timers manager initilization",
  		     "Failed to initialize timers manager");

    /*
     * Initialisation du clavier
     */

    INIT_CMD(k_init_keyb(), "Keyboard manager initilization");


#ifdef SERIAL
  debug_init();
#endif

#ifdef KANETON_TEST

  test_init();
  test_clean();

#else

  ms_mini_shell();

#endif // KANETON_TEST


  INIT_CMD_PANIKABLE(region_clean(),
		     "Clean region manager",
		     "Failed to clean region manager");

  INIT_CMD_PANIKABLE(segment_clean(),
		     "Clean segment manager",
		     "Failed to clean segment manager");

  INIT_CMD_PANIKABLE(map_clean(),
		     "Clean map manager",
		     "Failed to clean map manager");

  INIT_CMD_PANIKABLE(as_clean(),
		     "Clean as manager",
		     "Failed to clean as manager");

  INIT_CMD_PANIKABLE(set_clean(),
		     "Clean set manager",
		     "Failed to clean set manager");

  INIT_CMD_PANIKABLE(id_clean(),
		     "Clean id manager",
		     "Failed to clean id manager");

  kaneton_error("Kernel halted");
  while (42);
}


static t_error		kernel_init(void)
{
  /*
   * At the begining of the kernel, all the segments are mapped
   * Here, we create a new kernel task to have a clean mapping
   */
  int			i = 0;
  t_tskid		new_ktask = 98769876;
  t_asid		new_kasid = ID_UNUSED;
  t_regid		new_regid = ID_UNUSED;
  o_as			*as = NULL;

  if (ERROR_NONE != as_reserve(new_ktask, &new_kasid))
    return ERROR_UNKNOWN;

  if (ERROR_NONE != as_get(new_kasid, &as))
    return ERROR_UNKNOWN;

  for (i = 0; i < init->nsegments; ++i)
    {
      init->segments[i].asid = new_kasid;

      segment_inject(new_kasid, &init->segments[i]);
    }

  for (i = 0; i < init->nregions; ++i)
    {
      region_reserve(new_kasid, init->regions[i].segid, 0,
		     REGION_OPT_MAPALL | REGION_OPT_FORCE,
		     (t_vaddr)init->regions[i].segid,
		     0, &new_regid);
    }

  // Change the as to the new one
  asm("movl %0,    %%eax	\n\t"
      "movl %%eax, %%cr3	\n\t"
      :
      : "g"(as->machdep.pd)
      : "%eax"
      );

  if (ERROR_NONE != as_release(kasid))
    return ERROR_UNKNOWN;

  init->machdep.pd_kernel = as->machdep.pd;

  kasid = new_kasid;
  ktask = new_ktask;

  return ERROR_NONE;
}

