/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/arch/ia32-virtual/services/keyboard.c
 *
 * created       julien quintard   [sat dec 17 17:16:19 2005]
 * updated       Jerome Herbault   [fri mar 31 11:19:38 2006]
 */


/*
 * ------ Includes ------------------------------------------------------------
 */

#include <kaneton.h>

static t_bool		_is_init = FALSE;

/*
 * ------ Functions -----------------------------------------------------------
 */

t_error		k_init_keyb(void)
{
  ia32_keyboard_init();
  _is_init = TRUE;
  return ERROR_NONE;
}

char		k_getchar(void)
{
  char c;

  if (_is_init == FALSE)
    return 0;
  while (!ia32_keyboard_get_key(&c));
  return c;
}

t_error		k_loadkeys(const char*		map)
{
  if (strcmp("fr", map) == 0)
    ia32_keyboard_select_keymap(IA32_KEYMAP_FR);
  else if (strcmp("us", map) == 0)
    ia32_keyboard_select_keymap(IA32_KEYMAP_US);
  else
    return ERROR_KEYB_INVALID_MAP;
  return ERROR_NONE;
}
