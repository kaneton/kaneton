/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/id/id.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [fri mar 31 11:59:22 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the kaneton kernel uses 64-bit identifier.
 *
 * from this fact, we do not care about identifier recycling.
 *
 * the best example of this fact is located in the id_release()
 * function. indeed the function does nothing, meaning that the
 * identifier released will not be recycled.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the id manager is simply to generate identifier.
 *
 * this is the simpler manager of the kaneton kernel.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the id manager structure.
 */

m_id*			id = NULL;
// id->stats : int64
/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * this function juste display a id_object state
 */

t_error                 id_show(o_id*                        o)
{
  printf("id_show : '%du'\n", o->id);

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function duplicate an id object using the o identifier object
 */

t_error                 id_clone(o_id*                        o,
				 t_id                        old,
				 t_id*			      new)
{
  ID_ENTER(id);

  *new = o->id;

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function reserves an identifier in an identifier object
 */

t_error			id_reserve(o_id*			o,
				   t_id*			i)
{
  ID_ENTER(id);

  *i = o->id++;

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function releases an identifier from an identifier object.
 */

t_error			id_release(o_id*			o,
				   t_id				i)
{
  ID_ENTER(id);

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function initialises an id object.
 */

t_error			id_build(o_id*		o)
{
  ID_ENTER(id);

  o->id = 42;

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function cleans an id object.
 */

t_error			id_destroy(o_id*			o)
{
  ID_ENTER(id);

  ID_LEAVE(id, ERROR_NONE);
}

/*
 * this function just initialize the id manager
 */

t_error                 id_init(void)
{
  if (NULL == (id = malloc(sizeof (m_id))))
    {
      cons_msg('!', "id: cannot allocate memory for the id manager "
	       "structure\n");

      return (ERROR_UNKNOWN);
    }

  memset(id, 0x0, sizeof(m_id));

  STATS_RESERVE("id", &id->stats);

  return (ERROR_NONE);
}

/*
 * this function just destroy the id manager
 */

t_error                 id_clean(void)
{
  ID_ENTER(id);

  free(id);

  return ERROR_NONE;
}
