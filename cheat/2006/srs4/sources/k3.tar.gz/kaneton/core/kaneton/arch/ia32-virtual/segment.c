/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:29:40 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this  file implements dependent  code for  segment manager  on ia32
 * with paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_segment*	segment;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager interface.
 */

i_segment		segment_interface =
  {
    NULL,		// segment_clone
    NULL,		// segment_inject
    NULL,		// segment_give
    NULL,		// segment_resize
    NULL,		// segment_split
    NULL,		// segment_coalesce
    NULL,		// segment_read
    NULL,		// segment_write
    NULL,		// segment_copy
    NULL,		// segment_reserve
    NULL,		// segment_release
    NULL,		// segment_catch
    ia32_segment_perms,	// segment_perms
    NULL,		// segment_type
    NULL,		// segment_flush
    NULL,		// segment_init
    NULL		// segment_clean
  };

/*
 * ---------- functions -------------------------------------------------------
 */

t_error		ia32_segment_perms(t_segid	u,
				   t_perms	perms)
{
  t_iterator	iterator;
  t_state	state = ITERATOR_STATE_UNUSED;
  o_segment	*seg = NULL;
  o_as		*as = NULL;
  o_region	*reg = NULL;

  if (ERROR_NONE != segment_get(u, &seg))
    {
      cons_msg('!', "ia32_segment_type : cannot get the segment\n");
      return ERROR_UNKNOWN;
    }

  if (ERROR_NONE != as_get(seg->asid, &as))
    {
      cons_msg('!', "ia32_segment_type : cannot get the as\n");
      return ERROR_UNKNOWN;
    }

  set_foreach(SET_OPT_FORWARD, as->regions, &iterator, state)
    {
      if (ERROR_NONE != set_object(as->regions, iterator, (void**)&reg))
	{
	  cons_msg('!', "ia32_segment_type : cannot get the region\n");
	  return ERROR_UNKNOWN;
	}

      if (reg->segid == u)
	{
	  // The segment is mapped, let's go to update perms
	  // P.S.: this is ok when the regid == vaddr
	  o_region	new_reg;
	  t_regid	regid = ID_UNUSED;

	  memcpy(&new_reg, reg, sizeof(o_region));

	  if (ERROR_NONE != region_release(seg->asid, reg->regid))
	    {
	      cons_msg('!', "ia32_segment_type : cannot release the region\n");
	      return ERROR_UNKNOWN;
	    }

	  if (ERROR_NONE != region_reserve(seg->asid, new_reg.segid,
					   new_reg.offset, REGION_OPT_FORCE,
					   new_reg.address, new_reg.size,
					   &regid))
	    {
	      cons_msg('!', "ia32_segment_type : cannot reserve the region\n");
	      return ERROR_UNKNOWN;
	    }
	}
    }

  // This segment is not mapped, so no update to do
  return ERROR_NONE;
}
