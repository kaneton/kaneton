



#include <kaneton.h>

extern t_asid		kasid;
extern t_init		*init;

static t_error		test_reg_seg(t_asid asid)
{
  t_iterator	it;
  t_state	state;
  o_as		*as = NULL;
  o_region	*reg = NULL;
  o_segment	*seg = NULL;

  if (ERROR_NONE != as_get(asid, &as))
    return ERROR_UNKNOWN;

  set_foreach(SET_OPT_FORWARD, as->regions, &it, state)
    {
      if (ERROR_NONE != set_object(as->regions, it, (void**)&reg))
	return ERROR_UNKNOWN;

      if (ERROR_NONE != segment_get(reg->segid, &seg))
	return ERROR_UNKNOWN;
    }
  return ERROR_NONE;
}

void		test_advanced(void)
{
  t_tskid	tskid0 = 56785;
  t_asid	asid0 = ID_UNUSED;

  t_regid	regid0 = ID_UNUSED;
  t_regid	regid1 = ID_UNUSED;
  t_regid	regid2 = ID_UNUSED;

  t_segid	segid0 = ID_UNUSED;
  t_segid	segid1 = ID_UNUSED;
  t_segid	segid2 = ID_UNUSED;

  o_region	*reg0 = NULL;
  o_region	*reg1 = NULL;
  o_region	*reg2 = NULL;

  o_segment	*seg0 = NULL;
  o_segment	*seg1 = NULL;
  o_segment	*seg2 = NULL;

  t_vaddr	vaddr = 0;
  t_vaddr	vaddr1 = 0;
  t_vaddr	vaddr2 = 0;
  t_paddr	paddr = 0;
  char		*sz_test = "Chiche segfault vatican";
  char		buff[256];



  // as_paddr
  TEST(as_reserve(tskid0, &asid0));
  TEST(segment_reserve(asid0, 3 * PAGESZ, PERM_READ, &segid0));
  TEST(region_reserve(asid0, segid0, PAGESZ,
		      REGION_OPT_NONE, 0, PAGESZ, &regid0));
  TEST(segment_get(segid0, &seg0));
  TEST(region_get(asid0, regid0, &reg0));
  TEST(as_paddr(asid0, reg0->address, &paddr));
  TEST(paddr == seg0->address + PAGESZ);
  TEST(ERROR_NONE != as_paddr(asid0, reg0->address + PAGESZ + 512, &paddr));
  TEST(ERROR_NONE != as_paddr(asid0, reg0->address - 512, &paddr));

  // as_vaddr
  TEST(ERROR_NONE != as_vaddr(asid0, seg0->address, &vaddr));
  TEST(as_vaddr(asid0, seg0->address + PAGESZ, &vaddr));
  TEST(vaddr == reg0->address);
  TEST(ERROR_NONE != as_vaddr(asid0, seg0->address + 42, &vaddr));
  TEST(ERROR_NONE != as_vaddr(asid0, seg0->address + 2 * PAGESZ +789, &vaddr));
  TEST(region_release(asid0, regid0));
  TEST(segment_release(segid0));
  TEST(as_release(asid0));

  // segment_write
  TEST(map_reserve(kasid, MAP_OPT_NONE, &vaddr,
		   PAGESZ, PERM_READ|PERM_WRITE));
  regid1 = vaddr;
  TEST(test_reg_seg(kasid));
  TEST(region_get(kasid, regid1, &reg1));
  TEST(segment_get(reg1->segid, &seg1));
  segid1 = reg1->segid;
  TEST(as_vaddr(kasid, seg1->address, &vaddr));
  TEST(segment_show(reg1->segid));
  TEST(region_show(kasid, regid1));
  TEST(0 != memset((char*)vaddr, 0, PAGESZ));

  TEST(segment_write(reg1->segid, 42, (void*)sz_test, strlen(sz_test)));
  TEST(as_vaddr(kasid, seg1->address + 42, &vaddr));
  TEST(0 == strcmp((char*)vaddr, sz_test));

  // segment_read
  TEST(0 != memset(buff, 0, 256));
  TEST(segment_read(reg1->segid, 42, buff, 78));
  TEST(0 == strcmp(sz_test, buff));
  vaddr = regid1;
  TEST(map_release(kasid, vaddr));

  // segment_copy
  TEST(map_reserve(kasid, MAP_OPT_NONE, &vaddr1,
		   PAGESZ, PERM_READ|PERM_WRITE));
  TEST(map_reserve(kasid, MAP_OPT_NONE, &vaddr2,
		   PAGESZ, PERM_READ|PERM_WRITE));
  TEST(test_reg_seg(kasid));
  regid1 = vaddr1;
  regid2 = vaddr2;
  TEST(region_get(kasid, regid1, &reg1));
  TEST(region_get(kasid, regid2, &reg2));

  TEST(0 != memset((char*)vaddr1, 0, PAGESZ));
  TEST(0 != memset((char*)vaddr2, 0, PAGESZ));

  TEST(segment_write(reg1->segid, 42, (void*)sz_test, strlen(sz_test)));
  TEST(segment_copy(reg2->segid, 509, reg1->segid, 0, 1024));

  TEST(0 == strcmp((char*)(vaddr1 + 42), sz_test));
  TEST(0 == strcmp((char*)(vaddr2 + 509 + 42), sz_test));
  TEST(0 == strcmp((char*)(vaddr1 + 42), (char*)(vaddr2 + 509 + 42)));

  TEST(region_get(kasid, regid2, &reg2));
  segid2 = reg2->segid;
  TEST(segment_get(segid1, &seg1));
  TEST(segment_get(segid2, &seg2));
  TEST(as_vaddr(kasid, seg2->address + 509, &vaddr));
  TEST(0 == strcmp((char*)vaddr + 42, sz_test));

  TEST(map_release(kasid, regid1));
  TEST(map_release(kasid, regid2));



  // TEST of clone
  TEST(segment_reserve(kasid, PAGESZ, PERM_READ|PERM_WRITE, &segid1));
  TEST(region_reserve(kasid, segid1, 0, REGION_OPT_MAPALL, 0, 0, &regid1));
  TEST(ERROR_NONE != segment_clone(0xFFFFFFFF, segid1, &segid2));
  TEST(ERROR_NONE != segment_clone(asid0, 0xFFFFFFFF, &segid2));
  TEST(ERROR_NONE != segment_clone(asid0, segid1, NULL));
  TEST(segment_write(segid1, 1042, (void*)sz_test, strlen(sz_test)));
  TEST(segment_clone(kasid, segid1, &segid2));		// clone in the same as
  TEST(region_reserve(kasid, segid2, 0, REGION_OPT_MAPALL, 0, 0, &regid2));
  TEST(segment_dump());
  TEST(segment_get(segid1, &seg1));
  TEST(segment_get(segid2, &seg2));
  TEST(as_vaddr(kasid, seg1->address + 1042, &vaddr1));
  TEST(as_vaddr(kasid, seg2->address + 1042, &vaddr2));
  TEST(0 == strcmp((char*)vaddr1, sz_test));
  TEST(0 == strcmp((char*)vaddr2, sz_test));
  TEST(segment_release(segid1));
  TEST(region_release(kasid, regid1));
  TEST(segment_release(segid2));
  TEST(region_release(kasid, regid2));


  //***************************************************************************
  // TEST of update tlb
  vaddr = 0x44000000;
  TEST(segment_reserve(kasid, 3 * PAGESZ, PERM_READ, &segid0));
  TEST(segment_reserve(kasid, PAGESZ, PERM_READ|PERM_WRITE, &segid1));

  TEST(region_reserve(kasid, segid0, 0, REGION_OPT_FORCE|REGION_OPT_MAPALL,
		      vaddr, 0, &regid0));
  //** MUST raise general protection fault
  //    *((char*)vaddr) = 'X';
  //    *((char*)vaddr) = *((char*)vaddr);
  TEST(region_release(kasid, regid0));
  TEST(region_reserve(kasid, segid1, 0, REGION_OPT_FORCE|REGION_OPT_MAPALL,
		      vaddr, 0, &regid1));
  TEST(segment_write(segid1, 3022, (void*)sz_test, strlen(sz_test)));
  TEST(region_release(kasid, regid1));
  TEST(segment_release(segid0));
  TEST(segment_release(segid1));


  //***************************************************************************
  // TEST of update perms
  TEST(segment_reserve(kasid, PAGESZ, PERM_READ | PERM_WRITE, &segid0));
  TEST(region_reserve(kasid, segid0, 0, REGION_OPT_MAPALL, 0, 0, &regid0));
  TEST(segment_get(segid0, &seg0));
  TEST(as_vaddr(kasid, seg0->address + 3078, &vaddr));
  // MUST ok
  *(t_vaddr*)vaddr = (t_vaddr)0x42424242;
  // Change perms
  TEST(segment_perms(segid0, PERM_READ));
  // MUST failed
  //  *(t_vaddr*)vaddr = (t_vaddr)0x42424242;

  TEST(region_release(kasid, regid0));
  TEST(segment_release(segid0));


  //**************************************************************************
  // TEST of segment_copy with two segment not mapped
  TEST(as_reserve(tskid0, &asid0));
  TEST(segment_reserve(asid0, 2 * PAGESZ, PERM_READ, &segid1));
  TEST(segment_reserve(asid0, PAGESZ, PERM_WRITE, &segid2));
  TEST(segment_copy(segid2, 0, segid1, 2056, 4021));
  TEST(segment_release(segid2));
  TEST(segment_release(segid1));
  TEST(as_release(asid0));

  //**************************************************************************
  // TEST of the data when a segment_resize occured
  TEST(segment_reserve(kasid, PAGESZ, PERM_READ|PERM_WRITE, &segid1));
  TEST(segment_write(segid1, 789, (void*)sz_test, strlen(sz_test)));
  TEST(segment_resize(segid1, 4 * PAGESZ, &segid1));
  TEST(region_reserve(kasid, segid1, 0, REGION_OPT_MAPALL, 0, 0, &regid1));
  TEST(segment_get(segid1, &seg1));
  TEST(as_vaddr(kasid, seg1->address, &vaddr));
  TEST(0 == strcmp((char*)vaddr + 789, sz_test));
  TEST(region_release(kasid, regid1));
  TEST(segment_release(segid1));

  //**************************************************************************
  // TEST of segment_split
  TEST(segment_reserve(kasid, 2 * PAGESZ, PERM_READ|PERM_WRITE, &segid0));
  TEST(segment_write(segid0, 0, (void*)sz_test, strlen(sz_test) + 1));
  TEST(segment_write(segid0, PAGESZ, (void*)sz_test, strlen(sz_test) + 1));
  TEST(segment_split(segid0, PAGESZ, &segid1, &segid2));
  TEST(ERROR_NONE != segment_release(segid0));
  TEST(ERROR_NONE != region_reserve(kasid, segid1,
				    0, REGION_OPT_NONE, 0, 0, &regid1));
  TEST(region_reserve(kasid, segid1, 0, REGION_OPT_NONE, 0, PAGESZ, &regid1));
  TEST(region_reserve(kasid, segid2, 0, REGION_OPT_MAPALL, 0, 0, &regid2));
  TEST(region_get(kasid, regid1, &reg1));
  TEST(region_get(kasid, regid2, &reg2));
  TEST(0 == strcmp((char*)reg1->address, sz_test));
  TEST(0 == strcmp((char*)reg2->address, sz_test));
  TEST(0 == strcmp((char*)reg2->address, (char*)reg1->address));

  TEST(segment_release(segid1));
  TEST(segment_release(segid2));
  TEST(region_release(kasid, regid1));
  TEST(region_release(kasid, regid2));

  //**************************************************************************
  // TEST of segment_coalesce

  TEST(segment_reserve(kasid, 2 * PAGESZ, PERM_READ|PERM_WRITE, &segid0));
  TEST(segment_write(segid0, 0, (void*)sz_test, strlen(sz_test) + 1));
  TEST(segment_write(segid0, PAGESZ, (void*)sz_test, strlen(sz_test) + 1));
  TEST(segment_split(segid0, PAGESZ, &segid1, &segid2));
  TEST(ERROR_NONE != segment_release(segid0));
  TEST(ERROR_NONE != region_reserve(kasid, segid1,
				    0, REGION_OPT_NONE, 0, 0, &regid1));
  TEST(region_reserve(kasid, segid1, 0, REGION_OPT_NONE, 0, PAGESZ, &regid1));
  TEST(region_reserve(kasid, segid2, 0, REGION_OPT_MAPALL, 0, 0, &regid2));
  TEST(region_get(kasid, regid1, &reg1));
  TEST(region_get(kasid, regid2, &reg2));
  TEST(0 == strcmp((char*)reg1->address, sz_test));
  TEST(0 == strcmp((char*)reg2->address, sz_test));
  TEST(0 == strcmp((char*)reg2->address, (char*)reg1->address));
  TEST(segment_coalesce(segid1, segid2, &segid0));
  TEST(ERROR_NONE != segment_release(segid1));
  TEST(ERROR_NONE != segment_release(segid2));
  TEST(region_release(kasid, regid1));
  TEST(region_release(kasid, regid2));
  TEST(region_reserve(kasid, segid0, 0, REGION_OPT_MAPALL, 0, 0, &regid0));
  TEST(segment_get(segid0, &seg0));
  TEST(as_vaddr(kasid, seg0->address, &vaddr));
  TEST(0 == strcmp((char*)vaddr, sz_test));
  TEST(0 == strcmp((char*)vaddr + PAGESZ, sz_test));
  TEST(map_release(kasid, vaddr));

}
