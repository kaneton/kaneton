/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/segment/segment.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [sat mar 25 10:10:17 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the segment manager manages physical memory.
 *
 * it  is  able   to  reserve  and  release  memory   areas  (see  the
 * segment-fit.c for  allocation algorithm)  and to operated  on these
 * area: resize, split, copy, etc.
 *
 * a segment  is identified by  a 64 bits identifier  corresponding to
 * its physical  address. so  it is easy  to retrieve  this identifier
 * given the base address of a segment.
 *
 * remember  that  segments are  global:  there  is  only one  set  of
 * segments objects for  the entire kernel. the set  of segments in an
 * address space is just a set of identifiers.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have  to write the entire manager:  this file implementing
 * independent code plus  an architecture dependant file (ia32-virtual
 * or ia32-segment for example).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(segment);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the init variable, filled by the bootloader, containing in this case
 * the list of segments to mark used.
 */

extern t_init*		init;
extern t_asid		kasid;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the segment manager structure.
 */

m_segment*		segment;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Reads raw data from a segment into a buffer
 */
t_error			segment_read(t_segid	segid,
				     t_paddr	offs,
				     void*	buff,
				     t_psize	sz)
{
  o_segment		*seg = NULL;
  t_vaddr		vaddr = 0;
  t_regid		regid = ID_UNUSED;

  SEGMENT_ENTER(segment);

  if (NULL == buff)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (ERROR_NONE != segment_get(segid, &seg))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (seg->size < offs)
    {
      cons_msg('!', "segment_read : offset to large\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  sz = (seg->size - offs < sz ? seg->size - offs : sz);

  if (ERROR_NONE != region_reserve(kasid, segid, 0, REGION_OPT_MAPALL,
				   0, 0, &regid))
    {
      cons_msg('!', "segment_write : cannot map the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != as_vaddr(kasid, seg->address, &vaddr))
    {
      cons_msg('!', "segment_read : cannot get the virtual address\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  memcpy((char*)buff, (char*)vaddr + offs, sz);

  if (ERROR_NONE != region_release(kasid, regid))
    {
      cons_msg('!', "segment_write : cannot unmap the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Writes data to a segment
 */
t_error			segment_write(t_segid		segid,
				      t_paddr		offs,
				      const void	*buff,
				      t_psize		sz)
{
  o_segment		*seg = NULL;
  t_regid		regid = ID_UNUSED;
  t_vaddr		vaddr = 0;

  SEGMENT_ENTER(segment);

  if (NULL == buff)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (ERROR_NONE != segment_get(segid, &seg))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (seg->size < offs)
    {
      cons_msg('!', "segment_write : offset to large\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  sz = (seg->size - offs < sz ? seg->size - offs : sz);

  if (ERROR_NONE != region_reserve(kasid, segid, 0, REGION_OPT_MAPALL,
				   0, 0, &regid))
    {
      cons_msg('!', "segment_write : cannot map the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != as_vaddr(kasid, seg->address, &vaddr))
    {
      cons_msg('!', "segment_write : cannot get the virtual address\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  memcpy(((char*)vaddr) + offs, (char*)buff, sz);

  if (ERROR_NONE != region_release(kasid, regid))
    {
      cons_msg('!', "segment_write : cannot unmap the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  SEGMENT_LEAVE(segment, ERROR_NONE);
}


/*
 * Copies data from one segment to another
 */
t_error			segment_copy(t_segid	dst,
				     t_paddr	offsd,
				     t_segid	src,
				     t_paddr	offss,
				     t_psize	sz)
{
  char			buff[SEGMENT_COPY_BUFFER];
  t_uint32		i = 0;
  t_size		cursz = 0;

  SEGMENT_ENTER(segment);

  for (i = 0; i < sz; i += SEGMENT_COPY_BUFFER)
    {
      cursz = (sz - i < SEGMENT_COPY_BUFFER ? sz - i : SEGMENT_COPY_BUFFER);

      if (ERROR_NONE != segment_read(src, offss + i, buff, cursz))
	SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

      if (ERROR_NONE != segment_write(dst, offsd + i, buff, cursz))
	SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  SEGMENT_LEAVE(segment, ERROR_NONE);
}


/*
 * Display information.
 */
t_error			segment_show(t_segid	u)
{
  o_segment		*seg = NULL;

  SEGMENT_ENTER(segment);

  if (ERROR_NONE != segment_get(u, &seg))
    {
      cons_msg('!', "segment_show : No such segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  printf("seg"
	 " addr: 0x%8X"
	 " asid: %qd"
	 " type: %u"
	 " size: %8X"
	 " perms: %u\n",
	 seg->address, seg->asid, seg->type,
	 seg->size, seg->perms);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Display all segments
 */
t_error			segment_dump(void)
{
  t_state		state = ITERATOR_STATE_UNUSED;
  t_iterator		i;
  o_segment*		seg = NULL;

  SEGMENT_ENTER(segment);

  set_foreach(SET_OPT_FORWARD, segment->container, &i, state)
    {
      if (ERROR_NONE != set_object(segment->container, i, (void**)&seg))
	{
	  cons_msg('!', "segment_dump : cannot get the data from "
		   "this segment\n");
	  SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
	}

      if (ERROR_NONE != segment_show(seg->segid))
	{
	  cons_msg('!', "segment_dump : cannot show this segment\n");
	  SET_LEAVE(segment, ERROR_UNKNOWN);
	}
    }

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Clones a segment
 */
t_error			segment_clone(t_asid		as,
				      t_segid		old,
				      t_segid*		new)
{
  o_segment		*segfrom = NULL;
  t_regid		regid = ID_UNUSED;

  SEGMENT_ENTER(segment);

  if (ERROR_NONE != segment_get(old, &segfrom))
    {
      cons_msg('!', "segment_clone : cannot get the source segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (NULL == new || ERROR_NONE !=
      segment_reserve(as, segfrom->size, segfrom->perms, new))
    {
      cons_msg('!', "segment_clone : cannot reserve the clone segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_type(*new, segfrom->type))
    {
      cons_msg('!', "segment_clone : cannot set the perms of the "
	       "clone segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != region_reserve(kasid, *new, 0, REGION_OPT_MAPALL,
				   0, 0, &regid))
    {
      cons_msg('!', "segment_clone : cannot map the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_copy(*new, 0, old, 0, segfrom->size))
    {
      cons_msg('!', "segment_clone : cannot clone the data\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != machdep_call(segment, segment_clone, as, old, new))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (ERROR_NONE != region_release(kasid,  regid))
    {
      cons_msg('!', "segment_clone : cannot unmap the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Injects a pre-allocated segment
 */
t_error			segment_inject(t_asid		as,
				       o_segment*	o)
{
  o_as			*curas = NULL;

  SEGMENT_ENTER(segment);

  if (NULL == o)
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  o->segid = o->address;

  if (ERROR_NONE != as_get(as, &curas))
    {
      cons_msg('!', "segment_inject : cannnot get the address space\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_add(segment->container, o))
      {
	cons_msg('!', "segment_inject : cannot add the segment to"
		 " the container\n");

	SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
      }

  if (ERROR_NONE != set_add(curas->segments, &(o->segid)))
      {
	cons_msg('!', "segment_inject : cannot add the segment "
		 "identifier to the container\n");

	SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
      }

  if (ERROR_NONE != machdep_call(segment, segment_inject, as, o))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Gives a segment from one address space to another
 */
t_error			segment_give(t_segid	segid,
				     t_asid	asid)
{
  o_as			*asold = NULL;
  o_as			*asnew = NULL;
  o_segment		*seg = NULL;
  t_segid		*segsetid = NULL;

  SEGMENT_ENTER(segment);

  if (ERROR_NONE != segment_get(segid, &seg))
    {
      cons_msg('!', "segment_give : cannot get the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != as_get(seg->asid, &asold))
    {
      cons_msg('!', "segment_give : cannot get the old address space\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != as_get(asid, &asnew))
    {
      cons_msg('!', "segment_give : cannot get the new address space\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_get(asold->segments, segid, (void**)&segsetid))
    {
      cons_msg('!', "segment_give : cannot get the segment set "
	       "id of the old address space\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_remove(asold->segments, *segsetid))
    {
      cons_msg('!', "segment_give : cannot remove the segment from "
	       "the old address space\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  seg->asid = asid;

  if (ERROR_NONE != set_add(asnew->segments, seg))
    {
      cons_msg('!', "segment_give : cannot add the segment in "
	       "the address space\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != machdep_call(segment, segment_give, segid, asid))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Resizes a segment
 */
t_error			segment_resize(t_segid	segid,
				       t_psize	size,
				       t_segid*	new)
{
  o_segment		*seg = NULL;
  t_segid		new_segid = ID_UNUSED;

  SEGMENT_ENTER(segment);

  if (0 == size || NULL == new)
    {
      cons_msg('!', "segment_resize : param(s) not valid\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_get(segid, &seg))
    {
      cons_msg('!', "segment_resize : cannot get the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_reserve(seg->asid, size, seg->perms, &new_segid))
    {
      cons_msg('!', "segment_resize : cannot reserve the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_type(new_segid, seg->type))
    {
      cons_msg('!', "segment_resize : cannot set the type of the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_copy(new_segid, 0, seg->segid, 0,
				 (seg->size < size ? seg->size : size)))
    {
      cons_msg('!', "segment_resize : cannot copy the data\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_release(segid))
    {
      cons_msg('!', "segment_resize : cannot release the old segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != machdep_call(segment, segment_resize,
				 segid, size, &new_segid))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  *new = new_segid;

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Splits a segment into two.
 */
t_error			segment_split(t_segid	segid,
				      t_psize	size,
				      t_segid*	left,
				      t_segid*	right)
{
  o_segment		*seg = NULL;

  SEGMENT_ENTER(segment);

  if (NULL == left || NULL == right)
    {
      cons_msg('!', "segment_split : param(s) not valid\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_get(segid, &seg))
    {
      cons_msg('!', "segment_split : cannot get the segment to split\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (size >= seg->size || 0 == size)
    {
      cons_msg('!', "segment_split : size no valid\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_reserve(seg->asid, size, seg->perms, left))
    {
      cons_msg('!', "segment_split : cannot reserve the left segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_copy(*left, 0, segid, 0, size))
    {
      cons_msg('!', "segment_split : cannot copy the data to the "
	       "left segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_reserve(seg->asid, seg->size - size,
				    seg->perms, right))
    {
      if (ERROR_NONE != segment_release(*left))
	{
	  cons_msg('!', "segment_split : cannot return to stable state\n");
	  SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
	}
      cons_msg('!', "segment_split : cannot reserve the right segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_copy(*right, 0, segid, size, seg->size - size))
    {
      cons_msg('!', "segment_split : cannot copy the data to "
	       "the right segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_release(segid))
    {
      cons_msg('!', "segment_split : cannot release the old segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != machdep_call(segment, segment_split, segid,
				 size, left, right))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Merges two segments into one single.
 */
t_error			segment_coalesce(t_segid	left,
					 t_segid	right,
					 t_segid*	u)
{
  o_segment		*segleft = NULL;
  o_segment		*segright = NULL;

  SEGMENT_ENTER(segment);

  if (ERROR_NONE != segment_get(left, &segleft))
    {
      cons_msg('!', "segment_colesce : cannot get the left segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_get(right, &segright))
    {
      cons_msg('!', "segment_colesce : cannot get the right segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_reserve(segleft->asid,
				    segleft->size + segright->size,
				    segleft->perms, u))
    {
      cons_msg('!', "segment_coalesce : cannot create the new segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_type(*u, segleft->type))
    {
      cons_msg('!', "segment_coalesce : cannot change the perm of "
	       "the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_copy(*u, 0, left, 0, segleft->size)
      || ERROR_NONE != segment_copy(*u, segleft->size, right, 0,
				    segright->size))
    {
      cons_msg('!', "segment_coalesce : cannot copy the data to "
	       "the new segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if ((ERROR_NONE != segment_release(left))
      || (ERROR_NONE != segment_release(right)))
    {
      cons_msg('!', "segment_coalesce : cannot release the old segments\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != machdep_call(segment, segment_coalesce, left, right, u))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Reserves a segment of specified size
 */
t_error			segment_reserve(t_asid		as,
					t_psize		size,
					t_perms		perms,
					t_segid*	segid)
{
  o_segment		seg;

  SEGMENT_ENTER(segment);

  if (NULL == segid || 0 >= size || 0 != size % PAGESZ
      || 0 != (perms & ~(PERM_READ|PERM_WRITE|PERM_EXEC)))
    {
      cons_msg('!', "segment_reserve : parameter(s) not valid\n");

      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  memset(&seg, 0, sizeof(o_segment));

  if (ERROR_NONE != segment_fit(size, &(seg.address)))
    {
      cons_msg('!', "segment_reserve : cannot reserve a new segment\n");

      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  seg.segid = seg.address;
  seg.asid = as;
  seg.size = size;
  seg.perms = perms;

  *segid = seg.segid;

  if (ERROR_NONE != machdep_call(segment,
				 segment_reserve, as, size, perms, segid))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, segment_inject(as, &seg));
}

/*
 * Releases a segment
 */
t_error			segment_release(t_segid	u)
{
  o_as			*curas = NULL;
  o_segment		*seg = NULL;
  t_segid		*segsetid = NULL;

  SEGMENT_ENTER(segment);

  if (ERROR_NONE != segment_get(u, &seg))
    {
      cons_msg('!', "segment_release : cannot get this segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != as_get(seg->asid, &curas))
    {
      cons_msg('!', "segment_release : cannot get the address space\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_remove(segment->container, u))
    {
      cons_msg('!', "segment_release : cannot release this segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_get(curas->segments, u, (void**)&segsetid))
    {
	cons_msg('!', "segment_reserve : cannot get the segment "
		 "identifier from the address space\n");

	SEGMENT_LEAVE(set, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_remove(curas->segments, *segsetid))
    {
	cons_msg('!', "segment_reserve : cannot remove the segment "
		 "identifier from the address space\n");

	SEGMENT_LEAVE(set, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != machdep_call(segment, segment_release, u))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * This function is used to force a segment to be given to an address space.
 * catchable segments are reserved by the module service for architecture
 * specific servers.
 *
 * Catchable segments are defined in the kaneton.conf file.
 *
 */
t_error			segment_catch(t_asid		as,
				      t_segid		u)
{
  SEGMENT_ENTER(segment);

  // Mycure : tu t'en branles
  kaneton_error("segment_catch not implemented\n");

  SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
}

/*
 * Changes permissions for a segment.
 */
t_error			segment_perms(t_segid		u,
				      t_perms		perms)
{
  o_segment		*seg = NULL;

  SEGMENT_ENTER(segment);

  if (ERROR_NONE != segment_get(u, &seg))
    {
      cons_msg('!', "segment_perms : cannot get the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (0 != (perms & ~(PERM_READ|PERM_WRITE|PERM_EXEC)))
    {
      cons_msg('!', "segment_perms : permission(s) not valid\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  seg->perms = perms;

  if (ERROR_NONE != machdep_call(segment, segment_perms, u, perms))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);

}

/*
 * Changes the type of a segment
 */
t_error			segment_type(t_segid		u,
				     t_type		type)
{
  o_segment		*seg = NULL;

  SEGMENT_ENTER(segment);

  if (ERROR_NONE != segment_get(u, &seg))
    {
      cons_msg('!', "segment_type : cannot get the segment\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (0 != (type & ~(SEGMENT_TYPE_MEMORY|SEGMENT_TYPE_CATCH))
      || type == (SEGMENT_TYPE_MEMORY|SEGMENT_TYPE_CATCH))
    {
      cons_msg('!', "segment_type : type not valid\n");

      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  seg->type = type;

  if (ERROR_NONE != machdep_call(segment, segment_type, u, type))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Removes every segment that belongs to the address space.
 */
t_error			segment_flush(t_asid		asid)
{
  o_as			*as = NULL;
  t_iterator		iterator;
  t_segid		*segid = NULL;

  SEGMENT_ENTER(segment);

  if (ERROR_NONE != as_get(asid, &as))
    {
      cons_msg('!', "segment_flush : no such address space\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  while (ERROR_NONE == set_head(as->segments, &iterator))
    {
      if (ERROR_NONE != set_object(as->segments, iterator, (void**)&segid))
	{
	  cons_msg('!', "segment_flush : cannot find a segment "
		   "with this iterator\n");
	  SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
	}

      if (ERROR_NONE != segment_release(*segid))
	{
	  cons_msg('!', "segment_flush : cannot release this segment\n");

	  SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
	}
    }

  if (ERROR_NONE != machdep_call(segment, segment_flush, asid))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Gets the segment object associated to a segment identifier.
 */
t_error			segment_get(t_segid		u,
				    o_segment**		o)
{
  SEGMENT_ENTER(segment);

  if (ERROR_NONE != set_get(segment->container, u, (void**)o))
    {
      cons_msg('!', "segment_get : cannot get the segment object\n");

      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  SEGMENT_LEAVE(segment, ERROR_NONE);
}

/*
 * Initializes the segment manager
 */
t_error			segment_init(void)
{
  if (NULL == (segment = malloc(sizeof(m_segment))))
    {
      cons_msg('!', "segment_init : cannot allocate memory for the"
	       " segment manager structure\n");
      return (ERROR_UNKNOWN);
    }

  memset(segment, 0x0, sizeof(m_segment));


  // we dont need id manager because
  // the id == paddr

  if (ERROR_NONE != set_reserve(ll,
				SET_OPT_ALLOC|SET_OPT_SORT,
				sizeof(o_segment),
				&segment->container))
    {
      cons_msg('!', "segment_init : unable to reserve a set\n");
      return (ERROR_UNKNOWN);
    }

  segment->start = init->mem;
  segment->size = init->memsz;
  segment->fit = SEGMENT_FIT;

  if (ERROR_NONE != machdep_call(segment, segment_init))
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  STATS_RESERVE("segment", &segment->stats);

  return (ERROR_NONE);
}

/*
 * Cleans the segment manager
 */
t_error			segment_clean(void)
{
  if (ERROR_NONE != machdep_call(segment, segment_clean))
    SEGMENT_LEAVE(segment, ERROR_UNKNOWN);

  if (ERROR_NONE != set_flush(segment->container))
    {
      cons_msg('!', "segment_clean : cannot flush all segment object\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_release(segment->container))
    {
      cons_msg('!', "segment_clean : cannot release the container of the "
	       "segment manager\n");
      SEGMENT_LEAVE(segment, ERROR_UNKNOWN);
    }

  STATS_RELEASE(segment->stats);

  free(segment);

  return (ERROR_NONE);
}
