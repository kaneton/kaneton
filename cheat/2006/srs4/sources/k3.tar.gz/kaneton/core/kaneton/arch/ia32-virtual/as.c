/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/as.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:27:59 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file  implements dependent  code for as  manager on  ia32 with
 * paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern t_init*		init;
extern t_tskid		ktask;

/*
 * ---------- globals ---------------------------------------------------------
 */



/*
 * the address space manager interface.
 */

i_as			as_interface =
  {
    NULL,			//    as_give
    NULL,			//    as_vaddr
    NULL,			//    as_paddr
    NULL,			//    as_clone
    ia32_as_reserve,		//    as_reserve
    NULL,			//    as_release
    ia32_as_init,		//    as_init
    NULL			//    as_clean
  };

/*
 * ---------- functions -------------------------------------------------------
 */

t_error			ia32_as_reserve(t_tskid	task,
					t_asid	*asid)
{
  o_as			*as = NULL;

  if (ERROR_NONE != as_get(*asid, &as))
    {
      cons_msg('!', "ia32_as_reserve : cannot get the as\n");
      return ERROR_UNKNOWN;
    }

  if (task == ktask)
    {
      as->machdep.pd = init->machdep.pd_kernel;
    }
  else
    {
      if (ERROR_NONE != ia32_paging_table_alloc(&(as->machdep.pd)))
	{
	  cons_msg('!', "ia32_as_reserve : cannot allocate a "
		   "page directory\n");
	  return ERROR_UNKNOWN;
	}

      ia32_paging_pd_init(as->machdep.pd);
    }
  return ERROR_NONE;
}

t_error			ia32_as_init(void)
{
  ia32_paging_init((t_paddr*)init->machdep.paging,
		   init->machdep.pagingsz, FALSE);
  return ERROR_NONE;
}
