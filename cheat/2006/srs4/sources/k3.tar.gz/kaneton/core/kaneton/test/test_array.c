
#include <kaneton.h>

#define PAUSE		k_getchar();

void		test_array_reserve(void);
void		test_array_alloc(void);

void		test_array_reserve(void)
{
  t_setid	set1 = 0;
  t_setid	set2 = 0;
  t_setid	set3 = 0;
  t_setid	set4 = 0;
  t_setid	set5 = 0;
  int initial_alloc = 0;

  // SET_OPT_CONTAINER
  // SET_OPT_ALLOC
  // SET_OPT_FREE
  // SET_OPT SORT
  // SET_OPT_ORGANIZE

  printf("\n\n----------------------------------------\n");
  printf("------    TEST ARRAY - RESERVE    ------\n");
  printf("----------------------------------------\n");
  initial_alloc = alloc_nalloc() - alloc_nfree();
  TEST(set_reserve(array, SET_OPT_NONE, sizeof(int), &set1));
  TEST(set_reserve(array, SET_OPT_ALLOC, sizeof(int), &set2));
  TEST(set_reserve(array, SET_OPT_FREE, sizeof(int), &set3));
  TEST(ERROR_NONE != set_reserve(array, SET_OPT_ALLOC | SET_OPT_FREE,
				sizeof(int), &set4));
  TEST(set_reserve(array, SET_OPT_ALLOC | SET_OPT_SORT | SET_OPT_ORGANISE,
		   sizeof(int), &set5));
  TEST(set_release(set1));
  TEST(ERROR_NONE != set_release(set1));
  TEST(set_release(set2));
  TEST(set_release(set3));
  TEST(ERROR_NONE != set_release(set4));
  TEST(set_release(set5));
  TEST(set_reserve(array, SET_OPT_NONE, sizeof(int), &set1));
  TEST(set_release(set1));
  TEST((initial_alloc == alloc_nalloc() - alloc_nfree()) ?
       ERROR_NONE : ERROR_UNKNOWN);
  PAUSE;

  //TEST(ERROR_NONE != );
}

void		test_array_alloc(void)
{
  t_setid	*setid;
  t_setid	set;
  t_iterator	it;
  t_state	state;
  t_id		data = 1000;
  t_id		data2 = 42;
  int counter = 1;
  int initial_alloc = 0;

  printf("\n\n----------------------------------------\n");
  printf("------   TEST ARRAY - OPT ALLOC   ------\n");
  printf("----------------------------------------\n");
  TEST(set_reserve(array, SET_OPT_ALLOC | SET_OPT_SORT, sizeof(t_id), &set));

  initial_alloc = alloc_nalloc() - alloc_nfree();

  for (counter = 0; counter < 25; counter++)
    {
      if (ERROR_NONE != set_add(set, &(data)))
	break;
      data--;
    }
  TEST(counter == 25 ? ERROR_NONE : ERROR_UNKNOWN);
  counter = 0;
  set_foreach(SET_OPT_FORWARD, set, &it, state)
   {
      if (ERROR_NONE != set_delete_array(set, it))
	break;
     counter++;
    }
  TEST(counter == 25 ? ERROR_NONE : ERROR_UNKNOWN);
  TEST((initial_alloc == alloc_nalloc() - alloc_nfree()) ?
       ERROR_NONE : ERROR_UNKNOWN);
  for (counter = 0; counter < 100; counter++)
    {
      if (ERROR_NONE != set_add(set, &data))
	break;
    }
  TEST(counter == 100 ? ERROR_NONE : ERROR_UNKNOWN);
  counter = 0;
  set_foreach(SET_OPT_FORWARD, set, &it, state)
   {
     if (ERROR_NONE != set_delete_array(set, it))
	break;
     counter++;
    }
  TEST(counter == 100 ? ERROR_NONE : ERROR_UNKNOWN);
  TEST((initial_alloc == alloc_nalloc() - alloc_nfree()) ?
       ERROR_NONE : ERROR_UNKNOWN);
  for (counter = 0; counter < 1000; counter++)
    {
       if (ERROR_NONE != set_add(set, &data))
	break;
    }
  TEST(counter == 1000 ? ERROR_NONE : ERROR_UNKNOWN);
  counter = 0;
  set_foreach(SET_OPT_FORWARD, set, &it, state)
   {
     if (ERROR_NONE != set_delete_array(set, it))
	break;
     counter++;
   }
  TEST(counter == 1000 ? ERROR_NONE : ERROR_UNKNOWN);
  TEST((initial_alloc == alloc_nalloc() - alloc_nfree()) ?
       ERROR_NONE : ERROR_UNKNOWN);
  TEST(set_release(set));
  PAUSE;
}

void		test_array_free(void)
{
  t_setid	set;
  t_id		*data[1000];
  int counter = 1;
  int initial_alloc = 0;

  printf("\n\n----------------------------------------\n");
  printf("------   TEST ARRAY - OPT FREE    ------\n");
  printf("----------------------------------------\n");
  TEST(set_reserve(array, SET_OPT_FREE, sizeof(t_id), &set));

  initial_alloc = alloc_nalloc() - alloc_nfree();
  for ( counter = 0; counter < 1000; counter++)
    {
      data[counter] = malloc(sizeof (t_id));
      *(data[counter]) = counter;
    }
  for (counter = 0; counter < 1000; counter++)
    {
       if (ERROR_NONE != set_add(set, data[counter]))
	break;
    }
  TEST(counter == 1000 ? ERROR_NONE : ERROR_UNKNOWN);
  counter = 0;
  TEST(set_flush(set));
  TEST((initial_alloc == alloc_nalloc() - alloc_nfree()) ?
       ERROR_NONE : ERROR_UNKNOWN);

  TEST(set_release(set));
  PAUSE;
}

void		test_array(void)
{
  int			i0 = 500;
  int			i1 = 501;
  int			i2 = 502;
  int			i3 = 503;
  int			i4 = 504;
  int			i5 = 505;
  int			i6 = 506;
  int			i7 = 507;
  int			i8 = 508;
  int			i9 = 509;

  t_iterator		it;

  t_setid		set = 12345678;
  t_setid		set2 = 12345678;;

  printf("\n\n----------------------------------------\n");
  printf("----------------------------------------\n");
  printf("------                            ------\n");
  printf("------         TEST ARRAY         ------\n");
  printf("------                            ------\n");
  printf("----------------------------------------\n");
  printf("----------------------------------------\n");

  test_array_reserve();

  test_array_alloc();

  test_array_free();


 printf("\n\n----------------------------------------\n");
  printf("------    TEST ARRAY - OTHERS     ------\n");
  printf("----------------------------------------\n");

  TEST(set_reserve(array, SET_OPT_ALLOC|SET_OPT_SORT, sizeof(int), &set));
  TEST((ERROR_NONE != set_reserve(array, 0x88888, sizeof(int), &set2)));
  TEST((ERROR_NONE != set_reserve(array, SET_OPT_ALLOC|SET_OPT_FREE, sizeof(int), &set2)));
  TEST((ERROR_NONE != set_reserve(array, 0xFFFFFFFF, sizeof(int), &set2)));
  TEST(set_show(set));
  TEST(set_flush(set));
  TEST(set_add(set, &i1));
  TEST(set_add(set, &i2));
  TEST(set_add(set, &i3));
  TEST(set_add(set, &i4));
  TEST(set_show(set));
  TEST(set_dump());
  PAUSE;

  TEST(set_locate(set, i1, &it));
  TEST(set_insert_before(set, it, &i5));
  TEST(set_locate(set, i4, &it));
  TEST(set_insert_after(set, it, &i8));
  TEST(set_locate(set, i2, &it));
  TEST(set_insert_before(set, it, &i6));
  TEST(set_locate(set, i3, &it));
  TEST(set_insert_after(set, it, &i7));
  TEST(set_tail(set, &it));
  TEST(set_show(set));
  TEST(set_remove(set, i7));
  TEST(set_show(set));
  TEST(ERROR_NONE != set_locate(set, i7, &it));
  PAUSE;

  TEST(set_insert_head(set, &i0));
  TEST(set_insert_tail(set, &i9));
  TEST(set_flush(set));
  TEST(set_flush(set));
  TEST(set_release(set));
  TEST((ERROR_NONE != set_release(set2)));
  PAUSE
}


