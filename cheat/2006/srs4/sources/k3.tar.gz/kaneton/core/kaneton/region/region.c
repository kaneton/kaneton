/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/region/region.c
 *
 * created       julien quintard   [wed nov 23 09:19:43 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:44:09 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the region manager manages mapping of segments.
 *
 * reserving a region means to map virtual addresses to a segment.
 *
 * like for  segment, region identifiers are the  virtual address they
 * maps.
 *
 * unlike segments, regions  are proper to an address  space: there is
 * one set of region objects for each address space to prevent collisions.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students have to develop  entirely this manager, including the code
 * for one architecture (ia32-virtual or ia32-segment).
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(region);

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the region manager structure.
 */

m_region*		region = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Displays information on a region
 */
t_error		region_show(t_asid asid, t_regid regid)
{
  o_region	*reg = NULL;

  REGION_ENTER(region);

  if (ERROR_NONE != region_get(asid, regid, &reg))
    {
      cons_msg('!', "region_show : cannot get the region\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  printf("reg addr: %8X off: %8X size: %8X segid: %X \n",
	 reg->address, reg->offset, reg->size, reg->segid);

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Displays information on all regions of the address space
 */
t_error		region_dump(t_asid asid)
{
  t_state		state = ITERATOR_STATE_UNUSED;
  t_iterator		i;
  o_as			*as = NULL;
  o_region		*reg = NULL;

  REGION_ENTER(region);

  if (ERROR_NONE != as_get(asid, &as))
    {
      cons_msg('!', "region_dump : cannot get the as\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  set_foreach(SET_OPT_FORWARD, as->regions, &i, state)
    {
      if (ERROR_NONE != set_object(as->regions, i, (void**)&reg))
	{
	  cons_msg('!', "region_dump : cannot get the region\n");
	  REGION_LEAVE(region, ERROR_UNKNOWN);
	}

      if (ERROR_NONE != region_show(asid, reg->regid))
	{
	  cons_msg('!', "region_dump : cannot show this region\n");
	  REGION_LEAVE(region, ERROR_UNKNOWN);
	}
    }

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Injects a pre-reserved region
 */
t_error		region_inject(t_asid asid, o_region *reg)
{
  o_as		*as = NULL;

  REGION_ENTER(region);

  if (NULL == reg)
    REGION_LEAVE(region, ERROR_UNKNOWN);

  if (ERROR_NONE != as_get(asid, &as))
    {
      cons_msg('!', "region_inject : cannot get the as\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_add(as->regions, reg))
    {
      cons_msg('!', "region_inject : cannot add the region to"
	       " the address space\n");

      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  REGION_LEAVE(region, ERROR_NONE);

}

/*
 * Reserves a region given some properties
 */
t_error		region_reserve(t_asid	asid,
			       t_segid	segid,
			       t_paddr	offset,
			       t_opts	opt,
			       t_vaddr	address,
			       t_vsize	size,
			       t_regid*	regid)
{
  o_region	reg;
  o_segment	*seg = NULL;

  REGION_ENTER(region);

  /* Check the param */
  if (((0 == size) && (0 == (opt & REGION_OPT_MAPALL)))
      || NULL == regid || 0 != offset % PAGESZ || 0 != address % PAGESZ
      || 0 != size % PAGESZ
      || 0 != (opt & ~(REGION_OPT_NONE|REGION_OPT_FORCE|REGION_OPT_MAPALL)))
    {
      cons_msg('!', "region_reserve : param(s) not valid\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  memset(&reg, 0, sizeof(o_region));

  if (ERROR_NONE != segment_get(segid, &seg))
    {
      cons_msg('!', "region_reserve : cannot get the segment\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  reg.segid = segid;

  if (offset > seg->size)
    {
      cons_msg('!', "region_reserve : offset to high\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  reg.size =  (0 != (opt & REGION_OPT_MAPALL) ? seg->size : size);

  if (0 != (opt & REGION_OPT_FORCE))
    reg.address = address;
  else
    if (ERROR_NONE != region_fit(asid, reg.size, &(reg.address)))
      {
	cons_msg('!', "region_reserve : cannot find space for the region\n");
	REGION_LEAVE(region, ERROR_UNKNOWN);
      }

  reg.regid = reg.address;
  reg.offset = offset;

  *regid = reg.regid;

  if (ERROR_NONE != machdep_call(region, region_reserve, asid,
				 reg.segid, reg.offset, opt, reg.address,
				 reg.size, &(reg.regid)))
    REGION_LEAVE(region, ERROR_UNKNOWN);

  REGION_LEAVE(region, region_inject(asid, &reg));
}

/*
 * Releases a region
 */
t_error		region_release(t_asid asid, t_regid regid)
{
  o_as		*as = NULL;

  REGION_ENTER(region);

  if (ERROR_NONE != machdep_call(region, region_release, asid, regid))
    REGION_LEAVE(region, ERROR_UNKNOWN);

  if (ERROR_NONE != as_get(asid, &as))
    {
      cons_msg('!', "region_release : cannot get the address space\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != set_remove(as->regions, regid))
    {
      cons_msg('!', "region_release : cannot remove the region "
	       "from the address space\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Removes every region that belongs to the specified address space
 */
t_error		region_flush(t_asid asid)
{
  o_as		*as = NULL;
  t_iterator	it;
  o_region	*reg = NULL;

  REGION_ENTER(region);

  if (ERROR_NONE != as_get(asid, &as))
    {
      cons_msg('!', "region_flush : cannot get the as\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  while (ERROR_NONE == set_head(as->regions, &it))
    {
      if (ERROR_NONE != set_object(as->regions, it, (void**)&reg))
	{
	  cons_msg('!', "region_flush : cannot find a region\n");
	  REGION_LEAVE(region, ERROR_UNKNOWN);
	}

      if (ERROR_NONE != region_release(asid, reg->regid))
	{
	  cons_msg('!', "region_flush : cannot release this region\n");
	  REGION_LEAVE(region, ERROR_UNKNOWN);
	}
    }

  REGION_LEAVE(region, ERROR_NONE);
}

/*
 * Looks for and returns a region object
 */
t_error		region_get(t_asid asid, t_regid regid, o_region** o)
{
  t_state	state = ITERATOR_STATE_UNUSED;
  t_iterator	it;
  o_as		*as = NULL;
  o_region	*reg = NULL;


  REGION_ENTER(region);

  if (NULL == o)
    REGION_LEAVE(region, ERROR_UNKNOWN);

  if (ERROR_NONE != as_get(asid, &as))
    {
      cons_msg('!', "region_get : cannot get the address space\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  set_foreach(SET_OPT_FORWARD, as->regions, &it, state)
    {
      if (ERROR_NONE != set_object(as->regions, it, (void**)&reg))
	{
	  cons_msg('!', "region_get : cannot get the region\n");
	  REGION_LEAVE(region, ERROR_UNKNOWN);
	}

      if (reg->regid == regid)
	{
	  // Yeh !! gotta the one
	  *o = reg;
	  REGION_LEAVE(region, ERROR_NONE);
	}
    }
  // Not found :(
  cons_msg('!', "region_get : cannot find the region\n");
  REGION_LEAVE(region, ERROR_UNKNOWN);
}

/*
 * Initializes the region manager
 */
t_error		region_init(t_vaddr start, t_vsize size)
{
  if (0 == size)
    {
      cons_msg('!', "region_init : cannot create a region "
	       "manager with a null size\n");
      return (ERROR_UNKNOWN);
    }

  if (0 != start % PAGESZ)
    {
      cons_msg('!', "region_init : address not aligned\n");
      REGION_LEAVE(region, ERROR_UNKNOWN);
    }

  if (NULL == (region = malloc(sizeof(m_region))))
    {
      cons_msg('!', "region_init : cannot allocate memory for the"
	       " region manager structure\n");
      return (ERROR_UNKNOWN);
    }

  memset(region, 0x0, sizeof(m_region));

  region->fit = REGION_FIT;
  region->start = start;
  region->size = size;

  if (ERROR_NONE != machdep_call(region, region_init, REGION_FIT,
				 start, size))
    REGION_LEAVE(region, ERROR_UNKNOWN);

  STATS_RESERVE("region", &region->stats);

  return (ERROR_NONE);
}

/*
 * Cleans the region manager
 */
t_error		region_clean(void)
{
  if (ERROR_NONE != machdep_call(region, region_clean))
    REGION_LEAVE(region, ERROR_UNKNOWN);

  STATS_RELEASE(region->stats);

  free(region);

  return (ERROR_NONE);
}
