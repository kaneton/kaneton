/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/arch/ia32-virtual/services/interrupt.c
 *
 * created       julien quintard   [sat dec 17 17:16:19 2005]
 * updated       Jerome Herbault   [mon mar 20 22:20:27 2006]
 */


/*
 * ------ Includes ------------------------------------------------------------
 */

#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */
extern t_init	*init;
extern t_asid	kasid;

/*
 * ------ Functions -----------------------------------------------------------
 */

t_error		k_init_interrupts()
{

  if (ERROR_NONE != map_reserve(kasid, MAP_OPT_NONE, &(init->machdep.idt),
				PAGESZ, PERM_READ|PERM_WRITE))
    {
      cons_msg('!', "k_init_interrupts: cannot reserve a page for the idt\n");
      return ERROR_UNKNOWN;
    }


  ia32_idt_init(init->machdep.idt, &(init->machdep.idtr));

  if (ERROR_NONE != ia32_build_standart_idt(&(init->machdep.idtr)))
    return ERROR_INT_INIT;

  ia32_activate_interruptions(&(init->machdep.idtr));

  return ERROR_NONE;
}
