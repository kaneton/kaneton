/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/region/region-fit.c
 *
 * created       matthieu bucchianeri   [tue jan 10 01:28:36 2006]
 * updated       matthieu bucchianeri   [tue jan 31 00:21:31 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file implements simple  fitting algorithms for virtual memory
 * management.
 *
 * you can define which algorithm to use with the macro REGION_FIT.
 *
 *  - FIT_FIRST: first fit algorithm - the first large enough space is taken
 *  - FIT_BEST: best fit algorithm - the smaller space is taken
 *  - ...
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop at least a first-fit algorithm.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

machdep_include(region);

/*
 * ---------- extern ----------------------------------------------------------
 */

/*
 * the region manager structure.
 */

extern m_region*       region;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Looks for a region of given size
 * All the size and address are align on PAGESZ
 */
t_error			region_fit(t_asid	asid,
				   t_vsize	size,
				   t_vaddr*	address)
{
  o_as			*as = NULL;
  o_region		*regprev = NULL;
  o_region		*regnext = NULL;

  t_state		state = ITERATOR_STATE_UNUSED;
  t_iterator		it;

  REGION_ENTER(region);

  *address = 0;

  if (ERROR_NONE != as_get(asid, &as))
    return (ERROR_UNKNOWN);

  if (ERROR_NONE != set_head(as->regions, &it))
    {
      /* 0 element */
      if (size > region->size)
	{
	  cons_msg('!', "region_fit : no enough memory\n");
	  REGION_LEAVE(region, ERROR_UNKNOWN);
	}
      *address = region->start;
      REGION_LEAVE(region, ERROR_NONE);
    }

  set_foreach(SET_OPT_FORWARD, as->regions, &it, state)
    {
      if (ERROR_NONE != set_object(as->regions, it, (void**)&regnext))
	{
	  cons_msg('!', "region_fit : cannot get the object\n");
	  REGION_LEAVE(region, ERROR_UNKNOWN);
	}

      if (NULL == regprev)
	{
	  /* Some space before the first region */
	  if (regnext->address > region->start
	      && ALIGNMIN(regnext->address) - region->start >= size)
	    {
	      *address = region->start;
	      REGION_LEAVE(region, ERROR_NONE);
	    }
	}
      else
	{
	  /* Some space between regprev and regnext */
	  if (size <= ALIGNMIN(regnext->address)
	      - ALIGNMAX(regprev->address + regprev->size))
	    {
	      *address = ALIGNMAX(regprev->address + regprev->size);
	      REGION_LEAVE(region, ERROR_NONE);
	    }
	}
      regprev = regnext;
    }

  /* Some space after the last region */
  if (size <= ALIGNMIN(region->start + region->size)
      - ALIGNMAX(regprev->address + regprev->size))
    {
      *address = ALIGNMAX(regprev->address + regprev->size);
      REGION_LEAVE(region, ERROR_NONE);
    }

  /* Space not found */
  REGION_LEAVE(region, ERROR_UNKNOWN);
}
