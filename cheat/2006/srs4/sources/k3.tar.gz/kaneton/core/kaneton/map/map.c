/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/map/map.c
 *
 * created       julien quintard   [wed nov 23 09:19:43 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:44:09 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>


/*
 * ---------- globals ---------------------------------------------------------
 */
m_map		*map = NULL;

/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * Reserves a map
 */
t_error		map_reserve(t_asid	asid,
			    t_opts	opts,
			    t_vaddr	*addr,
			    t_vsize	size,
			    t_perms	perms)
{
  t_segid	segid = ID_UNUSED;
  t_regid	regid = ID_UNUSED;
  o_region	*reg = NULL;

  MAP_ENTER(map);

  if (NULL == addr
      || 0 != (opts & ~(MAP_OPT_NONE|MAP_OPT_FORCE))
      || !(opts == MAP_OPT_NONE || opts == MAP_OPT_FORCE))
    {
      cons_msg('!', "map_reserve : param(s) not valid\n");
      MAP_LEAVE(map, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_reserve(asid, size, perms, &segid))
    {
      cons_msg('!', "map_reserve : cannot reserve a segment\n");
      MAP_LEAVE(map, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != region_reserve(asid, segid, 0, REGION_OPT_MAPALL,
				   (opts == MAP_OPT_FORCE ? *addr : 0),
				   0, &regid))
    {
      cons_msg('!', "map_reserve : cannot reserve a region\n");
      MAP_LEAVE(map, ERROR_UNKNOWN);
    }

  if (MAP_OPT_FORCE != opts)
    {
      if (ERROR_NONE != region_get(asid, regid, &reg))
	{
	  cons_msg('!', "map_reserve : cannot get the region\n");
	  MAP_LEAVE(map, ERROR_UNKNOWN);
	}
      *addr = reg->address;
    }

  MAP_LEAVE(map, ERROR_NONE);
}

/*
 * Releases a map
 */
t_error		map_release(t_asid	asid,
			    t_vaddr	vaddr)
{
  t_regid	regid = ID_UNUSED;
  o_region	*reg = NULL;

  MAP_ENTER(map);

  // the regid is equal to the addr
  regid = (t_regid)vaddr;

  if (ERROR_NONE != region_get(asid, regid, &reg))
    {
      cons_msg('!', "map_release : no such region\n");
      MAP_LEAVE(map, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_release(reg->segid))
    {
      cons_msg('!', "map_release : cannot release the segment\n");
      MAP_LEAVE(map, ERROR_UNKNOWN);
    }

  if (ERROR_NONE != region_release(asid, regid))
    {
      cons_msg('!', "map_release : cannot release the region\n");
      MAP_LEAVE(map, ERROR_UNKNOWN);
    }

  MAP_LEAVE(map, ERROR_NONE);
}

/*
 * Initializes the map manager
 */
t_error		map_init(void)
{

  if (NULL == (map = malloc(sizeof(m_map))))
    {
      cons_msg('!', "map_init : cannot allocate memory for the "
	       "map manager\n");
      return (ERROR_UNKNOWN);
    }

  memset(map, 0x0, sizeof(m_map));

  STATS_RESERVE("map", &map->stats);

  return ERROR_NONE;
}

/*
 * Cleans the map manager
 */
t_error		map_clean(void)
{
  STATS_RELEASE(map->stats);

  free(map);

  return ERROR_NONE;
}
