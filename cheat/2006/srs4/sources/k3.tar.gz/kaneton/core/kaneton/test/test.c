
#include <kaneton.h>

t_error		test_init(void)
{
  test_launch();
  return ERROR_NONE;
}

t_error		test_launch(void)
{
  //  test_array();
  test_ll();
  test_segment();
  test_as();
  test_region();
  test_advanced();
  // test leak
  return ERROR_NONE;
}

t_error		test_clean(void)
{

  return ERROR_NONE;
}
