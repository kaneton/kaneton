/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/kaneton/arch/ia32-virtual/region.c
 *
 * created       julien quintard   [wed dec 14 07:06:44 2005]
 * updated       matthieu bucchianeri   [tue jan 31 00:44:47 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * this file  implements dependent  code for region  manager on  ia32 with
 * paging architecture.
 *
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * students will have to develop this entire part of the project. take
 * a look at the interface  structure declaration to fill it correctly
 * and to write needed functions.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- extern ----------------------------------------------------------
 */

extern m_region*	region;

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the region manager interface.
 */

i_region		region_interface =
  {
    ia32_region_reserve,	// region_reserve
    ia32_region_release,	// region_release
    NULL,			// region_flush
    NULL,			// region_init
    NULL			// region_clean
  };

/*
 * ---------- functions -------------------------------------------------------
 */

t_error			ia32_region_reserve(t_asid	asid,
					    t_segid	segid,
					    t_paddr	offset,
					    t_opts	opts,
					    t_vaddr	vaddr,
					    t_vsize	vsize,
					    t_regid	*regid)
{
  o_as			*as = NULL;
  o_segment		*seg = NULL;

  if (ERROR_NONE != as_get(asid, &as))
    {
      cons_msg('!', "ia32_region_reserve : cannot get the as\n");
      return (ERROR_UNKNOWN);
    }

  if (ERROR_NONE != segment_get(segid, &seg))
    {
      cons_msg('!', "ia32_region_reserve : cannot get the segment\n");
      return (ERROR_UNKNOWN);
    }

  if (ERROR_NONE != ia32_paging_alloc_pages(as->machdep.pd, vaddr,
					    seg->address + offset,
					    vsize, seg->perms))
    {
      cons_msg('!', "ia32_region_reserve : cannot fill up the pt\n");
      return (ERROR_UNKNOWN);
    }

  return (ERROR_NONE);
}


t_error			ia32_region_release(t_asid asid, t_regid regid)
{
  o_as			*as = NULL;
  o_region		*reg = NULL;

  if (ERROR_NONE != as_get(asid, &as))
    {
      cons_msg('!', "ia32_region_release : cannot get the as\n");
      return (ERROR_UNKNOWN);
    }

  if (ERROR_NONE != region_get(asid, regid, &reg))
    {
      cons_msg('!', "ia32_region_release : cannot get the region\n");
      return (ERROR_UNKNOWN);
    }

  if (ERROR_NONE != ia32_paging_free_pages(as->machdep.pd,
					   ALIGNMIN(reg->address),
	 ALIGNMAX(reg->address - ALIGNMIN(reg->address) + reg->size)))
    {
      cons_msg('!', "ia32_region_release : cannot release the region\n");
      return (ERROR_UNKNOWN);
    }

  return (ERROR_NONE);
}
