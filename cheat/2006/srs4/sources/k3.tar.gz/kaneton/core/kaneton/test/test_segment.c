
#include <kaneton.h>

extern m_as		*as;
extern t_asid		kasid;
extern m_segment	*segment;


static t_error		test_good_state()
 {
   t_iterator		it;
   t_state		state = ITERATOR_STATE_UNUSED;
   o_segment		*seg = NULL;
   o_as			*aso = NULL;
   void			*data = NULL;
   t_segid		*segid = NULL;

   set_foreach(SET_OPT_FORWARD, segment->container, &it, state)
     {
       ROE(set_object(segment->container, it, (void**)&seg));
       ROE(as_get(seg->asid, &aso));
       ROE(set_get(aso->segments, seg->segid, &data));
     }

   set_foreach(SET_OPT_FORWARD, as->container, &it, state)
     {
       t_iterator	it2;
       t_state		state2 = ITERATOR_STATE_UNUSED;

       ROE(set_object(as->container, it, (void**)&aso));

       set_foreach(SET_OPT_FORWARD, aso->segments,
		   &it2, state2)
	 {
	   ROE(set_object(aso->segments, it2,
			  (void**)&segid));
	   ROE(set_get(segment->container, *segid,
		       (void**)&data));
	 }
     }
   return (ERROR_NONE);
 }


void		test_segment(void)
{
  t_tskid		tskid1 = 76389;
  t_asid		asid1 = 0;
  t_asid		asid2 = 0;
  t_asid		asid3 = 0;
  t_asid		asid4 = 0;
  t_psize		size1 = PAGESZ;
  t_psize		size2 = 2 * PAGESZ;
  t_psize		size3 = 4 * PAGESZ;
  t_psize		size4 = 8 * PAGESZ;
  t_psize		size5 = 10 * PAGESZ;
  t_psize		size6 = 12 * PAGESZ;
  t_psize		size7 = 14 * PAGESZ;
  t_psize		size8 = 15 * PAGESZ;
  t_perms		perms1 = PERM_READ;
  t_perms		perms2 = PERM_WRITE;
  t_perms		perms4 = PERM_READ | PERM_WRITE;
  t_perms		perms5 = PERM_READ | PERM_EXEC;


  t_segid		segid1;
  t_segid		segid2;
  t_segid		segid3;
  t_segid		segid4;
  t_segid		segid5;
  t_segid		segid6;
  t_segid		segid7;
  t_segid		segid8;


  TEST(as_reserve(tskid1, &asid1));
  TEST(as_reserve(tskid1, &asid2));
  TEST(as_reserve(tskid1, &asid3));
  TEST(as_reserve(tskid1, &asid4));

  // TEST of reserve
  TEST(ERROR_NONE != segment_reserve(asid1, 78, perms1, &segid1));
  TEST(ERROR_NONE != segment_reserve(asid1, size1, perms1, NULL));
  TEST(ERROR_NONE != segment_reserve(ID_UNUSED, size1, perms1, &segid1));

  TEST(segment_reserve(asid1, size1, perms1, &segid1));
  TEST(segment_reserve(asid1, size5, perms5, &segid5));
  TEST(segment_reserve(asid1, size6, perms2, &segid6));

  TEST(segment_reserve(asid2, size2, perms2, &segid2));
  TEST(segment_reserve(asid2, size7, perms4, &segid7));

  TEST(segment_reserve(asid3, size3, perms4, &segid3));
  TEST(segment_reserve(asid3, size8, perms4, &segid8));

  TEST(as_dump());
  TEST(segment_dump());
  TEST(test_good_state());

  TEST(segment_reserve(asid4, size4, perms4, &segid4));

  TEST(test_good_state());


  // TEST of release
  TEST(segment_release(segid3)); // in first
  TEST(segment_release(segid7)); // in last
  TEST(segment_release(segid5)); // in middle
  TEST(segment_release(segid4)); // the last
  TEST(ERROR_NONE != segment_release(segid4)); // one already release
  TEST(test_good_state());

  // TEST of flush
  TEST(segment_flush(asid1));
  TEST(segment_flush(asid1));
  TEST(segment_flush(asid1));
  TEST(segment_flush(asid2));
  TEST(segment_flush(asid3));
  TEST(segment_flush(asid4));
  TEST(segment_flush(asid4));

  TEST(test_good_state());

  // MISC release flush reserve
  // param of segment_reserve
  TEST(ERROR_NONE != segment_reserve(asid1, size2, perms2, NULL));
  TEST(ERROR_NONE != segment_reserve(asid1, size2, 0xFFFFFFFF, &segid1));
  TEST(ERROR_NONE != segment_reserve(asid1, 0x7FFFFFFF, perms2, &segid1));
  TEST(ERROR_NONE != segment_reserve(asid1, 0, perms2, &segid1));
  TEST(ERROR_NONE != segment_reserve(0x7FFFFFFF, size2, perms2, &segid1));
  // param of released
  TEST((ERROR_NONE != segment_release(segid4))); // one already release
  TEST((ERROR_NONE != segment_release(0xFFFFFFFF)));
  // param of flush
  TEST(segment_flush(asid1));
  TEST(ERROR_NONE != segment_flush(0xFFFFFFFF));

  // TEST of inject
  {
    o_segment	seg;

    TEST(ERROR_NONE != segment_inject(0xFFFFFFFF, &seg));
    TEST(ERROR_NONE != segment_inject(asid1, NULL));
  }

  // TEST of give
  TEST(segment_reserve(asid1, size1, perms1, &segid1));
  TEST(segment_reserve(asid1, size5, perms5, &segid5));
  TEST(segment_reserve(asid1, size6, perms4, &segid6));

  TEST(segment_reserve(asid2, size2, perms2, &segid2));
  TEST(segment_reserve(asid2, size7, perms2, &segid7));

  TEST(segment_show(segid7));
  TEST(segment_give(segid7, asid1));		// give to another as
  TEST(test_good_state());
  TEST(segment_give(segid2, asid2));		// give to the same as
  TEST(test_good_state());

  TEST(ERROR_NONE != segment_give(0xFFFFFFFF, asid1));
  TEST(ERROR_NONE != segment_give(segid1, 0xFFFFFFFF));


  TEST(segment_flush(asid1));
  TEST(segment_flush(asid2));
  TEST(test_good_state());

  // TEST of resize
  TEST(segment_reserve(asid3, size3, perms4, &segid3));
  TEST(segment_reserve(asid3, size4, perms4, &segid4));

  TEST(ERROR_NONE != segment_resize(0xFFFFFFFF, size1, &segid1));
  TEST(ERROR_NONE != segment_resize(segid3, 0xFFFFFFFF, &segid1));
  TEST(ERROR_NONE != segment_resize(segid3, size1, NULL));
  TEST(segment_resize(segid3, size1, &segid3));
  TEST(test_good_state());
  TEST((ERROR_NONE != segment_resize(segid3, 0, &segid3)));
  TEST(test_good_state());
  TEST(segment_resize(segid3, size5, &segid3));
  TEST(test_good_state());
  TEST(segment_flush(asid3));
  TEST(test_good_state());

  // TEST of split
  TEST(segment_reserve(asid4, size6, perms4, &segid1));
  TEST(ERROR_NONE != segment_split(0xFFFFFFFF, size1, &segid5, &segid6));
  TEST(ERROR_NONE != segment_split(segid1, 0, &segid5, &segid6));
  TEST(ERROR_NONE != segment_split(segid1, size8, &segid5, &segid6));
  TEST(ERROR_NONE != segment_split(segid1, size2, NULL, &segid6));
  TEST(ERROR_NONE != segment_split(segid1, size2, &segid5, NULL));

  TEST(test_good_state());
  TEST(segment_split(segid1, size5, &segid5, &segid6));
  TEST(test_good_state());

  TEST(segment_flush(asid1));
  TEST(segment_flush(asid2));
  TEST(segment_flush(asid3));
  TEST(segment_flush(asid4));
  TEST(segment_reserve(asid1, size1, perms1, &segid1));
  TEST(segment_reserve(asid1, size5, perms5, &segid5));
  TEST(segment_dump());
  TEST(test_good_state());

  // TEST of coalesce
  TEST(segment_reserve(asid1, size1, perms2, &segid1));
  TEST(segment_reserve(asid1, size5, perms4, &segid5));
  TEST(segment_reserve(asid1, size6, perms4, &segid6));
  TEST(test_good_state());
  TEST(ERROR_NONE != segment_coalesce(ID_UNUSED, segid1, &segid7));
  TEST(ERROR_NONE != segment_coalesce(segid5, 0xFFFFFFFF, &segid7));
  TEST(ERROR_NONE != segment_coalesce(segid5, segid1, NULL));
  TEST(ERROR_NONE != segment_coalesce(segid1, segid1, &segid1));

  TEST(segment_coalesce(segid5, segid1, &segid7));
  TEST(test_good_state());
  TEST(segment_flush(asid1));
  TEST(test_good_state());


  // TEST of perms and type
  TEST(segment_reserve(asid1, size1, perms1, &segid1));
  TEST(segment_perms(segid1, PERM_READ));
  TEST(ERROR_NONE != segment_perms(0xFFFFFFF, PERM_READ));
  TEST(ERROR_NONE != segment_perms(segid1, 0xFFFFFF));

  TEST(segment_type(segid1, SEGMENT_TYPE_MEMORY));
  TEST(segment_type(segid1, SEGMENT_TYPE_CATCH));

  TEST(ERROR_NONE != segment_type(segid1,
				  SEGMENT_TYPE_CATCH|SEGMENT_TYPE_MEMORY));
  TEST(ERROR_NONE != segment_type(segid1, 0xFFFFFF));

  TEST(segment_flush(asid1));
  TEST(test_good_state());

  // TEST of get
  {
    o_segment	*seg = NULL;

    TEST(segment_reserve(asid1, size1, perms1, &segid1));
    TEST(segment_get(segid1, &seg));
    TEST(ERROR_NONE != segment_get(0xFFFFFFFF, &seg));
    TEST(ERROR_NONE != segment_get(segid1, NULL));
  }

  // TEST of catch
  //
  // TODO



  TEST(segment_flush(asid1));
  TEST(segment_flush(asid2));
  TEST(segment_flush(asid3));
  TEST(segment_flush(asid4));

  TEST(as_release(asid1));
  TEST(as_release(asid2));
  TEST(as_release(asid3));
  TEST(as_release(asid4));

}
