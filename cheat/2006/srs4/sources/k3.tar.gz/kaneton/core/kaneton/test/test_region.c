
#include <kaneton.h>


void		test_region(void)
{
  t_tskid	taskid = 0x988;
  t_asid	asid = ID_UNUSED;

  o_region	reg;

  t_vaddr	vaddr0 = 0;
  t_vaddr	vaddr1 = 0;
  t_vaddr	vaddr2 = 0;
  t_vaddr	vaddr3 = 0;
  t_vaddr	vaddr4 = 0;
  t_vaddr	vaddr5 = 0;
  t_vaddr	vaddr6 = 0;
  t_vaddr	vaddr7 = 0;
  t_vaddr	vaddr8 = 0;
  t_vaddr	vaddr9 = 0;
  t_vaddr	vaddr10 = 0;
  t_vaddr	vaddr11 = 0;
  t_vaddr	vaddr12 = 0;
  t_vaddr	vaddr13 = 0;
  t_vaddr	vaddr14 = 0;
  t_vaddr	vaddr15 = 0;
  t_vaddr	vaddr16 = 0;
  t_vaddr	vaddr17 = 0;
  t_vaddr	vaddr18 = 0;
  t_vaddr	vaddr19 = 0;
  t_vaddr	vaddr20 = 0;
  t_vaddr	vaddr21 = 0;
  t_vaddr	vaddr22 = 0;
  t_vaddr	vaddr23 = 0;
  t_vaddr	vaddr24 = 0;
  t_vaddr	vaddr25 = 0;
  t_vaddr	vaddr26 = 0;
  t_vaddr	vaddr27 = 0;
  t_vaddr	vaddr28 = 0;
  t_vaddr	vaddr29 = 0;
  t_vaddr	vaddr30 = 0;
  t_vaddr	vaddr31 = 0;
  t_vaddr	vaddr32 = 0;
  t_vaddr	vaddr33 = 0;
  t_vaddr	vaddr34 = 0;
  t_vaddr	vaddr35 = 0;
  t_vaddr	vaddr36 = 0;
  t_vaddr	vaddr37 = 0;
  t_vaddr	vaddr38 = 0;
  t_vaddr	vaddr39 = 0;
  t_vaddr	vaddr40 = 0;
  t_vaddr	vaddr41 = 0;
  t_vaddr	vaddr42 = 0;
  t_vaddr	vaddr43 = 0;
  t_vaddr	vaddr44 = 0;
  t_vaddr	vaddr45 = 0;
  t_vaddr	vaddr46 = 0;
  t_vaddr	vaddr47 = 0;
  t_vaddr	vaddr48 = 0;
  t_vaddr	vaddr49 = 0;


  TEST(as_reserve(taskid, &asid));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr0, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr1, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr2, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr3, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr4, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr5, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr6, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr7, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr8, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr9, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr10, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr11, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr12, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr13, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr14, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr15, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr16, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr17, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr18, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr19, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr20, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr21, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr22, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr23, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr24, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr25, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr26, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr27, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr28, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr29, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr30, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr31, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr32, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr33, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr34, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr35, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr36, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr37, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr38, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr39, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr40, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr41, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr42, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr43, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr44, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr45, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr46, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr47, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr48, 0x5b000, PERM_READ));
  TEST(map_reserve(asid, MAP_OPT_NONE, &vaddr49, 0x5b000, PERM_READ));

  TEST(region_dump(asid));

  // show
  TEST(ERROR_NONE != region_show(asid, (t_regid)(vaddr49 + 34)));
  TEST(ERROR_NONE != region_show(asid, ID_UNUSED));
  TEST(region_show(asid, (t_regid)vaddr23));
  TEST(ERROR_NONE != region_show(ID_UNUSED, vaddr23));

  // dump
  TEST(region_dump(asid));
  TEST(ERROR_NONE != region_dump(ID_UNUSED));

  // inject
  TEST(ERROR_NONE != region_inject(asid, NULL));
  TEST(ERROR_NONE != region_inject(ID_UNUSED, &reg));

  TEST(region_flush(asid));
  TEST(as_release(asid));

}
