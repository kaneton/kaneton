/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/kaneton/id/id.c
 *
 * created       julien quintard   [fri feb 11 03:04:40 2005]
 * updated       Jerome Herbault   [fri mar 31 11:59:22 2006]
 */

/*
 * ---------- information -----------------------------------------------------
 *
 * the kaneton kernel uses 64-bit identifier.
 *
 * from this fact, we do not care about identifier recycling.
 *
 * the best example of this fact is located in the event_release()
 * function. indeed the function does nothing, meaning that the
 * identifier released will not be recycled.
 */

/*
 * ---------- assignments -----------------------------------------------------
 *
 * the goal of the id manager is simply to generate identifier.
 *
 * this is the simpler manager of the kaneton kernel.
 */

/*
 * ---------- includes --------------------------------------------------------
 */

#include <klibc.h>
#include <kaneton.h>

/*
 * ---------- globals ---------------------------------------------------------
 */

/*
 * the event manager structure.
 */

m_event*			event = NULL;
/*
 * ---------- functions -------------------------------------------------------
 */

/*
 * this function ...
 */
t_error                 event_init(void)
{
  if (NULL == (event = malloc(sizeof(m_event))))
    {
      cons_msg('!', "event_init : cannot allocate memory for the"
               " event manager structure\n");
      return (ERROR_UNKNOWN);
    }

  memset(event, 0x0, sizeof(m_event));
  if (ERROR_NONE != set_reserve(ll,
                                SET_OPT_ALLOC|SET_OPT_SORT,
                                sizeof(o_event),
                                &event->container))
    {
      cons_msg('!', "event_init : unable to reserve a set\n");
      return (ERROR_UNKNOWN);
    }
  //FIXE-ME : OTHER INIT ?

  return (ERROR_NONE);
}




/*
 * Display information.
 */
t_error                 event_show(t_evid    u)
{
  o_event             *evt = NULL;

  EVENT_ENTER(event);

  if (ERROR_NONE != event_get(u, &evt))
    {
      cons_msg('!', "event_show : No such event\n");
      EVENT_LEAVE(event, ERROR_UNKNOWN);
    }

  //FIXEME PRINTF
  EVENT_LEAVE(event, ERROR_NONE);
}


/*
 * this function just display a event_object state
 */

t_error                 event_dump(void)
{
  t_state               state = ITERATOR_STATE_UNUSED;
  t_iterator            i;
  o_event               *evt = NULL;

  EVENT_ENTER(event);

  set_foreach(SET_OPT_FORWARD, event->container, &i, state)
    {
      if (ERROR_NONE != set_object(event->container, i, (void**)&evt))
        {
          cons_msg('!', "event_dump : cannot get the data from "
                   "this event\n");
          EVENT_LEAVE(event, ERROR_UNKNOWN);
        }
      if (ERROR_NONE != event_show(evt->id))
        {
          cons_msg('!', "event_dump : cannot show this event\n");
          SET_LEAVE(event, ERROR_UNKNOWN);
        }
    }
  EVENT_LEAVE(event, ERROR_NONE);
}

/*
 * this function duplicate an id object using the o identifier object
 */

t_error                 event_clone(t_evid                          curr,
				    t_evid			    new)
{
  o_event               *evt = NULL;
  o_event               n_evt;

  EVENT_ENTER(event);
  if (ERROR_NONE != event_get(curr, &evt))
    EVENT_LEAVE(event, ERROR_UNKNOWN);
  memcpy(evt, &n_evt, sizeof(o_event));

  if (ERROR_NONE != event_insert(new, &n_evt))
    EVENT_LEAVE(event, ERROR_NONE);

  EVENT_LEAVE(event, ERROR_NONE);
}

t_error                 event_get(t_evid            u,
				  o_event**         o)
{
  EVENT_ENTER(event);

  if (ERROR_NONE != set_get(event->container, u, (void**)o))
    {
      cons_msg('!', "event_get : cannot get the event object\n");

      EVENT_LEAVE(event, ERROR_UNKNOWN);
    }

  EVENT_LEAVE(event, ERROR_NONE);
}


/*
 * this function ...
 */
t_error                 event_insert(t_evid                         evid,
				     o_event*                       obj)
{
  EVENT_ENTER(event);  
  if (NULL == obj)
    {
      cons_msg('!', "event_insert : try to add a null object\n");

      EVENT_LEAVE(event, ERROR_UNKNOWN);
    }

  //FIXEME
  obj->id = evid;

  if (ERROR_NONE != set_add(event->container, obj))
    {
      cons_msg('!', "event : cannot add obj to container\n");
      EVENT_LEAVE(event, ERROR_UNKNOWN);
    }

  EVENT_LEAVE(event, ERROR_NONE);
}

/*
 * this function ...
 */
t_error                 event_release(t_evid                         curr)
{
  EVENT_ENTER(event);
  //FIXEME
  if (ERROR_NONE != set_remove(event->container, curr))
    {
      cons_msg('!', "event : cannot release the address space\n");
      EVENT_LEAVE(event, ERROR_UNKNOWN);
    }

  EVENT_LEAVE(event, ERROR_NONE);
}

/*
 * this function ...
 */
t_error                 event_mask(t_evid                          curr)
{
  o_event               *evt = NULL;

  EVENT_ENTER(event);

  if (ERROR_NONE != event_get(curr, &evt))
    EVENT_LEAVE(event, ERROR_UNKNOWN);

  evt->state = EVENT_MASKED;

  EVENT_LEAVE(event, ERROR_NONE);
}


/*
 * this function ...
 */
t_error                 event_unmask(t_evid                         curr)
{
  o_event               *evt = NULL;

  EVENT_ENTER(event);

  if (ERROR_NONE != event_get(curr, &evt))
    EVENT_LEAVE(event, ERROR_UNKNOWN);

  evt->state = EVENT_NOT_MASKED;

  EVENT_LEAVE(event, ERROR_NONE);
}

/*
 * this function just destroy the id manager
 */

t_error                 event_clean(void)
{
  EVENT_ENTER(event);

  EVENT_LEAVE(event, ERROR_NONE);
}

