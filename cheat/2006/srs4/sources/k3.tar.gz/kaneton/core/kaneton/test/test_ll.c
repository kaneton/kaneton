
#include <kaneton.h>

void		test_ll(void)
{
  int			i1 = 501;
  int			i2 = 502;
  int			i3 = 503;
  int			i4 = 504;
  int			i5 = 505;
  int			i6 = 506;
  int			i7 = 507;
  int			i8 = 508;

  t_iterator		it;

  t_setid		set = 12345678;
  t_setid		set2 = 9876543;;

  TEST(set_reserve(ll, SET_OPT_ALLOC|SET_OPT_SORT, sizeof(int), &set));
  TEST((ERROR_NONE != set_reserve(ll, 0x88888, sizeof(int), &set2)));
  TEST((ERROR_NONE != set_reserve(ll, SET_OPT_ALLOC|SET_OPT_FREE,
				  sizeof(int), &set2)));
  TEST((ERROR_NONE != set_reserve(ll, SET_OPT_ALLOC, sizeof(int), NULL)));
  TEST((ERROR_NONE != set_reserve(ll, SET_OPT_ALLOC, 0, &set2)));

  TEST(set_type_ll(set));
  // FIXME set_type_array
  // TEST(ERROR_NONE != set_type_array(set));
  TEST(set_show(set));
  TEST(set_flush(set));
  TEST(ERROR_NONE != set_locate(set, i7, &it));
  TEST(ERROR_NONE != set_show(set2));
  TEST(ERROR_NONE != set_flush(set2));

  TEST(ERROR_NONE != set_head(set, NULL));
  TEST(ERROR_NONE != set_head(set2, &it));
  TEST(ERROR_NONE != set_tail(set, NULL));
  TEST(ERROR_NONE != set_tail(set2, &it));

  TEST(ERROR_NONE != set_insert_head(set2, &i8));
  TEST(ERROR_NONE != set_insert_head(set, NULL));
  TEST(ERROR_NONE != set_insert_tail(set2, &i8));
  TEST(ERROR_NONE != set_insert_tail(set, NULL));

  TEST(set_add(set, &i1));
  TEST(set_add(set, &i2));
  TEST(set_add(set, &i3));
  TEST(set_add(set, &i4));
  TEST(ERROR_NONE != set_add(set, NULL));
  TEST(set_locate(set, i1, &it));
  TEST(ERROR_NONE != set_object(set, it, NULL));
  TEST(set_reserve(ll, SET_OPT_ALLOC|SET_OPT_SORT, sizeof(int), &set2));
  TEST(set_add(set2, &i5));
  TEST(set_add(set2, &i6));
  TEST(set_add(set2, &i7));
  TEST(set_add(set2, &i8));

  TEST(ERROR_NONE != set_locate(set, i1, NULL));
  TEST(ERROR_NONE != set_locate(set, i7, &it));
  TEST(ERROR_NONE != set_locate(set2, i1, &it));
  //  TEST(ERROR_NONE != set_prev(set, it, &it2));

  TEST(set_locate(set, i1, &it));
  TEST(set_insert_before(set, it, &i5));
  TEST(set_locate(set, i4, &it));
  TEST(set_insert_after(set, it, &i8));
  TEST(set_locate(set, i2, &it));
  TEST(set_insert_before(set, it, &i6));
  TEST(set_locate(set, i3, &it));
  TEST(set_insert_after(set, it, &i7));
  TEST(set_flush(set));
  TEST(set_flush(set));
  TEST(set_release(set));
  TEST(set_release(set2));
  TEST((ERROR_NONE != set_release(set2)));
}
