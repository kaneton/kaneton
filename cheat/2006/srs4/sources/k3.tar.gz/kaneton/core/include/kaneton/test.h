#ifndef KANETON_TEST_H
# define KANETON_TEST_H

/*
 * ---------- dependencies ----------------------------------------------------
 */

/*
 * ---------- defines ---------------------------------------------------------
 */

/*
 * ---------- types -----------------------------------------------------------
 */


/*
 * ---------- macros ----------------------------------------------------------
 */

#define TEST(_fct_)							\
{									\
  t_error	err;							\
  printf("%-70.70s   ", #_fct_);					\
  err = _fct_;								\
  if (err != ERROR_NONE)						\
   {									\
     printf("%#[%# KO %#]%#\n",						\
	    CONS_FRONT(CONS_BLUE) | CONS_BACK(CONS_BLACK) | CONS_INT,	\
	    CONS_FRONT(CONS_RED) | CONS_BACK(CONS_BLACK) | CONS_INT,	\
	    CONS_FRONT(CONS_BLUE) | CONS_BACK(CONS_BLACK) | CONS_INT,	\
	    CONS_FRONT(CONS_WHITE) | CONS_BACK(CONS_BLACK));		\
     kaneton_error(#_fct_);						\
   }									\
  printf("%#[%# OK %#]%#\n",						\
	 CONS_FRONT(CONS_BLUE) | CONS_BACK(CONS_BLACK) | CONS_INT,	\
	 CONS_FRONT(CONS_GREEN) | CONS_BACK(CONS_BLACK) | CONS_INT,	\
	 CONS_FRONT(CONS_BLUE) | CONS_BACK(CONS_BLACK) | CONS_INT,	\
	 CONS_FRONT(CONS_WHITE) | CONS_BACK(CONS_BLACK));		\
}

#define TEST_LEAK()		TEST((alloc_nalloc()			\
					 == alloc_nfree() ?		\
 				    ERROR_NONE : ERROR_UNKNOWN))

/* Halt On Error */
#define	HOE(_func_)		if (ERROR_NONE != (_func_))		\
				  {					\
					while (42);			\
				  }

/* Return On Error */
#define	ROE(_func_)		if (ERROR_NONE != (_func_))		\
				  {					\
					return (ERROR_UNKNOWN);		\
				  }



/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/test/test.c
 *      ../../kaneton/test/test_array.c
 *      ../../kaneton/test/test_as.c
 *      ../../kaneton/test/test_ll.c
 *      ../../kaneton/test/test_segment.c
 *	../../kaneton/test/test_advanced.c
 *	../../kaneton/test/test_region.c
 */

/*
 * ../../kaneton/test/test.c
 */

t_error		test_init(void);

t_error		test_launch(void);

t_error		test_clean(void);


/*
 * ../../kaneton/test/test_array.c
 */

void		test_array_reserve(void);
void		test_array_alloc(void);

void		test_array_reserve(void);

void		test_array_alloc(void);

void		test_array_free(void);

void		test_array(void);


/*
 * ../../kaneton/test/test_as.c
 */

void		test_as(void);


/*
 * ../../kaneton/test/test_ll.c
 */

void		test_ll(void);


/*
 * ../../kaneton/test/test_segment.c
 */

void		test_segment(void);


/*
 * ../../kaneton/test/test_advanced.c
 */

void		test_advanced(void);


/*
 * ../../kaneton/test/test_region.c
 */

void		test_region(void);


/*
 * eop
 */

#endif
