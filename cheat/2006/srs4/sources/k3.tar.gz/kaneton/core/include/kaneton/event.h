/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/buckman/kaneton/core/include/kaneton/event.h
 *
 * created       julien quintard   [fri feb 11 02:19:44 2005]
 * updated       matthieu bucchianeri   [tue jan 24 11:32:18 2006]
 */

#ifndef KANETON_EVENT_H
#define KANETON_EVENT_H		1

/*
 * ---------- dependencies ----------------------------------------------------
 */

#include <arch/machdep/machdep.h>
#include <kaneton/types.h>

/*
 * ---------- types -----------------------------------------------------------
 */

/*
 * identifier object
 */

enum event_states
  {
    EVENT_NOT_MASKED = 0,
    EVENT_MASKED = 1
  };

typedef struct
{
  t_evid				id;
  enum event_states                     state;
  t_paddr                               pCallBackFunc;             

  //machdep_data(o_event);
}				        o_event;

/*
 * the identifier manager
 */

typedef struct
{
  o_id				id;
  t_staid			stats;

  t_setid                       container;

  //machdep_data(m_event);
}				m_event;

/*
 * ---------- defines ---------------------------------------------------------
 */


/*
 * ---------- macros ----------------------------------------------------------
 */

/*
 * check
 */

#define EVENT_CHECK(_event_)							\
  {									\
    if ((_event_) == NULL)							\
      return (ERROR_UNKNOWN);						\
  }

/*
 * enter
 */

#define EVENT_ENTER(_event_)							\
  {									\
    EVENT_CHECK((_event_));							\
									\
    STATS_BEGIN((_event_)->stats);						\
  }

/*
 * leave
 */

#define EVENT_LEAVE(_event_, _error_)						\
  {									\
    STATS_END((_event_)->stats, (_error_));				\
									\
    return (_error_);							\
  }

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *      ../../kaneton/event/event.c
 */

/*
 * ../../kaneton/event/event.c
 */

t_error                 event_init(void);

t_error                 event_show(t_evid    u);

t_error                 event_dump(void);

t_error                 event_clone(t_evid                          curr,
				    t_evid			    new);

t_error                 event_get(t_evid            u,
				  o_event**         o);

t_error                 event_insert(t_evid                         evid,
				     o_event*                       obj);

t_error                 event_release(t_evid                         curr);

t_error                 event_mask(t_evid                          curr);

t_error                 event_unmask(t_evid                         curr);

t_error                 event_clean(void);


/*
 * eop
 */

#endif
