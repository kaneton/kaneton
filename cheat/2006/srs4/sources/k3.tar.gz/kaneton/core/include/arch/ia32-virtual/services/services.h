/*
 * licence       kaneton licence
 *
 * project       kaneton
 *
 * file          /home/master/dev/k1.1/kaneton/core/include/arch/ia32-virtual/services/services.h
 *
 * created       julien quintard   [sat dec 17 17:16:19 2005]
 * updated       Jerome Herbault   [mon mar 20 21:24:12 2006]
 */

#ifndef IA32_SERVICES_SERVICES_H
#define IA32_SERVICES_SERVICES_H	1

/*
 * ---------- includes --------------------------------------------------------
 */

/*
 * ---------- prototypes ------------------------------------------------------
 *
 *	../../../../kaneton/arch/machdep/services/interrupt.c
 *	../../../../kaneton/arch/machdep/services/keyboard.c
 *	../../../../kaneton/arch/machdep/services/timer.c
 *	../../../../kaneton/arch/machdep/services/pic.c
 *
 */

/*
 * ../../../../kaneton/arch/machdep/services/interrupt.c
 */

t_error		k_init_interrupts();


/*
 * ../../../../kaneton/arch/machdep/services/keyboard.c
 */

t_error		k_init_keyb(void);

char		k_getchar(void);

t_error		k_loadkeys(const char*		map);


/*
 * ../../../../kaneton/arch/machdep/services/timer.c
 */

t_bool		k_timer_init(t_uint32		frequency,
			     t_bool		force);

t_bool		k_sleep(t_uint32	mil_sec_length);


/*
 * ../../../../kaneton/arch/machdep/services/pic.c
 */

t_error		k_init_pic(void);

t_error		k_pic_enable(t_uint16		irq);

t_error		k_pic_disable(t_uint16		irq);


/*
 * eop
 */

#include <arch/machdep/services/cons.h>

#endif
