#include <elf32.h>
#include <multiboot.h>
#include <strings.h>
#include <printf.h>
#include <assert.h>

/*
 * global variables
 */


/*
 * extern variables
 */
extern char		_kernel_top;
extern _t_phys_addr	kernel_top;

/*
 * static variables
 */
static _t_elf32_infos	elf32_infos;

/*
 * static functions
 */
/* Is In Symbol Description Address Range */
static char		is_in_symbol_range(_t_elf32_sym		*sym,
					     unsigned int	addr)
{
  K_ASSERT_FATAL(sym);
  if ((addr >= sym->_value) && (addr < (sym->_value + sym->_size)))
    return 1;
  return 0;
}

/*
static void		dump_elf32_shdr(_t_elf32_shdr	*shdr,
					int		limit_pos)
{
  char			buf[CONSOLE_X];

  K_ASSERT_FATAL(shdr);
  k_snprintf(buf, (size_t)CONSOLE_X, "%#x", shdr);
  k_print_info(" Section header address ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%d", (int)(((char *)shdr -
	     (char *)(elf32_infos._shdrs)) / sizeof (_t_elf32_shdr)));
  k_print_info(" Section header index ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%u %s", shdr->_name,
	     elf32_infos._sh_strtbl + shdr->_name);
  k_print_info("     Name ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u", shdr->_type);
  k_print_info("     Type ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u", shdr->_flags);
  k_print_info("     Flags ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%#x", shdr->_addr);
  k_print_info("     Address ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u", shdr->_offset);
  k_print_info("     Offset ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u Bytes", shdr->_size);
  k_print_info("     Size ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u", shdr->_link);
  k_print_info("     Link ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u", shdr->_info);
  k_print_info("     Info ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u", shdr->_addralign);
  k_print_info("     Addr align ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u", shdr->_entsize);
  k_print_info("     Ent size ", limit_pos, buf);
}

static void		dump_elf32_sym(_t_elf32_sym	*sym,
				       int		limit_pos)
{
  char			buf[CONSOLE_X];

  K_ASSERT_FATAL(sym);
  k_snprintf(buf, (size_t)CONSOLE_X, "%#x", sym);
  k_print_info(" Symbol address ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%d",
	     (int)(((char *)sym - (char *)(elf32_infos._symtbl)) /
	     sizeof (_t_elf32_sym)));
  k_print_info(" Symbol index ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u %s", sym->_name,
	     k_resolv_symbol_name(sym));
  k_print_info("     Name ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u", sym->_value);
  k_print_info("     Value ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u Bytes", sym->_size);
  k_print_info("     Size ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%hhu", sym->_info);
  k_print_info("     Info ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%hhu", sym->_other);
  k_print_info("     Other ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%hu", sym->_shndx);
  k_print_info("     Shndx ", limit_pos, buf);
}
*/

/*
 * Init elf32
 *
 * Stores elf32 informations with multiboot infos.
 *  - beginning of section headers table
 *    (_t_elf32_shdr *elf32_infos._shdrs)
 *  - number of section headers
 *    (unsigned int elf32_infos._shdrs_size_num)
 *
 *  - section header string table section header
 *    (_t_elf32_shdr *elf32_infos._sh_strtbl_shdr)
 *  - section header string table (unsigned char *elf32_infos._sh_strtbl)
 *    Used to retrieve other sections with section name.
 *
 * Stores elf32 informations with section headers.
 *  - symbol table section header
 *    (_t_elf32_shdr *elf32_infos._symtbl_shdr)
 *  - symbol table
 *    (_t_elf32_sym *elf32_infos._symtbl)
 *  - symbol table size
 *    (unsigned int elf32_infos._symtbl_size)
 *    Used to retrieve symbols.
 *
 *  - String table section header
 *    (unsigned char *elf32_infos._strtbl_shdr)
 *  - String table
 *    (unsigned char *elf32_infos._strtbl)
 *    Used to resolv symbols.
 *
 *  - Code section header
 *    (_t_elf32_shdr *elf32_infos._code_shdr)
 *    Used to check if an adress is in the code section.
 */
void		k_init_elf32()
{
  char			buf[CONSOLE_X + 1];
  int			limit_pos =
    strlen(" Section header string table section header @ ");
  int			title_end = 0;
  //  int			i;

  title_end = k_print_initializing("Elf32 informations (already done)");

  k_print_initialization_result(1);
  k_print_up_border_info(limit_pos, title_end);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", &_kernel_top);
  k_print_info(" Kernel top from ld ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", elf32_infos._strtbl +
	     elf32_infos._strtbl_shdr->_size);
  k_print_info(" Kernel top adjusted ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", kernel_top);
  k_print_info(" Kernel top adjusted and page aligned ", limit_pos, buf);
  k_print_info(" ", limit_pos, "");

  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", elf32_infos._shdrs);
  k_print_info(" Section headers @ ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%u", elf32_infos._shdrs_num);
  k_print_info(" Section headers number ", limit_pos, buf);

  /*
  k_snprintf(buf, (size_t)CONSOLE_X, "%s", DUMP_SECTION_HEADERS ?
	     "Yes" : "No");
  k_print_info(" Dump section headers ", limit_pos, buf);

  if (DUMP_SECTION_HEADERS)
    {
      k_print_info("", limit_pos, "");
      k_print_info(" --------- Dump of section headers ---------- ",
		   limit_pos, "");
      for (i = 0; i < elf32_infos._shdrs_num; i++)
	{
	  k_print_info("", limit_pos, "");
	  dump_elf32_shdr(elf32_infos._shdrs + i, limit_pos);
	}
      k_print_info(" -------------------------------------------- ",
		   limit_pos, "");
    }
  */

  k_print_info("", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", elf32_infos._sh_strtbl_shdr);
  k_print_info(" Section header string table section header @ ", limit_pos,
	       buf);
  /*
  if (DUMP_SECTION_HEADERS)
    dump_elf32_shdr(elf32_infos._sh_strtbl_shdr, limit_pos);
  */
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", elf32_infos._sh_strtbl);
  k_print_info(" Section header string table @ ", limit_pos, buf);

  k_print_info("", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", elf32_infos._strtbl_shdr);
  k_print_info(" String table section header @ ", limit_pos, buf);

  /*
  if (DUMP_SECTION_HEADERS)
    dump_elf32_shdr(elf32_infos._strtbl_shdr, limit_pos);
  */
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", elf32_infos._strtbl);
  k_print_info(" String table @ ", limit_pos, buf);


  k_print_info("", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", elf32_infos._code_shdr);
  k_print_info(" Code section header @ ", limit_pos, buf);
  /*
  if (DUMP_SECTION_HEADERS)
    dump_elf32_shdr(elf32_infos._code_shdr, limit_pos);
  */

  k_print_info("", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", elf32_infos._symtbl_shdr);
  k_print_info(" Symbol table section header @ ", limit_pos, buf);
  /*
  if (DUMP_SECTION_HEADERS)
    dump_elf32_shdr(elf32_infos._symtbl_shdr, limit_pos);
  */
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x", elf32_infos._symtbl);
  k_print_info(" Symbol table @ ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%u symbols", elf32_infos._symtbl_size);
  k_print_info(" Symbol table size ", limit_pos, buf);

  /*
  k_snprintf(buf, (size_t)CONSOLE_X, "%s", DUMP_SYMBOL_TABLE ? "Yes" : "No");
  k_print_info(" Dump symbol table ", limit_pos, buf);

  if (DUMP_SYMBOL_TABLE)
    {
      k_print_info("", limit_pos, "");
      k_print_info(" ------------- Dump of symbols -------------- ",
		   limit_pos, "");
      for (i = 0; i < elf32_infos._symtbl_size; i++)
	{
	  k_print_info("", limit_pos, "");
	  dump_elf32_sym(elf32_infos._symtbl + i, limit_pos);
	}
      k_print_info(" -------------------------------------------- ",
		   limit_pos, "");
    }
  */
  k_print_down_border_info(limit_pos);
}

/*
 * Find Symbol At
 *
 * Retrieves Symbol descripting address.
 * It search the symbol containing adress in its description adresses range
 * and return it when found.
 */
_t_elf32_sym	*k_find_symbol_at(unsigned int	addr)
{
  int i;

  if ((!elf32_infos._symtbl_size) || (!elf32_infos._symtbl))
    return 0;
  for (i = 0; i < elf32_infos._symtbl_size; i++)
    if (is_in_symbol_range(&elf32_infos._symtbl[i], addr))
      return &elf32_infos._symtbl[i];
  return 0;
}

/*
 * Resolv Symbol Name
 *
 * Resolv name of a symbol using string table.
 * _name field of a _t_elf32_sym give offset to obtain the name in string
 * table.
 */
unsigned char	*k_resolv_symbol_name(_t_elf32_sym	*sym)
{
  K_ASSERT_FATAL(sym && elf32_infos._strtbl);
  return elf32_infos._strtbl + sym->_name;
}

/*
 * Is In Code Section
 *
 * Check if unsigned int value is in code section range.
 */
char		k_is_in_code_section(unsigned int value)
{
  if ((value >= elf32_infos._code_shdr->_addr) &&
      (value < elf32_infos._code_shdr->_addr + elf32_infos._code_shdr->_size))
    return 1;
  return 0;
}

/* Get Elf32 Section Header With Section Name
 *
 * To retrieve sections, _name field of _t_elf32_shdr structures
 * gives offset where find the name of the section in section header
 * string table.
 * All section header names are compared to find the wanted
 * sections and search is stopped if it's found.
 */
_t_elf32_shdr		*k_get_elf32_shdr_with_s_name(char	*s_name)
{
  int			i;
  int			f = -1;

  K_ASSERT_FATAL(s_name && elf32_infos._sh_strtbl);
  for (i = 0; i < elf32_infos._shdrs_num; i++)
    if (!strcmp((char *)(elf32_infos._sh_strtbl + elf32_infos._shdrs[i]._name),
		s_name))
      if ((elf32_infos._shdrs[i]._size != 0) || (f == -1))
	f = i;
  if (f != -1)
    return &(elf32_infos._shdrs[f]);
  return 0;
}


void		k_init_first_elf32(_t_multiboot_info	*mbi)
{
  elf32_infos._shdrs = (_t_elf32_shdr *)(mbi->_u._elf_sec._addr);
  elf32_infos._shdrs_num = mbi->_u._elf_sec._num;

  elf32_infos._sh_strtbl_shdr = &elf32_infos._shdrs[mbi->_u._elf_sec._shndx];
  elf32_infos._sh_strtbl = (unsigned char *)elf32_infos._sh_strtbl_shdr->_addr;

  elf32_infos._symtbl_shdr = k_get_elf32_shdr_with_s_name(".symtab");
  elf32_infos._symtbl = (_t_elf32_sym *)elf32_infos._symtbl_shdr->_addr;
  elf32_infos._symtbl_size = elf32_infos._symtbl_shdr->_size /
    sizeof (_t_elf32_sym);

  elf32_infos._strtbl_shdr = k_get_elf32_shdr_with_s_name(".strtab");
  elf32_infos._strtbl = (unsigned char *)(elf32_infos._strtbl_shdr->_addr);

  elf32_infos._code_shdr = k_get_elf32_shdr_with_s_name(".text");
}
