#include <exception.h>
#include <gdt.h>
#include <idt.h>
#include <idt_entry.h>
#include <console.h>
#include <debugger.h>
#include <registers.h>
#include <strings.h>
#include <printf.h>
#include <segment.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */
static _t_idt_handler	exception_handlers[IDT_EXCEPTION_NUM + 1] =
  {
    { (unsigned int)_k_int_00,
      IDT_EXCEPTION_BASE + K_EXCEPTION_DIVIDE_ERROR,
      (unsigned char *)"divide-by-zero" },
    { (unsigned int)_k_int_01,
      IDT_EXCEPTION_BASE + K_EXCEPTION_DEBUG,
      (unsigned char *)"debug exception" },
    { (unsigned int)_k_int_02,
      IDT_EXCEPTION_BASE + K_EXCEPTION_NMI_INTERRUPT,
      (unsigned char *)"non-maskable interrupt" },
    { (unsigned int)_k_int_03,
      IDT_EXCEPTION_BASE + K_EXCEPTION_BREAKPOINT,
      (unsigned char *)"breakpoint" },
    { (unsigned int)_k_int_04,
      IDT_EXCEPTION_BASE + K_EXCEPTION_OVERFLOW,
      (unsigned char *)"overflow" },
    { (unsigned int)_k_int_05,
      IDT_EXCEPTION_BASE + K_EXCEPTION_BOUND_RANGE_EXCEDEED,
      (unsigned char *)"bound exception" },
    { (unsigned int)_k_int_06,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INVALID_OPCODE,
      (unsigned char *)"invalid opcode" },
    { (unsigned int)_k_int_07,
      IDT_EXCEPTION_BASE + K_EXCEPTION_DEVICE_NOT_AVAILABLE,
      (unsigned char *)"FPU not available" },
    { (unsigned int)_k_int_08,
      IDT_EXCEPTION_BASE + K_EXCEPTION_DOUBLE_FAULT,
      (unsigned char *)"double fault" },
    { (unsigned int)_k_int_09,
      IDT_EXCEPTION_BASE + K_EXCEPTION_COPROCESSOR_SEGMENT_OVERRUN,
      (unsigned char *)"coprocesseur segment overrun" },
    { (unsigned int)_k_int_10,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INVALID_TSS,
      (unsigned char *)"invalid TSS" },
    { (unsigned int)_k_int_11,
      IDT_EXCEPTION_BASE + K_EXCEPTION_SEGMENT_NOT_PRESENT,
      (unsigned char *)"segment not present" },
    { (unsigned int)_k_int_12,
      IDT_EXCEPTION_BASE + K_EXCEPTION_STACK_SEGMENT_FAULT,
      (unsigned char *)"stack exception" },
    { (unsigned int)_k_int_13,
      IDT_EXCEPTION_BASE + K_EXCEPTION_GENERAL_PROTECTION,
      (unsigned char *)"general protection" },
    { (unsigned int)_k_int_14,
      IDT_EXCEPTION_BASE + K_EXCEPTION_PAGE_FAULT,
      (unsigned char *)"page fault" },
    { (unsigned int)_k_int_15,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_1,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_16,
      IDT_EXCEPTION_BASE + K_EXCEPTION_FLOATING_POINT_ERROR,
      (unsigned char *)"floating-point error" },
    { (unsigned int)_k_int_17,
      IDT_EXCEPTION_BASE + K_EXCEPTION_ALIGNEMENT_CHECK,
      (unsigned char *)"alignment check" },
    { (unsigned int)_k_int_18,
      IDT_EXCEPTION_BASE + K_EXCEPTION_MACHINE_CHECK,
      (unsigned char *)"machine check" },
    { (unsigned int)_k_int_19,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_2,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_20,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_3,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_21,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_4,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_22,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_5,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_23,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_6,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_24,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_7,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_25,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_8,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_26,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_9,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_27,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_10,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_28,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_11,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_29,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_12,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_30,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_13,
      (unsigned char *)"reserved" },
    { (unsigned int)_k_int_31,
      IDT_EXCEPTION_BASE + K_EXCEPTION_INTEL_RESERVED_14,
      (unsigned char *)"reserved" },
    { 0, 0, 0 }
  };

/*
 * static functions
 */


/*
 * Exception Handler
 */
void		k_init_exception()
{
  int		i;
  int		limit_pos =
    strlen(" Exception handler callers setted in IDT ");
  int		title_end = 0;

  title_end = k_print_initializing("exceptions");
  for (i = 0; exception_handlers[i]._callback; i++)
    k_idt_new_interrupt(exception_handlers[i]._int_num,
			exception_handlers[i]._callback,
			BUILD_SEGMENT_REG_VALUE(SEG_DPL0, SEG_IN_GDT,
						GDT_INDEX_KERNEL_CODE),
			IDTE_TYPE_INTERRUPT_GATE, IDTE_DPL0);
  k_print_initialization_result(1);
  k_print_up_border_info(limit_pos, title_end);
  k_print_info(" Exception handler callers setted in IDT ", limit_pos, "");
  k_print_info(" All exceptions panic K ", limit_pos, "");
  k_print_down_border_info(limit_pos);
}

void		k_exception_handler(_t_registers	regs,
				    int			num,
				    int			tmp,
				    int			eip)
{
  _t_gdtr	gdtr;
  _t_idtr	idtr;
  char		attr = k_get_attr();

  asm("sgdt %0" : "=m" (gdtr));
  asm("sidt %0" : "=m" (idtr));

  k_set_attr(MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_RED));
  k_console_printf("\nFatal: Exception #%d (%s)\n", num,
		   exception_handlers[num]._descr);

  k_console_printf("CS:  %#0.4hx     ", regs._cs);
  k_console_printf("DS:  %#0.4hx     ", regs._ds);
  k_console_printf("ES:  %#0.4hx     ", regs._es);
  k_console_printf("FS:  %#0.4hx     ", regs._fs);
  k_console_printf("GS:  %#0.4hx\n", regs._gs);

  k_console_printf("SS:  %#0.4hx     ", regs._ss);

  k_console_printf("ESP: %#0.8x ", regs._esp);
  k_console_printf("EBP: %#0.8x ", regs._ebp);
  k_console_printf("ESI: %#0.8x ", regs._esi);
  k_console_printf("EDI: %#0.8x\n", regs._edi);

  k_console_printf("EAX: %#0.8x ", regs._eax);
  k_console_printf("EBX: %#0.8x ", regs._ebx);
  k_console_printf("ECX: %#0.8x ", regs._ecx);
  k_console_printf("EDX: %#0.8x ", regs._edx);
  k_console_printf("EIP: %#0.8x\n");

  k_console_printf("CR0: %#0.8x ", regs._cr0);
  k_console_printf("CR2: %#0.8x ", regs._cr2);
  k_console_printf("CR3: %#0.8x ", regs._cr3);
  k_console_printf("CR4: %#0.8x ", regs._cr4);
  k_console_printf("DR0: %#0.8x\n", regs._dr0);

  k_console_printf("DR1: %#0.8x ", regs._dr1);
  k_console_printf("DR2: %#0.8x ", regs._dr2);
  k_console_printf("DR3: %#0.8x ", regs._dr3);
  k_console_printf("DR6: %#0.8x ", regs._dr6);
  k_console_printf("DR7: %#0.8x\n", regs._dr7);

  k_console_printf("GDT @%#0.8x ", gdtr._base_addr);
  k_console_printf("LEN: %#0.4x     ", gdtr._limit);

  k_console_printf("IDT @%#0.8x ", idtr._base_addr);
  k_console_printf("LEN: %#0.4x\n", idtr._limit);

  k_console_printf("EFLAGS: ");
  k_console_printf("CF=%d ", (regs._flags & 1));
  k_console_printf("PF=%d ", ((regs._flags >> 2) & 1));
  k_console_printf("AF=%d ", ((regs._flags >> 4) & 1));
  k_console_printf("ZF=%d ", ((regs._flags >> 6) & 1));
  k_console_printf("SF=%d ", ((regs._flags >> 7) & 1));
  k_console_printf("TF=%d ", ((regs._flags >> 8) & 1));
  k_console_printf("IF=%d ", ((regs._flags >> 9) & 1));
  k_console_printf("DF=%d ", ((regs._flags >> 10) & 1));
  k_console_printf("OF=%d ", ((regs._flags >> 11) & 1));
  k_console_printf("IOPL=%d ", ((regs._flags >> 12) & 3));
  k_console_printf("NT=%d ", ((regs._flags >> 14) & 1));
  k_console_printf("RF=%d ", ((regs._flags >> 16) & 1));
  k_console_printf("VM=%d\n", ((regs._flags >> 17) & 1));

  k_console_printf("        AC=%d ", ((regs._flags >> 18) & 1));
  k_console_printf("VIF=%d ", ((regs._flags >> 19) & 1));
  k_console_printf("VIP=%d ", ((regs._flags >> 20) & 1));
  k_console_printf("ID=%d ", ((regs._flags >> 21) & 1));
  k_console_printf("(%#0.8x)\n", regs._flags);

  k_dump_stack_trace();

  k_console_printf("KERNEL PANIC");

  k_set_attr(attr);
  k_panic("\n");
}

