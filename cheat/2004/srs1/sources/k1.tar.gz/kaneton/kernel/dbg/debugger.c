#include <debugger.h>
#include <console.h>
#include <multiboot.h>
#include <asm.h>
#include <printf.h>
#include <assert.h>
#include <strings.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */

/*
 * Inits Debugger
 *
 * Initializes Elf32 informations
 */
void		k_init_debugger(_t_multiboot_info	*mbi)
{
  //  char			buf[CONSOLE_X + 1];
  int			limit_pos = 0;
//    strlen(" Dump stack trace ");
  int			title_end = 0;

  k_init_elf32(mbi);
  title_end = k_print_initializing("debugger");
  k_print_initialization_result(1);
  k_print_up_border_info(limit_pos, title_end);

  /*
  k_snprintf(buf, (size_t)CONSOLE_X, "%s",
	     DUMP_STACK_TRACE ? "Yes" : "No");
  k_print_info(" Dump stack trace ", limit_pos, buf);
  */
  k_print_down_border_info(limit_pos);
  /*
  if (DUMP_STACK_TRACE)
    k_dump_stack_trace();
  */
}

/*
 * Dumps Stack Trace
 */
void		k_dump_stack_trace()
{
  unsigned int	ebp, eip, i = 0;
  unsigned int	cs;
  unsigned char	*s = 0;
  _t_elf32_sym	*sym;

  GET_EBP_AND_CS(ebp, cs);
  k_print_string((unsigned char *)"Stack trace:\n");
  do
    {
      eip = *(unsigned int *)(ebp + 4);
      ebp = *(unsigned int *)ebp;
      if (k_is_in_code_section(eip))
	{
	  sym = k_find_symbol_at(eip);
	  if (sym)
	    {
	      s = k_resolv_symbol_name(sym);
	      k_console_printf("#%#04x: @%#04x:%#08x => %s\n", i, cs,
			       sym->_value, s);
	    }
	  else
	    k_console_printf("#%#04x: @%#04x:%#08x => %s\n", i, cs,
			     eip, "Unknown symbol");
	}
      i++;
    }
  while (k_is_in_code_section(eip));
}

/*
 * Dumps a piece of memory in hexadecimal
 */
void		k_hexdump(const void	*mem,
			  size_t	len)
{
  size_t		i;
  int			j, title_len;
  int			c;
  const _t_alignment	align = left;
  const unsigned char	addr_col =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	col =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	col_ascii =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  char			s[17];
  char			buf[17][9];
  _t_bool		separators[CONSOLE_X - 5];
  _t_bool		separators2[CONSOLE_X - 5];

  if (len == 0)
    return ;
  for (i = 0; i < CONSOLE_X - 5; i++)
    separators[i] = separators2[i] = false;

  separators[8] = separators2[8] = true;
  for (i = 11, j = 1; (j <= 16) && (i < CONSOLE_X - 5); i+= 3, j++)
    {
      separators[i] = true;
      if ((j == 8)  || (j == 16))
	separators[++i] = true;
    }

  title_len = k_print_title_window("Hexdump");
  k_print_up_border_window(title_len, separators);

  for (i = 0; i < len; )
    {
      k_snprintf(buf[0], 8, "%08x", (((unsigned int)mem) + i));
      s[0] = s[16] = '\0';
      for (j = 1; j <= 16; j++, i++)
	{
	  if (i < len)
	    {
	      c = *(((unsigned char *)mem) + i);
	      k_snprintf(buf[j], 2, "%02x", c);
	      if ((c == 0) || (c == 8) || (c == 9) || (c == 10) || (c == 13) ||
		  (c == 255))
		c = '.';
	      k_snprintf(s, 16, "%s%c", s, c);
	    }
	  else
	    k_snprintf(buf[j], 1, "");
	}
      k_print_datas_in_window(separators,
			      buf[0], addr_col, align,
			      buf[1], col, align,
			      buf[2], col, align,
			      buf[3], col, align,
			      buf[4], col, align,
			      buf[5], col, align,
			      buf[6], col, align,
			      buf[7], col, align,
			      buf[8], col, align,
			      "", col, align,
			      buf[9], col, align,
			      buf[10], col, align,
			      buf[11], col, align,
			      buf[12], col, align,
			      buf[13], col, align,
			      buf[14], col, align,
			      buf[15], col, align,
			      buf[16], col, align,
			      "", col, align,
			      s, col_ascii, align);
      if (i >= len - 1)
	k_print_separator(separators, separators2);
    }
  k_snprintf(buf[0], 8, "%08x", (((unsigned int)mem) + len));
  k_print_datas_in_window(separators2,
			  buf[0], addr_col, align,
			  "", col, align);
  k_print_down_border_window(separators2);
}
