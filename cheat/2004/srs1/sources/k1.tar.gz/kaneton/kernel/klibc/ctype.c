#include <ctype.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */

/*
 * Check if the int value c is lower
 */
_t_bool		islower(int	c)
{
  if ((((unsigned char)c) >= 'a') && (((unsigned char)c) <= 'z'))
    return true;
  return false;
}

/*
 * Check if the int value c is upper
 */
_t_bool		isupper(int	c)
{
  if ((((unsigned char)c) >= 'A') && (((unsigned char)c) <= 'Z'))
    return true;
  return false;
}

/*
 * Check if the int value c is alpha
 */
_t_bool		isalpha(int	c)
{
  if (isupper(c) || islower(c))
    return true;
  return false;
}

/*
 * Check if the int value c is a digit
 */
_t_bool		isdigit(int	c)
{
  if (((unsigned char)c >= '0') && ((unsigned char)c <= '9'))
    return true;
  return false;
}

/*
 * Check if the int value c is an hexadecimal digit
 */
_t_bool		isxdigit(int	c)
{
  if (isdigit(c) ||
      (((unsigned char)c >= 'a') && ((unsigned char)c <= 'z')) ||
      (((unsigned char)c >= 'A') && ((unsigned char)c <= 'Z')))
    return true;
  return false;
}

/*
 * Check if the int value c is a blank (space or tabulation)
 */
_t_bool		isblank(int	c)
{
  if (((unsigned char)c == ' ') || ((unsigned char)c == '\t'))
    return true;
  return false;
}
