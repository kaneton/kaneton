#include <strings.h>
#include <types.h>
#include <limits.h>
#include <ctype.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */


/*
 * Get length of string
 */
size_t		strlen(const char	*str)
{
  size_t	i;

  for (i = 0; str[i]; i++)
    ;
  return (i);
}

/*
 * Compare two strings
 */
int		strcmp(const char	*str_1,
		       const char	*str_2)
{
  size_t	i;

  for (i = 0; str_1[i] && str_2[i]; i++)
    if (str_1[i] != str_2[i])
      return (str_1[i] - str_2[i]);
  return str_1[i] == str_2[i] ? 0 : str_1[i] ? 1 : -1;
}

/*
 * Copy n chars of string src in string dst
 */
char		*strncpy(char		*dst,
			 const char	*src,
			 size_t		len)
{
  size_t	i;

  for (i = 0; (i < len) && src[i]; i++)
    dst[i] = src[i];
  dst[i] = 0;
  return (dst);
}

/*
 * Compare two strings with 'len' chars
 */
int		strncmp(const char	*str_1,
			const char	*str_2,
			size_t		len)
{
  size_t	i;

  for (i = 0; (i < len) && str_1[i] && str_2[i]; i++)
    if (str_1[i] != str_2[i])
      return (str_1[i] - str_2[i]);
  return i == len || str_1[i] == str_2[i] ? 0 : str_1[i] ? 1 : -1;
}

/*
 * Copy 'size' chars from 'src' to 'dst'
 */
void		memcpy(void		*dst,
		       const void	*src,
		       size_t		size)
{
  size_t	i;

  for (i = 0; i < size; i++)
    ((char *)dst)[i] = ((char *)src)[i];
}

/*
 * Set 'size' chars at 'dst' to 'val'
 */
void		memset(void	*dst,
		       int	val,
		       size_t	size)
{
  size_t	i;

  for (i = 0; i < size; i++)
    ((char *)dst)[i] = val;
}

/*
 * Convert 'n' chars of string to int
 */
int		antoi(const char	*str,
		      size_t		size)
{
  size_t	i;
  _t_bool	neg;
  int		value;

  i = 0;
  neg = false;
  value = 0;

  if (!strncmp(str, SINT_MIN_STR, strlen(SINT_MIN_STR)))
    return (SINT_MIN);
  if (!str)
    return 0;
  if (str[i] == '-')
    neg = true;
  for (i = neg; (i < size) && isdigit(str[i]); i++)
    {
      value *= 10;
      value += str[i] - '0';
    }
  return (neg ? -value : value);
}

/*
 * Convert 'n' chars of string to unsigned int
 */
unsigned int	antox(const char	*str,
		      size_t		size)
{
  unsigned int	value;
  size_t	i, j;
  unsigned char	c;

  if (!str)
    return 0;
  value = 0;
  if ((str[0] == '0') &&
      ((str[1] == 'x') || (str[1] == 'X')))
    j = 2;
  else
    j = 0;
  for (i = j; i < size && isxdigit(str[i]); i++)
    {
      value = value << 4;
      if ((str[i] >= 'A') && (str[i] <= 'F'))
	c = str[i] - 'A' + 10;
      else if ((str[i] >= 'a') && (str[i] <= 'f'))
	c = str[i] - 'a' + 10;
      else if ((str[i] >= '0') && (str[i] <= '9'))
	c = str[i] - '0';
      value += c;
    }
  return value;
}

/*
 * Convert 'n' chars of string to size_t
 */
size_t		antosize(const char	*str,
			 size_t		size)
{
  size_t	value;
  size_t	i;

  if (!str)
    return 0;
  value = 0;
  for (i = 0; i < size && isdigit(str[i]); i++)
    {
      value *= 10;
      value += str[i] - '0';
    }
  return value;
}
