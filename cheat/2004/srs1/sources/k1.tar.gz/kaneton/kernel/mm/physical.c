#include <multiboot.h>
#include <mm.h>
#include <types.h>
#include <console.h>
#include <strings.h>
#include <pages.h>
#include <assert.h>
#include <errno.h>
#include <cycle_dlist.h>
#include <printf.h>
#include <elf32.h>

/*
 * global variables
 */
_t_phys_addr	kernel_core_base;

_t_phys_addr	bios_and_video_base;
_t_phys_addr	bios_and_video_top;

_t_phys_addr	kernel_base;
_t_phys_addr	kernel_top;

_t_phys_addr	page_descriptors_base;
_t_phys_addr	page_descriptors_top;

_t_phys_addr	history_base;
_t_phys_addr	history_top;

_t_phys_addr	kernel_core_top;

_t_phys_addr	phys_mem_base;
_t_phys_addr	phys_mem_top;



/*
 * extern variables
 */
extern unsigned int	history_lines;
extern unsigned short	history[];
/* Symbols defined by 'ld' with 'text' file to retrieve addresses.*/
extern char _kernel_base, _kernel_top;

/*
 * static variables
 */
static size_t		ram_size;
static unsigned int	mem_top;
static unsigned int	nb_of_pages;

static unsigned int	used_pages;
static unsigned int	free_pages;

static _t_cycle_dlist	*used_pages_list;
static _t_cycle_dlist	*free_pages_list;

static _t_page_descriptor	*page_descriptors;

/*
 * static functions
 */

/*
 * Initialize static physical addresses.
 * First page is not used to return error code.
 * Every page descriptors are initialized as free pages.
 * Pages allready used by kernel and others, are added after.
 * Each used history page is allready marked by console...
 */
static void	init_statics_phys_addr(_t_multiboot_info	*mbi)
{
  unsigned int	page;
  _t_phys_addr	page_addr;

  k_cycle_dlist_init(&used_pages_list);
  k_cycle_dlist_init(&free_pages_list);
  used_pages = 0;
  free_pages = 0;

  page_descriptors = (_t_page_descriptor *)page_descriptors_base;
  for (page = 0, page_addr = 0;
       ((page < nb_of_pages) && (page_addr + K_PAGE_SIZE <= phys_mem_top));
       page++, page_addr += K_PAGE_SIZE)
    {
      page_descriptors[page]._infos._base = page_addr;
      page_descriptors[page]._infos._refs = 0;
      page_descriptors[page]._infos._type = standard_page;
      page_descriptors[page]._node._elem =
	(void *)&(page_descriptors[page]._infos);
      k_cycle_dlist_add_tail(&free_pages_list,
			     &(page_descriptors[page]._node));
      free_pages++;
    }
  K_ASSERT_FATAL(page == nb_of_pages);

  k_mark_existing_pages(0x0,
			K_PAGE_ALIGN_SUP(0x0),
			reserved_page);
  k_mark_existing_pages(bios_and_video_base,
			bios_and_video_top,
			bios_video_page);
  k_mark_existing_pages(kernel_base,
			kernel_top,
			kernel_page);
  k_mark_existing_pages(page_descriptors_base,
			page_descriptors_top,
			page_descriptors_page);
  k_set_physical_history();
  k_mark_existing_pages(page_descriptors_base,
			page_descriptors_top,
			page_descriptors_page);
}

/*
 * To obtain a page descriptor for page containing 'addr'.
 */
_t_page_descriptor	*k_get_page_descriptor_at(_t_phys_addr	addr)
{
  _t_phys_addr			base_page_addr;
  unsigned int			page_index;

  base_page_addr = K_PAGE_ALIGN_INF(addr);
  page_index = base_page_addr >> K_PAGE_SHIFT;
  if (page_index > (nb_of_pages - 1))
    return NULL;
  return (&(page_descriptors[page_index]));
}

/*
 * Reference used pages
 */
void		k_mark_existing_pages(_t_phys_addr	base,
				      _t_phys_addr	top,
				      _t_page_type	type)
{
  unsigned int	page;

  for (page = (base >> K_PAGE_SHIFT);
       page < (top >> K_PAGE_SHIFT); page++)
    {
      page_descriptors[page]._infos._refs++;
      page_descriptors[page]._infos._type = type;
      k_cycle_dlist_del(&free_pages_list,
			&(page_descriptors[page]._node));
      free_pages--;
      k_cycle_dlist_add_tail(&used_pages_list,
			     &(page_descriptors[page]._node));
      used_pages++;
    }
}

/*
 * Initialize Physical Memory
 */
void		k_init_physical_memory(_t_multiboot_info	*mbi)
{
  char		buf[CONSOLE_X + 1];
  int		limit_pos = strlen("     * Page descriptors ");
  int		title_end = 0;

  title_end = k_print_initializing("physical memory");

  init_statics_phys_addr(mbi);

  k_print_initialization_result(1);

  k_print_up_border_info(limit_pos, title_end);

  k_snprintf(buf, (size_t)CONSOLE_X, "%lu Bytes (%u MBytes)",
	     ram_size, ram_size >> 20);
  k_print_info(" RAM size ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#lx", mem_top - 1);
  k_print_info(" Upper @ ", limit_pos, buf);

  k_print_info("", limit_pos, "");

  k_snprintf(buf, (size_t)CONSOLE_X, "%d Bytes (%d KBytes)", K_PAGE_SIZE,
	     K_PAGE_SIZE >> 10);
  k_print_info(" Page size ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d", nb_of_pages);
  k_print_info(" Number of pages ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d", used_pages);
  k_print_info("   Used pages ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d", free_pages);
  k_print_info("   Free pages ", limit_pos, buf);

  k_print_info(" Memory map : ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x                 (page 0)",
	     0, phys_mem_base - 1);
  k_print_info("   Reserved ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x (pages : %0.5d => %0.5d)",
	     phys_mem_base, phys_mem_top - 1,
	     phys_mem_base >> K_PAGE_SHIFT,
	     (phys_mem_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   Physical pages ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x (pages : %0.5d => %0.5d)",
	     bios_and_video_base, bios_and_video_top - 1,
	     bios_and_video_base >> K_PAGE_SHIFT,
	     (bios_and_video_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   - Bios and video ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x (pages : %0.5d => %0.5d)",
	     kernel_core_base, kernel_core_top - 1,
	     kernel_core_base >> K_PAGE_SHIFT,
	     (kernel_core_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   - Kernel core : ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x (pages : %0.5d => %0.5d)",
	     kernel_base, kernel_top - 1,
	     kernel_base >> K_PAGE_SHIFT,
	     (kernel_top >> K_PAGE_SHIFT) - 1);
  k_print_info("     * Kernel ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x (pages : %0.5d => %0.5d)",
	     page_descriptors_base, page_descriptors_top - 1,
	     page_descriptors_base >> K_PAGE_SHIFT,
	     (page_descriptors_top >> K_PAGE_SHIFT) - 1);
  k_print_info("     * Page descriptors ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x (pages : %0.5d => %0.5d)",
	     history_base, history_top - 1,
	     history_base >> K_PAGE_SHIFT,
	     (history_top >> K_PAGE_SHIFT) - 1);
  k_print_info("     * Console history ", limit_pos, buf);

  k_print_down_border_info(limit_pos);
}

/*
 * Physical memory page allocation at 'addr'
 *
 * Add a reference to page of physical memory containing 'addr'.
 * If this page was allready used it returns 1 and 0 if it wasn't used.
 * This function return a negative value if an error occured.
 */
int			k_page_alloc_at(_t_phys_addr	addr)
{
  _t_page_descriptor	*page_descriptor;

  if ((page_descriptor = k_get_page_descriptor_at(addr)) == NULL)
    return -K_EINVAL;
  if (page_descriptor->_infos._type != standard_page)
    return -K_EINVAL;

  page_descriptor->_infos._refs++;

  if (page_descriptor->_infos._refs == 1)
    {
      k_cycle_dlist_del(&free_pages_list, &(page_descriptor->_node));
      free_pages--;
      k_cycle_dlist_add_tail(&used_pages_list,
			     &(page_descriptor->_node));
      used_pages++;
      return (int)false;
    }
  return (int)true;
}

/*
 * Allocate a page of physical memory and return base address of the page.
 */
_t_phys_addr		k_page_alloc()
{
  _t_cycle_dlist	*free_page;

  if (free_pages == 0)
    return (_t_phys_addr)NULL;
  free_page = k_cycle_dlist_pop_head(&free_pages_list);
  free_pages--;
  used_pages++;
  k_cycle_dlist_add_tail(&used_pages_list, free_page);
  ((_t_page_infos *)(free_page->_elem))->_refs++;
  return (((_t_page_infos *)(free_page->_elem))->_base);
}

/*
 * Free a page of physical memory
 *
 * return 1 if the page is free (unreferenced) and 0 if other virtual pages
 * reference it.
 */
int			k_page_free(_t_phys_addr	addr)
{
  _t_page_descriptor	*page_descriptor;

  if ((page_descriptor = k_get_page_descriptor_at(addr)) == NULL)
    return -K_EINVAL;
  if (page_descriptor->_infos._refs == 0)
    return -K_EINVAL;
  if (page_descriptor->_infos._refs == 1)
    {
      k_cycle_dlist_del(&used_pages_list, &(page_descriptor->_node));
      k_cycle_dlist_add_tail(&free_pages_list, &(page_descriptor->_node));
      free_pages++;
      used_pages--;
    }
  page_descriptor->_infos._refs--;
  return ((page_descriptor->_infos._refs == 0) ? 1 : 0);
}

/*
 * Simple test when allocation return a NULL pointer.
 */
_t_bool			k_is_phys_memory_full()
{
  if (free_pages == 0)
    return true;
  return false;
}

/*
 * Display free pages of physical memory.
 */
void			k_display_free_pages()
{
  k_console_printf("Free pages : %d/%d\n", free_pages,
		   free_pages + used_pages);
}

/*
void			k_dump_page(_t_cycle_dlist	*node)
{
  _t_page_infos		*infos;

  k_console_printf("\n");
  k_console_printf("node @ : %#0.8x\n", node);
  k_console_printf("elem @ : %#0.8x\n", node->_elem);
  infos = (_t_page_infos *)(node->_elem);
  k_console_printf("Prev @ : %#0.8x\n", node->_prev);
  k_console_printf("Next @ : %#0.8x\n", node->_next);
  k_console_printf("Refs   : %d\n", infos->_refs);
  k_console_printf("Base @ : %#0.8x\n", infos->_base);
  k_console_printf("Type   : %s\n",
		   (infos->_type == standard_page) ?
		   "standard" :
		   (infos->_type == reserved_page) ?
		   "reserved" :
		   (infos->_type == kernel_page) ?
		   "kernel" :
		   (infos->_type == page_descriptors_page) ?
		   "page descriptors" :
		   (infos->_type == bios_video_page) ?
		   "bios video" :
		   "unknown");
}

void			k_dump_free_pages()
{
  _t_cycle_dlist	*free_page;
  int			i;

  for (free_page = free_pages_list, i = 0; i < free_pages; i++)
    {
      k_dump_page(free_page);
      free_page = free_page->_next;
    }
}

void			k_dump_used_pages()
{
  _t_cycle_dlist	*used_page;
  int			i;

  for (used_page = used_pages_list, i = 0; i < used_pages; i++)
    {
      k_dump_page(used_page);
      used_page = used_page->_next;
    }
}
*/

/*
 * Initialize variables with usefull physical addresses.
 */
void			k_init_first_statics_phys_addr(_t_multiboot_info
						       *mbi)
{
  _t_elf32_shdr		*strtab_shdr;

  ram_size = (mbi->_mem_upper << 10) + (1 << 20);
  mem_top = ram_size;

  phys_mem_base = (_t_phys_addr)K_PAGE_ALIGN_SUP(0);
  phys_mem_top = K_PAGE_ALIGN_INF(mem_top);
  nb_of_pages =(phys_mem_top >> K_PAGE_SHIFT);

  bios_and_video_base = (_t_phys_addr)K_PAGE_ALIGN_INF(BIOS_VIDEO_BASE);
  bios_and_video_top = (_t_phys_addr)K_PAGE_ALIGN_SUP(BIOS_VIDEO_TOP);

  kernel_base = kernel_core_base =
    (_t_phys_addr)K_PAGE_ALIGN_INF((_t_phys_addr)&_kernel_base);
  strtab_shdr = k_get_elf32_shdr_with_s_name(".strtab");
  kernel_top = (_t_phys_addr)(K_PAGE_ALIGN_SUP((strtab_shdr->_addr +
						strtab_shdr->_size)));
  page_descriptors_base = kernel_top;
  page_descriptors_top =
    (_t_phys_addr)K_PAGE_ALIGN_SUP((page_descriptors_base +
				    (nb_of_pages *
				     sizeof (_t_page_descriptor))));

  history_base = ((_t_phys_addr)(K_PAGE_ALIGN_INF((page_descriptors_top +
						   K_PAGE_SIZE))));
  history_top = (_t_phys_addr)history_base;
  kernel_core_top = history_top;
}
