#include <cycle_dlist.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */

/*
 * Warning :
 * This functions doesn't check validity of list and if node to del is in the
 * list.
 */

void		k_cycle_dlist_init(_t_cycle_dlist **list)
{
  if (list == NULL)
    return ;
  *list = NULL;
}

/*
 * Check if the list is empty.
 */
_t_bool		k_cycle_dlist_is_empty(_t_cycle_dlist	*list)
{
  if (list == NULL)
    return true;
  else
    return false;
}

/*
 * Return number of nodes in the list.
 */
size_t		k_cycle_dlist_get_size(_t_cycle_dlist	*list)
{
  size_t		count;
  _t_cycle_dlist	*iterator;

  if (list == NULL)
    return 0;
  if (list->_next == list)
    return 1;
  for (count = 1, iterator = list->_next;
       iterator != list;
       count++, iterator = iterator->_next)
    ;
  return count;
}

/*
 * Return first node (after the end).
 */
_t_cycle_dlist	*k_cycle_dlist_get_head(_t_cycle_dlist	*list)
{
  return list;
}

/*
 * Return last node (before the beginning).
 */
_t_cycle_dlist	*k_cycle_dlist_get_tail(_t_cycle_dlist	*list)
{
  if (list == NULL)
    return NULL;
  return list->_prev;
}

/*
 * Return the node containing the element elem.
 */
_t_cycle_dlist	*k_cycle_dlist_get_node(_t_cycle_dlist	*list,
					void		*elem)
{
  _t_cycle_dlist *it;

  if (list == NULL || elem == NULL)
    return NULL;
  if (list->_elem == elem)
    return list;
  for (it = list->_next; (it != list) && (it->_elem != elem); it = it->_next)
    ;
  if (it->_elem == elem)
    return it;
  else
    return NULL;
}

/*
 * Add a node before an other supposed to be in list.
 */
void		k_cycle_dlist_add_before(_t_cycle_dlist	**list,
					 _t_cycle_dlist	*before_this,
					 _t_cycle_dlist	*node)
{
  if ((list == NULL) || (node == NULL))
    return ;
  if (((*list) != NULL) && (before_this != NULL))
    {
      before_this->_prev->_next = node;
      node->_prev = before_this->_prev;
      node->_next = before_this;
      before_this->_prev = node;
      if (before_this == *list)
	      *list = node;
    }
  if ((*list) == NULL)
    {
      node->_next = node;
      node->_prev = node;
      *list = node;
    }
}

/*
 * Add a node after an other supposed to be in list.
 */
void		k_cycle_dlist_add_after(_t_cycle_dlist	**list,
					_t_cycle_dlist	*after_this,
					_t_cycle_dlist	*node)
{
  if ((list == NULL) || (node == NULL))
    return ;
  if (((*list) != NULL) && (after_this != NULL))
    {
      after_this->_next->_prev = node;
      node->_next = after_this->_next;
      node->_prev = after_this;
      after_this->_next = node;
    }
  if ((*list) == NULL)
    {
      node->_next = node;
      node->_prev = node;
      *list = node;
    }
}

/*
 * Add a node at the beginning of the list (after the end).
 */
void		k_cycle_dlist_add_head(_t_cycle_dlist	**list,
				       _t_cycle_dlist	*node)
{
  if (list == NULL)
    return ;
  k_cycle_dlist_add_before(list, *list, node);
}

/*
 * Add a node at the end (and before the begin) of the list.
 */
void		k_cycle_dlist_add_tail(_t_cycle_dlist	**list,
				       _t_cycle_dlist	*node)
{
  if (list == NULL)
    return ;
  k_cycle_dlist_add_after(list,  (*list)->_prev, node);
}

/*
 * Delete a node. It's supposed to be in list and that list is valid.
 */
void		k_cycle_dlist_del(_t_cycle_dlist	**list,
				  _t_cycle_dlist	*node)
{
  if (node == NULL)
    return ;
  if (list == NULL)
    return ;
  if ((*list) == NULL)
    return ;
  if ((*list)->_next == (*list))
    {
		  if (*list != node)
			  return ;
      (*list) = NULL;
    }
  else
    {
      node->_prev->_next = node->_next;
      node->_next->_prev = node->_prev;
    }
  if (node == *list)
    (*list) = node->_next;
}

/*
 * Pop the head of the list (delete and return it).
 */
_t_cycle_dlist	*k_cycle_dlist_pop_head(_t_cycle_dlist	**list)
{
  _t_cycle_dlist	*tmp;

  if (list == NULL)
    return NULL;
  tmp = *list;
  k_cycle_dlist_del(list, *list);
  return tmp;
}

/*
 * Pop the tail of the list (delete and return it).
 */
_t_cycle_dlist	*k_cycle_dlist_pop_tail(_t_cycle_dlist	**list)
{
  if (list == NULL)
    return NULL;
  k_cycle_dlist_del(list, (*list)->_prev);
  return *list;
}
