#include <paging.h>
#include <pages.h>
#include <mm.h>
#include <asm.h>
#include <errno.h>
#include <printf.h>
#include <console.h>
#include <strings.h>

/*
 * global variables
 */


/*
 * extern variables
 */
extern _t_phys_addr	bios_and_video_base;
extern _t_phys_addr	bios_and_video_top;

extern _t_phys_addr	kernel_base;
extern _t_phys_addr	kernel_top;

extern _t_phys_addr	page_descriptors_base;
extern _t_phys_addr	page_descriptors_top;

extern _t_phys_addr	history_base;
extern _t_phys_addr	history_top;

/*
 * static variables
 */
static _t_page_directory_entry		*page_directory;
static _t_phys_addr			p_pd;
static _t_linear_addr			v_pd;
static _t_linear_addr			mirror_vaddr;

/*
 * static functions
 */

static void	paging_init_failed(char	*str,
				   int	title_end)
{
  char					buf[CONSOLE_X + 1];
  int					limit_pos = strlen(" Error ");

  k_print_initialization_result(0);

  k_print_up_border_info(limit_pos, title_end);

  k_snprintf(buf, (size_t)CONSOLE_X, "%s", str);
  k_print_info(" Error ", limit_pos, buf);

  k_print_down_border_info(limit_pos);
}

/* Map a physical page in virtual memory using physical addresses */
/*
 * This is used to map kernel in virtual memory. All kernel pages are declared
 * readable and writable in supervisor mode.
 */
static int	map_phys_page_before_paging(_t_phys_addr	paddr,
					    _t_linear_addr	vaddr)
{
  unsigned int		index_in_page_directory;
  unsigned int		index_in_page_table;
  _t_page_table_entry	*page_table;

  index_in_page_directory = LINEAR_ADDR_TO_PAGE_DIRECTORY_INDEX(vaddr);
  index_in_page_table =	LINEAR_ADDR_TO_PAGE_TABLE_INDEX(vaddr);

  if (page_directory[index_in_page_directory]._present == 1)
    {
      page_table = (_t_page_table_entry *)
	(page_directory[index_in_page_directory]._page_table_phys_addr << 12);
      if (page_table[index_in_page_table]._present == 0)
	k_page_alloc_at((_t_phys_addr)page_table);
    }
  else
    {
      if ((page_table = (_t_page_table_entry *)k_page_alloc()) == NULL)
	return -K_ENOMEM;
      memset((void *)page_table, 0x0, K_PAGE_SIZE);
      page_directory[index_in_page_directory]._present = 1;
      page_directory[index_in_page_directory]._write = 1;
      page_directory[index_in_page_directory]._page_table_phys_addr =
	((_t_phys_addr)page_table) >> 12;
    }

  page_table[index_in_page_table]._present = 1;
  page_table[index_in_page_table]._write = 1;
  page_table[index_in_page_table]._user = 0;
  page_table[index_in_page_table]._physical_addr =
    (K_PAGE_ALIGN_INF(paddr)) >> 12;
  return K_NOERR;
}

/* Map used physical pages in virtual memory from 'base' physical addr to
 * 'top' physical addr. */
static int	map_existing_pages_before_paging(_t_phys_addr	base,
						 _t_phys_addr	top)
{
  _t_phys_addr	page_addr;

  for (page_addr = K_PAGE_ALIGN_INF(base);
       page_addr + K_PAGE_SIZE < K_PAGE_ALIGN_SUP(top);
       page_addr += K_PAGE_SIZE)
    if (map_phys_page_before_paging(page_addr, page_addr) == -K_ENOMEM)
      return -K_ENOMEM;
  return K_NOERR;
}

/*
 * Initialize paging
 *
 * Page directory is mapped at end of virtual memory and page tables are mapped
 * before. This is mapped in place of the last replaced page table addressable
 * space. Page table referencing this part of virtual memory is replaced with
 * the page directory itself.
 *
 * At the end of this function, page directory is changed to point on virtual
 * mapped page directory.
 */
int		k_init_paging()
{
  _t_page_directory_base_register	pdr;
  char					buf[CONSOLE_X + 1];
  int					limit_pos =
    strlen(" Adresses are now in virtual space ");
  int					title_end = 0;
  int					i;

  title_end = k_print_initializing("Paging of memory");

  if ((page_directory = (_t_page_directory_entry *)k_page_alloc())
      == NULL)
    {
      paging_init_failed("Not enough memory available", title_end);
      return -K_ENOMEM;
    }
  p_pd = (_t_phys_addr)page_directory;
  memset((void *)page_directory, 0x0, K_PAGE_SIZE);


  if (map_existing_pages_before_paging(bios_and_video_base,
				       bios_and_video_top) == -K_ENOMEM)
    {
      paging_init_failed("Not enough memory available", title_end);
      return -K_ENOMEM;
    }
  if (map_existing_pages_before_paging(kernel_base,
				       kernel_top) == -K_ENOMEM)
    {
      paging_init_failed("Not enough memory available", title_end);
      return -K_ENOMEM;
    }
  if (map_existing_pages_before_paging(page_descriptors_base,
				       page_descriptors_top) == -K_ENOMEM)
    {
      paging_init_failed("Not enough memory available", title_end);
      return -K_ENOMEM;
    }
  if (map_existing_pages_before_paging(history_base,
				       history_top) == -K_ENOMEM)
    {
      paging_init_failed("Not enough memory available", title_end);
      return -K_ENOMEM;
      }
  page_directory[K_PD_INDEX_IN_PD]._present = 1;
  page_directory[K_PD_INDEX_IN_PD]._write = 1;
  page_directory[K_PD_INDEX_IN_PD]._user  = 0;
  page_directory[K_PD_INDEX_IN_PD]._page_table_phys_addr = (p_pd >> 12);
  memset((void *)&pdr, 0x0, sizeof (_t_page_directory_base_register));
  pdr._page_directory_phys_addr = (p_pd >> 12);
  USE_NEW_PD(pdr, CR0_USED_FLAGS);
  v_pd = (_t_linear_addr)K_PD_VADDR;
  mirror_vaddr = K_MIRROR_VADDR;

  page_directory = (_t_page_directory_entry *)v_pd;
  k_set_history_dynamic();
  k_print_initialization_result(1);

  k_print_up_border_info(limit_pos, title_end);
  k_print_info(" Adresses are now in virtual space ", limit_pos, "");

  k_print_info(" Bios and video memory mapping ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%u => %u",
	     bios_and_video_base >> K_PAGE_SHIFT,
	     (bios_and_video_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   Physical pages ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x",
	     bios_and_video_base,
	     bios_and_video_top - 1);
  k_print_info("   Physical @ ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%u => %u",
	     bios_and_video_base >> K_PAGE_SHIFT,
	     (bios_and_video_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   Virtual pages ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x",
	     bios_and_video_base,
	     bios_and_video_top - 1);
  k_print_info("   Virtual @ ", limit_pos, buf);
  k_print_info("", limit_pos, "");
  k_print_info(" Kernel memory mapping ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%u => %u",
	     kernel_base >> K_PAGE_SHIFT,
	     (kernel_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   Physical pages ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x",
	     kernel_base,
	     kernel_top - 1);
  k_print_info("   Physical @ ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%u => %u",
	     kernel_base >> K_PAGE_SHIFT,
	     (kernel_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   Virtual pages ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x",
	     kernel_base,
	     kernel_top - 1);
  k_print_info("   Virtual @ ", limit_pos, buf);
  k_print_info("", limit_pos, "");
  k_print_info(" Page descriptors mapping ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%u => %u",
	     page_descriptors_base >> K_PAGE_SHIFT,
	     (page_descriptors_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   Physical pages ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x",
	     page_descriptors_base,
	     page_descriptors_top - 1);
  k_print_info("   Physical @ ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%u => %u",
	     page_descriptors_base >> K_PAGE_SHIFT,
	     (page_descriptors_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   Virtual pages ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x",
	     page_descriptors_base,
	     page_descriptors_top - 1);
  k_print_info("   Virtual @ ", limit_pos, buf);
  k_print_info("", limit_pos, "");
  k_print_info(" Actual history mapping ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%u => %u",
	     history_base >> K_PAGE_SHIFT,
	     (history_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   Physical pages ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x",
	     history_base,
	     history_top - 1);
  k_print_info("   Physical @ ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%u => %u",
	     history_base >> K_PAGE_SHIFT,
	     (history_top >> K_PAGE_SHIFT) - 1);
  k_print_info("   Virtual pages ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X,
	     "%#0.8x => %#0.8x",
	     history_base,
	     history_top - 1);
  k_print_info("   Virtual @ ", limit_pos, buf);
  k_print_info("", limit_pos, "");

  k_print_info(" Page tables entries mapping ", limit_pos, "");

  for (i = 0; i < 1024; i++)
    if ((i != K_PD_INDEX_IN_PD) && (page_directory[i]._present == 1))
      {
	k_snprintf(buf, (size_t)CONSOLE_X, "%u",
		   ((page_directory[i]._page_table_phys_addr << 12)
		    >> K_PAGE_SHIFT));
	k_print_info("   Physical page ", limit_pos, buf);
	k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x => %#0.8x",
		   page_directory[i]._page_table_phys_addr << 12,
		   (page_directory[i]._page_table_phys_addr << 12) +
		   K_PAGE_SIZE - 1);
	k_print_info("   Physical @ ", limit_pos, buf);
	k_snprintf(buf, (size_t)CONSOLE_X, "%u",
		   (mirror_vaddr + i * K_PAGE_SIZE) >> K_PAGE_SHIFT);
	k_print_info("   Virtual page ", limit_pos, buf);
	k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x => %#0.8x",
		   (_t_linear_addr)(mirror_vaddr + i * K_PAGE_SIZE),
		   (_t_linear_addr)(mirror_vaddr + (i + 1) * K_PAGE_SIZE));
	k_print_info("   Virtual @ ", limit_pos, buf);
      }

  k_print_info("   Reserved virtual space ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, "%u => %u",
	     (mirror_vaddr >> K_PAGE_SHIFT),
	     ((mirror_vaddr + K_MIRROR_SIZE - 1) >> K_PAGE_SHIFT));
  k_print_info("     Virtual pages ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x => %#0.8x",
	     K_MIRROR_VADDR,
	     K_MIRROR_VADDR + K_MIRROR_SIZE - 1);
  k_print_info("     Virtual @ ", limit_pos, buf);
  k_print_info("", limit_pos, "");
  k_print_info(" Page directory mapping ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, "%u",
	     p_pd >> K_PAGE_SHIFT);
  k_print_info("   Physical page ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x => %#0.8x",
	     p_pd, p_pd + K_PAGE_SIZE - 1);
  k_print_info("   Physical @ ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u",
	     v_pd >> K_PAGE_SHIFT);
  k_print_info("   Virtual page ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%#0.8x => %#0.8x",
	     v_pd, v_pd + K_PAGE_SIZE - 1);
  k_print_info("   Virtual @ ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%u", K_PD_INDEX_IN_PD + 1);
  k_print_info("   In place of table entry  # ", limit_pos, buf);

  k_print_down_border_info(limit_pos);
  return K_NOERR;
}

/*
 * Map a physical page in virtual memory
 *
 * Number of used entries in a page table is stored in physical page
 * 'refs' counter of this one. It's to free physical page if no entries
 * are used.
 *
 * If a physical page was allready mapped at vaddr and was not unmapped before,
 * then it free or remove one reference on the physical page previously mapped.
 */
int			k_map_page(_t_phys_addr		paddr,
				   _t_linear_addr	vaddr,
				   _t_bool		user,
				   int			perms)
{
  unsigned int		index_in_page_directory;
  unsigned int		index_in_page_table;
  _t_page_table_entry	*page_table_entry;
  _t_phys_addr		page_table_phys_addr;

  index_in_page_directory = LINEAR_ADDR_TO_PAGE_DIRECTORY_INDEX(vaddr);
  index_in_page_table = LINEAR_ADDR_TO_PAGE_TABLE_INDEX(vaddr);

  if (index_in_page_directory == K_PD_INDEX_IN_PD)
    return -K_EINVAL;

  page_table_entry = (_t_page_table_entry *)
    (K_MIRROR_VADDR + (K_PAGE_SIZE * index_in_page_directory));

  if (page_directory[index_in_page_directory]._present == 0)
    {
      if ((page_table_phys_addr = (_t_phys_addr)k_page_alloc())
	  == (_t_phys_addr)NULL)
	return -K_ENOMEM;
      page_directory[index_in_page_directory]._present = 1;
      page_directory[index_in_page_directory]._write = 1;
      page_directory[index_in_page_directory]._user = (user ? 1 : 0);
      page_directory[index_in_page_directory]._page_table_phys_addr =
	(page_table_phys_addr >> 12);

      INVALIDATE_TLB(page_table_entry);
      memset((void *)page_table_entry, 0x0, K_PAGE_SIZE);
    }
  else
    {
      if (page_table_entry[index_in_page_table]._present == 0)
	k_page_alloc_at(page_directory[index_in_page_directory].
			_page_table_phys_addr << 12);
      else
	k_page_free(page_table_entry[index_in_page_table]._physical_addr
		    << 12);
    }

  page_table_entry[index_in_page_table]._present = 1;
  page_table_entry[index_in_page_table]._write =
    (perms & K_MAP_PERM_WRITE) ? 1 : 0;
  page_table_entry[index_in_page_table]._user = (user ? 1 : 0);
  page_table_entry[index_in_page_table]._physical_addr = paddr >> 12;
  k_page_alloc_at(K_PAGE_ALIGN_INF(paddr));

  INVALIDATE_TLB(K_PAGE_ALIGN_INF(vaddr));
  return K_NOERR;
}

/*
 * Remove a page mapping from virtual_memory
 */
int			k_unmap_page(_t_linear_addr	vaddr)
{
  unsigned int		index_in_page_directory;
  unsigned int		index_in_page_table;
  _t_page_table_entry	*page_table_entry;
  unsigned int		page_table_entries_used;

  index_in_page_directory = LINEAR_ADDR_TO_PAGE_DIRECTORY_INDEX(vaddr);
  index_in_page_table = LINEAR_ADDR_TO_PAGE_TABLE_INDEX(vaddr);

  if (index_in_page_directory == K_PD_INDEX_IN_PD)
    return -K_EINVAL;

  page_table_entry = (_t_page_table_entry *)
    (K_MIRROR_VADDR + (K_PAGE_SIZE * index_in_page_directory));

  if ((page_directory[index_in_page_directory]._present == 0) ||
      (page_table_entry[index_in_page_table]._present == 0))
    return -K_EINVAL;

  k_page_free(page_table_entry[index_in_page_table]._physical_addr << 12);
  memset(page_table_entry + index_in_page_table, 0x0,
	 sizeof (_t_page_table_entry));
  INVALIDATE_TLB(K_PAGE_ALIGN_INF(vaddr));

  page_table_entries_used =
    k_page_free(page_directory[index_in_page_directory]._page_table_phys_addr
		<< 12);
  if (page_table_entries_used < 0)
    return -K_EINVAL;
  if (page_table_entries_used == 0)
    {
      memset(page_directory + index_in_page_directory, 0x0,
	     sizeof (_t_page_directory_entry));
      INVALIDATE_TLB(page_table_entry);
    }
  return K_NOERR;
}

/*
 * Get a physical address from a linear address
 */
_t_phys_addr		k_get_phys_addr(_t_linear_addr	vaddr)
{
  unsigned int		index_in_page_directory;
  unsigned int		index_in_page_table;
  unsigned int		page_offset;
  _t_page_table_entry	*page_table_entry;

  index_in_page_directory = LINEAR_ADDR_TO_PAGE_DIRECTORY_INDEX(vaddr);
  index_in_page_table = LINEAR_ADDR_TO_PAGE_TABLE_INDEX(vaddr);
  page_offset = LINEAR_ADDR_TO_PAGE_OFFSET(vaddr);

  if ((page_directory[index_in_page_directory]._present == 0) ||
      (page_table_entry[index_in_page_table]._present == 0))
    return ((_t_phys_addr)NULL);

  page_table_entry = (_t_page_table_entry *)
    (K_MIRROR_VADDR + (K_PAGE_SIZE * index_in_page_directory));

  return ((_t_phys_addr)((page_table_entry[index_in_page_table]._physical_addr
			  << 12) + page_offset));
}

/*
 * Get permissions associated to a linear address
 */
int			k_get_perms(_t_linear_addr	vaddr)
{
  unsigned int		index_in_page_directory;
  unsigned int		index_in_page_table;
  _t_page_table_entry	*page_table_entry;
  int			perms;

  index_in_page_directory = LINEAR_ADDR_TO_PAGE_DIRECTORY_INDEX(vaddr);
  index_in_page_table = LINEAR_ADDR_TO_PAGE_TABLE_INDEX(vaddr);
  page_table_entry = (_t_page_table_entry *)
    (K_MIRROR_VADDR + (K_PAGE_SIZE * index_in_page_directory));
  if ((page_directory[index_in_page_directory]._present == 0) ||
      (page_table_entry[index_in_page_table]._present == 0))
    return K_MAP_PERM_NO;
  perms = K_MAP_PERM_READ;

  if (page_directory[index_in_page_directory]._write &&
      page_table_entry[index_in_page_table]._write)
    perms |= K_MAP_PERM_WRITE;

  return perms;
}

/*
 * Check if a linear address is physically mapped
 */
_t_bool			k_is_physical_mapped_addr(_t_linear_addr	vaddr)
{
  if (k_get_phys_addr(vaddr) != (_t_phys_addr)NULL)
    return true;
  return false;
}
