#include <mm.h>
#include <console.h>
#include <paging.h>
#include <assert.h>
#include <errno.h>
#include <strings.h>
/*
 * global variables
 */


/*
 * extern variables
 */
extern _t_phys_addr	history_base;
extern _t_phys_addr	history_top;
extern _t_phys_addr	kernel_core_top;
extern long int		k_history_current_line;
extern long int		k_history_lines;
extern unsigned short	*k_history;

/*
 * static variables
 */


/*
 * static functions
 */


/*
 * Initialize virtual memory tables and enable paging
 */
void		k_init_virtual_memory()
{
  char			buf[CONSOLE_X + 1];
  int			limit_pos = strlen(" Max phys. pages for history ");
  int			title_end = 0;

  k_init_paging();
  title_end = k_print_initializing("Virtual memory");
  k_print_initialization_result(1);

  k_print_up_border_info(limit_pos, title_end);

  k_snprintf(buf, (size_t)CONSOLE_X, "%s",
	     (LIMITED_HISTORY ? "Yes" : "No"));
  k_print_info(" Limited history ", limit_pos, buf);
  if (LIMITED_HISTORY)
    {
      k_snprintf(buf, (size_t)CONSOLE_X, "%d Pages", MAX_HISTORY_PAGES);
      k_print_info(" Max phys. pages for history ", limit_pos, buf);
    }
 
  k_print_down_border_info(limit_pos);
}

void			k_check_if_page_alloc_required_for_history()
{
  _t_phys_addr		new_page;

  if ((_t_linear_addr)(k_history +
		       (k_history_lines + CONSOLE_Y + 1) * CONSOLE_X)
      >= ((_t_linear_addr)(history_top)))
    {
      if (!LIMITED_HISTORY)
	{
	  if ((new_page = k_page_alloc()) == (_t_phys_addr)NULL)
	    k_panic("All memory is now filled. It's a normal panic.");
	  if (k_map_page(new_page, (_t_linear_addr)history_top, false,
			 K_MAP_PERM_READ | K_MAP_PERM_WRITE) != K_NOERR)
	    k_panic("Historic mapping error.");
	  history_top += K_PAGE_SIZE;
	  kernel_core_top = history_top;
	}
      if (LIMITED_HISTORY)
	{
	  k_panic("Not yet implemented.");
	}
    }
}
