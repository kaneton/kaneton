#include <multiboot.h>
#include <console.h>
#include <bochs.h>
#include <debugger.h>
#include <keyboard.h>
#include <gdt.h>
#include <mm.h>
#include <idt.h>
#include <asm.h>
#include <shell.h>
#include <irq.h>
#include <system.h>
#include <printf.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */


/*
 * Kernel Main Function
 */
void	k_main(unsigned int		mbmn,
	       _t_multiboot_info	*mbi)
{
  k_init_first_elf32(mbi);
  k_init_first_statics_phys_addr(mbi);
  k_init_console();
  k_init_bochs();
  k_init_debugger(mbi);
  k_init_keyboard();
  k_init_gdt();
  k_init_physical_memory(mbi);
  k_init_idt();
  k_init_virtual_memory();

  STI();
  k_console_printf("%kWelcome in K.\n",
		   MK_BRIGHT_COLOR(COLOR_CYAN, COLOR_BLUE));
  k_console_printf("%kUse 'Page up' and 'Page down' keys to scroll screen.\n",
		   MK_BRIGHT_COLOR(COLOR_BLACK, COLOR_BLUE));
  k_console_printf("%kType 'help' to get some.\n",
		   MK_BRIGHT_COLOR(COLOR_BLACK, COLOR_BLUE));
  k_console_printf("%kThank you for using K. Enjoy !\n",
		   MK_COLOR(COLOR_WHITE, COLOR_BLUE));
  k_shell();

  k_halt();
}
