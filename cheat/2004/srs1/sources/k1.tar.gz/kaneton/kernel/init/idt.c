#include <idt.h>
#include <idt_entry.h>
#include <gdt.h>
#include <segment.h>
#include <asm.h>
#include <console.h>
#include <strings.h>
#include <printf.h>
#include <i8259.h>
#include <exception.h>
#include <irq.h>

/*
 * global variables
 */
_t_idt_entry			k_idt[IDT_SIZE];

/*
 * extern variables
 */


/*
 * static variables
 */
static _t_idtr			idtr;

/*
 * static functions
 */


/*
 * Add an entry to Interrupt Descriptor Table
 */
void		k_idt_new_interrupt(unsigned short	entry,
				    unsigned int	offset,
				    unsigned short	segment,
				    unsigned short	type,
				    unsigned short	level)
{
  if (!(entry < IDT_SIZE))
    return ;
  if (!(level <= 3))
    return ;

  k_idt[entry]._reserved = 0;
  k_idt[entry]._flags = 0;
  k_idt[entry]._op_size = IDTE_OP_SIZE_32;
  k_idt[entry]._zero = 0;
  k_idt[entry]._segment = segment;
  k_idt[entry]._type = type & 0x7;

  if (offset != 0x0)
    {
      k_idt[entry]._offset_00_15 = offset & 0xffff;
      k_idt[entry]._offset_16_31 = (offset >> 16) & 0xffff;
      k_idt[entry]._dpl = level & 0x3;
      k_idt[entry]._present = IDTE_PRESENT;
    }
  else
    {
      k_idt[entry]._offset_00_15 = 0x0;
      k_idt[entry]._offset_16_31 = 0x0;
      k_idt[entry]._dpl = IDTE_DPL0;
      k_idt[entry]._present = IDTE_NOT_PRESENT;
    }
}

/*
 * Initialize and load Interrupt Descriptor Table
 *
 * Initialize IDT with exception wrappers and IRQs wrappers.
 * Initialize PIC (i8259).
 */
void		k_init_idt()
{
  int		i;
  char		buf[CONSOLE_X + 1];
  int		limit_pos = strlen(" Max number of elements ");
  int		title_end = 0;

  title_end = k_print_initializing("Interrupt Descriptor Table");

  idtr._limit = IDT_SIZE * sizeof (_t_idt_entry) - 1;
  idtr._base_addr = (unsigned int)k_idt;

  for (i = 0; i < IDT_SIZE; i++)
    k_idt_new_interrupt(i, 0x0,
			BUILD_SEGMENT_REG_VALUE(SEG_DPL0, SEG_IN_GDT,
						GDT_INDEX_KERNEL_CODE),
			IDTE_TYPE_INTERRUPT_GATE, IDTE_DPL0);

  k_print_initialization_result(1);

  k_print_up_border_info(limit_pos, title_end);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#x", &idtr);
  k_print_info(" IDT register @ ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d Bytes", idtr._limit);
  k_print_info("   IDT limit ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#x", idtr._base_addr);
  k_print_info("   IDT base @ ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d Bytes", sizeof (_t_idt_entry));
  k_print_info(" IDT element size ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d", IDT_SIZE);
  k_print_info(" Max number of elements ", limit_pos, buf);

  /*
  k_snprintf(buf, (size_t)CONSOLE_X, "%s", DUMP_IDT_ELMTS ? "Yes" : "No");
  k_print_info(" Dump IDT elements ", limit_pos, buf);
  */
  k_print_down_border_info(limit_pos);

  k_init_exception();
  k_init_irq();

  USE_NEW_IDT(idtr);
}
