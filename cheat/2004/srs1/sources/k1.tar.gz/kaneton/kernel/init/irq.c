#include <irq.h>
#include <idt.h>
#include <idt_entry.h>
#include <gdt.h>
#include <console.h>
#include <segment.h>
#include <strings.h>
#include <i8259.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */
/*
 * Standard IRQ descriptions.
 */
static _t_idt_handler	irq_handlers[IDT_IRQ_NUM + 1] =
  {
    { (unsigned int)_k_irq_00, IDT_IRQ_BASE + K_IRQ_TIMER,
      (unsigned char *)"System timer" },
    { (unsigned int)_k_irq_01, IDT_IRQ_BASE + K_IRQ_KEYBOARD,
      (unsigned char *)"Keyboard" },
    { (unsigned int)_k_irq_02, IDT_IRQ_BASE + K_IRQ_SLAVE_PIC,
      (unsigned char *)"Chain to IRQ 8-15 / IRQ 9" },
    { (unsigned int)_k_irq_03, IDT_IRQ_BASE + K_IRQ_COM2,
      (unsigned char *)"COM2 / COM4" },
    { (unsigned int)_k_irq_04, IDT_IRQ_BASE + K_IRQ_COM1,
      (unsigned char *)"COM1 / COM3" },
    { (unsigned int)_k_irq_05, IDT_IRQ_BASE + K_IRQ_LPT2,
      (unsigned char *)"Sound card / LPT2" },
    { (unsigned int)_k_irq_06, IDT_IRQ_BASE + K_IRQ_FLOPPY,
      (unsigned char *)"Floppy controller" },
    { (unsigned int)_k_irq_07, IDT_IRQ_BASE + K_IRQ_LPT1,
      (unsigned char *)"LPT1 / Sound card" },
    { (unsigned int)_k_irq_08, IDT_IRQ_BASE + K_IRQ_CMOS,
      (unsigned char *)"Real time clock (CMOS)" },
    { (unsigned int)_k_irq_09, IDT_IRQ_BASE + K_IRQ_9,
      (unsigned char *)"Not defined / Network card" },
    { (unsigned int)_k_irq_10, IDT_IRQ_BASE + K_IRQ_IDE4,
      (unsigned char *)"4th IDE controller" },
    { (unsigned int)_k_irq_11, IDT_IRQ_BASE + K_IRQ_IDE3,
      (unsigned char *)"3th IDE controller" },
    { (unsigned int)_k_irq_12, IDT_IRQ_BASE + K_IRQ_PS2,
      (unsigned char *)"PS/2 Mouse" },
    { (unsigned int)_k_irq_13, IDT_IRQ_BASE + K_IRQ_COPROCESSOR,
      (unsigned char *)"Maths coprocessor" },
    { (unsigned int)_k_irq_14, IDT_IRQ_BASE + K_IRQ_IDE1,
      (unsigned char *)"Primary IDE controller / SCSI controller" },
    { (unsigned int)_k_irq_15, IDT_IRQ_BASE + K_IRQ_IDE2,
      (unsigned char *)"Secondary IDE controller" },
    { 0, 0, 0 }
  };

/*
 * static functions
 */
/*
 * Initialize IRQ
 */
void		k_init_irq()
{
  int		i;
  int		limit_pos = strlen(" IRQ handler callers setted in IDT ");
  int		title_end = 0;

  title_end = k_print_initializing("IRQs");
  for (i = 0; irq_handlers[i]._callback; i++)
    k_idt_new_interrupt(irq_handlers[i]._int_num,
			irq_handlers[i]._callback,
			BUILD_SEGMENT_REG_VALUE(SEG_DPL0, SEG_IN_GDT,
						GDT_INDEX_KERNEL_CODE),
			IDTE_TYPE_INTERRUPT_GATE, IDTE_DPL0);
  k_print_initialization_result(1);
  k_print_up_border_info(limit_pos, title_end);
  k_print_info(" IRQ handler callers setted in IDT ", limit_pos, "");
  k_print_down_border_info(limit_pos);

  k_init_i8259();
}

/*
 * Enable an IRQ line
 */
/*
void		k_enable_irq(unsigned short	irq)
{
  k_i8259_enable_irq_line(irq);
}
*/

/*
 * Disable an IRQ line
 */
/*
void		k_disable_irq(unsigned short	irq)
{
  k_i8259_disable_irq_line(irq);
}
*/
