#include <system.h>
#include <asm.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */


void			k_reboot()
{
  _k_reboot();
}

void			k_halt()
{
  CLI();
  for (; ; )
    asm("hlt\n");
}
