#include <gdt.h>
#include <segment.h>
#include <console.h>
#include <strings.h>
#include <types.h>
#include <printf.h>
#include <asm.h>

/*
 * global variables
 */
_t_segment_descriptor	k_gdt[GDT_SIZE];

/*
 * extern variables
 */


/*
 * static variables
 */
static _t_gdtr	gdtr;

/*
 * static functions
 */
/* Update CPU segment registers */
static void		gdt_update_cpu_segments(unsigned int	new_code,
						unsigned int	new_data)
{
  GDT_UPDATE_CPU_SEGMENTS(new_code, new_data);
}

/*
 * Add An Entry To Global Descriptor Table
 */
unsigned short		k_gdt_new_segment(unsigned int	base,
					  unsigned int	limit,
					  unsigned char	seg_type,
					  unsigned char des_type,
					  unsigned char dpl,
					  unsigned char	present,
					  unsigned char custom,
					  unsigned char op_size,
					  unsigned char granularity)
{
  int		i;

  i = (gdtr._limit + 1) / sizeof (_t_segment_descriptor);

  if (i == GDT_SIZE)
    return i;

  k_gdt[i]._limit_00_15 = limit & 0xffff;
  k_gdt[i]._base_paged_addr_00_15 = base & 0xffff;
  k_gdt[i]._base_paged_addr_16_23 = (base >> 16) & 0xff;
  k_gdt[i]._segment_type = seg_type & 0xf;
  k_gdt[i]._descriptor_type = des_type & 0x1;
  k_gdt[i]._dpl = dpl & 0x3;
  k_gdt[i]._present = present & 0x1;
  k_gdt[i]._limit_16_19 = (limit >> 16) & 0xf;
  k_gdt[i]._custom = custom & 0x1;
  k_gdt[i]._zero = 0;
  k_gdt[i]._op_size = op_size & 0x1;
  k_gdt[i]._granularity = granularity & 0x1;
  k_gdt[i]._base_paged_addr_24_31 = (base >> 24) & 0xff;

  if (gdtr._limit == 0)
    gdtr._limit += sizeof (_t_segment_descriptor) - 1;
  else
    gdtr._limit += sizeof (_t_segment_descriptor);
  return i;
}

/*
 * Delete An Entry To Global Descriptor Table
 */
void			k_gdt_del_segment(unsigned short	entry)
{
  int			limit;
  int			i;

  limit = (gdtr._limit + 1) / sizeof (_t_segment_descriptor);
  if ((entry >= limit) ||
      ((entry == GDT_INDEX_NULL) ||
       (entry == GDT_INDEX_KERNEL_CODE) ||
       (entry == GDT_INDEX_KERNEL_DATA)))
    return ;
  for (i = entry; i < limit - 2; i++)
    {
      k_gdt[i]._limit_00_15 = k_gdt[i + 1]._limit_00_15;
      k_gdt[i]._base_paged_addr_00_15 = k_gdt[i + 1]._base_paged_addr_00_15;
      k_gdt[i]._base_paged_addr_16_23 = k_gdt[i + 1]._base_paged_addr_16_23;
      k_gdt[i]._segment_type = k_gdt[i + 1]._segment_type;
      k_gdt[i]._descriptor_type = k_gdt[i + 1]._descriptor_type;
      k_gdt[i]._dpl = k_gdt[i + 1]._dpl;
      k_gdt[i]._present = k_gdt[i + 1]._present;
      k_gdt[i]._limit_16_19 = k_gdt[i + 1]._limit_16_19;
      k_gdt[i]._custom = k_gdt[i + 1]._custom;
      k_gdt[i]._zero = k_gdt[i + 1]._zero;
      k_gdt[i]._op_size = k_gdt[i + 1]._op_size;
      k_gdt[i]._granularity = k_gdt[i + 1]._granularity;
      k_gdt[i]._base_paged_addr_24_31 = k_gdt[i + 1]._base_paged_addr_24_31;
    }
  gdtr._limit -= sizeof (_t_segment_descriptor);
  k_gdt[limit - 1]._present = 0;
}

/*
 * Initialize And Load Global Descriptor Table
 */
void			k_init_gdt()
{
  int			limit_pos = strlen(" GDT segment descriptor size ");
  int			title_end = 0;
  char			buf[CONSOLE_X + 1];

  title_end = k_print_initializing("Global Descriptor Table");

  gdtr._base_addr = (unsigned int)k_gdt;
  gdtr._limit = 0;

  k_gdt_new_segment(0x0, 0x0, 0, 0, 0, 0, 0, 0, 0);

  k_gdt_new_segment(SEG_MIN_BASE, SEG_MAX_LIMIT,
		    SEG_TYPE_CODE,
		    SEG_DES_TYPE_CODE_DATA,
		    SEG_DPL0,
		    SEG_PRESENT,
		    SEG_CUSTOM,
		    SEG_OP_SIZE_32,
		    SEG_GRANULARITY_4K);

  k_gdt_new_segment(SEG_MIN_BASE, SEG_MAX_LIMIT,
		    SEG_TYPE_DATA,
		    SEG_DES_TYPE_CODE_DATA,
		    SEG_DPL0,
		    SEG_PRESENT,
		    SEG_CUSTOM,
		    SEG_OP_SIZE_32,
		    SEG_GRANULARITY_4K);

  USE_NEW_GDT(gdtr);

  gdt_update_cpu_segments(BUILD_SEGMENT_REG_VALUE(SEG_DPL0,
						  SEG_IN_GDT,
						  GDT_INDEX_KERNEL_CODE),
			  BUILD_SEGMENT_REG_VALUE(SEG_DPL0,
						  SEG_IN_GDT,
						  GDT_INDEX_KERNEL_DATA));
  k_print_initialization_result(1);

  k_print_up_border_info(limit_pos, title_end);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#x", &gdtr);
  k_print_info(" GDT register (gdtr) @ ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d Bytes", gdtr._limit);
  k_print_info("   GDT limit ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#x", gdtr._base_addr);
  k_print_info("   GDT base @ ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d Bytes",
	     sizeof (_t_segment_descriptor));
  k_print_info(" GDT segment descriptor size ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d", GDT_SIZE);
  k_print_info(" Max number of elements ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d",
	     (gdtr._limit + 1) / sizeof (_t_segment_descriptor));
  k_print_info(" Number of elements used ", limit_pos, buf);

  /*
  k_snprintf(buf, (size_t)CONSOLE_X, "%s", DUMP_GDT_ELMTS ? "Yes" : "No");
  k_print_info(" Dump GDT elements ", limit_pos, buf);
  */
  k_print_down_border_info(limit_pos);
}
