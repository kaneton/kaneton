#include <printf.h>
#include <types.h>
#include <limits.h>
#include <stdarg.h>
#include <writers.h>
#include <strings.h>
#include <ctype.h>
#include <bochs.h>
#include <console.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */
static size_t		max_chars;

static _t_bool		out_error_found = false;
static size_t		wroten = 0;
static size_t		pos = 0;
static const char	*fmt = 0;
static _t_bool		resolving_arg = false;
static _t_va_list	args;
static _t_va_list	args_orig;
static _t_va_list	resolved_arg_list;
static int		current_arg = 1;

static _t_writer	writer;
static _t_str_w_info	str_w_info;

static int		handle_conversion();
static int		handle_end();

static struct
{
  char			_c;
  int			(*_f)();
} chars_tab[] =
  {
    { '%', &handle_conversion },
    { '\0', &handle_end },
    { 0, 0 }
  };

static int		sharp_attribute(_t_arg_infos		*infos);
static int		zero_attribute(_t_arg_infos		*infos);
static int		minus_attribute(_t_arg_infos		*infos);
static int		space_attribute(_t_arg_infos		*infos);
static int		more_attribute(_t_arg_infos		*infos);
static int		apostrophe_attribute(_t_arg_infos	*infos);
static int		I_attribute(_t_arg_infos		*infos);
static struct
{
  char			_c;
  int			(*_f)(_t_arg_infos	*infos);
}			attributes_tab[] =
  {
    { '#', &sharp_attribute },
    { '0', &zero_attribute },
    { '-', &minus_attribute },
    { ' ', &space_attribute },
    { '+', &more_attribute },
    { '\'', &apostrophe_attribute },
    { 'I', &I_attribute },
    { 0, 0 }
  };

static int		hh_len_modifier(_t_arg_infos	*infos);
static int		ll_len_modifier(_t_arg_infos	*infos);
static int		h_len_modifier(_t_arg_infos	*infos);
static int		l_len_modifier(_t_arg_infos	*infos);
static int		L_len_modifier(_t_arg_infos	*infos);
static int		q_len_modifier(_t_arg_infos	*infos);
static int		j_len_modifier(_t_arg_infos	*infos);
static int		z_len_modifier(_t_arg_infos	*infos);
static int		t_len_modifier(_t_arg_infos	*infos);
static struct
{
  char			*_s;
  int			(*_f)(_t_arg_infos	*infos);
}			len_modifiers_tab[] =
  {
    { "hh", &hh_len_modifier },
    { "ll", &ll_len_modifier },
    { "h", &h_len_modifier },
    { "l", &l_len_modifier },
    { "L", &L_len_modifier },
    { "q", &q_len_modifier },
    { "j", &j_len_modifier },
    { "z", &z_len_modifier },
    { "t", &t_len_modifier },
    { 0, 0 }
  };

static int		d_conversion_indicator(_t_arg_infos	*infos);
static int		i_conversion_indicator(_t_arg_infos	*infos);
static int		o_conversion_indicator(_t_arg_infos	*infos);
static int		u_conversion_indicator(_t_arg_infos	*infos);
static int		x_conversion_indicator(_t_arg_infos	*infos);
static int		X_conversion_indicator(_t_arg_infos	*infos);
static int		e_conversion_indicator(_t_arg_infos	*infos);
static int		E_conversion_indicator(_t_arg_infos	*infos);
static int		f_conversion_indicator(_t_arg_infos	*infos);
static int		F_conversion_indicator(_t_arg_infos	*infos);
static int		g_conversion_indicator(_t_arg_infos	*infos);
static int		G_conversion_indicator(_t_arg_infos	*infos);
static int		a_conversion_indicator(_t_arg_infos	*infos);
static int		A_conversion_indicator(_t_arg_infos	*infos);
static int		c_conversion_indicator(_t_arg_infos	*infos);
static int		s_conversion_indicator(_t_arg_infos	*infos);
static int		C_conversion_indicator(_t_arg_infos	*infos);
static int		S_conversion_indicator(_t_arg_infos	*infos);
static int		p_conversion_indicator(_t_arg_infos	*infos);
static int		k_conversion_indicator(_t_arg_infos	*infos);
static int		n_conversion_indicator(_t_arg_infos	*infos);
static int		percent_conversion_indicator(_t_arg_infos	*infos);
static struct
{
  char			_c;
  int			(*_f)(_t_arg_infos	*infos);
}			conversion_indicators_tab[] =
  {
    { 'd', &d_conversion_indicator },
    { 'i', &i_conversion_indicator },
    { 'o', &o_conversion_indicator },
    { 'u', &u_conversion_indicator },
    { 'x', &x_conversion_indicator },
    { 'X', &X_conversion_indicator },
    { 'e', &e_conversion_indicator },
    { 'E', &E_conversion_indicator },
    { 'f', &f_conversion_indicator },
    { 'F', &F_conversion_indicator },
    { 'g', &g_conversion_indicator },
    { 'G', &G_conversion_indicator },
    { 'a', &a_conversion_indicator },
    { 'A', &A_conversion_indicator },
    { 'c', &c_conversion_indicator },
    { 's', &s_conversion_indicator },
    { 'C', &C_conversion_indicator },
    { 'S', &S_conversion_indicator },
    { 'p', &p_conversion_indicator },
    { 'n', &n_conversion_indicator },
    { 'k', &k_conversion_indicator }, // a color setter
    { '%', &percent_conversion_indicator },
    { 0, 0 }
  };

/*
 * static functions
 */
static ssize_t		_printf(const char	*format,
				_t_va_list	va_list);

static int		resolv(int		arg_nb)
{
  int			i;
  size_t		pos_saved;
  int			ret;

  if (arg_nb <= 0)
    return K_PRINTF_ERR;
  current_arg = 1;
  k_va_copy(resolved_arg_list, args_orig);
  pos_saved = pos;
  for (i = 1; i < arg_nb; i++)
    {
      resolving_arg = i;
      ret = _printf(fmt, args_orig);
      if (ret != K_PRINTF_RESOLVED)
	{
	  resolving_arg = 0;
	  pos = pos_saved;
	  return ret;
	}
    }
  resolving_arg = 0;
  pos = pos_saved;
  return K_PRINTF_RESOLVED;
}

static int		check_percent_m_dollar(_t_arg_infos	*infos)
{
  size_t		tmppos;

  tmppos = pos;
  while (isdigit(fmt[tmppos]))
    tmppos++;
  if (fmt[tmppos] == '$')
    {
      if (tmppos == pos)
	return K_PRINTF_ERR;
      if ((infos->_arg_to_use = antoi(fmt + pos, tmppos - pos)) == 0)
	return K_PRINTF_ERR;
      infos->_static_arg = 1;
      pos = tmppos + 1;
      return 1;
    }
  infos->_static_arg = 0;
  return 0;
}

static int		sharp_attribute(_t_arg_infos	*infos)
{
  infos->_attrs._sharp = 1;
  return 0;
}
static int		zero_attribute(_t_arg_infos	*infos)
{
  infos->_attrs._zero = 1;
  return 0;
}
static int		minus_attribute(_t_arg_infos	*infos)
{
  infos->_attrs._minus = 1;
  return 0;
}
static int		space_attribute(_t_arg_infos	*infos)
{
  infos->_attrs._space = 1;
  return 0;
}
static int		more_attribute(_t_arg_infos	*infos)
{
  infos->_attrs._more = 1;
  return 0;
}
static int		apostrophe_attribute(_t_arg_infos	*infos)
{
  infos->_attrs._apostrophe = 1;
  return 0;
}
static int		I_attribute(_t_arg_infos	*infos)
{
  infos->_attrs._I = 1;
  return 0;
}

static int		check_attributes(_t_arg_infos	*infos)
{
  int			i;
  char			found;

  do
    {
      found = 0;
      for (i = 0; !found && attributes_tab[i]._f != 0; i++)
	{
	  if (attributes_tab[i]._c == fmt[pos])
	    {
	      if (!resolving_arg)
		if ((*(attributes_tab[i]._f))(infos) == K_PRINTF_ERR)
		  return K_PRINTF_ERR;
	      found = 1;
	      pos++;
	    }
	}
    }
  while (found);
  return 0;
}

static int		check_min_len(_t_arg_infos*	infos)
{
  size_t		tmppos = pos;

  if (isdigit(fmt[tmppos]))
    {
      while (isdigit(fmt[tmppos]))
	tmppos++;
      infos->_min_len_to_use = antoi(fmt + pos, tmppos - pos);
      pos = tmppos;
      return 0;
    }
  if (fmt[tmppos] == '*')
    {
      tmppos++;
      while (isdigit(fmt[tmppos]))
	tmppos++;
      if (fmt[tmppos] == '$')
	{
	  if (tmppos == pos + 1)
	    return K_PRINTF_ERR;
	  if ((infos->_min_len_to_use =
	       antoi(fmt + pos + 1, tmppos - (pos + 1))) == 0)
	    return K_PRINTF_ERR;
	  if (!resolving_arg)
	    {
	      if (resolv(infos->_min_len_to_use) != K_PRINTF_RESOLVED)
		return K_PRINTF_ERR;
	      infos->_min_len_to_use = k_va_arg(resolved_arg_list, int);
	      if (infos->_min_len_to_use < 0)
		{
		  minus_attribute(infos);
		  infos->_min_len_to_use = -infos->_min_len_to_use;
		}
	    }
	  else
	    if (infos->_min_len_to_use == resolving_arg)
	      {
		k_va_arg(resolved_arg_list, int);
		return K_PRINTF_RESOLVED;
	      }
	  pos = tmppos + 1;
	  return 0;
	}
      if (!resolving_arg)
	{
	  infos->_min_len_to_use = k_va_arg(args, int);
	  if (infos->_min_len_to_use < 0)
	    {
	      minus_attribute(infos);
	      infos->_min_len_to_use = -infos->_min_len_to_use;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      k_va_arg(resolved_arg_list, int);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    current_arg++;
	}
      pos++;
      return 0;
    }
  infos->_min_len_to_use = 0;
  return 0;
}

static int		check_precision(_t_arg_infos*	infos)
{
  size_t		tmppos = pos;

  if (fmt[tmppos] == '.')
    {
      infos->_precision_specified = 1;
      infos->_precision_to_use = 0;

      tmppos++;
      if (isdigit(fmt[tmppos]) || (fmt[tmppos] == '-'))
	{
	  if (fmt[tmppos] == '-')
	    {
	      if (!isdigit(fmt[tmppos + 1]))
		return K_PRINTF_ERR;
	      tmppos++;
	    }
	  while (isdigit(fmt[tmppos]))
	    tmppos++;
	  if ((infos->_precision_to_use = antoi(fmt + pos + 1,
						tmppos - (pos + 1))) < 0)
	    infos->_precision_to_use = 0;
	  pos = tmppos;
	  return 0;
	}
      if (fmt[tmppos] == '*')
	{
	  tmppos++;
	  while (isdigit(fmt[tmppos]))
	    tmppos++;
	  if (fmt[tmppos] == '$')
	    {
	      if (tmppos == pos + 2)
		return K_PRINTF_ERR;
	      if ((infos->_precision_to_use =
		   antoi(fmt + pos + 2, tmppos - (pos + 2))) == 0)
		return K_PRINTF_ERR;
	      if (!resolving_arg)
		{
		  if (resolv(infos->_precision_to_use) != K_PRINTF_RESOLVED)
		    return K_PRINTF_ERR;
		  infos->_precision_to_use = k_va_arg(resolved_arg_list, int);
		  if (infos->_precision_to_use < 0)
		    infos->_precision_to_use = 0;
		}
	      else
		{
		  if (infos->_precision_to_use == resolving_arg)
		    {
		      k_va_arg(resolved_arg_list, int);
		      return K_PRINTF_RESOLVED;
		    }
		}
	      pos = tmppos + 1;
	      return 0;
	    }
	  if (!resolving_arg)
	    {
	      infos->_precision_to_use = k_va_arg(args, int);
	      if (infos->_precision_to_use < 0)
		infos->_precision_to_use = 0;
	    }
	  else
	    {
	      if (current_arg == resolving_arg)
		{
		  k_va_arg(resolved_arg_list, int);
		  return K_PRINTF_RESOLVED;
		}
	      else
		current_arg++;
	    }
	  pos = pos + 2;
	  return 0;
	}
      pos = pos + 1;
      return 0;
    }
  infos->_precision_specified = 0;
  infos->_precision_to_use = 1;
  return 0;
}

static int		hh_len_modifier(_t_arg_infos	*infos)
{
  infos->_len_modifier._hh = 1;
  return 0;
}

static int		ll_len_modifier(_t_arg_infos	*infos)
{
  infos->_len_modifier._ll = 1;
  return 0;
}

static int		h_len_modifier(_t_arg_infos	*infos)
{
  infos->_len_modifier._h = 1;
  return 0;
}

static int		l_len_modifier(_t_arg_infos	*infos)
{
  infos->_len_modifier._l = 1;
  return 0;
}

static int		L_len_modifier(_t_arg_infos	*infos)
{
  infos->_len_modifier._L = 1;
  return 0;
}

static int		q_len_modifier(_t_arg_infos	*infos)
{
  infos->_len_modifier._q = 1;
  return 0;
}

static int		j_len_modifier(_t_arg_infos	*infos)
{
  infos->_len_modifier._j = 1;
  return 0;
}

static int		z_len_modifier(_t_arg_infos	*infos)
{
  infos->_len_modifier._z = 1;
  return 0;
}

static int		t_len_modifier(_t_arg_infos	*infos)
{
  infos->_len_modifier._t = 1;
  return 0;
}

static int		check_len_modifier(_t_arg_infos	*infos)
{
  int			i;
  int			ret;

  for (i = 0; len_modifiers_tab[i]._f != 0; i++)
    {
      if (!strncmp(len_modifiers_tab[i]._s, fmt + pos,
		   strlen(len_modifiers_tab[i]._s)))
	{
	  ret = (*(len_modifiers_tab[i]._f))(infos);
	  pos += strlen(len_modifiers_tab[i]._s);
	  return ret;
	}
    }
  return 0;
}

static int		d_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    signed char		_hh;
    short int		_h;
    long int		_l;
    long long int	_ll;
    long long int	_q;
    intmax_t		_j;
    ssize_t		_z;
    ptrdiff_t		_t;
    int			_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, signed char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, intmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, ssize_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, int);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, signed char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, intmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, ssize_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, int);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(resolved_arg_list, signed char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(resolved_arg_list, short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(resolved_arg_list, long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(resolved_arg_list, long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(resolved_arg_list, long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(resolved_arg_list, intmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(resolved_arg_list, ssize_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(resolved_arg_list, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, int);
	}
      else
	{
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(args, signed char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(args, short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(args, long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(args, long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(args, long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(args, intmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(args, ssize_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(args, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(args, int);
	}
      if (infos->_len_modifier._hh)
	return _k_print_hhd(arg_value._hh, infos);
      else if (infos->_len_modifier._h)
	return _k_print_hd(arg_value._h, infos);
      else if (infos->_len_modifier._l)
	return _k_print_ld(arg_value._l, infos);
      else if (infos->_len_modifier._ll)
	return _k_print_lld(arg_value._ll, infos);
      else if (infos->_len_modifier._q)
	return _k_print_qd(arg_value._q, infos);
      else if (infos->_len_modifier._j)
	return _k_print_jd(arg_value._j, infos);
      else if (infos->_len_modifier._z)
	return _k_print_zd(arg_value._z, infos);
      else if (infos->_len_modifier._t)
	return _k_print_td(arg_value._t, infos);
      else
	return _k_print_d(arg_value._default, infos);
    }
  return 0;
}

static int		i_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    signed char		_hh;
    short int		_h;
    long int		_l;
    long long int	_ll;
    long long int	_q;
    intmax_t		_j;
    ssize_t		_z;
    ptrdiff_t		_t;
    int			_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, signed char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, intmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, ssize_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, int);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, signed char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, intmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, ssize_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, int);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(resolved_arg_list, signed char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(resolved_arg_list, short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(resolved_arg_list, long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(resolved_arg_list, long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(resolved_arg_list, long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(resolved_arg_list, intmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(resolved_arg_list, ssize_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(resolved_arg_list, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, int);
	}
      else
	{
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(args, signed char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(args, short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(args, long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(args, long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(args, long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(args, intmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(args, ssize_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(args, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(args, int);
	}
      if (infos->_len_modifier._hh)
	return _k_print_hhi(arg_value._hh, infos);
      else if (infos->_len_modifier._h)
	return _k_print_hi(arg_value._h, infos);
      else if (infos->_len_modifier._l)
	return _k_print_li(arg_value._l, infos);
      else if (infos->_len_modifier._ll)
	return _k_print_lli(arg_value._ll, infos);
      else if (infos->_len_modifier._q)
	return _k_print_qi(arg_value._q, infos);
      else if (infos->_len_modifier._j)
	return _k_print_ji(arg_value._j, infos);
      else if (infos->_len_modifier._z)
	return _k_print_zi(arg_value._z, infos);
      else if (infos->_len_modifier._t)
	return _k_print_ti(arg_value._t, infos);
      else
	return _k_print_i(arg_value._default, infos);
    }
  return 0;
}

static int		o_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    unsigned char		_hh;
    unsigned short int		_h;
    unsigned long int		_l;
    unsigned long long int	_ll;
    unsigned long long int	_q;
    uintmax_t			_j;
    size_t			_z;
    ptrdiff_t			_t;
    unsigned int		_default;
  }				arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, unsigned char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, unsigned short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, unsigned long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, uintmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, size_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, unsigned int);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, unsigned char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, unsigned short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, unsigned long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, uintmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, size_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, unsigned int);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(resolved_arg_list, unsigned char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(resolved_arg_list, unsigned short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(resolved_arg_list, unsigned long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(resolved_arg_list,
				     unsigned long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(resolved_arg_list, unsigned long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(resolved_arg_list, uintmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(resolved_arg_list, size_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(resolved_arg_list, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, unsigned int);
	}
      else
	{
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(args, unsigned char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(args, unsigned short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(args, unsigned long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(args, unsigned long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(args, unsigned long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(args, uintmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(args, size_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(args, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(args, unsigned int);
	}
      if (infos->_len_modifier._hh)
	return _k_print_hho(arg_value._hh, infos);
      else if (infos->_len_modifier._h)
	return _k_print_ho(arg_value._h, infos);
      else if (infos->_len_modifier._l)
	return _k_print_lo(arg_value._l, infos);
      else if (infos->_len_modifier._ll)
	return _k_print_llo(arg_value._ll, infos);
      else if (infos->_len_modifier._q)
	return _k_print_qo(arg_value._q, infos);
      else if (infos->_len_modifier._j)
	return _k_print_jo(arg_value._j, infos);
      else if (infos->_len_modifier._z)
	return _k_print_zo(arg_value._z, infos);
      else if (infos->_len_modifier._t)
	return _k_print_to(arg_value._t, infos);
      else
	return _k_print_o(arg_value._default, infos);
    }
  return 0;
}

static int		u_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    unsigned char		_hh;
    unsigned short int		_h;
    unsigned long int		_l;
    unsigned long long int	_ll;
    unsigned long long int	_q;
    uintmax_t			_j;
    size_t			_z;
    ptrdiff_t			_t;
    unsigned int		_default;
  }				arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, unsigned char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, unsigned short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, unsigned long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, uintmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, size_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, unsigned int);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, unsigned char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, unsigned short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, unsigned long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, uintmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, size_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, unsigned int);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(resolved_arg_list, unsigned char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(resolved_arg_list, unsigned short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(resolved_arg_list, unsigned long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(resolved_arg_list,
				     unsigned long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(resolved_arg_list, unsigned long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(resolved_arg_list, uintmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(resolved_arg_list, size_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(resolved_arg_list, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, unsigned int);
	}
      else
	{
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(args, unsigned char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(args, unsigned short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(args, unsigned long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(args, unsigned long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(args, unsigned long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(args, uintmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(args, size_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(args, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(args, unsigned int);
	}
      if (infos->_len_modifier._hh)
	return _k_print_hhu(arg_value._hh, infos);
      else if (infos->_len_modifier._h)
	return _k_print_hu(arg_value._h, infos);
      else if (infos->_len_modifier._l)
	return _k_print_lu(arg_value._l, infos);
      else if (infos->_len_modifier._ll)
	return _k_print_llu(arg_value._ll, infos);
      else if (infos->_len_modifier._q)
	return _k_print_qu(arg_value._q, infos);
      else if (infos->_len_modifier._j)
	return _k_print_ju(arg_value._j, infos);
      else if (infos->_len_modifier._z)
	return _k_print_zu(arg_value._z, infos);
      else if (infos->_len_modifier._t)
	return _k_print_tu(arg_value._t, infos);
      else
	return _k_print_u(arg_value._default, infos);
    }
  return 0;
}

static int		x_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    unsigned char		_hh;
    unsigned short int		_h;
    unsigned long int		_l;
    unsigned long long int	_ll;
    unsigned long long int	_q;
    uintmax_t			_j;
    size_t			_z;
    ptrdiff_t			_t;
    unsigned int		_default;
  }				arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, unsigned char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, unsigned short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, unsigned long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, uintmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, size_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, unsigned int);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, unsigned char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, unsigned short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, unsigned long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, uintmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, size_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, unsigned int);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(resolved_arg_list, unsigned char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(resolved_arg_list, unsigned short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(resolved_arg_list, unsigned long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(resolved_arg_list,
				     unsigned long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(resolved_arg_list, unsigned long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(resolved_arg_list, uintmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(resolved_arg_list, size_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(resolved_arg_list, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, unsigned int);
	}
      else
	{
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(args, unsigned char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(args, unsigned short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(args, unsigned long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(args, unsigned long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(args, unsigned long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(args, uintmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(args, size_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(args, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(args, unsigned int);
	}
      if (infos->_len_modifier._hh)
	return _k_print_hhx(arg_value._hh, infos);
      else if (infos->_len_modifier._h)
	return _k_print_hx(arg_value._h, infos);
      else if (infos->_len_modifier._l)
	return _k_print_lx(arg_value._l, infos);
      else if (infos->_len_modifier._ll)
	return _k_print_llx(arg_value._ll, infos);
      else if (infos->_len_modifier._q)
	return _k_print_qx(arg_value._q, infos);
      else if (infos->_len_modifier._j)
	return _k_print_jx(arg_value._j, infos);
      else if (infos->_len_modifier._z)
	return _k_print_zx(arg_value._z, infos);
      else if (infos->_len_modifier._t)
	return _k_print_tx(arg_value._t, infos);
      else
	return _k_print_x(arg_value._default, infos);
    }
  return 0;
}

static int		X_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    unsigned char		_hh;
    unsigned short int		_h;
    unsigned long int		_l;
    unsigned long long int	_ll;
    unsigned long long int	_q;
    uintmax_t			_j;
    size_t			_z;
    ptrdiff_t			_t;
    unsigned int		_default;
  }				arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, unsigned char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, unsigned short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, unsigned long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, uintmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, size_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, unsigned int);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, unsigned char);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, unsigned short int);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, unsigned long int);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, unsigned long long int);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, uintmax_t);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, size_t);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t);
	      else
		k_va_arg(resolved_arg_list, unsigned int);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(resolved_arg_list, unsigned char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(resolved_arg_list, unsigned short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(resolved_arg_list, unsigned long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(resolved_arg_list,
				     unsigned long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(resolved_arg_list, unsigned long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(resolved_arg_list, uintmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(resolved_arg_list, size_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(resolved_arg_list, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, unsigned int);
	}
      else
	{
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(args, unsigned char);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(args, unsigned short int);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(args, unsigned long int);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(args, unsigned long long int);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(args, unsigned long long int);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(args, uintmax_t);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(args, size_t);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(args, ptrdiff_t);
	  else
	    arg_value._default = k_va_arg(args, unsigned int);
	}
      if (infos->_len_modifier._hh)
	return _k_print_hhX(arg_value._hh, infos);
      else if (infos->_len_modifier._h)
	return _k_print_hX(arg_value._h, infos);
      else if (infos->_len_modifier._l)
	return _k_print_lX(arg_value._l, infos);
      else if (infos->_len_modifier._ll)
	return _k_print_llX(arg_value._ll, infos);
      else if (infos->_len_modifier._q)
	return _k_print_qX(arg_value._q, infos);
      else if (infos->_len_modifier._j)
	return _k_print_jX(arg_value._j, infos);
      else if (infos->_len_modifier._z)
	return _k_print_zX(arg_value._z, infos);
      else if (infos->_len_modifier._t)
	return _k_print_tX(arg_value._t, infos);
      else
	return _k_print_X(arg_value._default, infos);
    }
  return 0;
}

static int		e_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    long double		_L;
    double		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(resolved_arg_list, long double);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, double);
	}
      else
	{
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(args, long double);
	  else
	    arg_value._default = k_va_arg(args, double);
	}
      if (infos->_len_modifier._L)
	return _k_print_Le(arg_value._L, infos);
      else
	return _k_print_e(arg_value._default, infos);
    }
  return 0;
}

static int		E_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    long double		_L;
    double		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(resolved_arg_list, long double);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, double);
	}
      else
	{
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(args, long double);
	  else
	    arg_value._default = k_va_arg(args, double);
	}
      if (infos->_len_modifier._L)
	return _k_print_LE(arg_value._L, infos);
      else
	return _k_print_E(arg_value._default, infos);
    }
  return 0;
}

static int		f_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    long double		_L;
    double		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(resolved_arg_list, long double);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, double);
	}
      else
	{
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(args, long double);
	  else
	    arg_value._default = k_va_arg(args, double);
	}
      if (infos->_len_modifier._L)
	return _k_print_Lf(arg_value._L, infos);
      else
	return _k_print_f(arg_value._default, infos);
    }
  return 0;
}

static int		F_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    long double		_L;
    double		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(resolved_arg_list, long double);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, double);
	}
      else
	{
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(args, long double);
	  else
	    arg_value._default = k_va_arg(args, double);
	}
      if (infos->_len_modifier._L)
	return _k_print_LF(arg_value._L, infos);
      else
	return _k_print_F(arg_value._default, infos);
    }
  return 0;
}

static int		g_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    long double		_L;
    double		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(resolved_arg_list, long double);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, double);
	}
      else
	{
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(args, long double);
	  else
	    arg_value._default = k_va_arg(args, double);
	}
      if (infos->_len_modifier._L)
	return _k_print_Lg(arg_value._L, infos);
      else
	return _k_print_g(arg_value._default, infos);
    }
  return 0;
}

static int		G_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    long double		_L;
    double		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(resolved_arg_list, long double);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, double);
	}
      else
	{
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(args, long double);
	  else
	    arg_value._default = k_va_arg(args, double);
	}
      if (infos->_len_modifier._L)
	return _k_print_LG(arg_value._L, infos);
      else
	return _k_print_G(arg_value._default, infos);
    }
  return 0;
}

static int		a_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    long double		_L;
    double		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(resolved_arg_list, long double);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, double);
	}
      else
	{
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(args, long double);
	  else
	    arg_value._default = k_va_arg(args, double);
	}
      if (infos->_len_modifier._L)
	return _k_print_La(arg_value._L, infos);
      else
	return _k_print_a(arg_value._default, infos);
    }
  return 0;
}

static int		A_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    long double		_L;
    double		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._L)
		k_va_arg(resolved_arg_list, long double);
	      else
		k_va_arg(resolved_arg_list, double);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(resolved_arg_list, long double);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, double);
	}
      else
	{
	  if (infos->_len_modifier._L)
	    arg_value._L = k_va_arg(args, long double);
	  else
	    arg_value._default = k_va_arg(args, double);
	}
      if (infos->_len_modifier._L)
	return _k_print_LA(arg_value._L, infos);
      else
	return _k_print_A(arg_value._default, infos);
    }
  return 0;
}

static int		c_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    wint_t		_l;
    int			_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, wint_t);
	      else
		k_va_arg(resolved_arg_list, int);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, wint_t);
	      else
		k_va_arg(resolved_arg_list, int);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(resolved_arg_list, wint_t);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, int);
	}
      else
	{
	  if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(args, wint_t);
	  else
	    arg_value._default = k_va_arg(args, int);
	}
      if (infos->_len_modifier._l)
	return _k_print_lc(arg_value._l, infos);
      else
	return _k_print_c(arg_value._default, infos);
    }
  return 0;
}

static int		s_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    const wchar_t	*_l;
    const char		*_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, const wchar_t *);
	      else
		k_va_arg(resolved_arg_list, const char *);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, const wchar_t *);
	      else
		k_va_arg(resolved_arg_list, const char *);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(resolved_arg_list, const wchar_t *);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, const char *);
	}
      else
	{
	  if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(args, const wchar_t *);
	  else
	    arg_value._default = k_va_arg(args, const char *);
	}
      if (infos->_len_modifier._l)
	return _k_print_ls(arg_value._l, infos);
      else
	return _k_print_s(arg_value._default, infos);
    }
  return 0;
}

static int		C_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    wint_t		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      k_va_arg(resolved_arg_list, wint_t);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      k_va_arg(resolved_arg_list, wint_t);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  arg_value._default = k_va_arg(resolved_arg_list, wint_t);
	}
      else
	{
	  arg_value._default = k_va_arg(args, wint_t);
	}
      return _k_print_C(arg_value._default, infos);
    }
  return 0;
}

static int		S_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    const wchar_t	*_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      k_va_arg(resolved_arg_list, const wchar_t *);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      k_va_arg(resolved_arg_list, const wchar_t *);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  arg_value._default = k_va_arg(resolved_arg_list, const wchar_t *);
	}
      else
	{
	  arg_value._default = k_va_arg(args, const wchar_t *);
	}
      return _k_print_S(arg_value._default, infos);
    }
  return 0;
}

static int		p_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    void		*_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      k_va_arg(resolved_arg_list, void *);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      k_va_arg(resolved_arg_list, void *);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  arg_value._default = k_va_arg(resolved_arg_list, void *);
	}
      else
	{
	  arg_value._default = k_va_arg(args, void *);
	}
      return _k_print_p(arg_value._default, infos);
    }
  return 0;
}

static int		k_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    char		_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      k_va_arg(resolved_arg_list, char);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      k_va_arg(resolved_arg_list, char);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  arg_value._default = k_va_arg(resolved_arg_list, char);
	}
      else
	{
	  arg_value._default = k_va_arg(args, char);
	}
      k_set_attr(arg_value._default);
      return 0;
    }
  return 0;
}

static int		n_conversion_indicator(_t_arg_infos	*infos)
{
  union
  {
    signed char		*_hh;
    short int		*_h;
    long int		*_l;
    long long int	*_ll;
    long long int	*_q;
    intmax_t		*_j;
    ssize_t		*_z;
    ptrdiff_t		*_t;
    int			*_default;
  }			arg_value;

  if (resolving_arg)
    {
      if (infos->_static_arg == 1)
	{
	  if (infos->_arg_to_use == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, signed char *);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, short int *);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, long int *);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, long long int *);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, long long int *);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, intmax_t *);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, ssize_t *);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t *);
	      else
		k_va_arg(resolved_arg_list, int *);
	      return K_PRINTF_RESOLVED;
	    }
	}
      else
	{
	  if (current_arg == resolving_arg)
	    {
	      if (infos->_len_modifier._hh)
		k_va_arg(resolved_arg_list, signed char *);
	      else if (infos->_len_modifier._h)
		k_va_arg(resolved_arg_list, short int *);
	      else if (infos->_len_modifier._l)
		k_va_arg(resolved_arg_list, long int *);
	      else if (infos->_len_modifier._ll)
		k_va_arg(resolved_arg_list, long long int *);
	      else if (infos->_len_modifier._q)
		k_va_arg(resolved_arg_list, long long int *);
	      else if (infos->_len_modifier._j)
		k_va_arg(resolved_arg_list, intmax_t *);
	      else if (infos->_len_modifier._z)
		k_va_arg(resolved_arg_list, ssize_t *);
	      else if (infos->_len_modifier._t)
		k_va_arg(resolved_arg_list, ptrdiff_t *);
	      else
		k_va_arg(resolved_arg_list, int *);
	      return K_PRINTF_RESOLVED;
	    }
	  else
	    {
	      current_arg++;
	      return 0;
	    }
	}
    }
  else
    {
      if (infos->_static_arg == 1)
	{
	  if (resolv(infos->_arg_to_use) != K_PRINTF_RESOLVED)
	    return K_PRINTF_ERR;
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(resolved_arg_list, signed char *);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(resolved_arg_list, short int *);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(resolved_arg_list, long int *);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(resolved_arg_list, long long int *);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(resolved_arg_list, long long int *);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(resolved_arg_list, intmax_t *);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(resolved_arg_list, ssize_t *);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(resolved_arg_list, ptrdiff_t *);
	  else
	    arg_value._default = k_va_arg(resolved_arg_list, int *);
	}
      else
	{
	  if (infos->_len_modifier._hh)
	    arg_value._hh = k_va_arg(args, signed char *);
	  else if (infos->_len_modifier._h)
	    arg_value._h = k_va_arg(args, short int *);
	  else if (infos->_len_modifier._l)
	    arg_value._l = k_va_arg(args, long int *);
	  else if (infos->_len_modifier._ll)
	    arg_value._ll = k_va_arg(args, long long int *);
	  else if (infos->_len_modifier._q)
	    arg_value._q = k_va_arg(args, long long int *);
	  else if (infos->_len_modifier._j)
	    arg_value._j = k_va_arg(args, intmax_t *);
	  else if (infos->_len_modifier._z)
	    arg_value._z = k_va_arg(args, ssize_t *);
	  else if (infos->_len_modifier._t)
	    arg_value._t = k_va_arg(args, ptrdiff_t *);
	  else
	    arg_value._default = k_va_arg(args, int *);
	}
      if (infos->_len_modifier._hh)
	{
	  if (arg_value._hh)
	    *(arg_value._hh) = (signed char)wroten;
	}
      else if (infos->_len_modifier._h)
	{
	  if (arg_value._h)
	    *(arg_value._h) = (short int)wroten;
	}
      else if (infos->_len_modifier._l)
	{
	  if (arg_value._l)
	    *(arg_value._l) = (long int)wroten;
	}
      else if (infos->_len_modifier._ll)
	{
	  if (arg_value._ll)
	    *(arg_value._ll) = (long long int)wroten;
	}
      else if (infos->_len_modifier._q)
	{
	  if (arg_value._q)
	    *(arg_value._q) = (long long int)wroten;
	}
      else if (infos->_len_modifier._j)
	{
	  if (arg_value._j)
	    *(arg_value._j) = (intmax_t)wroten;
	}
      else if (infos->_len_modifier._z)
	{
	  if (arg_value._z)
	    *(arg_value._z) = (ssize_t)wroten;
	}
      else if (infos->_len_modifier._t)
	{
	  if (arg_value._t)
	    *(arg_value._t) = (ptrdiff_t)wroten;
	}
      else
	{
	  if (arg_value._default)
	    *(arg_value._default) = (int)wroten;
	}
    }
  return 0;
}

static int		percent_conversion_indicator(_t_arg_infos	*infos)
{
  if (!resolving_arg)
    return _k_print_char('%');
  return 0;
}

static int		check_conversion_indicator(_t_arg_infos	*infos)
{
  int			i;
  int			ret;

  for (i = 0; conversion_indicators_tab[i]._f != 0; i++)
    if (conversion_indicators_tab[i]._c == fmt[pos])
      {
	ret = (*(conversion_indicators_tab[i]._f))(infos);
	pos++;
	return ret;
      }
  return K_PRINTF_ERR;
}

static int		init_infos(_t_arg_infos	*infos)
{
  if (!infos)
    return K_PRINTF_ERR;
  infos->_len_modifier._hh = 0;
  infos->_len_modifier._ll = 0;
  infos->_len_modifier._h = 0;
  infos->_len_modifier._l = 0;
  infos->_len_modifier._L = 0;
  infos->_len_modifier._q = 0;
  infos->_len_modifier._j = 0;
  infos->_len_modifier._z = 0;
  infos->_len_modifier._t = 0;
  infos->_attrs._sharp = 0;
  infos->_attrs._zero = 0;
  infos->_attrs._minus = 0;
  infos->_attrs._space = 0;
  infos->_attrs._more = 0;
  infos->_attrs._apostrophe = 0;
  infos->_attrs._I = 0;
  infos->_min_len_to_use = 0;
  infos->_precision_to_use = 1;
  infos->_precision_specified = 0;
  infos->_arg_to_use = 0;
  infos->_static_arg = 0;
  return 0;
}

static int		handle_conversion()
{
  _t_arg_infos		infos;
  int			ret;

  pos++;
  if (init_infos(&infos) == K_PRINTF_ERR)
    return K_PRINTF_ERR;

  if (check_percent_m_dollar(&infos) == K_PRINTF_ERR)
    {
      return K_PRINTF_ERR;
    }

  if (check_attributes(&infos) == K_PRINTF_ERR)
    {
      return K_PRINTF_ERR;
    }

  if ((ret = check_min_len(&infos)) == K_PRINTF_ERR)
    {
      return K_PRINTF_ERR;
    }
  if (ret == K_PRINTF_RESOLVED)
    return K_PRINTF_RESOLVED;

  if ((ret = check_precision(&infos)) == K_PRINTF_ERR)
    {
      return K_PRINTF_ERR;
    }
  if (ret == K_PRINTF_RESOLVED)
    return K_PRINTF_RESOLVED;

  if (check_len_modifier(&infos) == K_PRINTF_ERR)
    {
      return K_PRINTF_ERR;
    }

  if ((ret = check_conversion_indicator(&infos)) == K_PRINTF_ERR)
    {
      return K_PRINTF_ERR;
    }
  if (ret == K_PRINTF_RESOLVED)
    return K_PRINTF_RESOLVED;
  return 0;
}

static int		handle_end()
{
  if (writer == k_str_writer)
    _k_print_char('\0');
  return K_PRINTF_END;
}

static int		print_element_at_pos()
{
  int			i;
  _t_va_list		args_backup;
  size_t		pos_backup;
  int			current_arg_backup;
  int			ret;

  for (i = 0; (chars_tab[i]._c != fmt[pos]) && (chars_tab[i]._f != 0); i++)
    ;
  if (!chars_tab[i]._f)
    {
      if (!resolving_arg)
	if (_k_print_char(fmt[pos]) == K_PRINTF_END)
	  return K_PRINTF_END;
      pos++;
    }
  else
    {
      k_va_copy(args_backup, args);
      pos_backup = pos;
      current_arg_backup = current_arg;
      ret = (*(chars_tab[i]._f))();
      if (ret == K_PRINTF_ERR)
	{
	  k_va_copy(args, args_backup);
	  pos = pos_backup;
	  current_arg = current_arg_backup;
	  if (!resolving_arg)
	    if (_k_print_char(fmt[pos]) == K_PRINTF_END)
	      return K_PRINTF_END;
	  pos++;
	}
      return ret;
    }
  return 0;
}

static ssize_t		_printf(const char	*format,
				_t_va_list	va_list)
{
  _t_bool		end_reached = false;
  char			old_attr;

  pos = 0;
  if (!resolving_arg)
    {
      old_attr = k_get_attr();
      out_error_found = false;
      wroten = 0;
      fmt = format;
      k_va_copy(args, va_list);
      k_va_copy(args_orig, args);
    }
  if (!format)
    return K_PRINTF_ERR;
  while (!end_reached)
    {
      switch (print_element_at_pos())
	{
	case K_PRINTF_RESOLVED :
	  return K_PRINTF_RESOLVED;
	case K_PRINTF_END :
	  end_reached = 1;
	  break ;
	}
    }
  if (!resolving_arg)
    {
      k_va_end(args);
      k_va_end(args_orig);
      k_va_end(resolved_arg_list);
      k_set_attr(old_attr);
      return ((out_error_found == 1) ? K_PRINTF_ERR : wroten);
    }
  else
    return K_PRINTF_NOT_RESOLVED;
}

int			_k_print_char(unsigned char	c)
{
  if (wroten < max_chars)
    {
      if (writer == k_str_writer)
	{
	  if (((*writer)(c, &str_w_info)) == K_WRITER_ERR)
	    out_error_found = true;
	  if (pos < SLONG_MAX)
	    str_w_info._pos++;
	}
      else
	{
	  if (((*writer)(c, 0)) == K_WRITER_ERR)
	    out_error_found = true;
	}
    }
  else if ((wroten == max_chars) && (writer == k_str_writer))
    if ((*writer)('\0', &str_w_info) == K_WRITER_ERR)
      out_error_found = true;
  if (wroten < SLONG_MAX)
    wroten++;
  return 0;
}

ssize_t			k_console_printf(const char	*format,
					 ...)
{
  _t_va_list		va_list;
  ssize_t		ret;

  max_chars = SLONG_MAX;
  writer = &k_console_writer;

  k_va_start(va_list, format);
  ret = _printf(format, va_list);

  if (DUPLICATE_CONSOLE_PRINTF_ON_BOCHS)
    {
      k_va_start(va_list, format);
      writer = &k_bochs_writer;
      _printf(format, va_list);
    }
  k_va_end(va_list);
  return ret;
}

ssize_t			k_snprintf(char			*buf,
				   size_t		len,
				   const char		*format,
				   ...)
{
  _t_va_list		va_list;
  ssize_t		ret;

  max_chars = SLONG_MAX;
  if (len < max_chars)
    max_chars = len;
  str_w_info._str = buf;
  str_w_info._pos = 0;
  writer = &k_str_writer;
  k_va_start(va_list, format);
  ret = _printf(format, va_list);
  k_va_end(va_list);
  return ret;
}

ssize_t			k_sprintf(char			*buf,
				  const char		*format,
				  ...)
{
  _t_va_list		va_list;
  ssize_t		ret;

  max_chars = SLONG_MAX;
  writer = &k_str_writer;
  str_w_info._str = buf;
  str_w_info._pos = 0;
  k_va_start(va_list, format);
  ret = _printf(format, va_list);
  k_va_end(va_list);
  return ret;
}

ssize_t			k_bochs_printf(const char	*format,
				       ...)
{
  _t_va_list		va_list;
  ssize_t		ret;

  max_chars = SLONG_MAX;
  writer = &k_bochs_writer;
  k_va_start(va_list, format);
  ret = _printf(format, va_list);
  k_va_end(va_list);
  return ret;
}

ssize_t			k_null_printf(const char	*format,
				      ...)
{
  _t_va_list		va_list;
  ssize_t		ret;

  max_chars = SLONG_MAX;
  writer = &k_null_writer;

  k_va_start(va_list, format);
  ret = _printf(format, va_list);
  k_va_end(va_list);
  return ret;
}
