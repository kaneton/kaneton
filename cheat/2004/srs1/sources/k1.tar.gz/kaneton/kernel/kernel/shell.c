#include <shell.h>
#include <keyboard.h>
#include <console.h>
#include <debugger.h>
#include <system.h>
#include <strings.h>
#include <printf.h>
#include <ctype.h>
#include <bochs.h>
#include <mm.h>
/*
 * global variables
 */


/*
 * extern variables
 */
extern _t_kbdmap	k_keyboard_maps[];

/*
 * static variables
 */
static void	shell_help(char	*cmd);
static void	shell_kbdmap(char	*cmd);
static void	shell_reboot(char	*cmd);
static void	shell_halt(char	*cmd);
static void	shell_keyscan(char	*cmd);
static void	shell_panic(char	*cmd);
static void	shell_stacktrace(char	*cmd);
static void	shell_hexdump(char	*cmd);
static void	shell_hexdump_from_to(char	*cmd);
static void	shell_ascii(char	*cmd);
static void	shell_freepages(char	*cmd);
static void	shell_about(char	*cmd);

static _t_cmds		_commands[] =
  {
    { "help", shell_help },
    { "kbdmap", shell_kbdmap },
    { "reboot", shell_reboot },
    { "halt", shell_halt },
    { "keyscan", shell_keyscan },
    { "panic", shell_panic },
    { "stacktrace", shell_stacktrace },
    { "hexdump", shell_hexdump },
    { "hexdump_to", shell_hexdump_from_to },
    { "ascii", shell_ascii },
    { "freepages", shell_freepages },
    { "about", shell_about },
    { 0, 0 }
  };

/*
 * static functions
 */
/* Print Shell Help */
static void	shell_help(char		*cmd)
{
  int		i, title_len,  column_len;
  _t_bool	separators[CONSOLE_X - 5];
  _t_alignment  alignment[2] = { left, left };
  unsigned char	left_color = MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);
  unsigned char	right_color = MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  static _t_cmd_help	cmd_help[] =
    {
      { " help ", "Displays this text." },
      { " about ", "Informations about the project." },
      { "", "" },
      { " ascii ", "Shows ASCII table with decimal codes." },
      { "       dec ", "Shows ASCII table with decimal codes." },
      { "       oct ", "Shows ASCII table with octal codes." },
      { "       hex ", "Shows ASCII table with hexadecimal codes." },
      { "", "" },
      { " kbdmap <mapname> ", "Changes keyboard mapping." },
      { "        list ", "Displays maps list." },
      { " keyscan ", "Dumps key scan codes." },
      { "", "" },
      { " panic ", "Generates fatal exception 'divide by zero'." },
      { "", "" },
      { " stacktrace ", "Dumps callstack." },
      { " hexdump <addr> <size> ", "Dumps 'size' bytes at memory address "
	"'addr'." },
      { " ", "'addr' is hexadecimal value." },
      { " ", "'size' is decimal value." },
      { " hexdump_to <addr1> <addr2> ",
	"Dumps bytes from memory address " },
      { " ", "'addr1' up to and including memory address " },
      { " ", "'addr2'." },
      { " ", "'addr1' and 'addr2' are hexadecimal values." },
      { " freepages ", "Displays number of free physical pages." },
      { "", "" },
      { " reboot ", "Reboots the system." },
      { " halt ", "Halts the system." },
      { 0, 0 }
    };

  title_len = k_print_title_window("Help");
  for (i = 0, column_len = 0; cmd_help[i]._cmd != 0; i++)
    if (strlen(cmd_help[i]._cmd) > column_len)
      column_len = strlen(cmd_help[i]._cmd);
  for (i = 0; i < CONSOLE_X - 5; i++)
    separators[i] = false;
  separators[column_len] = true;
  k_print_up_border_window(title_len, separators);
  for (i = 0; cmd_help[i]._cmd != 0; i++)
    {
      if (!strcmp(cmd_help[i]._cmd, ""))
	k_print_separator(separators, separators);
      else
	k_print_datas_in_window(separators,
				cmd_help[i]._cmd, left_color, alignment[0],
				cmd_help[i]._desc, right_color, alignment[1]);
    }
  k_print_down_border_window(separators);
}

/* Changes Keyboard Map */
static void	shell_kbdmap(char	*cmd)
{
  int		i;
  char		map[1024];

  map[0] = '\0';
  while (isblank(*cmd))
    cmd++;
  for (i = 0; isalpha(cmd[i]); i++)
    ;
  if (!((cmd[i] == '\0') || (isblank(cmd[i]))))
    {
      if (i == 0)
	k_console_printf("Map name or \"list\" is missing.\n");
      else
	k_console_printf("Invalid parameter. "
			 "(alpha required).\n");
    }
  else
    strncpy(map, cmd, i);

  if (!strcmp(map, "list"))
    {
      k_console_printf("Availables keymaps:\n");
      for (i = 0; k_keyboard_maps[i]._map; i++)
	k_console_printf("  - %s\n",
			 k_keyboard_maps[i]._mapname);
    }
  else
    {
      for (i = 0; k_keyboard_maps[i]._map; i++)
	if (!strcmp(cmd, k_keyboard_maps[i]._mapname))
	  {
	    k_set_keyboard_map(k_keyboard_maps[i]._map);
	    k_console_printf("Keyboard mapping changed to \"%s\".\n",
			     k_keyboard_maps[i]._mapname);
	    i--;
	    break ;
	  }
      if (!k_keyboard_maps[i]._map)
	k_console_printf("%s: inexistant map name, use \"list\""
			 " to get available ones.\n", cmd);
    }
}

/* Reboot Command Action */
static void	shell_reboot(char	*cmd)
{
  k_console_printf("Rebooting...\n");
  k_reboot();
}

/* Halt Command Action */
static void	shell_halt(char	*cmd)
{
  k_console_printf("System halted...\n");
  k_halt();
}

/* Keyscan Command Action */
static void	shell_keyscan(char	*cmd)
{
  unsigned char	key;

  k_console_printf("Dumping keycodes, press ESC to exit\n");
  do
    {
      key = k_get_char();
      k_console_printf("%#0.2x ", key);
    }
  while (key != 1);
  k_console_printf("\n");
}

/* Panic Command Action */
static void	shell_panic(char	*cmd)
{
  int		i = 0;

  i /= i;
}

/* Stacktrace Command Action */
static void	shell_stacktrace(char	*cmd)
{
  k_dump_stack_trace();
}

/* About me */
static void	shell_about(char	*cmd)
{
  k_console_printf("K for X86 version 1.0 (Jan 2006), made by Damien ELIE.\n");
  k_console_printf("elie_d@epita.fr\n");
}

/* Hexdump Command Action */
static void	shell_hexdump(char	*cmd)
{
  _t_bool	err = false;
  int		i, j;
  unsigned int	addr;
  size_t	size;

  while (isblank(*cmd))
    cmd++;
  if ((cmd[0] == '0') && ((cmd[1] == 'x') || (cmd[1] == 'X')))
    j = 2;
  else
    j = 0;
  for (i = j; isxdigit(cmd[i]); i++)
    ;
  if ((!((cmd[i] == '\0') || (isblank(cmd[i])))) || (i == 0))
    {
      if (((j == 0) && (i == 0)) ||
	  ((j == 2) && (i == 2)))
	{
	  k_console_printf("Address parameter is missing.\n");
	  err = true;
	}
      else
	{
	  k_console_printf("Invalid address parameter "
			   "(hexadecimal value required).\n");
	  err = true;
	}
    }
  else
    addr = antox(cmd, i);

  cmd += i;
  while (isblank(*cmd))
    cmd++;
  for (i = 0; isdigit(cmd[i]); i++)
    ;
  if ((!((cmd[i] == '\0') || (isblank(cmd[i])))) || (i == 0))
    {
      if (i == 0)
	{
	  k_console_printf("Size parameter is missing.\n");
	  err = true;
	}
      else
	{
	  k_console_printf("Invalid size parameter "
			   "(decimal value required).\n");
	  err = true;
	}
    }
  else
    size = antosize(cmd, i);

  if (err == false)
    k_hexdump((void *)addr, size);
}

/* Hexdump from @ to @ Command Action */
static void	shell_hexdump_from_to(char	*cmd)
{
  _t_bool	err = false;
  int		i, j;
  unsigned int	addr1, addr2;

  while (isblank(*cmd))
    cmd++;
  if ((cmd[0] == '0') && ((cmd[1] == 'x') || (cmd[1] == 'X')))
    j = 2;
  else
    j = 0;
  for (i = j; isxdigit(cmd[i]); i++)
    ;
  if ((!((cmd[i] == '\0') || (isblank(cmd[i])))) || (i == 0))
    {
      if (((j == 0) && (i == 0)) ||
	  ((j == 2) && (i == 2)))
	{
	  k_console_printf("First address parameter is missing.\n");
	  err = true;
	}
      else
	{
	  k_console_printf("Invalid first address parameter "
			   "(hexadecimal value required).\n");
	  err = true;
	}
    }
  else
    addr1 = antox(cmd, i);

  cmd += i;
  while (isblank(*cmd))
    cmd++;

  if ((cmd[0] == '0') && ((cmd[1] == 'x') || (cmd[1] == 'X')))
    j = 2;
  else
    j = 0;
  for (i = j; isxdigit(cmd[i]); i++)
    ;
  if ((!((cmd[i] == '\0') || (isblank(cmd[i])))) || (i == 0))
    {
      if (((j == 0) && (i == 0)) ||
	  ((j == 2) && (i == 2)))
	{
	  k_console_printf("Second address parameter is missing.\n");
	  err = true;
	}
      else
	{
	  k_console_printf("Invalid second address parameter "
			   "(hexadecimal value required).\n");
	  err = true;
	}
    }
  else
    addr2 = antox(cmd, i);

  if (err == false)
    {
      if (addr2 >= addr1)
	k_hexdump((void *)addr1, addr2 - addr1 + 1);
      else
	k_hexdump((void *)addr2, addr1 - addr2 + 1);
    }
}

/* Dump ASCII table */
static void	shell_ascii(char	*cmd)
{
  int		c;
  int		i;
  int		title_len;
  const unsigned char	col_num =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	col_char =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);
  _t_alignment	align;
  char		buf[15][2][6];
  _t_bool	separators[CONSOLE_X - 5];

  align = left;
  while (isblank(*cmd))
    cmd++;
  for (i = 0; i < CONSOLE_X - 5; i++)
    separators[i] = false;
  if (!strcmp(cmd, "oct") || !strcmp(cmd, "dec") || !strcmp(cmd, ""))
    {
      for (i = 1; i < CONSOLE_X - 5; i += 6)
	{
	  separators[i] = true;
	  separators[i + 4] = true;
	}
      if (!strcmp(cmd, "oct"))
	title_len = k_print_title_window("ASCII table (Octal)");
      else
	title_len = k_print_title_window("ASCII table (Decimal)");
      k_print_up_border_window(title_len, separators);
      for (c = 0; c < 256; )
	{
	  for (i = 0; i < 12; c++, i++)
	    {
	      if (c < 256)
		{
		  if (!strcmp(cmd, "oct"))
		    k_snprintf(buf[i][0], 3, "%0.3o", c);
		  else
		    k_snprintf(buf[i][0], 3, "%0.3d", c);
		  if (c == 8 || c == 9 || c == 10 || c == 13)
		    k_snprintf(buf[i][1], 1, " ");
		  else
		    k_snprintf(buf[i][1], 1, "%c", c);
		}
	      else
		{
		  k_snprintf(buf[i][0], 3, "");
		  k_snprintf(buf[i][1], 1, "");
		}
	    }
	  k_print_datas_in_window(separators,
				  "", col_num, align,
				  buf[0][0], col_num, align,
				  buf[0][1], col_char, align,
				  buf[1][0], col_num, align,
				  buf[1][1], col_char, align,
				  buf[2][0], col_num, align,
				  buf[2][1], col_char, align,
				  buf[3][0], col_num, align,
				  buf[3][1], col_char, align,
				  buf[4][0], col_num, align,
				  buf[4][1], col_char, align,
				  buf[5][0], col_num, align,
				  buf[5][1], col_char, align,
				  buf[6][0], col_num, align,
				  buf[6][1], col_char, align,
				  buf[7][0], col_num, align,
				  buf[7][1], col_char, align,
				  buf[8][0], col_num, align,
				  buf[8][1], col_char, align,
				  buf[9][0], col_num, align,
				  buf[9][1], col_char, align,
				  buf[10][0], col_num, align,
				  buf[10][1], col_char, align,
				  buf[11][0], col_num, align,
				  buf[11][1], col_char, align,
				  "", col_num, align);
	}
      k_print_down_border_window(separators);
    }
  else if (!strcmp(cmd, "hex"))
    {
      for (i = 2; i < CONSOLE_X - 5; i += 5)
	{
	  separators[i] = true;
	  separators[i + 2] = true;
	}
      title_len = k_print_title_window("ASCII table (Hexadecimal)");
      k_print_up_border_window(title_len, separators);
      for (c = 0; c < 256; )
	{
	  for (i = 0; i < 15; c++, i++)
	    {
	      if (c < 256)
		{
		  k_snprintf(buf[i][0], 2, "%0.2x", c);
		  if (c == 8 || c == 9 || c == 10 || c == 13)
		    k_snprintf(buf[i][1], 1, " ");
		  else
		    k_snprintf(buf[i][1], 1, "%c", c);
		}
	      else
		{
		  k_snprintf(buf[i][0], 3, "");
		  k_snprintf(buf[i][1], 1, "");
		}
	    }
	  k_print_datas_in_window(separators,
				  buf[0][0], col_num, align,
				  buf[0][1], col_char, align,
				  buf[1][0], col_num, align,
				  buf[1][1], col_char, align,
				  buf[2][0], col_num, align,
				  buf[2][1], col_char, align,
				  buf[3][0], col_num, align,
				  buf[3][1], col_char, align,
				  buf[4][0], col_num, align,
				  buf[4][1], col_char, align,
				  buf[5][0], col_num, align,
				  buf[5][1], col_char, align,
				  buf[6][0], col_num, align,
				  buf[6][1], col_char, align,
				  buf[7][0], col_num, align,
				  buf[7][1], col_char, align,
				  buf[8][0], col_num, align,
				  buf[8][1], col_char, align,
				  buf[9][0], col_num, align,
				  buf[9][1], col_char, align,
				  buf[10][0], col_num, align,
				  buf[10][1], col_char, align,
				  buf[11][0], col_num, align,
				  buf[11][1], col_char, align,
				  buf[12][0], col_num, align,
				  buf[12][1], col_char, align,
				  buf[13][0], col_num, align,
				  buf[13][1], col_char, align,
				  buf[14][0], col_num, align,
				  buf[14][1], col_char, align,
				  "", col_num, align);

	}
      k_print_down_border_window(separators);
    }
  else
    {
      k_console_printf("%s: Option not recognized. Use \"hex\" or \"dec\".\n"
		       "No option is equal to \"dec\" option.\n");
    }
}

/*
 * Display number of free physical pages
 */
void			shell_freepages(char	*cmd)
{
  k_display_free_pages();
}

/*
 * Demonstration Shell
 */
void			k_shell()
{
  unsigned char		buf[READLINE_SIZE + 1];
  unsigned int		len, cmd_len;
  int			i, j;
  const unsigned char	prompt_color1 =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	prompt_color2 =
    MK_BRIGHT_COLOR(COLOR_CYAN, COLOR_BLUE);

  k_set_attr(MK_COLOR(COLOR_WHITE, COLOR_BLUE));
  while (1)
  {
    k_console_printf("%kK%k> ", prompt_color1, prompt_color2);
    k_unhide_cursor();
    len = k_get_string(buf, READLINE_SIZE);
    k_hide_cursor();
    buf[len] = '\0';

    if (DUPLICATE_CONSOLE_PRINTF_ON_BOCHS)
      k_bochs_printf("%s\n", buf);

    for (i = 0; (buf[i] != '\0') &&
	   ((buf[i] == ' ') || (buf[i] == '\t')); i++)
      ;
    for (cmd_len = 0; (buf[i + cmd_len] != '\0') &&
	   (buf[i + cmd_len] != '\t') && (buf[i + cmd_len] != ' '); cmd_len++)
      ;
    for (j = 0; _commands[j]._function; j++)
      if (!strncmp((char *)(buf + i), _commands[j]._command,
		   MAX(cmd_len, strlen(_commands[j]._command))))
	{
	  _commands[j]._function((char *)(buf + i +
					  strlen(_commands[j]._command)));
	  break ;
	}
    if (!_commands[j]._function)
      {
	if (strcmp((char *)(buf + i), "") != 0)
	  {
	    k_console_printf("%k%s", MK_BRIGHT_COLOR(COLOR_BLACK, COLOR_BLUE),
			     buf + i);
	    k_console_printf(": command not found,"
			     "type \"help\" to get some.\n");
	  }
      }
  }
}
