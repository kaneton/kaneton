#include <writers.h>
#include <console.h>
#include <bochs.h>
#include <assert.h>
/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */


int		k_console_writer(unsigned char	c,
				 void		*p)
{
  if (p) ;
  k_print_char(c);
  return 0;
}

int		k_str_writer(unsigned char	c,
			     void		*p)
{
  K_ASSERT_FATAL(p != NULL);
  ((unsigned char *)(((_t_str_w_info *)p)->_str))[((_t_str_w_info *)p)->_pos] =
    c;
  return 0;
}

int		k_bochs_writer(unsigned char	c,
			       void		*p)
{
  if (p) ;
  k_bochs_print_char(c);
  return 0;
}

int		k_null_writer(unsigned char	c,
			      void		*p)
{
  if (p) ;
  if (c) ;
  return 0;
}
