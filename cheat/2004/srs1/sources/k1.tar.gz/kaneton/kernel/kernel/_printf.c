#include <printf.h>
#include <types.h>
#include <_printf.h>
#include <strings.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */


int	_k_print_hhd(signed char	arg_value,
		     _t_arg_infos	*infos)
{
  PRINT_NB_D(signed char)
}

int	_k_print_hd(short int		arg_value,
		    _t_arg_infos	*infos)
{
  PRINT_NB_D(short int)
}

int	_k_print_ld(long int		arg_value,
		    _t_arg_infos	*infos)
{
  PRINT_NB_D(long int)
}

int	_k_print_lld(long long int	arg_value,
		     _t_arg_infos	*infos)
{
  //  PRINT_NB_D(long long int)
  return 0;
}

int	_k_print_qd(long long int	arg_value,
		    _t_arg_infos	*infos)
{
  //  PRINT_NB_D(long long int)
  return 0;
}

int	_k_print_jd(intmax_t		arg_value,
		    _t_arg_infos	*infos)
{
  //  PRINT_NB_D(intmax_t)
  return 0;
}

int	_k_print_zd(ssize_t		arg_value,
		    _t_arg_infos	*infos)
{
  PRINT_NB_D(ssize_t)
}

int	_k_print_td(ptrdiff_t		arg_value,
		    _t_arg_infos	*infos)
{
  PRINT_NB_D(ptrdiff_t)
}

int	_k_print_d(int			arg_value,
		   _t_arg_infos		*infos)
{
  PRINT_NB_D(int)
}


int	_k_print_hhi(signed char	arg_value,
		     _t_arg_infos	*infos)
{
  PRINT_NB_D(signed char)
}

int	_k_print_hi(short int		arg_value,
		    _t_arg_infos	*infos)
{
  PRINT_NB_D(short int)
}

int	_k_print_li(long int		arg_value,
		    _t_arg_infos	*infos)
{
  PRINT_NB_D(long int)
}

int	_k_print_lli(long long int	arg_value,
		     _t_arg_infos	*infos)
{
  //  PRINT_NB_D(long long int)
  return 0;
}

int	_k_print_qi(long long int	arg_value,
		    _t_arg_infos	*infos)
{
  //  PRINT_NB_D(long long int)
  return 0;
}

int	_k_print_ji(intmax_t		arg_value,
		    _t_arg_infos	*infos)
{
  //  PRINT_NB_D(intmax_t)
  return 0;
}

int	_k_print_zi(ssize_t		arg_value,
		    _t_arg_infos	*infos)
{
  PRINT_NB_D(ssize_t)
}

int	_k_print_ti(ptrdiff_t		arg_value,
		    _t_arg_infos	*infos)
{
  PRINT_NB_D(ptrdiff_t)
}

int	_k_print_i(int			arg_value,
		   _t_arg_infos		*infos)
{
  PRINT_NB_D(int)
}


int	_k_print_hho(unsigned char		arg_value,
		     _t_arg_infos		*infos)
{
  PRINT_NB_O(unsigned char)
}

int	_k_print_ho(unsigned short int		arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_O(unsigned short int)
}

int	_k_print_lo(unsigned long int		arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_O(unsigned long int)
}

int	_k_print_llo(unsigned long long int	arg_value,
		     _t_arg_infos		*infos)
{
  PRINT_NB_O(unsigned long long int)
}

int	_k_print_qo(unsigned long long int	arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_O(unsigned long long int)
}

int	_k_print_jo(uintmax_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_O(uintmax_t)
}

int	_k_print_zo(size_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_O(size_t)
}

int	_k_print_to(ptrdiff_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_O(ptrdiff_t)
}

int	_k_print_o(unsigned int			arg_value,
		   _t_arg_infos			*infos)
{
  PRINT_NB_O(unsigned int)
}


int	_k_print_hhu(unsigned char		arg_value,
		     _t_arg_infos		*infos)
{
  PRINT_NB_U(unsigned char)
}

int	_k_print_hu(unsigned short int		arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_U(unsigned short int)
}

int	_k_print_lu(unsigned long int		arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_U(unsigned long int)
}

int	_k_print_llu(unsigned long long int	arg_value,
		     _t_arg_infos		*infos)
{
  //  PRINT_NB_U(unsigned long long int)
  return 0;
}

int	_k_print_qu(unsigned long long int	arg_value,
		    _t_arg_infos		*infos)
{
  //  PRINT_NB_U(unsigned long long int)
  return 0;
}

int	_k_print_ju(uintmax_t			arg_value,
		    _t_arg_infos		*infos)
{
  //  PRINT_NB_U(uintmax_t)
  return 0;
}

int	_k_print_zu(size_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_U(size_t)
}

int	_k_print_tu(ptrdiff_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_U(ptrdiff_t)
}

int	_k_print_u(unsigned int			arg_value,
		   _t_arg_infos			*infos)
{
  PRINT_NB_U(unsigned int)
}


int	_k_print_hhx(unsigned char		arg_value,
		     _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned char, 0)
}

int	_k_print_hx(unsigned short int		arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned short int, 0)
}

int	_k_print_lx(unsigned long int		arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned long int, 0)
}

int	_k_print_llx(unsigned long long int	arg_value,
		     _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned long long int, 0)
}

int	_k_print_qx(unsigned long long int	arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned long long int, 0)
}

int	_k_print_jx(uintmax_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(uintmax_t, 0)
}

int	_k_print_zx(size_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(size_t, 0)
}

int	_k_print_tx(ptrdiff_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(ptrdiff_t, 0)
}

int	_k_print_x(unsigned int			arg_value,
		   _t_arg_infos			*infos)
{
  PRINT_NB_X(unsigned int, 0)
}

int	_k_print_hhX(unsigned char		arg_value,
		     _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned char, 1)
}

int	_k_print_hX(unsigned short int		arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned short int, 1)
}

int	_k_print_lX(unsigned long int		arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned long int, 1)
}

int	_k_print_llX(unsigned long long int	arg_value,
		     _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned long long int, 1)
}

int	_k_print_qX(unsigned long long int	arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(unsigned long long int, 1)
}

int	_k_print_jX(uintmax_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(uintmax_t, 1)
}

int	_k_print_zX(size_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(size_t, 1)
}

int	_k_print_tX(ptrdiff_t			arg_value,
		    _t_arg_infos		*infos)
{
  PRINT_NB_X(ptrdiff_t, 1)
}

int	_k_print_X(unsigned int			arg_value,
		   _t_arg_infos			*infos)
{
  PRINT_NB_X(unsigned int, 1)
}


int	_k_print_Le(long double		arg_value,
		    _t_arg_infos	*infos)
{
  //  PRINT_NB_E(long double, 0)
  return 0;
}

int	_k_print_e(double		arg_value,
		   _t_arg_infos		*infos)
{
  //  PRINT_NB_E(double, 0)
  return 0;
}


int	_k_print_LE(long double		arg_value,
		    _t_arg_infos	*infos)
{
  //  PRINT_NB_E(long double, 1)
  return 0;
}

int	_k_print_E(double		arg_value,
		   _t_arg_infos		*infos)
{
  //  PRINT_NB_E(double, 1)
  return 0;
}


int	_k_print_Lf(long double		arg_value,
		    _t_arg_infos	*infos)
{
  //  PRINT_NB_F(long double, 0)
  return 0;
}

int	_k_print_f(double		arg_value,
		   _t_arg_infos		*infos)
{
  //  PRINT_NB_F(double, 0)
  return 0;
}


int	_k_print_LF(long double		arg_value,
		    _t_arg_infos	*infos)
{
  //  PRINT_NB_F(long double, 1)
  return 0;
}

int	_k_print_F(double		arg_value,
		   _t_arg_infos		*infos)
{
  //  PRINT_NB_F(double, 1)
  return 0;
}


int	_k_print_Lg(long double		arg_value,
		    _t_arg_infos	*infos)
{
  return 0;
}

int	_k_print_g(double		arg_value,
		   _t_arg_infos		*infos)
{
  return 0;
}


int	_k_print_LG(long double		arg_value,
		    _t_arg_infos	*infos)
{
  return 0;
}

int	_k_print_G(double		arg_value,
		   _t_arg_infos		*infos)
{
  return 0;
}


int	_k_print_La(long double		arg_value,
		    _t_arg_infos	*infos)
{
  return 0;
}

int	_k_print_a(double		arg_value,
		   _t_arg_infos		*infos)
{
  return 0;
}


int	_k_print_LA(long double		arg_value,
		    _t_arg_infos	*infos)
{
  return 0;
}

int	_k_print_A(double		arg_value,
		   _t_arg_infos		*infos)
{
  return 0;
}


int	_k_print_lc(wint_t		arg_value,
		    _t_arg_infos	*infos)
{
  return 0;
}

int	_k_print_c(int			arg_value,
		   _t_arg_infos		*infos)
{
  return _k_print_char((unsigned char)arg_value);
}


int	_k_print_ls(const wchar_t	*arg_value,
		    _t_arg_infos	*infos)
{
  return 0;
}

int	_k_print_s(const char		*arg_value,
		   _t_arg_infos		*infos)
{
  size_t	i;
  size_t	nb_chars_to_write;
  size_t	nb_chars_for_min_len;

  if (infos->_precision_specified &&
      (infos->_precision_to_use < strlen(arg_value)))
    nb_chars_to_write = infos->_precision_to_use;
  else
    nb_chars_to_write = strlen(arg_value);
  nb_chars_for_min_len = 0;
  if (infos->_min_len_to_use > nb_chars_to_write)
    nb_chars_for_min_len = infos->_min_len_to_use - nb_chars_to_write;

  if (!infos->_attrs._minus)
    for (i = 0; i < nb_chars_for_min_len; i++)
      _k_print_char(' ');

  for (i = 0; i < nb_chars_to_write; i++)
    _k_print_char(arg_value[i]);

  if (infos->_attrs._minus)
    for (i = 0; i < nb_chars_for_min_len; i++)
      _k_print_char(' ');
  return 0;
}


int	_k_print_C(wint_t		arg_value,
		   _t_arg_infos		*infos)
{
  return 0;
}


int	_k_print_S(const wchar_t	*arg_value,
		   _t_arg_infos		*infos)
{
  return 0;
}


int	_k_print_p(void			*arg_value,
		   _t_arg_infos		*infos)
{
  return 0;
}
