#ifndef _I8259_H_
#define _I8259_H_

/*
 * includes
 */


/*
 * defines
 */
#define PIC_MASTER	0x20
#define PIC_SLAVE	0xa0

#define ICW1_M		0x11
#define ICW1_S		0x11

#define ICW2_M		0x20
#define ICW2_S		0x28

#define ICW3_M		0x4
#define ICW3_S		0x2

#define ICW4_M		0x1
#define ICW4_S		0x1

#define OCW1_M		0xf9
#define OCW1_S		0xff

/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */
void		k_init_i8259(void);
/*
void		k_i8259_enable_irq_line(unsigned char	irq);
void		k_i8259_disable_irq_line(unsigned char	irq);
*/
#endif
