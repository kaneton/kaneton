#ifndef _MM_H
#define _MM_H

/*
 * includes
 */
#include <multiboot.h>
#include <types.h>
#include <cycle_dlist.h>
#include <pages.h>

/*
 * defines
 */


/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */
void		k_init_physical_memory(_t_multiboot_info	*mbi);
void		k_mark_existing_pages(_t_phys_addr	base,
				      _t_phys_addr	top,
				      _t_page_type	type);
_t_page_descriptor	*k_get_page_descriptor_at(_t_phys_addr	addr);

int		k_page_alloc_at(_t_phys_addr	addr);
_t_phys_addr	k_page_alloc();
int		k_page_free(_t_phys_addr	addr);

void		k_init_virtual_memory();

/*
void		k_dump_page(_t_cycle_dlist	*node);
void		k_dump_free_pages();
void		k_dump_used_pages();
*/

void		k_display_free_pages();

void		k_check_if_page_alloc_required_for_history();
void		k_init_first_statics_phys_addr(_t_multiboot_info	*mbi);

#endif
