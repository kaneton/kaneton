#ifndef _PAGING_H_
#define _PAGING_H_

/*
 * includes
 */
#include <types.h>
#include <pages.h>

/*
 * defines
 */
#define K_MAP_PERM_NO		0
#define K_MAP_PERM_READ		1
#define K_MAP_PERM_WRITE	2

#define K_PD_INDEX_IN_PD	1023

#define K_MIRROR_VADDR		(K_PD_INDEX_IN_PD << 22)
#define K_MIRROR_SIZE		(1 << 22)

#define K_PD_VADDR		K_MIRROR_VADDR + \
				(K_PAGE_SIZE * K_PD_INDEX_IN_PD)

#define CR0_PAGING_ENABLED_FLAG	(1 << 31)
#define CR0_WRITE_PROTECT_FLAG	(1 << 16)
#define CR0_USED_FLAGS		(CR0_PAGING_ENABLED_FLAG | \
				 CR0_WRITE_PROTECT_FLAG)

#define LINEAR_ADDR_TO_PAGE_DIRECTORY_INDEX(vaddr)	(vaddr >> 22)
#define LINEAR_ADDR_TO_PAGE_TABLE_INDEX(vaddr)		((vaddr >> 12) & 0x3ff)
#define LINEAR_ADDR_TO_PAGE_OFFSET(vaddr)		(vaddr & K_PAGE_MASK)

/*
 * structures / types
 */
typedef struct			_s_page_directory_entry
{
  unsigned int	_present : 1;
  unsigned int	_write : 1;
  unsigned int	_user : 1;
  unsigned int	_write_through : 1;
  unsigned int	_cache_disabled : 1;
  unsigned int	_accessed : 1;
  unsigned int	_zero : 1;
  unsigned int	_page_size : 1;
  unsigned int	_global_page : 1;
  unsigned int	_custom : 3;
  unsigned int	_page_table_phys_addr : 20;
} __attribute__ ((packed))	_t_page_directory_entry;

typedef struct			_s_page_table_entry
{
  unsigned int	_present : 1;
  unsigned int	_write : 1;
  unsigned int	_user : 1;
  unsigned int	_write_through : 1;
  unsigned int	_cache_disabled : 1;
  unsigned int	_accessed : 1;
  unsigned int	_dirty : 1;
  unsigned int	_zero : 1;
  unsigned int	_global_page : 1;
  unsigned int	_custom : 3;
  unsigned int	_physical_addr : 20;
} __attribute__ ((packed))	_t_page_table_entry;

typedef struct			_s_page_directory_base_register
{
  unsigned int	_zero1 : 3;
  unsigned int	_write_through : 1;
  unsigned int	_cache_disabled : 1;
  unsigned int	_zero2 : 7;
  unsigned int	_page_directory_phys_addr : 20;
} __attribute__ ((packed))	_t_page_directory_base_register;

/*
 * inline functions
 */


/*
 * prototypes
 */
int		k_init_paging();

int		k_map_page(_t_phys_addr		paddr,
			   _t_linear_addr	vaddr,
			   _t_bool		user,
			   int			perms);
int		k_unmap_page(_t_linear_addr	vaddr);

_t_phys_addr	k_get_phys_addr(_t_linear_addr	vaddr);
int		k_get_perms(_t_linear_addr	vaddr);
_t_bool		k_is_physical_mapped_addr(_t_linear_addr	vaddr);
_t_bool		k_is_phys_memory_full();

#endif
