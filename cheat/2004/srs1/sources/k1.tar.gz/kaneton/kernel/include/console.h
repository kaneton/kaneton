#ifndef _CONSOLE_H
#define _CONSOLE_H

/*
 * includes
 */
#include <types.h>
#include <stdarg.h>
#include <multiboot.h>

/*
 * defines
 */

#define LIMITED_HISTORY			0
#define MAX_HISTORY_PAGES		10

#define CONSOLE_VIDEO_ADDR		0xb8000
#define CONSOLE_VIDEO_LIMIT		0xb8fa0
#define CONSOLE_SIZE			0xfa0
#define CONSOLE_X			80
#define CONSOLE_Y			25
#define CONSOLE_VIDEO_MEMORY		CONSOLE_X * CONSOLE_Y
#define CONSOLE_BPP			2
#define VGA_OUTPUT_REGISTER		0x3cc
#define VGA_OUTPUT_READ_REGISTER	0x3cc

#define VGA_CRT_INDEX_REGISTER		0x03d4
#define VGA_CRT_DATA_REGISTER		0x03d5

#define COLOR_BLACK	0x00
#define COLOR_BLUE	0x01
#define COLOR_GREEN	0x02
#define COLOR_CYAN	0x03
#define COLOR_RED	0x04
#define COLOR_MAGENTA	0x05
#define COLOR_YELLOW	0x06
#define COLOR_WHITE	0x07
#define ATTR_COLOR_BRIGHT	0x08
#define ATTR_COLOR_BLINK	0x80

#define MK_COLOR(fg, bg)			((bg << 4) + fg)
#define MK_BRIGHT_COLOR(fg, bg)			(MK_COLOR(fg, bg) | \
						 ATTR_COLOR_BRIGHT)
#define MK_BLINK_COLOR(fg, bg)			(MK_COLOR(fg, bg) | \
						 ATTR_COLOR_BLINK)
#define MK_BRIGHT_BLINK_COLOR(fg, bg)		(MK_COLOR(fg, bg) | \
						 ATTR_COLOR_BRIGHT | \
						 ATTR_COLOR_BLINK)
#define MK_BLINK_BRIGHT_COLOR(fg, bg)		(MK_BRIGHT_BLINK_COLOR(fg, bg))
#define MK_SPECIAL_COLOR(fg, bg, bright, blink)	(MKCOLOR(fg, bg) | \
						 (bright ? \
						  ATTR_COLOR_BRIGTH : \
						  0) | \
						 (blink ? \
						  ATTR_COLOR_BLINK : \
						  0))

#define PAGE_UP_N_DOWN_LINES		(CONSOLE_Y >> 1)

#define CONSOLE_TABULATION		8
#define CONSOLE_DEFAULT_CURSOR_STATUS	1
#define CONSOLE_DEFAULT_ATTR		(MK_COLOR(COLOR_WHITE, COLOR_BLUE))

#define CONSOLE_HEXADECIMAL_BASE_HIGH	"0123456789ABCDEF"
#define CONSOLE_HEXADECIMAL_BASE_LOW	"0123456789abcdef"
#define CONSOLE_DECIMAL_BASE		"0123456789"
#define CONSOLE_OCTAL_BASE		"01234567"
#define CONSOLE_BINARY_BASE		"01"

#define CONSOLE_CURSOR_MASK		0x1

/*
 * structures / types
 */
typedef struct _s_console
{
  unsigned short	_crt_addr_register;
  unsigned short	_crt_data_register;
  unsigned short	*_vga;
  unsigned char		_attr;
  unsigned short	_cursor;
}	_t_console;

typedef enum _e_alignment
{
  left = 0,
  right
}	_t_alignment;

/*
 * inline functions
 */


/*
 * prototypes
 */
void	k_init_console();
void	k_hide_cursor();
void	k_unhide_cursor();
void	k_print_string(const unsigned char	*string);
void	k_print_number_hex(const unsigned int	number);
void	k_print_number_hex_0pad(const unsigned int	number,
				const char		nbdigit);
void	k_print_number(const int	number);
void	k_print_char(const unsigned char	c);
void	k_panic(const char	*message);
void	k_clrscr();
void	k_set_attr(const char	attr);
char	k_get_attr();

int	k_print_initializing(const char	*message);
void	k_print_initialization_result(const _t_bool	ok);
void	k_print_up_border_info(const int	limit_pos,
			       const int	title_end);
void	k_print_info(const char	*info,
		     const int	limit_pos,
		     const char	*data);
void	k_print_down_border_info(const int	limit_pos);

int	k_print_title_window(const char	*message);
void	k_print_up_border_window(const int	title_len,
				 const _t_bool	separators[CONSOLE_X - 5]);
void	k_print_datas_in_window(const _t_bool	separators[CONSOLE_X - 5],
				...);
void	k_print_separator(const _t_bool	up_separators[CONSOLE_X - 5],
			  const _t_bool	down_separators[CONSOLE_X - 5]);
void	k_print_down_border_window(const _t_bool	separators[CONSOLE_X -
								   5]);

void	k_page_up();
void	k_page_down();
void	k_exit_history();

void	k_set_history_dynamic();
void	k_set_physical_history();

void	k_append_actual_screen_to_history();

#endif
