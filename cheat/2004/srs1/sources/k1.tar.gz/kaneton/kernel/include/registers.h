#ifndef _REGISTERS_H_
#define _REGISTERS_H_

/*
 * includes
 */


/*
 * defines
 */


/*
 * structures / types
 */
typedef struct _s_registers
{
  unsigned int		_dr7;
  unsigned int		_dr6;
  unsigned int		_dr3;
  unsigned int		_dr2;
  unsigned int		_dr1;
  unsigned int		_dr0;
  unsigned int		_cr4;
  unsigned int		_cr3;
  unsigned int		_cr2;
  unsigned int		_cr0;
  unsigned int		_flags;
  unsigned short	_ss, pad1;
  unsigned short	_gs, pad2;
  unsigned short	_fs, pad3;
  unsigned short	_es, pad4;
  unsigned short	_ds, pad5;
  unsigned short	_cs, pad6;
  unsigned int		_edx;
  unsigned int		_ecx;
  unsigned int		_ebx;
  unsigned int		_eax;
  unsigned int		_esi;
  unsigned int		_edi;
  unsigned int		_ebp;
  unsigned int		_esp;
} __attribute__ ((packed))	_t_registers;

/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
