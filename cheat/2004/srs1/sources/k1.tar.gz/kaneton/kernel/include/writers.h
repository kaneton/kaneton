#ifndef _WRITERS_H_
#define _WRITERS_H_

/*
 * includes
 */
#include <types.h>

/*
 * defines
 */
#define K_WRITER_ERR	-1

/*
 * structures / types
 */
typedef int	(*_t_writer)(unsigned char, void *);
typedef struct _s_str_w_info
{
  char			*_str;
  size_t		_pos;
}	_t_str_w_info;

/*
 * inline functions
 */


/*
 * prototypes
 */
int		k_console_writer(unsigned char	c,
				 void		*p);
int		k_str_writer(unsigned char	c,
			     void		*p);
int		k_bochs_writer(unsigned char	c,
			       void		*p);
int		k_null_writer(unsigned char	c,
			      void		*p);

#endif
