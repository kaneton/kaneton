#ifndef _LIMITS_H_
#define _LIMITS_H_

/*
 * includes
 */

/*
 * defines
 */
#define SCHAR_MIN	(-128)
#define SCHAR_MAX	127
#define UCHAR_MAX	255
#define SHRT_MIN	(-32768)
#define SHRT_MAX	32767
#define USHRT_MAX	65535
#define SINT_MIN	(-SINT_MAX - 1)
#define SINT_MAX	2147483647
#define UINT_MAX	4294967295U
#define SLONG_MAX	2147483647L
#define SLONG_MIN	(-SLONG_MAX - 1L)
#define ULONG_MAX	4294967295UL
#define SLLONG_MAX	9223372036854775807LL
#define SLLONG_MIN	(-SLLONG_MAX - 1LL)
#define ULLONG_MAX	18446744073709551615ULL

#define SIZE_T_MAX	ULONG_MAX
#define SINT_MIN_STR	"-2147483648"
/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
