#ifndef _SEGMENT_H_
#define _SEGMENT_H_

/*
 * includes
 */


/*
 * defines
 */
#define BUILD_SEGMENT_REG_VALUE(desc_privilege, in_ldt, seg_index)	\
((((desc_privilege) & 0x3) << 0) | (((in_ldt) ? 1 : 0) << 2) |		\
((seg_index) << 3))

#define SEG_MIN_BASE	0x0
#define SEG_MAX_BASE	0xffffffff
#define SEG_MIN_LIMIT	0x0
#define SEG_MAX_LIMIT	0xfffff

#define SEG_TYPE_CODE	0xb
#define SEG_TYPE_DATA	0x3

#define SEG_DES_TYPE_CODE_DATA	1

#define SEG_DPL0	0
#define SEG_DPL1	1
#define SEG_DPL2	2
#define SEG_DPL3	3

#define SEG_PRESENT	1

#define SEG_CUSTOM	0

#define SEG_OP_SIZE_32		1

#define SEG_GRANULARITY_4K	1
#define SEG_GRANULARITY_BYTE	0

#define SEG_IN_GDT	0
#define SEG_IN_LDT	1

/*
 * structures / types
 */
typedef struct _s_segment_descriptor
{
  unsigned short	_limit_00_15;
  unsigned short	_base_paged_addr_00_15;
  unsigned char		_base_paged_addr_16_23;

  unsigned char		_segment_type : 4;
  unsigned char		_descriptor_type : 1;
  unsigned char		_dpl : 2;
  unsigned char		_present : 1;

  unsigned char		_limit_16_19 : 4;
  unsigned char		_custom : 1;
  unsigned char		_zero : 1;
  unsigned char		_op_size : 1;
  unsigned char		_granularity : 1;

  unsigned char		_base_paged_addr_24_31;
} __attribute__ ((packed, aligned (8)))	_t_segment_descriptor;

/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
