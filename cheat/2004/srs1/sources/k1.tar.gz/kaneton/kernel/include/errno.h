#ifndef _ERRNO_H_
#define _ERRNO_H_

/*
 * includes
 */


/*
 * defines
 */
#define K_NOERR		0
#define K_EINVAL	1
#define K_ENOMEM	2

/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
