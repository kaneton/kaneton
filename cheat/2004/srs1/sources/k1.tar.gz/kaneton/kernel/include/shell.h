#ifndef _SHELL_H
#define _SHELL_H

/*
 * includes
 */


/*
 * defines
 */
#define READLINE_SIZE	1024
#define MAX(a, b)	((a > b) ? a : b)
#define MIN(a, b)	((a < b) ? a : b)

/*
 * structures / types
 */
typedef void	(*_t_func)(char *);

typedef struct _s_cmds
{
  char		*_command;
  _t_func	_function;
}		_t_cmds;

typedef struct _s_cmd_help
{
  char		*_cmd;
  char		*_desc;
}		_t_cmd_help;
/*
 * inline functions
 */


/*
 * prototypes
 */
void	k_shell();

#endif
