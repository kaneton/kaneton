#ifndef _DEBUGGER_H
#define _DEBUGGER_H

/*
 * includes
 */
#include <elf32.h>
#include <multiboot.h>
#include <types.h>

/*
 * defines
 */
//#define DUMP_STACK_TRACE	0

/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */
void		k_init_debugger(_t_multiboot_info	*mbi);
_t_elf32_sym	*k_find_symbol_at(unsigned int	addr);
unsigned char	*k_resolv_symbol_name(_t_elf32_sym	*sym);
void		k_dump_stack_trace();
void		k_hexdump(const void	*mem,
			  size_t	len);
#endif
