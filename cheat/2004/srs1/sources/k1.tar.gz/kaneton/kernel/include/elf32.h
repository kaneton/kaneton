#ifndef _ELF32_H_
#define _ELF32_H_

/*
 * includes
 */
#include <multiboot.h>
#include <console.h>

/*
 * defines
 */
//#define DUMP_SECTION_HEADERS	0
/*
 * Warning : this dump take many time to print
 */
//#define DUMP_SYMBOL_TABLE	0

/*
 * structures / types
 */
typedef struct
{
  unsigned int		_name;
  unsigned int		_type;
  unsigned int		_flags;
  unsigned int		_addr;
  unsigned int		_offset;
  unsigned int		_size;
  unsigned int		_link;
  unsigned int		_info;
  unsigned int		_addralign;
  unsigned int		_entsize;
} __attribute__ ((packed))	_t_elf32_shdr;

typedef struct
{
  unsigned int		_name;
  unsigned int		_value;
  unsigned int		_size;
  unsigned char		_info;
  unsigned char		_other;
  unsigned short	_shndx;
} __attribute__ ((packed))	_t_elf32_sym;

typedef struct
{
  _t_elf32_shdr		*_shdrs;
  unsigned int		_shdrs_num;
  
  _t_elf32_shdr		*_sh_strtbl_shdr;
  unsigned char		*_sh_strtbl;

  _t_elf32_shdr		*_symtbl_shdr;
  _t_elf32_sym		*_symtbl;
  unsigned int		_symtbl_size;
  
  _t_elf32_shdr		*_strtbl_shdr;
  unsigned char		*_strtbl;
  
  _t_elf32_shdr		*_code_shdr;
}				_t_elf32_infos;

/*
 * inline functions
 */


/*
 * prototypes
 */
void		k_init_elf32();
void		k_init_first_elf32(_t_multiboot_info	*mbi);
_t_elf32_shdr	*k_get_elf32_shdr_with_s_name(char	*s_name);

_t_elf32_sym	*k_find_symbol_at(unsigned int	addr);
unsigned char	*k_resolv_symbol_name(_t_elf32_sym	*sym);
char		k_is_in_code_section(unsigned int	value);

#endif
