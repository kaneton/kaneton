#ifndef _PRINTF_H_
#define _PRINTF_H_

/*
 * includes
 */
#include <types.h>

/*
 * defines
 */
#define K_PRINTF_ERR		-1
#define K_PRINTF_END		-2
#define K_PRINTF_RESOLVED	-3
#define K_PRINTF_NOT_RESOLVED	-4

#define SEPARATOR		1
#define COMMA			','
#define SEPARATOR_CHAR		'.'
/*
 * structures / types
 */
typedef struct _s_arg_infos
{
  struct
  {
    unsigned int	_hh : 1;
    unsigned int	_ll : 1;
    unsigned int	_h : 1;
    unsigned int	_l : 1;
    unsigned int	_L : 1;
    unsigned int	_q : 1;
    unsigned int	_j : 1;
    unsigned int	_z : 1;
    unsigned int	_t : 1;
  }			_len_modifier;

  struct
  {
    unsigned int	_sharp : 1;
    unsigned int	_zero : 1;
    unsigned int	_minus : 1;
    unsigned int	_space : 1;
    unsigned int	_more : 1;
    unsigned int	_apostrophe : 1;
    unsigned int	_I : 1;
  }			_attrs;

  int			_min_len_to_use;
  unsigned int		_precision_specified : 1;
  int			_precision_to_use;

  int			_arg_to_use;
  unsigned int		_static_arg : 1;
}			_t_arg_infos;

/*
 * inline functions
 */


/*
 * prototypes
 */
ssize_t			k_console_printf(const char	*format,
					 ...);

ssize_t			k_snprintf(char			*buf,
				   size_t		len,
				   const char		*format,
				   ...);

ssize_t			k_sprintf(char			*buf,
				  const char		*format,
				  ...);

ssize_t			k_bochs_printf(const char	*format,
					 ...);

ssize_t			k_null_printf(const char	*format,
				      ...);

int			_k_print_char(unsigned char	c);


int	_k_print_hhd(signed char	arg_value,
		     _t_arg_infos	*infos);
int	_k_print_hd(short int		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_ld(long int		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_lld(long long int	arg_value,
		     _t_arg_infos	*infos);
int	_k_print_qd(long long int	arg_value,
		    _t_arg_infos	*infos);
int	_k_print_jd(intmax_t		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_zd(ssize_t		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_td(ptrdiff_t		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_d(int			arg_value,
		   _t_arg_infos		*infos);

int	_k_print_hhi(signed char	arg_value,
		     _t_arg_infos	*infos);
int	_k_print_hi(short int		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_li(long int		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_lli(long long int	arg_value,
		     _t_arg_infos	*infos);
int	_k_print_qi(long long int	arg_value,
		    _t_arg_infos	*infos);
int	_k_print_ji(intmax_t		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_zi(ssize_t		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_ti(ptrdiff_t		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_i(int			arg_value,
		   _t_arg_infos		*infos);

int	_k_print_hho(unsigned char		arg_value,
		     _t_arg_infos		*infos);
int	_k_print_ho(unsigned short int		arg_value,
		    _t_arg_infos		*infos);
int	_k_print_lo(unsigned long int		arg_value,
		    _t_arg_infos		*infos);
int	_k_print_llo(unsigned long long int	arg_value,
		     _t_arg_infos		*infos);
int	_k_print_qo(unsigned long long int	arg_value,
		    _t_arg_infos		*infos);
int	_k_print_jo(uintmax_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_zo(size_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_to(ptrdiff_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_o(unsigned int			arg_value,
		   _t_arg_infos			*infos);

int	_k_print_hhu(unsigned char		arg_value,
		     _t_arg_infos		*infos);
int	_k_print_hu(unsigned short int		arg_value,
		    _t_arg_infos		*infos);
int	_k_print_lu(unsigned long int		arg_value,
		    _t_arg_infos		*infos);
int	_k_print_llu(unsigned long long int	arg_value,
		     _t_arg_infos		*infos);
int	_k_print_qu(unsigned long long int	arg_value,
		    _t_arg_infos		*infos);
int	_k_print_ju(uintmax_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_zu(size_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_tu(ptrdiff_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_u(unsigned int			arg_value,
		   _t_arg_infos			*infos);

int	_k_print_hhx(unsigned char		arg_value,
		     _t_arg_infos		*infos);
int	_k_print_hx(unsigned short int		arg_value,
		    _t_arg_infos		*infos);
int	_k_print_lx(unsigned long int		arg_value,
		    _t_arg_infos		*infos);
int	_k_print_llx(unsigned long long int	arg_value,
		     _t_arg_infos		*infos);
int	_k_print_qx(unsigned long long int	arg_value,
		    _t_arg_infos		*infos);
int	_k_print_jx(uintmax_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_zx(size_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_tx(ptrdiff_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_x(unsigned int			arg_value,
		   _t_arg_infos			*infos);

int	_k_print_hhX(unsigned char		arg_value,
		     _t_arg_infos		*infos);
int	_k_print_hX(unsigned short int		arg_value,
		    _t_arg_infos		*infos);
int	_k_print_lX(unsigned long int		arg_value,
		    _t_arg_infos		*infos);
int	_k_print_llX(unsigned long long int	arg_value,
		     _t_arg_infos		*infos);
int	_k_print_qX(unsigned long long int	arg_value,
		    _t_arg_infos		*infos);
int	_k_print_jX(uintmax_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_zX(size_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_tX(ptrdiff_t			arg_value,
		    _t_arg_infos		*infos);
int	_k_print_X(unsigned int			arg_value,
		   _t_arg_infos			*infos);

int	_k_print_Le(long double		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_e(double		arg_value,
		   _t_arg_infos		*infos);

int	_k_print_LE(long double		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_E(double		arg_value,
		   _t_arg_infos		*infos);

int	_k_print_Lf(long double		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_f(double		arg_value,
		   _t_arg_infos		*infos);

int	_k_print_LF(long double		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_F(double		arg_value,
		   _t_arg_infos		*infos);

int	_k_print_Lg(long double		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_g(double		arg_value,
		   _t_arg_infos		*infos);

int	_k_print_LG(long double		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_G(double		arg_value,
		   _t_arg_infos		*infos);

int	_k_print_La(long double		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_a(double		arg_value,
		   _t_arg_infos		*infos);

int	_k_print_LA(long double		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_A(double		arg_value,
		   _t_arg_infos		*infos);

int	_k_print_lc(wint_t		arg_value,
		    _t_arg_infos	*infos);
int	_k_print_c(int			arg_value,
		   _t_arg_infos		*infos);

int	_k_print_ls(const wchar_t	*arg_value,
		    _t_arg_infos	*infos);
int	_k_print_s(const char		*arg_value,
		   _t_arg_infos		*infos);

int	_k_print_C(wint_t		arg_value,
		   _t_arg_infos		*infos);

int	_k_print_S(const wchar_t	*arg_value,
		   _t_arg_infos		*infos);

int	_k_print_p(void			*arg_value,
		   _t_arg_infos		*infos);

#endif
