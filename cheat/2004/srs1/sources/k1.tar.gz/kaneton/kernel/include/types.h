#ifndef _TYPES_H_
#define _TYPES_H_

/*
 * includes
 */


/*
 * defines
 */
#define NULL ((void*)0)

/*
 * structures / types
 */
typedef int			wint_t;
typedef char			wchar_t;

typedef long unsigned int	size_t;
typedef long signed int		ssize_t;
typedef long int		ptrdiff_t;

typedef signed long long int	intmax_t;
typedef unsigned long long int	uintmax_t;

typedef enum _e_bool
  {
    false = 0,
    true
  }				_t_bool;

typedef unsigned int		_t_phys_addr;
typedef unsigned int		_t_linear_addr;

/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
