#ifndef _IDT_ENTRY_H_
#define _IDT_ENTRY_H_

/*
 * includes
 */


/*
 * defines
 */
#define IDTE_TYPE_TRAP_GATE		0x5 /* for system calls */
#define IDTE_TYPE_INTERRUPT_GATE	0x6 /* for interruptions */
#define	IDTE_TYPE_TASK_GATE		0x7 /* for task switching */

#define IDTE_OP_SIZE_32	1

#define IDTE_DPL0	0
#define IDTE_DPL1	1
#define IDTE_DPL2	2
#define IDTE_DPL3	3

#define IDTE_PRESENT		1
#define IDTE_NOT_PRESENT	0

/*
 * structures / types
 */
typedef struct _s_idt_entry
{
  unsigned short	_offset_00_15;
  unsigned short	_segment;

  unsigned char		_reserved : 5;
  unsigned char		_flags : 3;
  unsigned char		_type : 3;
  unsigned char		_op_size : 1;
  unsigned char		_zero : 1;
  unsigned char		_dpl : 2;
  unsigned char		_present : 1;

  unsigned short	_offset_16_31;
} __attribute__ ((packed))	_t_idt_entry;

/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
