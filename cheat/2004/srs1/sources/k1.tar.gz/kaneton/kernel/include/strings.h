#ifndef _STRINGS_H_
#define _STRINGS_H_

/*
 * includes
 */
#include <types.h>

/*
 * defines
 */


/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */
size_t		strlen(const char	*str);
int		strcmp(const char	*str_1,
		       const char	*str_2);
char		*strncpy(char		*dst,
			 const char	*src,
			 size_t		len);
int		strncmp(const char	*str_1,
			const char	*str_2,
			size_t		len);
void		memcpy(void		*dst,
		       const void	*src,
		       size_t		size);
void		memset(void	*dst,
		       int	val,
		       size_t	size);
int		antoi(const char	*str,
		      size_t		size);
unsigned int	antox(const char	*str,
		      size_t		size);
size_t		antosize(const char	*str,
			 size_t		size);

#endif
