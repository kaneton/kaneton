#ifndef _BOCHS_H_
#define _BOCHS_H_

/*
 * includes
 */


/*
 * defines
 */
#define K_BOCHS_IOPORT				0xe9
#define DUPLICATE_CONSOLE_PRINTF_ON_BOCHS	1
#define PRINT_SPACE_FOR_NO_LEN_CHARS		1
#define PRINT_WINDOW_CHARS			0
/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */
void			k_init_bochs();
void			k_bochs_print_char(unsigned char	c);

#endif
