#ifndef _IO_H
#define _IO_H

/*
 * includes
 */


/*
 * defines
 */


/*
 * structures / types
 */


/*
 * inline functions
 */
inline static void		outb(unsigned short	port,
				     unsigned char	data)
{
  asm volatile ("outb %%al, %%dx"::"d" (port), "a" (data));
}

inline static void		outw(unsigned short	port,
				     unsigned int	data)
{
  asm volatile ("outw %%ax, %%dx"::"d" (port), "a" (data));
}

inline static void		outl(unsigned short	port,
				     unsigned long	data)
{
  asm volatile ("outl %%al, %%dx"::"d" (port), "a" (data));
}

inline static unsigned char	inb(unsigned short	port)
{
  unsigned char	data;

  asm volatile ("inb %%dx, %%al" : "=a" (data) : "d" (port));
  return (data);
}

inline static unsigned int	inw(unsigned short	port)
{
  unsigned int	data;

  asm volatile ("inw %%dx, %%ax" : "=a" (data) : "d" (port));
  return (data);
}

inline static unsigned long	inl(unsigned short	port)
{
  unsigned long	data;

  asm volatile ("inl %%dx, %%ax" : "=a" (data) : "d" (port));
  return (data);
}

/*
 * prototypes
 */


#endif
