#ifndef __PRINTF_H_
#define __PRINTF_H_

/*
 * includes
 */


/*
 * defines
 */
#define		PRINT_NB_D(arg_type)					\
  arg_type		tmp_value;					\
  int			nb_digits;					\
  int			nb_chars_to_write;				\
  int			nb_chars_for_precision;				\
  int			nb_chars_for_min_len;				\
  int			i, j, pos;					\
									\
  tmp_value = arg_value;						\
  nb_digits = 1;							\
  nb_chars_to_write = 0;						\
									\
  while ((tmp_value / 10) != 0)						\
    {									\
      tmp_value /= 10;							\
      nb_digits++;							\
    }									\
  if (arg_value == 0 && infos->_precision_specified &&			\
      (infos->_precision_to_use == 0))					\
    nb_digits = 0;							\
  nb_chars_to_write = nb_digits;					\
									\
  if ((arg_value < 0) || infos->_attrs._more || infos->_attrs._space)	\
    nb_chars_to_write++;						\
									\
  nb_chars_for_precision = 0;						\
  if (infos->_precision_specified && (infos->_precision_to_use >	\
				      nb_digits))			\
    nb_chars_for_precision = infos->_precision_to_use - nb_digits;	\
  nb_chars_to_write += nb_chars_for_precision;				\
									\
  if ((infos->_attrs._apostrophe) && (SEPARATOR))			\
    {									\
      if ((nb_chars_for_precision + nb_digits) % 3)			\
	nb_chars_to_write += ((nb_chars_for_precision + nb_digits) /	\
			      3);					\
      else								\
	if ((nb_chars_for_precision + nb_digits) >= 3)			\
	  nb_chars_to_write += (((nb_chars_for_precision + nb_digits)	\
				 / 3) - 1);				\
    }									\
									\
  nb_chars_for_min_len = 0;						\
  if (infos->_min_len_to_use > nb_chars_to_write)			\
    nb_chars_for_min_len = infos->_min_len_to_use - nb_chars_to_write;	\
									\
  if (!infos->_attrs._minus)						\
    if (!(infos->_attrs._zero && !infos->_precision_specified))		\
      for (i = 0; i < nb_chars_for_min_len; i++)			\
	_k_print_char(' ');						\
									\
  if (arg_value < 0)							\
    _k_print_char('-');							\
  else									\
    {									\
      if (infos->_attrs._space)						\
	_k_print_char(' ');						\
      else								\
	if (infos->_attrs._more)					\
	  _k_print_char('+');						\
    }									\
  if (!infos->_attrs._minus && infos->_attrs._zero &&			\
      !infos->_precision_specified)					\
    {									\
      if (infos->_attrs._apostrophe && SEPARATOR)			\
	{								\
	  pos = nb_chars_for_min_len + nb_digits;			\
	  if (nb_digits % 3)						\
	    pos += nb_digits / 3;					\
	  else								\
	    if (nb_digits >= 3)						\
	      pos += nb_digits / 3 - 1;					\
	  for (i = 0; i < nb_chars_for_min_len; i++)			\
	    {								\
	      if (!(pos % 4))						\
		{							\
		  if (i == 0)						\
		    _k_print_char(' ');					\
		  else							\
		    _k_print_char(SEPARATOR_CHAR);			\
		}							\
	      else							\
		_k_print_char('0');					\
	      pos--;							\
	    }								\
	}								\
      else								\
	for (i = 0; i < nb_chars_for_min_len; i++)			\
	  _k_print_char('0');						\
    }									\
  if (infos->_precision_specified)					\
    {									\
      if (infos->_attrs._apostrophe && SEPARATOR)			\
	{								\
	  pos = nb_chars_for_precision + nb_digits;			\
	  if ((nb_chars_for_precision + nb_digits) % 3)			\
	    pos += ((nb_chars_for_precision + nb_digits) / 3);		\
	  else								\
	    if ((nb_chars_for_precision + nb_digits) >= 3)		\
	      pos += (((nb_chars_for_precision + nb_digits) / 3)	\
				    - 1);				\
	  for (i = 0; i < nb_chars_for_precision; )			\
	    {								\
	      if (!(pos % 4))						\
		_k_print_char(SEPARATOR_CHAR);				\
	      else							\
		{							\
		  _k_print_char('0');					\
		  i++;							\
		}							\
	      pos--;							\
	    }								\
	  if ((!(pos % 4)) && (pos > 0))				\
	    _k_print_char(SEPARATOR_CHAR);				\
	}								\
      else								\
	for (i = 0; i < nb_chars_for_precision; i++)			\
	  _k_print_char('0');						\
    }									\
  for (i = nb_digits; i > 0; i--)					\
    {									\
      tmp_value = arg_value;						\
      for (j = 1; j < i; j++)						\
	{								\
	  tmp_value /= 10;						\
	}								\
      tmp_value %= 10;							\
      if (tmp_value < 0)						\
	tmp_value = -tmp_value;						\
      _k_print_char('0' + tmp_value);					\
      if (infos->_attrs._apostrophe && SEPARATOR)			\
	{								\
	  if (((i % 3) == 1) && (i > 1))				\
	    _k_print_char(SEPARATOR_CHAR);				\
	}								\
    }									\
  if (infos->_attrs._minus)						\
    for (i = 0; i < nb_chars_for_min_len; i++)				\
      _k_print_char(' ');						\
  return 0;

#define		PRINT_NB_O(arg_type)					\
  arg_type		tmp_value;					\
  int			nb_digits;					\
  int			nb_chars_to_write;				\
  int			nb_chars_for_precision;				\
  int			nb_chars_for_min_len;				\
  int			i, j;						\
  char			prefix;						\
									\
  tmp_value = arg_value;						\
  nb_digits = 1;							\
  nb_chars_to_write = 0;						\
  prefix = 0;								\
									\
  while ((tmp_value / 8) != 0)						\
    {									\
      tmp_value /= 8;							\
      nb_digits++;							\
    }									\
  if (arg_value == 0 && infos->_precision_specified &&			\
      (infos->_precision_to_use == 0))					\
    nb_digits = 0;							\
  nb_chars_to_write = nb_digits;					\
									\
  nb_chars_for_precision = 0;						\
  if (infos->_precision_specified && (infos->_precision_to_use >	\
				      nb_digits))			\
    nb_chars_for_precision = infos->_precision_to_use - nb_digits;	\
  nb_chars_to_write += nb_chars_for_precision;				\
									\
  if (infos->_attrs._sharp &&						\
      ((nb_digits == 0) || (nb_chars_for_precision == 0)) &&		\
      (!((nb_digits == 1) && (arg_value == 0))))			\
    {									\
      nb_chars_to_write++;						\
      prefix = 1;							\
    }									\
									\
  nb_chars_for_min_len = 0;						\
  if (infos->_min_len_to_use > nb_chars_to_write)			\
    {									\
      nb_chars_for_min_len = infos->_min_len_to_use -			\
			     nb_chars_to_write;				\
      if (prefix == 1)							\
	if (!infos->_attrs._minus && infos->_attrs._zero &&		\
	    !infos->_precision_specified)				\
	  {								\
	    prefix = 0;							\
	    nb_chars_to_write--;					\
	    nb_chars_for_min_len++;					\
	  }								\
    }									\
									\
  if (!infos->_attrs._minus)						\
    if (!(infos->_attrs._zero && !infos->_precision_specified))		\
      for (i = 0; i < nb_chars_for_min_len; i++)			\
	_k_print_char(' ');						\
									\
  if (prefix == 1)							\
    _k_print_char('0');							\
									\
  if (!infos->_attrs._minus && infos->_attrs._zero &&			\
      !infos->_precision_specified)					\
    for (i = 0; i < nb_chars_for_min_len; i++)				\
      _k_print_char('0');						\
  if (infos->_precision_specified)					\
    for (i = 0; i < nb_chars_for_precision; i++)			\
      _k_print_char('0');						\
  for (i = nb_digits; i > 0; i--)					\
    {									\
      tmp_value = arg_value;						\
      for (j = 1; j < i; j++)						\
	{								\
	  tmp_value /= 8;						\
	}								\
      tmp_value %= 8;							\
      _k_print_char('0' + tmp_value);					\
    }									\
  if (infos->_attrs._minus)						\
    for (i = 0; i < nb_chars_for_min_len; i++)				\
      _k_print_char(' ');						\
  return 0;

#define		PRINT_NB_U(arg_type)					\
  arg_type		tmp_value;					\
  int			nb_digits;					\
  int			nb_chars_to_write;				\
  int			nb_chars_for_precision;				\
  int			nb_chars_for_min_len;				\
  int			i, j, pos;					\
									\
  tmp_value = arg_value;						\
  nb_digits = 1;							\
  nb_chars_to_write = 0;						\
									\
  while ((tmp_value / 10) != 0)						\
    {									\
      tmp_value /= 10;							\
      nb_digits++;							\
    }									\
  if (arg_value == 0 && infos->_precision_specified &&			\
      (infos->_precision_to_use == 0))					\
    nb_digits = 0;							\
  nb_chars_to_write = nb_digits;					\
									\
  nb_chars_for_precision = 0;						\
  if (infos->_precision_specified && (infos->_precision_to_use >	\
				      nb_digits))			\
    nb_chars_for_precision = infos->_precision_to_use - nb_digits;	\
  nb_chars_to_write += nb_chars_for_precision;				\
									\
  if ((infos->_attrs._apostrophe) && (SEPARATOR))			\
    {									\
      if ((nb_chars_for_precision + nb_digits) % 3)			\
	nb_chars_to_write += ((nb_chars_for_precision + nb_digits) /	\
			      3);					\
      else								\
	if ((nb_chars_for_precision + nb_digits) >= 3)			\
	  nb_chars_to_write += (((nb_chars_for_precision + nb_digits)	\
				 / 3) - 1);				\
    }									\
									\
  nb_chars_for_min_len = 0;						\
  if (infos->_min_len_to_use > nb_chars_to_write)			\
    nb_chars_for_min_len = infos->_min_len_to_use - nb_chars_to_write;	\
									\
  if (!infos->_attrs._minus)						\
    if (!(infos->_attrs._zero && !infos->_precision_specified))		\
      for (i = 0; i < nb_chars_for_min_len; i++)			\
	_k_print_char(' ');						\
									\
  if (!infos->_attrs._minus && infos->_attrs._zero &&			\
      !infos->_precision_specified)					\
    {									\
      if (infos->_attrs._apostrophe && SEPARATOR)			\
	{								\
	  pos = nb_chars_for_min_len + nb_digits;			\
	  if (nb_digits % 3)						\
	    pos += nb_digits / 3;					\
	  else								\
	    if (nb_digits >= 3)						\
	      pos += nb_digits / 3 - 1;					\
	  for (i = 0; i < nb_chars_for_min_len; i++)			\
	    {								\
	      if (!(pos % 4))						\
		{							\
		  if (i == 0)						\
		    _k_print_char(' ');					\
		  else							\
		    _k_print_char(SEPARATOR_CHAR);			\
		}							\
	      else							\
		_k_print_char('0');					\
	      pos--;							\
	    }								\
	}								\
      else								\
	for (i = 0; i < nb_chars_for_min_len; i++)			\
	  _k_print_char('0');						\
    }									\
  if (infos->_precision_specified)					\
    {									\
      if (infos->_attrs._apostrophe && SEPARATOR)			\
	{								\
	  pos = nb_chars_for_precision + nb_digits;			\
	  if ((nb_chars_for_precision + nb_digits) % 3)			\
	    pos += ((nb_chars_for_precision + nb_digits) / 3);		\
	  else								\
	    if ((nb_chars_for_precision + nb_digits) >= 3)		\
	      pos += (((nb_chars_for_precision + nb_digits) / 3)	\
				    - 1);				\
	  for (i = 0; i < nb_chars_for_precision; )			\
	    {								\
	      if (!(pos % 4))						\
		_k_print_char(SEPARATOR_CHAR);				\
	      else							\
		{							\
		  _k_print_char('0');					\
		  i++;							\
		}							\
	      pos--;							\
	    }								\
	  if ((!(pos % 4)) && (pos > 0))				\
	    _k_print_char(SEPARATOR_CHAR);				\
	}								\
      else								\
	for (i = 0; i < nb_chars_for_precision; i++)			\
	  _k_print_char('0');						\
    }									\
  for (i = nb_digits; i > 0; i--)					\
    {									\
      tmp_value = arg_value;						\
      for (j = 1; j < i; j++)						\
	{								\
	  tmp_value /= 10;						\
	}								\
      tmp_value %= 10;							\
      _k_print_char('0' + tmp_value);					\
      if (infos->_attrs._apostrophe && SEPARATOR)			\
	{								\
	  if (((i % 3) == 1) && (i > 1))				\
	    _k_print_char(SEPARATOR_CHAR);				\
	}								\
    }									\
  if (infos->_attrs._minus)						\
    for (i = 0; i < nb_chars_for_min_len; i++)				\
      _k_print_char(' ');						\
  return 0;

#define		PRINT_NB_X(arg_type, x_maj)				\
  arg_type		tmp_value;					\
  int			nb_digits;					\
  int			nb_chars_to_write;				\
  int			nb_chars_for_precision;				\
  int			nb_chars_for_min_len;				\
  int			i, j;						\
  char			prefix;						\
  static char		base_min[16] =					\
    {									\
      '0', '1', '2', '3', '4', '5', '6', '7',				\
      '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'				\
    };									\
  static char		base_maj[16] =					\
    {									\
      '0', '1', '2', '3', '4', '5', '6', '7',				\
      '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'				\
    };									\
  tmp_value = arg_value;						\
  nb_digits = 1;							\
  nb_chars_to_write = 0;						\
  prefix = 0;								\
									\
  while ((tmp_value / 16) != 0)						\
    {									\
      tmp_value /= 16;							\
      nb_digits++;							\
    }									\
  if (arg_value == 0 && infos->_precision_specified &&			\
      (infos->_precision_to_use == 0))					\
    nb_digits = 0;							\
  nb_chars_to_write = nb_digits;					\
									\
  nb_chars_for_precision = 0;						\
  if (infos->_precision_specified && (infos->_precision_to_use >	\
				      nb_digits))			\
    nb_chars_for_precision = infos->_precision_to_use - nb_digits;	\
  nb_chars_to_write += nb_chars_for_precision;				\
									\
  if (infos->_attrs._sharp && !(nb_digits == 0))			\
    {									\
      nb_chars_to_write += 2;						\
      prefix = 1;							\
    }									\
									\
  nb_chars_for_min_len = 0;						\
  if (infos->_min_len_to_use > nb_chars_to_write)			\
    {									\
      nb_chars_for_min_len = infos->_min_len_to_use -			\
			     nb_chars_to_write;				\
    }									\
									\
  if (!infos->_attrs._minus)						\
    if (!(infos->_attrs._zero && !infos->_precision_specified))		\
      for (i = 0; i < nb_chars_for_min_len; i++)			\
	_k_print_char(' ');						\
									\
  if (prefix == 1)							\
    {									\
      _k_print_char('0');						\
      if (x_maj)							\
	_k_print_char('X');						\
      else								\
	_k_print_char('x');						\
    }									\
									\
  if (!infos->_attrs._minus && infos->_attrs._zero &&			\
      !infos->_precision_specified)					\
    for (i = 0; i < nb_chars_for_min_len; i++)				\
      _k_print_char('0');						\
  if (infos->_precision_specified)					\
    for (i = 0; i < nb_chars_for_precision; i++)			\
      _k_print_char('0');						\
  for (i = nb_digits; i > 0; i--)					\
    {									\
      tmp_value = arg_value;						\
      for (j = 1; j < i; j++)						\
	{								\
	  tmp_value /= 16;						\
	}								\
      tmp_value %= 16;							\
      _k_print_char((x_maj ? base_maj : base_min)[tmp_value]);		\
    }									\
  if (infos->_attrs._minus)						\
    for (i = 0; i < nb_chars_for_min_len; i++)				\
      _k_print_char(' ');						\
  return 0;

#define		PRINT_NB_E(arg_type, e_maj)				\
  arg_type		tmp_value, digit_value;				\
  arg_type		round_value, round_pos;				\
  int			nb_digits;					\
  int			nb_chars_to_write;				\
  int			nb_chars_for_precision;				\
  int			nb_chars_for_min_len;				\
  int			i, j, pos;					\
  int			exp, tmp_exp;					\
									\
  tmp_value = arg_value;						\
  nb_digits = 0;							\
  nb_chars_to_write = 0;						\
									\
  while (!(((tmp_value / 10.) < 1.) && ((tmp_value / 10.) > -1.)))	\
    {									\
      tmp_value /= 10.;							\
      nb_digits++;							\
    }									\
  exp = nb_digits;							\
  if (arg_value == 0.)							\
    exp = 0;								\
  else if ((arg_value < 1.) && (arg_value > -1.))			\
    {									\
      tmp_value = arg_value;						\
      nb_digits = 0;							\
      while ((tmp_value < 1.) && (tmp_value > -1.))			\
	{								\
	  nb_digits++;							\
	  tmp_value *= 10.;						\
	}								\
      exp = -nb_digits;							\
    }									\
									\
  nb_chars_to_write = 1;						\
									\
  if ((infos->_precision_specified &&					\
       (infos->_precision_to_use > 0)) ||				\
      (!infos->_precision_specified) ||					\
      (infos->_attrs._sharp))						\
    nb_chars_to_write++;						\
									\
  if ((arg_value < 0.) || infos->_attrs._more || infos->_attrs._space)	\
    nb_chars_to_write++;						\
									\
  nb_chars_for_precision = infos->_precision_specified ?		\
			   infos->_precision_to_use :			\
			   6;						\
  nb_chars_to_write += nb_chars_for_precision;				\
									\
  round_value = 0.;							\
  round_pos = 1.;							\
  for (i = 0; i <= nb_chars_for_precision; i++)				\
    {									\
      digit_value = -1.;						\
      if (tmp_value < 0.)						\
	{								\
	  if (tmp_value > -1.)						\
	    digit_value = 0.;						\
	  else if (tmp_value > -2.)					\
	    digit_value = 1.;						\
	  else if (tmp_value > -3.)					\
	    digit_value = 2.;						\
	  else if (tmp_value > -4.)					\
	    digit_value = 3.;						\
	  else if (tmp_value > -5.)					\
	    digit_value = 4.;						\
	  else if (tmp_value > -6.)					\
	    digit_value = 5.;						\
	  else if (tmp_value > -7.)					\
	    digit_value = 6.;						\
	  else if (tmp_value > -8.)					\
	    digit_value = 7.;						\
	  else if (tmp_value > -9.)					\
	    digit_value = 8.;						\
	  else if (tmp_value > -10.)					\
	    digit_value = 9.;						\
	}								\
      else								\
	{								\
	  if (tmp_value < 1.)						\
	    digit_value = 0.;						\
	  else if (tmp_value < 2.)					\
	    digit_value = 1.;						\
	  else if (tmp_value < 3.)					\
	    digit_value = 2.;						\
	  else if (tmp_value < 4.)					\
	    digit_value = 3.;						\
	  else if (tmp_value < 5.)					\
	    digit_value = 4.;						\
	  else if (tmp_value < 6.)					\
	    digit_value = 5.;						\
	  else if (tmp_value < 7.)					\
	    digit_value = 6.;						\
	  else if (tmp_value < 8.)					\
	    digit_value = 7.;						\
	  else if (tmp_value < 9.)					\
	    digit_value = 8.;						\
	  else if (tmp_value < 10.)					\
	    digit_value = 9.;						\
	}								\
      if (arg_value < 0.)						\
	{								\
	  tmp_value += digit_value;					\
	  round_value -= digit_value * round_pos;			\
	  if (i == nb_chars_for_precision)				\
	    {								\
	      if (tmp_value * 10. <= -5.)				\
		round_value -= round_pos + round_pos / 2.;		\
	      else							\
		round_value -= round_pos / 2.;				\
	    }								\
	}								\
      else								\
	{								\
	  tmp_value -= digit_value;					\
	  round_value += digit_value * round_pos;			\
	  if (i == nb_chars_for_precision)				\
	    {								\
	      if (tmp_value * 10. >= 5.)				\
		round_value += round_pos + round_pos / 2.;		\
	      else							\
		round_value += round_pos / 2.;				\
	    }								\
	}								\
      tmp_value *= 10.;							\
      round_pos /= 10.;							\
    }									\
									\
  if ((round_value >= 10.) || (round_value <= -10.))			\
    {									\
      round_value /= 10.;						\
      exp++;								\
    }									\
  tmp_value = round_value;						\
									\
  if ((infos->_attrs._apostrophe) && (SEPARATOR))			\
    {									\
      if (nb_chars_for_precision % 3)					\
	nb_chars_to_write += (nb_chars_for_precision / 3);		\
      else								\
	if (nb_chars_for_precision >= 3)				\
	  nb_chars_to_write += ((nb_chars_for_precision / 3) - 1);	\
    }									\
									\
  tmp_exp = exp;							\
  nb_digits = 0;							\
  while (tmp_exp != 0)							\
    {									\
      tmp_exp /= 10;							\
      nb_digits++;							\
    }									\
  if (infos->_attrs._apostrophe && SEPARATOR)				\
    if (nb_digits >= 4)							\
      nb_chars_to_write++;						\
  nb_chars_to_write += 2;						\
  nb_chars_to_write += ((nb_digits <= 2) ? 2 : nb_digits);		\
									\
  nb_chars_for_min_len = 0;						\
  if (infos->_min_len_to_use > nb_chars_to_write)			\
    nb_chars_for_min_len = infos->_min_len_to_use - nb_chars_to_write;	\
									\
  if (!infos->_attrs._minus)						\
    if (!infos->_attrs._zero)						\
      for (i = 0; i < nb_chars_for_min_len; i++)			\
	_k_print_char(' ');						\
									\
  if (arg_value < 0.)							\
    _k_print_char('-');							\
  else									\
    {									\
      if (infos->_attrs._space)						\
	_k_print_char(' ');						\
      else								\
	if (infos->_attrs._more)					\
	  _k_print_char('+');						\
    }									\
  if (!infos->_attrs._minus && infos->_attrs._zero)			\
    {									\
      if (infos->_attrs._apostrophe && SEPARATOR)			\
	{								\
	  pos = nb_chars_for_min_len + 1;				\
	  for (i = 0; i < nb_chars_for_min_len; i++)			\
	    {								\
	      if (!(pos % 4))						\
		{							\
		  if (i == 0)						\
		    _k_print_char(' ');					\
		  else							\
		    _k_print_char(SEPARATOR_CHAR);			\
		}							\
	      else							\
		_k_print_char('0');					\
	      pos--;							\
	    }								\
	}								\
      else								\
	for (i = 0; i < nb_chars_for_min_len; i++)			\
	  _k_print_char('0');						\
    }									\
									\
  for (i = 0; i <= nb_chars_for_precision; i++)				\
    {									\
      digit_value = -1.;						\
      if (tmp_value < 0.)						\
	{								\
	  if (tmp_value > -1.)						\
	    { digit_value = 0.; _k_print_char('0'); }			\
	  else if (tmp_value > -2.)					\
	    { digit_value = 1.; _k_print_char('1'); }			\
	  else if (tmp_value > -3.)					\
	    { digit_value = 2.; _k_print_char('2'); }			\
	  else if (tmp_value > -4.)					\
	    { digit_value = 3.; _k_print_char('3'); }			\
	  else if (tmp_value > -5.)					\
	    { digit_value = 4.; _k_print_char('4'); }			\
	  else if (tmp_value > -6.)					\
	    { digit_value = 5.; _k_print_char('5'); }			\
	  else if (tmp_value > -7.)					\
	    { digit_value = 6.; _k_print_char('6'); }			\
	  else if (tmp_value > -8.)					\
	    { digit_value = 7.; _k_print_char('7'); }			\
	  else if (tmp_value > -9.)					\
	    { digit_value = 8.; _k_print_char('8'); }			\
	  else if (tmp_value > -10.)					\
	    { digit_value = 9.; _k_print_char('9'); }			\
	}								\
      else								\
	{								\
	  if (tmp_value < 1.)						\
	    { digit_value = 0.; _k_print_char('0'); }			\
	  else if (tmp_value < 2.)					\
	    { digit_value = 1.; _k_print_char('1'); }			\
	  else if (tmp_value < 3.)					\
	    { digit_value = 2.; _k_print_char('2'); }			\
	  else if (tmp_value < 4.)					\
	    { digit_value = 3.; _k_print_char('3'); }			\
	  else if (tmp_value < 5.)					\
	    { digit_value = 4.; _k_print_char('4'); }			\
	  else if (tmp_value < 6.)					\
	    { digit_value = 5.; _k_print_char('5'); }			\
	  else if (tmp_value < 7.)					\
	    { digit_value = 6.; _k_print_char('6'); }			\
	  else if (tmp_value < 8.)					\
	    { digit_value = 7.; _k_print_char('7'); }			\
	  else if (tmp_value < 9.)					\
	    { digit_value = 8.; _k_print_char('8'); }			\
	  else if (tmp_value < 10.)					\
	    { digit_value = 9.; _k_print_char('9'); }			\
	}								\
									\
      if (!i &&								\
	  ((infos->_attrs._sharp) || (nb_chars_for_precision > 0)))	\
	_k_print_char(infos->_attrs._apostrophe ? COMMA : '.');		\
									\
      if (i && (!(i % 3)) && (i != nb_chars_for_precision) &&		\
	  infos->_attrs._apostrophe && SEPARATOR)			\
	_k_print_char(SEPARATOR_CHAR);					\
      if (tmp_value < 0.)						\
	tmp_value += digit_value;					\
      else								\
	tmp_value -= digit_value;					\
      tmp_value *= 10.;							\
    }									\
									\
  _k_print_char(e_maj ? 'E' : 'e');					\
  _k_print_char(exp >= 0 ? '+' : '-');					\
  if ((exp < 10) && (exp > -10))					\
    _k_print_char('0');							\
  if (exp == 0)								\
    _k_print_char('0');							\
									\
  for (i = nb_digits; i > 0; i--)					\
    {									\
      tmp_exp = exp;							\
      for (j = 1; j < i; j++)						\
	{								\
	  tmp_exp /= 10;						\
	}								\
      tmp_exp %= 10;							\
      if (tmp_exp < 0)							\
	tmp_exp = -tmp_exp;						\
      _k_print_char('0' + tmp_exp);					\
      if ((i == nb_digits) && (nb_digits == 4) &&			\
	  (infos->_attrs._apostrophe && SEPARATOR))			\
	_k_print_char(SEPARATOR_CHAR);					\
   }									\
									\
  if (infos->_attrs._minus)						\
    for (i = 0; i < nb_chars_for_min_len; i++)				\
      _k_print_char(' ');						\
  return 0;

#define		PRINT_NB_F(arg_type, f_maj)				\
  arg_type		tmp_value, digit_value;				\
  arg_type		round_value, round_pos;				\
  int			nb_digits;					\
  int			nb_chars_to_write;				\
  int			nb_chars_for_precision;				\
  int			nb_chars_for_min_len;				\
  int			i, pos;						\
									\
  nb_chars_to_write = 0;						\
  tmp_value = arg_value;						\
  nb_digits = 1;							\
  round_pos = 1.;							\
  while (!(((tmp_value / 10.) < 1.) && ((tmp_value / 10.) > -1.)))	\
    {									\
      tmp_value /= 10.;							\
      nb_digits++;							\
      round_pos *= 10.;							\
    }									\
									\
  if ((infos->_precision_specified &&					\
       (infos->_precision_to_use > 0)) ||				\
      (!infos->_precision_specified) ||					\
      (infos->_attrs._sharp))						\
    nb_chars_to_write++;						\
									\
  if ((arg_value < 0.) || infos->_attrs._more || infos->_attrs._space)	\
    nb_chars_to_write++;						\
									\
  nb_chars_for_precision = infos->_precision_specified ?		\
    infos->_precision_to_use : 6;					\
  nb_chars_to_write += nb_chars_for_precision;				\
									\
  round_value = 0.;							\
  for (i = 1; i <= nb_digits + nb_chars_for_precision; i++)		\
    {									\
      digit_value = -1.;						\
      if (tmp_value < 0.)						\
	{								\
	  if (tmp_value > -1.)						\
	    digit_value = 0.;						\
	  else if (tmp_value > -2.)					\
	    digit_value = 1.;						\
	  else if (tmp_value > -3.)					\
	    digit_value = 2.;						\
	  else if (tmp_value > -4.)					\
	    digit_value = 3.;						\
	  else if (tmp_value > -5.)					\
	    digit_value = 4.;						\
	  else if (tmp_value > -6.)					\
	    digit_value = 5.;						\
	  else if (tmp_value > -7.)					\
	    digit_value = 6.;						\
	  else if (tmp_value > -8.)					\
	    digit_value = 7.;						\
	  else if (tmp_value > -9.)					\
	    digit_value = 8.;						\
	  else if (tmp_value > -10.)					\
	    digit_value = 9.;						\
	}								\
      else								\
	{								\
	  if (tmp_value < 1.)						\
	    digit_value = 0.;						\
	  else if (tmp_value < 2.)					\
	    digit_value = 1.;						\
	  else if (tmp_value < 3.)					\
	    digit_value = 2.;						\
	  else if (tmp_value < 4.)					\
	    digit_value = 3.;						\
	  else if (tmp_value < 5.)					\
	    digit_value = 4.;						\
	  else if (tmp_value < 6.)					\
	    digit_value = 5.;						\
	  else if (tmp_value < 7.)					\
	    digit_value = 6.;						\
	  else if (tmp_value < 8.)					\
	    digit_value = 7.;						\
	  else if (tmp_value < 9.)					\
	    digit_value = 8.;						\
	  else if (tmp_value < 10.)					\
	    digit_value = 9.;						\
	}								\
      if (arg_value < 0.)						\
	{								\
	  tmp_value += digit_value;					\
	  round_value -= digit_value * round_pos;			\
	  if (i == nb_digits + nb_chars_for_precision)			\
	    {								\
	      if (tmp_value * 10. <= -5.)				\
		round_value -= round_pos + round_pos / 2.;		\
	      else							\
		round_value -= round_pos / 2.;				\
	    }								\
	}								\
      else								\
	{								\
	  tmp_value -= digit_value;					\
	  round_value += digit_value * round_pos;			\
	  if (i == nb_digits + nb_chars_for_precision)			\
	    {								\
	      if (tmp_value * 10. >= 5.)				\
		round_value += round_pos + round_pos / 2.;		\
	      else							\
		round_value += round_pos / 2.;				\
	    }								\
	}								\
      tmp_value *= 10.;							\
      round_pos /= 10.;							\
    }									\
									\
  tmp_value = round_value;						\
  nb_digits = 1;							\
  while (!(((tmp_value / 10.) < 1.) && ((tmp_value / 10.) > -1.)))	\
    {									\
      tmp_value /= 10.;							\
      nb_digits++;							\
    }									\
									\
  nb_chars_to_write += nb_digits;					\
  if ((infos->_attrs._apostrophe) && (SEPARATOR))			\
    {									\
      if (nb_chars_for_precision % 3)					\
	nb_chars_to_write += (nb_chars_for_precision / 3);		\
      else								\
	if (nb_chars_for_precision >= 3)				\
	  nb_chars_to_write += ((nb_chars_for_precision / 3) - 1);	\
      if (nb_digits % 3)						\
	nb_chars_to_write += (nb_digits / 3);				\
      else								\
	if (nb_digits >= 3)						\
	  nb_chars_to_write += ((nb_digits / 3) - 1);			\
    }									\
									\
  nb_chars_for_min_len = 0;						\
  if (infos->_min_len_to_use > nb_chars_to_write)			\
    nb_chars_for_min_len = infos->_min_len_to_use - nb_chars_to_write;	\
									\
  if (!infos->_attrs._minus)						\
    if (!infos->_attrs._zero)						\
      for (i = 0; i < nb_chars_for_min_len; i++)			\
	_k_print_char(' ');						\
									\
  if (arg_value < 0.)							\
    _k_print_char('-');							\
  else									\
    {									\
      if (infos->_attrs._space)						\
	_k_print_char(' ');						\
      else								\
	if (infos->_attrs._more)					\
	  _k_print_char('+');						\
    }									\
									\
  if (!infos->_attrs._minus && infos->_attrs._zero)			\
    {									\
      if (infos->_attrs._apostrophe && SEPARATOR)			\
	{								\
	  pos = nb_chars_for_min_len + nb_digits;			\
	  if (nb_digits % 3)						\
	    pos += nb_digits / 3;					\
	  else								\
	    if (nb_digits >= 3)						\
	      pos += nb_digits / 3 - 1;					\
	  for (i = 0; i < nb_chars_for_min_len; i++)			\
	    {								\
	      if (!(pos % 4))						\
		{							\
		  if (i == 0)						\
		    _k_print_char(' ');					\
		  else							\
		    _k_print_char(SEPARATOR_CHAR);			\
		}							\
	      else							\
		_k_print_char('0');					\
	      pos--;							\
	    }								\
	}								\
      else								\
	for (i = 0; i < nb_chars_for_min_len; i++)			\
	  _k_print_char('0');						\
    }									\
									\
  for (i = nb_digits - 1; i >= 0; i--)					\
    {									\
      digit_value = -1.;						\
      if (tmp_value < 0.)						\
	{								\
	  if (tmp_value > -1.)						\
	    { digit_value = 0.; _k_print_char('0'); }			\
	  else if (tmp_value > -2.)					\
	    { digit_value = 1.; _k_print_char('1'); }			\
	  else if (tmp_value > -3.)					\
	    { digit_value = 2.; _k_print_char('2'); }			\
	  else if (tmp_value > -4.)					\
	    { digit_value = 3.; _k_print_char('3'); }			\
	  else if (tmp_value > -5.)					\
	    { digit_value = 4.; _k_print_char('4'); }			\
	  else if (tmp_value > -6.)					\
	    { digit_value = 5.; _k_print_char('5'); }			\
	  else if (tmp_value > -7.)					\
	    { digit_value = 6.; _k_print_char('6'); }			\
	  else if (tmp_value > -8.)					\
	    { digit_value = 7.; _k_print_char('7'); }			\
	  else if (tmp_value > -9.)					\
	    { digit_value = 8.; _k_print_char('8'); }			\
	  else if (tmp_value > -10.)					\
	    { digit_value = 9.; _k_print_char('9'); }			\
	}								\
      else								\
	{								\
	  if (tmp_value < 1.)						\
	    { digit_value = 0.; _k_print_char('0'); }			\
	  else if (tmp_value < 2.)					\
	    { digit_value = 1.; _k_print_char('1'); }			\
	  else if (tmp_value < 3.)					\
	    { digit_value = 2.; _k_print_char('2'); }			\
	  else if (tmp_value < 4.)					\
	    { digit_value = 3.; _k_print_char('3'); }			\
	  else if (tmp_value < 5.)					\
	    { digit_value = 4.; _k_print_char('4'); }			\
	  else if (tmp_value < 6.)					\
	    { digit_value = 5.; _k_print_char('5'); }			\
	  else if (tmp_value < 7.)					\
	    { digit_value = 6.; _k_print_char('6'); }			\
	  else if (tmp_value < 8.)					\
	    { digit_value = 7.; _k_print_char('7'); }			\
	  else if (tmp_value < 9.)					\
	    { digit_value = 8.; _k_print_char('8'); }			\
	  else if (tmp_value < 10.)					\
	    { digit_value = 9.; _k_print_char('9'); }			\
	}								\
									\
      if (i && (!(i % 3)) &&						\
	  infos->_attrs._apostrophe && SEPARATOR)			\
	_k_print_char(SEPARATOR_CHAR);					\
      if (tmp_value < 0.)						\
	tmp_value += digit_value;					\
      else								\
	tmp_value -= digit_value;					\
      tmp_value *= 10.;							\
    }									\
									\
  if (((infos->_attrs._sharp) || (nb_chars_for_precision > 0)))		\
    _k_print_char(infos->_attrs._apostrophe ? COMMA : '.');		\
									\
  for (i = 1; i <= nb_chars_for_precision; i++)				\
    {									\
      digit_value = -1.;						\
      if (tmp_value < 0.)						\
	{								\
	  if (tmp_value > -1.)						\
	    { digit_value = 0.; _k_print_char('0'); }			\
	  else if (tmp_value > -2.)					\
	    { digit_value = 1.; _k_print_char('1'); }			\
	  else if (tmp_value > -3.)					\
	    { digit_value = 2.; _k_print_char('2'); }			\
	  else if (tmp_value > -4.)					\
	    { digit_value = 3.; _k_print_char('3'); }			\
	  else if (tmp_value > -5.)					\
	    { digit_value = 4.; _k_print_char('4'); }			\
	  else if (tmp_value > -6.)					\
	    { digit_value = 5.; _k_print_char('5'); }			\
	  else if (tmp_value > -7.)					\
	    { digit_value = 6.; _k_print_char('6'); }			\
	  else if (tmp_value > -8.)					\
	    { digit_value = 7.; _k_print_char('7'); }			\
	  else if (tmp_value > -9.)					\
	    { digit_value = 8.; _k_print_char('8'); }			\
	  else if (tmp_value > -10.)					\
	    { digit_value = 9.; _k_print_char('9'); }			\
	}								\
      else								\
	{								\
	  if (tmp_value < 1.)						\
	    { digit_value = 0.; _k_print_char('0'); }			\
	  else if (tmp_value < 2.)					\
	    { digit_value = 1.; _k_print_char('1'); }			\
	  else if (tmp_value < 3.)					\
	    { digit_value = 2.; _k_print_char('2'); }			\
	  else if (tmp_value < 4.)					\
	    { digit_value = 3.; _k_print_char('3'); }			\
	  else if (tmp_value < 5.)					\
	    { digit_value = 4.; _k_print_char('4'); }			\
	  else if (tmp_value < 6.)					\
	    { digit_value = 5.; _k_print_char('5'); }			\
	  else if (tmp_value < 7.)					\
	    { digit_value = 6.; _k_print_char('6'); }			\
	  else if (tmp_value < 8.)					\
	    { digit_value = 7.; _k_print_char('7'); }			\
	  else if (tmp_value < 9.)					\
	    { digit_value = 8.; _k_print_char('8'); }			\
	  else if (tmp_value < 10.)					\
	    { digit_value = 9.; _k_print_char('9'); }			\
	}								\
									\
      if ((!(i % 3)) && (i != nb_chars_for_precision) &&		\
	  infos->_attrs._apostrophe && SEPARATOR)			\
	_k_print_char(SEPARATOR_CHAR);					\
      if (tmp_value < 0.)						\
	tmp_value += digit_value;					\
      else								\
	tmp_value -= digit_value;					\
      tmp_value *= 10.;							\
    }									\
									\
  if (infos->_attrs._minus)						\
    for (i = 0; i < nb_chars_for_min_len; i++)				\
      _k_print_char(' ');						\
  return 0;

/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
