#ifndef _SYSTEM_H_
# define _SYSTEM_H_

/*
 * includes
 */


/*
 * defines
 */


/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */
void	k_halt();
void	_k_reboot();
void	k_reboot();

#endif
