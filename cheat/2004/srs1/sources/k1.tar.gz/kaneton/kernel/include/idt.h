#ifndef _IDT_H
#define _IDT_H

/*
 * includes
 */


/*
 * defines
 */
#define DUMP_IDT_ELMTS	0

#define IDT_SIZE		256

#define IDT_EXCEPTION_BASE	0
#define IDT_EXCEPTION_NUM	32
#define IDT_EXCEPTION_MAX	(IDT_EXCEPTION_BASE + IDT_EXCEPTION_NUM - 1)

#define IDT_IRQ_BASE		IDT_EXCEPTION_MAX + 1
#define IDT_IRQ_NUM		16
#define IDT_IRQ_MAX		(IDT_IRQ_BASE + IDT_IRQ_NUM - 1)

/*
 * structures / types
 */
typedef struct _s_idtr
{
  unsigned short	_limit;
  unsigned int		_base_addr;
} __attribute__ ((packed))	_t_idtr;

typedef struct _s_idt_handler
{
  unsigned int		_callback;
  unsigned short	_int_num;
  unsigned char		*_descr;
} __attribute__ ((packed))	_t_idt_handler;

/*
 * inline functions
 */


/*
 * prototypes
 */
void	k_init_idt();
void	k_idt_new_interrupt(unsigned short	entry,
			    unsigned int	offset,
			    unsigned short	segment,
			    unsigned short	type,
			    unsigned short	level);

#endif
