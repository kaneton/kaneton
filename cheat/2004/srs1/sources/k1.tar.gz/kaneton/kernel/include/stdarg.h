#ifndef _STDARG_H_
#define _STDARG_H_
/*
 * includes
 */


/*
 * defines
 */
#define k_va_arg_size(x)	(sizeof(x) & 3 ? sizeof(x) + 4 -\
(sizeof(x) & 3) : sizeof(x))
#define k_va_start(va, param)	va = (void *)((char *)(&param) +\
sizeof(char *))
#define k_va_arg(va, type)	*(type *)(((char *)(va = ((char *)va) +\
k_va_arg_size(type))) - k_va_arg_size(type))
#define k_va_copy(vadst, vasrc)	vadst = vasrc
#define k_va_end(va)		va = 0

/*
 * structures / types
 */
typedef void			*_t_va_list;

/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
