#ifndef _EXCEPTIONS_H_
#define _EXCEPTIONS_H_

/*
 * includes
 */
#include <registers.h>

/*
 * defines
 */
#define K_EXCEPTION_DIVIDE_ERROR		0
#define K_EXCEPTION_DEBUG			1
#define K_EXCEPTION_NMI_INTERRUPT		2
#define K_EXCEPTION_BREAKPOINT			3
#define K_EXCEPTION_OVERFLOW			4
#define K_EXCEPTION_BOUND_RANGE_EXCEDEED	5
#define K_EXCEPTION_INVALID_OPCODE		6
#define K_EXCEPTION_DEVICE_NOT_AVAILABLE	7
#define K_EXCEPTION_DOUBLE_FAULT		8
#define K_EXCEPTION_COPROCESSOR_SEGMENT_OVERRUN	9
#define K_EXCEPTION_INVALID_TSS			10
#define K_EXCEPTION_SEGMENT_NOT_PRESENT		11
#define K_EXCEPTION_STACK_SEGMENT_FAULT		12
#define K_EXCEPTION_GENERAL_PROTECTION		13
#define K_EXCEPTION_PAGE_FAULT			14
#define K_EXCEPTION_INTEL_RESERVED_1		15
#define K_EXCEPTION_FLOATING_POINT_ERROR	16
#define K_EXCEPTION_ALIGNEMENT_CHECK		17
#define K_EXCEPTION_MACHINE_CHECK		18
#define K_EXCEPTION_INTEL_RESERVED_2		19
#define K_EXCEPTION_INTEL_RESERVED_3		20
#define K_EXCEPTION_INTEL_RESERVED_4		21
#define K_EXCEPTION_INTEL_RESERVED_5		22
#define K_EXCEPTION_INTEL_RESERVED_6		23
#define K_EXCEPTION_INTEL_RESERVED_7		24
#define K_EXCEPTION_INTEL_RESERVED_8		25
#define K_EXCEPTION_INTEL_RESERVED_9		26
#define K_EXCEPTION_INTEL_RESERVED_10		27
#define K_EXCEPTION_INTEL_RESERVED_11		28
#define K_EXCEPTION_INTEL_RESERVED_12		29
#define K_EXCEPTION_INTEL_RESERVED_13		30
#define K_EXCEPTION_INTEL_RESERVED_14		31

/*
 * structures / types
 */
typedef void (*_t_exception_handler)(_t_registers	regs,
				     int		num,
				     int		eip);


/*
 * inline functions
 */


/*
 * prototypes
 */
void		k_init_exception();

void		k_exception_handler(_t_registers	regs,
				    int			tmp,
				    int			num,
				    int			eip);

void		_k_int_00();
void		_k_int_01();
void		_k_int_02();
void		_k_int_03();
void		_k_int_04();
void		_k_int_05();
void		_k_int_06();
void		_k_int_07();
void		_k_int_08();
void		_k_int_09();
void		_k_int_10();
void		_k_int_11();
void		_k_int_12();
void		_k_int_13();
void		_k_int_14();
void		_k_int_15();
void		_k_int_16();
void		_k_int_17();
void		_k_int_18();
void		_k_int_19();
void		_k_int_20();
void		_k_int_21();
void		_k_int_22();
void		_k_int_23();
void		_k_int_24();
void		_k_int_25();
void		_k_int_26();
void		_k_int_27();
void		_k_int_28();
void		_k_int_29();
void		_k_int_30();
void		_k_int_31();

#endif
