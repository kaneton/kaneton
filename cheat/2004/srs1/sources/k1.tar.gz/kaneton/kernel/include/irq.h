#ifndef _IRQ_H_
#define _IRQ_H_

/*
 * includes
 */


/*
 * defines
 */
#define K_DISABLE_IRQS(flags)		\
({					\
   asm volatile("pushfl; popl %0"	\
		: "=g"(flags)		\
		:			\
		: "memory");		\
   asm("cli\n");			\
})

#define K_RESTORE_IRQS(flags)		\
(asm volatile("push %0; popfl"		\
	      :				\
	      :"g"(flags)		\
	      :"memory"))

#define K_IRQ_TIMER		0
#define K_IRQ_KEYBOARD		1
#define K_IRQ_SLAVE_PIC		2
#define K_IRQ_COM2		3
#define K_IRQ_COM1		4
#define K_IRQ_LPT2		5
#define K_IRQ_FLOPPY		6
#define K_IRQ_LPT1		7
#define K_IRQ_CMOS		8
#define K_IRQ_9			9
#define K_IRQ_IDE4		10
#define K_IRQ_IDE3		11
#define K_IRQ_PS2		12
#define K_IRQ_COPROCESSOR	13
#define K_IRQ_IDE1		14
#define K_IRQ_IDE2		15

/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */
void		k_init_irq();
void		k_enable_irq(unsigned short	irq);
void		k_disable_irq(unsigned short	irq);

void		_k_irq_00();
void		_k_irq_01();
void		_k_irq_02();
void		_k_irq_03();
void		_k_irq_04();
void		_k_irq_05();
void		_k_irq_06();
void		_k_irq_07();
void		_k_irq_08();
void		_k_irq_09();
void		_k_irq_10();
void		_k_irq_11();
void		_k_irq_12();
void		_k_irq_13();
void		_k_irq_14();
void		_k_irq_15();

#endif
