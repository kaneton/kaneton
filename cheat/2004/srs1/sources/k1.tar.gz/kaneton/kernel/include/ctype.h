#ifndef _CTYPE_H_
#define _CTYPE_H_

/*
 * includes
 */
#include <types.h>

/*
 * defines
 */


/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */
_t_bool		islower(int	c);
_t_bool		isupper(int	c);
_t_bool		isalpha(int	c);
_t_bool		isdigit(int	c);
_t_bool		isxdigit(int	c);
_t_bool		isblank(int	c);

#endif
