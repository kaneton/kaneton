#ifndef _KEYBOARD_H
#define _KEYBOARD_H
/*
 * includes
 */


/*
 * defines
 */
#define NUMLOCK_ON_BOOT		1
#define KEYBOARD_BUFFER_SIZE	1024

#define KEYBOARD_ESCAPE		0x01
#define KEYBOARD_F1		0x3b
#define KEYBOARD_F2		0x3c
#define KEYBOARD_F3		0x3d
#define KEYBOARD_F4		0x3e
#define KEYBOARD_F5		0x3f
#define KEYBOARD_F6		0x40
#define KEYBOARD_F7		0x41
#define KEYBOARD_F8		0x42
#define KEYBOARD_F9		0x43
#define KEYBOARD_F10		0x44
#define KEYBOARD_F11		0x57
#define KEYBOARD_F12		0x58
#define KEYBOARD_PRINT_SCREEN	0x37
#define KEYBOARD_PAUSE		0xe1
#define KEYBOARD_BACKSPACE	0xe
#define KEYBOARD_INSERT		0x52
#define KEYBOARD_HOME		0x47
#define KEYBOARD_PAGE_UP	0x49
#define KEYBOARD_DELETE		0x53
#define KEYBOARD_END		0x4f
#define KEYBOARD_PAGE_DOWN	0x51
#define KEYBOARD_UP		0x48
#define KEYBOARD_LEFT		0x4b
#define KEYBOARD_DOWN		0x50
#define KEYBOARD_RIGHT		0x4d

#define KEYBOARD_NUMPAD_SLASH	0x35
#define KEYBOARD_NUMPAD_ENTER	0x1c

#define KEYBOARD_SPECIAL_KEY	0xe0
#define KEYBOARD_CTRL		0x1d
#define KEYBOARD_ALT		0x38
#define KEYBOARD_LEFT_SHIFT	0x2a
#define KEYBOARD_RIGHT_SHIFT	0x36
#define KEYBOARD_SCROLL_LOCK	0x46
#define KEYBOARD_NUM_LOCK	0x45
#define KEYBOARD_CAPS_LOCK	0x3a

/*
 * structures / types
 */
typedef struct _s_kbdmap
{
  char		*_mapname;
  unsigned char	*_map;
}	_t_kbdmap;

typedef struct _s_keyboard
{
  unsigned char	*_keyboard_table;
  unsigned char	_buffer[KEYBOARD_BUFFER_SIZE];
  int		_write_pos;
  int		_read_pos;
  struct
  {
    unsigned char	_l_shift : 1;
    unsigned char	_r_shift : 1;
    unsigned char	_l_ctrl : 1;
    unsigned char	_r_ctrl : 1;
    unsigned char	_l_alt : 1;
    unsigned char	_r_alt : 1;
    unsigned char	_caps_lock : 1;
    unsigned char	_num_lock : 1;
    unsigned char	_scroll_lock : 1;
    unsigned char	_caps_lock_pressed : 1;
    unsigned char	_num_lock_pressed : 1;
    unsigned char	_scroll_lock_pressed : 1;
  } _state;
}	_t_keyboard;

/*
 * inline functions
 */


/*
 * prototypes
 */
void			k_keyboard_isr();
void			k_set_keyboard_map(unsigned char	*map);
char			*k_get_keyboard_map_name();
void			k_init_keyboard();
unsigned char		k_get_char();
unsigned int		k_get_string(unsigned char	*buffer,
				     unsigned int	len);

#endif
