#ifndef _MULTIBOOT_H
#define _MULTIBOOT_H
/*
 * includes
 */


/*
 * defines
 */
#define K_STACK_SIZE	0x4000

/*
 * structures / types
 */
typedef struct _s_multiboot_header
{
  unsigned int	_magic;
  unsigned int	_flags;
  unsigned int	_checksum;
  unsigned int	_header_addr;
  unsigned int	_load_addr;
  unsigned int	_load_end_addr;
  unsigned int	_bss_end_addr;
  unsigned int	_entry_addr;
}	_t_multiboot_header;

typedef struct _s_aout_symbol_table
{
  unsigned int	_tabsize;
  unsigned int	_strsize;
  unsigned int	_addr;
  unsigned int	_reserved;
}	_t_aout_symbol_table;

typedef struct _s_elf_section_header_table
{
  unsigned int	_num;
  unsigned int	_size;
  unsigned int	_addr;
  unsigned int	_shndx;
}	_t_elf_section_header_table;

typedef struct _s_multiboot_info
{
  unsigned int	_flags;
  unsigned int	_mem_lower;
  unsigned int	_mem_upper;
  unsigned int	_boot_device;
  unsigned int	_cmdline;
  unsigned int	_mods_count;
  unsigned int	_mods_addr;
  union
  {
    _t_aout_symbol_table	_aout_sym;
    _t_elf_section_header_table	_elf_sec;
  }		_u;
  unsigned int	_mmap_length;
  unsigned int	_mmap_addr;
}	_t_multiboot_info;

typedef struct _s_module
{
  unsigned int	_mod_start;
  unsigned int	_mod_end;
  unsigned int	_string;
  unsigned int	_reserved;
}	_t_module;

typedef struct _s_memory_map
{
  unsigned int	_size;
  unsigned int	_base_addr_low;
  unsigned int	_base_addr_high;
  unsigned int	_length_low;
  unsigned int	_length_high;
  unsigned int	_type;
}	_t_memory_map;

/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
