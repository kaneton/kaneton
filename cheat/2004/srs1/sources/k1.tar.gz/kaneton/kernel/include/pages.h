#ifndef _PAGES_H_
#define _PAGES_H_

/*
 * includes
 */
#include <cycle_dlist.h>

/*
 * defines
 */
#define K_PAGE_SIZE	(4 * 1024)
#define K_PAGE_SHIFT	12
#define K_PAGE_MASK	((1 << K_PAGE_SHIFT) - 1)

#define K_PAGE_ALIGN_INF(addr)	((addr >> K_PAGE_SHIFT) << K_PAGE_SHIFT)
#define K_PAGE_ALIGN_SUP(addr)	(K_PAGE_ALIGN_INF(addr) + K_PAGE_SIZE)

#define BIOS_VIDEO_BASE		0xa0000
#define BIOS_VIDEO_TOP		0x100000

/*
 * structures / types
 */
typedef enum			_e_page_type
  {
    standard_page = 0,
    reserved_page,
    bios_video_page,
    kernel_page,
    page_descriptors_page
  }				_t_page_type;

typedef struct			_s_page_infos
{
  _t_phys_addr			_base;
  unsigned int			_refs;
  _t_page_type			_type;
} __attribute__ ((packed))	_t_page_infos;

typedef struct			_s_page_descriptor
{
  _t_cycle_dlist		_node;
  _t_page_infos			_infos;
} __attribute__ ((packed))	_t_page_descriptor;

/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
