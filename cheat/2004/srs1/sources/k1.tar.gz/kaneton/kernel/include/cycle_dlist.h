#ifndef _CYCLE_DLIST_H_
#define _CYCLE_DLIST_H_

/*
 * includes
 */
#include <types.h>

/*
 * defines
 */


/*
 * structures / types
 */
typedef struct		_s_cycle_dlist
{
  void			*_elem;
  struct _s_cycle_dlist	*_next;
  struct _s_cycle_dlist	*_prev;
}			_t_cycle_dlist;

/*
 * inline functions
 */


/*
 * prototypes
 */

/*
 * Warning :
 * This functions doesn't check validity of list and if node to delete is in
 * the list.
 */

void		k_cycle_dlist_init(_t_cycle_dlist	**list);
_t_bool		k_cycle_dlist_is_empty(_t_cycle_dlist	*list);
size_t		k_cycle_dlist_get_size(_t_cycle_dlist	*list);
_t_cycle_dlist	*k_cycle_dlist_get_head(_t_cycle_dlist	*list);
_t_cycle_dlist	*k_cycle_dlist_get_tail(_t_cycle_dlist	*list);
_t_cycle_dlist	*k_cycle_dlist_get_node(_t_cycle_dlist	*list,
					void		*elem);
void		k_cycle_dlist_add_before(_t_cycle_dlist	**list,
					 _t_cycle_dlist	*before_this,
					 _t_cycle_dlist	*node);
void		k_cycle_dlist_add_after(_t_cycle_dlist	**list,
					_t_cycle_dlist	*after_this,
					_t_cycle_dlist	*node);
void		k_cycle_dlist_add_head(_t_cycle_dlist	**list,
				       _t_cycle_dlist	*node);
void		k_cycle_dlist_add_tail(_t_cycle_dlist	**list,
				       _t_cycle_dlist	*node);
void		k_cycle_dlist_del(_t_cycle_dlist	**list,
				  _t_cycle_dlist	*node);
_t_cycle_dlist	*k_cycle_dlist_pop_head(_t_cycle_dlist	**list);
_t_cycle_dlist	*k_cycle_dlist_pop_tail(_t_cycle_dlist	**list);

#endif
