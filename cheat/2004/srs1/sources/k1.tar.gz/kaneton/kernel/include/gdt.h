#ifndef _GDT_H
#define _GDT_H

/*
 * includes
 */


/*
 * defines
 */
#define DUMP_GDT_ELMTS	0

#define GDT_SIZE	256

#define GDT_INDEX_NULL		0
#define GDT_INDEX_KERNEL_CODE	1
#define GDT_INDEX_KERNEL_DATA	2

/*
 * structures / types
 */
typedef struct _s_gdtr
{
  unsigned short	_limit;
  unsigned int		_base_addr;
} __attribute__ ((packed, aligned (8)))	_t_gdtr;

/*
 * inline functions
 */


/*
 * prototypes
 */
unsigned short	k_gdt_new_segment(unsigned int	base,
				  unsigned int	limit,
				  unsigned char	seg_type,
				  unsigned char des_type,
				  unsigned char dpl,
				  unsigned char present,
				  unsigned char custom,
				  unsigned char op_size,
				  unsigned char granularity);
void		k_gdt_del_segment(unsigned short	entry);
void		k_init_gdt();

#endif
