#ifndef _ASM_H
#define _ASM_H

/*
 * includes
 */


/*
 * defines
 */
#define CLI()			asm volatile ("cli\n"			\
					      :				\
					      : )
#define STI()			asm volatile ("sti\n"			\
					      :				\
					      : )

#define GET_EBP_AND_CS(ebp, cs)	asm volatile ("movl %%ebp, %%eax\n"	\
					      "pushw %%cs\n"		\
					      "popw %%bx\n"		\
					      :	"=a" (ebp), "=b" (cs)	\
					      : );			\
				cs &= 0xffff

#define USE_NEW_IDT(idtr)	asm volatile ("lidt %0\n"		\
					      :				\
					      : "m"(idtr))

#define GDT_UPDATE_CPU_SEGMENTS(new_code, new_data)			\
				asm volatile ("pushl %0\n"		\
					      "pushl $cs_jump\n"	\
					      "lret\n"			\
					      "cs_jump:\n"		\
					      "mov %1, %%eax\n"		\
					      "mov %%ax, %%ds\n"	\
					      "mov %%ax, %%es\n"	\
					      "mov %%ax, %%fs\n"	\
					      "mov %%ax, %%gs\n"	\
					      "mov %%ax, %%ss\n"	\
					      :				\
					      : "g"(new_code), "g"(new_data))

#define USE_NEW_GDT(gdtr)	asm volatile ("lgdt %0\n"		\
					      :				\
					      : "m"(gdtr))


#define USE_NEW_PD(pdr, cr0flags)					\
				asm volatile ("movl %0, %%cr3\n"	\
					      "movl %%cr0, %%eax\n"	\
					      "orl %%ebx, %%eax\n"	\
					      "movl %%eax, %%cr0\n"	\
					      "jmp 1f\n"		\
					      "1:\n"			\
					      "movl $2f, %%eax\n"	\
					      "jmp *%%eax\n"		\
					      "2:\n"			\
					      :				\
					      : "r"(pdr), "b"(cr0flags)	\
					      : "memory", "eax")

#define INVALIDATE_TLB(vaddr)	asm volatile ("invlpg %0\n"		\
					      :				\
					      : "m"(*((unsigned int *)vaddr)))
#define FLUSH_TLB()		asm volatile ("movl %%cr3, %%eax\n"	\
					      "movl %%eax, %%cr3\n"	\
					      :				\
					      : )




/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
