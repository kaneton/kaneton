#ifndef _ASSERT_H_
#define _ASSERT_H_

/*
 * includes;
 */
#include <asm.h>
#include <printf.h>
#include <system.h>

/*
 * defines
 */
#define K_ASSERT_FATAL(expr)						\
({									\
  int	res=(int)(expr);						\
									\
  if (!res)								\
    {									\
      CLI();								\
      k_console_printf("\n%1$k%3$s%2$k @ %1$k%4$s%2$k : %1$k%5$d%2$k\n"	\
		       "%6$k%7$5s Assertion %1$k" # expr		\
		       "%6$k failed.\n",				\
		       MK_BRIGHT_COLOR(COLOR_RED, COLOR_BLACK),		\
		       MK_COLOR(COLOR_RED, COLOR_BLACK),		\
		       __PRETTY_FUNCTION__, __FILE__, __LINE__,		\
		       MK_COLOR(COLOR_RED, COLOR_BLACK), "=>");		\
      k_halt();								\
    }									\
})

/*
 * structures / types
 */


/*
 * inline functions
 */


/*
 * prototypes
 */


#endif
