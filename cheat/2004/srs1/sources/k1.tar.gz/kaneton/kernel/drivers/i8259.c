#include <i8259.h>
#include <ioports.h>
#include <strings.h>
#include <printf.h>
#include <console.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */


/*
 * Initialize Programmable Interrupt Controller
 */
void		k_init_i8259(void)
{
  char			buf[CONSOLE_X + 1];
  int			limit_pos =
    strlen("   Released vector informations ");
  int			title_end = 0;
  int			i;

  title_end = k_print_initializing("i8259 "
				   "(Programmable Interrupt Controller)");

  outb(PIC_MASTER, ICW1_M);
  outb(PIC_SLAVE, ICW1_S);
  outb(PIC_MASTER + 1, ICW2_M);
  outb(PIC_SLAVE + 1, ICW2_S);
  outb(PIC_MASTER + 1, ICW3_M);
  outb(PIC_SLAVE + 1, ICW3_S);
  outb(PIC_MASTER + 1, ICW4_M);
  outb(PIC_SLAVE + 1, ICW4_S);

  outb(PIC_MASTER + 1, OCW1_M);
  outb(PIC_SLAVE + 1, OCW1_S);

  k_print_initialization_result(1);

  k_print_up_border_info(limit_pos, title_end);

  k_print_info(" Initialization Command Word 1 ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, ((ICW1_M >> 3) & 1) ? "Level triggered" :
	     "Edge triggered");
  k_print_info("   Interrupts ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, ((ICW1_M >> 2) & 1) ? "4" : "8");
  k_print_info("   Call @ interval ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, ((ICW1_M >> 1) & 1) ? "Single" :
	     "Cascaded");
  k_print_info("   PIC type ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, ((ICW1_M >> 0) & 1) ? "Yes" : "No");
  k_print_info("   ICW4 required ", limit_pos, buf);
  k_print_info(" Initialization Command Word 2 ", limit_pos, "");
  k_print_info("   Released vector informations ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, "%s%s%s%s%s",
	     ((ICW2_M >> 3) & 1) ? "13 " : "",
	     ((ICW2_M >> 4) & 1) ? "14 " : "",
	     ((ICW2_M >> 5) & 1) ? "15 " : "",
	     ((ICW2_M >> 6) & 1) ? "16 " : "",
	     ((ICW2_M >> 7) & 1) ? "17 " : "");
  k_print_info("     Master : ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%s%s%s%s%s",
	     ((ICW2_S >> 3) & 1) ? "13 " : "",
	     ((ICW2_S >> 4) & 1) ? "14 " : "",
	     ((ICW2_S >> 5) & 1) ? "15 " : "",
	     ((ICW2_S >> 6) & 1) ? "16 " : "",
	     ((ICW2_S >> 7) & 1) ? "17 " : "");
  k_print_info("     Slave : ", limit_pos, buf);
  k_print_info(" Initialization Command Word 3 ", limit_pos, "");
  k_print_info(" Master PIC", limit_pos, "");
  for (i = 0; i < 8; i++)
    if ((ICW3_M >> i) & 1)
      {
	k_snprintf(buf, (size_t)CONSOLE_X, "%d", i);
	k_print_info("   IR # connected to a slave ", limit_pos, buf);
      }
  k_print_info(" Slave PIC ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, "%d", ICW3_S & 0x3);
  k_print_info("   Slave ID ", limit_pos, buf);
  k_print_info(" Initialization Command Word 4 ", limit_pos, "");
  k_snprintf(buf, (size_t)CONSOLE_X, "%s", ((ICW4_M >> 4) & 1) ? "Yes" : "No");
  k_print_info("   Special Fully Nested Mode ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%s",
	     ((ICW4_M >> 2) & 3) == 2 ?
	     "Slave" :
	     ((ICW4_M >> 2) & 3) == 3 ?
	     "Master":
	     "Non");
  k_print_info("   Buffered Mode ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%s", ((ICW4_M >> 1) & 1) ?
	     "Auto" :
	     "Normal");
  k_print_info("   EOI ", limit_pos, buf);
  k_snprintf(buf, (size_t)CONSOLE_X, "%s", ((ICW4_M >> 0) & 1) ?
	     "8086/8080" :
	     "MCS-80/85");
  k_print_info("   Mode ", limit_pos, buf);

  k_print_info(" Operation Control Word 1 ", limit_pos, "");
  for (i = 0; i < 16; i++)
    {
      k_snprintf(buf, (size_t)CONSOLE_X, "%i %s", i,
		 ((((i > 7) ? OCW1_S : OCW1_M) >> ((i > 7) ? i - 8 : i)) & 1) ?
		 "Disabled" : " Enabled");
      k_print_info("   IRQ # ", limit_pos, buf);
    }
  k_print_down_border_info(limit_pos);
}

/*
 * Enable an irq line (change mask)
 */
/*
void		k_i8259_enable_irq_line(unsigned int	irq)
{
  if (irq < 8)
    outb((inb(PIC_MASTER + 1) & ~(1 << irq)), PIC_MASTER + 1);
  else
    outb((inb(PIC_SLAVE + 1) & ~(1 << (irq - 8))), PIC_SLAVE + 1);
}
*/

/*
 * Disable an irq line (change mask)
 */
/*
void		k_i8259_disable_irq_line(unsigned int	irq)
{
  if(irq < 8)
    outb((inb(PIC_MASTER + 1) | (1 << irq)), PIC_MASTER + 1);
  else
    outb((inb(PIC_SLAVE + 1) | (1 << (irq - 8))), PIC_SLAVE + 1);
}
*/
