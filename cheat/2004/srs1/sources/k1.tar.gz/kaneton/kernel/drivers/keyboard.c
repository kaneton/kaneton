#include <keyboard.h>
#include <console.h>
#include <ioports.h>
#include <printf.h>
#include <strings.h>
/*
 * global variables
 */
_t_keyboard		k_keyboard;

/*
 * extern variables
 */
extern _t_kbdmap	k_keyboard_maps[];
extern unsigned char	k_keyboard_qwerty_table[];
extern unsigned char	k_keyboard_azerty_table[];
extern unsigned char	k_keyboard_num_table[];

/*
 * static variables
 */


/*
 * static functions
 */
static unsigned char	send_8042_byte(unsigned char	b)
{
  unsigned char		code;

  do
    {
      outb(0x60, b);
      while (!(inb(0x64) & 1)) ;
      code = inb(0x60);
      switch (code)
	{
	case 0xfa: // ack
	  return 1;
	case 0xfe: // resend
	  break;
	default:
	  return 0;
	}
    }
  while (code == 0xfe);
  return 0;
}

/* Set keyboard leds */
static void		set_led_status()
{
  unsigned char		b = 0;

  if (k_keyboard._state._scroll_lock)
    b |= 1;
  if (k_keyboard._state._num_lock)
    b |= 2;
  if (k_keyboard._state._caps_lock)
    b |= 4;
  if (send_8042_byte(0xed))
    send_8042_byte(b);
}

/* Push a char into keyboard buffer */
static void		push_char(unsigned char	c)
{
  k_exit_history();

  if (((k_keyboard._write_pos + 1) % KEYBOARD_BUFFER_SIZE) !=
      k_keyboard._read_pos)
    {
      k_keyboard._buffer[k_keyboard._write_pos++] = c;
      k_keyboard._write_pos %= KEYBOARD_BUFFER_SIZE;
    }
}

/* Pop a char from keyboard buffer */
static unsigned char	pop_char()
{
  unsigned char		key = 0;

  if (k_keyboard._read_pos != k_keyboard._write_pos)
    {
      key = k_keyboard._buffer[k_keyboard._read_pos++];
      k_keyboard._read_pos %= KEYBOARD_BUFFER_SIZE;
    }
  return key;
}

static void		handle_numpad_key(unsigned char	key)
{
  unsigned char		shift_state = k_keyboard._state._l_shift |
    k_keyboard._state._r_shift;

  if (k_keyboard._state._num_lock)
    shift_state = !shift_state;
  if (shift_state)
    if (k_keyboard_num_table[key - 0x47])
      push_char(k_keyboard_num_table[key - 0x47]);
    else
      push_char(key);
  else
    {
      push_char(0xe0);
      push_char(key);
    }
}

static void		handle_std_key(unsigned char	key)
{
  unsigned char		shift_state;

  k_exit_history();
  if (key < 0x4f)
    {
      shift_state = k_keyboard._state._l_shift | k_keyboard._state._r_shift;
      if (k_keyboard._state._caps_lock)
	shift_state = !shift_state;
      if (k_keyboard._keyboard_table[key * 2 + shift_state])
	push_char(k_keyboard._keyboard_table[key * 2 + shift_state]);
      else
      if (key < 0x47)
	push_char(key);
    }
  if (key >= 0x47 && key < 0x54)
    handle_numpad_key(key);
  if (key >= 0x54 && key < 0x80)
    push_char(key);
}

static void		handle_ctrl_alt_key(unsigned char	key)
{
  if (key < 0x80)
    push_char(0xf2);
  handle_std_key(key);
}

static void		handle_ctrl_key(unsigned char	key)
{
  if (key < 0x80)
    push_char(0xf0);
  handle_std_key(key);
}

static void		handle_alt_key(unsigned char	key)
{
  if (key < 0x80)
    push_char(0xf1);
  handle_std_key(key);
}

static void		handle_extended2_key(unsigned char	key)
{
  unsigned char		key2, key3;

  while (!(inb(0x64) & 1)) ;
  key2 = inb(0x60);
  while (!(inb(0x64) & 1)) ;
  key3 = inb(0x60);
  if ((key2 < 0x80) && (key3 < 0x80))
    {
      if ((k_keyboard._state._l_ctrl || k_keyboard._state._r_ctrl) &&
	  (k_keyboard._state._l_alt || k_keyboard._state._r_alt))
	push_char(0xf8);
      else
	if (k_keyboard._state._l_ctrl || k_keyboard._state._r_ctrl)
	  push_char(0xf6);
	else
	  if (k_keyboard._state._l_alt || k_keyboard._state._r_alt)
	    push_char(0xf7);
      push_char(key);
      push_char(key2);
      push_char(key3);
    }
}

static void		handle_extended_key(unsigned char	key)
{
  unsigned char		key2;

  while (!(inb(0x64) & 1)) ;
  key2 = inb(0x60);
  if (key2 == KEYBOARD_PAGE_UP)
    {
      k_page_up();
      return ;
    }
  if (key2 == KEYBOARD_PAGE_DOWN)
    {
      k_page_down();
      return ;
    }
  if ((k_keyboard._state._num_lock == 1) &&
      (key2 == KEYBOARD_LEFT_SHIFT))
    return;

  switch (key2)
    {
    case KEYBOARD_ALT:
      k_keyboard._state._r_alt = 1;
      break;
    case KEYBOARD_CTRL:
      k_keyboard._state._r_ctrl = 1;
      break;
    case KEYBOARD_ALT + 0x80:
      k_keyboard._state._r_alt = 0;
      break;
    case KEYBOARD_CTRL + 0x80:
      k_keyboard._state._r_ctrl = 0;
      break;
    case KEYBOARD_NUMPAD_SLASH:
      push_char('/');
      break;
    case KEYBOARD_NUMPAD_ENTER:
      push_char('\n');
      break;
    default:
      if (key2 < 0x80)
	{
	  if ((k_keyboard._state._l_ctrl || k_keyboard._state._r_ctrl) &&
	      (k_keyboard._state._l_alt || k_keyboard._state._r_alt))
	    push_char(0xf5);
	  else
	    if (k_keyboard._state._l_ctrl || k_keyboard._state._r_ctrl)
	      push_char(0xf3);
	    else
	      if (k_keyboard._state._l_alt || k_keyboard._state._r_alt)
		push_char(0xf4);
	  push_char(key);
	  push_char(key2);
	}
    }
}

static void		handle_key_press(unsigned char	key)
{
  switch (key)
    {
    case KEYBOARD_CTRL:
      k_keyboard._state._l_ctrl = 1;
      break;
    case KEYBOARD_ALT:
      k_keyboard._state._l_alt = 1;
      break;
    case KEYBOARD_LEFT_SHIFT:
      k_keyboard._state._l_shift = 1;
      break;
    case KEYBOARD_RIGHT_SHIFT:
      k_keyboard._state._r_shift = 1;
      break;
    case KEYBOARD_CAPS_LOCK:
      if (!k_keyboard._state._caps_lock_pressed)
	{
	  k_keyboard._state._caps_lock = !k_keyboard._state._caps_lock;
	  k_keyboard._state._caps_lock_pressed = 1;
	  set_led_status();
	}
      break;
    case KEYBOARD_NUM_LOCK:
      if (!k_keyboard._state._num_lock_pressed)
	{
	  k_keyboard._state._num_lock = !k_keyboard._state._num_lock;
	  k_keyboard._state._num_lock_pressed = 1;
	  set_led_status();
	}
      break;
    case KEYBOARD_SCROLL_LOCK:
      if (!k_keyboard._state._scroll_lock_pressed)
	{
	  k_keyboard._state._scroll_lock = !k_keyboard._state._scroll_lock;
	  k_keyboard._state._scroll_lock_pressed = 1;
	  set_led_status();
	}
      break;
    default:
      if ((k_keyboard._state._l_ctrl || k_keyboard._state._r_ctrl) &&
	  (k_keyboard._state._l_alt || k_keyboard._state._r_alt))
	handle_ctrl_alt_key(key);
      else
	if (k_keyboard._state._l_ctrl || k_keyboard._state._r_ctrl)
	  handle_ctrl_key(key);
	else
	  if (k_keyboard._state._l_alt || k_keyboard._state._r_alt)
	    handle_alt_key(key);
	  else
	    handle_std_key(key);
    }
}

static void		handle_key_release(unsigned char	key)
{
  switch (key - 0x80)
    {
    case KEYBOARD_CTRL:
      k_keyboard._state._l_ctrl = 0;
      break;
    case KEYBOARD_ALT:
      k_keyboard._state._l_alt = 0;
      break;
    case KEYBOARD_LEFT_SHIFT:
      k_keyboard._state._l_shift = 0;
      break;
    case KEYBOARD_RIGHT_SHIFT:
      k_keyboard._state._r_shift = 0;
      break;
    case KEYBOARD_CAPS_LOCK:
      k_keyboard._state._caps_lock_pressed = 0;
      break ;
    case KEYBOARD_NUM_LOCK:
      k_keyboard._state._num_lock_pressed = 0;
      break;
    case KEYBOARD_SCROLL_LOCK:
      k_keyboard._state._scroll_lock_pressed = 0;
      break;
    }
}

/*
 * Keyboard Handler
 */
void			k_keyboard_isr()
{
  unsigned char		key;

  while (!(inb(0x64) & 1))
    ;
  key = inb(0x60);
  if (key == 0xe0)
    handle_extended_key(key);
  else
    if (key == 0xe1)
      handle_extended2_key(key);
    else
      (key < 0x80) ? handle_key_press(key) : handle_key_release(key);
}

/*
 * Set keyboard map
 */
void			k_set_keyboard_map(unsigned char	*map)
{
  k_keyboard._keyboard_table = map;
}

/*
 * Get active keyboard map name
 */
char			*k_get_keyboard_map_name()
{
  int			i;

  for (i = 0; k_keyboard_maps[i]._map; i++)
    {
      if (k_keyboard_maps[i]._map == k_keyboard._keyboard_table)
	return k_keyboard_maps[i]._mapname;
    }
  return "Unknown";
}

/*
 * Init keyboard
 */
void			k_init_keyboard()
{
  int			i;
  char			buf[CONSOLE_X + 1];
  int			limit_pos =
    strlen(" Available keymaps ");
  int			title_end = 0;

  title_end = k_print_initializing("keyboard");

  k_set_keyboard_map(k_keyboard_azerty_table);
  for (i = 0; i < KEYBOARD_BUFFER_SIZE; i++)
    k_keyboard._buffer[i] = 0;
  k_keyboard._write_pos = 0;
  k_keyboard._read_pos = 0;

  k_keyboard._state._l_shift = 0;
  k_keyboard._state._r_shift = 0;
  k_keyboard._state._l_ctrl = 0;
  k_keyboard._state._r_ctrl = 0;
  k_keyboard._state._l_alt = 0;
  k_keyboard._state._r_alt = 0;
  k_keyboard._state._caps_lock = 0;
  k_keyboard._state._num_lock = (NUMLOCK_ON_BOOT ? 1 : 0);
  k_keyboard._state._scroll_lock = 0;
  k_keyboard._state._caps_lock_pressed = 0;
  k_keyboard._state._num_lock_pressed = 0;
  k_keyboard._state._scroll_lock_pressed = 0;

  set_led_status();
  k_print_initialization_result(1);
  k_print_up_border_info(limit_pos, title_end);

  k_snprintf(buf, (size_t)CONSOLE_X, "%s",
	     NUMLOCK_ON_BOOT ? "Yes" : "No");
  k_print_info(" Numlock on boot ", limit_pos, buf);

  k_print_info(" Available keymaps ", limit_pos, "");
  for (i = 0; k_keyboard_maps[i]._mapname; i++)
    k_print_info("", limit_pos, k_keyboard_maps[i]._mapname);

  k_print_info(" Selected keymap ", limit_pos, k_get_keyboard_map_name());

  k_snprintf(buf, (size_t)CONSOLE_X, "%d Bytes", KEYBOARD_BUFFER_SIZE);
  k_print_info(" Buffer size ", limit_pos, buf);

  k_print_down_border_info(limit_pos);
}

/*
 * Get A Printable Character
 */
unsigned char		k_get_char()
{
  unsigned char		key;

  do
    {
      while (k_keyboard._write_pos == k_keyboard._read_pos)
	;
      key = pop_char();
    }
  while (key == 0);
  return key;
}

/*
 * Get A Printable String
 */
unsigned int		k_get_string(unsigned char	*buffer,
				     unsigned int	len)
{
  unsigned int		i, j;

  for (i = 0; i < len; )
    {
      buffer[i] = k_get_char();
      if (((buffer[i] >= 1) && (buffer[i] <= 7)) ||
	  ((buffer[i] >= 11) && (buffer[i] <= 12)) ||
	  (buffer[i] >= 14) || (buffer[i] == '\n') || (buffer[i] == '\t'))
	k_print_char(buffer[i]);
      else
	if (buffer[i] != '\b')
	  k_print_char('~');
      if (buffer[i] == '\b')
	{
	  if (i > 0)
	    {
	      if (buffer[i - 1] == '\t')
		{
		  for (j = 0; j < CONSOLE_TABULATION; j++)
		    k_print_char('\b');
		  i--;
		}
	      else
		{
		  k_print_char('\b');
		  i--;
		}
	    }
	}
      else
	if (buffer[i] == '\n')
	  return i;
	else
	  i++;
    }
  return len;
}
