#include <console.h>
#include <ioports.h>
#include <system.h>
#include <types.h>
#include <limits.h>
#include <strings.h>
#include <printf.h>
#include <mm.h>
#include <pages.h>
#include <shell.h>
#include <assert.h>
/*
 * global variables
 */
long int	k_history_lines = 0;
long int	k_history_current_line = 0;

unsigned short	*k_history;
_t_bool		k_history_status = true;

/*
 * extern variables
 */
extern _t_phys_addr	history_base;
extern _t_phys_addr	history_top;
extern _t_phys_addr	kernel_core_top;

/*
 * static variables
 */
static _t_bool		cursor_status = 1;
static _t_bool		cursor_status_before_scrolling;
static _t_bool		history_dynamic = false;
static _t_bool		physical_history = false;
static _t_console	console;
static short		cursor_pos;
static const char	hex_char[] =
{
  '0', '1', '2', '3', '4', '5', '6', '7',
  '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'
};

/*
 * static functions
 */
/* Get cursor position */
static unsigned short	get_cursor_pos()
{
  unsigned char		hi, lo;

  outb(console._crt_addr_register, 0x0e);
  hi = inb(console._crt_data_register);
  outb(console._crt_addr_register, 0x0f);
  lo = inb(console._crt_data_register);
  return ((hi & 0x0f) << 8) + lo;
}

/* Print history at line 'line' */
static void		print_history_at_line(long int	line)
{
  int	lines_to_print = 0;
  int	i;

  if (line > k_history_lines)
    line = k_history_lines;
  if (line < 0)
    line = 0;
  lines_to_print = MIN(CONSOLE_Y, k_history_lines);
  for (i = 0; i < CONSOLE_X * lines_to_print; i++)
    console._vga[i] = k_history[line * CONSOLE_X + i];
  for (; i < CONSOLE_X * CONSOLE_Y; i++)
    console._vga[i] = console._attr << 8;
}

/* Scrolls screen to up */
static void		scroll_screen()
{
  int			i;
  unsigned short	*history;
  static _t_phys_addr	old_history_top = 0;

  if (k_history_status == true)
    {
      for (i = 0; i < CONSOLE_X; i++)
	k_history[k_history_lines * CONSOLE_X + i] = console._vga[i];
      k_history_lines++;
      k_history_current_line++;
      if (history_dynamic)
	{
	  k_check_if_page_alloc_required_for_history();
	}
      else
	{
	  history = k_history + ((k_history_lines + CONSOLE_Y) * CONSOLE_X);
	  kernel_core_top =
	    (history_top =
	     (_t_phys_addr)(K_PAGE_ALIGN_SUP((_t_phys_addr)history)));
	  if ((old_history_top != history_top) && physical_history)
	    {
	      k_mark_existing_pages(old_history_top, history_top,
				    standard_page);
	      K_ASSERT_FATAL((k_get_page_descriptor_at(history_top - 1))->
			     _infos._refs == 1);
	    }
	  old_history_top = history_top;
	}
    }
  for (i = CONSOLE_X; i < (CONSOLE_SIZE >> 1); i++)
    console._vga[i - CONSOLE_X] = console._vga[i];
  for (i = (CONSOLE_SIZE >> 1) - CONSOLE_X; i < (CONSOLE_SIZE >> 1); i++)
    {
      if ((k_history_status == true) && history_dynamic)
	k_history[k_history_lines * CONSOLE_X + i] = console._attr << 8;
      console._vga[i] = console._attr << 8;
    }
}

/* Moves cursor to new position */
static void		update_cursor()
{
  outb(console._crt_addr_register, 0x0e);
  outb(console._crt_data_register, (console._cursor >> 8) & 0x0f);
  outb(console._crt_addr_register, 0x0f);
  outb(console._crt_data_register, console._cursor & 0xff);
}

/*
 * Hide cursor
 */
void			k_hide_cursor()
{
  outb(console._crt_addr_register, 0x0a);
  outb(console._crt_data_register, 1 << 5);
  cursor_status = 0;
}

/*
 * Unhide cursor
 */
void			k_unhide_cursor()
{
  outb(console._crt_addr_register, 0x0a);
  outb(console._crt_data_register, 0 << 5);
  cursor_status = 1;
}

/*
 * Initialize Console: cursor, video memory, color attributs
 */
void			k_init_console()
{
  char			buf[CONSOLE_X + 1];
  int			limit_pos = strlen(" History Physical start @ ");
  int			title_end = 0;
  unsigned int		i;

  k_history_lines = 0;

  k_history = (unsigned short *)((_t_phys_addr)history_base);
  console._crt_addr_register = VGA_CRT_INDEX_REGISTER;
  console._crt_data_register = VGA_CRT_DATA_REGISTER;
  console._attr = CONSOLE_DEFAULT_ATTR;
  for (i = 0; i < CONSOLE_X * CONSOLE_Y - 1; i++)
    k_history[i] = console._attr << 8;

  console._cursor = get_cursor_pos();
  console._vga = (unsigned short *)CONSOLE_VIDEO_ADDR;
  k_hide_cursor();
  k_clrscr();
  title_end = k_print_initializing("console (x86 video memory)"
				   " (already done)");
  k_print_initialization_result(1);

  k_print_up_border_info(limit_pos, title_end);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d * %d (Bytes Per 'Pixel' : %d)",
	     CONSOLE_X, CONSOLE_Y, CONSOLE_BPP);
  k_print_info(" Mode ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#x => %#x",
	     CONSOLE_VIDEO_ADDR, CONSOLE_VIDEO_LIMIT);
  k_print_info(" Video @ ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%'d Bytes",
	     CONSOLE_SIZE);
  k_print_info(" Size ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "Index %#x, Data %#x",
	     VGA_CRT_INDEX_REGISTER, VGA_CRT_DATA_REGISTER);
  k_print_info(" Registers ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#x",
	     (_t_phys_addr)k_history);
  k_print_info(" History Physical start @ ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%d", PAGE_UP_N_DOWN_LINES);
  k_print_info(" Number of scrolled lines ", limit_pos, buf);

  k_print_down_border_info(limit_pos);
}


/*
 * Print a String to the Console Screen
 */
void			k_print_string(const unsigned char	*string)
{
  size_t		i;

  for (i = 0; string[i]; i++)
    k_print_char(string[i]);
}

/*
 *  Print a Number in hex to the Console Screen
 */
void			k_print_number_hex(const unsigned int	number)
{
  if (number >= 16)
    k_print_number_hex(number >> 4);
  else
    k_print_string((unsigned char *)"0x");
  k_print_char(hex_char[number - ((number >> 4) << 4)]);
}


/*
 *  Print a Number in 0 padded hex to the Console Screen
 */
void			k_print_number_hex_0pad(const unsigned int	number,
						const char	nbdigit)
{
  if ((nbdigit > 1) || (number >= 16))
    k_print_number_hex_0pad(number >> 4, nbdigit - 1);
  else
    k_print_string((unsigned char *)"0x");
  k_print_char(hex_char[(number - ((number >> 4) << 4))]);
}


/*
 *  Print a Number to the Console Screen
 */
void			k_print_number(const int	number)
{
  if (number == SINT_MIN)
    {
      k_print_string((unsigned char *)SINT_MIN_STR);
      return ;
    }
  if (number < 0)
  {
    k_print_char('-');
  }
  if (number >= 10)
    k_print_number(number / 10);
  k_print_char((number % 10) + '0');
}

/*
 * Print a Char to the Console Screen
 *
 */
void			k_print_char(const unsigned char	c)
{
  int			i;

  switch (c)
  {
    case '\r':
      break;
    case '\b':
      if (console._cursor)
      {
	console._cursor--;
	k_print_char(' ');
	console._cursor--;
      }
      break;
    case '\n':
      console._cursor += CONSOLE_X - console._cursor % CONSOLE_X;
      break;
    case '\t':
      for (i = 0; i < CONSOLE_TABULATION; i++)
	k_print_char(' ');
      break;
    default:
      console._vga[console._cursor] = (console._attr << 8) + c;
      console._cursor++;
  }
  if (console._cursor >= (CONSOLE_SIZE >> 1))
  {
    scroll_screen();
    console._cursor = (CONSOLE_SIZE >> 1) - CONSOLE_X;
  }
  update_cursor();
}

/*
 * Print A Panic Message And Loop
 */
void			k_panic(const char	*message)
{
  k_print_string((unsigned char *)message);
  k_halt();
}

/*
 * Clears screen
 */
void			k_clrscr()
{
  int			i;

  for (i = 0; i < CONSOLE_SIZE >> 1; i++)
    console._vga[i] = console._attr << 8;
  console._cursor = 0;
}

/*
 * Sets color attributes
 */
void			k_set_attr(const char	attr)
{
  console._attr = attr;
}

/*
 * Gets color attributes
 */
char			k_get_attr()
{
  return console._attr;
}

/*
 * Print a K initialization message
 */
int			k_print_initializing(const char	*message)
{
  const int		window_pos = 1;
  const int		title_offset = 1;
  int			title_len;
  const int		init_result_len = 4;
  int			wroten;
  int			i;
  const unsigned char	shadow_color =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  const unsigned char	title_color =
    MK_BRIGHT_COLOR(COLOR_CYAN, COLOR_BLUE);
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);

  k_console_printf("\n");
  wroten = 0;

  for (i = 0; i < title_offset + window_pos; i++)
    wroten += k_console_printf(" ");

  wroten += k_console_printf("%k%c", bright_border_color, 0xda);
  title_len = k_null_printf("Initializing %s...", message);
  for (i = 0; i < title_len; i++)
    wroten += k_console_printf("%k%c", bright_border_color, 0xc4);
  wroten += k_console_printf("%k%c", bright_border_color, 0xbf);
  wroten += k_console_printf("%c", ' ');

  for (i = 0; i < CONSOLE_X - (wroten + (init_result_len + 2) + 1 + 1 + 1);
       i++)
    k_console_printf(" ");
  k_console_printf("%k%c", bright_border_color, 0xda);
  for (i = 0; i < init_result_len; i++)
    k_console_printf("%k%c", bright_border_color, 0xc4);
  k_console_printf("%k%c", bright_border_color, 0xbf);

  k_console_printf("%c", ' ');

  k_console_printf("\n");
  wroten = 0;

  for (i = 0; i < title_offset + window_pos; i++)
    wroten += k_console_printf(" ");

  wroten += k_console_printf("%k%c", bright_border_color, 0xb3);
  wroten += k_console_printf("%kInitializing %s...", title_color,
			     message);
  wroten += k_console_printf("%k%c", border_color, 0xb3);
  wroten += k_console_printf("%k%c", shadow_color, 0xb0);

  for (i = 0; i < CONSOLE_X - (wroten + (init_result_len + 2) + 1 + 1 + 1);
       i++)
    k_console_printf(" ");
  return wroten;
}

/*
 * Print a K initialization result
 */
void			k_print_initialization_result(const _t_bool	ok)
{
  const unsigned char	shadow_color =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);

  k_console_printf("%k%c", bright_border_color, 0xb3);
  k_console_printf("%k%c", MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE),
		   0x11);
  if (ok)
    k_console_printf("%kOk",
		     MK_BRIGHT_COLOR(COLOR_GREEN, COLOR_BLUE));
  else
    k_console_printf("%kKo",
		     MK_BRIGHT_COLOR(COLOR_RED, COLOR_BLUE));

  k_console_printf("%k%c", MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE),
		   0x10);
  k_console_printf("%k%c", border_color, 0xb3);
  k_console_printf("%k%c", shadow_color, 0xb0);
  k_console_printf("\n");
}

void			k_print_up_border_info(const int	limit_pos,
					       const int	title_end)
{
  const int		window_pos = 1;
  const int		title_offset = 1;
  int			i;
  int			c;
  int			wroten;
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);

  wroten = 0;
  for (i = 0; i < window_pos; i++)
    wroten += k_console_printf(" ");
  wroten += k_console_printf("%k%c", bright_border_color, 0xc9);
  for (i = 0; i < CONSOLE_X - wroten - 3; i++)
    {
      if (i == title_offset - 1)
	c = 0xcf;
      else if (i == CONSOLE_X - wroten - 4)
	c = 0xcf;
      else if (i == CONSOLE_X - wroten - (5 + 4))
	c = 0xcf;
      else if ((i == limit_pos) && (i != 0))
	c = 0xd1;
      else
	c = 0xcd;
      if (i == title_end - wroten - 2)
	switch (c)
	  {
	  case 0xd1:
	    c = 0xd8;
	    break ;
	  default:
	    c = 0xcf;
	  }
      if ((i < title_offset) || ((i > title_end - wroten - 2) &&
		       (i <= CONSOLE_X - wroten - (5 + 4))))
	k_console_printf("%k%c", bright_border_color, c);
      else
	k_console_printf("%k%c", border_color, c);
    }
  k_console_printf("%k%c", bright_border_color, 0xbb);
  k_console_printf("%c", ' ');
  k_console_printf("\n");
}

void			k_print_info(const char			*info,
				     const int			limit_pos,
				     const char			*data)
{
  const int		window_pos = 1;
  int			i;
  int			wroten;
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	shadow_color =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  const unsigned char	info_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	data_color =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);

  wroten = 0;
  for (i = 0; i < window_pos; i++)
    wroten += k_console_printf(" ");
  wroten += k_console_printf("%k%c", bright_border_color, 0xba);
  wroten += k_console_printf("%k%-*s", info_color, limit_pos, info);
  wroten += k_console_printf("%k%c", border_color, 0xb3);
  k_console_printf("%k%*s", data_color, CONSOLE_X - wroten - 3, data);
  k_console_printf("%k%c", border_color, 0xba);
  k_console_printf("%k%c", shadow_color, 0xb0);
  k_console_printf("\n");
}

void			k_print_down_border_info(const int	limit_pos)
{
  const int		window_pos = 1;
  int			i;
  int			wroten;
  const unsigned char	shadow_color =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);

  wroten = 0;
  for (i = 0; i < window_pos; i++)
    wroten += k_console_printf(" ");
  wroten += k_console_printf("%k%c", bright_border_color, 0xc8);
  for (i = 0; i < limit_pos; i++)
    wroten += k_console_printf("%k%c", border_color, 0xcd);
  if (limit_pos != 0)
    wroten += k_console_printf("%k%c", border_color, 0xcf);
  for (i = 0; i < CONSOLE_X - wroten - 3; i++)
    k_console_printf("%k%c", border_color, 0xcd);
  k_console_printf("%k%c", border_color, 0xbc);
  k_console_printf("%k%c", shadow_color, 0xb0);

  k_console_printf("\n");
  wroten = 0;

  for (i = 0; i < window_pos; i++)
    wroten += k_console_printf(" ");
  wroten += k_console_printf("%c", ' ');

  for (i = 0; i < CONSOLE_X - wroten - 3; i++)
    k_console_printf("%k%c", shadow_color, 0xb0);
  k_console_printf("%k%c", shadow_color, 0xb0);
  k_console_printf("%k%c", shadow_color, 0xb0);

  k_console_printf("\n");
}

/*
 * Print a window title
 */
int		k_print_title_window(const char	*message)
{
  const int		window_pos = 1;
  const int		title_offset = 1;
  int			title_len;
  int			i;
  const unsigned char	shadow_color =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  const unsigned char	title_color =
    MK_BRIGHT_COLOR(COLOR_CYAN, COLOR_BLUE);
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);

  k_console_printf("\n");

  for (i = 0; i < title_offset + window_pos; i++)
    k_console_printf(" ");
  k_console_printf("%k%c", bright_border_color, 0xda);
  title_len = strlen(message);
  for (i = 0; i < title_len; i++)
    k_console_printf("%k%c", bright_border_color, 0xc4);
  k_console_printf("%k%c", bright_border_color, 0xbf);
  k_console_printf("%c", ' ');
  k_console_printf("\n");

  for (i = 0; i < title_offset + window_pos; i++)
    k_console_printf(" ");
  k_console_printf("%k%c", bright_border_color, 0xb3);
  k_console_printf("%k%s", title_color, message);
  k_console_printf("%k%c", border_color, 0xb3);
  k_console_printf("%k%c", shadow_color, 0xb0);
  k_console_printf("\n");
  return title_len;
}

/*
 * Print a window up border
 */
void	k_print_up_border_window(const int		title_len,
				 const _t_bool		separators[CONSOLE_X -
								   5])
{
  const int		window_pos = 1;
  const int		title_offset = 1;
  int			c, i;
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);

  for (i = 0; i < window_pos; i++)
    k_console_printf(" ");
  k_console_printf("%k%c", bright_border_color, 0xc9);
  for (i = 0; i < CONSOLE_X - 5; i++)
    {
      if (i == title_offset - 1)
	c = 0xcf;
      else if (i == title_len + title_offset)
	c = 0xcf;
      else
	c = 0xcd;
      if (separators[i] == true)
	{
	  if (c == 0xcf)
	    c = 0xd8;
	  else
	    c = 0xd1;
	}
      if ((i < title_offset) || (i > title_len + title_offset))
	k_console_printf("%k%c", bright_border_color, c);
      else
	k_console_printf("%k%c", border_color, c);
    }
  k_console_printf("%k%c", bright_border_color, 0xbb);
  k_console_printf("%c\n", ' ');
}

/*
 * Print datas in a window
 */
void	k_print_datas_in_window(const _t_bool	separators[CONSOLE_X - 5],
				...)
{
  const int		window_pos = 1;
  _t_va_list		args;
  _t_alignment		alignment;
  unsigned char		*s;
  int			col;
  int			i, j;
  const unsigned char	shadow_color =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);

  k_va_start(args, separators);
  for (i = 0; i < window_pos; i++)
    k_console_printf(" ");
  k_console_printf("%k%c", bright_border_color, 0xba);
  i = 0;
  while (i < CONSOLE_X - 5)
    {
      for (j = i; (j < CONSOLE_X - 5) && (separators[j] == false); j++)
	;
      s = k_va_arg(args, unsigned char *);
      col = k_va_arg(args, int);
      alignment = k_va_arg(args, _t_alignment);

      if (alignment == left)
	i += k_console_printf("%1$k%2$-*3$.*3$s", col, s, j - i);
      else
	i += k_console_printf("%1$k%2$*3$.*3$s", col, s, j - i);
      if (i < CONSOLE_X - 5)
	{
	  k_console_printf("%k%c", border_color, 0xb3);
	  i++;
	}
    }
  k_console_printf("%k%c", border_color, 0xba);
  k_console_printf("%k%c\n", shadow_color, 0xb0);
  k_va_end(args);
}

/*
 * Print an horizontal separator in window
 */
void	k_print_separator(const _t_bool	up_separators[CONSOLE_X - 5],
			  const _t_bool	down_separators[CONSOLE_X - 5])
{
  const int		window_pos = 1;
  int			c;
  int			i;
  const unsigned char	shadow_color =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);

  for (i = 0; i < window_pos; i++)
    k_console_printf(" ");
  k_console_printf("%k%c", bright_border_color, 0xc7);
  for (i = 0; i < CONSOLE_X - 5; i++)
    {
      c = 0xc4;
      if ((up_separators[i] == true) && (down_separators[i] == true))
	c = 0xc5;
      else
	{
	  if (up_separators[i] == true)
	    c = 0xc1;
	  else if (down_separators[i] == true)
	    c = 0xc2;
	}
      k_console_printf("%k%c", border_color, c);
    }
  k_console_printf("%k%c", border_color, 0xb6);
  k_console_printf("%k%c\n", shadow_color, 0xb0);
}

/*
 * Print a window down border (to close window)
 */
void	k_print_down_border_window(const _t_bool separators[CONSOLE_X - 5])
{
  const int		window_pos = 1;
  int			c, i;
  const unsigned char	shadow_color =
    MK_COLOR(COLOR_BLACK, COLOR_BLUE);
  const unsigned char	border_color =
    MK_COLOR(COLOR_WHITE, COLOR_BLUE);
  const unsigned char	bright_border_color =
    MK_BRIGHT_COLOR(COLOR_WHITE, COLOR_BLUE);

  for (i = 0; i < window_pos; i++)
    k_console_printf(" ");
  k_console_printf("%k%c", bright_border_color, 0xc8);
  for (i = 0; i < CONSOLE_X - 5; i++)
    {
      c = 0xcd;
      if (separators[i] == true)
	c = 0xcf;
      k_console_printf("%k%c", border_color, c);
    }
  k_console_printf("%k%c", border_color, 0xbc);
  k_console_printf("%k%c\n", shadow_color, 0xb0);

  for (i = 0; i < window_pos; i++)
    k_console_printf(" ");

  k_console_printf("%c", ' ');

  for (i = 0; i < CONSOLE_X - 5; i++)
    k_console_printf("%k%c", shadow_color, 0xb0);
  k_console_printf("%k%c", shadow_color, 0xb0);
  k_console_printf("%k%c", shadow_color, 0xb0);

  k_console_printf("\n");
}

/*
 * Scroll up in history
 */
void	k_page_up()
{
  int	old_line;

  if (k_history_status == true)
    cursor_status_before_scrolling = cursor_status;
  k_hide_cursor();
  old_line = k_history_current_line;
  if (k_history_status == true)
    {
      k_history_status = false;
      cursor_pos = get_cursor_pos();
      k_append_actual_screen_to_history();
    }
  k_history_current_line -= PAGE_UP_N_DOWN_LINES;
  k_history_current_line = ((k_history_current_line < 0) ? 0 :
			  k_history_current_line);
  if (k_history_lines == 0)
    k_exit_history();
  if (old_line != k_history_current_line)
    print_history_at_line(k_history_current_line);
}

/*
 * Scroll down in history
 */
void	k_page_down()
{
  int	old_line;

  if (k_history_status == true)
    return ;
  k_hide_cursor();
  old_line = k_history_current_line;
  k_history_current_line += PAGE_UP_N_DOWN_LINES;
  if (k_history_current_line >= k_history_lines)
    {
      k_history_current_line = k_history_lines;
      k_exit_history();
      return ;
    }
  if (k_history_current_line < 0)
    k_history_current_line = 0;
  if (old_line != k_history_current_line)
    print_history_at_line(k_history_current_line);

}

/*
 * Exit history mode
 */
void	k_exit_history()
{
  long int	line;

  if (k_history_status == false)
    {
      line = k_history_lines;
      k_history_current_line = line;
      print_history_at_line(line);
      console._cursor = cursor_pos;
      k_history_status = true;
      if (cursor_status_before_scrolling == 1)
	k_unhide_cursor();
      else
	k_hide_cursor();
      update_cursor();
    }
}

/*
 * Set history dynamic after paging initialization to check if physical pages
 * are allocated.
 */
void	k_set_history_dynamic()
{
  history_dynamic = true;
}

/*
 * Permit to know when physical lists of pages are available
 */
void	k_set_physical_history()
{
  physical_history = true;
}

void	k_append_actual_screen_to_history()
{
  int	i;

  for (i = 0; i < CONSOLE_X * CONSOLE_Y; i++)
    k_history[k_history_lines * CONSOLE_X + i] = console._vga[i];
}
