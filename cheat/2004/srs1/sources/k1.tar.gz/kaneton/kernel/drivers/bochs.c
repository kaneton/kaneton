#include <bochs.h>
#include <ioports.h>
#include <console.h>
#include <printf.h>
#include <strings.h>

/*
 * global variables
 */


/*
 * extern variables
 */


/*
 * static variables
 */


/*
 * static functions
 */


/*
 * Init Bochs output (just print a message).
 */
void			k_init_bochs()
{
  char			buf[CONSOLE_X + 1];
  int			limit_pos =
    strlen(" Print spaces for special length chars ");
  int			title_end = 0;

  title_end = k_print_initializing("Bochs output (already done)");
  k_print_initialization_result(1);

  k_print_up_border_info(limit_pos, title_end);

  k_snprintf(buf, (size_t)CONSOLE_X, "%#x", K_BOCHS_IOPORT);
  k_print_info(" Bochs I/O Port ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%s", DUPLICATE_CONSOLE_PRINTF_ON_BOCHS ?
	     "Yes" : "No");
  k_print_info(" Printf duplicated in bochs ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%s", PRINT_SPACE_FOR_NO_LEN_CHARS ?
	     "Yes" : "No");
  k_print_info(" Print spaces for special length chars ", limit_pos, buf);

  k_snprintf(buf, (size_t)CONSOLE_X, "%s", PRINT_WINDOW_CHARS ?
	     "Yes" : "No");
  k_print_info(" Print spaces for window chars ", limit_pos, buf);

  k_print_down_border_info(limit_pos);
}

/*
 * Print a char in console launching bochs. This is usefull to copy and paste K
 * output, if duplication of k_console_printf on k_bochs_printf is setted in
 * bochs.h.
 */
void			k_bochs_print_char(unsigned char	c)
{
  if (PRINT_SPACE_FOR_NO_LEN_CHARS == 1)
    if (((c >= 0x7f) && (c <= 0x9f)) ||
	((c >= 0x1b) && (c <= 0x1f)) ||
	(c == 0x19) ||
	((c >= 0x0e) && (c <= 0x17)) ||
	(c == 0x0b) || (c == 0x0c) ||
	((c >= 0x01) && (c <= 0x07)))
      c = ' ';
  if (PRINT_WINDOW_CHARS == 0)
    if ((c >= 0xb0) && (c <= 0xdf))
      c = ' ';
  outb(K_BOCHS_IOPORT, c);
}
