#!/bin/sh
MTOOLSRC=bootloader/mtoolsrc
export MTOOLSRC

mcopy -bo k K:/kernel/k
cp k_grub.img k.img

