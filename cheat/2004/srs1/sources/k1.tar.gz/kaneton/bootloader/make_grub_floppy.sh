#!/bin/sh
GRUB=/sbin/grub

mformat A:

mmd A:/boot
mmd A:/boot/grub
mcopy /boot/grub/stage1 A:/boot/grub/
mcopy /boot/grub/stage2 A:/boot/grub/
mmd A:/kernel

$GRUB --batch << EOT || exit 1
install (fd0)/boot/grub/stage1 (fd0) (fd0)/boot/grub/stage2 p (fd0)/boot/grub/menu.lst
quit
EOT
mcopy -bo menu.lst A:/boot/grub/

