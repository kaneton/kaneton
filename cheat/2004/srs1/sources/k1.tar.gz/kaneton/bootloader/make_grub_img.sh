#!/bin/sh
GRUB=/sbin/grub
MTOOLSRC=mtoolsrc
export MTOOLSRC

dd if=/dev/zero of=k_grub.img bs=18k count=80

echo "drive K: file=\"k_grub.img\" 1.44M filter" > $MTOOLSRC
if mformat K: ; then
  : ;
else
  echo "drive K: file=\"k_grub.img\" 1.44M" > $MTOOLSRC
  if mformat K: ; then
    : ;
  else
    echo "drive K: file=\"k_grub.img\"" > $MTOOLSRC
    mformat K:
  fi
fi


mmd K:/boot
mmd K:/boot/grub
mcopy /boot/grub/stage1 K:/boot/grub/
mcopy /boot/grub/stage2 K:/boot/grub/
mmd K:/kernel

$GRUB --no-floppy --batch << EOT || exit 1
device (fd0) k_grub.img
install (fd0)/boot/grub/stage1 (fd0) (fd0)/boot/grub/stage2 p (fd0)/boot/grub/menu.lst
quit
EOT
mcopy -bo menu.lst K:/boot/grub/

