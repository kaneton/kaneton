/*
 * global variables
 */

unsigned char *exceptions[] =
{
  "divide-by-zero",
  "debug exception",
  "non-maskable interrupt",
  "breakpoint",
  "overflow",
  "bound exception",
  "invalid opcode",
  "FPU not available",
  "double fault",
  "coprocessor segment overrun",
  "invalid TSS",
  "segment not present",
  "stack exception",
  "general protection",
  "page fault",
  "reserved",
  "floating-point error",
  "alignment check",
  "machine check"
};

/*
 * Exception Handler
 */

void k_exception_handler()
{

  /*
   * vous pourriez par exemple afficher l'etat des registres ici.
   * dans ce cas il faut les sauvegarder sur la stack des que
   * l'interruption est recue pour enfin pouvoir les recuperer dans
   * cette fonction. c'est plus complique que ca n'en n'a l'air.
   * certains registres generaux ne peuvent etre lus simplement.
   * a vous de bien vous documenter ou de trouver une astuce :)
   */

}
