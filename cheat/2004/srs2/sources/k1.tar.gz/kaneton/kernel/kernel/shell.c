#include <keyboard.h>
#include <console.h>
#include <shell.h>
#include <asm.h>
#include "../klibc/klibc.h"




/*
 * Print Shell Help
 */
void 	k_shell_help()
{
	k_print_string("Affichage de l'aide\n");
	k_print_string("presse la touche ESC pour sortir\n");
	k_print_string("kbdfr pour changer le clavier en fr\n");
	k_print_string("kbden pour changer le clavier en en\n");
}


void 	kbden() {
	k_set_kbd_en();
}

void 	kbdfr() {
	k_set_kbd_fr();
}

/*
 * static variables
 */
static 	_t_cmds commands[] =
{
  	{ "help", k_shell_help },
	{ "kbden", kbden },
	{ "kbdfr", kbdfr },
  	{ (void *) 0, (void *) 0 }
};

void 	prompt(void) {
	k_print_string("$>");
}

/*
 * Demonstration Shell
 */
void k_shell()
{
	char cmd[KEYBOARD_BUFFER_SIZE];
	int i;
	
	for (i = 0; i < KEYBOARD_BUFFER_SIZE; i++)
		cmd[i] = 0x0;
		
  	while (1) {
		prompt();
		k_get_string(cmd, 0); 
		
		for (i = 0; commands[i].command; i++) {
			if (!strncmp(cmd, commands[i].command, strlen(commands[i].command))) {
	      			commands[i].function(cmd);
	      			break;
	    		}
		}
    		if(!commands[i].command) {
			k_panic("K: "); k_panic(cmd); k_panic(" : Command not found!\n");
    		}
	}
}
