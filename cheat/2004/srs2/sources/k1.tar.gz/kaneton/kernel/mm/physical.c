#include <multiboot.h>
#include <mm.h>
#include <console.h>
#include <gdt.h>
#include <idt.h>

/*
 * global variables
 */


/*
 * Initialize Physical Memory
 */

void k_init_physical_memory(multiboot_info_t *mbi)
{

}

/*
 * Allocate A Page Of Physical Memory
 */

void *k_page_alloc(unsigned int size)
{

  return ((void *) 0);
}

/*
 * Free A Page Of Physical Memory
 */

void k_page_free(void *addr)
{

}
