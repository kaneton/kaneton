#include <asm.h>
#include <mm.h>

/*
 * extern variables
 */

/*
 * Initialize Virtual Memory Tables And Enable Paging
 */

void k_init_virtual_memory()
{

}
