#ifndef _GDT_H
#define _GDT_H

/*
 * defines
 */

#define GDT_ADDR 0x20000
#define GDT_SIZE 256

#define GDT_LDT 0x1
#define GDT_GDT 0x0

#define GDT_GRANULAR 0x8

#define GDT_USE32 0x4
#define GDT_USE16 0x0

#define GDT_AVAILABLE 0x1

#define GDT_PRESENT 0x80

#define GDT_DPL3 0x60
#define GDT_DPL2 0x40
#define GDT_DPL1 0x20
#define GDT_DPL0 0x00

#define GDT_S 0x10

#define GDT_CODE 0x0a
#define GDT_DATA 0x02

typedef struct                  _s_gdt
{
  unsigned short                limit_00_15;
  unsigned short                base_00_15;
  unsigned char                 base_16_23;
  unsigned char                 type; /* P + DPL + S + Type*/
  unsigned char                 limit_16_19 : 4;
  unsigned char                 flags : 4; /* AVL +  0 + D/B + G*/
  unsigned char                 base_24_31;
}                               __attribute__ ((packed)) _t_gdt;

typedef struct                  _s_gdtr
{
  unsigned short                size;
  unsigned int                  address;
}                               __attribute__ ((packed)) _t_gdtr;

/*
 * prototypes
 */

unsigned short k_gdt_new_segment(unsigned int base, unsigned int length,
				 unsigned char type, unsigned char flags);
void k_gdt_del_segment(unsigned int entry);
void k_init_gdt();
unsigned short k_get_kernel_code_segment();
unsigned short k_get_kernel_data_segment();
unsigned short k_get_user_code_segment();
unsigned short k_get_user_data_segment();

#endif
