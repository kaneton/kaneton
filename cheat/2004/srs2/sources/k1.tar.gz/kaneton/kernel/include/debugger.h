#ifndef _DEBUGGER_H
#define _DEBUGGER_H

/*
 * defines
 */

/*
 * structures / types
 */

typedef struct _s_registers
{
  unsigned int _cr4;
  unsigned int _cr3;
  unsigned int _cr2;
  unsigned int _cr0;
  unsigned int _esp;
  unsigned int _ebp;
  unsigned int _eip;
  unsigned int _gs;
  unsigned int _fs;
  unsigned int _es;
  unsigned int _ss;
  unsigned int _ds;
  unsigned int _cs;
  unsigned int _eflags;
  unsigned int _edi;
  unsigned int _esi;
  unsigned int _edx;
  unsigned int _ecx;
  unsigned int _ebx;
  unsigned int _eax;
  unsigned int _exception;
} _t_registers;

/*
 * prototypes
 */

#endif
