#ifndef _KEYBOARD_H
#define _KEYBOARD_H

/*
 * defines
 */

#define KEYBOARD_BUFFER_SIZE 1024
#define KEYBOARD_STATUS_REGISTER 0x60

#define KEYBOARD_ESCAPE 0x01
#define KEYBOARD_F1 0x3b
#define KEYBOARD_F2 0x3c
#define KEYBOARD_F3 0x3d
#define KEYBOARD_F4 0x3e
#define KEYBOARD_F5 0x3f
#define KEYBOARD_F6 0x40
#define KEYBOARD_F7 0x41
#define KEYBOARD_F8 0x42
#define KEYBOARD_F9 0x43
#define KEYBOARD_F10 0x44
#define KEYBOARD_F11 0x57
#define KEYBOARD_F12 0x58
#define KEYBOARD_PRINT_SCREEN 0x37
#define KEYBOARD_PAUSE 0xe1
#define KEYBOARD_BACKSPACE 0xe
#define KEYBOARD_INSERT 0x52
#define KEYBOARD_HOME 0x47
#define KEYBOARD_PAGE_UP 0x49
#define KEYBOARD_DELETE 0x53
#define KEYBOARD_END 0x4f
#define KEYBOARD_PAGE_DOWN 0x51
#define KEYBOARD_UP 0x48
#define KEYBOARD_LEFT 0x4b
#define KEYBOARD_DOWN 0x50
#define KEYBOARD_RIGHT 0x4d

#define KEYBOARD_NUMPAD_SLASH 0x35
#define KEYBOARD_NUMPAD_ENTER 0x1c

#define KEYBOARD_SPECIAL_KEY 0xe0
#define KEYBOARD_CTRL 0x1d
#define KEYBOARD_LEFT_ALT 0x38
#define KEYBOARD_LEFT_SHIFT 0x2a
#define KEYBOARD_RIGHT_SHIFT 0x36
#define KEYBOARD_SCROLL_LOCK 0x46
#define KEYBOARD_NUM_LOCK 0x45
#define KEYBOARD_CAPS_LOCK 0x3a

#define KEYBOARD_MODE_ECHO_MASK 0x7
#define KEYBOARD_SPECIAL_KEY_MASK 0x6
#define KEYBOARD_CTRL_MASK 0x5
#define KEYBOARD_ALT_MASK 0x4
#define KEYBOARD_SHIFT_MASK 0x3
#define KEYBOARD_SCROLL_LOCK_MASK 0x2
#define KEYBOARD_NUM_LOCK_MASK 0x1
#define KEYBOARD_CAPS_LOCK_MASK 0x0

/*
 * structures / types
 */

typedef struct _s_keyboard
{
  unsigned char *_keyboard_table;
  unsigned char _buffer[KEYBOARD_BUFFER_SIZE];
  int _ptr;
  unsigned char _character;
} _t_keyboard;

/*
 * prototypes
 */
void k_set_kbd_fr();
void k_set_kbd_en();
void k_keyboard_isr();
void k_init_keyboard();
void k_get_char(unsigned char *c);
unsigned int k_get_string(unsigned char *buffer, unsigned int len);

#endif
