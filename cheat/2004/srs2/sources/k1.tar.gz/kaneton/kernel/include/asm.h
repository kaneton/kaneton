#ifndef _ASM_H
#define _ASM_H

/*
 * defines
 */

#define cli asm("cli"::)
#define sti asm("sti"::)

#endif
