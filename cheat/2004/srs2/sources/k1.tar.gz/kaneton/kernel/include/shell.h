#ifndef _SHELL_H
#define _SHELL_H

/*
 * structures / types
 */

typedef struct _s_cmds
{
  char *command;
  void (*function)(unsigned char *cmd);
} _t_cmds;

/*
 * prototypes
 */

void k_shell();

#endif
