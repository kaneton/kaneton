#ifndef _CONSOLE_H
#define _CONSOLE_H

/*
 * includes
 */

#include <keyboard.h>

/*
 * defines
 */

#define CONSOLE_VIDEO_ADDR 0xb8000
#define CONSOLE_VIDEO_LIMIT 0xb8fa0
#define CONSOLE_SIZE 0xfa0
#define CONSOLE_X 80
#define CONSOLE_Y 25
#define CONSOLE_VIDEO_MEMORY CONSOLE_X * CONSOLE_Y
#define CONSOLE_BPP 2
#define VGA_OUTPUT_REGISTER 0x3cc
#define VGA_OUTPUT_READ_REGISTER 0x3cc
#define CONSOLE_TABULATION 8
#define CONSOLE_DEFAULT_CURSOR_STATUS 1
#define CONSOLE_DEFAULT_ATTR 0x0f

#define CONSOLE_CURSOR_COLOR 0x00
#define CONSOLE_PANIC_ATTR 0x0c

#define CONSOLE_HEXADECIMAL_BASE_HIGH "0123456789ABCDEF"
#define CONSOLE_HEXADECIMAL_BASE_LOW "0123456789abcdef"
#define CONSOLE_DECIMAL_BASE "0123456789"
#define CONSOLE_OCTAL_BASE "01234567"
#define CONSOLE_BINARY_BASE "01"

#define CONSOLE_CURSOR_MASK 0x1

/*
 * structures / types
 */

typedef struct _s_console
{
  unsigned short _crt_addr_register;
  unsigned short _crt_data_register;
  unsigned char *_vga;
  unsigned char _attr;
  unsigned short _cursor;
} _t_console;

/*
 * prototypes
 */

void k_init_console();
void k_print_string(unsigned char *string);
void k_print_number(int number);
void k_print_char(unsigned char c);
void k_panic(char *message);
void k_del_char();

#endif
