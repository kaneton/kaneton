#ifndef _MM_H
#define _MM_H

/*
 * includes
 */

#include <multiboot.h>

/*
 * defines
 */

/*
 * structures / types
 */

/*
 * prototypes
 */

void k_init_physical_memory(multiboot_info_t *mbi);
void *k_page_alloc(unsigned int size);
void k_page_free(void *addr);

void k_init_virtual_memory();

#endif
