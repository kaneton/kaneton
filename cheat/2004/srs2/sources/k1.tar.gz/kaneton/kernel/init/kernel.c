#include <multiboot.h>
#include <keyboard.h>
#include <debugger.h>
#include <console.h>
#include <shell.h>
#include <gdt.h>
#include <idt.h>
#include <mm.h>

/*
 * Kernel Main Function
 */

void 	k_main(unsigned int mbmn, multiboot_info_t *mbi)
{
  	k_init_console();
	k_print_string("[init console] OK\n");
	
  	k_init_keyboard();
	k_print_string("[init keyboard] OK\n");
	
  	k_init_gdt();
	k_print_string("[init gdt] OK\n");
	
	k_init_physical_memory(mbi);
	k_print_string("[init physical memory] OK\n");

  	k_init_idt();
	k_print_string("[init idt] OK\n");
	
  	k_init_virtual_memory();
	k_print_string("[init virtual memory] OK\n");
	
	k_print_string("Chargement du shell ...\n");
  	
	k_shell();
}
