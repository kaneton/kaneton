#include <console.h>
#include <gdt.h>
#include <mm.h>

/*
 * global variables
 */

_t_gdt _gdt[GDT_SIZE];

/*
 * static variables
 */
static _t_gdtr gdtr;
static unsigned short kcs;		/* kernel code segment */
static unsigned short kds;		/* kernel data segment */
static unsigned short ucs;		/* user code segment */
static unsigned short uds;		/* user data segment */

/*
 * Add An Entry To Global Descriptor Table
 */
unsigned short k_gdt_new_segment(unsigned int base, unsigned int limit,
				 unsigned char type, unsigned char flags)
{
	int i;

  	for (i = 1; i < GDT_SIZE; i++) {
   		if (_gdt[i].type == 0) {
			_gdt[i].limit_00_15 = limit & 0xffff;
			_gdt[i].limit_16_19 = (limit & 0xf0000) >> 16;
			_gdt[i].base_00_15 = base & 0xffff;
			_gdt[i].base_16_23 = (base & 0xff0000) >> 16;
			_gdt[i].base_24_31 = (base & 0xff000000) >> 24;
			_gdt[i].type = type;
			_gdt[i].flags = flags & 0x0f;
			return (i << 3);
		}
  	}
  	return 0;
}

/*
 * Delete An Entry To Global Descriptor Table
 */

void 	k_gdt_del_segment(unsigned int entry)
{
	_gdt[entry].limit_00_15 = 0x0;
	_gdt[entry].limit_16_19 = 0x0;
	_gdt[entry].base_00_15 = 0x0;
	_gdt[entry].base_16_23 = 0x0;
	_gdt[entry].base_24_31 = 0x0;
	_gdt[entry].type = 0x0;
	_gdt[entry].flags = 0x0;
}

/*
 * Initialize And Load Global Descriptor Table
 */
void 	k_init_gdt()
{
	int i;
	
	//init de tous les segments � null
	for (i = 0; i < GDT_SIZE; i++) {
		_gdt[i].base_00_15 = 0x0;
		_gdt[i].base_16_23 = 0x0;
		_gdt[i].base_24_31 = 0x0;
		_gdt[i].limit_00_15 = 0x0;
		_gdt[i].limit_16_19 = 0x0;
		_gdt[i].flags = 0x0;
		_gdt[i].type = 0x0;
	}
	
	kcs = k_gdt_new_segment(0, 0xFFFFFFFF, 0x9a, 0x0C);

 	kds = k_gdt_new_segment(0, 0xFFFFFFFF, 0x92, 0x0C);

  	gdtr.address = (unsigned int)_gdt;
  	gdtr.size = GDT_SIZE * sizeof(_t_gdt);
  /*
       * code asm inline pour loader la gdt (repris du cours)
       */

	asm ("lgdt %0":: "m" (gdtr));
	
	asm ("mov %cr0,%eax\n"
        "or %ax,1\n"
        "mov %eax,%cr0\n");
				
	
  	asm ("pushl %0\n"
		"pushl $cs_jump\n"
		"lret\n"
		"cs_jump:\n"
		"mov %1, %%eax\n"
		"mov %%ax, %%ds\n"
		"mov %%ax, %%es\n"
		"mov %%ax, %%fs\n"
		"mov %%ax, %%gs\n"
		"mov %%ax, %%ss"
		: : "g" (kcs), "g" (kds));
}

unsigned short k_get_kernel_code_segment() {
	return kcs;
}

unsigned short k_get_kernel_data_segment() {
	return kds;
}

unsigned short k_get_user_code_segment() {
	return ucs;
}

unsigned short k_get_user_data_segment() {
	return uds;
}
