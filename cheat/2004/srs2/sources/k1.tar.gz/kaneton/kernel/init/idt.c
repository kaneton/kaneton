#include <idt.h>
#include <gdt.h>
#include <asm.h>
#include <io.h>
#include <console.h>

/*
 * global variables
 */
_t_idt 	_idt[IDT_SIZE];
_t_idtr idtr;
unsigned short slaveMask, masterMask;
unsigned int ticks = 0;

/*
 * static functions
 */

static void k_init_pic();


/*
 * Initialize Programmable Interrupt Controller
 */
#define PIC1 0x20
#define PIC2 0xA0

#define ICW1 0x11
#define ICW4 0x03

#define SYS_TICKS 0x01
#define SYS_PCI 0x02

static void k_init_pic()
{
  /* send ICW1 */
  outb(PIC1, ICW1);
  outb(PIC2, ICW1);

  /* send ICW2 */
  outb(PIC1 + 1, 0x20);/* remap */
  outb(PIC2 + 1, 0x28);/*  pics */

  /* send ICW3 */
  outb(PIC1 + 1, 0x04);/* IRQ2 -> connection to slave */
  outb(PIC2 + 1, 0x02);

  /* send ICW4 */
  outb(PIC1 + 1, ICW4);
  outb(PIC2 + 1, ICW4);

  /* disable all IRQs */
  outb(PIC1+1, 0xff);
  //outb(PIC2+1, 0xff);

  slaveMask = 0xff;
  masterMask = 0xff;

  sti;

}

/*
 * Disable An IRQ
 */
void k_disable_irq(unsigned short irq)
{
  masterMask = masterMask | (1 << irq);

  if (irq >= 8)
    slaveMask = slaveMask | (1 << (irq - 8));
  outb(PIC1+1, masterMask);
  outb(PIC2+1, slaveMask);
}

/*
 * Enable An IRQ
 */
void k_enable_irq(unsigned short irq)
{
  masterMask = masterMask & ~(1 << irq);

  if (irq >= 8) {
    //enable IRQ2
    masterMask = masterMask & 0xfb;
    slaveMask = slaveMask & ~ (1 << (irq - 8));
  }
  outb(PIC1+1, masterMask);
  outb(PIC2+1, slaveMask);
}

/*
 * Add An Entry To Interrupt Descriptor Table
 * pas compris � quoi sert level ...
 */
void k_idt_new_interrupt(unsigned short entry, unsigned int offset,
			 unsigned short segment, unsigned short type,
			 unsigned short level)
{
  _idt[entry].__offset = offset & 0xffff;
  _idt[entry]._offset = (offset & 0xffff0000) >> 16;
  _idt[entry]._segment = segment;
  _idt[entry]._type = type;
}




void timer_isr()
{
  ticks++;
  asm volatile("leave");
  asm volatile("iret");
}

void sys_ticks()
{
  asm("mov %0,%%eax"::"m" (ticks));
}
/*
 * Initiliaze And Load Interrupt Descriptor Table
 */
void 	k_init_idt()
{
	int i;
	
	for (i = 0; i < IDT_SIZE; i++) {
	  _idt[i].__offset = 0x0;
		_idt[i]._offset = 0x0;
		_idt[i]._segment = 0x0;
		_idt[i]._type = 0x0;
	}
	
	//Exception
	k_idt_new_interrupt(0, (unsigned int)_k_int_00, k_get_kernel_code_segment(),
		    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(1, (unsigned int)_k_int_01, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(2, (unsigned int)_k_int_02, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(3, (unsigned int)_k_int_03, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(4, (unsigned int)_k_int_04, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(5, (unsigned int)_k_int_05, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(6, (unsigned int)_k_int_06, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(7, (unsigned int)_k_int_07, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(8, (unsigned int)_k_int_08, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(9, (unsigned int)_k_int_09, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(10, (unsigned int)_k_int_10, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(11, (unsigned int)_k_int_11, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(12, (unsigned int)_k_int_12, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(13, (unsigned int)_k_int_13, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(14, (unsigned int)_k_int_14, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(15, (unsigned int)_k_int_15, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(16, (unsigned int)_k_int_16, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	k_idt_new_interrupt(17, (unsigned int)_k_int_17, k_get_kernel_code_segment(),
                    IDT_TRAPGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
	
	//Interruption	
	k_idt_new_interrupt(33, (unsigned int)_k_irq_01, k_get_kernel_code_segment(),
                    IDT_INTGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
										
	k_idt_new_interrupt(32, (unsigned int)timer_isr, k_get_kernel_code_segment(),
                    IDT_INTGATE | IDT_PRESENT | IDT_DPL0 | IDT_32, 0);
  	idtr._addr = (unsigned int)_idt;
  	idtr._size = IDT_SIZE * sizeof(_t_idt);
	asm volatile("lidt %0":: "m" (idtr));
	k_init_pic();
  	k_enable_irq(0);
  	k_enable_irq(1);
}
