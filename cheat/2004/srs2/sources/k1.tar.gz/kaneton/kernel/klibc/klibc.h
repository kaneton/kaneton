unsigned int strlen(unsigned char *str);
unsigned int strcmp(unsigned char *str_1, unsigned char *str_2);
unsigned char *strncpy(unsigned char *dst, unsigned char *src, unsigned int len);
unsigned int strncmp(unsigned char *str_1, unsigned char *str_2, unsigned int len);
