unsigned int 		strlen(unsigned char *str)
{
	unsigned int 	size;	

	for (size = 0; str[size] && str[size] != '\n'; size++);

  	return size;
	
}

unsigned int 	strcmp(unsigned char *str_1, unsigned char *str_2)
{
	for (;*str_1 == *str_2 && *str_1 != 0; str_1++, str_2++);
	
	if (str_1 != str_2)
		return 1;
	return 0;
}

unsigned char 	*strncpy(unsigned char *dst, unsigned char *src, 
			unsigned int len)
{
	unsigned int	i;
	
	for (	i = 0; i < len && src[i] != 0 && src[i] != '\n'; i++)
		dst[i] = src[i];
	dst[i] = 0;
  
	return dst;
}

unsigned int 	strncmp(unsigned char *str_1, unsigned char *str_2, 
			unsigned int len)
{
	int 				i;
	
	for (	i = 0; 
		*str_1 == *str_2 && i < len && *str_1 != 0; 
		str_1++, str_2++, i++);

	if (*str_1 == *str_2)
		return 0;
	return 1;
}

