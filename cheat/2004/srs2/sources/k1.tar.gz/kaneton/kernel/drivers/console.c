#include <keyboard.h>
#include <console.h>
#include <asm.h>
#include <io.h>

#include "../klibc/klibc.h"

/*
 * extern variables
 */

extern unsigned char _keyboard_qwerty_table[];

/*
 * static variables
 */
static _t_console _console;

/*
 * Clear screen
 */
void 	k_cls ()
{
	int i;
	
	for (i = 0; i < CONSOLE_SIZE; i += 2) {
		_console._vga[i] = 0;
		_console._vga[i + 1] = 0x07; /* without intensity or 0x0f with */
	}
}

/*
 * Initialize Console: cursor, video memory, color attributs
 */
void	k_init_console()
{
  	_console._crt_addr_register = 0;
  	_console._crt_data_register = 0;	
	_console._vga = (unsigned char *)CONSOLE_VIDEO_ADDR;
  	_console._attr = CONSOLE_DEFAULT_ATTR;
  	_console._cursor = 0;

  	k_cls();
	
	k_print_string("le noyau a boote oufff ;-)\n\n");
}

/*
 * Print a String to the Console Screen
 */
void 	k_print_string(unsigned char *string)
{
  	int i;

  	for (i = 0; string[i] != 0; i++)
		k_print_char(string[i]);
}

/*
 *  Print a Number to the Console Screen
 */
void 	k_print_number(int number)
{
 	unsigned int 	puissance_de_dix;

  	if (number < 0) {
    		k_print_char('-');
    		number = -number;
  	}
  
	puissance_de_dix = 1;
	for (; number / puissance_de_dix >= 10; puissance_de_dix *= 10);
	
	for (; puissance_de_dix != 1; puissance_de_dix /= 10) {
		k_print_char('0' + number / puissance_de_dix);
		number %= puissance_de_dix;
	}
	k_print_char('0' + number);
}

/*
 * Print a Char to the Console Screen
 */
void 	k_print_char(unsigned char c)
{
	if (_console._cursor == CONSOLE_VIDEO_MEMORY * 2) {
		_console._cursor = 0;
		k_cls();
	}
  	switch(c) {
    	case '\n':
		_console._vga[_console._cursor+2] = 0;
      		_console._cursor = (_console._cursor + 160) - (_console._cursor % 160);
      		break;
    	default:
      		_console._vga[_console._cursor++] = c;
      		_console._vga[_console._cursor++] = _console._attr;
      		break;
    	}
  	_console._vga[_console._cursor + 1] = CONSOLE_CURSOR_COLOR;
}

/*
 * Print A Panic Message And Loop
 */
void 	k_panic(char *message)
{
  	unsigned char current_attr;

  	current_attr = _console._attr;
  	_console._attr = CONSOLE_PANIC_ATTR;
  	
	k_print_string(message);

  	_console._attr = current_attr;
}

/* 
 *Delete a char on the screen, when touch backspace is tape
*/
void 	k_del_char()
{
  	_console._vga[_console._cursor] = 0;
  	_console._vga[_console._cursor + 1] = 0;
	
  	_console._cursor = _console._cursor - 2;
	
  	_console._vga[_console._cursor] = 0;
  	_console._vga[_console._cursor + 1] = CONSOLE_CURSOR_COLOR;
}
