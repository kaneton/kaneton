#include <keyboard.h>
#include <console.h>
#include <io.h>

#include "../klibc/klibc.h"

/*
 * global variables
 */

_t_keyboard 	_keyboard;
unsigned char 	reading;

/*
 * extern variables
 */

extern unsigned char _keyboard_qwerty_table[];
extern unsigned char _keyboard_azerty_table[];
extern unsigned char _keyboard_num_table[];

void 	k_set_kbd_fr() {
	_keyboard._keyboard_table = _keyboard_azerty_table;
}

void 	k_set_kbd_en() {
	_keyboard._keyboard_table = _keyboard_qwerty_table;
}

/*
 * Keyboard Handler
 */
void 	k_keyboard_isr()
{
	unsigned char key;
	
	/* check KEYBOARD_STATUS_REGISTER */
	key = inb(KEYBOARD_STATUS_REGISTER);

	/*k_print_string("OUI");*/
	k_get_char(&key);
	if (key != 255)
		k_print_char(key);
}

/*
 * Init keyboard
 */
void 	k_init_keyboard()
{
	int	i;
  
	_keyboard._keyboard_table = _keyboard_qwerty_table;
	for (i = 0; i < KEYBOARD_BUFFER_SIZE; i++)
		_keyboard._buffer[i] = 0;
	_keyboard._ptr = 0;
	_keyboard._character = 0;
}

/*
 * Get A Printable Character
 */
void 	k_get_char(unsigned char *c) {
	switch (*c) {
		case KEYBOARD_BACKSPACE : {
			*c = 255;
			if (_keyboard._ptr != 0) { //nothing to delete if we are at the beginning
				_keyboard._buffer[_keyboard._ptr] = 0;
				_keyboard._ptr--;
				k_del_char();
			}
		}
		break;
		case KEYBOARD_ESCAPE :{
			k_halt();
		}
		break;
		case 0x1c : {
			reading = 1;
		}
		default : {
			if (*c < 0x58) { //scancode max of the main keyboard, I don't manage keypad and numpad already
				*c = _keyboard._keyboard_table[*c * 2];
				if (_keyboard._ptr >= KEYBOARD_BUFFER_SIZE - 1 && *c != '\n')
					k_panic("\n[KEYBOARD] Probleme dans k_get_char : _keyboard.ptr >= KEYBORD_BUFFER_SIZE\n");
				else {
					_keyboard._character = *c;
					_keyboard._buffer[_keyboard._ptr++]= *c;
				}
			} else
				*c = 255;
		}
	}
}

/*
 * Get A Printable String
 */
unsigned int 	k_get_string(unsigned char *buffer, unsigned int len)
{
  	int 	i;
	
  	_keyboard._ptr = 0;
  	for (i = 0; i < KEYBOARD_BUFFER_SIZE; i++)
		_keyboard._buffer[i] = 0;
	
	reading = 0;
  	while(!reading) {
  	}
	
  	_keyboard._ptr=0;
  	strncpy(buffer, _keyboard._buffer, strlen(_keyboard._buffer));

  	return (_keyboard._ptr);
}
