/*
** main.c for s_list in /tmp
**
** Made by damien laniel
** Login   <laniel_d@epita.fr>
**
** Started on  Tue Sep 30 21:59:54 2003 damien laniel
** Last update Sun Mar  6 23:30:07 2005 Damien Laniel
*/

#include "../../../src/lib/list/list.h"
#include "../../../src/lib/console/console.h"
#include "../../../src/include/kaneton/types.h"

#define STRING_SIZE	8
#define NODE_SIZE	(sizeof(t_list) + (STRING_SIZE + 1) * sizeof(char))
#define LIST_ADDR	0x300000
#define NEW_NODE_ADDR	list_search_free_phys_space(LIST_ADDR, NODE_SIZE)

static int	copy_string(const void * source, void * destination)
{
  char		*sour = (char *) source;
  char		*dest = (char *) destination;
  unsigned int	i = 0;

  for (i = 0; sour[i] && i < STRING_SIZE; ++i)
    dest[i] = sour[i];
  dest[i] = '\0';
  return 0;
}

static int	cmp_string(const void * data, const void * data2)
{
  char		*str = (char *) data;
  char		*str2 = (char *) data2;
  unsigned int	i = 0;

  for (i = 0; str[i] && str2[i] && i < STRING_SIZE; ++i)
    if (str[i] > str2[i])
      return 1;
    else
      if (str[i] < str2[i])
	return -1;
  return 0;
}

static void	clear_string(void * data)
{
  char		*str = (char *) data;
  unsigned int	i = 0;

  for (i = 0; i < STRING_SIZE; ++i)
    str[i] = 0;
}

static void	print_string(const void * msg)
{
  cons_print_string((char *) msg);
}

static void	init(char * msg)
{
  list_init(LIST_ADDR);
  init_ttys();
  cons_clear_screen();
  cons_print_string(msg);
  cons_goto_next_line();
  cons_goto_next_line();
}

static void	add(t_list ** list, void * data)
{
  char *	str = (char *) data;
  t_paddr	node_addr;

  node_addr = NEW_NODE_ADDR;
  list_add_item_sorted(list, node_addr, str, copy_string, cmp_string);
}

static void	delete(t_list ** list, void * data)
{
  char *	str = (char *) data;

  list_delete_item(list, str, cmp_string, clear_string);
}

static void	print_list(t_list * list, char * msg)
{
  cons_print_string(msg);
  list_print(list, print_string);
  cons_goto_next_line();
}

static void	find_item(t_list * list, void * data)
{
  char *	data_searched = (char *) data;
  void *	data_found;

  data_found = list_find_item(list, data_searched, cmp_string);
  cons_print_string("item found : ");
  print_string(data_found);
  cons_goto_next_line();
}

int	main(void)
{
  char *	msg = "Test of liblist";
  t_list *	list = NULL;

  init(msg);

  add(&list, "1st node");
  add(&list, "2nd node");
  add(&list, "3rd node");
  delete(&list, "2nd node");
  add(&list, "4th node");
  delete(&list, "1st node");
  add(&list, "1st node");
  add(&list, "8th node");
  add(&list, "6th node");
  print_list(list, "list : ");

  find_item(list, "3rd node");

  list_clear(&list, clear_string);
  print_list(list, "empty list : ");

  while(1)
    ;
  return 0;
}
