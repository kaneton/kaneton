/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon May 16 20:16:33 2005 Damien Laniel
** Last update Tue Nov  8 00:25:31 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "dlist.h"
/* #include "../console/console.h" */
#include "../../../include/kaneton/types.h"
#include "../../../lib/libc/libc.h"
/* #include "../../kaneton/malloc/kmalloc.h" */

unsigned int	set_dlist_size(const t_set_dlist *list)
{
  unsigned int	size = 0;

  while (list)
    {
      size++;
      list = list->next;
    }
  return size;
}

/* static t_set_dlist	*set_dlist_create_node(void *data) */
/* { */
/*   t_set_dlist	*list = NULL; */

/*   if (!(list = malloc(sizeof (t_set_dlist), KASID))) */
/*     return NULL; */
/*   list->data = data; */
/*   list->next = NULL; */
/*   list->prev = NULL; */

/*   return list; */
/* } */

void		set_dlist_add_item_head(t_set_dlist **list, void *data)
{
  t_set_dlist	*new = NULL;

  if ((new = malloc(sizeof (t_set_dlist))))
    {
      new->data = data;
      new->next = *list;
      new->prev = 0;
      (*list)->next->prev = new;
      *list = new;
    }
}

static t_set_dlist	*set_dlist_create_node2(void *data)
{
  t_set_dlist	*list = NULL;

  if (!(list = malloc(sizeof (t_set_dlist))))
    return NULL;
  list->data = data;
  list->next = NULL;
  list->prev = NULL;
  return list;
}

void		set_dlist_add_item_end(t_set_dlist **list, void *data)
{
  t_set_dlist	*tmp = NULL;

  if (*list)
    {
      tmp = *list;
      while (tmp->next)
	tmp = tmp->next;
      tmp->next = set_dlist_create_node2(data);
      tmp->next->prev = tmp;
    }
  else
    {
      *list = set_dlist_create_node2(data);
      (*list)->prev = 0;
    }
}

static t_set_dlist	*set_dlist_create_node3(void *data)
{
  t_set_dlist	*list;

  if (!(list = malloc(sizeof (t_set_dlist))))
    return NULL;
  list->data = data;
  list->next = NULL;

  return list;
}

void		set_dlist_add_item_sorted(void		*data,
				      t_set_dlist		**list,
				      t_set_dlist_cmp_func	cmp_func)
{
  t_set_dlist	*tmp;
  t_set_dlist	*tmpnext;

  tmp = *list;
  while (tmp && cmp_func(tmp->data, data) <= 0)
    tmp = tmp->next;
  tmpnext = tmp->next;
  tmp->next = set_dlist_create_node3(data);
  tmp->next->next = tmpnext;
}

void		set_dlist_delete_item(t_set_dlist	**list,
				   const void	*data,
				   t_set_dlist_cmp_func	cmp_func,
				   t_set_dlist_free_func	free_func)
{
  t_set_dlist	*cur_node = *list;
  t_set_dlist	*prev_node = NULL;

  if (cur_node)
    {
      if (!(cmp_func(cur_node->data, data)))
	{
	  *list = cur_node->next;
	  if (free_func)
	    free_func(cur_node->data);
	  cur_node->data = NULL;
	  cur_node->next = NULL;
	  return;
	}
      for (prev_node = cur_node, cur_node = cur_node->next;
	   cur_node;
	   prev_node = cur_node, cur_node = cur_node->next)
	{
	  if (!(cmp_func(cur_node->data, data)))
	    {
	      prev_node->next = cur_node->next;
	      if (free_func)
		free_func(cur_node->data);
	      cur_node->data = NULL;
	      cur_node->next = NULL;
	      return;
	    }
	}
    }
}

void	*set_dlist_find_item_eq(const t_set_dlist	*list,
			    const void		*data,
			    t_set_dlist_cmp_func		cmp_func)
{
  while (list)
    {
      if (!(cmp_func(list->data, data)))
	return list->data;
      list = list->next;
    }
  return NULL;
}

void		set_dlist_free(t_set_dlist **list, t_set_dlist_free_func free_func)
{
  t_set_dlist	*tmp = NULL;

  if (list)
    if (*list)
      {
	while ((*list)->next)
	  {
	    free_func((*list)->data);
	    tmp = (*list)->next;
	    free(*list);
	    *list = tmp;
	  }
	free_func((*list)->data);
	free(*list);
	*list = NULL;
      }
}

void		set_dlist_sort(t_set_dlist **list, t_set_dlist_cmp_func cmp_func)
{
  t_set_dlist	*new = 0;
  t_set_dlist	*tmp = 0;
  void		*max = 0;
  t_set_dlist	*next2 = 0;

  while (*list)
    {
      max = (*list)->data;
      tmp = *list;
      while (tmp)
	{
	  if (!(cmp_func(tmp->data, max)))
	    max = tmp->data;
	  tmp = tmp->next;
	}
      next2 = tmp->next;
      next2 = new->next;
      new = next2;
      tmp->next = tmp->next->next;
    }
  *list = new;
}

void		set_dlist_concat(t_set_dlist **list_a, t_set_dlist *list_b)
{
  t_set_dlist	*tmp;

  tmp = *list_a;
  while (tmp->next)
    tmp = tmp->next;
  tmp->next = list_b;
  list_b->prev = tmp;
}

void		set_dlist_shift(t_set_dlist **list)
{
  t_set_dlist	*tmp;

  tmp = *list;
  while (tmp->next)
    tmp = tmp->next;
  tmp->next = *list;
  (*list)->prev = tmp;
  *list = (*list)->next;
  (*list)->prev = 0;
  tmp->next->next = 0;
}

static void	set_dlist_add_item_head2(t_set_dlist **list, t_set_dlist *new)
{
  new->next = *list;
  new->prev = NULL;
  if (new->next)
    new->next->prev = new;
  *list = new;
}

void		set_dlist_rev(t_set_dlist **list)
{
  t_set_dlist	*newlist = NULL;
  t_set_dlist	*tmp = NULL;
  t_set_dlist	*tmp2 = NULL;

  if (list && *list)
    {
      tmp = *list;
      while (tmp)
	{
	  tmp2 = tmp->next;
	  tmp->next = 0;
	  set_dlist_add_item_head2(&newlist, tmp);
	  tmp = tmp2;
	}
      *list = newlist;
    }
}

static void	set_dlist_sort2(t_set_dlist **list, t_set_dlist_cmp_func cmp_func)
{
  t_set_dlist	*new = 0;
  t_set_dlist	*tmp = 0;
  void		*max = 0;
  t_set_dlist	*next2 = 0;

  while (*list)
    {
      max = (*list)->data;
      tmp = *list;
      while (tmp)
	{
	  if (!(cmp_func(tmp->data, max)))
	    max = tmp->data;
	  tmp = tmp->next;
	}
      next2 = tmp->next;
      next2 = new->next;
      new = next2;
      tmp->next = tmp->next->next;
    }
  *list = new;
}

void		set_dlist_merge(t_set_dlist	**list_a,
			   t_set_dlist	*list_b,
			   t_set_dlist_cmp_func	cmp_func)
{
  t_set_dlist	*tmp;
  t_set_dlist	*pouet;

  tmp = *list_a;
  while (tmp->next)
    tmp = tmp->next;
  if (!(pouet = malloc(sizeof (t_set_dlist))))
    return;
  pouet->data = list_b->data;
  pouet->next = list_b->next;
  tmp->next = pouet;

  set_dlist_sort2(list_a, cmp_func);
}

void	set_dlist_print(const t_set_dlist *list, t_set_dlist_display_func display_func)
{
  while (list)
    {
      display_func(list->data);
      list = list->next;
    }
}

void	*set_dlist_get_item_head(t_set_dlist *list)
{
  return (NULL == list) ? NULL : list->data;
}

void		*set_dlist_get_item_end(t_set_dlist *list)
{
  t_set_dlist	*cursor = list;

  if (NULL == cursor)
    return NULL;
  while (NULL != cursor->next)
    cursor = cursor->next;
  return cursor->data;
}

void		*set_dlist_find_prev_item(t_set_dlist *list, const void *data, t_set_dlist_cmp_func cmp_func)
{
  for (; NULL != list; list = list->next)
    if (!(cmp_func(list->data, data)))
      return (NULL == list->prev) ? NULL : list->prev->data;
  return NULL;
}

void		*set_dlist_find_next_item(t_set_dlist *list, const void *data, t_set_dlist_cmp_func cmp_func)
{
  for (; NULL != list; list = list->next)
    if (!(cmp_func(list->data, data)))
      return (NULL == list->next) ? NULL : list->next->data;
  return NULL;
}
