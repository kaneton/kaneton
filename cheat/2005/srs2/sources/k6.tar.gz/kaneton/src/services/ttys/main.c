/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Tue Nov 15 02:07:07 2005 Nicolas Clermont
** Last update Sat Dec  3 20:11:13 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../lib/libc/libc.h"
#include "display.h"

/*!
 * Main function for the console service
 */
int		main()
{
/*   t_msg		*msg_rcv; */
/*   int		i; */
/*   int           attr; */

/*   ttys_init(); */
/* /\*   tty_status_set(TTY_ENABLE); *\/ */
/*   cons_print_string("TTYs server is initialized\n"); */

/*   while (1) */
/*     { */
/*       msg_rcv = wait_msg(); */
/*       if (msg_rcv) */
/* 	{ */
/* 	  if (msg_rcv->data) */
/*             { */
/* 	      switch (*(char *)(msg_rcv->data)) */
/* 		{ */
/* 		case 0: */
/* 		  for (i = 0; i < msg_rcv->data_size; i++) */
/* 		    cons_print_char(((char *)(msg_rcv->data))[i]); */
/* 		  break; */
/* 		case 1: */
/* 		  tty_clear_screen(); */
/* 		  break; */
/* 		case 2: */
/* 		  attr = get_attributes(); */
/* 		  set_char_attributes(*(char *)(msg_rcv->data + 1)); */
/* 		  for (i = 2; i < msg_rcv->data_size; i++) */
/* 		    cons_print_char(((char *)(msg_rcv->data))[i]); */
/* 		  set_char_attributes(attr); */
/* 		  break; */
/* 		default: */
/* 		  break; */
/* 		} */
/* 	    } */
/* 	  else */
/* 	    { */
/* 	      cons_print_string("Serveur TTYs: data null\n"); */
/* 	      while (1); */
/* 	    } */
/* 	} */
/*       else */
/* 	cons_print_string("Serveur TTYs: j'ai pas recu de msg\n"); */
/*     } */
  t_msg         *msg_rcv;
  int           i;
  int           attr;

  ttys_init();
  /*   tty_status_set(TTY_ENABLE); */
  cons_print_string("TTYs server is initialized\n");

  while (1)
    {
      msg_rcv = wait_msg();
      if (msg_rcv)
        {
          if (msg_rcv->data)
            {
              switch (*(char *)(msg_rcv->data))
                {
                case 0:
                  for (i = 0; i < msg_rcv->data_size; i++)
                    cons_print_char(((char *)(msg_rcv->data))[i]);
                  break;
                case 1:
                  tty_clear_screen();
                  break;
                case 2:
                  attr = get_attributes();
                  set_char_attributes(*(char *)(msg_rcv->data + 1));
                  for (i = 2; i < msg_rcv->data_size; i++)
                    cons_print_char(((char *)(msg_rcv->data))[i]);
                  set_char_attributes(attr);
                  break;
                default:
                  break;
                }
            }
          else
            {
              cons_print_string("Serveur TTYs: data null\n");
              while (1);
            }
        }
      else
        cons_print_string("Serveur TTYs: j'ai pas recu de msg\n");
    }

  return 0;
}
