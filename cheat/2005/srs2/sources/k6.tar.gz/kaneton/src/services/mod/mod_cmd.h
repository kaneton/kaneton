/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sun Nov 13 17:07:45 2005 Nicolas Clermont
** Last update Sat Dec  3 20:33:08 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef _MOD_CMD_H_
# define _MOD_CMD_H_

# include "../../lib/libc/libc.h"

# define MOD_CMD_PS		0
# define MOD_CMD_GET_MODID	1
# define MOD_CMD_GET_TSKID	2
# define MOD_CMD_EXEC		3


int	mod_cmd_ps(t_msg *msg_rcv);

int	mod_cmd_get_modid(t_msg *msg_rcv);

int	mod_cmd_get_tskid(t_msg *msg_rcv);

int	mod_cmd_exec(t_msg *msg_rcv);

#endif	/* !_MOD_CMD_H_ */
