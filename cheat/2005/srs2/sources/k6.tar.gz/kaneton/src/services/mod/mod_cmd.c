/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sun Nov 13 17:15:32 2005 Nicolas Clermont
** Last update Sun Dec  4 02:50:34 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "elf.h"
#include "mod.h"
#include "mod_cmd.h"
#include "mod_libc.h"
#include "set/set.h"
#include "../../lib/libc/libc.h"
#include "../../lib/libc/string.h"

extern t_setid	mod_setid;

int		mod_cmd_ps(t_msg *msg_rcv)
{
  t_iterator	it_mod;
  t_module	*mod;
  t_tskid	tskid;
  t_msg         *answer;

  my_printf("MODULE NAME (COMMAND)\tMODID\tTSKID\n");
  SET_FOREACH(FOREACH_FORWARD, mod_setid, &it_mod)
    {
      mod_get(ITERATOR_ID(&it_mod), &mod);
      tskid = mod_as_modid_taskid(mod->modid);
      my_printf("%s\t%d\t%d\n", mod->name, mod->modid, tskid);
    }
  answer = create_msg(msg_rcv->src, sizeof (unsigned int));
  *(unsigned int *)(answer->data) = 0;
  send_msg(answer);

  return 0;
}

int		mod_cmd_get_modid(t_msg *msg_rcv)
{
  t_iterator	it_mod;
  t_module	*mod;
  t_msg		*answer;

  SET_FOREACH(FOREACH_FORWARD, mod_setid, &it_mod)
    {
      mod_get(ITERATOR_ID(&it_mod), &mod);
      if (!strcmp((char *)(msg_rcv->data + 1), mod->name))
	{
	  answer = create_msg(msg_rcv->src, sizeof (unsigned int));
	  *(unsigned int *)(answer->data) = mod->modid;
	  send_msg(answer);
	  break;
	}
    }

  return 0;
}

int		mod_cmd_get_tskid(t_msg *msg_rcv)
{
  t_iterator	it_mod;
  t_module	*mod;
  t_msg		*answer;
  t_tskid	tskid;

  SET_FOREACH(FOREACH_FORWARD, mod_setid, &it_mod)
    {
      mod_get(ITERATOR_ID(&it_mod), &mod);
      if (!strcmp((char *)(msg_rcv->data + 1), mod->name))
	{
	  tskid = mod_as_modid_taskid(mod->modid);
	  answer = create_msg(msg_rcv->src, sizeof (unsigned int));
	  *(unsigned int *)(answer->data) = tskid;
	  send_msg(answer);
	  break;
	}
    }

  return 0;
}

int		mod_cmd_exec(t_msg *msg_rcv)
{
  t_module	*mod;
  t_modid	modid;
  t_tskid	tskid;
  t_thrid	thrid;
  t_asid	asid;
  t_msg         *answer;
  /*   t_vaddr	mod_vaddr; */
  /*   t_paddr	pd_paddr; */
  /*   t_thrctx	thrctx; */

  answer = create_msg(msg_rcv->src, sizeof (unsigned int));
  /*
  ** On recup l'id du module si il est deja en RAM.
  ** Sinon on le charge.
  */
  mod_add((char *)(msg_rcv->data + 1), LIFETIME_INFINITE, &modid);
  if (mod_get(modid, &mod))
    *(unsigned int *)(answer->data) = 1;
  else
    {
      mod_task_create(mod, &tskid, &asid, &thrid);
      *(unsigned int *)(answer->data) = 0;
    }
  send_msg(answer);
  /*
  ** On cree le contexte d'execution du nouveau process
  */
  /*   mod_task_rsv(CLASS_USER, BEHAV_TIMESHARING, PRIOR_TIMESHARING, &tskid); */
  /*   mod_as_rsv(&asid); */
  /*   mod_as_attach(asid, tskid); */
  /*   mod_thread_rsv(PRIOR_TIMESHARING, &thrid); */
  /*   mod_thread_attach(thrid, tskid); */
  /*   mod_thread_stack(thrid, 1); */
  /*  /\* Debut mod_load *\/ */
  /*   mod_vm_rsv(asid, &mod_vaddr, mod->npages, VM_FLAG_ANY); */
  /*   mod_vm_map(asid, mod->paddr, mod_vaddr, mod->npages); */
  /*   mod_as_set_modid(asid, modid); */
  /*   /\* Fin mod_load *\/ */
  /*   mod_as_get_pd_paddr(asid, &pd_paddr); */
  /*   thrctx.pc = mod_he_get_param(pd_paddr, mod_vaddr, E_ENTRY); */
  /*   thrctx.sp = mod_thread_get_stack_addr(thrid) + PAGE_SIZE; */
  /*   mod_thread_load(thrid, &thrctx); */
  /*   mod_thread_run(thrid); */

  return 0;
}
