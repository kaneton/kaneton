/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Wed Nov 23 22:59:30 2005 Nicolas Clermont
** Last update Sat Dec  3 20:39:13 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "shell.h"
#include "../../lib/libc/mod.h"

static int	my_keylen(char *command)
{
  int		len;

  len = 0;
  if (*command == '|')
    return 1;
  while ((*command != ' ') && (*command != '\0') &&
	 (*command != '|') && (*command != '&'))
  {
    command++;
    len++;
  }
  return len;
}

static t_built	*find(char *name, t_built **gl_builts)
{
  t_built	*bl;

  for (bl = *gl_builts; bl; bl = bl->next)
    {
      if (strcmp(bl->name, name) == 0)
	{
	  return bl;
	}
    }
  return NULL;
}

static int	my_execvp(char *args, t_built **gl_builts)
{
  t_built	*t;
  char		*key, *tmp;

  gl_builts = gl_builts;
  tmp = malloc(my_keylen(args) + 1);
  key = tmp;
  while ((*args != ' ') && (*args != '\0'))
    *tmp++ = *args++;
  *tmp = '\0';
  /* Verifie si la cmd est une builtin */
  if ((t = find(key, gl_builts)) == NULL)
    return 0;
  t->func(args);

  return 1;
}

static void	fill_com(char **com, char *command)
{
  char		*tmp, *head;
  int		i;

  i = 1;
  while ((*command != '\0') && (*command != '>'))
  {
    tmp = malloc(my_keylen(command) + 1);
    head = tmp;
    if (*command == '|')
      *tmp++ = *command++;
    else
      while ((*command != '>') && (*command != ' ') && (*command != '\0') &&
	     (*command != '|') && (*command != '&'))
	*tmp++ = *command++;
    if ((*command == ' ') || (*command == '&'))
      command++;
    *tmp = '\0';
    com[i] = strdup(head);
    if (!strcmp(com[i], "\0"))
	i++;
  }
  com[i] = 0;
}

static void	empty_com(char **com)
{
  int		i;

  for (i = 0; i < 25; i++)
    com[i] = strdup("\0");
}

static int	i_pipe(char *command)
{
  int		is_pipe;

  is_pipe = 0;
  while (*command != '\0')
  {
    if (*command == '|')
      is_pipe++;
    command++;
  }
  return is_pipe;
}

static int	i_and(char *command)
{
  int		is_and;

  is_and = 0;
  while (*command != '\0')
  {
    if (*command == '&')
      is_and++;
    command++;
  }
  return is_and;
}

/* static char	*is_redirect(char *command, int *redir) */
/* { */
/*   char		*file, *f; */

/*   *redir = 0; */
/*   f = 0; */
/*   while ((*command != '\0') && (*redir == 0)) */
/*   { */
/*     if (*command++ == '>') */
/*     { */
/*       *redir = *redir + 1; */
/*       if (*command++ == '>') */
/* 	*redir = *redir + 1; */
/*       while (*command == ' ') */
/* 	command++; */
/*       file = malloc(my_keylen(command) + 1); */
/*       f = file; */
/*       while ((*command != ' ') && (*command != '\0') && (*command != '|') && */
/* 	     (*command != '&')) */
/* 	*file++ = *command++; */
/*       *file = '\0'; */
/*     } */
/*   } */
/*   return f; */
/* } */

/* static char	*is_indirect(char *command, int *indir) */
/* { */
/*   char		*file, *f; */

/*   *indir = 0; */
/*   f = 0; */
/*   while ((*command != '\0') && (*indir == 0)) */
/*   { */
/*     if (*command++ == '<') */
/*     { */
/*       *indir = *indir + 1; */
/*       while (*command == ' ') */
/*       { */
/* 	*indir = *indir + 1; */
/* 	command++; */
/*       } */
/*       f = file = malloc(my_keylen(command) + 1); */
/*       while ((*command != ' ') && (*command != '\0') && (*command != '|') && */
/* 	     (*command != '&')) */
/*       { */
/* 	*indir = *indir + 1; */
/* 	*file++ = *command++; */
/*       } */
/*       *file = '\0'; */
/*     } */
/*   } */
/*   return f; */
/* } */

static void	is_keyword(char *key, char *command,
			   char *file_indir,
			   t_built **gl_builts)
{
  int		is_pipe, is_and;
  char		*com[25];
  int		fd/*, redir*/, flag;
  /*   char		*file; */
/*   t_thrid	fork_thrid; */

  file_indir = file_indir;
  flag = fd = 0;
  /* Concerne les redirections */
  /*   file = is_redirect(command, &redir); */
  /*   if (file_indir != 0) */
  /*     redir = 3; */
  /* Fin */
  com[0] = strdup(key);
  fill_com(com, command);
  if (flag == 0)
    {
    if (my_execvp(my_strcat(my_strcat(key, " "), command),
		  gl_builts) == 0)
      {
      is_pipe = i_pipe(command);
      is_and = i_and(command);
      /*       if (is_pipe != 0) */
      /* 	make_pipe(com); */
      /*       if (is_pipe == 0) */
      /*       { */
/*       if ((fork_thrid = fork()) == (t_tskid)-1) */
/* 	return; */
/*       my_printf("On a forker on est thrid : %d\n", fork_thrid); */
/*       if (fork_thrid == 0) */
/* 	{ */
      /* 	  if (redir != 0) */
      /*           { */
      /* 	    if (redir == 1) */
      /* 	      if ((fd = open(file, O_WRONLY | O_CREAT | O_TRUNC, 0600)) == -1) */
      /* 		perror("open"); */
      /* 	    if (redir == 2) */
      /* 	      if ((fd = open(file, O_WRONLY | O_CREAT | O_APPEND, 0600)) == -1) */
      /* 		perror("open"); */
      /* 	    if (redir == 3) */
      /* 	    { */
      /* 	      if ((fd = open(file_indir, O_RDONLY)) == -1) */
      /* 		perror("open"); */
      /* 	      dup2(fd, 0); */
      /* 	    } */
      /* 	    else */
      /* 	      if (dup2(fd, 1) == -1) */
      /* 		perror("dup2"); */
      /* 	  } */
      /* 	  execvp(key, com); */
	  if (exec(key/*, com*/))
	    {
	      write(STDOUT, "koinkoin_shell: ", 17);
	      write(STDOUT, key, my_strlen(key));
	      write(STDOUT, ": command not found\n", 20);
	    }
/*             exit(1); */
/*       	} */
      /* 	else */
      /* 	{ */
      /* 	  if (is_and == 0) */
      /* 	    wait(&pid); */
      /* 	} */
      /*       } */
      empty_com(com);
      }
    }
}

int		treatment(char *command,  t_built **gl_builts)
{
  /* Recupere le nom de fichier indirections*/
  char		*file = NULL;
  char		*keyword, *keyw;
  /*   int		indir, i; */

  /* Concerne les redirections*/
  /*   file = is_indirect(command, &indir); */
  /*   if (indir != 0) */
  /*     for (i = 0; i <= indir; i++) */
  /*       command++; */
  /* Fin des redirections */
  keyword = malloc(my_keylen(command) + 1);
  keyw = keyword;
  while (*command == ' ')
    command++;
  while ((*command != ' ') && (*command != '\0') &&
	 (*command != '|') && (*command != '&'))
    *keyword++ = *command++;
  *keyword = '\0';
  if (*command == ' ')
    command ++;
  if (!strcmp(keyw, "\0"))
    return 0;
  is_keyword(keyw, command, file, gl_builts);
  return 0;
}
