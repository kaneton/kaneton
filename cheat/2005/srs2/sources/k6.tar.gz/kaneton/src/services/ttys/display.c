#include "ioports.h"
#include "display.h"

/** \file display.c */
/** \brief fonctions d'affichage sur la console et de gestions du curseur. */

/** \addtogroup console 
 ** \@{
 */

/** offset de la ligne par rapport a l'adresse de base de la console */
static t_uint32		g_line = 0;

/** numero de colone */
static t_uint32		g_col = 0;

/** attribut courant du caractere imprime. */
static char		g_attribute = FOREGROUND_LIGHTGRAY;

/** Retoune l'offset courant.
 */ 
t_uint32		line_get()
{
  return g_line;
}

/** Retourne la colonne courante.
 */
t_uint32		col_get()
{
  return g_col;
}

/** Modifie la ligne courante
 */
void			line_set(t_uint32 new_line)
{
  g_line = new_line;
}

/** Modifie la colonne courante.
 */
void			col_set(t_uint32 new_col)
{
  g_col = new_col;
}

/** efface l'ecran et repositionne le curseur en haut a droite,
 ** position = 0 (g_col = g_line = 0).
 */
void			clear_screen(void)
{
  tty_clear_screen();
}

/** \addtogroup attributs */
/** \@{ */

char			get_attributes(void)
{
  return g_attribute;
}

/** Attribue a toute la console le meme attribut.
 ** \param a Valeur de l'attribut, les valeurs possibles se trouvent
 ** dans display.h
 */
void			set_attributes(char a)
{
  char			*c = (char *)CONSOLE_BASE_ADDR + 1;
  int			i = 0;

  for (i = 0 ; i < (COLUMN * LINE * 2) ; i = i + 2)
    c[i] = a;
  set_char_attributes(a);
}

/** Change l'attribut des prochains caracteres a afficher sur la
 ** console.
 ** \param a Valeur de l'attribut, les valeurs possibles se trouvent
 ** dans display.h
  */
void			set_char_attributes(char a)
{
  g_attribute = a;
}

/** Modifie les couleurs background de l'attribut de la console.
 ** Il s'agit du bit 4 � 6.
 ** bit 4 : composante bleu.
 ** bit 5 : composante verte.
 ** bit 6 : composante rouge.
 */
int			set_background(int argc, char **args)
{
  char usage[] = "Usage : background [black|blue|green|cyan|red|magenta|brown|lightgray] [all]";
  char *colors[8] = {"black", "blue", "green", "cyan", "red", "magenta", "brown", "lightgray" };
  int i = 0;
  int color_code[8] = {BACKGROUND_BLACK,
		       BACKGROUND_BLUE,
		       BACKGROUND_GREEN,
		       BACKGROUND_CYAN,
		       BACKGROUND_RED,
		       BACKGROUND_MAGENTA,
		       BACKGROUND_BROWN,
		       BACKGROUND_LIGHTGRAY};

  // mauvaise utilisation de la commande.
  if (argc > 3 || argc < 2)
    printf("%s\n", usage);
  // test de la couleur.
  for (i = 0; i < 8 ; i++)
    if (strcmp(args[1], colors[i]) == 0)
      {
	printf("background color is %s\n", colors[i]);
	g_attribute &= (0x8f);
	g_attribute |= color_code[i];
	break;
      }
  // mauvaise couleur demand�e.
  if (i == 8)
    {
      printf("bad color...\n");
      return -1;
    }
  //On modifie toute la console avec la nouvelle valeur de l'attribut.
  if (argc >= 3)
    {
      printf("[%s]\n", args[argc - 1]);
      if (strcmp(args[argc - 1], "all") == 0)
	set_attributes(g_attribute);
    }
  return 0;
}

/** Modifie les couleurs foreground de l'attribut de la console.
 ** Il s'agit du bit 0 � 3.
 ** bit 0 : composante bleu.
 ** bit 1 : composante verte.
 ** bit 2 : composante rouge.
 ** bit 3 : intensit�.
 */
int			set_foreground(int argc, char **args)
{
  char usage[] = "Usage : foreground [black|blue|green|cyan|red|magenta|brown|lightgray] [intensity:[on|off]] [all]";
  char *colors[8] = {"black", "blue", "green", "cyan", "red", "magenta", "brown", "lightgray" };
  int i = 0;
  int color_code[8] = {FOREGROUND_BLACK,
		       FOREGROUND_BLUE,
		       FOREGROUND_GREEN,
		       FOREGROUND_CYAN,
		       FOREGROUND_RED,
		       FOREGROUND_MAGENTA,
		       FOREGROUND_BROWN,
		       FOREGROUND_LIGHTGRAY};

  printf("%d\n", argc);

  // mauvaise utilisation de la commande.
  if (argc > 4 || argc < 2)
    {
      printf("%s\n", usage);
      return -1;
    }
  // teste la couleur demand�e
  for (i = 0; i < 8 ; i++)
    if (strcmp(args[1], colors[i]) == 0)
      {
	printf ("background color is %s\n", colors[i]);
	g_attribute &= (0xf8);
	g_attribute |= color_code[i];
	break;
      }
  // mauvaise couleur demand�e.
  if (i == 8)
    {
      printf("bad color...\n");
      return -1;
    }
  // Intensit�.
  if (argc >= 3)
    {
      // activation de l'intensit�
      if (strcmp(args[2], "intensity:on") == 0)
	{
	  g_attribute &= (0xf7);
	  g_attribute |= FOREGROUND_INTENSITY;
	  printf("Intensity is ON.\n");
	}
      else
	// desactivation de l'intensit�
	if (strcmp(args[2], "intensity:off") == 0)
	  {
	    g_attribute &= (0xf7);
	    printf("Intensity is OFF.\n");
	  }
    }
  //On modifie toute la console
  if (argc >= 3)
    {
      printf("[%s]\n", args[argc - 1]);
      if (strcmp(args[argc - 1], "all") == 0)
	set_attributes(g_attribute);
    }
  return 0;
}

/** Met le mode blinking en marche/arret.
 ** Il s'agit du bit 7 de l'attribut de la console.
 */
int			set_blinking(int argc, char **args)
{
  char error[] = "blink [on|off]\n";
  
  if ((argc > 2) || (argc < 2))
    {
      printf("%s1", error);
      return 1;
    }
  else
    {
      if (strcmp(args[1], "on") == 0)
	{
	  printf("Blink mode ON\n");
	  g_attribute |= VGA_BLINKING_ON;
	}
      else
      if (strcmp(args[1], "off") == 0)
	{
	  printf("Blink mode OFF\n");
	  g_attribute &= VGA_BLINKING_OFF;
	}
      else
	{
	  printf("%s2", error);
	  return 1;
	}
    }
  return 0;
}

/** \@} */

/** ajoute une ligne sur l'ecran quand le bas de la console est atteint.
 */
void			add_line()
{
  int	l, c;
  char	*ch = (char *) CONSOLE_BASE_ADDR;

  for (l = 0; l < 25 ; l++)
    for (c = 0 ; c < 160; c += 2)
    {
      ch[((l * 160) + c)] = ch[(((l + 1) * 160) + c)];
      ch[((l * 160) + c) + 1] = ch[(((l + 1) * 160) + c) + 1];
    }
  g_col = 0;
  g_line = 3840;
}

/** incremente d'une colonne lorsqu'une colonne de la console est
 ** entierement remplie.
 */
void			inc_column(void)
{
  if (g_col == 158)
    {
      if (tty_status_get() == TTY_ENABLE)
	tty_buffer();
      g_col = 0;
      g_line += 160;
      if (g_line == 4000)
	{
	  add_line();
	}
    }
  else
    g_col += 2;
}

/** Incremente la position du curseur sur la console en fonction de la
 ** position du dernier caractere affiche.
 */
void			cursor(void)
{
  int			position = 0;

  // conversion pour obtenir la position du curseur.
  position = (g_col / 2) + ((g_line) / 2);
  // cursor high -> bits 15 - 8
  outb(VGA_CURSOR_HIGH, VGA_COMMAND_PORT);
  outb((position >> 8), VGA_DATA_PORT);
  // cursor low -> bits 0 - 7
  outb(VGA_CURSOR_LOW, VGA_COMMAND_PORT);
  outb((position & 0xFF), VGA_DATA_PORT);
}

/** N'affiche pas le curseur lorsque le TTY est en mode scrolling.
 */
void			cursor_hide(void)
{
  int			position = VGA_CURSOR_HIDE;

  outb(VGA_CURSOR_HIGH, VGA_COMMAND_PORT);
  outb((position >> 8), VGA_DATA_PORT);
  outb(VGA_CURSOR_LOW, VGA_COMMAND_PORT);
  outb((position & 0xFF), VGA_DATA_PORT);
}
/** \@} */

/** Affiche un caractere a l'ecran..

 */
void                    cons_print_char(char c)
{
  char			*console = (char *) CONSOLE_BASE_ADDR;
  int			i, ident_col = 0;

  if (tty_status_get() == TTY_ENABLE)
    tty_check_scrolling();
  switch(c)
    {
      /* retour a la ligne */
    case '\n':
      if (tty_status_get() == TTY_ENABLE)
	tty_buffer();
      g_col = 0;
      g_line = g_line + 160;
      cursor();
      if (g_line == 4000)
	{
	  add_line();
	} 
       break;

       /* effacement d'un charactere. */
    case '\b':
      if (g_col != 0)
	{
	  g_col -= 2;
	  console[g_line + g_col] = ' ';
	  cursor();
	}
      break;
      
    case '\a':
      break;
    case '\0':
      break;
      /* Tabulation */
    case '\t':
      for (i = 0; i < TAB_SIZE; i++)
	{
	  console[g_line + g_col] = ' ';
	  console[g_line + g_col + 1] = g_attribute;
	  inc_column();
	  cursor();
	}
      break;
    case '\v':
      ident_col = g_col;
      cons_print_char('\n');
      for (i = 0; i < ident_col / 2; i++)
	{
	  console[g_line + g_col] = ' ';
	  console[g_line + g_col + 1] = g_attribute;
	  inc_column();
	  cursor();
	}
      break;
    case '\f':
      ident_col = g_col;
      cons_print_char('\n');
      for (i = 0; i < ident_col / 2; i++)
	{
	  console[g_line + g_col] = ' ';
	  console[g_line + g_col + 1] = g_attribute;
	  inc_column();
	  cursor();
	}
      break;
    case '\r':
      g_col = 0;
      cursor();
      break;
    default:
      console[g_line + g_col] = c;
      console[g_line + g_col + 1] = g_attribute;
      inc_column();
      cursor();
      break;
    }
}

/** Affiche une chaine de caractere.
 */
void                    cons_print_string(char *str)
{
  while (*str != '\0')
  {
    cons_print_char(*str);
    str++;
  }
}

/** Affiche un entier signe.
 */
void                    cons_print_num(int i)
{
  if ((i < 10) && (i > -10))
    if (i >= 0)
      cons_print_char(i + 48);
  else
  {
    cons_print_char('-');
    cons_print_char((-i) + 48);
  }
  else
  {
    if (i < 0)
    {
      cons_print_char('-');
      cons_print_num(-(i / 10));
      cons_print_char(-(i % 10) + 48);
    }
      else
      {
        cons_print_num(i / 10);
        cons_print_char((i % 10) + 48);
      }
  }
}
/*!
** retourne le caractere en hexa d'une vealeur entiere en vue de l'afficher.
*/
static char	gethex(int i)
{
  char          table[16] = {'0', '1', '2', '3', '4', '5', '6', '7',
                             '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

  return table[i];
}

/*!
** Affiche un nombre en hexadecimal.
*/
void			cons_print_hex(unsigned long i)
{
  if (i < 16)
      cons_print_char(gethex(i));
  else
  {
      cons_print_hex(i / 16);
      cons_print_char(gethex(i % 16));
  }
}
/*!
** Affiche le contenu, bit a bit, d'un registre et ce,
** du bit de poids faible au bit de poids fort dans le
** sens de la lecture.
*/
void	cons_print_bin(int i)
{
  char	cpt;
  int	val = 1;

  for (cpt = 0; cpt < 32; ++cpt)
    {
      if (i & val)
	cons_print_char('1');
      else
	cons_print_char('0');
      val *= 2;
    }
}

/** printf du Kaneton.
 */
void	printf(const char *format, ...)
{
  char	**arg = (char **) &format;
  int	c;
  
  /*   if (scroll_lock_enabled()) */
  /*     return; */
  arg++;
  while ((c = *format++) != 0)
    {
      if (c != '%')
	{
	  cons_print_char(c);
	}
      else
	{
	  char *p;
	  
	  c = *format++;
	  switch (c)
	    {
	    case 'd':
	      cons_print_num((int) (*(int *) arg++));
	      break;

	    case 's':
	      p = *arg++;
	      if (!p)
		p = "(null)";
	      cons_print_string(p);
	      break;

	    case 'b':
	      cons_print_bin((int) (*(int *) arg++));
	      break;

	    case 'x':
	      cons_print_hex((int) (*(int *) arg++));
	      break;

	    default:
	      cons_print_char(*((int *) arg++));
	      break;
	    }
	}
    }
}
