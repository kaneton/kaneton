/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon May 16 20:11:45 2005 Damien Laniel
** Last update Wed May 25 16:12:36 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef DLIST_H_
# define DLIST_H_

typedef struct		s_set_dlist
{
  struct s_set_dlist	*next;
  struct s_set_dlist	*prev;
  void			*data;
}			t_set_dlist;

typedef int		(*t_set_dlist_cmp_func)(const void *source, const void *destination);

typedef void		(*t_set_dlist_display_func)(const void *data);

typedef void		(*t_set_dlist_free_func)(void *data);


unsigned int		set_dlist_size(const t_set_dlist *list);

void			set_dlist_add_item_head(t_set_dlist **list, void *data);
void			set_dlist_add_item_end(t_set_dlist **list, void *data);
void			set_dlist_add_item_sorted(void		*data,
					      t_set_dlist		**list,
					      t_set_dlist_cmp_func	cmp_func);
void			set_dlist_delete_item(t_set_dlist	**list,
					   const void	*data,
					   t_set_dlist_cmp_func	cmp_func,
					   t_set_dlist_free_func	free_func);
void			*set_dlist_find_item_eq(const t_set_dlist	*list,
					    const void		*data,
					    t_set_dlist_cmp_func		cmp_func);

void			set_dlist_free(t_set_dlist **list, t_set_dlist_free_func free_func);

void			set_dlist_sort(t_set_dlist **list, t_set_dlist_cmp_func cmp_func);

void			set_dlist_concat(t_set_dlist **list_a, t_set_dlist *list_b);
void			set_dlist_shift(t_set_dlist **list);
void			set_dlist_rev(t_set_dlist **list);
void			set_dlist_merge(t_set_dlist	**list_a,
				   t_set_dlist	*list_b,
				   t_set_dlist_cmp_func	cmp_func);

void			set_dlist_print(const t_set_dlist *list, t_set_dlist_display_func display_func);

void			*set_dlist_get_item_head(t_set_dlist *list);
void			*set_dlist_get_item_end(t_set_dlist *list);

void			*set_dlist_find_prev_item(t_set_dlist *list, const void *data, t_set_dlist_cmp_func cmp_func);
void			*set_dlist_find_next_item(t_set_dlist *list, const void *data, t_set_dlist_cmp_func cmp_func);

#endif /* !DLIST_H_ */
