/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Wed Nov 23 22:39:55 2005 Nicolas Clermont
** Last update Thu Nov 24 01:38:00 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "shell.h"
#include "../../lib/libc/mod.h"

#define CMD_SIZE	255
#define	SHELL_PROMPT	"[koinkoin_shell://]# "
#define	BUILT_ERROR	"koinkoin shell: builtin error\n"

/*!
** Print the shell prompt on the current TTY
*/
static void	aff_prompt(void)
{
  write_color(STDOUT, SHELL_PROMPT, strlen(SHELL_PROMPT), 0xe);
}

static void	clear_screen(void)
{
  t_msg		*msg;
  
  msg = create_msg(STDOUT, 1);
  *(char *)(msg->data) = 1;
  send_msg(msg);
}

/*!
** Initialize the builtins structure
** @param	gl_builts	Contains all the builtins
*/
static int	init_builtins(t_built **gl_builts)
{
  t_built      	*b;

  *gl_builts = NULL;
  if ((b = malloc(sizeof (t_built))) == NULL)
    return 1;
  b->func = (void *)func_echo;
  b->name = "echo";
  b->next = *gl_builts;
  *gl_builts = b;

  if ((b = malloc(sizeof (t_built))) == NULL)
    return 1;
  b->func = (void *)ps;
  b->name = "lsmod";
  b->next = *gl_builts;
  *gl_builts = b;

  if ((b = malloc(sizeof (t_built))) == NULL)
    return 1;
  b->func = (void *)clear_screen;
  b->name = "clear";
  b->next = *gl_builts;
  *gl_builts = b;
  
  return 0;
}

/*!
** Check if the last key pressed is Delete, and if
** we can delete the last character.
** @param	key		The last key pressed
** @param	size_read	Number of characters currently
**				presents in the command buffer
*/
static int	check_delete(char key, int size_read)
{
  if ((key == '\b') && (!size_read))
    return 1;
  if ((key == '\b') && (size_read))
    return 2;
  return 0;
}

/*!
** The minishell
*/
int		main(void)
{
  int		ext = 0;
  char		*command;
  char		part = 0;
  t_built	*gl_builts;
  int		/*i = 0,*/ is_delete = 0;
  int		size_read = 0;

  if (init_builtins(&gl_builts))
    write(STDOUT, BUILT_ERROR, strlen(BUILT_ERROR));
  while (!ext)
  {
    aff_prompt();
    command = malloc(CMD_SIZE);
/* CA C READLINE, SANS AFF CHAQUE CHAR */
/*     size_read = read(STDIN, command, CMD_SIZE); */
/*     write(STDOUT, command, strlen(command)); */
/*     for (i = 0; i < size_read; i++) */
/*       if (command[i] == '\n') */
/* 	command[i] = 0; */
    read(STDIN, &part, 1);
    if (part != '\b')
      write(STDOUT, &part, 1);
    else
      is_delete = 1;
    while (part != '\n')
      {
	if (!is_delete)
	  command[size_read++] = part;
	if (is_delete == 2)
	  command[--size_read] = 0;
	read(STDIN, &part, 1);
	if ((is_delete = check_delete(part, size_read)) != 1)
	  write(STDOUT, &part, 1);
      }
    command[size_read] = '\0';
    ext = treatment(command, &gl_builts);
    is_delete = size_read = 0;
    free(command);
  }
  return 0;
}
