/*
** curseur.c for kaneton in /home/xebech/kaneton/src
**
** Made by xebech
** Login   <xebech@epita.fr>
**
** Started on  Wed Mar 23 23:31:11 2005 xebech
** Last update Thu Mar 24 03:26:05 2005 xebech
*/
#include "console.h"
#include "ioports.h"

void	update_curseur_pos_in_char(int offset)
{
  int	arg_to_give_reg_14 = offset >> 8;/* Args to give to the MSB register */
  int	arg_to_give_reg_15 = offset & 0xFF;/* Args to give to the LSB register */

  outb(VGA_SET_CURSOR_HIGH,VGA_COMMAND_PORT);
  outb(arg_to_give_reg_14, VGA_DATA_PORT );
  outb(VGA_SET_CURSOR_LOW, VGA_COMMAND_PORT);
  outb(arg_to_give_reg_15, 0x3D5);
}

/*
** @param x This is the column
** @param y This is the line
*/
void	update_curseur_x_y(int x, int y)
{
  update_curseur_pos_in_char(x + 1 + COLUMNS * y);
}

void	update_curseur()
{
  update_curseur_pos_in_char(((int) ttys[current_tty].addr - (CONSOLE_ADDRESS) + (4096 * current_tty)/*-1*/) / 2);
}
