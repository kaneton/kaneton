/*
** Copyright (c) 2005, Sebastien Raveau
**  All rights reserved.
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following condititions
** are met:
**
** Redistributions of source code must retain the above copyright notice,
** this list of conditions and the following disclaimer.
** Redistributions in binary form must reproduce the above copyright notice,
** this list of conditions and the following disclaimer in the documentation
** and/or other materials provided with the distribution.
** Neither the name of EPITA nor the names of its contributors may be used to
** endorse or promote products derived from this software without specific
** prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
*/

#include "cpuinfo.h"

/*!
** Fill in the s_cpuinfo structure with information
** about the processor on which this code is run
*/
void	cpuinfo(struct s_cpuinfo *cpu)
{
  cpu->vendor_id[0] = cpu->vendor_id[12] = '\0';
  cpu->model_name[0] = cpu->model_name[48] = '\0';

  __asm__ __volatile__ (
  "		cpuid				;"
  :	"=a"(cpu->stdfunc_max), "=b"(*((int *)&cpu->vendor_id[0])),
	"=d"(*((int *)&cpu->vendor_id[4])), "=c"(*((int *)&cpu->vendor_id[8]))
  :	"a"(CPUID_GET_MAX)
  );

  __asm__ __volatile__ (
  "		cpuid				;"
  :	"=a"(cpu->extfunc_max)
  :	"a"(CPUID_EXT_GET_MAX)
  );

  if (CPUID_EXT_NAME1 > cpu->extfunc_max)
    return;

  __asm__ __volatile__ (
  "		cpuid				;"
  :	"=a"(*((int *)&cpu->model_name[0])), "=b"(*((int *)&cpu->model_name[4])),
	"=c"(*((int *)&cpu->model_name[8])), "=d"(*((int *)&cpu->model_name[12]))
  :	"a"(CPUID_EXT_NAME1)
  );

  if (CPUID_EXT_NAME2 > cpu->extfunc_max)
    return;

  __asm__ __volatile__ (
  "		cpuid				;"
  :	"=a"(*((int *)&cpu->model_name[16])), "=b"(*((int *)&cpu->model_name[20])),
	"=c"(*((int *)&cpu->model_name[24])), "=d"(*((int *)&cpu->model_name[28]))
  :	"a"(CPUID_EXT_NAME2)
  );

  if (CPUID_EXT_NAME3 > cpu->extfunc_max)
    return;

  __asm__ __volatile__ (
  "		cpuid				;"
  :	"=a"(*((int *)&cpu->model_name[32])), "=b"(*((int *)&cpu->model_name[36])),
	"=c"(*((int *)&cpu->model_name[40])), "=d"(*((int *)&cpu->model_name[44]))
  :	"a"(CPUID_EXT_NAME3)
  );
}
