/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Wed Nov 23 22:59:57 2005 Nicolas Clermont
** Last update Wed Nov 23 23:03:22 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "shell.h"

static int	msg_len(char *msg)
{
  int		len;

  len = 0;
  while ((*msg != '>') && (*msg != '|') && (*msg != '\0'))
  {
    msg++;
    len++;
  }
  return len;
}

static char	*sup_db(char *msg)
{
  char		*tmp, *result;

  tmp = malloc(strlen(msg) - 1);
  result = tmp;
  if (*msg == '"')
    msg++;
  while (*msg != '\0')
  {
    if (*msg != '"')
      *tmp++ = *msg;
    msg++;
  }
  *tmp = '\0';
  return result;
}

static char	*sup_back(char *msg)
{
  char		*tmp, *result;

  tmp = malloc(strlen(msg) + 1);
  result = tmp;
  while (*msg != '\0')
  {
    if (*msg != '\\')
      *tmp++ = *msg;
    msg++;
  }
  *tmp = '\0';
  return result;
}

void		func_echo(char *param)
{
  char		*msg, *msgw, *ms;
  int		len, env, opt_n;

  opt_n = env = 0;
  while (*param == ' ')
    param++;
  if (*param == '-')
  {
    param++;
    if (*param == 'n')
    {
      param++;
      opt_n = 1;
      while (*param == ' ')
	param++;
    }
  }
  len = msg_len(param);
  msg = malloc(len + 2);
  ms = msgw = msg;
  /*   if (*param == '$') */
  /*   { */
  /*     env++; */
  /*     param++; */
  /*   } */
  while ((*param != '>') && (*param != '|') && (*param != '\0'))
    *msg++ = *param++;
  if ((env == 0) && (opt_n == 0))
    *msg++ = '\n';
  *msg = '\0';
/*   if (env == 1) */
/*   { */
/*     if ((msgw = getenv(msgw)) == NULL) */
/*       msgw = mystrcat(mystrcat(ms, ": Undefined variable."), "\n"); */
/*     else */
/*       if (opt_n == 0) */
/* 	msgw = mystrcat(msgw, "\n"); */
/*   } */
  if (*msgw == '"')
    msgw = sup_db(msgw);
  else
    msgw = sup_back(msgw);
/*   if (*param == '>') */
/*     func_redirect(msgw, ++param); */
/*   else */
    write(STDOUT, msgw, strlen(msgw));
}
