#ifndef TTY_H_
# define TTY_H_

/* # include "type.h" */
/* # include "macros.h" */
# include "../../include/kaneton/types.h"
# include "display.h"

# define TRUE			0
# define FALSE			1

# define COLUMN			80
# define LINE			25

# define MAX_TTY		4
# define MAX_TTY_PAGE		5

# define TTY_BUFFER_LENGTH	(MAX_TTY_PAGE * COLUMN * LINE * 2)
# define TTY_PAGE_UD		COLUMN * 2 * 12
# define TTY_ENABLE		TRUE
# define TTY_DISABLE		FALSE
# define TTY_ERROR		3
# define TTY_INTERACTIVE	-1
/*!
** Macros pour changer de TTYs.
*/
# define TTY_FIRST		0
# define TTY_LAST		(MAX_TTY - 1)


/*!
** Represente un tty
*/
struct s_tty_driver
{
  // buffer pour un TTY de taille TTY_BUFFER_LENGTH.
  char *buffer;
  /// offset courant dans la memoire buffer.
  t_uint32 current_offset;
  /// offset courant dans le buffer pour l'affichage par scrolling (-1 si pas scrolling).
  t_sint32 current_display_offset;
  // g_line sur la console.
  t_uint32 line;
  // g_col sur la console.
  t_uint32 col;
  char attributes;
} __attribute__((packed));

int	ttys_init(void);
void	tty_buffer(void);
void	tty_check_scrolling(void);
void	tty_change_display(void);
int	tty_current_set(t_sint8);
int	tty_current_get(void);
void	tty_page_up(void);
void	tty_line_down(void);
void	tty_line_up(void);
void	tty_page_up(void);
void	tty_page_down(void);
t_bool	tty_status_set(t_bool new_status);
t_bool	tty_status_get(void);
void	tty_clear_screen(void);

#endif /* !TTY_H_ */
