/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sun Sep 25 21:33:28 2005 Damien Laniel
** Last update Sun Sep 25 23:46:52 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../include/kaneton/types.h"

#ifndef ELF_H_
# define ELF_H_

/* Header Elf*/
#define E_IDENT		0x0
#define	E_TYPE		0x10
#define E_MACHINE	0x12
#define E_VERSION	0x14
#define E_ENTRY		0x18
#define E_PHOFF		0x1C
#define E_SHOFF		0x20
#define E_FLAGS		0x24
#define E_EHSIZE	0x28
#define E_PHENTSIZE	0x2A
#define E_PHNUM		0x2C
#define E_SHENTSIZE	0x2E
#define E_SHNUM		0x30
#define E_SHSTRNDX	0x32

/* Section Header */
#define	SH_TYPE		0x4
#define	SH_OFFSET	0x10
#define	SH_SIZE		0x14

/* Symbol Table Entry */
#define	ST_NAME		0x0
#define	ST_VALUE	0x4
#define	ST_INFO		0xC

/* Section types -> sh_type */
#define	SHT_SYMTAB	2
#define	SHT_STRTAB	3

/* Symbol types */
#define	STT_FUNC	2

/* Size of an entry of the symbol table */
#define	ST_ENTRY_SIZE	16

/* Get symbol type */
#define ELF32_ST_TYPE(i) ((i) & 0xf)

/* Get param from a header */
int	he_get_param(t_vaddr header_elf, int param);

#endif /* !ELF_H_ */
