/*!
** The outb function provide to write on I/O ports
**
** @param value	Represent the value to write
** @param port Represent the port to write the value
*/

void outb(unsigned char value, unsigned short int port)
{
  __asm__ __volatile__
    ("outb %b0,%w1": :"a" (value),"Nd" (port));
}


/*!
** The inb function provide to read on I/O ports
**
** @param port Represent the port to read the value
*/

unsigned char inb(unsigned short int port)
{
  unsigned char _v;

  __asm__ __volatile__
    ("inb %w1,%0":"=a" (_v):"Nd" (port));
  return _v;
}
