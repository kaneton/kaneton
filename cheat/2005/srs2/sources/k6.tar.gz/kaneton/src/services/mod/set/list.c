/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon May 16 19:53:59 2005 Damien Laniel
** Last update Mon Nov 14 23:19:01 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "list.h"
#include "../../../lib/libc/libc.h"
/* #include "../console/console.h" */
#include "../../../include/kaneton/types.h"
/* #include "../../../kaneton/malloc/kmalloc.h" */

unsigned int	set_list_size(const t_set_list *list)
{
  unsigned int	size = 0;

  while (list)
    {
      size++;
      list = list->next;
    }
  return size;
}

static t_set_list	*set_list_create_node(void *data)
{
  t_set_list	*list = NULL;
  
  if (!(list = malloc(sizeof (t_set_list))))
    {
      /*       printf("SET_LIST_CREATE_NODE MALLOC KI PUE\n"); */
      return NULL;
    }
  list->data = data;
  list->next = NULL;
  return list;
}

void		set_list_add_item_head(t_set_list **list, void *data)
{
  t_set_list	*new = NULL;

  if (!(new = malloc(sizeof (t_set_list))))
    return;
  new->data = data;
  new->next = *list;
  *list = new;
}

void		set_list_add_item_end(t_set_list **list, void *data)
{
  t_set_list	*tmp = NULL;
  void		*test = NULL;

  if (!list)
    {
      *list = set_list_create_node(data);
      return;
    }
  if (*list)
    {
      tmp = *list;
      while (tmp->next)
	tmp = tmp->next;
      test = set_list_create_node(data);
      tmp->next = test;
    }
  else
    *list = set_list_create_node(data);
}

void		*set_list_get_item_head(t_set_list *list)
{
  if (list == NULL)
    return NULL;
  return list->data;
}

void		*set_list_get_item_end(t_set_list *list)
{
  t_set_list	*cur_node = NULL;

  if (list == NULL)
    return NULL;
  for (cur_node = list; cur_node->next; cur_node = cur_node->next)
    ;
  return cur_node->data;
}

void		set_list_add_item_sorted(t_set_list	**list,
				     void	*data,
				     t_set_list_cmp_func	cmp_func)
{
  t_set_list	*tmp = NULL;
  t_set_list	*tmpnext = NULL;

  if (!list)
    return;
  tmp = *list;
  while (tmp && cmp_func(tmp->data, data) <= 0)
    tmp = tmp->next;
  tmpnext = tmp->next;
  tmp->next = set_list_create_node(data);
  tmp->next->next = tmpnext;
}

void		set_list_delete_item(t_set_list		**list,
				     const void		*data,
				     t_set_list_cmp_func		cmp_func,
				     t_set_list_free_func	free_func)
{
  t_set_list	*cur_node = *list;
  t_set_list	*prev_node = NULL;

  if (cur_node)
    {
      if (!(cmp_func(cur_node->data, data)))
	{
	  *list = cur_node->next;
	  if (free_func)
	    free_func(cur_node->data);
	  cur_node->data = NULL;
	  cur_node->next = NULL;
	  return;
	}
      for (prev_node = cur_node, cur_node = cur_node->next;
	   cur_node;
	   prev_node = cur_node, cur_node = cur_node->next)
	{
	  if (!(cmp_func(cur_node->data, data)))
	    {
	      prev_node->next = cur_node->next;
	      if (free_func)
		free_func(cur_node->data);
	      cur_node->data = NULL;
	      cur_node->next = NULL;
	      return;
	    }
	}
    }
}

void	*set_list_find_item(const t_set_list	*list,
			const void	*data,
			t_set_list_cmp_func	cmp_func)
{

  while (list)
    {
/*       printf("Set liste item boucle\n"); */
      if (!(cmp_func(list->data, data)))
	{
/* 	  printf("cmp_func qui match\n"); */
/* 	  while (1); */
	  return list->data;
	}
   /*      printf("cmp_func qui match pas\n"); */
/* 	  while (1); */
      list = list->next;
    }
  return NULL;
}

void	*set_list_find_prev_item(t_set_list	*list,
				 const void	*data,
				 t_set_list_cmp_func	cmp_func)
{
  t_set_list	*prev = NULL;

  while (list)
    {
      if (!(cmp_func(list->data, data)))
	{
	  if (prev)
	    return prev->data;
	  else
	    return NULL;
	}
      prev = list;
      list = list->next;
    }
  return NULL;
}

void	*set_list_find_next_item(t_set_list	*list,
				 const void	*data,
				 t_set_list_cmp_func	cmp_func)
{
  while (list)
    {
      if (!(cmp_func(list->data, data)))
	{
	  if (list->next)
	    return list->next->data;
	  else
	    return NULL;
	}
      list = list->next;
    }
  return NULL;
}

void		set_list_free(t_set_list **list, t_set_list_free_func free_func)
{
  t_set_list *tmp = NULL;

  if (!list)
    return;
  tmp = *list;
  while (tmp)
    {
      free_func(tmp->data);
      tmp = tmp->next;
    }
  free(list);
}

void		set_list_sort(t_set_list **list, t_set_list_cmp_func cmp_func)
{
  t_set_list	*new = NULL;
  t_set_list	*tmp = NULL;
  void		*max = NULL;
  t_set_list	*next2 = NULL;

  if (!list)
    return;
  while (*list)
    {
      max = (*list)->data;
      tmp = *list;
      while (tmp)
	{
	  if ((cmp_func(tmp->data, max)) > 0)
	    max = tmp->data;
	  tmp = tmp->next;
	}
      next2 = tmp->next;
      next2 = new->next;
      new = next2;
      tmp->next = tmp->next->next;
    }
  *list = new;
}

void		set_list_concat(t_set_list **list_a, t_set_list *list_b)
{
  t_set_list	*tmp = NULL;

  if (list_a)
    return;
  tmp = *list_a;
  while (tmp->next)
    tmp = tmp->next;
  tmp->next = list_b;
}

void		set_list_shift(t_set_list **list)
{
  t_set_list	*tmp = NULL;

  tmp = *list;
  while (tmp->next)
    tmp = tmp->next;
  tmp->next = *list;
  *list = (*list)->next;
  tmp->next->next = NULL;
}

void		set_list_rev(t_set_list **list)
{
  t_set_list	*new = NULL;
  t_set_list	*tmp = NULL;

  if (!list)
    return;
  tmp = *list;
  while (tmp)
    {
      set_list_add_item_head(&new, tmp->data);
      tmp = tmp->next;
      *list = new;
    }
}

static void	set_list_sort2(t_set_list **list, t_set_list_cmp_func cmp_func)
{
  t_set_list	*new = NULL;
  t_set_list	*tmp = NULL;
  void		*max = NULL;
  t_set_list	*next2 = NULL;

  while (*list)
    {
      max = (*list)->data;
      tmp = *list;
      while (tmp)
	{
	  if (cmp_func(tmp->data, max) > 0)
	    max = tmp->data;
	  tmp = tmp->next;
	}
      next2 = tmp->next;
      next2 = new->next;
      new = next2;
      tmp->next = tmp->next->next;
    }
  *list = new;
}

void		set_list_merge(t_set_list	**list_a,
			   const t_set_list	*list_b,
			   t_set_list_cmp_func	cmp_func)
{
  t_set_list	*tmp = NULL;
  t_set_list	*tmp2 = NULL;

  tmp = *list_a;
  while (tmp->next)
    tmp = tmp->next;
  if (!(tmp2 = malloc(sizeof (t_set_list))))
    return;
  tmp2->data = list_b->data;
  tmp2->next = list_b->next;
  tmp->next = tmp2;
  set_list_sort2(list_a, cmp_func);
}

void	set_list_print(const t_set_list *list, t_set_list_display_func display_func)
{
  while (list)
    {
      display_func(list->data);
      /*       if (list->next) */
      /* 	cons_goto_next_line(); */
      list = list->next;
    }
}
