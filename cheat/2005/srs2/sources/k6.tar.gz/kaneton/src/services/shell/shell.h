/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Wed Nov 23 22:56:42 2005 Nicolas Clermont
** Last update Wed Nov 23 22:56:44 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef SHELL_H
# define SHELL_H

# include "../../lib/libc/libc.h"
# include "../../lib/libc/string.h"

typedef	struct		s_built
{
  char			*name;
  int			(*func)(char *argv);
  void			*h;
  struct s_built	*next;
}			t_built;

int		treatment(char *command, t_built **gl_builts);
void		func_echo(char *param);
void		func_cd(char *param);
void		func_kill(char *param);
void		func_redirect(char *data, char *param);
void		make_pipe(char **com);
#endif		/* !SHELL_H */
