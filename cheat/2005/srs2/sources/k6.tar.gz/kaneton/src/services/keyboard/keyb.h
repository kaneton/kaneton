/*
** Copyright (C) Borek Boissy aka Borek <borek@free.fr>
**
** Part of Kaneton
**
** Started on  Sun Oct  9 19:19:24 2005 Antoine Castaing
** Last update Wed Nov 23 01:27:07 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef KEYB_H_
# define KEYB_H_

# define KEY_BUF_SIZE   4
# define IRQ_BUF_SIZE	128

# include "../../include/kaneton/ioports.h"
# include "../../include/kaneton/types.h"
# include "../../lib/libc/libc.h"
# include "../../lib/console/console.h"

# define KB_WAIT() ({ __asm__ __volatile__ ( "pushl %eax \n" \
					 "0: \n"            \
					 " inb $0x64,%al \n"\
					 " testb $2, %al \n"\
					 " jne 0b \n"       \
					    "popl %eax");    })

typedef	struct	s_keyboard
{
  t_uint8	menu;
  t_uint8	windows;
  t_uint8	windows_left;
  t_uint8	windows_right;
  t_uint8	shift;
  t_uint8	shift_left;
  t_uint8	shift_right;
  t_uint8	ctrl;
  t_uint8	ctrl_left;
  t_uint8	ctrl_right;
  t_uint8	alt;
  t_uint8	altgr;
  t_sint8	value;
  t_uint8	code[KEY_BUF_SIZE];
} __attribute__((packed)) t_kbd;

int	keyboard_init(int);
t_kbd	get_key(void);
int	send_key(int);

/**
 ** Gestion de r�gions de clavier
*/

# define LANGUAGE_QTY   2
# define US_KEYBOARD    0
# define FR_KEYBOARD    1

/**
 ** Variable contenant le serveur a qui envoye le caractere recu.
*/
int	current_client;
int	is_get_char;

int	loadkeys(int);

/**
 ** V�rifie si la structure contient un caract�re imprimable
*/

char	is_printable(t_kbd);

/**
 ** Ensemble de fonctions de test d'enfoncement de touche
*/
int	Irq1_FillKeyboardBuffer();
char	is_shift(t_kbd);
char	is_shift_left(t_kbd);
char	is_shift_right(t_kbd);
char	is_ctrl(t_kbd);
char	is_ctrl_left(t_kbd);
char	is_ctrl_right(t_kbd);
char	is_alt(t_kbd);
char	is_altgr(t_kbd);

char	is_f1(t_kbd);
char	is_f2(t_kbd);
char	is_f3(t_kbd);
char	is_f4(t_kbd);
char	is_f5(t_kbd);
char	is_f6(t_kbd);
char	is_f7(t_kbd);
char	is_f8(t_kbd);
char	is_f9(t_kbd);
char	is_f10(t_kbd);
char	is_f11(t_kbd);
char	is_f12(t_kbd);

char	is_up(t_kbd);
char	is_down(t_kbd);
char	is_left(t_kbd);
char	is_right(t_kbd);
char	is_pageup(t_kbd);
char	is_pagedown(t_kbd);
char	is_insert(t_kbd);
char	is_delete(t_kbd);
char	is_home(t_kbd);
char	is_end(t_kbd);
char	is_escape(t_kbd);

/**
 ** Ensemble de fonctions de gestion des leds du clavier
*/

# define	LED_SCROLL	0x1
# define	LED_NUM		0x2
# define	LED_CAPS	0x4

void	set_led(char);
void	unset_led(char);
char	get_leds(void);

char	scroll_lock_enabled(void);

void	display_buffer(t_kbd);

#endif
