#include "../../lib/libc/libc.h"
#include "tty.h"

/// \file tty.c
/// \brief Driver pour les ttys.

/// \addtogroup drivers Drivers
/// @{

/// \addtogroup tty TTy
/// @{

/// tableau sur tout les ttys;
static struct s_tty_driver	*g_ttys;
/// etat du driver TTY.
static t_bool			g_tty_status = TTY_DISABLE;
/// TTY courant utilise.
static t_uint32			g_tty_current = TTY_FIRST;

/** initialise tout les ttys == on met les memes attributs pour tous.
 ** On bufferise l'ecran entier dans le 1er TTY.
 */
int			ttys_init(void)
{
  t_uint32		i = 0;
  t_uint32		j = 0;
  char			*buffer_tmp = NULL;
  char			*console = (char *) CONSOLE_BASE_ADDR;

  g_ttys = malloc(sizeof(struct s_tty_driver) * MAX_TTY);

  clear_screen();
  printf("TTYs initialization ... \n");
  for (i = 0 ; i < MAX_TTY ; i++)
    {
      buffer_tmp = malloc(sizeof(char) * TTY_BUFFER_LENGTH);
      g_ttys[i].buffer = buffer_tmp;
      printf("tty %d, vaddr : 0x%x, buffer : 0x%x\n", i, &g_ttys[i],
	     g_ttys[i].buffer);
      for (j = 0 ; j < TTY_BUFFER_LENGTH; j += 2)
	{
	  g_ttys[i].buffer[j] = ' ';
	  g_ttys[i].buffer[j + 1] = FOREGROUND_LIGHTGRAY + BACKGROUND_BLACK;
	}
      g_ttys[i].buffer[0] = '$';
      g_ttys[i].current_offset = 0;
      g_ttys[i].current_display_offset = -1;
      g_ttys[i].line = 0;
      g_ttys[i].col = 4;
      g_ttys[i].attributes = FOREGROUND_LIGHTGRAY + BACKGROUND_BLACK;
      if (i == 0)
	{
	  for (j = 0 ; j < (line_get() + col_get()) ; j ++)
	    {
	      g_ttys[i].buffer[j] = console[j];
	      g_ttys[i].current_offset++;
	    }
	  g_ttys[i].line = line_get();
	  g_ttys[i].col = col_get();
	  tty_status_set(TTY_ENABLE);
	}
    }
  tty_current_set(TTY_FIRST);

  return 0;
}

/// \addtogroup accessors Accesseurs.
/// @{

/**
 ** Modifie le status d'utilisation des TTYs.
 */
t_bool			tty_status_set(t_bool new_status)
{
  if ((new_status == TTY_ENABLE) || (new_status == TTY_DISABLE))
    g_tty_status = new_status;

  return g_tty_status;
}

/** Retourne l'etat courant des TTYs.
 */
t_bool			tty_status_get(void)
{
  return g_tty_status;
}

/// @}

/** Modifie le TTY courant.
 ** \param Numero du nouveau TTY choisit. Si le numero est > a MAX_TTY
 ** ou < 0, le TTY courant n'est pas change.
 */
int			tty_current_set(t_sint8 tty_number)
{
  // sauvegarde la position du dernier caractere affiche sur la
  // console du TTY.
  g_ttys[g_tty_current].line = line_get();
  g_ttys[g_tty_current].col = col_get();
  if (g_ttys[g_tty_current].current_display_offset == TTY_INTERACTIVE)
    {
      tty_buffer();
      g_ttys[g_tty_current].current_offset -= 160;
    }

  if ((tty_number < MAX_TTY) && (tty_number != -1))
    {
      g_tty_current = tty_number;
      // retablie le TTY.
      /*       g_ttys[g_tty_current].current_display_offset = */
      /* 	g_ttys[g_tty_current].current_offset - g_ttys[tty_number].line; */
      line_set(g_ttys[tty_number].line);
      col_set(g_ttys[tty_number].col);
      tty_change_display();
      g_ttys[g_tty_current].current_display_offset = TTY_INTERACTIVE;
      // repositionne le curseur.
      cursor();
      return 0;
    }
  else
    return -1;
}

/** Renvoie le numero du TTY courant.
 */
int			tty_current_get(void)
{
  return g_tty_current;
}

/// @}

/** Bufferise la ligne courante sur le tty courant (cad 160 char a la fois).
 ** Ceci est realise a chaque nouvelle ligne affichee sur le TTY et a chaque
 ** changement de TTY. CAD lors de l'affichage d'un '\n' a l'ecran et lorsque
 ** l'affichage atteint la fin de la ligne.
 */
void			tty_buffer(void)
{
  char			*console = (char *) (CONSOLE_BASE_ADDR);
  t_uint32		count = (COLUMN * 2);
  t_uint32		line = line_get();
  t_uint32		i = 0;

  // buffer plein
  if ((g_ttys[g_tty_current].current_offset + count) > TTY_BUFFER_LENGTH)
    {
      g_ttys[g_tty_current].current_offset -= count;
      // on supprime une ligne du buffer.
      for (i = 0 ; i < (TTY_BUFFER_LENGTH - (COLUMN * 2)); i++)
	g_ttys[g_tty_current].buffer[i] = g_ttys[g_tty_current].buffer[i + (COLUMN * 2)];
    }

  // on bufferise la ligne courante du TTY.
  for (i = 0 ; i < count; i++)
    g_ttys[g_tty_current].buffer[g_ttys[g_tty_current].current_offset + i] = console[line + i];

  g_ttys[g_tty_current].current_offset += count;
  return;
}

/** Modifie la position de l'affichage sur l'ecran par rapport au buffer.
 ** \param position
 */
void			tty_modify_display(t_sint32 position)
{
  t_uint32		i = 0;
  char			*console = (char *) CONSOLE_BASE_ADDR;

  // si le mode scrolling n'est pas activ�, on bufferise d'abord et on l'active.
  // ensuite.
  if (g_ttys[g_tty_current].current_display_offset == -1)
    {
      tty_buffer();
      g_ttys[g_tty_current].current_offset -= 160;
      // affecte l'offset du 1er char affich� dans la console.
      g_ttys[g_tty_current].current_display_offset =
	g_ttys[g_tty_current].current_offset - line_get();
    }
  cursor_hide();
  // si le scrolling de l'affichage est vers le haut avec un d�passement en vue
  // dans le buffer.
  if (( (t_sint32) (g_ttys[g_tty_current].current_display_offset + position))
      < 0)
    g_ttys[g_tty_current].current_display_offset = 0;
  else
    {
      //modification de l'affichage vers le bas et d�passement buffer.
      if ((g_ttys[g_tty_current].current_display_offset + position + line_get()) >
	  (g_ttys[g_tty_current].current_offset))
	{
	  g_ttys[g_tty_current].current_display_offset =
	    g_ttys[g_tty_current].current_offset - line_get();
	}
      else
	// modification de l'offset pour la modification de l'affichage.
	g_ttys[g_tty_current].current_display_offset += position;
    }

  for (i = 0 ; i < (COLUMN * LINE * 2) ; i ++)
    console[i] =
      g_ttys[g_tty_current].buffer[g_ttys[g_tty_current].current_display_offset
				   + i];

}

/** Affiche la ligne inf�rieure du TTY dans le buffer.
 */
void			tty_line_down(void)
{
  tty_modify_display(COLUMN * 2);
}

/** Affiche la ligne sup�rieure du TTY dans le buffer.
 */
void			tty_line_up(void)
{
  tty_modify_display(- (COLUMN * 2));
}

/** Affiche la page sup�rieure du TTY dans le buffer.
 */
void			tty_page_up(void)
{
  tty_modify_display(- TTY_PAGE_UD);
}

/** Affiche la page inf�rieure du TTY dans le buffer.
 */
void			tty_page_down(void)
{
  tty_modify_display(TTY_PAGE_UD);
}

/** A ne tester que si les ttys sont initialis�s.
 ** Si on est en mode scrolling et que printf est appel�, l'affichage est
 ** modifi�. Et le mode scrolling devient mode interactif.
 */
void			tty_check_scrolling(void)
{
  if (g_ttys[g_tty_current].current_display_offset != TTY_INTERACTIVE)
    {
      tty_change_display();
      g_ttys[g_tty_current].current_display_offset = TTY_INTERACTIVE;
    }
}

/** Change l'affichage sur le TTY courant.
 */
void			tty_change_display(void)
{
  t_uint32		i = 0;
  t_uint32		offset = 0;
  char			*console = (char *) CONSOLE_BASE_ADDR;

  // pour les TTYs bien remplis.
  if (g_ttys[g_tty_current].current_offset >= line_get())
    offset = g_ttys[g_tty_current].current_offset - line_get();
  // pour les TTYs vides.
  else
    offset = 0;

  for (i = 0; i < (line_get() + col_get()) ; i ++)
      console[i] = g_ttys[g_tty_current].buffer[offset + i];
  for (i = (line_get() + col_get()); i < (COLUMN * LINE * 2) ; i += 2)
    {
      console[i] = ' ';
      console[i + 1] = get_attributes();
    }
}

void			tty_clear_screen(void)
{
  char			*c = (char *) CONSOLE_BASE_ADDR;
  /*   char			last_line[160]; */
  int			i = 0;

  /* copie de la derni�re ligne de la console sur la premi�re.*/
  /* si en mode interactive.*/
  if (g_ttys[g_tty_current].current_display_offset == TTY_INTERACTIVE)
    for (i = 0 ; i < (COLUMN * 2) ; i++)
      c[i] = c[i + (COLUMN * LINE * 2) - (COLUMN * 2)];
  /* si en mode scrolling. */
  else
    {
      for (i = 0 ; i < (COLUMN * 2) ; i++)
	c[i] = c[i + (COLUMN * LINE * 2) - (COLUMN * 2)];
    }
/*   tty_buffer(); */
  //g_ttys[g_tty_current].current_offset -= (COLUMN * 2);
  /* effacement de la console. */
  for (i = 160 ; i < (COLUMN * LINE * 2) ; i = i + 2)
    {
      c[i] = ' ';
      c[i + 1] = get_attributes();
    }
  //  col_set(0);
  line_set(0);
  g_ttys[g_tty_current].line = line_get();
  g_ttys[g_tty_current].col = col_get();
  cursor();
}

/// @}
/// @}
