/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Sat Nov  5 04:08:30 2005 Nicolas Clermont
** Last update Mon Nov 14 00:02:34 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mod_libc.h"
#include "../../lib/libc/libc.h"

/*!
** Syscall for vm_rsv
*/
int		mod_vm_rsv(t_asid asid, t_vaddr *vaddr, 
			   t_vsize npages, t_vmflags flags)
{
  int		syscall = SYSCALL_VM_RSV;
  t_vaddr	res = 0;

  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (asid));
  asm(" mov %0, %%ecx"::"m" (npages));
  asm(" mov %0, %%edx"::"m" (flags));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  *vaddr = (t_vaddr)res;

  return 0;
}

/*!
** Syscall for vm_map
*/
int		mod_vm_map(t_asid asid, t_paddr paddr, 
			   t_vaddr vaddr, t_vsize npages)
{
  int		syscall = SYSCALL_VM_MAP;
  int		res = 0;
  unsigned int	*addr = NULL;

  addr = malloc(sizeof (unsigned int) * 2);
  addr[0] = paddr;
  addr[1] = vaddr;
    
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (asid));
  asm(" mov %0, %%ecx"::"m" (addr));
  asm(" mov %0, %%edx"::"m" (npages));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));

  return res;
}

/*!
** Syscall for mm_rel
*/
int	mod_mm_rel(t_asid asid, t_vaddr vaddr, t_vsize npages)
{
  int	syscall = SYSCALL_MM_REL;
  int	res = 0;

  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (asid));
  asm(" mov %0, %%ecx"::"m" (vaddr));
  asm(" mov %0, %%edx"::"m" (npages));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  
  return res;
}

/*!
** Syscall for task_rsv
*/
int		mod_task_rsv(t_class class, t_behav behav,
			     t_prior prior, t_tskid *tskid)
{
  int		syscall = SYSCALL_TASK_RSV;
  unsigned int	res = 0;

  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (class));
  asm(" mov %0, %%ecx"::"m" (behav));
  asm(" mov %0, %%edx"::"m" (prior));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  *tskid = res;
  
  return 0;
}

/*!
** Syscall for as_rsv
*/
int		mod_as_rsv(t_asid *asid)
{
  int		syscall = SYSCALL_AS_RSV;
  unsigned int	res = 0;

  asm("mov %0, %%eax"::"m"(syscall));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  *asid = res;
  
  return 0;
}

/*!
** Syscall for thread_rsv
*/
int		mod_thread_rsv(t_prior prior, t_thrid *thrid)
{
  int		syscall = SYSCALL_THREAD_RSV;
  unsigned int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (prior));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  *thrid = res;
  
  return 0;
}

/*!
** Syscall for as_attach
*/
int	mod_as_attach(t_asid asid, t_tskid tskid)
{
  int	syscall = SYSCALL_AS_ATTACH;
  int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (asid));
  asm(" mov %0, %%ecx"::"m" (tskid));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  
  return res;
}

/*!
** Syscall for thread_attach
*/
int	mod_thread_attach(t_thrid thrid, t_tskid tskid)
{
  int	syscall = SYSCALL_THREAD_ATTACH;
  int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (thrid));
  asm(" mov %0, %%ecx"::"m" (tskid));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  
  return res;
}

/*!
** Syscall for thread_stack
*/
int	mod_thread_stack(t_thrid thrid, t_vsize npages)
{
  int	syscall = SYSCALL_THREAD_STACK;
  int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (thrid));
  asm(" mov %0, %%ecx"::"m" (npages));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  
  return res;
}

/*!
** Syscall for thread_load
*/
int	mod_thread_load(t_thrid thrid, t_thrctx *thrctx)
{
  int	syscall = SYSCALL_THREAD_LOAD;
  int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (thrid));
  asm(" mov %0, %%ecx"::"m" (thrctx));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  
  return res;
}

/*!
** Syscall for thread_run
*/
int	mod_thread_run(t_thrid thrid)
{
  int	syscall = SYSCALL_THREAD_RUN;
  int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (thrid));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  
  return res;
}

/*!
** Syscall for thread_get_stack_addr
*/
t_vaddr		mod_thread_get_stack_addr(t_thrid thrid)
{
  int		syscall = SYSCALL_THREAD_GET_STACK_ADDR;
  t_vaddr	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (thrid));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  
  return res;
}

/*!
** Syscall for as_modid
*/
int		mod_as_set_modid(t_asid asid, t_modid modid)
{
  int		syscall = SYSCALL_AS_SET_MODID;
  int		res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (asid));
  asm(" mov %0, %%ecx"::"m" (modid));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  
  return res;
}

/*!
** Syscall for as_get_modid
*/
int		mod_as_get_modid(t_asid asid, t_modid *modid)
{
  int		syscall = SYSCALL_AS_GET_MODID;
  unsigned int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (asid));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  *modid = (t_modid)res;

  return 0;
}

/*!
** Syscall for as_get_pd_addr
*/
int	mod_as_get_pd_paddr(t_asid asid, t_paddr *pd_paddr)
{
  int	syscall = SYSCALL_AS_GET_PD_PADDR;
  int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (asid));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));
  *pd_paddr = (t_paddr)res;

  return 0;
}

/*!
** Syscall for he_get_param
*/
int	mod_he_get_param(t_paddr pd_paddr, t_vaddr header_elf, int param)
{
  int	syscall = SYSCALL_HE_GET_PARAM;
  int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (pd_paddr));
  asm(" mov %0, %%ecx"::"m" (header_elf));
  asm(" mov %0, %%edx"::"m" (param));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));

  return res;
}

/*!
** Syscall for as_modid_taskid
*/
unsigned int	mod_as_modid_taskid(t_modid modid)
{
  int		syscall = SYSCALL_AS_MODID_TASKID;
  unsigned int	res = 0;
  
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (modid));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(res));

  return res;
}

/*!
** Syscall for task_create
*/
int		mod_task_create(t_module *module, t_tskid *tskid, 
				t_asid *asid, t_thrid *thrid)
{
  int		syscall = SYSCALL_TASK_CREATE;
  
  asm(" mov %0, %%ebx"::"m" (module->npages));
  asm(" mov %0, %%ecx"::"m" (module->paddr));
  asm(" mov %0, %%edx"::"m" (module->modid));
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" int $0x31");
  asm ("mov %%eax, %0":"=m"(*tskid));
  /*   asm ("mov %%ebx, %0":"=m"(*asid)); */
  /*   asm ("mov %%ecx, %0":"=m"(*thrid)); */
  
  thrid = asid;
  
  return 0;
}
