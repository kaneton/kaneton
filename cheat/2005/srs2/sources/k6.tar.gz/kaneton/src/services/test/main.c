/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Nov 28 13:27:24 2005 Damien Laniel
** Last update Sat Dec  3 11:47:49 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
** This is a test server, used only to test other servers
** Currently, it tests the ide server
*/

# include "../../lib/libc/ide.h"
#include "../../lib/libc/libc.h"
#include "../../lib/libc/string.h"

int	main(void)
{
/*   char	buffer[37] = "IDE write with a message ... [OK]\n"; */
/*   char	*read_buffer = NULL; */

/*   write(STDOUT, "Test initialized\n", strlen("Test initialized\n")); */
/*   ide_write(ATA_CTRL1, ATA_MASTER, 1, 1, 20, buffer, strlen(buffer) + 1); */
/*   read_buffer = ide_read(ATA_CTRL1, ATA_MASTER, 1, 1, 20, strlen(buffer) + 1); */
/*   if (read_buffer != NULL) */
/*     write(STDOUT, read_buffer, strlen(read_buffer)); */
/*   else */
/*     write(STDOUT, "Read failed\n", strlen("Read failed\n")); */

  while (1)
    ;
  return 0;
}
