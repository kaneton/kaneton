/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon May 16 19:52:23 2005 Damien Laniel
** Last update Wed May 25 16:11:40 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef	SET_LIST_H_
# define SET_LIST_H_

typedef struct		s_set_list
{
  struct s_set_list	*next;
  void			*data;
}			t_set_list;

typedef int (*t_set_list_cmp_func)(const void *source, const void *destination);

typedef void (*t_set_list_display_func)(const void *data);

typedef void (*t_set_list_free_func)(void *data);


unsigned int	set_list_size(const t_set_list *list);

void		set_list_add_item_head(t_set_list **list, void *data);
void		set_list_add_item_end(t_set_list **list, void *data);
void		set_list_add_item_sorted(t_set_list	**list,
				     void	*data,
				     t_set_list_cmp_func	cmp_func);
void		*set_list_get_item_head(t_set_list *list);
void		*set_list_get_item_end(t_set_list *list);
void		set_list_delete_item(t_set_list		**list,
				     const void		*data,
				     t_set_list_cmp_func		cmp_func,
				     t_set_list_free_func	free_func);
void		*set_list_find_item(const t_set_list	*list,
				const void	*data,
				t_set_list_cmp_func	cmp_func);
void		*set_list_find_prev_item(t_set_list	*list,
					 const void	*data,
					 t_set_list_cmp_func	cmp_func);

void		*set_list_find_next_item(t_set_list	*list,
					 const void	*data,
					 t_set_list_cmp_func	cmp_func);

void		set_list_free(t_set_list **list, t_set_list_free_func free_func);

void		set_list_sort(t_set_list **list, t_set_list_cmp_func cmp_func);

void		set_list_concat(t_set_list **list_a, t_set_list *list_b);
void		set_list_shift(t_set_list **list);
void		set_list_rev(t_set_list **list);
void		set_list_merge(t_set_list	**list_a,
			   const t_set_list	*list_b,
			   t_set_list_cmp_func	cmp_func);

void		set_list_print(const t_set_list *list, t_set_list_display_func display_func);

/*int		set_list_insert_before(const t_id id, void *object); */
/*int		set_list_insert_after(const t_id id, void *object); */

#endif /* !SET_LIST_H_ */
