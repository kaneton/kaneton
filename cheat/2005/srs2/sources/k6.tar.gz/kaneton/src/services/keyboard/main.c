/*
** Copyright (C) Antoine Castaing aka Xebech <castai_a@epita.fr>
**
** Part of kaneton
**
** Started on  Sun Oct  9 11:16:25 2005 xebech
** Last update Wed Nov 23 12:41:00 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../../lib/libc/string.h"
#include "../../lib/libc/libc.h"
#include "../../lib/libc/write.h"
#include "keyb.h"

int	main()
{
  t_msg	*msg = NULL;
  t_kbd	touche;
  t_msg *msg_to_send = NULL;

  current_client = -1;
  is_get_char = 0;

  subscribe_trap(33);
  keyboard_init(US_KEYBOARD);
  while (1)
    {
      msg = wait_msg();
      if ((msg->data_size == 33) && (msg->src == 1))
	{
	  if (!Irq1_FillKeyboardBuffer())
	    if (current_client != -1)
	      {
		touche = get_key();
		msg_to_send = create_msg(current_client, 1);
		strncpy((char *)(msg_to_send->data), &(touche.value), 1);
/* 		my_printf("keyb envoie a %d le char %c\n", current_client, touche.value); */
		send_msg(msg_to_send);
		if (is_get_char)
		  {
		    is_get_char = 0;
		    current_client = -1;
		  }
	      }
	}
      else
	{
	  if (!msg->data)
	    {
	     /*  my_printf("inscription venant de %d\n", msg->src); */
	      if (msg->data_size == 42)
		current_client = -1;
	      else
		{
		  if (msg->data_size == 0)
		    is_get_char = 1;
		  current_client = msg->src;
		}
	    }
	}
    }

  return 0;
}
