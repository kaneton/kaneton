/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Thu Nov  3 17:09:11 2005 Nicolas Clermont
** Last update Sat Dec  3 20:33:35 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mod.h"
#include "mod_cmd.h"
#include "set/set.h"
/* #include "console/console.h" */
#include "../../lib/libc/libc.h"
#include "../../lib/libc/string.h"

/* #define DEBUG_MOD */
int		main(int argc, char **argv)
{
  t_msg		*msg_rcv;
  t_vaddr	grub_addr = 0x100c000;
  char		cmd;

  argc = argc;
  argv = argv;

  /*   init_ttys(); */
  set_init();
  mod_init(grub_addr);

  while (1)
    {
      if ((msg_rcv = wait_msg()))
	{
#ifdef DEBUG_MOD
	  my_printf("msg_rcv : %x, src %d dest %d data %x\n", msg_rcv,
		    msg_rcv->src, msg_rcv->dest, msg_rcv->data);
#endif
	  switch((cmd = *(char *)msg_rcv->data))
	    {
	    case MOD_CMD_PS:
	      mod_cmd_ps(msg_rcv);
	      break;
	    case MOD_CMD_GET_MODID:
	      mod_cmd_get_modid(msg_rcv);
	      break;
	    case MOD_CMD_GET_TSKID:
	      mod_cmd_get_tskid(msg_rcv);
	      break;
	    case MOD_CMD_EXEC:
	      mod_cmd_exec(msg_rcv);
	      break;
	    default:
	      my_printf("Service Mod : Message recu avec cmd = %x\n", cmd);
	      break;
	    }
	}
      else
      	my_printf("Service Mod : j ai recu NULL\n");
    }

  return 0;
}
