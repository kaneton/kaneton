/*
** Copyright (C) xebech aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Fri Oct  7 15:29:47 2005 xebech
** Last update Sat Nov 12 22:49:22 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../lib/libc/libc.h"
#include "cons_print.h"
#include "console.h"

/*!
 * Main function for the console service
 */
int		main()
{
  t_msg		*msg_rcv;
  int		i;

  init_ttys();
  cons_clear_screen();
  cons_print_string("Console server is running\n");

  while (1)
    {
      msg_rcv = wait_msg();
      if (msg_rcv)
	{
	if (msg_rcv->data)
	  for (i = 0; i < msg_rcv->data_size; i++)
	  cons_print_char(((char *)(msg_rcv->data))[i]);
	else
	  cons_print_string("Serveur Console: data null\n");
	}
      else
	cons_print_string("Serveur Console: j'ai recu NULL\n");
    }

  return 0;
}
