/*
** curseur.h for kaneton in /home/xebech/kaneton/src
**
** Made by xebech
** Login   <xebech@epita.fr>
**
** Started on  Wed Mar 23 23:32:41 2005 xebech
** Last update Wed Mar 23 23:33:43 2005 xebech
*/

#ifndef CURSEUR_H_
# define CURSEUR_H_

void	update_curseur_pos_in_char(int offset);
void	update_curseur_x_y(int x, int y);
void	update_curseur(void);

#endif
