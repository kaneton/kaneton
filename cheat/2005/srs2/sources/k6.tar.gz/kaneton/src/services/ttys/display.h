#ifndef   	DISPLAY_H_
# define   	DISPLAY_H_

/// \file display.h
/// \brief definitions des macros pour l'affichage.
#include "../../lib/libc/string.h"
/* # include "asm.h" */
/* # include "lib/klibc/string.h" */
# include "tty.h"
/* # include "drivers/keyboard/keyb.h" */

# define TAB_SIZE		8
# define CONSOLE_BASE_ADDR	0xB8000
# define VGA_COMMAND_PORT	0x3D4
# define VGA_DATA_PORT		0x3D5
# define VGA_CURSOR_HIGH	0xE
# define VGA_CURSOR_LOW		0xF
# define VGA_CURSOR_HIDE	-1
/*
** Couleurs pour l'affichage dans la console.
*/

# define VGA_BLINKING_ON		(0x80)	/* bit 7 a 1 */
# define VGA_BLINKING_OFF	(0x7f)	/* bit 7 a 0 */

# define FOREGROUND_BLACK	0x0
# define FOREGROUND_BLUE	0x1
# define FOREGROUND_GREEN	0x2
# define FOREGROUND_CYAN	0x3
# define FOREGROUND_RED		0x4
# define FOREGROUND_MAGENTA	0x5
# define FOREGROUND_BROWN	0x6
# define FOREGROUND_LIGHTGRAY	0x7
# define FOREGROUND_INTENSITY	0x8
/* #define FOREGROUND_DARKGRAY	8 */
/* #define FOREGROUND_LIGHTBLUE	9 */
/* #define FOREGROUND_LIGHTGREEN	0xA */
/* #define FOREGROUND_LIGHTCYAN	0xB */
/* #define FOREGROUND_LIGHTRED	0xC */
/* #define FOREGROUND_LIGHTMAGENTA 0xD */
/* #define FOREGROUND_YELLOW	0xE */
/* #define FOREGROUND_WHITE	0xF */

# define BACKGROUND_BLACK	(0 << 4)
# define BACKGROUND_BLUE	(1 << 4)
# define BACKGROUND_GREEN	(2 << 4)
# define BACKGROUND_CYAN	(3 << 4)
# define BACKGROUND_RED		(4 << 4)
# define BACKGROUND_MAGENTA	(5 << 4)
# define BACKGROUND_BROWN	(6 << 4)
# define BACKGROUND_LIGHTGRAY	(7 << 4)
/* #define BACKGROUND_DARKGRAY	(8 << 4) */
/* #define BACKGROUND_LIGHTBLUE	(9 << 4) */
/* #define BACKGROUND_LIGHTGREEN	(0xA << 4) */
/* #define BACKGROUND_LIGHTCYAN	(0xB << 4) */
/* #define BACKGROUND_LIGHTRED	(0xC << 4) */
/* #define BACKGROUND_LIGHTMAGENTA (0xD << 4) */
/* #define BACKGROUND_YELLOW	(0xE << 4) */
/* #define BACKGROUND_WHITE	(0xF << 4) */

t_uint32	line_get();
t_uint32	col_get();
void		line_set(t_uint32 new_line);
void		col_set(t_uint32 new_col);
void		clear_screen(void);
void		cons_print_char(char c);
void		cons_print_hex(unsigned long i);
void		cons_print_num(int i);
void		cons_print_string(char *str);
void		cursor(void);
void		cursor_hide(void);
void		printf(const char *format, ...);
void		set_attributes(char a);
int		set_background(int argc, char **args);
int		set_foreground(int argc, char **args);
int		set_blinking(int argc, char **args);
void		set_char_attributes(char a);
char		get_attributes(void);

#endif 	    /* !DISPLAY_H_ */
