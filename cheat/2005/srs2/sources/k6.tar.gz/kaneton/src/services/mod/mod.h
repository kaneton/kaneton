/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Wed Sep 14 16:08:40 2005 Damien Laniel
** Last update Tue Nov  8 16:09:13 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef MOD_H_
# define MOD_H_

# include "../../include/kaneton/types.h"

/*!
** Structure that describe a module
*/
typedef struct	s_module
{
  t_modid	modid;
  t_paddr	paddr;
  t_vaddr	vaddr;
  t_psize	npages;
  char		*name;
  t_lifetime	lifetime;
}		t_module;

/*!
** Initialize the module manager
*/
int	mod_init(t_paddr multiboot);

/*!
** Return the identifier of a module. If it's not loaded, load it
*/
 int	mod_add(char *path, t_lifetime lifetime, t_modid* modid);

/*!
** Remove a module from the module manager
*/
int	mod_remove(t_modid modid);

/*!
** Load a module in a address space
*/
int	mod_load(t_modid modid, t_asid asid);

/*!
** Unload a module and free used memory
*/
int	mod_unload(t_asid asid);

/*!
** Get the virtual address of the entry point of a module
*/
int	mod_entry(t_modid modid, t_vaddr* entry);

/*!
** Get the virtual address of a function in an ELF executable
*/
int	mod_function(t_modid modid, char *function, t_vaddr *entry);

/*!
** Reinitialize the module manager
*/
int	mod_clean(void);

/*!
** Get the module modid
*/
int	mod_get(t_modid modid, t_module **module);

#endif /* !MOD_H_ */
