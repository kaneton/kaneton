/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Tue Nov 22 13:34:11 2005 Damien Laniel
** Last update Sat Dec  3 12:05:56 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "ide.h"
#include "../../lib/libc/libc.h"
#include "../../lib/libc/string.h"

void	ide_test(void)
{
  char	buffer[32] = "IDE Read / write test ... [OK]\n";
  char	*read_buffer = NULL;

  if (ide_write(ATA_CTRL1, ATA_MASTER, 1, 1, 20, buffer, strlen(buffer) + 1) != 0)
    write(STDOUT, "Write failed\n", strlen("Write failed\n"));
  read_buffer = ide_read(ATA_CTRL1, ATA_MASTER, 1, 1, 20, strlen(buffer) + 1);
  if (read_buffer != NULL)
    write(STDOUT, read_buffer, strlen(read_buffer));
  else
    write(STDOUT, "Read failed\n", strlen("Read failed\n"));

  ide_print_device_infos(ATA_CTRL1);
}

static void		ide_write_msg_received(const t_msg *msg_rcv)
{
  /* We've read message type already */
  t_uint32		data_current_offset = sizeof(t_ide_msg_type);
  t_ata_controller	controller;
  t_ata_master_slave	master_slave;
  t_uint16		cylinder;
  t_uint8		head;
  t_uint8		sector;
  t_uint32		data_size;
  void			*data = NULL;

  /* Get from the message all the arguments for ide_write */
  controller = *((t_ata_controller *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_ata_controller);
  master_slave = *((t_ata_master_slave *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_ata_master_slave);
  cylinder = *((t_uint16 *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_uint16);
  head = *((t_uint8 *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_uint8);
  sector = *((t_uint8 *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_uint8);
  data_size = *((t_uint32 *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_uint32);

  data = msg_rcv->data + (void *)data_current_offset;

  ide_write(controller, master_slave, cylinder, head, sector, data, data_size);
}

static void		ide_read_msg_received(const t_msg *msg_rcv)
{
  /* We've read message type already */
  t_uint32		data_current_offset = sizeof(t_ide_msg_type);
  t_ata_controller	controller;
  t_ata_master_slave	master_slave;
  t_uint16		cylinder;
  t_uint8		head;
  t_uint8		sector;
  t_uint32		data_size;
  char			*read_buffer = NULL;
  t_msg			*msg_read;

  controller = *((t_ata_controller *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_ata_controller);
  master_slave = *((t_ata_master_slave *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_ata_master_slave);
  cylinder = *((t_uint16 *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_uint16);
  head = *((t_uint8 *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_uint8);
  sector = *((t_uint8 *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_uint8);
  data_size = *((t_uint32 *)(msg_rcv->data + data_current_offset));
  data_current_offset += sizeof(t_uint32);

  read_buffer = ide_read(controller, master_slave, cylinder, head, sector, data_size);
  if (read_buffer != NULL)
    {
      msg_read = create_msg(msg_rcv->src, data_size);
      memcpy((void *)(msg_read->data), read_buffer, data_size);
      send_msg(msg_read);
    }
  else
    write(STDOUT, "Read failed\n", strlen("Read failed\n"));
}

int			main(void)
{
  t_msg			*msg_rcv;
  t_ide_msg_type	msg_type;

  ide_init();
  write(STDOUT, "IDE initialized\n", strlen("IDE initialized\n"));

  /*   ide_select_drive(ATA_CTRL1, ATA_MASTER); */
/*     ide_test(); */

  while (1)
    {
      msg_rcv = wait_msg();
      if (msg_rcv && msg_rcv->data)
	{
	  msg_type = *((t_ide_msg_type *)(msg_rcv->data));
	  if (msg_type == IDE_MSG_WRITE)
	    ide_write_msg_received(msg_rcv);
	  else
	    {
	      if (msg_type == IDE_MSG_READ)
		ide_read_msg_received(msg_rcv);
	      else
		write(STDOUT, "Unknown message type\n", strlen("Unknown message type\n"));
	    }
	}
      else
	{
	  if (!msg_rcv)
	    {
	      write(STDOUT, "IDE : no message\n", strlen("IDE : no message\n"));
	      while (1);
	    }
	  else
	    {
	      write(STDOUT, "IDE : data NULL\n", strlen("IDE : data NULL\n"));
	      while (1);
	    }
	}
    }

  return 0;
}
