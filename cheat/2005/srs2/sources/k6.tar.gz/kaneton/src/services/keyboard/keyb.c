/*
** Copyright (C) Borek Boissy aka Borek <borek@free.fr>
**
** Part of Kaneton
**
** Started on  Sun Oct  9 19:15:24 2005 Antoine Castaing
** Last update Wed Nov 23 12:23:05 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../../lib/libc/string.h"
#include "keyb.h"

/**
 ** initialise le clavier.
 */
//char		gl_keymap[LANGUAGE_QTY][2][2][256];
char		****gl_keymap;

unsigned char	gl_key_buf[IRQ_BUF_SIZE];
int		gl_code;
char		gl_key;
char		gl_qty;

char		gl_leds;
char		gl_caps;
char		gl_tmp_caps;
char		gl_num;
char		gl_tmp_num;
char		gl_scroll;
char		gl_tmp_scroll;

char		gl_shift;
char		gl_ctrl;
char		gl_windows;
char		gl_menu;
char		gl_shift_left;
char		gl_ctrl_left;
char		gl_windows_left;
char		gl_shift_right;
char		gl_ctrl_right;
char		gl_windows_right;
char		gl_alt;
char		gl_altgr;

t_kbd		gl_kbd;

t_uint8		get_next_elt()
{
  t_uint8	car;
  t_uint16	i;

  car = gl_key_buf[0];
  for (i = 0; (i < IRQ_BUF_SIZE - 1) && (!gl_key_buf[i + 1]); ++i)
    gl_key_buf[i] = gl_key_buf[i + 1];
  return car;
}

void		pop_buffer()
{
  t_sint8	i;
/*   my_printf("Pop buffer\n"); */
/*   while (1); */
  for (i = 0; i < KEY_BUF_SIZE; ++i)
    gl_kbd.code[i] = '\0';
  gl_kbd.code[0] = get_next_elt();
/*   my_printf("pop buffer %x %d\n", gl_kbd.code[0], gl_kbd.code[0]); */
  switch (gl_kbd.code[0])
    {
    case 0xE0:
      gl_kbd.code[1] = get_next_elt();
      break;
    case 0xE1:
      gl_kbd.code[1] = get_next_elt();
      gl_kbd.code[2] = get_next_elt();
      break;
    default:
      break;
    }
}

void		clear_buffer()
{
  t_uint8	i;

  for (i = 0; i < IRQ_BUF_SIZE; ++i)
    gl_key_buf[i] = '\0';
}

/* #define DEBUG_KEYBOARD_SERVER */

void		add_buff_byte(t_uint8 val)
{
  t_uint16	i = 0;
#ifdef DEBUG_KEYBOARD_SERVER
  my_printf("add_buff_byte %x\n", val);
#endif
/*  my_printf("add_buff_byte %d\n", val); */
  while (gl_key_buf[i] != '\0')
    ++i;
  if (i >= IRQ_BUF_SIZE)
    {
      return ;
/*       printf("KEYBOARD ERROR : buffer capacity has been exceeded\n"); */
    }
  else
    gl_key_buf[i] = val;
/*   while (1); */
}
# define KEYBOARD_RESET		0x61
# define KEYBOARD_PORT2		0x64

int		Irq1_FillKeyboardBuffer()
{
  t_uint8	car1;
  t_uint8	car2;
  unsigned char	i = 0;

  do {
    /*  my_printf("PB rien dans le tampon !!\n"); */
    i = inb(KEYBOARD_PORT2);
  } while((i & 0x01) == 0);


  car1 = inb(0x60);

  switch (car1)
    {
    case 0xE0:
#ifdef DEBUG_KEYBOARD_SERVER
      my_printf("Irq1_fillkb .. inb donne 0xE0\n");
#endif
      // On doit s'attendre � recevoir encore un octet
      add_buff_byte(0xE0);
      while ((car1 = inb(0x60)) == 0xE0);
      add_buff_byte(car1);
      break;
    case 0xE1:
#ifdef DEBUG_KEYBOARD_SERVER
      my_printf("Irq1_fillkb .. inb donne 0xE1\n");
#endif
      // On doit s'attendre � recevoir encore deux octets
      add_buff_byte(0xE1);
      while ((car1 = inb(0x60)) == 0xE1);
      add_buff_byte(car1);
      while ((car2 = inb(0x60)) == car1);
      add_buff_byte(car2);
      break;
    default:

#ifdef DEBUG_KEYBOARD_SERVER
      my_printf("Irq1_fillkb .. inb donne default\n");
#endif
    /*    my_printf("Irq1_fillkb .. inb donne default\n"); */
/*       my_printf("Irq1_fillkb .. inb donne %x %d\n", car1, car1); */
      // Cet octet suffit � d�finir la touche
      if (car1 < 128)
	add_buff_byte(car1);
      else
	return 1;
      break;
    }
   ++gl_qty;
#ifdef DEBUG_KEYBOARD_SERVER
  my_printf("Reception d'une interruption clavier...\n");
#endif
 /* my_printf("Reception d'une interruption clavier...\n"); */
   inb(KEYBOARD_RESET);
   return 0;
}

int	loadkeys(int code)
{
  switch(code)
    {
    case US_KEYBOARD:
/*       printf("US keyboard map has been loaded\n"); */
      break;
    case FR_KEYBOARD:
/*       printf("FR keyboard map has been loaded\n"); */
      break;
    default:
/*       printf("ERROR: unknown region code\n"); */
/*       printf("WARNING: US keyboard will be the default mapping\n"); */
      return loadkeys(US_KEYBOARD);
    }
  gl_code = code;
  return 0;
}

void	init_keymap()
{
  int	i, j, k, l;

  for (i = 0; i < LANGUAGE_QTY; ++i)
    for (j = 0; j < 2; ++j)
      for (k = 0; k < 2; ++k)
	for (l = 0; l < 256; ++l)
	  gl_keymap[i][j][k][l] = '\0';

  // Mapping du clavier americain

  gl_keymap[US_KEYBOARD][0][0][14] = '\b';
  gl_keymap[US_KEYBOARD][0][0][15] = '\t';
  gl_keymap[US_KEYBOARD][0][0][16] = 'q';
  gl_keymap[US_KEYBOARD][0][0][17] = 'w';
  gl_keymap[US_KEYBOARD][0][0][18] = 'e';
  gl_keymap[US_KEYBOARD][0][0][19] = 'r';
  gl_keymap[US_KEYBOARD][0][0][20] = 't';
  gl_keymap[US_KEYBOARD][0][0][21] = 'y';
  gl_keymap[US_KEYBOARD][0][0][22] = 'u';
  gl_keymap[US_KEYBOARD][0][0][23] = 'i';
  gl_keymap[US_KEYBOARD][0][0][24] = 'o';
  gl_keymap[US_KEYBOARD][0][0][25] = 'p';
  gl_keymap[US_KEYBOARD][0][0][26] = '[';
  gl_keymap[US_KEYBOARD][0][0][27] = ']';
  gl_keymap[US_KEYBOARD][0][0][30] = 'a';
  gl_keymap[US_KEYBOARD][0][0][31] = 's';
  gl_keymap[US_KEYBOARD][0][0][32] = 'd';
  gl_keymap[US_KEYBOARD][0][0][33] = 'f';
  gl_keymap[US_KEYBOARD][0][0][34] = 'g';
  gl_keymap[US_KEYBOARD][0][0][35] = 'h';
  gl_keymap[US_KEYBOARD][0][0][36] = 'j';
  gl_keymap[US_KEYBOARD][0][0][37] = 'k';
  gl_keymap[US_KEYBOARD][0][0][38] = 'l';
  gl_keymap[US_KEYBOARD][0][0][39] = ';';
  gl_keymap[US_KEYBOARD][0][0][40] = '\'';
  gl_keymap[US_KEYBOARD][0][0][44] = 'z';
  gl_keymap[US_KEYBOARD][0][0][45] = 'x';
  gl_keymap[US_KEYBOARD][0][0][46] = 'c';
  gl_keymap[US_KEYBOARD][0][0][47] = 'v';
  gl_keymap[US_KEYBOARD][0][0][48] = 'b';
  gl_keymap[US_KEYBOARD][0][0][49] = 'n';
  gl_keymap[US_KEYBOARD][0][0][50] = 'm';
  gl_keymap[US_KEYBOARD][0][0][51] = ',';
  gl_keymap[US_KEYBOARD][0][0][52] = '.';
  gl_keymap[US_KEYBOARD][0][0][53] = '/';

  gl_keymap[US_KEYBOARD][0][0][41] = '`';
  gl_keymap[US_KEYBOARD][0][0][2] = '1';
  gl_keymap[US_KEYBOARD][0][0][3] = '2';
  gl_keymap[US_KEYBOARD][0][0][4] = '3';
  gl_keymap[US_KEYBOARD][0][0][5] = '4';
  gl_keymap[US_KEYBOARD][0][0][6] = '5';
  gl_keymap[US_KEYBOARD][0][0][7] = '6';
  gl_keymap[US_KEYBOARD][0][0][8] = '7';
  gl_keymap[US_KEYBOARD][0][0][9] = '8';
  gl_keymap[US_KEYBOARD][0][0][10] = '9';
  gl_keymap[US_KEYBOARD][0][0][11] = '0';
  gl_keymap[US_KEYBOARD][0][0][12] = '-';
  gl_keymap[US_KEYBOARD][0][0][13] = '=';
  gl_keymap[US_KEYBOARD][0][0][43] = '\\';

  gl_keymap[US_KEYBOARD][0][1][16] = 'Q';
  gl_keymap[US_KEYBOARD][0][1][17] = 'W';
  gl_keymap[US_KEYBOARD][0][1][18] = 'E';
  gl_keymap[US_KEYBOARD][0][1][19] = 'R';
  gl_keymap[US_KEYBOARD][0][1][20] = 'T';
  gl_keymap[US_KEYBOARD][0][1][21] = 'Y';
  gl_keymap[US_KEYBOARD][0][1][22] = 'U';
  gl_keymap[US_KEYBOARD][0][1][23] = 'I';
  gl_keymap[US_KEYBOARD][0][1][24] = 'O';
  gl_keymap[US_KEYBOARD][0][1][25] = 'P';
  gl_keymap[US_KEYBOARD][0][1][26] = '{';
  gl_keymap[US_KEYBOARD][0][1][27] = '}';
  gl_keymap[US_KEYBOARD][0][1][30] = 'A';
  gl_keymap[US_KEYBOARD][0][1][31] = 'S';
  gl_keymap[US_KEYBOARD][0][1][32] = 'D';
  gl_keymap[US_KEYBOARD][0][1][33] = 'F';
  gl_keymap[US_KEYBOARD][0][1][34] = 'G';
  gl_keymap[US_KEYBOARD][0][1][35] = 'H';
  gl_keymap[US_KEYBOARD][0][1][36] = 'J';
  gl_keymap[US_KEYBOARD][0][1][37] = 'K';
  gl_keymap[US_KEYBOARD][0][1][38] = 'L';
  gl_keymap[US_KEYBOARD][0][1][39] = ':';
  gl_keymap[US_KEYBOARD][0][1][40] = '"';
  gl_keymap[US_KEYBOARD][0][1][44] = 'Z';
  gl_keymap[US_KEYBOARD][0][1][45] = 'X';
  gl_keymap[US_KEYBOARD][0][1][46] = 'C';
  gl_keymap[US_KEYBOARD][0][1][47] = 'V';
  gl_keymap[US_KEYBOARD][0][1][48] = 'B';
  gl_keymap[US_KEYBOARD][0][1][49] = 'N';
  gl_keymap[US_KEYBOARD][0][1][50] = 'M';
  gl_keymap[US_KEYBOARD][0][1][51] = '<';
  gl_keymap[US_KEYBOARD][0][1][52] = '>';
  gl_keymap[US_KEYBOARD][0][1][53] = '?';

  gl_keymap[US_KEYBOARD][0][1][41] = '~';
  gl_keymap[US_KEYBOARD][0][1][2]  = '!';
  gl_keymap[US_KEYBOARD][0][1][3]  = '@';
  gl_keymap[US_KEYBOARD][0][1][4]  = '#';
  gl_keymap[US_KEYBOARD][0][1][5]  = '$';
  gl_keymap[US_KEYBOARD][0][1][6]  = '%';
  gl_keymap[US_KEYBOARD][0][1][7]  = '^';
  gl_keymap[US_KEYBOARD][0][1][8]  = '&';
  gl_keymap[US_KEYBOARD][0][1][9]  = '*';
  gl_keymap[US_KEYBOARD][0][1][10] = '(';
  gl_keymap[US_KEYBOARD][0][1][11] = ')';
  gl_keymap[US_KEYBOARD][0][1][12] = '_';
  gl_keymap[US_KEYBOARD][0][1][13] = '+';
  gl_keymap[US_KEYBOARD][0][1][43] = '|';

  gl_keymap[US_KEYBOARD][0][0][57] = ' ';
  gl_keymap[US_KEYBOARD][0][1][57] = ' ';
  gl_keymap[US_KEYBOARD][0][0][28] = '\n';
  gl_keymap[US_KEYBOARD][0][1][28] = '\n';

  gl_keymap[US_KEYBOARD][0][0][78] = '+';
  gl_keymap[US_KEYBOARD][0][1][78] = '+';
  gl_keymap[US_KEYBOARD][0][0][74] = '-';
  gl_keymap[US_KEYBOARD][0][1][74] = '-';
  gl_keymap[US_KEYBOARD][0][0][55] = '*';
  gl_keymap[US_KEYBOARD][0][1][55] = '*';

  // Mapping du clavier francais

  gl_keymap[FR_KEYBOARD][0][0][14] = '\b';
  gl_keymap[FR_KEYBOARD][0][0][15] = '\t';
  gl_keymap[FR_KEYBOARD][0][0][16] = 'a';
  gl_keymap[FR_KEYBOARD][0][0][17] = 'z';
  gl_keymap[FR_KEYBOARD][0][0][18] = 'e';
  gl_keymap[FR_KEYBOARD][0][0][19] = 'r';
  gl_keymap[FR_KEYBOARD][0][0][20] = 't';
  gl_keymap[FR_KEYBOARD][0][0][21] = 'y';
  gl_keymap[FR_KEYBOARD][0][0][22] = 'u';
  gl_keymap[FR_KEYBOARD][0][0][23] = 'i';
  gl_keymap[FR_KEYBOARD][0][0][24] = 'o';
  gl_keymap[FR_KEYBOARD][0][0][25] = 'p';
  gl_keymap[FR_KEYBOARD][1][0][16] = 'a';
  gl_keymap[FR_KEYBOARD][1][0][17] = 'z';
  gl_keymap[FR_KEYBOARD][1][0][18] = 'e';
  gl_keymap[FR_KEYBOARD][1][0][19] = 'r';
  gl_keymap[FR_KEYBOARD][1][0][20] = 't';
  gl_keymap[FR_KEYBOARD][1][0][21] = 'y';
  gl_keymap[FR_KEYBOARD][1][0][22] = 'u';
  gl_keymap[FR_KEYBOARD][1][0][23] = 'i';
  gl_keymap[FR_KEYBOARD][1][0][24] = 'o';
  gl_keymap[FR_KEYBOARD][1][0][25] = 'p';
  gl_keymap[FR_KEYBOARD][0][0][26] = '^';
  gl_keymap[FR_KEYBOARD][0][0][27] = '$';

  gl_keymap[FR_KEYBOARD][0][0][30] = 'q';
  gl_keymap[FR_KEYBOARD][0][0][31] = 's';
  gl_keymap[FR_KEYBOARD][0][0][32] = 'd';
  gl_keymap[FR_KEYBOARD][0][0][33] = 'f';
  gl_keymap[FR_KEYBOARD][0][0][34] = 'g';
  gl_keymap[FR_KEYBOARD][0][0][35] = 'h';
  gl_keymap[FR_KEYBOARD][0][0][36] = 'j';
  gl_keymap[FR_KEYBOARD][0][0][37] = 'k';
  gl_keymap[FR_KEYBOARD][0][0][38] = 'l';
  gl_keymap[FR_KEYBOARD][0][0][39] = 'm';
  gl_keymap[FR_KEYBOARD][1][0][30] = 'q';
  gl_keymap[FR_KEYBOARD][1][0][31] = 's';
  gl_keymap[FR_KEYBOARD][1][0][32] = 'd';
  gl_keymap[FR_KEYBOARD][1][0][33] = 'f';
  gl_keymap[FR_KEYBOARD][1][0][34] = 'g';
  gl_keymap[FR_KEYBOARD][1][0][35] = 'h';
  gl_keymap[FR_KEYBOARD][1][0][36] = 'j';
  gl_keymap[FR_KEYBOARD][1][0][37] = 'k';
  gl_keymap[FR_KEYBOARD][1][0][38] = 'l';
  gl_keymap[FR_KEYBOARD][1][0][39] = 'm';
  gl_keymap[FR_KEYBOARD][0][0][40] = '|';

  gl_keymap[FR_KEYBOARD][0][0][44] = 'w';
  gl_keymap[FR_KEYBOARD][0][0][45] = 'x';
  gl_keymap[FR_KEYBOARD][0][0][46] = 'c';
  gl_keymap[FR_KEYBOARD][0][0][47] = 'v';
  gl_keymap[FR_KEYBOARD][0][0][48] = 'b';
  gl_keymap[FR_KEYBOARD][0][0][49] = 'n';
  gl_keymap[FR_KEYBOARD][1][0][44] = 'w';
  gl_keymap[FR_KEYBOARD][1][0][45] = 'x';
  gl_keymap[FR_KEYBOARD][1][0][46] = 'c';
  gl_keymap[FR_KEYBOARD][1][0][47] = 'v';
  gl_keymap[FR_KEYBOARD][1][0][48] = 'b';
  gl_keymap[FR_KEYBOARD][1][0][49] = 'n';
  gl_keymap[FR_KEYBOARD][0][0][50] = ',';
  gl_keymap[FR_KEYBOARD][0][0][51] = ';';
  gl_keymap[FR_KEYBOARD][0][0][52] = ':';
  gl_keymap[FR_KEYBOARD][0][0][53] = '!';

  gl_keymap[FR_KEYBOARD][0][0][41] = '*';
  gl_keymap[FR_KEYBOARD][0][0][2] = '&';
  gl_keymap[FR_KEYBOARD][0][0][3] = '{';
  gl_keymap[FR_KEYBOARD][0][0][4] = '"';
  gl_keymap[FR_KEYBOARD][0][0][5] = '\'';
  gl_keymap[FR_KEYBOARD][0][0][6] = '(';
  gl_keymap[FR_KEYBOARD][0][0][7] = '-';
  gl_keymap[FR_KEYBOARD][0][0][8] = '}';
  gl_keymap[FR_KEYBOARD][0][0][9] = '_';
  gl_keymap[FR_KEYBOARD][0][0][10] = '/';
  gl_keymap[FR_KEYBOARD][0][0][11] = '@';
  gl_keymap[FR_KEYBOARD][0][0][12] = ')';
  gl_keymap[FR_KEYBOARD][0][0][13] = '=';
  gl_keymap[FR_KEYBOARD][0][0][43] = '*';

  gl_keymap[FR_KEYBOARD][0][1][16] = 'A';
  gl_keymap[FR_KEYBOARD][0][1][17] = 'Z';
  gl_keymap[FR_KEYBOARD][0][1][18] = 'E';
  gl_keymap[FR_KEYBOARD][0][1][19] = 'R';
  gl_keymap[FR_KEYBOARD][0][1][20] = 'T';
  gl_keymap[FR_KEYBOARD][0][1][21] = 'Y';
  gl_keymap[FR_KEYBOARD][0][1][22] = 'U';
  gl_keymap[FR_KEYBOARD][0][1][23] = 'I';
  gl_keymap[FR_KEYBOARD][0][1][24] = 'O';
  gl_keymap[FR_KEYBOARD][0][1][25] = 'P';
  gl_keymap[FR_KEYBOARD][1][1][16] = 'A';
  gl_keymap[FR_KEYBOARD][1][1][17] = 'Z';
  gl_keymap[FR_KEYBOARD][1][1][18] = 'E';
  gl_keymap[FR_KEYBOARD][1][1][19] = 'R';
  gl_keymap[FR_KEYBOARD][1][1][20] = 'T';
  gl_keymap[FR_KEYBOARD][1][1][21] = 'Y';
  gl_keymap[FR_KEYBOARD][1][1][22] = 'U';
  gl_keymap[FR_KEYBOARD][1][1][23] = 'I';
  gl_keymap[FR_KEYBOARD][1][1][24] = 'O';
  gl_keymap[FR_KEYBOARD][1][1][25] = 'P';
  gl_keymap[FR_KEYBOARD][0][1][26] = '<';
  gl_keymap[FR_KEYBOARD][0][1][27] = '>';


  gl_keymap[FR_KEYBOARD][0][1][30] = 'Q';
  gl_keymap[FR_KEYBOARD][0][1][31] = 'S';
  gl_keymap[FR_KEYBOARD][0][1][32] = 'D';
  gl_keymap[FR_KEYBOARD][0][1][33] = 'F';
  gl_keymap[FR_KEYBOARD][0][1][34] = 'G';
  gl_keymap[FR_KEYBOARD][0][1][35] = 'H';
  gl_keymap[FR_KEYBOARD][0][1][36] = 'J';
  gl_keymap[FR_KEYBOARD][0][1][37] = 'K';
  gl_keymap[FR_KEYBOARD][0][1][38] = 'L';
  gl_keymap[FR_KEYBOARD][0][1][39] = 'M';
  gl_keymap[FR_KEYBOARD][1][1][30] = 'Q';
  gl_keymap[FR_KEYBOARD][1][1][31] = 'S';
  gl_keymap[FR_KEYBOARD][1][1][32] = 'D';
  gl_keymap[FR_KEYBOARD][1][1][33] = 'F';
  gl_keymap[FR_KEYBOARD][1][1][34] = 'G';
  gl_keymap[FR_KEYBOARD][1][1][35] = 'H';
  gl_keymap[FR_KEYBOARD][1][1][36] = 'J';
  gl_keymap[FR_KEYBOARD][1][1][37] = 'K';
  gl_keymap[FR_KEYBOARD][1][1][38] = 'L';
  gl_keymap[FR_KEYBOARD][1][1][39] = 'M';
  gl_keymap[FR_KEYBOARD][0][1][40] = '%';


  gl_keymap[FR_KEYBOARD][0][1][44] = 'W';
  gl_keymap[FR_KEYBOARD][0][1][45] = 'X';
  gl_keymap[FR_KEYBOARD][0][1][46] = 'C';
  gl_keymap[FR_KEYBOARD][0][1][47] = 'V';
  gl_keymap[FR_KEYBOARD][0][1][48] = 'B';
  gl_keymap[FR_KEYBOARD][0][1][49] = 'N';
  gl_keymap[FR_KEYBOARD][1][1][44] = 'W';
  gl_keymap[FR_KEYBOARD][1][1][45] = 'X';
  gl_keymap[FR_KEYBOARD][1][1][46] = 'C';
  gl_keymap[FR_KEYBOARD][1][1][47] = 'V';
  gl_keymap[FR_KEYBOARD][1][1][48] = 'B';
  gl_keymap[FR_KEYBOARD][1][1][49] = 'N';
  gl_keymap[FR_KEYBOARD][0][1][50] = '?';
  gl_keymap[FR_KEYBOARD][0][1][51] = '.';
  gl_keymap[FR_KEYBOARD][0][1][52] = '/';
  gl_keymap[FR_KEYBOARD][0][1][53] = '\\';


  gl_keymap[FR_KEYBOARD][0][1][41] = '~';
  gl_keymap[FR_KEYBOARD][0][1][2]  = '1';
  gl_keymap[FR_KEYBOARD][0][1][3]  = '2';
  gl_keymap[FR_KEYBOARD][0][1][4]  = '3';
  gl_keymap[FR_KEYBOARD][0][1][5]  = '4';
  gl_keymap[FR_KEYBOARD][0][1][6]  = '5';
  gl_keymap[FR_KEYBOARD][0][1][7]  = '6';
  gl_keymap[FR_KEYBOARD][0][1][8]  = '7';
  gl_keymap[FR_KEYBOARD][0][1][9]  = '8';
  gl_keymap[FR_KEYBOARD][0][1][10] = '9';
  gl_keymap[FR_KEYBOARD][0][1][11] = '0';
  gl_keymap[FR_KEYBOARD][0][1][12] = ']';
  gl_keymap[FR_KEYBOARD][0][1][13] = '+';
  gl_keymap[FR_KEYBOARD][0][1][43] = '#';


  gl_keymap[FR_KEYBOARD][0][0][57] = ' ';
  gl_keymap[FR_KEYBOARD][0][1][57] = ' ';
  gl_keymap[FR_KEYBOARD][0][0][28] = '\n';
  gl_keymap[FR_KEYBOARD][0][1][28] = '\n';

  gl_keymap[FR_KEYBOARD][0][0][78] = '+';
  gl_keymap[FR_KEYBOARD][0][1][78] = '+';
  gl_keymap[FR_KEYBOARD][0][0][74] = '-';
  gl_keymap[FR_KEYBOARD][0][1][74] = '-';
  gl_keymap[FR_KEYBOARD][0][0][55] = '*';
  gl_keymap[FR_KEYBOARD][0][1][55] = '*';


  gl_keymap[FR_KEYBOARD][1][0][3] = '~';
  gl_keymap[FR_KEYBOARD][1][0][4] = '#';
  gl_keymap[FR_KEYBOARD][1][0][5] = '{';
  gl_keymap[FR_KEYBOARD][1][0][6] = '[';
  gl_keymap[FR_KEYBOARD][1][0][7] = '|';
  gl_keymap[FR_KEYBOARD][1][0][8] = '\'';
  gl_keymap[FR_KEYBOARD][1][0][9] = '\\';
  gl_keymap[FR_KEYBOARD][1][0][10] = '^';
  gl_keymap[FR_KEYBOARD][1][0][11] = '@';
  gl_keymap[FR_KEYBOARD][1][0][12] = ']';
  gl_keymap[FR_KEYBOARD][1][0][13] = '}';
}

int		keyboard_init(int code)
{
  t_uint8	i;
  t_uint8	j;
  t_uint8	k;
  char		*tmp;


  my_printf("Starting Keyboard initialization... \n");
  gl_keymap = malloc(LANGUAGE_QTY * sizeof (char ****));
#ifdef DEBUG_KEYBOARD_SERVER
  my_printf("retour de malloc a %x\n",  gl_keymap);
#endif
  for (i = 0; i < LANGUAGE_QTY; ++i)
    {
      j = k;
#ifdef DEBUG_KEYBOARD_SERVER
     my_printf("bizarre %i\n",  gl_keymap[0]);
     my_printf("bizarre %i %i\n",  gl_keymap[0], gl_keymap[1]);
#endif
      gl_keymap[i] = NULL;
      tmp = malloc(2 * sizeof (char ***));
      gl_keymap[i] = (char ***)tmp;
/*       gl_keymap[i] = malloc(2 * sizeof (char ***)); */
/*       my_printf("@ du keymap %i est %x\n", i, (unsigned int)gl_keymap[i]); */
/*       while (1); */


      for (j = 0; j < 2; ++j)
	{
	  tmp = malloc(2 * sizeof (char **));
	  /* 	  gl_keymap[i][j] = malloc(2 * sizeof (char **)); */
	  gl_keymap[i][j] = (char **)tmp;
	  for (k = 0; k < 2; ++k)
	    {
	      tmp = malloc(256 * sizeof (char *));
	      gl_keymap[i][j][k] = (char *)tmp;
	      /* 	      gl_keymap[i][j][k] = malloc(256 * sizeof (char *)); */
	    }
	}
    }
/*   write(STDOUT, "WHILE1\n", */
/* 	strlen("WHILE1\n")); */
/* /\*  while (1); *\/ */
  clear_buffer();

  if (loadkeys(code))
    return 1;

  gl_shift		= 0;
  gl_ctrl		= 0;
  gl_windows		= 0;
  gl_menu		= 0;
  gl_shift_left		= 0;
  gl_ctrl_left		= 0;
  gl_windows_left	= 0;
  gl_shift_right	= 0;
  gl_ctrl_right		= 0;
  gl_windows_right	= 0;
  gl_alt		= 0;
  gl_altgr		= 0;
  init_keymap();
  for (i = 0; i < KEY_BUF_SIZE; ++i)
    gl_kbd.code[i] = 0;
 /*  pic_enable(IRQ_KEYBOARD); */
  gl_leds = 0;
  gl_num = 1;
  gl_tmp_num = 0x3;
  set_led(LED_NUM);
  gl_caps = 0;
  gl_tmp_caps = 0xF;
  gl_scroll = 0;
  gl_tmp_scroll = 0xF;
  gl_qty = 0;
/*   printf("Keyboard initialisation is OK\n"); */
  return 0;
}

char	test_CAPS(char car)
{
  return car;
  if (!gl_caps)
    return car;
  if ('a' <= car && car <= 'z')
    return car - 0x20;
  if ('A' <= car && car <= 'Z')
    return car + 0x20;
  return car;
}

void	identify_key()
{
  gl_key = '\0';
  switch(gl_kbd.code[0])
    {
    // Gestion des cas tordus ;-)
    case '\0':
      break;

    // Touche . du keypad enfonc�e
    case 83:
      if (gl_num)
	gl_key = '.';
      break;

    // Touche 0 du keypad enfonc�e
    case 82:
      if (gl_num)
	gl_key = '0';
      break;

    // Touche 1 du keypad enfonc�e
    case 79:
      if (gl_num)
	gl_key = '1';
      break;

    // Touche 2 du keypad enfonc�e
    case 80:
      if (gl_num)
	gl_key = '2';
      break;

    // Touche 3 du keypad enfonc�e
    case 81:
      if (gl_num)
	gl_key = '3';
      break;

    // Touche 4 du keypad enfonc�e
    case 75:
      if (gl_num)
	gl_key = '4';
      break;

    // Touche 5 du keypad enfonc�e
    case 76:
      if (gl_num)
	gl_key = '5';
      break;

    // Touche 6 du keypad enfonc�e
    case 77:
      if (gl_num)
	gl_key = '6';
      break;

    // Touche 7 du keypad enfonc�e
    case 71:
      if (gl_num)
	gl_key = '7';
      break;

    // Touche 8 du keypad enfonc�e
    case 72:
      if (gl_num)
	gl_key = '8';
      break;

    // Touche 9 du keypad enfonc�e
    case 73:
      if (gl_num)
	gl_key = '9';
      break;

    // Touche CAPS LOCK enfonc�e
    case 58:
      if (gl_tmp_caps & 0x8)
	{
	  gl_tmp_caps = 0x1;
	  gl_caps = 1;
	  set_led(LED_CAPS);
	}
      else if (gl_tmp_caps & 0x2)
	{
	  gl_tmp_caps = 0x7;
	  gl_caps = 0;
	  unset_led(LED_CAPS);
	}
      break;

    // Touche CAPS LOCK relach�e
    case 186:
      if (gl_tmp_caps & 0x4)
	gl_tmp_caps = 0xF;
      else if (gl_tmp_caps & 0x1)
	gl_tmp_caps = 0x3;
      break;

    // Touche SCROLL LOCK enfonc�e
    case 70:
      if (gl_tmp_scroll & 0x8)
	{
	  gl_tmp_scroll = 0x1;
	  gl_scroll = 1;
	  set_led(LED_SCROLL);
	}
      else if (gl_tmp_scroll & 0x2)
	{
	  gl_tmp_scroll = 0x7;
	  gl_scroll = 0;
	  unset_led(LED_SCROLL);
	}
      break;

    // Touche SCROLL LOCK relach�e
    case 198:
      if (gl_tmp_scroll & 0x4)
	gl_tmp_scroll = 0xF;
      else if (gl_tmp_scroll & 0x1)
	gl_tmp_scroll = 0x3;
      break;

    // Touche NUM LOCK enfonc�e
    case 69:
      if (gl_tmp_num & 0x8)
	{
	  gl_tmp_num = 0x1;
	  gl_num = 1;
	  set_led(LED_NUM);
	}
      else if (gl_tmp_num & 0x2)
	{
	  gl_tmp_num = 0x7;
	  gl_num = 0;
	  unset_led(LED_NUM);
	}
      break;

    // Touche NUM LOCK relach�e
    case 197:
      if (gl_tmp_num & 0x4)
	gl_tmp_num = 0xF;
      else if (gl_tmp_num & 0x1)
	gl_tmp_num = 0x3;
      break;

    // Touche SHIFT gauche enfonc�e
    case 42:
      gl_shift = 1;
      gl_shift_left = 1;
      break;

    // Touche SHIFT gauche relach�e
    case 170:
      gl_shift_left = 0;
      if (!gl_shift_right)
	gl_shift = 0;
      break;

    // Touche SHIFT droite enfonc�e
    case 54:
      gl_shift = 1;
      gl_shift_right = 1;
      break;

    // Touche SHIFT droite relach�e
    case 182:
      gl_shift_right = 0;
      if (!gl_shift_left)
	gl_shift = 0;
      break;

    // Touche ALT enfonc�e
    case 56:
      gl_alt = 1;
      break;

    // Touche ALT relach�e
    case 184:
      gl_alt = 0;
      break;

    // Touche CTRL gauche enfonc�e
    case 29:
      gl_ctrl_left = 1;
      gl_ctrl = 1;
      break;

    // Touche CTRL gauche relach�e
    case 157:
      gl_ctrl_left = 0;
      if (!gl_ctrl_right)
	gl_ctrl = 0;
      break;

    // D�tection d'un code �tendu sur deux caract�res
    case 0xE0:
      switch(gl_kbd.code[1])
	{
	// Touche '/' du keypad enfonc�e
	case 53:
	  gl_key = '/';
	  //printf("Touche `/' enfoncee\n");
	  return;

	// Touche ENTER du keypad enfonc�e
	case 28:
	  //printf("Touche `ENTER' enfoncee\n");
	  gl_key = '\n';
	  return;;

	// Touche ALTGR enfonc�e
	case 56:
	  gl_altgr = 1;
	  break;

	// Touche ALTGR relach�e
	case 184:
	  gl_altgr = 0;
	  break;

	// Touche CTRL droite enfonc�e
	case 29:
	  gl_ctrl_right = 1;
	  gl_ctrl = 1;
	  break;

	// Touche CTRL droite relach�e
	case 157:
	  gl_ctrl_right = 0;
	  if (!gl_ctrl_left)
	    gl_ctrl = 0;
	  break;

	// Touche WINDOWS gauche enfonc�e
	case 91:
	  gl_windows_left = 1;
	  gl_windows = 1;
	  break;

	// Touche WINDOWS gauche relach�e
	case 219:
	  gl_windows_left = 0;
	  if (!gl_windows_right)
	    gl_windows = 0;
	  break;

	// Touche WINDOWS droite enfonc�e
	case 92:
	  gl_windows_right = 1;
	  gl_windows = 1;
	  break;

	// Touche WINDOWS droite relach�e
	case 220:
	  gl_windows_right = 0;
	  if (!gl_windows_left)
	    gl_windows = 0;
	  break;

	// Touche MENU enfonc�e
	case 93:
	  gl_menu = 1;
	  break;

	// Touche MENU relach�e
	case 221:
	  gl_menu = 0;
	  break;

	default:
	  break;
	}
      break;

    // D�tection d'un code �tendu sur trois caract�res
    case 0xE1:
      break;
    default:
      /* my_printf("identify key avec %d %s\n", gl_kbd.code[1], gl_kbd.code[0]); */
      if (gl_kbd.code[1] == 0 && gl_kbd.code[0] != 0)
	{
	  gl_key = test_CAPS(gl_keymap[gl_code][(int)gl_altgr][(int)gl_shift][gl_kbd.code[0]]);
	}
      break;
    }
}

t_kbd		get_key()
{
  int		i = 0;
/*   unsigned char	car; */
/*   int		cpt; */

  pop_buffer();
  identify_key();
 /*  my_printf("Apres identify\n"); */
/*   while (1); */
/*   my_printf("ds get_key gl_key %d gl_kbd.code[0] %d\n", gl_key, gl_kbd.code[0]); */
 /*  while (gl_key > 127) */
/*     { */
/*       pop_buffer(); */
/*       identify_key(); */
/*     } */
  gl_kbd.menu		= gl_menu;
  gl_kbd.windows	= gl_windows;
  gl_kbd.windows_left	= gl_windows_left;
  gl_kbd.windows_right	= gl_windows_right;
  gl_kbd.shift		= gl_shift;
  gl_kbd.shift_left	= gl_shift_left;
  gl_kbd.shift_right	= gl_shift_right;
  gl_kbd.ctrl		= gl_ctrl;
  gl_kbd.ctrl_left	= gl_ctrl_left;
  gl_kbd.ctrl_right	= gl_ctrl_right;
  gl_kbd.alt		= gl_alt;
  gl_kbd.altgr		= gl_altgr;
  gl_kbd.value		= gl_key;

  // FIXME : Goritude
/*   for (i = 0; i < 400000; ++i); */

  if (!gl_qty)
    gl_kbd.value = '\0';
  else if (gl_kbd.code[0])
    --gl_qty;

  return gl_kbd;
}

char	is_printable(t_kbd kbd)
{
  if (kbd.value == 0 || kbd.value == '\0')
    return 0;

  // A un caract�re imprimable correspond un code d'une taille
  // d'un octet seulement
  if (kbd.code[0] == 0)
    return 0;

  // En clavier am�ricain, la touche altgr ne peut pas provoquer
  // l'affichage d'un caract�re
  if (gl_code == US_KEYBOARD &&
      is_altgr(kbd))
    return 0;
  if (kbd.value != '\0' &&
 /*      kbd.value < 128 && */
      !is_ctrl(kbd) &&
      !is_alt(kbd))
    return 1;
  return 0;
}

char	is_menu(t_kbd kbd)
{
  return kbd.menu;
}

char	is_windows(t_kbd kbd)
{
  return kbd.windows;
}

char	is_windows_left(t_kbd kbd)
{
  return kbd.windows_left;
}

char	is_windows_right(t_kbd kbd)
{
  return kbd.windows_right;
}

char	is_shift(t_kbd kbd)
{
  return kbd.shift;
}

char	is_shift_left(t_kbd kbd)
{
  return kbd.shift_left;
}

char	is_shift_right(t_kbd kbd)
{
  return kbd.shift_right;
}

char	is_ctrl(t_kbd kbd)
{
  return kbd.ctrl;
}

char	is_ctrl_left(t_kbd kbd)
{
  return kbd.ctrl_left;
}

char	is_ctrl_right(t_kbd kbd)
{
  return kbd.ctrl_right;
}

char	is_alt(t_kbd kbd)
{
  return kbd.alt;
}

char	is_altgr(t_kbd kbd)
{
  return kbd.altgr;
}

char	is_f1(t_kbd kbd)
{
  if (kbd.code[0] == 0x3b)
    return 1;
  return 0;
}

char	is_f2(t_kbd kbd)
{
  if (kbd.code[0] == 0x3c)
    return 1;
  return 0;
}

char	is_f3(t_kbd kbd)
{
  if (kbd.code[0] == 0x3d)
    return 1;
  return 0;
}

char	is_f4(t_kbd kbd)
{
  if (kbd.code[0] == 0x3e)
    return 1;
  return 0;
}

char	is_f5(t_kbd kbd)
{
  if (kbd.code[0] == 0x3f)
    return 1;
  return 0;
}

char	is_f6(t_kbd kbd)
{
  if (kbd.code[0] == 0x40)
    return 1;
  return 0;
}

char	is_f7(t_kbd kbd)
{
  if (kbd.code[0] == 0x41)
    return 1;
  return 0;
}

char	is_f8(t_kbd kbd)
{
  if (kbd.code[0] == 0x42)
    return 1;
  return 0;
}

char	is_f9(t_kbd kbd)
{
  if (kbd.code[0] == 0x43)
    return 1;
  return 0;
}

char	is_f10(t_kbd kbd)
{
  if (kbd.code[0] == 0x44)
    return 1;
  return 0;
}

char	is_f11(t_kbd kbd)
{
  if (kbd.code[0] == 0x57)
    return 1;
  return 0;
}

char	is_f12(t_kbd kbd)
{
  if (kbd.code[0] == 0x58)
    return 1;
  return 0;
}

char	is_left(t_kbd kbd)
{
  if (kbd.code[1] == 75 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 75 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_right(t_kbd kbd)
{
  if (kbd.code[1] == 77 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 77 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_up(t_kbd kbd)
{
  if (kbd.code[1] == 72 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 72 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_down(t_kbd kbd)
{
  if (kbd.code[1] == 80 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 80 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_pageup(t_kbd kbd)
{
  if (kbd.code[1] == 73 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 73 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_pagedown(t_kbd kbd)
{
  if (kbd.code[1] == 81 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 81 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_insert(t_kbd kbd)
{
  if (kbd.code[1] == 82 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 82 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_delete(t_kbd kbd)
{
  if (kbd.code[1] == 83 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 83 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_home(t_kbd kbd)
{
  if (kbd.code[1] == 71 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 71 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_end(t_kbd kbd)
{
  if (kbd.code[1] == 79 &&
      kbd.code[0] == 224)
    return 1;
  if (kbd.code[0] == 79 &&
      !gl_num)
    return 1;
  return 0;
}

char	is_escape(t_kbd kbd)
{
  if (kbd.code[0] == 0x1)
    return 1;
  return 0;
}

int	send_key(int value)
{
  value = value;
  return 0;
}

void	display_buffer(t_kbd kbd)
{
/*   int	i; */

  if (!kbd.code[0])
    return;
/*   printf("Code touche :"); */
/*   for (i = 0; i < KEY_BUF_SIZE; ++i) */
/*     printf(" %d", kbd.code[i]); */
/*   printf("\n"); */
}

void	display_tmp_buffer(/* t_kbd kbd */)
{
/*   int	i; */

/*   printf("Code touche :"); */
/*   for (i = 0; i < KEY_BUF_SIZE; ++i) */
/*     printf(" %d", gl_key_buf[i]); */
/*   printf("\n"); */
}


void	set_led(char value)
{
  gl_leds |= value;
  // Pr�paration � l'allumage de led
  KB_WAIT();
  outb(0xED, 0x60);

  // Changement d'�tat des leds
  KB_WAIT();
  outb(gl_leds, 0x60);
}

void	unset_led(char value)
{
  gl_leds &= ~value;
  // Pr�paration � l'allumage de led
  KB_WAIT();
  outb(0xED, 0x60);

  // Changement d'�tat des leds
  KB_WAIT();
  outb(gl_leds, 0x60);
}

char	get_leds(void)
{
  return gl_leds;
}

char	scroll_lock_enabled(void)
{
  return gl_scroll;
}
