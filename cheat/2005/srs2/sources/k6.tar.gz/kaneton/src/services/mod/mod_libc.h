/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Sun Nov  6 23:43:29 2005 Nicolas Clermont
** Last update Sun Nov 13 23:25:41 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef _MOD_LIBC_H_
# define _MOD_LIBC_H_

# include "mod.h"
# include "../../include/kaneton/types.h"
# include "../../lib/libc/syscall.h"
# include "../../kaneton/class.h"
# include "../../kaneton/behav.h"
# include "../../kaneton/prior.h"
# include "../../kaneton/cpu.h"

# define VM_FLAG_ANY	0x0

int		mod_vm_rsv(t_asid asid, t_vaddr *vaddr, 
			   t_vsize npages, t_vmflags flags);

int		mod_vm_map(t_asid asid, t_paddr paddr, 
			   t_vaddr vaddr, t_vsize npages);

int		mod_mm_rel(t_asid asid, t_vaddr vaddr, 
			   t_vsize npages);

int		mod_task_rsv(t_class class, t_behav behav,
			     t_prior prior, t_tskid *tskid);

int		mod_as_rsv(t_asid *asid);

int		mod_thread_rsv(t_prior prior, t_thrid *thrid);

int		mod_as_attach(t_asid asid, t_tskid tskid);

int		mod_thread_attach(t_thrid thrid, t_tskid tskid);

int		mod_thread_stack(t_thrid thrid, t_vsize npages);

int		mod_thread_load(t_thrid thrid, t_thrctx *thrctx);

int		mod_thread_run(t_thrid thrid);

t_vaddr		mod_thread_get_stack_addr(t_thrid thrid);

int		mod_as_set_modid(t_asid asid, t_modid modid);

int		mod_as_get_modid(t_asid asid, t_modid *modid);

int		mod_as_get_pd_paddr(t_asid asid, 
				    t_paddr *pd_paddr);

int		mod_he_get_param(t_paddr pd_paddr, t_vaddr header_elf, int param);

unsigned int	mod_as_modid_taskid(t_modid modid);

int		mod_task_create(t_module *module, t_tskid *tskid, 
				t_asid *asid, t_thrid *thrid);

#endif		/* !_MOD_LIBC_H_ */
