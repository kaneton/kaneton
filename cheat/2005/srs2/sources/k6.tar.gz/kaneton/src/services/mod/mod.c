/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sat Oct 29 01:00:58 2005 Nicolas Clermont
** Last update Sat Dec  3 20:50:00 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mod.h"
#include "elf.h"
#include "mod_libc.h"
#include "set/set.h"
/* #include "console/console.h" */
#include "../../bootloader/multiboot.h"
#include "../../lib/libc/libc.h"
#include "../../lib/libc/string.h"

#define	THREAD_STACKSZ	1

/*!
** The set that contains all the modules
*/
t_setid			mod_setid;

/*!
** The next identifier usable for a new module
*/
static t_modid		cur_modid = 0;

/*!
** Initialize the module manager
** @param multiboot	The adress of the multiboot grub structure, containing
**			the modules to launch and the adress of the modules file
*/
/* #define DEBUG_MOD */
int			mod_init(t_paddr multiboot)
{
  unsigned int		i;
  multiboot_info_t	*grub = (multiboot_info_t *)multiboot;
  module_t		*module = (module_t *)grub->mods_addr;
  t_tskid		tskid;
  t_asid		asid;
  t_thrid		thrid;
  t_thrctx		thrctx;
  t_paddr		pd_paddr;
  t_vaddr		mod_vaddr;
  t_vaddr		entry_point = 0;
  t_module		*new_mod;
  int			j;
  char			*tmp_name;

  if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_module),
	      0, &mod_setid))
    return 1;

  for (i = 3, module += 3; i < grub->mods_count; i++, module++, cur_modid++)
    {
      new_mod = malloc(sizeof(t_module));
      /* Creation of the task and as for the new module */
      mod_task_rsv(CLASS_USER, BEHAV_TIMESHARING,
	       PRIOR_TIMESHARING, &tskid);
      mod_as_rsv(&asid);
      mod_as_attach(asid, tskid);
      mod_as_get_pd_paddr(asid, &pd_paddr);
#ifdef DEBUG_MOD
      printf("   Task %d attachee a as %d, as->pd_addr %x, as->pd_vaddr %x\n",
      	     tskid, asid, as->pd_addr, as->pd_vaddr/0x10);
#endif
      /* Initialization of the module structure */
      new_mod->modid = cur_modid;
      new_mod->paddr = module->mod_start;
      new_mod->npages = (module->mod_end - module->mod_start) / PAGE_SIZE;
      if ((module->mod_end - module->mod_start) % PAGE_SIZE)
	new_mod->npages++;
      tmp_name = strndup((char *)module->string, strlen((char *)module->string));
      /*       new_mod->name = strndup((char *)module->string, strlen((char *)module->string)); */
      new_mod->name = tmp_name;
      new_mod->lifetime = LIFETIME_INFINITE;
#ifdef DEBUG_MOD
      printf("   Module %d cree : paddr : %x, npages : %d, name %s",
      	     new_mod->modid, new_mod->paddr, new_mod->npages, new_mod->name);
#endif
      mod_vm_rsv(asid, &mod_vaddr, new_mod->npages, VM_FLAG_ANY);
      mod_vm_map(asid, new_mod->paddr, mod_vaddr, new_mod->npages);
      new_mod->vaddr = mod_vaddr;
      mod_as_set_modid(asid, new_mod->modid);
      /* Get the entry point of the module */
      entry_point = mod_he_get_param(pd_paddr, mod_vaddr, E_ENTRY);
      /* Creation of the thread for the new module */
      mod_thread_rsv(PRIOR_TIMESHARING, &thrid);
      mod_thread_attach(thrid, tskid);
      mod_thread_stack(thrid, THREAD_STACKSZ);
      /* We load the context */
      thrctx.pc = entry_point;
      thrctx.sp = mod_thread_get_stack_addr(thrid) + PAGE_SIZE;
      mod_thread_load(thrid, &thrctx);
      if (set_insert(mod_setid, new_mod))
	{
	  /* 	  printf("ERROR: %s:%d: mod_init\n", __FILE__, __LINE__); */
	  for (j = 0; j < 10000000; j++)
	    ;
	  return 1;
	}
      mod_thread_run(thrid);
      /*       printf("* Module %d started\n", new_mod->modid); */
   }

  return 0;
}

/*!
** Get the identifier of a module. If it's not loaded, load it
*/
int		mod_add(char *path,
			t_lifetime lifetime,
			t_modid* modid)
{
  t_iterator    it_mod;
  t_module      *mod;

  lifetime = lifetime;
  SET_FOREACH(FOREACH_FORWARD, mod_setid, &it_mod)
    {
      mod_get(ITERATOR_ID(&it_mod), &mod);
      if (!strcmp(path, mod->name))
        {
          *modid = mod->modid;
          return 0;
        }
    }
  *modid = -1;
  //FIXME : ca sera a remettre kan IDE + FS
  /*   mod = malloc(sizeof(t_module)); */
  /*   /\* The module isn't loaded yet, so we do it *\/ */
  /*   mod->modid = cur_modid++; */
  /*   *modid = mod->modid; */
  /*   /\* CES LIGNES ST TMP ! LORSQUE FS, LECTURE INFO MOD A PATH *\/ */
  /*   mod->paddr = 0; /\* param tmp_mod_addr ds proto ? *\/ */
  /*   mod->npages = 0; /\* EH - param tmp_mod_size ds proto ? *\/ */
  /*   mod->name = "None"; /\* param tmp_mod_name ds proto ? *\/ */
  /*   mod->lifetime = lifetime; */
  /*   if (set_insert(mod_setid, mod)) */
  /*     return 1; */

  return 0;
}

/*!
** Remove a module from the module manager
*/
// FIXME : Y A T-IL D'AUTRE CHANGEMENT (etat, as_detach, sched, ...)
int		mod_remove(t_modid modid)
{
  t_module	*module = NULL;

  if (mod_get(modid, &module))
    return 1;
  if (set_delete(mod_setid, module->modid))
    return 1;

  return 0;
}

/*!
** Load a module in an address space
*/
int		mod_load(t_modid modid, t_asid asid)
{
  t_vaddr	mod_vaddr;
  t_module	*module = NULL;

  if (mod_get(modid, &module))
    return 1;

  mod_vm_rsv(asid, &mod_vaddr, module->npages, VM_FLAG_ANY);
  mod_vm_map(asid, module->paddr, mod_vaddr, module->npages);
  mod_as_set_modid(asid, modid);

  return 0;
}

/*!
** Unload a module and free used memory
*/
int		mod_unload(t_asid asid)
{
  t_modid	modid = 0;
  /*   t_as		*as = NULL; */
  t_module	*module = NULL;

  mod_as_get_modid(asid, &modid);
  if (mod_get(modid, &module))
    return 1;
  /*   if (as_get(asid, &as)) */
  /*     return 1; */
  if (!modid)
    return 1;

  mod_mm_rel(asid, module->vaddr, module->npages);
  /*   as->modid = 0; */
  mod_as_set_modid(asid, 0);

  return 0;
}

/*!
** Get the virtual address of the entry point of a module
*/
//FIXME : changer asid = 4 se servir de l'as courant
int		mod_entry(t_modid modid, t_vaddr* entry)
{
  t_asid	current_asid = 4;
  t_module	*module = NULL;
  t_vaddr	mod_vaddr;
  t_paddr	pd_paddr;

  if (mod_get(modid, &module))
    return  1;

  mod_vaddr = module->vaddr;
  mod_as_get_pd_paddr(current_asid, &pd_paddr);
  *entry = mod_he_get_param(pd_paddr, mod_vaddr, E_ENTRY);

  return 0;
}

/*!
** Get the virtual address of a function in an ELF executable
*/
//FIXME : ASID -> AS COURANT ou bien @ = 0xc00000
int		mod_function(t_modid modid, char *function,
		     t_vaddr *entry)
{
  unsigned int  i, j;
  t_module	*module = NULL;
  t_asid	current_asid = 4;
  t_uint16	nb_section_header;
  t_uint16	section_header_size;
  t_uint16	section_header_str_index;
  t_uint32	section_type;
  t_vaddr	mod_vaddr;
  t_vaddr	section_header;
  t_vaddr	section_header_table;
  t_vaddr	symbol_table = 0;
  t_vaddr	symbol_table_size = 0;
  t_vaddr	symbol_name_index;
  t_vaddr	symbol_value;
  t_vaddr	string_table = 0;
  t_paddr	pd_paddr;
  unsigned char	symbol_info;

  if (mod_get(modid, &module))
    return 1;
  mod_as_get_pd_paddr(current_asid, &pd_paddr);

  /* Get informations about sections into the Header Elf */
  mod_vaddr = module->vaddr;
  section_header_table = mod_vaddr + mod_he_get_param(pd_paddr, mod_vaddr, E_SHOFF);
  section_header_size = mod_he_get_param(pd_paddr, mod_vaddr, E_SHENTSIZE);
  nb_section_header = mod_he_get_param(pd_paddr, mod_vaddr, E_SHNUM);
  section_header_str_index = mod_he_get_param(pd_paddr, mod_vaddr, E_SHSTRNDX);

  /* Search the address of the string and symbol tables */
  for (i = 0, section_header = section_header_table; i < nb_section_header;
       i++, section_header += section_header_size)
    {
      section_type = mod_he_get_param(pd_paddr, section_header, SH_TYPE);
      if (section_type == SHT_STRTAB && i != section_header_str_index)
	string_table = mod_vaddr + mod_he_get_param(pd_paddr,section_header,
						    SH_OFFSET);
      if (section_type == SHT_SYMTAB)
	{
	  symbol_table = mod_vaddr + mod_he_get_param(pd_paddr, section_header,
						      SH_OFFSET);
	  symbol_table_size = mod_he_get_param(pd_paddr, section_header, SH_SIZE);
	}
    }
  /* Search the function in the symbol table */
  for (j = 0; j < symbol_table_size / ST_ENTRY_SIZE; j++)
    {
      symbol_name_index = mod_he_get_param(pd_paddr, symbol_table + j * 16,
					   ST_NAME);
      symbol_info = mod_he_get_param(pd_paddr, symbol_table + j * 16, ST_INFO);
      symbol_value = mod_he_get_param(pd_paddr, symbol_table + j * 16, ST_VALUE);
      if (ELF32_ST_TYPE(symbol_info) == STT_FUNC)
	{
	  function = function;
	 /*  set_pd_address(pd_paddr); */
/* 	  if (!strcmp(function, (char *)(string_table + symbol_name_index))) */
/* 	    { */
/* 	      *entry = symbol_value; */
/* 	      set_pd_address(PD_ENTRY); */
/* 	      return 0; */
/* 	    } */
/* 	  set_pd_address(PD_ENTRY); */
	}
    }

  /*   printf("The function %s hasn't been found...\n", function); */
  *entry = 0;

  return 1;
}

/*!
** Reinitialize the module manager
*/
//FIXME : VERIFIER QUE C TOUT -> INTERACTION AVEC LE SCHED, LES AS ...
int	mod_clean(void)
{
  if (set_rel(mod_setid))
    return 1;

  return 0;
}

/*!
** Get the module modid
*/
int		mod_get(t_modid modid, t_module **module)
{
  t_iterator	it;

  if (set_get(mod_setid, modid, &it))
    {
      /*       printf("ERROR: %s:%d: mod_get on modid %d\n", */
      /* 	     __FILE__, __LINE__, modid); */
      return 1;
    }
  *module = ITERATOR_ADDR(&it);

  return 0;
}
