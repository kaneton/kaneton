#ifndef _KANETON_IOPORTS_H_
# define _KANETON_IOPORTS_H_

void outb(unsigned char value, unsigned short int port);

unsigned char inb (unsigned short int port);

#endif /* !_KANETON_IOPORTS_H_ */
