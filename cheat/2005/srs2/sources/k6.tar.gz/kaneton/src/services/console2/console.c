/*
** Copyright (C) Castaing Antoin et Lolo <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Mon Feb 28 03:56:55 2005 Laurent Decool
** Last update Sat Jun  4 21:49:27 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "console.h"
#include "ioports.h"

int	console_attrib = 0x07;

int	console_pos_in_screen = 0;

int	current_tty = 0;

/*
** VGA mem is from 0xB8000 to 0xC0000 so as we have
** 8 console, each of them will have a size of 4096
*/
void	init_ttys(void)
{
  int	i = 0;

  outb(VGA_SET_CURSOR_START, VGA_COMMAND_PORT);
  outb(((0x2 << 5) | 11), VGA_DATA_PORT);
  for (; i < 4; ++i)
    {
      ttys[i].start_addr = (char *) ((CONSOLE_ADDRESS) + (8192 * i));
      ttys[i].addr = ttys[i].start_addr;
      ttys[i].attrib = DEFAULT_CONSOLE_ATTRIB;
      ttys[i].end_addr = (char *) (ttys[i].start_addr + 8192);
      ttys[i].current_scroll_offset = 0;
    }
}

/*!
** Write from 0xB8000 the nil character with a black
** background (attrib) color
** for cleaning the console.
**
** @param g_console	pointer to console address
*/
void	cons_clear_screen(void)
{
  int	pos = 0;

  /*partie de poid fort de l adresse ds le screen*/
  outb(12, 0x3D4); /*12th register -> MSB*/
  outb(0, 0x3D5);
  /*partie de poid faible de l adresse ds le screen*/
  outb(13, 0x3D4); /*13th register -> LSB*/
  outb(0, 0x3D5);
  ttys[current_tty].current_scroll_offset = 0;
  update_curseur_pos_in_char(0);
  console_attrib = DEFAULT_CONSOLE_ATTRIB;
  ttys[current_tty].addr = (char *) (CONSOLE_ADDRESS + 4096 * current_tty );
  for (; pos < ((int)ttys[current_tty].end_addr - (int)ttys[current_tty].start_addr) / 2; ++pos)
    cons_print_char(0);
  ttys[current_tty].addr = (char *) (CONSOLE_ADDRESS + 8192 * current_tty);
  ttys[current_tty].start_addr = (char *) (CONSOLE_ADDRESS + 8192 * current_tty);

}

/*!
** Backspace
*/
void    cons_backspace(void)
{
  ttys[current_tty].addr -= 2;
  *(ttys[current_tty].addr) = 0;
  ttys[current_tty].addr++;
  *(ttys[current_tty].addr) = ttys[current_tty].attrib;
  ttys[current_tty].addr++;
}

/*!
** The fonction increase the console address
** until the next new line
**
** @param console	pointer to console address
*/
void	cons_goto_next_line(void)
{
  int	char_to_pass = (((int)(ttys[current_tty].addr) - (int)(ttys[current_tty].start_addr)) / 2) % 80;

  for (; char_to_pass < 80; char_to_pass++)
    {
/*       *(ttys[current_tty].addr) = 0; */
      ttys[current_tty].addr++;
/*       *(ttys[current_tty].addr) = ttys[current_tty].attrib; */
      ttys[current_tty].addr++;
    }
  update_curseur();
}

void	update_tty(int tty_id, char new_attrib)
{
  ttys[tty_id].attrib = new_attrib;
}

void	hard_scrolling(int pos)
{

  if (!ttys[current_tty].current_scroll_offset && (pos < 0))
    return;
  ttys[current_tty].current_scroll_offset += pos;
  int	arg_to_give_reg_12 = /*(pos +*/ ttys[current_tty].current_scroll_offset/*)*/ >> 8;
  int	arg_to_give_reg_13 = /*(pos +*/ ttys[current_tty].current_scroll_offset/*)*/ & 0xFF;
/*   int	i; */

#ifdef DEBUG
  printf("start <%x>, cur <%x>, end <%x>",ttys[current_tty].start_addr,
	 ttys[current_tty].addr, ttys[current_tty].end_addr);
#endif

  ttys[current_tty].start_addr += pos * 2;


  outb(12, 0x3D4); /*12th register -> MSB*/
  outb(arg_to_give_reg_12, 0x3D5);
  outb(13, 0x3D4); /*13th register -> LSB*/
  outb(arg_to_give_reg_13, 0x3D5);
}

int	switch_tty(int tty)
{
  if (tty > 8)
    {
      printf("Warning : Bad tty number\n");
      return 1;
    }
  current_tty = tty;
  hard_scrolling((int) ttys[current_tty].start_addr);
  printf("Switch to tty %d\n", current_tty);
  return 0;
}
