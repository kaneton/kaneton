/*
** Copyright (C) xebech aka Xebech <castai_a@epita.fr>
**
** Part of kaneton
**
** Started on  Tue Oct  4 22:24:13 2005 xebech
** Last update Sat Dec  3 21:06:37 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef MESSAGES_H_
# define MESSAGES_H_

#include "../../include/kaneton/types.h"

/*!
** The message header
*/
typedef struct	s_msg_hdr {
  t_tskid	src;
  t_tskid	dest;
  t_vaddr	data;
  int		data_size;
}t_msg_hdr;

/*!
** Create a message
*/
t_msg_hdr	*create_msg(t_tskid src,t_tskid dest, int data_size);

/*!
** Syscall to put message in the message file of the receiver
*/
int		send_msg(t_msg_hdr *msg_hdr, t_tskid src);

/*!
** Ask kernel to deliver a message at address msg_dest
*/
t_vaddr		get_msg(t_tskid receiver);

int		wait_msg(t_thrid dst);

t_vaddr		get_msg_from(t_tskid receiver, t_tskid sender);

int		wait_msg_from(t_thrid dst, t_tskid sender);

int             my_sched_switch(t_thrid thrid);

#endif		/* !MESSAGES_H_ */
