/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Sun Mar  6 01:45:27 2005 Castaing Antoine
** Last update Sat Sep 24 22:15:19 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "exception.h"
#include "../../include/kaneton/error.h"
#include "../../lib/console/console.h"


exception_handler_t tabexceptionhandler[EXCEPTION_ENTRIES] =
  { NULL, };



int	exception_init(void)
{
  int	i;

  for (i = 0; i < EXCEPTION_ENTRIES; i++)
    exception_set_routine(i, exceptions_how_handler);
#ifdef DEBUG_EXCEPTION
  printf("Exception init, ajout %d exception\n", i);
  printf("Exception init, ajout du handler how_handler a l adresse <%d> \n", exceptions_how_handler);
#endif
  return 0;
}

int exception_rm_routine(int except_no)
{
  tabexceptionhandler[except_no] = 0;
  return 0;
}

int exception_set_routine(int except_no,
				exception_handler_t fct)
{
#ifdef DEBUG_EXCEPTION
  printf("Exception set routine no %d avec l adresse %d\n", except_no, fct);
#endif
  if ((except_no < 0) || (except_no >= EXCEPTION_ENTRIES))
    return -ERROR_WRONG_ARG;

  if (except_no == DOUBLE_FAULT)
    return ERROR_FORBIDDEN;

    tabexceptionhandler[except_no] = fct;
  return NO_ERROR;
}

exception_handler_t exception_get_routine(int except_no)
{
  if ((except_no < 0) || (except_no >= EXCEPTION_ENTRIES))
    return NULL;

  return tabexceptionhandler[except_no];
}
