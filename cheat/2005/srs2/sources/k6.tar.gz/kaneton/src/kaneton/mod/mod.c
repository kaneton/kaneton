/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sat Oct 29 01:00:58 2005 Nicolas Clermont
** Last update Tue Nov  8 17:29:28 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include "mod.h"
#include "elf.h"
#include "../task/task.h"
#include "../thread/thread.h"
#include "../../lib/set/set.h"
#include "../../bootloader/multiboot.h"
#include "../../lib/memory/as.h"
#include "../malloc/kmalloc.h"
#include "../malloc/string.h"
#include "../../lib/console/console.h"
#include "../../lib/memory/vm.h"
#include "../../lib/memory/mm.h"
#include "../../bootloader/ch_cr.h"
#include "../../bootloader/phys_mem_mapping.h"

/*!
** The set that contains all the modules
*/
static t_setid	mod_setid;

/*!
** The next identifier usable for a new module
*/
static t_modid  cur_modid = 0;

t_modid	mod_modid(char *name)
{
 t_iterator	it_mod;
 t_module	*mod;

 SET_FOREACH(FOREACH_FORWARD, mod_setid, &it_mod)
   {
     mod_get(ITERATOR_ID(&it_mod), &mod);
     if (!strcmp(name, mod->name))
       return mod->modid;
    }
 return 0;
}


/*!
** Initialize the module manager
*/
/* #define DEBUG_MOD */
int			mod_init(t_paddr multiboot)
{
  unsigned int		i;
  multiboot_info_t	*grub = (multiboot_info_t *)multiboot;
  module_t		*module = (module_t *)grub->mods_addr;
  t_tskid		tskid;
  t_asid		asid;
  t_thrid		thrid;
  t_thread		*thread;
  t_thrctx		thrctx;
  t_vaddr		mod_vaddr;
  t_vaddr		entry_point = 0;
  t_module		*new_mod = malloc(sizeof(t_module), KASID);
  t_as			*as = NULL;
  int			j;

  if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_module),
	      0, &mod_setid))
    return 1;
  module += 2;
  for (i = 2; i < grub->mods_count; i++, module++, cur_modid++)
    {
      /* Creation of the task and as for the new module */
      task_rsv(CLASS_USER, BEHAV_TIMESHARING,
	       PRIOR_TIMESHARING, &tskid);
      as_rsv(&asid);
      as_attach(asid, tskid);
      as_get(asid, &as);
#ifdef DEBUG_MOD
      printf("   Task %d attachee a as %d, as->pd_addr %x, as->pd_vaddr %x\n",
	     tskid, asid, as->pd_addr, as->pd_vaddr/0x10);
#endif
      /* Initialization of the module structure */
      new_mod->modid = cur_modid;
      new_mod->paddr = module->mod_start;
      new_mod->npages = (module->mod_end - module->mod_start) / PAGE_SIZE;
      if ((module->mod_end - module->mod_start) % PAGE_SIZE)
	new_mod->npages++;
      new_mod->name = strndup((char *)module->string,
			      strlen((char *)module->string));
      new_mod->lifetime = LIFETIME_INFINITE;
#ifdef DEBUG_MOD
      printf("   Module %d cree : paddr : %x, npages : %d, name %s",
	     new_mod->modid, new_mod->paddr, new_mod->npages, new_mod->name);
#endif
      vm_rsv(asid, &mod_vaddr, new_mod->npages, VM_FLAG_ANY);
      vm_map(asid, new_mod->paddr, mod_vaddr, new_mod->npages);
      new_mod->vaddr = mod_vaddr;
      as->modid = new_mod->modid;
      /* Get the entry point of the module */
      set_pd_address(as->pd_addr);
      entry_point = he_get_param(mod_vaddr, E_ENTRY);
      set_pd_address(PD_ENTRY);
      /* Creation of the thread for the new module */
      thread_rsv(PRIOR_TIMESHARING, &thrid);
      thread_attach(thrid, tskid);
      thread_stack(thrid, 1);
      /* We load the context */
      thread_get(thrid, &thread);
      thrctx.pc = entry_point;
      thrctx.sp = thread->stack + PAGE_SIZE;
      thread_load(thrid, &thrctx);
      if (set_insert(mod_setid, new_mod))
	{
	  printf("ERROR: %s:%d: mod_init\n", __FILE__, __LINE__);
	  for (j = 0; j < 10000000; j++)
	    ;
	  return 1;
	}
      printf("* Module %s started\n", new_mod->name);
      thread_run(thrid);
   }
  return 0;
}

/*!
** Get the identifier of a module. If it's not loaded, load it
*/
int		mod_add(char *path,
			t_lifetime lifetime,
			t_modid* modid)
{
  t_iterator	it_mod;
  t_module	*mod = malloc(sizeof(t_module), KASID);

  SET_FOREACH(FOREACH_FORWARD, mod_setid, &it_mod)
    {
      mod_get(ITERATOR_ID(&it_mod), &mod);
      if (!strcmp(path, mod->name))
	{
	  *modid = mod->modid;
	  return 0;
	}
    }

  /* The module isn't loaded yet, so we do it */
  mod->modid = cur_modid++;
  *modid = mod->modid;
  /* CES LIGNES ST TMP ! LORSQUE FS, LECTURE INFO MOD A PATH */
  mod->paddr = 0; /* param tmp_mod_addr ds proto ? */
  mod->npages = 0; /* EH - param tmp_mod_size ds proto ? */
  mod->name = "None"; /* param tmp_mod_name ds proto ? */
  mod->lifetime = lifetime;
  if (set_insert(mod_setid, mod))
    return 1;

  return 0;
}

/*!
** Remove a module from the module manager
*/
// FIXME : Y A T-IL D'AUTRE CHANGEMENT (etat, as_detach, sched, ...)
int		mod_remove(t_modid modid)
{
  t_module	*module = NULL;

  if (mod_get(modid, &module))
    return 1;
  if (set_delete(mod_setid, module->modid))
    return 1;

  return 0;
}

/*!
** Load a module in an address space
*/
int		mod_load(t_modid modid, t_asid asid)
{
  t_vaddr	mod_vaddr;
  t_as		*as = NULL;
  t_module	*module = NULL;

  if (mod_get(modid, &module))
    return 1;
  if (as_get(asid, &as))
    return 1;

  vm_rsv(asid, &mod_vaddr, module->npages, VM_FLAG_ANY);
  vm_map(asid, module->paddr, mod_vaddr, module->npages);
  as->modid = modid;

  return 0;
}

/*!
** Unload a module and free used memory
*/
int		mod_unload(t_asid asid)
{
  t_as		*as = NULL;
  t_module	*module = NULL;

  if (mod_get(as->modid, &module))
    return 1;
  if (as_get(asid, &as))
    return 1;
  if (!as->modid)
    return 1;

  mm_rel(asid, module->vaddr, module->npages);
  as->modid = 0;

  return 0;
}

/*!
** Get the virtual address of the entry point of a module
*/
//FIXME : changer asid = 4 se servir de l'as courant
int		mod_entry(t_modid modid, t_vaddr* entry)
{
  t_asid	current_asid = 4;
  t_as		*current_as = NULL;
  t_module	*module = NULL;
  t_vaddr	mod_vaddr;

  if (mod_get(modid, &module))
    return  1;

  mod_vaddr = module->vaddr;
  if (as_get(current_asid, &current_as))
    return 1;
  set_pd_address(current_as->pd_addr);
  *entry = he_get_param(mod_vaddr, E_ENTRY);
  set_pd_address(PD_ENTRY);

  return 0;
}

/*!
** Get the virtual address of a function in an ELF executable
*/
//FIXME : ASID -> AS COURANT
int		mod_function(t_modid modid, char *function,
		     t_vaddr *entry)
{
  unsigned int  i, j;
  t_module	*module = NULL;
  t_asid	current_asid = 4;
  t_as		*current_as = NULL;
  t_uint16	nb_section_header;
  t_uint16	section_header_size;
  t_uint16	section_header_str_index;
  t_uint32	section_type;
  t_vaddr	mod_vaddr;
  t_vaddr	section_header;
  t_vaddr	section_header_table;
  t_vaddr	symbol_table = 0;
  t_vaddr	symbol_table_size = 0;
  t_vaddr	symbol_name_index;
  t_vaddr	symbol_value;
  t_vaddr	string_table = 0;
  unsigned char	symbol_info;

  if (mod_get(modid, &module))
    return 1;
  if (as_get(current_asid, &current_as))
    return 1;

  /* Get informations about sections into the Header Elf */
  mod_vaddr = module->vaddr;
  set_pd_address(current_as->pd_addr);
  section_header_table = mod_vaddr + he_get_param(mod_vaddr,
						  E_SHOFF);
  section_header_size = he_get_param(mod_vaddr, E_SHENTSIZE);
  nb_section_header = he_get_param(mod_vaddr, E_SHNUM);
  section_header_str_index = he_get_param(mod_vaddr, E_SHSTRNDX);
  set_pd_address(PD_ENTRY);
  /* Search the address of the string and symbol tables */
  for (i = 0, section_header = section_header_table; i < nb_section_header;
       i++, section_header += section_header_size)
    {
      set_pd_address(current_as->pd_addr);
      section_type = he_get_param(section_header, SH_TYPE);
      set_pd_address(PD_ENTRY);
      if (section_type == SHT_STRTAB &&
	  i != section_header_str_index)
	{
	  set_pd_address(current_as->pd_addr);
	  string_table = mod_vaddr + he_get_param(section_header,
						  SH_OFFSET);
	  set_pd_address(PD_ENTRY);
	}
      if (section_type == SHT_SYMTAB)
	{
	  set_pd_address(current_as->pd_addr);
	  symbol_table = mod_vaddr + he_get_param(section_header,
						  SH_OFFSET);
	  symbol_table_size = he_get_param(section_header,
					   SH_SIZE);
	  set_pd_address(PD_ENTRY);
	}
    }
  /* Search the function in the symbol table */
  for (j = 0; j < symbol_table_size / ST_ENTRY_SIZE; j++)
    {
      set_pd_address(current_as->pd_addr);
      symbol_name_index = he_get_param(symbol_table + j * 16,
				       ST_NAME);
      symbol_info = he_get_param(symbol_table + j * 16, ST_INFO);
      symbol_value = he_get_param(symbol_table + j * 16, ST_VALUE);
      set_pd_address(PD_ENTRY);
      if (ELF32_ST_TYPE(symbol_info) == STT_FUNC)
	{
	  set_pd_address(current_as->pd_addr);
	  if (!strcmp(function, (char *)(string_table + symbol_name_index)))
	    {
	      *entry = symbol_value;
	      set_pd_address(PD_ENTRY);
	      return 0;
	    }
	  set_pd_address(PD_ENTRY);
	}
    }

  printf("The function %s hasn't been found...\n", function);
  *entry = 0;

  return 1;
}

/*!
** Reinitialize the module manager
*/
//FIXME : VERIFIER QUE C TOUT -> INTERACTION AVEC LE SCHED, LES AS ...
int	mod_clean(void)
{
  if (set_rel(mod_setid))
    return 1;

  return 0;
}

/*!
** Get the module modid
*/
int		mod_get(t_modid modid, t_module **module)
{
  t_iterator	it;

  if (set_get(mod_setid, modid, &it))
    {
      printf("ERROR: %s:%d: mod_get on modid %d\n",
	     __FILE__, __LINE__, modid);
      return 1;
    }
  *module = ITERATOR_ADDR(&it);

  return 0;
}
