/*
** Copyright (C) Laurent Decool aka traktopel <laurent.decool@gmail.com>
**
** Part of Kaneton
**
** Started on  Wed Oct  5 14:49:25 2005 Laurent Decool
** Last update Wed Oct  5 15:24:35 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef /* KANETON_QWERTY_H_ */
# define /* KANETON_QWERTY_H_ */

/*
** Mappage clavier us
*/

char standard_keys[58][2];

char	num_keys[];

/*
** This table contain the name of each function to call
** when a direction key is pressed
*/

char	*direction_keys[];

#endif /* !KANETON_QWERTY_H_ */
