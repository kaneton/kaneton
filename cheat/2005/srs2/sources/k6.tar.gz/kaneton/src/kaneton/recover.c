/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Mon Mar 28 03:39:30 2005 Nicolas Clermont
** Last update Tue Nov  8 02:38:26 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "recover.h"
#include "../bootloader/multiboot.h"
#include "../bootloader/phys_mem_mapping.h"
#include "../lib/memory/as.h"
#include "../lib/memory/pm.h"
#include "../lib/list/list.h"
#include "../lib/console/console.h"

extern t_pm		*pm;
extern t_as_list	*as_list;

/*!
** Rebuild the lists of areas that describe the physical memory
*/
static void		rebuild_pm(void)
{
  int			tampon = sizeof(t_area_list) + sizeof(t_area);

  pm = (t_pm *)AREA;
  pm->used = (t_area_list *)(AREA + sizeof(t_pm) + tampon);
  pm->used->data = (t_area *)(AREA + sizeof(t_pm) + sizeof(t_area_list) + tampon);

  pm->free = (t_area_list *)(AREA + sizeof(t_pm) + sizeof(t_area_list)
			       + sizeof(t_area) + tampon);
  pm->free->data = (t_area *)(AREA + sizeof(t_pm) + 2 * sizeof(t_area_list)
				+ sizeof(t_area) + tampon);
}

/*!
** Rebuild the list of address space
*/
static void		rebuild_as(void)
{
  as_list = (t_as_list*)ASLIST;
  as_list->data = (t_as *)(ASLIST + sizeof(t_as_list));
  ((t_as*)(as_list->data))->pas = (t_area_list*)PASLIST;
}

/*!
** Recover the address of Kernel and the total amount of memory
*/
static void		rebuild_grub(void)
{
  multiboot_info_t	*grub = (multiboot_info_t *) GRUB_ADDR;
  module_t		*kmodule = (module_t *)grub->mods_addr;

  mem_upper = grub->mem_upper;
  kern_addr = kmodule->mod_start;
  kern_npages = (kmodule->mod_end - kern_addr) / PAGE_SIZE;
  if ((kmodule->mod_end - kern_addr) % PAGE_SIZE)
    kern_npages++;
  kmodule++;
  file_conf_addr = (unsigned long)kmodule->mod_start;
  kmodule++;
  console_addr = (unsigned long)kmodule->mod_start;
  kmodule++;
  kmodule++;
  keyboard_addr = (unsigned long)kmodule->mod_start;
}

/*!
** Recover all the data needed which have been lost when jumping
** on the Kernel
*/
void			recover_from_bootloader(void)
{
  rebuild_pm();
  rebuild_as();
  rebuild_grub();
}
