/*
** Copyright (C) Castaing Antoine aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Fri Sep 23 19:32:36 2005 Castaing Antoine
** Last update Fri Oct  7 17:51:43 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "log_int.h"
#include "../../include/kaneton/error.h"
#include "../../lib/console/console.h"


log_int_handler_t tabloginthandler[LOG_INT_ENTRIES] =
  { NULL, };




int log_int_init(void)
{
  int	i;

  for (i = 0; i < LOG_INT_ENTRIES; i++)
    log_int_set_routine(i, log_int_high_handler);
#ifdef DEBUG_LOG_INT
  printf("Exception init, ajout %d exception\n", i);
  printf("Exception init, ajout du handler how_handler a l adresse <%d> \n", log_int_high_handler);
#endif
  return 0;
}

int log_int_set_routine(int except_no,
			log_int_handler_t routine)
{
#ifdef DEBUG_LOG_INT
  printf("Exception set routine no %d avec l adresse %d\n", except_no, fct);
#endif
  if ((except_no < 0) || (except_no >= LOG_INT_ENTRIES))
    return -ERROR_WRONG_ARG;
  tabloginthandler[except_no] = routine;
  return NO_ERROR;
}

int log_int_rm_routine(int except_no)
{
  tabloginthandler[except_no] = 0;
  return 0;
}

log_int_handler_t log_int_get_routine(int log_int_no)
{
return tabloginthandler[log_int_no];
}
