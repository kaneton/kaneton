/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Sun Nov  6 23:47:04 2005 Nicolas Clermont
** Last update Sun Nov  6 23:47:18 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

# ifndef  KANETON_KANETON_WAIT_H_
# define KANETON_KANETON_WAIT_H_

# include "../include/kaneton/types.h"
# include "status.h"

# define WAIT_TSKID(_wait_)		\
(_wait_).u.tskid

# define WAIT_THIRD(_wait_)		\
(_wait_).u.third

# define WAIT_STATUS(_wait_)		\
(_wait_).status

# define WAIT_VALUE(_wait_)		\
(_wait_).value

typedef struct		s_wait
{
  union
  {
    t_tskid		tskid;
    t_thrid		thrid;
  }			u;
  t_status		status;
  t_uint32		value;
}			t_wait;

#endif			/* !KANETON_KANETON_WAIT_H_ */
