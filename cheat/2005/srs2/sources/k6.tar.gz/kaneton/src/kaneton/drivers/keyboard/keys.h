/*
** Copyright (C) Laurent Decool aka traktopel <laurent.decool@gmail.com>
**
** Part of Kaneton
**
** Started on  Wed Oct  5 14:49:25 2005 Laurent Decool
** Last update Wed Oct  5 15:25:28 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef KANETON_KEYS_H_
# define KANETON_KEYS_H_

# include "../../../include/kaneton/types.h"

# define MODE_SHIFT		1

/* Size setting of the keyboard buffer */
# define KEY_BUFF_SIZE		16

/*
** Useful definitions for leds management
*/
# define SCROLL_LOCK_MASK	0x01
# define NUM_LOCK_MASK		0x02
# define CAPS_LOCK_MASK		0x04

/*
** Definition of the Input/Output port used to get information about the keyboard
*/
# define KEYBOARD_PORT		0x60
# define KEYBOARD_RESET		0x61
# define KEYBOARD_PORT2		0x64

/* Size of the keyboard buffer */
# define KEYBOARD_BUFF_SIZE	16

# define EXTEND_CODE		0xE0

/*!
** Definition of the first key of the numeric pad
** (7 -> 71)
*/

# define START_INDEX_NUMPAD 71

struct		s_keyboard
{
  byte		num_lock;		/* Is numpad activated ? */
  byte		caps_lock;		/* Is shift activated ? */
  byte		scroll_lock;		/* Is shift activated ? */
  byte		ext_key;	/* Is an extended key ? */
  byte		alt;
};

typedef void	(*fct_key)(void);

void	keyboard_init(void);
void	keyboard_irq(int a);

void	keyboard_empty_func(void);
void	keyboard_home(void);
void	keyboard_haut(void);
void	keyboard_page_up(void);
void	keyboard_gauche(void);
void	keyboard_droite(void);
void	keyboard_fin(void);
void	keyboard_bas(void);
void	keyboard_page_down(void);
void	keyboard_insert(void);
void	keyboard_suppr(void);

void	keyboard_f1(void);
void	keyboard_f2(void);
void	keyboard_f3(void);
void	keyboard_f4(void);
void	keyboard_f5(void);
void	keyboard_f6(void);
void	keyboard_f7(void);
void	keyboard_f8(void);
void	keyboard_f9(void);
void	keyboard_f10(void);

#endif /* !KANETON_KEYS_H_ */
