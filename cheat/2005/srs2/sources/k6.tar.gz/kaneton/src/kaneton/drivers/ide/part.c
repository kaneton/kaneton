/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Oct 10 14:08:04 2005 Damien Laniel
** Last update Tue Nov  1 16:12:50 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "ide.h"
#include "../../../lib/console/console.h"
#include "../../../include/kaneton/types.h"
/* #include "../../../lib/libc/string.h" */

typedef struct	partition_table_entry
{
  t_uint8	active;
  t_uint8	start_chs_head;
  t_uint16	start_chs_sector_cylinder;
  t_uint8	type;
  t_uint8	end_chs_head;
  t_uint16	end_chs_sector_cylinder;
  t_uint32	start_lba;
  t_uint32	size;
}		t_partition_table_entry;

void	part_detect(void)
{
  char	*buffer;
  int	i;

  /* Read MBR at cylinder 0, head 0, sector 1 */
  buffer = ide_read(ATA_CTRL1, 0, 0, 1, 512);
  /* Skip the binary loader and go to the first partition table entry */
  buffer += 446;
  /* A partition table entry is 16 bytes long */
  for (i = 0; i < 16; ++i)
    printf("Buffer : %x\n", buffer[i]);
}
