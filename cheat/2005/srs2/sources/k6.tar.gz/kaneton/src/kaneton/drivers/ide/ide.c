/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Tue Sep 27 14:02:08 2005 Damien Laniel
** Last update Wed Nov 23 17:18:26 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "ide.h"
#include "../../../include/kaneton/ioports.h"
#include "../../../lib/console/console.h"
#include "../../../kaneton/malloc/kmalloc.h"
#include "../../../kaneton/error.h"
#include "../../mutex.h"

/* static t_semaphore	mutex = 0; */

int	schedyield(void)
{
  return sched_yield();
}

void	print(void)
{
  register word x;

  asm ("mov %%edx,%0":"=r"(x));
  printf("mutex : %d\n", x);
}

/* static void mutex_lock(void) */
/* {} */

/* static void mutex_unlock(void) */
/* {} */

/* extern void	mutexlock(t_semaphore mutex); */

/*
** I/O ports
*/

/* Base address of I/O ports */
/* #define ATA_CTRL1_IOPORT	0x1f0 */
/* #define ATA_CTRL2_IOPORT	0x170 */
/* #define ATA_CTRL3_IOPORT	0xf0 */
/* #define ATA_CTRL4_IOPORT	0x70 */

/* Send or receive datas */
#define ATA_IOPORT_IO_DATA		0x00
/* Get the error of a drive */
#define ATA_IOPORT_IN_ERROR		0x01
/* Number of sectors */
#define ATA_IOPORT_IO_NB_SECTORS	0x02
/* Start sector */
#define ATA_IOPORT_IO_SECTOR		0x03
/* Number of cylinders LSB (low bits) */
#define ATA_IOPORT_IO_CYL_LSB		0x04
/* Number of cylinders MSB (high bits) */
#define ATA_IOPORT_IO_CYL_MSB		0x05
/* Select drive and head */
#define ATA_IOPORT_IO_DRIVE		0x06
/* Get the status of a drive */
#define ATA_IOPORT_IN_STATUS		0x07
/* Send a command to the drive */
#define ATA_IOPORT_OUT_CMD		0x07
/* Control a device */
#define ATA_IOPORT_OUT_CONTROL		0x206

/*
** Drive codes (port : ATA_IOPORT_IO_DRIVE)
*/

/* Select master drive */
/* #define ATA_DRIVE_MASTER	0xa0 */
/* Message code for master */
/* #define ATA_DRIVE_SLAVE		0xb0 */

/*
** Status codes (port : ATA_IOPORT_IN_STATUS)
*/

/* Error */
#define ATA_STATUS_ERROR	0x01
/* Index */
#define ATA_STATUS_INDEX	0x02
/* Data corrected */
#define ATA_STATUS_CORR		0x04
/* Data request */
#define ATA_STATUS_DRQ		0x08
/* Drive seek completed */
#define ATA_STATUS_DSC		0x10
/* Drive write fault */
#define ATA_STATUS_DWF		0x20
/* Drive ready */
#define ATA_STATUS_DRDY		0x40
/* Busy */
#define ATA_STATUS_BSY		0x80

/*
** Control codes (port : ATA_IOPORT_OUT_CONTROL)
*/

/* Disable interrupts */
#define ATA_CONTROL_NO_INT	0x02
/* Reset controller */
#define ATA_CONTROL_RESET	0x04
/* Drive has more than 8 heads */
#define ATA_CONTROL_MORE_8_HEAD	0x08


/* Some commands send or return 256 words to Data port */
#define ATA_DATA_BUFFER_SIZE	256

/* Magic numbers used to detect ATAPI devices */
#define ATAPI_MAGIC_LSB		0x14
#define ATAPI_MAGIC_MSB		0xeb

/* Commands to send to the drive */
typedef enum	e_ata_command
  {
    ATA_CMD_ATA_IDENTIFY =	0xec,
    ATA_CMD_ATAPI_IDENTIFY =	0xa1,
    ATA_CMD_READ =		0x20,
    ATA_CMD_WRITE =		0x30,
/*     ATA_CMD_READ_MULTI =	0xc4, */
/*     ATA_CMD_WRITE_MULTI =	0xc5, */
/*     ATA_CMD_SET_MULTI =		0xc6, */
    ATA_CMD_PACKET_CMD =	0xa0
  }		t_ata_command;

/*!
** Sleep for sec seconds
** FIXME : change it to use the timer
**
** @param	sec	Number of secondes to wait
*/
static void	sleep(unsigned int sec)
{
  unsigned int	i;

  for (i = 0; i < 1500000 * sec; ++i)
    ;
}

/*!
** Check if a drive is an ATA or ATAPI drive
**
** @param	controller	Controller on which is the drive to use
*/
t_ata_atapi	ide_ata_or_atapi(t_ata_controller controller)
{
  if (inb(controller + ATA_IOPORT_IO_CYL_LSB) == ATAPI_MAGIC_LSB &&
     inb(controller + ATA_IOPORT_IO_CYL_MSB) == ATAPI_MAGIC_MSB)
    return ATAPI;
  else
    return ATA;
}

/*!
** Only check if a drive is listening for ports changes
**
** @param	controller	Controller on which is the drive to use
*/
static void	ide_first_dialog(t_ata_controller controller)
{
  const t_uint8	random_value_error = 0x58;
  const t_uint8	random_value_cyl_lsb = 0xa5;

  outb(random_value_error, controller + ATA_IOPORT_IN_ERROR);
  outb(random_value_cyl_lsb, controller + ATA_IOPORT_IO_CYL_LSB);
  if(inb(controller + ATA_IOPORT_IN_ERROR) != random_value_error &&
     inb(controller + ATA_IOPORT_IO_CYL_LSB) == random_value_cyl_lsb)
    printf("ATA hard drive waiting for orders\n");
}

/*!
** Print the status of a drive
**
** @param	status		Status code
*/
void	ide_print_status_string(char status_code)
{
  printf("Status :\n");
  if (status_code & ATA_STATUS_ERROR)
    printf("- Error\n");
  if (status_code & ATA_STATUS_INDEX)
    printf("- Index\n");
  if (status_code & ATA_STATUS_CORR)
    printf("- Data corrected\n");
  if (status_code & ATA_STATUS_DRQ)
    printf("- Data request\n");
  if (status_code & ATA_STATUS_DSC)
    printf("- Drive seek completed\n");
  if (status_code & ATA_STATUS_DWF)
    printf("- Drive write fault\n");
  if (status_code & ATA_STATUS_DRDY)
    printf("- Drive ready\n");
  if (status_code & ATA_STATUS_BSY)
    printf("- Busy\n");
}

/*!
** Get the error code of a drive
**
** @param	controller	Controller on which is the drive to use
*/
char	ide_get_error_code(t_ata_controller controller)
{
  return inb(controller + ATA_IOPORT_IN_ERROR);
}

/*!
** Get the status code of a drive
**
** @param	controller	Controller on which is the drive to use
*/
char	ide_get_status_code(t_ata_controller controller)
{
  return inb(controller + ATA_IOPORT_IN_STATUS);
}

/*!
** Wait for command completion
**
** @param	controller	Controller on which is the drive to use
*/
static void	ide_wait_busy(t_ata_controller controller)
{
  char		status_code = 0;
  t_uint32	timeout;

  for (timeout = 0; timeout < 30000; ++timeout)
    {
      status_code = ide_get_status_code(controller);
      if (!(status_code & ATA_STATUS_BSY))
        break;
      printf("IDE is busy, please wait\n");
      sleep(1);
    }
}

/*!
** Common part of ide_read and ide_write functions.
** Parameters are the same as ide_read and ide_write
*/
static void	ide_read_write_common(t_ata_controller controller,
				      t_uint16 cylinder,
				      t_uint8 head,
				      t_uint8 sector,
				      t_uint32 data_size)
{
  t_uint8	nb_sectors;
  t_uint8	drive_head_register = inb(controller + ATA_IOPORT_IO_DRIVE);
  t_uint8	cylinder_lsb = cylinder & 255;
  t_uint8	cylinder_msb = cylinder >> 8;

  /* Calculate the number of sectors to write, given data size */
  nb_sectors = data_size / ATA_DATA_BUFFER_SIZE;
  if (data_size % ATA_DATA_BUFFER_SIZE)
    ++nb_sectors;

  /* Keep all the bits of the register but the head number (3 first bits) */
  drive_head_register &= 0xF8;
  /* Fill in the new head value */
  drive_head_register |= head;

/*   printf("nb sector : %d\n", nb_sectors); */
/*   printf("head : %x\n", drive_head_register); */
/*   printf("sector : %d\n", sector); */
/*   printf("cyl_lsb : %d\n", cylinder_lsb); */
/*   printf("cyl_msb : %d\n", cylinder_msb); */

/*   mutexlock(&mutex); */

  /* Set read / write parameters */
  outb(nb_sectors, controller + ATA_IOPORT_IO_NB_SECTORS);
  outb(sector, controller + ATA_IOPORT_IO_SECTOR);
  outb(cylinder_lsb, controller + ATA_IOPORT_IO_CYL_LSB);
  outb(cylinder_msb, controller + ATA_IOPORT_IO_CYL_MSB);
  outb(drive_head_register, controller + ATA_IOPORT_IO_DRIVE);
}

/*!
** Read some datas from a drive.
** The address is given in CHS (Cylinder/Head/Sector) mode
**
** @param	controller	Controller on which is the drive to use
** @param	cylinder	Cylinder to use
** @param	head		Head to use
** @param	sector		Start sector
** @param	data_size	Size in bytes of the datas to read
** @return	Read datas. NULL if an error occurs
*/
char		*ide_read(t_ata_controller controller,
			  t_uint16 cylinder,
			  t_uint8 head,
			  t_uint8 sector,
			  t_uint32 data_size)
{
  char		*data = NULL;
  t_uint32	i;

  ide_read_write_common(controller, cylinder, head, sector, data_size);

  /* Send read command */
  outb(ATA_CMD_READ, controller + ATA_IOPORT_OUT_CMD);
  ide_wait_busy(controller);

/*   printf("\nnb sector : %x\n", inb(controller + ATA_IOPORT_IO_NB_SECTORS)); */
/*   printf("head : %x\n", inb(controller + ATA_IOPORT_IO_DRIVE)); */
/*   printf("sector : %x\n", inb(controller + ATA_IOPORT_IO_SECTOR)); */
/*   printf("cyl_lsb : %x\n", inb(controller + ATA_IOPORT_IO_CYL_LSB)); */
/*   printf("cyl_msb : %x\n\n", inb(controller + ATA_IOPORT_IO_CYL_MSB)); */

  /* Check if the drive is ready to send datas */
  if (!(ide_get_status_code(controller) & ATA_STATUS_DRQ))
    {
      error("DRQ wasn't set after READ\n", __FILE__, __LINE__);
      return NULL;
    }

  if (!(data = malloc(data_size, KASID)))
    return NULL;

  /* Read datas */
  for (i = 0; i < data_size; ++i)
    {
/*   if (!(ide_get_status_code(controller) & ATA_STATUS_DRQ)) */
/*     { */
/*       error("1 - DRQ wasn't set after READ\n", __FILE__, __LINE__); */
/*       return NULL; */
/*     } */
      data[i] = inw(controller + ATA_IOPORT_IO_DATA);
      ide_wait_busy(controller);
    }
  for (i = data_size; i < 256; ++i)
    {
/*   if (!(ide_get_status_code(controller) & ATA_STATUS_DRQ)) */
/*     { */
/*       error("2 - DRQ wasn't set after READ\n", __FILE__, __LINE__); */
/*       return NULL; */
/*     } */
      inw(controller + ATA_IOPORT_IO_DATA);
      ide_wait_busy(controller);
    }

/*   mutex_unlock(); */


/*   printf("nb sector : %x\n", inb(controller + ATA_IOPORT_IO_NB_SECTORS)); */
/*   printf("head : %x\n", inb(controller + ATA_IOPORT_IO_DRIVE)); */
/*   printf("sector : %x\n", inb(controller + ATA_IOPORT_IO_SECTOR)); */
/*   printf("cyl_lsb : %x\n", inb(controller + ATA_IOPORT_IO_CYL_LSB)); */
/*   printf("cyl_msb : %x\n\n", inb(controller + ATA_IOPORT_IO_CYL_MSB)); */

  return data;
}

/*!
** Write some datas to a drive.
** The address is given in CHS (Cylinder/Head/Sector) mode
**
** @param	controller	Controller on which is the drive to use
** @param	cylinder	Cylinder to use
** @param	head		Head to use
** @param	sector		Start sector
** @param	data		Datas to write
** @param	data_size	Size in bytes of the datas to write
** @return	0 if success, 1 otherwise
*/
int		ide_write(t_ata_controller controller,
			  t_uint16 cylinder,
			  t_uint8 head,
			  t_uint8 sector,
			  const void *data,
			  t_uint32 data_size)
{
  t_uint32	i;

  ide_read_write_common(controller, cylinder, head, sector, data_size);

  /* Send write command */
  outb(ATA_CMD_WRITE, controller + ATA_IOPORT_OUT_CMD);
  ide_wait_busy(controller);

  /* Check if the drive is ready to receive datas */
  if (!(ide_get_status_code(controller) & ATA_STATUS_DRQ))
    return error("DRQ wasn't set after WRITE\n", __FILE__, __LINE__);

  /* Write datas */
  for (i = 0; i < data_size; ++i)
    {
      outw(((char *)data)[i], controller + ATA_IOPORT_IO_DATA);
      ide_wait_busy(controller);
    }
  for (i = data_size; i < 256; ++i)
    {
      outw(0, controller + ATA_IOPORT_IO_DATA);
      ide_wait_busy(controller);
    }

/*   mutex_unlock(); */

  return 0;
}

/*!
** Print information about an IDE device
**
** @param	controller	Controller on which is the drive to use
*/
void			ide_print_device_infos(t_ata_controller controller)
{
  char			status_code = 0;
  char			error_code = 0;
  t_ata_atapi		ata_atapi;
  t_ide_device_info	*dev_info = NULL;

  /* Get and print status code */
  status_code = ide_get_status_code(controller);
  printf("Status code : %x\n", status_code);
  ide_print_status_string(status_code);
  /* Get and print error code */
  error_code = ide_get_error_code(controller);
  printf("Error code : %x\n", error_code);
  /* FIXME : print error message */

  ata_atapi = ide_ata_or_atapi(controller);
  if (ata_atapi == ATA)
    {
      printf("ATA hard drive\n");
      ide_first_dialog(controller);
    }
  else
    if (ata_atapi == ATAPI)
      printf("ATAPI cdrom drive\n");

  dev_info = ide_get_device_info(controller);

  printf("cylinder_nb : %d\n", dev_info->nb_logical_cylinders);
  printf("head_nb : %d\n", dev_info->nb_logical_heads);
  printf("sector_per_track : %d\n", dev_info->nb_logical_sectors);
}

/*!
** Get a device information
**
** @param	controller	Controller on which is the drive to use
*/
t_ide_device_info	*ide_get_device_info(t_ata_controller controller)
{
  char			status_code = 0;
  t_uint32		i;
  t_uint16		identify_buffer[ATA_DATA_BUFFER_SIZE];
  t_ide_device_info	*dev_info;

  outb(ATA_CMD_ATA_IDENTIFY, controller + ATA_IOPORT_OUT_CMD);
  ide_wait_busy(controller);

  /* Check that Data Request (DRQ) is set */
  status_code = ide_get_status_code(controller);
  if (!(status_code & ATA_STATUS_DRQ))
    printf("DRQ wasn't set after IDENTIFY\n");

  /* Read data */
  for (i = 0; i < ATA_DATA_BUFFER_SIZE; ++i)
    identify_buffer[i] = inw(controller + ATA_IOPORT_IO_DATA);

  dev_info = (t_ide_device_info *) identify_buffer;
  return dev_info;
}

/*!
** Select the drive to use
**
** @param	controller	Controller on which to select a drive
** @param	master_slave	Drive to select
*/
void	ide_select_drive(t_ata_controller controller, t_ata_master_slave master_slave)
{
/*   mutexlock(&mutex); */
/*   printf("test\n"); */
/*   mutexlock(&mutex); */
/*   printf("test\n"); */
/*   mutexunlock(&mutex); */
/*   mutexlock(&mutex); */
/*   printf("test\n"); */
  outb(master_slave, controller + ATA_IOPORT_IO_DRIVE);
  ide_wait_busy(controller);
}

/*!
** Init an IDE controller
**
** @param	controller	Controller to init
*/
void	ide_init_controller(t_ata_controller controller)
{
  outb(ATA_CONTROL_NO_INT | ATA_CONTROL_RESET, controller + ATA_IOPORT_OUT_CONTROL);
  /* Must sleep during at least 4.8 microseconds */
  sleep(1);
  outb(ATA_CONTROL_NO_INT, controller + ATA_IOPORT_OUT_CONTROL);
  sleep(1);
  inb(controller + ATA_IOPORT_IN_ERROR);
  outb(ATA_CONTROL_MORE_8_HEAD, controller + ATA_IOPORT_OUT_CONTROL);
  sleep(1);
}

/*!
** Initialize IDE manager
*/
void		ide_init(void)
{
/*   char			status_code = 0; */
/*   char			error_code = 0; */
/*   t_ata_atapi		ata_atapi; */
/*   t_ide_device_info	*dev_info = NULL; */

  /* Init first controller */
  ide_init_controller(ATA_CTRL1);

  /* First controller, Master drive */
/*   ide_select_drive(ATA_CTRL1, ATA_MASTER); */

  /* First controller, Slave drive */
/*   ide_select_drive(ATA_CTRL1, ata_slave); */

/* /\* Init second controller *\/ */
/*   ide_init_controller(ata_ctrl2); */
/*   /\* Second controller, Master drive *\/ */
/*   ide_select_drive(ata_ctrl2, ata_master); */
/*   /\* Second controller, Slave drive *\/ */
/*   ide_select_drive(ata_ctrl2, ata_slave); */

/*   printf("* IDE service initialization ... [OK]\n"); */


/* May be used if we need to build a "s_ide_drive" struct */
/*   ata_atapi = ide_ata_or_atapi(ATA_CTRL1); */
/*   dev_info = ide_get_device_info(ATA_CTRL1); */
}
