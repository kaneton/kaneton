/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:39:15 2005 Castaing Antoine
** Last update Thu Oct  6 19:29:30 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef SCHEDULER_H_
# define SCHEDULER_H_

# include "../../include/kaneton/types.h"
# include "../../lib/set/set.h"
/* # include "../../lib/libc/libc.h" */
# include "../thread/thread.h"

typedef t_uint16 t_quantum;

typedef struct		s_scheduler
{
  unsigned int		ebp_val;
  t_quantum		quantum;
  t_setid		run;
  t_thrid		thrid;
  unsigned long int	tick;
} t_scheduler;

t_scheduler	*sched;

int	sched_init(t_quantum q);

int	sched_quantum(t_quantum q);

int	sched_yield(void);

int	sched_next(t_thrid *thrid);

int	sched_switch(t_thrid thrid);

int	sched_thrid(t_thrid *thrid);

int	sched_clean(void);

int	sched_remove(t_thrid thrid);

int	sched_add(t_thrid thrid);

#endif
