/*
** atoi_base.c for corewar in /u/a1/stoven_m/mini_proj/corewar/fonction
**
** Made by martin stoven
** Login   <stoven_m@epita.fr>
**
** Started on  Wed Nov 24 20:30:50 2004 martin stoven
** Last update Fri Oct  7 11:11:14 2005 xebech
*/

#include "kmalloc.h"
#include "string.h"


#define BINBASE	"01"
#define OCTBASE	"01234567"
#define DECBASE	"0123456789"
#define HEXBASE "0123456789abcdef"

static int	my_atoi_bin_dec(char *tmp, int len);
static int	my_atoi_oct(char *tmp, int len);

/*!
** The search_in_base() function takes charactere and returns
** its place in the base
**
** @param c is the charactere to search.
**
** @param base is the base.
**
** @return The search_in_base() function returns -1 in Failure
** else an integer (>= 0).
*/
int	search_in_base(char c, const char *base)
{
  int	len = 0;
  int	i = 0;

  len = strlen((char *)base);
  while ((i < len) && (base[i] != c))
    i++;
  if (i < len)
    return i;
  return -1;
}

/*!
** The no_underscores() function takes a string and remove all '_'.
**
**
** @param str the string.
**
** @return The no_underscores() function returns the string without the '_'.
*/
char	*no_underscores(char *str)
{
  int	i = 0;
  int	j = 0;
  int	len = 0;

  if (str == NULL)
    return NULL;
  len = strlen(str);
  for (i = 0; i < len; i++)
    while (str[i] == '_')
      {
	for (j = i; j < (len - 1); j++)
	  str[j] = str[j + 1];
	str[j] = '\0';
      }
  return str;
}


/*!
** The my_atoi_x() function takes a number formated in a base and its base,
** and put it in an integer
**
** @param str is the number in a chosen base.
**
** @param base is the base.
**
** @return The my_atoi_x() function returns -1 in Failure
** else an integer (>= 0).
*/

int	my_atoi_x(char *str, const char *base)
{
  int	i = 0;
  int	res = 0;
  int	len = 0;
  int	baz = 0;
  int	tmp = 0;

  if ((str == NULL) || (len = strlen(str)) == 0)
    return -1;
  baz = strlen((char *)base);
  for (i = 0; i < len; i++)
    {
      if ((tmp = search_in_base(str[i], base)) == -1)
	return -1;
      res = (res * baz) + tmp;
    }
  return res;
}

/*!
** The my_atoi_oct() function takes a number formated in Octal (0...).
** and put it into a integer.
**
** @param tmp is the formated number.
** @param len is the size of tmp.
**
** @return The my_atoi_oct() returns a integer (>= 0) or -1 in failure.
*/

static int      my_atoi_oct(char *tmp, int len)
{
  int		res_tmp = 0;

  if ((len > 0) && (tmp[0] != '_') && (tmp[len - 1] != '_'))
    {
      res_tmp = my_atoi_x(no_underscores(tmp), OCTBASE);
      free(tmp);
      return res_tmp;
    }
  return -1;
}

/*!
** The my_atoi_base() function create takes a number formated in
** hexadecimal (0x...), Octal (0...), Binary (%...) or decimal (...).
** and put it into a integer.
**
** @param str is the formated number.
**
** @return The my_atoi_base() returns a integer (>= 0) or -1 in failure.
*/

int	my_atoi_base(char *str)
{
  char	*tmp = NULL;
  int	len = 0;
  int	res_tmp = 0;

  /*   tmp = my_strdup(str); */
  tmp = str;
  if (tmp == NULL)
      return -1;
  len = strlen((char *)str);

  if (tmp[0] == '0' && tmp[1])
    {
      /*       tmp = my_shift_str(tmp); */
      tmp++;
      if (((tmp[0] == 'x') || (tmp[0] == 'X'))
	  && (len > 0))
	{
	  res_tmp = my_atoi_x(/*(char *)my_shift_str(no_underscores(tmp))*/++tmp, HEXBASE);
	  /* 	  free(tmp); */
	  return res_tmp;
	}
      else
	return my_atoi_oct(tmp, len -1);
    }

  return my_atoi_bin_dec(tmp, len);
}

/*!
** The my_atoi_bin_dec() function takes a number formated in
** Octal (0...), Binary (%...) or decimal (...).
** and put it into a integer.
**
** @param tmp is the formated number.
**
** @param len is the size of tmp.
**
** @return The my_atoi_bin_dec() returns a integer (>= 0) or -1 in failure.
*/

static int	my_atoi_bin_dec(char *tmp, int len)
{
  int		res_tmp = 0;

  if (tmp[0] == '0' && !(tmp[1]))
    {
      free(tmp);
      return 0;
    }
  if ((tmp[0] == '%') && (len > 0) && (tmp[1] != '_') && (tmp[len - 1] != '_'))
    {
      res_tmp = my_atoi_x(/*(char *)my_shift_str(no_underscores(tmp))*/++tmp, BINBASE);
      free(tmp);
      return res_tmp;
    }
  if ((tmp[0] != '_') && len > 0 && (tmp[len - 1] != '_'))
    {
      res_tmp = my_atoi_x(no_underscores(tmp), DECBASE);
      free(tmp);
      return res_tmp;
    }
  free(tmp);
  return -1;
}
