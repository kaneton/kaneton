/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Sun Nov  6 23:48:26 2005 Nicolas Clermont
** Last update Mon Nov 14 22:18:11 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef KANETON_KANETON_TASK_TASK_H_
# define KANETON_KANETON_TASK_TASK_H_

# include "../../include/kaneton/types.h"
# include "../class.h"
# include "../behav.h"
# include "../prior.h"
# include "../status.h"
# include "../wait.h"
# include "../../lib/set/set.h"
/*
Structure of the message during they stay in the kernel
*/
typedef struct	s_msg_kern
{
  t_tskid	src;
  t_vaddr	msg;
}		t_msg_kern;

/*
** Describe a task
*/
typedef struct	s_task
{
  t_tskid	tskid;
  t_ownid	ownid;
  t_asid	asid;

  t_setid	threads;
  t_setid	children;

  t_class	class;
  t_behav	behav;
  t_prior	prior;

  t_status	sched;

  t_wait	wait;
  t_setid	msg;
  t_setid	waitlist;

  /*  matchdep_include(task);*/
}		t_task;

/*!
** User-friendly task create function
*/
int		task_create(char *filename, t_class class, char **argv);

/*!
** Initialize the tasks manager
*/
int		task_init(void);

/*
** Create and initialize a new task
** @param class		The new task class
** @param behav		The new task bahavior
** @param prior		The new task priority
** @param tskid		Return the id of the new task
*/
int		task_rsv(t_class class, t_behav behav,
			 t_prior prior, t_tskid *tskid);

/*!
** Get the identifier of the set that contains the system tasks
*/
int		task_setid(t_setid *setid);

/*!
** Fill prior with the actual priority of the task tskid
*/
int		task_prior(t_tskid tskid, t_prior *prior);

/*!
** Update the priority of the task tskid
*/
int		task_grade(t_tskid tskid, t_prior prior);

/*!
** Equivalent of the UNIX function wait()
*/
int		task_wait(t_tskid tskid, t_wait* wait);

/*!
** Fill task with the addess of the task structure tskid
*/
int		task_get(t_tskid tskid, t_task** task);

/*!
** Free the task structure tskid
*/
int		task_rel(t_tskid tskid);

/*!
** Clone a task, with its address space, modid, ...
*/
int		task_clone(t_tskid old, t_tskid *new);

/*!
** Fill asid the asid of the as used by the task tskid
*/
int		task_asid(t_tskid tskid, t_asid *asid);

/*!
** Fill ownid the ownid of the task tskid
*/
int		task_ownid(t_tskid tskid, t_ownid *ownid);

/*!
** Change the owner of the task tskid
** @param	tskid	Identify the task to give
** @param	ownid	Identify the new owner
*/
int		task_give(t_tskid tskid, t_ownid ownid);

/*!
** Make the task tskid executable
*/
int		task_run(t_tskid tskid);

/*!
** Stop the task tskid
*/
int		task_stop(t_tskid tskid);

/*!
** Allow to quit the task tskid
*/
int		task_exit(t_tskid tskid);

/*!
** Reinitialize the task manager
*/
int		task_clean(void);

/*!
** Print on screen all informations about task tskid
*/
int		task_print(t_tskid tskid);
/*!
** Wake up a thread when it receives a msg
*/
int	task_wakeup_thread_msg(t_tskid tskid, t_tskid src);

#endif		/* !KANETON_KANETON_TASK_TASK_H_ */
