/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:39:46 2005 Castaing Antoine
** Last update Mon Nov 14 22:22:38 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
** On i386, IRQ0 interruptions come from PIC 8259 which is connected
** to PIT (Programmable Interval Timer) 8254
*/

#ifndef TIMER_H_
# define TIMER_H_

#include "../../../lib/shell/parse_cmd.h"

#define TIMER_IRQ	0

/* Clock frequency in Hz */
#define I8254_MAX_FREQ	1193180
/* Frequency we use. The period is then 1 / FREQ = 10ms */
#define FREQ		100
#define NB_TICK		I8254_MAX_FREQ / FREQ

/* Max tick for the PIT */
#define MAX_TICK	65536

/* Ports to communicate with the PIT */
/* Connected to the processor */
#define I8254_TIMER0  0x40
/* Used to refresh the RAM */
#define I8254_TIMER1  0x41
/* Connected to speakers */
#define I8254_TIMER2  0x42
/* Used to control the chip behaviour, changing modes */
#define I8254_CONTROL 0x43

/* Number to send to the chip to set mode 2 */
#define I8254_CONTROL_MODE2	0x34
/* PIT LSB value */
#define I8254_LSB		(NB_TICK & 0xFF)
/* PIT LSB value */
#define I8254_MSB		((NB_TICK >> 8) & 0xFF)

/* struct time */
/* { */
/*   unsigned long int  sec; */
/*   /\*  unsigned long int nanosec; *\/ */
/* }; */

void	time(char *arg[NB_MAX_ARG], int nb_arg);
void	timer_tick(int a);
void	timer_init(void);

#endif /* !TIMER_H_ */
