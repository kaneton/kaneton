/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Sun Mar  6 23:37:07 2005 Castaing Antoine
** Last update Wed Nov 16 17:09:22 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
# include "../../lib/console/console.h"
#include "../../bootloader/ch_cr.h"
#include "../../bootloader/phys_mem_mapping.h"
#include "../trap/trap.h"
#include "idt.h"

void	exceptions_how_handler(int inter)
{

  t_vaddr pd_user = 0;

  pd_user = get_pd_address();
  set_pd_address(PD_ENTRY);

  tab_traps[inter]->behave(inter);

  set_pd_address(pd_user);
/*   printf("exception no %d %x", inter, inter); */
/*   for ( a =0; a < 200000; a++) */
/*     ; */
/*   asm("sti\n"); */
}

void	exception_null_handler(int inter)
{
/*   asm("cli\n"); */
  inter = inter;
/*   asm("sti\n"); */
}
