#include "thread.h"
#include "../task/task.h"
#include "../scheduler/scheduler.h"
#include "../malloc/kmalloc.h"
#include "../../lib/console/console.h"
#include "../../lib/memory/as.h"
#include "../../lib/memory/pm.h"
#include "../../lib/memory/vm.h"
#include "../../bootloader/ch_cr.h"
#include "../../bootloader/phys_mem_mapping.h"

static t_setid	thread_setid;

/*!
** Initialize the threads manager
*/
int		thread_init(void)
{
  if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_thread), 0, &thread_setid))
    return 1;

  return 0;
}

/*!
** Create and initialize a new thread
** @param prior		The new thread priority
** @param thrid		Return the id of the new thread
*/
int			thread_rsv(t_prior prior, t_thrid *thrid)
{
  t_thread		*thread = malloc(sizeof(t_thread), KASID);
  t_thrid		current_thrid;
  t_tskid		current_tskid;
  static t_thrid	cur_thrid = 0;

  sched_thrid(&current_thrid);
  if (current_thrid != (t_thrid) -1)
    thread_tskid(current_thrid, &current_tskid);
  else
    current_tskid = 0;
  /* Initialize the new thread */
  thread->thrid = cur_thrid;
  *thrid = thread->thrid;
  ++cur_thrid;
  thread->tskid = -1;
  thread->ownid = current_tskid;
  thread->prior = prior;
  thread->sched = STATUS_STOP;
  /* NOT SURE */
  thread->wait.u.tskid = 0;
  thread->wait.u.thrid = 0;
  thread->wait.status = 0;
  thread->wait.value = 0;
  if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_thrid), 0, &(thread->wait_list)))
    return 1;
  thread->stack = 0;
  thread->stacksz = 0;
  /*  thread->cpu_state = -1; */
  if (set_insert(thread_setid, thread))
    {
      printf("ERROR: %s:%d: thread_rsv\n", __FILE__, __LINE__);
      return 1;
    }
  return 0;
}

/*!
** Fill prior with the actual priority of the thread thrid
*/
int		thread_prior(t_thrid thrid, t_prior *prior)
{
  t_thread	*thread = NULL;

  if (thread_get(thrid, &thread))
    return 1;

  *prior = thread->prior;

  return 0;
}

/*!
** Update the priority of the thread thrid with prior
*/
int		thread_grade(t_thrid thrid, t_prior prior)
{
  t_thread	*thread = NULL;

  if (thread_get(thrid, &thread))
    return 1;

  thread->prior = prior;

  return 0;
}

/*!
** Equivalent of the UNIX function wait()
*/
int		thread_wait(t_thrid thrid, t_wait *wait)
{
  t_thread	*thread = NULL;
  t_thread	*current_thread = NULL;
  t_thrid	*current_thrid = malloc(sizeof(t_thrid), KASID);
  t_thrid	next_thrid;

  sched_thrid(current_thrid);
  if (thread_get(*current_thrid, &current_thread))
    return 1;
  if (thread_get(thrid, &thread))
    return 1;

  if (thread->sched == STATUS_ZOMBIE)
    {
      if (wait)
	{
	  wait->u.thrid = thrid;
	  wait->status = STATUS_EXITED;
	  wait->value = 0; // FIXME : VALEUR DE RETOUR
	}
      /*parcourir la wait_list pour prevenir que mort*/
      thread_rel(thrid);
      free(current_thrid);
      return 0;
    }

  set_insert(thread->wait_list, current_thrid);

  current_thread->sched = STATUS_WAIT;
  sched_remove(*current_thrid);
  if (sched_next(&next_thrid))
      return 0;
  sched_switch(next_thrid);
  if (wait)
    *wait = current_thread->wait;

  return 0;
}



/*!
** Fill thread with the addess of the thread structure thrid
*/
int		thread_get(t_thrid thrid, t_thread **thread)
{
  t_iterator	it;

  if (set_get(thread_setid, thrid, &it))
    {
      printf("ERROR: %s:%d: thread_get on thrid %d\n", __FILE__, __LINE__, thrid);
      return 1;
    }
  *thread = ITERATOR_ADDR(&it);

  return 0;
}

/*!
** Free the thread structure thrid
*/
int		thread_rel(t_thrid thrid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread))
    return 1;
  if (set_delete(thread_setid, thread->thrid))
    return 1;

  return 0;
}

/*!
** Clone a thread
*/
int		thread_clone(t_thrid old, t_thrid *new)
{
  t_thread	*old_thread;
  t_thread	*new_thread;

  if (thread_get(old, &old_thread))
    return 1;
  if (thread_rsv(old_thread->prior, new))
    return 1;

  if (thread_get(*new, &new_thread))
    return 1;

  new_thread->tskid = old_thread->tskid;
  new_thread->ownid = old_thread->ownid;
  new_thread->prior = old_thread->prior;

  return 0;
}

/*!
** Make the thread thrid executable
*/
int		thread_run(t_thrid thrid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread))
    return 1;
  thread->sched = STATUS_RUN;
  sched_add(thrid);

  return 0;
}

/*!
** Stop the thread thrid
*/
int		thread_stop(t_thrid thrid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread))
    return 1;
  thread->sched = STATUS_STOP;
  sched_remove(thrid);

  return 0;
}

/*!
** Fill tskid with the id of the task that owned the thread thrid
*/
int		thread_tskid(t_thrid thrid, t_tskid *tskid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread))
    return 1;
  *tskid = thread->tskid;
  return 0;
}

/*!
** Fill ownid with the id of the owner the thread thrid
*/
int		thread_ownid(t_thrid thrid, t_ownid *ownid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread))
    return 1;
  *ownid = thread->ownid;
  return 0;
}

/*!
** Change the owner of the thread thrid with ownid
*/
int		thread_give(t_thrid thrid, t_ownid ownid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread))
    return 1;
  thread->ownid = ownid;
  return 0;
}

/*!
** Reserve a stack of size npages for the thread thrid
*/
int		thread_stack(t_thrid thrid, t_vsize npages)
{
  t_thread	*thread;
  t_task	*task;
  t_as		*as;
  t_tskid	tskid;
  t_paddr	stack_paddr;
  t_paddr	ptm_addr;
  t_vaddr	vptm_addr;

  if (thread_get(thrid, &thread))
    return 1;
  if (thread->stack)
    free((void *)thread->stack);
  if(thread_tskid(thrid, &tskid))
    return 1;
  if (task_get(tskid, &task))
    return 1;
  if (as_get(task->asid, &as))
    return 1;

  ptm_addr = ((((t_paddr*)(as->pd_vaddr))[1]) >> 12) * PAGE_SIZE;
  pm_rsv(task->asid, &stack_paddr, npages, PM_FLAG_ANY);
  vptm_addr = ptm_pm_to_vm(KASID, ptm_addr);
  thread->stack = PTM_PDE << 22;
  thread->stack |= (map_new_page(vptm_addr, stack_paddr, USER | RW)) << 12;
  thread->stacksz = npages;

  return 0;
}

/*!
** FIXME : WITH SCHEDULER
*/
int		thread_load(t_thrid thrid, t_thrctx *thrctx)
{
  t_thread	*thread;

  thrctx = thrctx;

  if (thread_get(thrid, &thread))
    return 1;
  thread->cpu_state.eip = thrctx->pc;
  thread->cpu_state.esp = thrctx->sp;
  thread->cpu_state.ebp = thrctx->sp;
  thread->cpu_state.ss = 0x2B;
  thread->cpu_state.cs = 0x23;
  thread->cpu_state.ds = 0x2B;
  thread->cpu_state.es = 0x2B;
  thread->cpu_state.fs = 0x2B;
  thread->cpu_state.eflags = 0x3202;
  thread->cpu_state.eax = 0;
  thread->cpu_state.ebx = 0;
  thread->cpu_state.ecx = 0;
  thread->cpu_state.edx = 0;
  thread->cpu_state.edi = 0;
  thread->cpu_state.esi = 0;
  return 0;
}

/*!
** FIXME : WITH SCHEDULER
*/
int		thread_store(t_thrid thrid, t_thrctx *thrctx)
{
  t_thread	*thread;

  thrctx = thrctx;

  if (thread_get(thrid, &thread))
    return 1;

  return 0;
}

/*!
** Copy size octets of args on the stack of thread thrid
*/
int		thread_args(t_thrid thrid, void *args, t_size size)
{
  t_thread	*thread;
  unsigned char	i = 0;

  if (thread_get(thrid, &thread))
    return 1;
  if (!thread->stack)
    return 1;

  for (i = 0; i < size; i++)
    // Ecrire a partir de ESP + bouger ESP (CRT ?)
    *((char *)thread->stack + i) = *((char *)args + i);

  return 0;
}

/*!
** Attach the thread thrid to the task tskid
*/
int		thread_attach(t_thrid thrid, t_tskid tskid)
{
  t_thread	*thread;
  t_task	*task;
  t_thrid	*thrid_attach = malloc(sizeof(t_thrid), KASID);

  if (thread_get(thrid, &thread))
    return 1;
  thread->tskid = tskid;
  if (task_get(tskid, &task))
    return 1;

  *thrid_attach = thrid;
  if (set_insert(task->threads, thrid_attach))
    return 1;

  return 0;
}

/*!
** Detach the thread thrid from the task tskid
*/
int		thread_detach(t_thrid thrid, t_tskid tskid)
{
  t_thread	*thread = NULL;
  t_task	*task = NULL;

  if (thread_get(thrid, &thread))
    return 1;
  thread->tskid = -1;
  if (task_get(tskid, &task))
    return 1;
  if (set_delete(task->threads, thrid))
    return 1;

  return 0;
}

/*!
**
*/
int		thread_exit(t_thrid thrid)
{
  t_iterator	it_wait;
  t_thread	*thread = NULL;
  t_thread	*wait_thread = NULL;
  t_wait	wait;

  if (thread_get(thrid, &thread))
    return 1;
  if (thread_stop(thrid))
    return 1;

  /*             FIXME : IMPLEMENT SET_SIZE */

  /*   if (!set_size(thread->wait_list)) */
  /*     { */
  /*       thread->sched = STATUS_ZOMBIE; */
  /*       return 0; */
  /*     } */

  wait.u.thrid = thrid;
  wait.status = STATUS_EXITED;
  wait.value = 0;//FIXME : OU SE TROUVE T ELLE ? REGISTRE ? PILE ?

  SET_FOREACH(FOREACH_FORWARD, thread->wait_list, &it_wait)
    {
      // EST CE AU KERNEL DE LE FAIRE ???
      thread_get(ITERATOR_ID(&it_wait), &wait_thread);
      wait_thread->wait = wait;
      wait_thread->sched = STATUS_RUN;
    }
  thread_rel(thrid);

  return 0;
}

/*!
** Reinitialize the thread manager
*/
int	thread_clean(void)
{
  if (set_rel(thread_setid))
    return 1;

  return 0;
}

/*!
** Get the virtual address of the stack of the thread thrid
*/
t_vaddr		thread_get_stack_vaddr(t_thrid thrid)
{
  t_thread	*thread = NULL;

  if (thread_get(thrid, &thread))
    return 1;
  return (thread->stack);
}
