/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:39:19 2005 Castaing Antoine
** Last update Wed Oct 12 16:23:26 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "scheduler.h"
#include "../../lib/console/console.h"
#include "../../lib/memory/as.h"
#include "../../bootloader/phys_mem_mapping.h"
#include "../../bootloader/ch_cr.h"
#include "../../bootloader/gdt_segments.h"
#include "../malloc/kmalloc.h"
/* #define DEBUG_SCHED 1 */

/*!
** Regle le quantum par defaut.
** @param q : quantum en milli sec
*/

int	sched_init(t_quantum q)
{
  t_tss		*tss = (t_tss *)TSS;

  sched = (t_scheduler*)SCHED_ENTRY;
  sched->quantum = q;
  if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_thrid), 0, &(sched->run)))
    return 1;
  sched->thrid = -1;
  sched->tick = 0;
  sched->ebp_val = 0;
  tss->ss0 = 0x10;
  asm ("mov $0x18, %ebx \n \
	ltr %bx \n");
  return 0;
}

/*!
** Redefini le quantum
*/
int	sched_quantum(t_quantum q)
{
  sched->quantum = q;
  return 0;
}

/*!
** Cette fonction est appelee par une tache.
** Elle rend la main au scheduler
*/
int	sched_yield(void)
{
  return 0;
}

/*!
** Met dans thread le prochain thread a etre exec
** @param thread : prochain thread execute
*/
int	sched_next(t_thrid *thrid)
{
  t_iterator	it;
  t_iterator	it_next;

/*   printf("sched_next thrid <%d>\n", *thrid); */
  if (set_get(sched->run, *thrid, &it))
    return 1;

  if (set_next(sched->run, it, &it_next))
    set_head(sched->run, &it_next);
  *thrid = ITERATOR_ID(&it_next);
/*   printf("sched_next thrid <%d>\n", *thrid); */
  return 0;
}

/*!
** Cette fonction effectue le changement de contexte
** et execute thread
*/
int	sched_switch(t_thrid thrid)
{
  /*Instance du thread courant*/
  t_thread	*thread = NULL;
  /*pointeur nous permttant de visiter la pile*/
  unsigned int	*temp;
  /*Iterateur pour le set*/
  t_iterator	it;
  /*Identifiant de la tache courant*/
  t_tskid	tskid;
  /*Identifiant de l as courant*/
  t_asid	asid;
  /*As courant*/
  t_as		*as;
  /*tss*/
  t_tss		*tss = (t_tss *)TSS;


  /*On passe en as kernel*/
  set_pd_address((unsigned int)PD_ENTRY);

  /*Si le thrid est a -1 on  est dans le kernel
  **et donc pas encore de thread courant*/
  if (thrid == (t_thrid)-1)
    {
      sched->tick = 100;
      /*On regarde si il y en a un dans la file d attente*/
      if (set_head(sched->run, &it))
	return 1;

      /*Si oui on le recupere ainsi que son as, ...*/
      sched->thrid = ITERATOR_ID(&it);
      if (thread_get(sched->thrid, &thread))
	return 1;
      if (thread_tskid(sched->thrid, &tskid))
	return 1;
      if (task_asid(tskid, &asid))
	return 1;
      if (as_get(asid, &as))
	return 1;

      sched->tick = 100;

      /*Comme je n ai pas encore de thread courant
       je remplis les valeurs de registre sauvegard�
      avec le thread a exectuer. Ainsi apres retour timer
      le thread sera exec*/
      temp = (unsigned int *)((void *)sched->ebp_val);


      /*Ici on recuppere tt ce ki est empiler pour le retour de l interruption
       esp ss cs eip ...*/
#ifdef DEBUG_SCHED
      printf("le ancien ebp est <");
      my_printnbr((unsigned int)*temp);
      printf("> a l @ <%x>\n", temp);
#endif
      *temp = thread->cpu_state.ebp;
#ifdef DEBUG_SCHED
      printf("le nouvo ebp est <");
      my_printnbr((unsigned int)*temp);
      printf("> a l @ <%x>\n", temp);
#endif
      temp++;


#ifdef DEBUG_SCHED
      printf("le ancien eip est <");
      my_printnbr((unsigned int)*temp);
      printf("> a l @ <%x>\n", temp);
#endif
      *temp = thread->cpu_state.eip;
#ifdef DEBUG_SCHED
      printf("le nouvo eip est <");
      my_printnbr((unsigned int)*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp++;
#ifdef DEBUG_SCHED
      printf("le ancien cs est <");
      my_printnbr((unsigned int)*temp);
      printf("> a l @ <%x>\n", temp);
#endif
      *temp = thread->cpu_state.cs;
#ifdef DEBUG_SCHED
      printf("le nouvo cs est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp++;
#ifdef DEBUG_SCHED
      printf("les ancien eflags sont <");
      my_printnbr((unsigned int)*temp);
      printf("> a l @ <%x>\n", temp);
#endif
      *temp = thread->cpu_state.eflags;
#ifdef DEBUG_SCHED
      printf("le nouvo eflags est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp++;
#ifdef DEBUG_SCHED
      printf("l ancien potentiel esp <");
      my_printnbr((unsigned int)*temp);
      printf("> a l @ <%x>\n", temp);
#endif
      *temp = thread->cpu_state.esp;
#ifdef DEBUG_SCHED
      printf("le nouvo esp est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp++;
#ifdef DEBUG_SCHED
      printf("l ancien potentiel ss <");
      my_printnbr((unsigned int)*temp);
      printf("> a l @ <%x>\n", temp);
#endif
      *temp = thread->cpu_state.ss;
#ifdef DEBUG_SCHED
      printf("le nouvo ss est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      /*Je met les bonne valeur dans eax, ebx, ...*/
      temp = (unsigned int *)((void *)sched->ebp_val);

      temp--;
      *temp = thread->cpu_state.ds;
#ifdef DEBUG_SCHED
      printf("le ds mis est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp--;
      *temp = thread->cpu_state.eax;
#ifdef DEBUG_SCHED
      printf("le nouvo eax est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp--;
      *temp = thread->cpu_state.ecx;
#ifdef DEBUG_SCHED
      printf("le nouvo ecx est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp--;
      *temp = thread->cpu_state.edx;
#ifdef DEBUG_SCHED
      printf("le nouvo edx est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp--;
      *temp = thread->cpu_state.ebx;
#ifdef DEBUG_SCHED
      printf("le nouvo ebx est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif

      temp--;
      /* ESP */

      temp--;
      /* EBP */


      temp--;
      *temp = thread->cpu_state.esi;
#ifdef DEBUG_SCHED
      printf("le nouvo esi est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp--;
      *temp = thread->cpu_state.edi;
#ifdef DEBUG_SCHED
      printf("le nouvo edi est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif


      temp--;
      *temp = thread->cpu_state.ebp;
#ifdef DEBUG_SCHED
      printf("le nouvo ebp est <");
      my_printnbr(*temp);
      printf("> a l @ <%x>\n", temp);
#endif

      /*Je met les bonne valeur ds le tss*/
      tss->esp0 = sched->ebp_val + 4 * 6;
      tss->ss0 = 0x10;
      tss->esp = thread->cpu_state.esp;
      tss->ss = thread->cpu_state.ss;
      tss->cs = thread->cpu_state.cs;
      tss->cr3 = as->pd_addr;
      /*et passe en as user*/
      set_pd_address((unsigned int)as->pd_addr);
  /*     while (1); */
      return 0;
    }

  /*Ici il y a deja des threads en exec donc je sched*/

  if (thread_get(thrid, &thread))
    return 1;

/*   printf("scheduler thd a save %d\n", thrid); */

  /*JE SAVE L ANCIEN THREAD*/
  temp = (unsigned int *)((void *)sched->ebp_val);
#ifdef DEBUG_SCHED
  printf("le ancien ebp est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.ebp = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo ebp est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("le ancien eip est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.eip = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo eip est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif


  temp++;
#ifdef DEBUG_SCHED
  printf("le ancien cs est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.cs = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo cs est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("les ancien eflags sont <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.eflags = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo eflags est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("l ancien potentiel esp <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.esp = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo esp est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("l ancien potentiel ss <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.ss = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo ss est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp = (unsigned int *)((void *)sched->ebp_val);
  temp--;
  thread->cpu_state.ds = *temp;
#ifdef DEBUG_SCHED
  printf("le ds mis est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif


  temp--;
  thread->cpu_state.eax = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo eax est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  thread->cpu_state.ecx = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo ecx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  thread->cpu_state.edx = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo edx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  thread->cpu_state.ebx = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo ebx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  /* ESP */

  temp--;
  /* EBP */

  temp--;
  thread->cpu_state.esi = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo esi est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  thread->cpu_state.edi = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo edi est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  temp--;

/*   printf("sched -> sched->thrid avt next %d\n", sched->thrid); */

  sched_next(&(sched->thrid));
  if (thread_get(sched->thrid, &thread))
    return 1;

/*   printf("sched -> sched->thrid apres next %d\n", sched->thrid); */

  /*
  ** Ici on fait le switch vers le prochain thread
  */
  sched->tick = 100;
  temp = (unsigned int *)((void *)sched->ebp_val);


#ifdef DEBUG_SCHED
  printf("le ancien ebp est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.ebp;
#ifdef DEBUG_SCHED
  printf("le nouvo ebp est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("le ancien eip est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.eip;
#ifdef DEBUG_SCHED
  printf("le nouvo eip est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif


  temp++;
#ifdef DEBUG_SCHED
  printf("le ancien cs est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.cs;
#ifdef DEBUG_SCHED
  printf("le nouvo cs est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("les ancien eflags sont <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.eflags;
#ifdef DEBUG_SCHED
  printf("le nouvo eflags est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("l ancien potentiel esp <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.esp;
#ifdef DEBUG_SCHED
  printf("le nouvo esp est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("l ancien potentiel ss <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.ss;
#ifdef DEBUG_SCHED
  printf("le nouvo ss est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp = (unsigned int *)((void *)sched->ebp_val);

  temp--;
  *temp = thread->cpu_state.ds;
#ifdef DEBUG_SCHED
  printf("le ds mis est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif


  temp--;
  *temp = thread->cpu_state.eax;
#ifdef DEBUG_SCHED
  printf("le nouvo eax est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.ecx;
#ifdef DEBUG_SCHED
  printf("le nouvo ecx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.edx;
#ifdef DEBUG_SCHED
  printf("le nouvo edx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.ebx;
#ifdef DEBUG_SCHED
  printf("le nouvo ebx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  /* ESP */

  temp--;
  /* EBP */

  temp--;
  *temp = thread->cpu_state.esi;
#ifdef DEBUG_SCHED
  printf("le nouvo esi est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.edi;
#ifdef DEBUG_SCHED
  printf("le nouvo edi est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.ebp;
#ifdef DEBUG_SCHED
  printf("le nouvo ebp est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif


  if (thread_tskid(sched->thrid, &tskid))
    return 1;
  if (task_asid(tskid, &asid))
    return 1;
  if (as_get(asid, &as))
    return 1;

  tss->esp0 = sched->ebp_val + 4 * 6;
  tss->ss0 = 0x10;
  tss->esp = thread->cpu_state.esp;
  tss->ss = thread->cpu_state.ss;
  tss->cs = thread->cpu_state.cs;
  tss->cr3 = as->pd_addr;



  /* while (1); */
  set_pd_address((unsigned int)as->pd_addr);

  return 0;
}

/*!
** Cette fonctoin remplit thread avec le thread en execution
*/
int	sched_thrid(t_thrid *thrid)
{
  *thrid = sched->thrid;
  return 0;
}

/*!
** Cette fonction reinitialise le scheduler
*/
int	sched_clean(void)
{
  sched->run = 0;
  sched->thrid = 0;

  return 0;
}

/*!
** Remove a thread from the run-queue
*/
int	sched_remove(t_thrid thrid)
{
#ifdef DEBUG_SCHED
  printf("sched_remove de thrid %d\n", thrid);
#endif
  if (set_delete(sched->run, thrid))
    {
      printf("scheduler -> set_delete rate\n");
      return 1;
    }
#ifdef DEBUG_SCHED
  printf("scheduler -> set_delete reussi\n");
#endif
  return 0;
}

/*!
** Add a thread to the run-queue
*/
int		sched_add(t_thrid thrid)
{
  t_thrid	*sched_thrid = malloc(sizeof(t_thrid), 1);

  *sched_thrid = thrid;
  if (set_insert(sched->run, sched_thrid))
    return 1;
  return 0;
}
