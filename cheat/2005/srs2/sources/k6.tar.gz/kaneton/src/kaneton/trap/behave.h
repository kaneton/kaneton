/*
** Copyright (C) Antoine Castaing aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Tue Nov  8 17:31:19 2005 Antoine Castaing
** Last update Wed Nov 16 16:59:27 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/



#ifndef KERN_TRAP_BEHAVE_H_
# define KERN_TRAP_BEHAVE_H_

# define BEHAVE_MALLOC		1
# define BEHAVE_FREE		2
# define BEHAVE_GET_MSG		3
# define BEHAVE_WAIT_MSG	4
# define BEHAVE_SEND_MSG	5
# define BEHAVE_CREATE_MSG	6
# define BEHAVE_EXIT		7
# define BEHAVE_SUBSCRIBE_TRAP	8
# define BEHAVE_UNSUBSCRIBE_TRAP 9
# define BEHAVE_VM_RSV		10
# define BEHAVE_VM_MAP		11
# define BEHAVE_MM_REL		12
# define BEHAVE_TASK_RSV	13
# define BEHAVE_AS_RSV		14
# define BEHAVE_THREAD_RSV	15
# define BEHAVE_AS_ATTACH	16
# define BEHAVE_THREAD_ATTACH	17
# define BEHAVE_THREAD_STACK	18
# define BEHAVE_THREAD_LOAD	19
# define BEHAVE_THREAD_RUN	20
# define BEHAVE_THREAD_GET_STACK_ADDR	21
# define BEHAVE_AS_SET_MODID	22
# define BEHAVE_AS_GET_MODID	23
# define BEHAVE_AS_GET_PD_PADDR 24
# define BEHAVE_FORK		25
# define BEHAVE_HE_GET_PARAM	26
# define BEHAVE_AS_MODID_TASKID 27
# define BEHAVE_TASK_CREATE	28
# define BEHAVE_GET_MSG_FROM	29
# define BEHAVE_WAIT_MSG_FROM	30

void	behave_syscall(int);
void	behave_mod_syscall(int);
void	behave_irq_exception(int);
void	behave_void(int);
void	behave_exception_debug(int);

#endif
