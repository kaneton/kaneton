#include "test.h"

/*!
** Test for division by zero (interrupt)
*/
void		test_div_zero(void)
{
  int		i = 5;

  i = 5 / (i - 5);
}
