/*
** Copyright (C) Laurent Decool aka traktopel <laurent.decool@gmail.com>
**
** Part of Kaneton
**
** Started on  Wed Oct  5 14:49:25 2005 Laurent Decool
** Last update Wed Oct  5 15:18:33 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../keys.h"
#include "../../../../lib/console/console.h"

void	keyboard_empty_func(void)
{
  printf("  empty-fct called  ");
}

void	keyboard_home(void)
{
  printf("  home-fct called  ");
}

void	keyboard_haut(void)
{
  printf("  up-fct called  ");
}

void	keyboard_page_up(void)
{
  printf("  page_up-fct called  ");
}

void	keyboard_gauche(void)
{
  printf("  left-fct called  ");
}

void	keyboard_droite(void)
{
  printf("  right-fct called  ");
}

void	keyboard_fin(void)
{
  printf("  end-fct called  ");
}

void	keyboard_bas(void)
{
  printf("  down-fct called  ");
}

void	keyboard_page_down(void)
{
  printf("  page_down-fct called  ");
}

void	keyboard_insert(void)
{
  printf("  insert-fct called  ");
}

void	keyboard_suppr(void)
{
  printf("  suppr-fct called  ");
}

void	keyboard_f1(void)
{
  printf("  F1 pressed  ");
}

void	keyboard_f2(void)
{
  printf("  F2 pressed  ");
}

void	keyboard_f3(void)
{
  printf("  F3 pressed  ");
}

void	keyboard_f4(void)
{
  printf("  F4 pressed  ");
}

void	keyboard_f5(void)
{
  printf("  F5 pressed  ");
}

void	keyboard_f6(void)
{
  printf("  F6 pressed  ");
}
void	keyboard_f7(void)
{
  printf("  F7 pressed  ");
}


void	keyboard_f8(void)
{
  printf("  F8 pressed  ");
}

void	keyboard_f9(void)
{
  printf("  F9 pressed  ");
}

void	keyboard_f10(void)
{
  printf("  F10 pressed  ");
}

