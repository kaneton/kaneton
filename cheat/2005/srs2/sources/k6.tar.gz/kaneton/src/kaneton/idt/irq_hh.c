/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Sun Mar  6 23:37:07 2005 Castaing Antoine
** Last update Wed Nov 16 17:05:00 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../../lib/console/console.h"
#include "../../bootloader/ch_cr.h"
#include "../../bootloader/phys_mem_mapping.h"
#include "../trap/trap.h"
#include "idt.h"

/* extern t_trap		*tab_traps[256]; */

void	irqs_how_handler(int inter)
{
/*   extern t_trap		*tab_traps[256]; */
  t_vaddr pd_user = 0;

/*   printf("irq no %d\n", inter); */
  pd_user = get_pd_address();
/*   printf("avt changement de pd elle est a %x\n", pd_user); */
  set_pd_address(PD_ENTRY);
/*   printf("avt appelle behave no %d\n l @ du tableau de  trap est %x\n", EXCEPTION_ENTRIES + inter, */
/* 	 tab_traps); */
 /*  printf("L'@ de la fct est %x%x\n", (unsigned int)(tab_traps[EXCEPTION_ENTRIES + inter]->behave) / 0x10, (unsigned int)(tab_traps[EXCEPTION_ENTRIES + inter]->behave) % 0x10); */
/*   while (1); */
  tab_traps[EXCEPTION_ENTRIES + inter]->behave(EXCEPTION_ENTRIES + inter);
/*   while (1); */
  set_pd_address(pd_user);
/*   printf("fin irqs how handler\n"); */
}


void	irq_null_handler(int inter)
{
  int a = inter;

  inter = a;
}
