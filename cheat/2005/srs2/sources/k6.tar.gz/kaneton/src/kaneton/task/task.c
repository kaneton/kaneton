/*
** Copyright (C) Decool Laurent aka Traktopel <laurent.decool@gmail.com>
**
** Part of Kaneton
**
** Started on  Mon Mar 28 15:07:55 2005 Laurent Decool
** Last update Wed Nov 23 03:16:25 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have receivedstruct_mapping.h a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../bootloader/ch_cr.h"
#include "../../bootloader/phys_mem_mapping.h"
#include "../../lib/memory/pm.h"
#include "../../lib/memory/vm.h"
#include "../../lib/memory/as.h"
#include "../../lib/set/set.h"
#include "../malloc/kmalloc.h"
#include "task.h"
#include "../thread/thread.h"
#include "../scheduler/scheduler.h"
#include "../../lib/console/console.h"

#define PAS_NODE_ADDR	list_search_free_phys_space_pt(PTAS_ENTRY, sizeof(t_area_list), 1)

extern t_list	*as_list;
extern t_pm	*pm;

/*
** The task set of the system
*/
t_setid		tasks;
/*
** the kernel task
*/
t_task		ktask;

/*!
** User-friendly task create function
*/
/* int		task_create(char *filename, t_class class, char **argv) */
/* { */
/*   filename = filename; */
/*   argv = argv; */

/*   t_tskid	tskid; */
/*   t_thrid	thrid; */
/*   /\*   t_modid	modid; *\/ */
/*   /\*   t_thrctx	thrctx; *\/ */
/*   t_asid	asid; */
/*   unsigned int	i = 0; */
/*   t_as		*tskas; */
/*   t_area_list	*pm_tmp = pm->used; */

/*   task_rsv(class, BEHAV_TIMESHARING, PRIOR_TIMESHARING, &tskid); */

/*   as_rsv(&asid); */

/*   as_attach(asid, tskid); */

/*   thread_rsv(PRIOR_TIMESHARING, &thrid); */
/*   thread_attach(thrid, tskid); */

  /*   mod_add(filename, LIFETIME_FINITE, &modid); */
  /*   mod_load(modid, asid); */

  /*   thread_store(thrid, &thrctx); */
  /*   mod_entry(modid, &thrctx.pc); */
  /*   thread_load(thrid, &thrctx); */


  /*
  **  A PARTIR
  **   DE LA
  **  C DANS
  ** AS ATTACH ?
  */
/*   as_get(asid, &tskas); */
/*   set_pd_address((unsigned int)tskas->pd_addr); */
  /*   set_pd_address((unsigned int)PD_ENTRY); */
/*   return 0; */
/* } */

/*!
** Initialize the tasks manager
*/
int		task_init(void)
{
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_task), 0, &tasks);
/*   printf("SET DE TACHE : %d\n", tasks); */
/*   while (1); */
/*   printf("TASK_INIT CR3 : %x\n", (unsigned int)get_CR3()); */
/*   while (1); */
  /*
  ** Initialize the Kernel Task
  */
  ktask.tskid = 1;
  ktask.ownid = 0;
  ktask.asid = KASID;
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_thrid), 0,
	  &(ktask.threads));
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_tskid), 0,
	  &(ktask.children));
  ktask.class = CLASS_KERNEL;
  ktask.behav = BEHAV_KERNEL;
  ktask.prior = PRIOR_KERNEL;
  ktask.sched = STATUS_RUN;

  /* NOT SURE */
  /*   ktask.wait.u.tskid = 0; */
  /*   ktask.wait.u.thrid = 0; */
  /*   ktask.wait.status = 0; */
  /*   ktask.wait.value = 0; */
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_tskid), 0,
	  &(ktask.waitlist));
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_msg_kern), 0,
	  &(ktask.msg));
 /*  as_attach(KASID, ktask.tskid); */
  ktask.asid = KASID;
/*   while (1); */
  /*   task_print(ktask.tskid); */

  return 0;
}

/*
** Create and initialize a new task
** @param class		The new task class
** @param behav		The new task bahavior
** @param prior		The new task priority
** @param tskid		Return the id of the new task
*/
int			task_rsv(t_class class, t_behav behav,
				 t_prior prior, t_tskid *tskid)
{
  static t_tskid	new_tskid = 2;
  t_task		*new_task;
  t_thrid		current_thrid;
  t_tskid		current_tskid;

  sched_thrid(&current_thrid);
  if (current_thrid != (t_thrid) -1)
    thread_tskid(current_thrid, &current_tskid);
  else
    current_tskid = 0;

  /* FIXME KEL ASID ??? */
  new_task = malloc(sizeof(t_task), KASID);
  new_task->tskid = new_tskid;
  new_task->ownid = current_tskid;
  new_task->asid = 0;
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_thrid), 0,
	  &(new_task->threads));
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_tskid), 0,
	  &(new_task->children));
  new_task->class = class;
  new_task->behav = behav;
  new_task->prior = prior;
  new_task->sched = STATUS_STOP;
  /* NOT SURE */
  /*   new_task->wait.u.tskid = 0; */
  /*   new_task->wait.u.thrid = 0; */
  /*   new_task->wait.status = 0; */
  /*   new_task->wait.value = 0; */
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_tskid), 0,
	  &(new_task->waitlist));

  /* Reservation du set de msg de la tache
   On garde l @ du msg et de la tache envoyant*/
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_msg_kern), 0,
	  &(new_task->msg));

  *tskid = new_tskid;
  set_insert(tasks, new_task);
  new_tskid++;

  return 0;
}

/*!
** Get the identifier of the set that contains the system tasks
*/
int		task_setid(t_setid *setid)
{
  *setid = tasks;

  return 0;
}

/*!
** Fill prior with the actual priority of the task tskid
*/
int		task_prior(t_tskid tskid, t_prior *prior)
{
  t_task	*searched_task = NULL;

  if (task_get(tskid, &searched_task))
    return 1;

  *prior = searched_task->prior;

  return 0;
}

/*!
** Update the priority of the task tskid
*/
int		task_grade(t_tskid tskid, t_prior prior)
{
  t_task	*searched_task = NULL;

  if (task_get(tskid, &searched_task))
    return 1;

  searched_task->prior = prior;

  return 0;
}

/*!
** Equivalent of the UNIX function wait()
** @param	tskid	Identify the task to wait
** @param	wait	Contains informations on the dead task tskid
*/
int		task_wait(t_tskid tskid, t_wait* wait)
{
  t_iterator	it_threads;
  t_task	*searched_task = NULL;
  t_task	*current_task = NULL;
  t_thrid	current_thrid;
  t_tskid	*current_tskid = malloc(sizeof(t_tskid), 1); //FIXME ASID

  sched_thrid(&current_thrid);
  thread_tskid(current_thrid, current_tskid);
  /*FIXME VOIR POUR KASID*/
  if (task_get(tskid, &searched_task))
    return 1;
  if (task_get(*current_tskid, &current_task))
    return 1;

  if (searched_task->sched == STATUS_ZOMBIE)
    {
      if (wait)
	{
	  wait->u.tskid = tskid;
	  wait->status = STATUS_EXITED;
	  wait->value = 0; // FIXME : VALEUR DE RETOUR
	}
      task_rel(tskid);
      free(current_tskid);
      return 0;
    }

  set_insert(searched_task->waitlist, current_tskid);
  current_task->sched = STATUS_WAIT;
  SET_FOREACH(FOREACH_FORWARD, current_task->threads, &it_threads)
    {
      ((t_thread *)ITERATOR_ADDR(&it_threads))->sched = STATUS_WAIT;
      //Envoie message au kernel ki va stopper l'exec
    }

  if (wait)
    *wait = current_task->wait;

  return 0;
}

/*!
** Fill task with the addess of the task structure tskid
*/
int		task_get(t_tskid tskid, t_task** task)
{
  t_iterator	it_task;

  /*  printf("On est dans task_get\n"); */
  if (set_get(tasks, tskid, &it_task))
    {
      if (tskid == 1)
	{
	  /* printf ("task get return le kern\n"); */
	  *task = &ktask;
	 /*  while (1); */
	  return 0;
	}
      /* printf("set_get a 1\n"); */
      /* while (1); */
      return 1;
    }
  /*   printf("set_get est cool\n"); */
  /*   while (1); */
  *task = ITERATOR_ADDR(&it_task);

  return 0;
}

int	task_wakeup_thread_msg(t_tskid tskid, t_tskid src)
{
  t_thread	*thr;
  t_task	*tsk;
  t_iterator	it_threads;
/*   int		i = 0; */

/*   if (src == 5) */
/*     printf("msg venant du keyb vers %d\n", tskid); */
/*   if (tskid == 4) */
/*     printf("msg pour le server de test venant de %d\n", src); */
  if (task_get(tskid,&tsk))
    return -1;

  SET_FOREACH(FOREACH_FORWARD, tsk->threads, &it_threads)
    {

      thread_get(ITERATOR_ID(&it_threads), &thr);
      if (thr->sched == STATUS_MSG)
	{
/* 	  printf("         task wake up thread de la tache %d par un msg venant de %d\n", */
/* 		 tskid, src); */
/* 	  for (i = 0; i < 10000000; i++) */
/* 	    ; */
	/*   while (1); */
	  thread_run(ITERATOR_ID(&it_threads));
	  return 0;
	}
      if ((thr->sched == STATUS_MSG_FROM) &&
	  (src == thr->wait_from_tskid))
	{
/* 	  printf("          task wake up thread from de la tache %d par un msg venant de %d\n", */
/* 		 tskid, src); */
/* 	  printf("          task wake up thread msg MSG FROM\n"); */
/* 	  while (1); */
	  thread_run(ITERATOR_ID(&it_threads));
	  return 0;
	}
    }
  return 0;
}

/*!
** Free the task structure tskid
*/
int		task_rel(t_tskid tskid)
{
  t_task	*searched_task;
  t_iterator	it_threads, it_wait, it_children;

  if (task_get(tskid, &searched_task))
    return 1;
  SET_FOREACH(FOREACH_FORWARD, searched_task->threads, &it_threads)
    thread_rel(ITERATOR_ID(&it_threads));
  SET_FOREACH(FOREACH_FORWARD, searched_task->children, &it_children)
    task_rel(ITERATOR_ID(&it_children));
  if (searched_task->asid)
    as_rel(searched_task->asid);
  SET_FOREACH(FOREACH_BACKWARD, searched_task->waitlist, &it_wait)
    set_delete(searched_task->waitlist, ITERATOR_ID(&it_wait));
  set_delete(tasks, tskid);

  return 0;
}

/*!
** Clone a task, with its address space, modid, ...
*/
int		task_clone(t_tskid old, t_tskid *new)
{
  t_iterator	it_threads;
  t_task	*old_task = NULL;
  t_task	*new_task = NULL;
  t_thread	*tmp_thrd = NULL;
  t_thread	*new_thrd = NULL;
  t_thrid	new_thrid;

  if (task_get(old, &old_task))
    return 1;
  task_rsv(old_task->class, old_task->behav, old_task->prior,
	   new);
  if (task_get(*new, &new_task))
    return 1;

  new_task->ownid = old_task->ownid;
  /*   as_rsv(&(new_task->asid)); */
  as_clone(old_task->asid, &(new_task->asid));
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_thread), 0,
	  &(new_task->threads));
  SET_FOREACH(FOREACH_BACKWARD, old_task->threads, &it_threads)
    {
      tmp_thrd = ITERATOR_ADDR(&it_threads);
      thread_clone(tmp_thrd->thrid, &new_thrid);
      thread_get(new_thrid, &new_thrd);
      set_insert(new_task->threads, new_thrd);
    }
  new_task->class = old_task->class;
  new_task->behav = old_task->behav;
  new_task->prior = old_task->prior;

  return 0;
}

/*!
** Fill asid the asid of the as used by the task tskid
*/
int		task_asid(t_tskid tskid, t_asid *asid)
{
  t_task	*searched_task = NULL;

  if (task_get(tskid, &searched_task))
    {
      printf("task_asid return 1\n");
      return 1;
    }
  /*    printf("task_asid return 1\n"); */
  /*    if (tskid == 1) */
  /*      while (1); */
   *asid = searched_task->asid;

  return 0;
}

/*!
** Fill ownid the ownid of the task tskid
*/
int		task_ownid(t_tskid tskid, t_ownid *ownid)
{
  t_task	*searched_task = NULL;

  if (task_get(tskid, &searched_task))
    return 1;
  *ownid = searched_task->ownid;

  return 0;
}

/*!
** Change the owner of the task tskid
** @param	tskid	Identify the task to give
** @param	ownid	Identify the new owner
*/
int		task_give(t_tskid tskid, t_ownid ownid)
{
  t_iterator	it_threads;
  t_task	*searched_task = NULL;

  if (task_get(tskid, &searched_task))
    return 1;
  searched_task->ownid = ownid;
  SET_FOREACH(FOREACH_FORWARD, searched_task->threads, &it_threads)
    thread_give(ITERATOR_ID(&it_threads), ownid);

  return 0;
}

/*!
** Make the task tskid executable
*/
int		task_run(t_tskid tskid)
{
  t_iterator	it_threads;
  t_task	*searched_task = NULL;
  t_thrid	current_thrid;
  t_tskid	current_tskid;

  sched_thrid(&current_thrid);
  thread_tskid(current_thrid, &current_tskid);
  if (task_get(tskid, &searched_task))
    return 1;
  if (current_tskid != KASID && current_tskid != searched_task->ownid &&
      current_tskid != searched_task->tskid)
    return 1;
  if (!searched_task->asid || !searched_task->threads)
    return 1;
  searched_task->sched = STATUS_RUN;

  SET_FOREACH(FOREACH_FORWARD, searched_task->threads, &it_threads)
    thread_run(ITERATOR_ID(&it_threads));

  return 0;
}

/*!
** Stop the task tskid
*/
int		task_stop(t_tskid tskid)
{
  t_iterator	it_threads;
  t_task	*searched_task = NULL;
  t_thrid	current_thrid;
  t_tskid	current_tskid;

  sched_thrid(&current_thrid);
  thread_tskid(current_thrid, &current_tskid);
  if (task_get(tskid, &searched_task))
    return 1;
  if (current_tskid != 1 && current_tskid != searched_task->ownid &&
      current_tskid != searched_task->tskid)
    return 1;

  SET_FOREACH(FOREACH_FORWARD, searched_task->threads, &it_threads)
    thread_stop(ITERATOR_ID(&it_threads));
  searched_task->sched = STATUS_STOP;

  return 0;
}

/*!
** Allow to quit the task tskid
*/
int		task_exit(t_tskid tskid)
{
  t_task	*task = NULL;
  t_task	*wait_task = NULL;
  t_iterator	it_threads, it_wait;
  t_wait	wait;

  if (task_get(tskid, &task))
    return 1;

 /*             FIXME : IMPLEMENT SET_SIZE */

  /*   if (!set_size(task->waitlist)) */
  /*     { */
  /*       task->sched = STATUS_ZOMBIE; */
  /*       return 0; */
  /*     } */

  SET_FOREACH(FOREACH_FORWARD, task->threads, &it_threads)
    thread_exit(ITERATOR_ID(&it_threads));

  wait.u.tskid = tskid;
  wait.status = STATUS_EXITED;
  wait.value = 0;//FIXME : OU SE TROUVE T ELLE ? REGISTRE ? PILE ?

  SET_FOREACH(FOREACH_FORWARD, task->waitlist, &it_wait)
    {
      // EST CE AU KERNEL DE LE FAIRE ???
      task_get(ITERATOR_ID(&it_wait), &wait_task);
      wait_task->wait = wait;
      wait_task->sched = STATUS_RUN;
    }
  task_rel(tskid);

  return 0;
}

/*!
** Reinitialize the task manager
*/
int		task_clean(void)
{
  t_iterator	it_tasks;

  SET_FOREACH(FOREACH_FORWARD, tasks, &it_tasks)
    task_rel(ITERATOR_ID(&it_tasks));

  set_rel(tasks);

  return 0;
}

/*!
** Print on screen all informations about task tskid
*/
int		task_print(t_tskid tskid)
{
  t_task	*searched_task = NULL;

  if (task_get(tskid, &searched_task))
    return 1;
  printf("Task %d: \n\townid : %d\n\tasid : %d\n\tthreads : %d\n\t children : %d\n",
	 tskid, searched_task->ownid, searched_task->asid, searched_task->threads,
	 searched_task->children);
  printf("\tclass : %d\n\tbehav : %d\n\tprior : %d\n\tsched : %d\n",
	 searched_task->class, searched_task->behav, searched_task->prior,
	 searched_task->sched);

  return 0;
}
