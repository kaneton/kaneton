/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Sun Mar  6 02:40:18 2005 Castaing Antoine
** Last update Tue Mar 29 01:06:53 2005 Castaing Antoine
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef PIC_H_
# define PIC_H_
# include "../../include/kaneton/types.h"

int	pic_init(void);

int	pic_enable(t_event_id eventid);

int	pic_disable(t_event_id eventid);

int	pic_clear(void);

#endif
