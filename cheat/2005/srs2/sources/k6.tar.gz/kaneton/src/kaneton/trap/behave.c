/*
** Copyright (C) xebech aka Xebech <castai_a@epita.fr>
**
** Part of kaneton
**
** Started on  Thu Oct  6 23:17:00 2005 xebech
** Last update Sat Dec  3 21:04:06 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../include/kaneton/types.h"
#include "../../lib/console/console.h"
#include "../scheduler/scheduler.h"
#include "../thread/thread.h"
#include "../../lib/memory/as.h"
#include "../../lib/memory/vm.h"
#include "../../lib/memory/mm.h"
#include "../../bootloader/gdt_segments.h"
#include "../../bootloader/phys_mem_mapping.h"
#include "../../bootloader/ch_cr.h"
#include "../malloc/kmalloc.h"
#include "behave.h"
#include "../messages/messages.h"
#include "trap.h"

/* #define DEBUG_KERN_BEHAVE 1 */

typedef struct	s_cpu
{
  t_uint32	*ss;/*pt etre pas obligatoire*/
  t_uint32	*esp;
  t_uint32	*ebp;
  t_uint32	*eflags;
  t_uint32	*cs;
  t_uint32	*ds;
  t_uint32	*es;
  t_uint32	*fs;
  t_uint32	*eip;
  t_uint32	*edi;
  t_uint32	*esi;
  t_uint32	*eax;
  t_uint32	*ebx;
  t_uint32	*ecx;
  t_uint32	*edx;
}		t_cpu;


void	fill_arch_dep_cpu(t_cpu	*tmp,
			  unsigned int		*temp)
{

  temp -= 2;
  tmp->eax = temp;
  temp--;
  tmp->ecx = temp;
  temp--;
  tmp->edx = temp;
  temp--;
  tmp->ebx = temp;
}

void	behave_void(int a)
{
  t_thread		*thread = NULL;
  t_tskid		tskid;
  t_asid		asid;
  t_as			*as;

  a = a;
  if (thread_get(sched->thrid, &thread))
    return ;
  if (thread_tskid(sched->thrid, &tskid))
    return ;
  if (task_asid(tskid, &asid))
    return ;
  if (as_get(asid, &as))
    return ;
  set_pd_address((unsigned int)as->pd_addr);
}

void	behave_syscall(int a)
{
  t_thread		*thread = NULL;
  unsigned int		*temp = NULL;
  t_tskid		tskid;
  t_asid		asid;
  t_as			*as;
  t_cpu			tmp;
  int			tmp2;
  t_thrid               thrid;

  temp = (unsigned int *)((void *)sched->ebp_val);
  if (thread_get(sched->thrid, &thread))
    return ;
  if (thread_tskid(sched->thrid, &tskid))
    return ;
  if (task_asid(tskid, &asid))
    return ;
  if (as_get(asid, &as))
    return ;

  fill_arch_dep_cpu(&tmp, temp);

#ifdef DEBUG_KERN_BEHAVE
  printf ("thread est %d\n le tskid %d\nasid %d\n", sched->thrid, tskid, asid);
  printf("eax %x\nebx %x\necx %x\n", *(tmp.eax), *(tmp.ebx), *(tmp.ecx));
#endif

  switch (*(tmp.eax))
    {
    case BEHAVE_MALLOC:
      *(tmp.eax) = (t_vaddr)malloc(*(tmp.ebx),asid);
#ifdef DEBUG_KERN_BEHAVE
      printf("eax au retour est : %x\n", *(tmp.eax));
#endif
      break;

    case BEHAVE_GET_MSG:
      *(tmp.eax) = get_msg(tskid);
      break;

    case BEHAVE_SEND_MSG:
      send_msg((t_msg_hdr *)*(tmp.ebx), tskid);
      break;

    case BEHAVE_GET_MSG_FROM:
      *(tmp.eax) = get_msg_from(tskid, (t_tskid)(*(tmp.ebx)));
      break;

    case BEHAVE_WAIT_MSG:
      if ((tmp2 = wait_msg(sched->thrid)))
/* 	{ */
/* 	  printf("on change le eax de tskid %d et thrid %d\n", tskid, sched->thrid); */
	*(tmp.eax) = tmp2;
/* 	} */
/*       else */
/* 	printf("on change pas le eax de tskid %d et thrid %d\n", tskid, sched->thrid); */
      if (thread_get(sched->thrid, &thread))
	return ;
      if (thread_tskid(sched->thrid, &tskid))
	return ;
      if (task_asid(tskid, &asid))
	return ;
      if (as_get(asid, &as))
	return ;

/*       while (1); */
      break;

    case BEHAVE_WAIT_MSG_FROM:
 /*      printf(""); */
/*       printf("behave wait msg from %d\n", (t_tskid)(*(tmp.ebx))); */
      if ((tmp2 = wait_msg_from(sched->thrid, (t_tskid)(*(tmp.ebx)))))
/* 	{ */
/* 	  printf("on change le eax de tskid %d et thrid %d\n", tskid, sched->thrid); */
	  *(tmp.eax) = tmp2;
/* 	} */
/*       else */
/* 	  printf("on change pas le eax de tskid %d et thrid %d\n", tskid, sched->thrid); */
      if (thread_get(sched->thrid, &thread))
	return ;
      if (thread_tskid(sched->thrid, &tskid))
	return ;
      if (task_asid(tskid, &asid))
	return ;
      if (as_get(asid, &as))
	return ;
      break;

    case BEHAVE_CREATE_MSG:
      *(tmp.eax) = (unsigned int)create_msg(tskid, (t_tskid)*(tmp.ebx), (int)*(tmp.ecx));
      break;

    case BEHAVE_EXIT:
      thread->sched = STATUS_STOP;
      thrid = sched->thrid;
      my_sched_switch(thrid);
      sched_remove(thrid);
      if (thread_get(sched->thrid, &thread))
        return ;
      if (thread_tskid(sched->thrid, &tskid))
        return ;
      if (task_asid(tskid, &asid))
        return ;
      if (as_get(asid, &as))
        return ;
      break;

    case BEHAVE_FORK:
      //appel au fork (kernel side)
      break;

    case BEHAVE_SUBSCRIBE_TRAP:
      *(tmp.eax) = trap_subscribe((t_trapid)*(tmp.ebx), tskid);
      break;

    case BEHAVE_UNSUBSCRIBE_TRAP:
      *(tmp.eax) = trap_unsubscribe((t_trapid)*(tmp.ebx), tskid);
      break;

    default:
      printf("Pas bon appel systeme\n");
      break;
    }
#ifdef DEBUG_KERN_BEHAVE
  printf("sortie du syscall\n");
#endif
  a = a;
  set_pd_address((unsigned int)as->pd_addr);
}

void		behave_exception_debug(int a)
{
  t_thread		*thread = NULL;
  unsigned int		*temp = NULL;
  t_tskid		tskid;
  t_asid		asid;
  t_as			*as;
  t_cpu			tmp;

  temp = (unsigned int *)((void *)sched->ebp_val);
  if (thread_get(sched->thrid, &thread))
    return ;
  if (thread_tskid(sched->thrid, &tskid))
    return ;
  if (task_asid(tskid, &asid))
    return ;
  if (as_get(asid, &as))
    return ;

  fill_arch_dep_cpu(&tmp, temp);
  printf("                 exception no %d\n", a);
  printf("                 l exception est instervenu durant l exec de\n");
  printf("                 la tache %d et le thread %d\n", tskid, sched->thrid);
  printf("                 l eip etait %x et le cs %x\n", tmp.eip, tmp.cs);
  while (1);
}

void		behave_irq_exception(int a)
{
  t_iterator	it;
/*   extern t_trap	*tab_traps[256]; */
  t_msg_hdr	*msg_hd;
#ifdef DEBUG_KERN_BEHAVE
  printf("behave irq_exception %d\n", a);
#endif

  msg_hd = create_msg(1, 4, a)/*FIXME KTASKID (le 1 pas le 0 qui est un nb temp)*/;
#ifdef DEBUG_KERN_BEHAVE
  printf("avt FOR EACH behave\n");
#endif

/*   while (1); */
  SET_FOREACH(FOREACH_FORWARD, tab_traps[a]->lstid, &it)
    {
#ifdef DEBUG_KERN_BEHAVE
        printf("FOR EACH behave\n");
#endif
    /*     printf("FOR EACH behave envoie vers %d venant de %d\n", ITERATOR_ID(&it), a); */
/*       task_get(ITERATOR_ID(&it), &tsk); */
      msg_hd->dest = ITERATOR_ID(&it);
/*       printf("IRQ a destination de %i\n", ITERATOR_ID(&it)); */
      send_msg(msg_hd, 1)/*FIXME KTASKID*/;
    }
#ifdef DEBUG_KERN_BEHAVE
  printf("fin behave irq_exception %d\n", a);
#endif

}
#define DEBUG_KERN_MOD_BEHAVE
void	behave_mod_syscall(int a)
{
  t_thread		*thread = NULL;
  unsigned int		*temp = NULL;
  t_tskid		cur_tskid, tskid;
  t_as			*as, *new_as;
  t_cpu			tmp;
  t_paddr		paddr;
  t_vaddr		ventry, vaddr = 0;
  t_asid		asid;
  t_thrid		thrid;
  t_modid		modid;
  t_thrctx		thrctx;

  temp = (unsigned int *)((void *)sched->ebp_val);
  if (thread_get(sched->thrid, &thread))
    return ;
  if (thread_tskid(sched->thrid, &cur_tskid))
    return ;
  if (task_asid(cur_tskid, &asid))
    return ;
  if (as_get(asid, &as))
    return ;

  fill_arch_dep_cpu(&tmp, temp);

#ifdef DEBUG_KERN_BEHAVE
  printf ("thread est %d\n le tskid %d\nasid %d\n", sched->thrid, cur_tskid, asid);
  printf("eax %x\nebx %x\necx %x\n", *(tmp.eax), *(tmp.ebx), *(tmp.ecx));
#endif

  switch (*(tmp.eax))
    {
    case BEHAVE_VM_RSV:
      vm_rsv(*(tmp.ebx), &vaddr, *(tmp.ecx), *(tmp.edx));
      *(tmp.eax) = vaddr;
      break;
    case BEHAVE_VM_MAP:
       set_pd_address((unsigned int)as->pd_addr);
       paddr = ((unsigned int *)(*(tmp.ecx)))[0];
       vaddr = ((unsigned int *)(*(tmp.ecx)))[1];
       set_pd_address(PD_ENTRY);
       *(tmp.eax) = vm_map(*(tmp.ebx), paddr, vaddr, *(tmp.edx));
      break;
    case BEHAVE_MM_REL:
      *(tmp.eax) = mm_rel(*(tmp.ebx), *(tmp.ecx), *(tmp.edx));
      break;
    case BEHAVE_TASK_RSV:
      task_rsv(*(tmp.ebx), *(tmp.ecx), *(tmp.edx), &tskid);
      *(tmp.eax) = tskid;
      break;
    case BEHAVE_AS_RSV:
      as_rsv(&asid);
      if (as_get(asid, &new_as))
	return ;
      new_as->ownid = cur_tskid;
      *(tmp.eax) = asid;
      break;
    case BEHAVE_THREAD_RSV:
      thread_rsv(*(tmp.ebx), &thrid);
      *(tmp.eax) = thrid;
      break;
    case BEHAVE_AS_ATTACH:
      *(tmp.eax) = as_attach(*(tmp.ebx), *(tmp.ecx));
      break;
    case BEHAVE_THREAD_ATTACH:
      *(tmp.eax) = thread_attach(*(tmp.ebx), *(tmp.ecx));
      break;
    case BEHAVE_THREAD_STACK:
      *(tmp.eax) = thread_stack(*(tmp.ebx), *(tmp.ecx));
      break;
    case BEHAVE_THREAD_LOAD:
      set_pd_address((unsigned int)as->pd_addr);
      thrctx.sp = ((t_thrctx *)(*(tmp.ecx)))->sp;
      thrctx.pc = ((t_thrctx *)(*(tmp.ecx)))->pc;
      set_pd_address(PD_ENTRY);
      *(tmp.eax) = thread_load(*(tmp.ebx), &thrctx);
      break;
    case BEHAVE_THREAD_RUN:
      *(tmp.eax) = thread_run(*(tmp.ebx));
      break;
    case BEHAVE_THREAD_GET_STACK_ADDR:
      *(tmp.eax) = thread_get_stack_vaddr(*(tmp.ebx));
      break;
    case BEHAVE_AS_SET_MODID:
      *(tmp.eax) = as_set_modid(*(tmp.ebx), *(tmp.ecx));
      break;
    case BEHAVE_AS_GET_MODID:
      as_modid(*(tmp.ebx), &modid);
      *(tmp.eax) = modid;
      break;
    case BEHAVE_AS_GET_PD_PADDR:
      as_get_pd_paddr(*(tmp.ebx), &paddr);
      *(tmp.eax) = paddr;
      break;
    case BEHAVE_HE_GET_PARAM:
      set_pd_address((unsigned int)*(tmp.ebx));
      vaddr = *(t_vaddr *)(*(tmp.ecx) + *(tmp.edx));
      set_pd_address(PD_ENTRY);
      *(tmp.eax) = vaddr;
      break;
    case BEHAVE_AS_MODID_TASKID:
      *(tmp.eax) = as_modid_taskid(*(tmp.ebx));
      break;
    case BEHAVE_TASK_CREATE:
      task_rsv(CLASS_USER, BEHAV_TIMESHARING, PRIOR_TIMESHARING, &tskid);
      as_rsv(&asid);
      if (as_get(asid, &new_as))
	return ;
      new_as->ownid = cur_tskid;
      as_attach(asid, tskid);
      thread_rsv(PRIOR_TIMESHARING, &thrid);
      thread_attach(thrid, tskid);
      thread_stack(thrid, THREAD_STACKSZ);
      vm_rsv(asid, &vaddr, *(tmp.ebx), VM_FLAG_ANY);
      vm_map(asid, *(tmp.ecx), vaddr, *(tmp.ebx));
      as_set_modid(asid, *(tmp.edx));
      as_get_pd_paddr(asid, &paddr);
      set_pd_address(paddr);
      ventry = *(t_vaddr *)(vaddr + 0x18);
      set_pd_address(PD_ENTRY);
      thrctx.pc = ventry;
      thrctx.sp = thread_get_stack_vaddr(thrid) + PAGE_SIZE;
      thread_load(thrid, &thrctx);
      thread_run(thrid);
      /*
      ** The return values
      */
      *(tmp.eax) = tskid;
      /*       *(tmp.ebx) = asid; */
      /*       *(tmp.ecx) = thrid; */
      break;
    default:
      printf("Pas bon appel systeme %d\n", (unsigned int)*(tmp.eax));
      break;
    }
#ifdef DEBUG_KERN_BEHAVE
  printf("sortie du syscall\n");
#endif
  a = a;
  set_pd_address((unsigned int)as->pd_addr);
}
