/*
** Copyright (C) xebech aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Fri Sep 23 16:03:33 2005 xebech
** Last update Wed Oct 19 15:01:41 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef KANETON_TRAP_H_
# define KANETON_TRAP_H_

# include "../../include/kaneton/types.h"
# include "../../lib/set/set.h"
# include "behave.h"

# define TRAP_PL_USER 0
/*
** 1 user can (un)subscribe
** 2 user can read
** 4 user can post
*/
# define TRAP_PL_SERVICE 8
/*
** 8 service can (un)subscribe
** 16 service can read
** 32 service can post
*/
# define TRAP_PL_KERNEL 64
/*
** 68 kernel can (un)subscribe
** 128 kernel can read
** 256 kernel can post
*/

typedef void (*t_behave) (int);

typedef struct s_trap
{
/*   t_trapid trapid; */
  t_pl pl;
  t_behave behave;
  t_setid lstid;
}t_trap;

t_trap		**tab_traps;

int trap_init(void);

int trap_clean(void);

int trap_grade(t_trapid trapid, t_pl pl);

t_pl trap_pl(t_trapid trapid);

int trap_subscribe(t_trapid trapid, t_tskid tskid);

int trap_unsubscribe(t_trapid trapid, t_tskid tskid);

int trap_setbehave(t_trapid trapid, t_behave behave);

t_behave trap_getbehave(t_trapid trapid);

int trap_delbehave(t_trapid trapid);

#endif
