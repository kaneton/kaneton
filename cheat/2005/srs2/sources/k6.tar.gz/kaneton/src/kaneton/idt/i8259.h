/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Sun Mar  6 02:40:18 2005 Castaing Antoine
** Last update Sat Mar 19 11:09:01 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef I8259_H_
# define I8259_H_

/*
** 7	6	5	4	3	2	1	0
** 0	0	0	1	Trig	0	M/S	ICW4
**
** Trig :	0 -> Edge triggered
**		1 -> Level Triggered
**
** M/S  :	0 -> Master/Slave configuration
**		1 -> Master only
**
** ICW4 :	0 -> No ICW4
**		1 -> ICW4 will be send
*/
# define ICW1 0x11

/*
**  7		6  	5 	4  	3 	2  	1 	0
** A15/T7	A14/T6 	A13/T5 	A12/T4 	A11/T3 	A10 	A9 	A8
** Offset of the irq interruption for
** the master pic
*/
# define ICW2_MASTER	0x20
/*
**  7		6  	5 	4  	3 	2  	1 	0
** A15/T7	A14/T6 	A13/T5 	A12/T4 	A11/T3 	A10 	A9 	A8
** Offset of the irq interruption for
** the slave pic
*/
# define ICW2_SLAVE	0x28
/*
** 7 	6  	5 	4  	3 	2  	1 	0
** S7 	S6 	S5 	S4 	S3 	S2 	S1 	S0
** S7..S0 indicates that the specified interrupt request (IR)
** is connected to a slave.
** indique le no de l irq reliant le maitre a
** esclave (nous c le no 2)
*/
# define ICW3_MASTER 0x4
/*
** 7 	6  	5 	4  	3 	2  	1 	0
** 0 	0 	0 	0 	0 	ID2 	ID1 	ID0
** c'est le no d' irq du maitre avec lequel
** l esclave communique
*/
# define ICW3_SLAVE 0x2
/*
** 7 	6  	5 	4  	3 	2  	1 	0
** 0 	0 	0 	SFNM 	BUF 	M/S 	AEOI 	�PM
**
** Bits 7..5 must be set to 0.
** Setting SFNM selects the special fully nested mode
**     which is often used in large systems containing multiple cascaded
**     controllers to recognize mutliple levels of prioritized interrupts
**     on a slave controller.
** When BUF is set, the controller operates in buffered mode.
** When BUF is set, M/S can be used to select Buffered Master (M/S = 1)
**     or Buffered Slave (M/S = 0).
** Setting AEOI selects automatic end of interrupt mode whereby the controller
**     automatically performs an end of interrupt (EOI) operation on the
**     trailing edge of the last interrupt acknowledge pulse.
** Setting �PM indicates that the controller is operating in 8086/8088 mode.
**     Clearing �PM selects MCS-80/85 mode.
*/
# define ICW4 0x3
/*
** 7 	6  	5 	4  	3 	2  	1 	0
** M7 	M6 	M5 	M4 	M3 	M2 	M1 	M0
** M7..M0 control the mask bits for the associated interrupt line.
** Setting a bit enables the mask and inhibits the specified interrupt.
**
** Il est possible d' avoir le masque d' irq en lisant sur le port B le
** OCW1
*/
/*
** On met FB car on veut que le pic maitre et escalce continue de communiquer
** Mais on interdis tte autres interruption materielle
*/
# define INIT_OCW1_MASTER 0xFB
# define INIT_OCW1_SLAVE 0xFF
# define PIC1 0x20
# define PIC2 0xA0

#define disable_IRQ() \
  asm("cli\n")

#define enable_IRQ() \
  asm("sti\n")

# include "../../include/kaneton/types.h"

int	i8259_pic_init(void);

int	i8259_pic_enable(t_event_id eventid);

int	i8259_pic_disable(t_event_id eventid);

int	i8259_pic_clear(void);

#endif


