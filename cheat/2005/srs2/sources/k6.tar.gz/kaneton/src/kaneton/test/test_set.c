/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Thu Oct 20 18:00:20 2005 Damien Laniel
** Last update Thu Oct 20 19:39:27 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../lib/set/set.h"
# include "../../lib/console/console.h"

t_setid	setid;

void		test_set(void)
{
  int		i = 2;
  int		j = 4;
  int		k = 7;
  int		l = 11;
  t_iterator	it;

  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(int), 0, &setid);
  set_insert(setid, &i);
  set_insert(setid, &j);
  set_insert(setid, &k);
  set_delete(setid, j);
  set_insert(setid, &l);

  printf("All set elements :\n");
  SET_FOREACH(FOREACH_FORWARD, setid, &it)
    printf("- %d\n", *(int *)(it.addr));

  set_get(setid, k, &it);
  printf("\nFind one set element : %d\n", *((int *)it.addr));
}
