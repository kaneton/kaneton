/*
** Copyright (C) xebech aka Xebech <castai_a@epita.fr>
**
** Part of Asos
**
** Started on  Sun Sep 25 14:56:45 2005 xebech
** Last update Wed Nov 16 17:04:58 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../../lib/set/set.h"
#include "../../lib/console/console.h"
#include "../../include/kaneton/types.h"
#include "../malloc/kmalloc.h"
#include "trap.h"
#include "behave.h"

/* t_trap		*tab_traps[256]; */

int		trap_init(void)
{
  int		i = 0;
  t_trap	*tmp = 0;

/*   printf("TRAP DEBUTE\n"); */

  tab_traps = (t_trap **)malloc(sizeof(t_trap *) * 256, KASID);

   for (i = 1; i < 256; i++)
     {
       if (i < 32)
	 {
	   tmp = (t_trap *)malloc(sizeof(t_trap), KASID);
/* 	   printf("L @ de la 1 ere trap alloue est %x\n", tmp); */
	   tmp->pl = 0;
	   tmp->behave = behave_exception_debug;
	   if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_tskid), 0, &(tmp->lstid)))
	       return 1;
	   tab_traps[i] = tmp;
	 }
       else
	 if (i < 48)
	   {
	     tmp = (t_trap *)malloc(sizeof(t_trap), KASID);
	     /* 	   printf("L @ de la 1 ere trap alloue est %x\n", tmp); */
	     tmp->pl = 0;
	     tmp->behave = behave_irq_exception;
	   if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_tskid), 0, &(tmp->lstid)))
	     return 1;
	   tab_traps[i] = tmp;
	   /* 	   printf("L'A du tableau est %x\n", tab_traps); */
	   }
	 else
	   if (i == 48)
	     {
	       tmp = (t_trap *)malloc(sizeof(t_trap), KASID);
	       tmp->pl = 0;
	       tmp->behave = behave_syscall;
	       if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_tskid), 0, &(tmp->lstid)))
		 return 1;
	       tab_traps[i] = tmp;
	     }
	   else
	     {
	       if (i == 49)
		 {
		   tmp = (t_trap *)malloc(sizeof(t_trap), KASID);
		   tmp->pl = 0;
		   tmp->behave = behave_mod_syscall;
		   if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_tskid), 0, &(tmp->lstid)))
		     return 1;
		   tab_traps[i] = tmp;
		 }
	       else
		 {
		   tmp = (t_trap *)malloc(sizeof(t_trap), KASID);
		   tmp->pl = 0;
		   tmp->behave = behave_void;
		   if (set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_tskid), 0, &(tmp->lstid)))
		     return 1;
		   tab_traps[i] = tmp;
		 }
	     }
     }

   return 0;
}

int trap_clean(void)
{
  int		i = 0;

   for (i = 0; i < 256; i++)
     {
       /* ICI il fo vide les set :) */
       set_rel(tab_traps[i]->lstid);
       free(tab_traps[i]);
     }
   return 0;
}

int trap_grade(t_trapid trapid,
	       t_pl pl)
{
  /*ICI fo tester les droit pour pouvoir les changer*/
  tab_traps[trapid]->pl = pl;
  return 0;
}

t_pl trap_pl(t_trapid trapid)
{
  return tab_traps[trapid]->pl;
}

int trap_subscribe(t_trapid trapid,
		   t_tskid tskid)
{
  t_tskid *tmp_tsk = malloc(sizeof(t_tskid), KASID);
  *tmp_tsk = tskid;
  /*ICI tester les droit pour souscrire*/
  set_insert(tab_traps[trapid]->lstid, tmp_tsk);
  return 0;
}

int trap_unsubscribe(t_trapid trapid,
		     t_tskid tskid)
{
  /*ICI tester les droit pour desinscrire*/
  set_delete(tab_traps[trapid]->lstid, tskid);
  return 0;
}

int trap_setbehave(t_trapid trapid,
		   t_behave behave)
{
  /*ICI tester les droit pour changer le fonctionnement*/
 tab_traps[trapid]->behave = behave;
 return 0;
}

t_behave trap_getbehave(t_trapid trapid)
{
  /*ICI tester les droit pour avoir acces au fonctionnement*/
  return tab_traps[trapid]->behave;
}

int trap_delbehave(t_trapid trapid)
{
  /*ICI tester les droit pour supp le fonctionnement*/
  tab_traps[trapid]->behave = NULL;
  return 0;

}
