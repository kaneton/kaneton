/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:39:52 2005 Castaing Antoine
** Last update Mon Nov 14 22:22:15 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "timer.h"
#include "../../../include/kaneton/ioports.h"
#include "../../../lib/console/console.h"
#include "../../../lib/shell/parse_cmd.h"
#include "../../scheduler/scheduler.h"

unsigned long int	tick_count;

void	time(char *arg[NB_MAX_ARG], int nb_arg)
{
  nb_arg = 0;
  arg[0] = 0;
  // _time time;
  unsigned long heure0;
  unsigned long heure1;
  unsigned long heure2;
  unsigned long heure3;
  unsigned long heure4;

  //  heure0 = inb(Ox40);
  heure1 = inb(0x41)<< 8;
  heure2 = inb(0x42)<< 8;
  heure3 = inb(0x43)<< 8;
  heure4 = inb(0x44)<< 8;
  heure0 = inb(0x40) << 8;


  // ttys[0].addr++;
  printf("test heure0 %d ", heure0);
  printf("test heure1 %d ", heure1);
  printf("test heure2 %d ", heure2);
  printf("test heure3 %d ", heure3);
  printf("test heure4 %d\n", heure4);
  printf("NB DE TIC : <%d>\n", tick_count);
}


/*
** Initialize the timer
*/
void	timer_init(void)
{
  /* Set the timer chip I8254 to mode 2 for a rate generator, that is it sends a periodic signal */
  outb(I8254_CONTROL_MODE2, I8254_CONTROL);
 /* Send LSB of counter */
  outb(I8254_LSB, I8254_TIMER0);
  /* Send MSB of counter */
  outb(I8254_MSB, I8254_TIMER0);

  tick_count = 0;
/*   printf("tick count init : %d", tick_count); */
}

/*
** Timer tick handler
*/
void	timer_tick(int a)
{
/*   unsigned int test = (unsigned int)*(int *)sched->esp_val; */

  a = a;
/*   asm("cli\n"); */
/*   ttys[0].addr++; */

/*   a =b; */

  /* if (!sched->thrid) */
/*     printf("Je continue a recevoir des tick\n"); */
  if (!sched->tick)
    {
   /*    cons_clear_screen(); */
/*       printf("SUPER THRID <%d>\n", sched->thrid); */
/*       while (1); */
      sched_switch(sched->thrid);
    }
  sched->tick--;
  tick_count++;
 /*  outb(0x20,0x20); */
/*   outb(0x20,0xA0); */
  if (tick_count == NB_TICK)
    tick_count = 0;

/*       cons_clear_screen(); */
/*       printf ("Nous sommes Tick\n"); */
/*       printf ("esp est <%x>\n",sched->esp_val); */


/*   if (sched->tick == sched->quantum ) */
/*   asm("sti\n"); */
  /*  printf("tick count : %d", tick_count); */
}
