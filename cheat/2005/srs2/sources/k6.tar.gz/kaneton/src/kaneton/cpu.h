#ifndef CPU_H_
# define CPU_H_

#include "../include/kaneton/types.h"



typedef t_vaddr	t_pc;
typedef t_vaddr	t_sp;

typedef struct	s_arch_dep_cpu
{
  t_uint32	ss;/*pt etre pas obligatoire*/
  t_uint32	esp;
  t_uint32	ebp;
  t_uint32	eflags;
  t_uint32	cs;
  t_uint32	ds;
  t_uint32	es;
  t_uint32	fs;
  t_uint32	eip;
  t_uint32	edi;
  t_uint32	esi;
  t_uint32	eax;
  t_uint32	ebx;
  t_uint32	ecx;
  t_uint32	edx;
}		t_arch_dep_cpu;


typedef struct	s_thrctx
{
  t_pc		pc;
  t_sp		sp;
}		t_thrctx;

#endif
