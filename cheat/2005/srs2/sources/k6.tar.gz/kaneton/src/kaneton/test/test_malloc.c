#include "test.h"

void	test_malloc(void)
{
#ifdef DEBUG_LIBC
  char			**test = NULL;
  t_asid		as = 1;
  int			i = 0;


  *test = malloc(sizeof(char *) * 10, as);
  for (i = 0; i < 10; i++)
    {
/*       printf("\nALLOC %d de taill %d\n", i, i*200 + 1); */
      test[i] = malloc(i*200 + 1, as);
    }
  printf("\n\n############# FREE #############\n");
  free(test[0]);
  free(test[1]);
  test[0] = malloc(200, as);
  test[1] = malloc(1, as);
  free(test[9]);
  free(test[8]);
  free(test[7]);
/*   init_malloc(); */

/*   printf("1 : TENTATIVE D ALLOC de 8\n"); */
/*   test = (char *)malloc(8, as); */
/*   printf("1 : ADD ALLOUE EST <%x>\n\n", test); */
/*   for (i = 0; i < 8; i++) */
/*     test[i] = 0; */

/*   printf("2 : TENTATIVE D ALLOC de 20\n"); */
/*   test = (char *)malloc(20, as); */
/*   printf("2 : ADD ALLOUE EST <%x>\n\n", test); */
/*   for (i = 0; i < 20; i++) */
/*     test[i] = 0; */

/*   printf("3 : TENTATIVE D ALLOC de 4096\n"); */
/*   test = (char *)malloc(4096, as); */
/*   printf("3 : ADD ALLOUE EST <%x>\n\n", test); */
/*   for (i = 0; i < 4096; i++) */
/*     test[i] = 0; */

/*   printf("4 : TENTATIVE D ALLOC de 1000\n"); */
/*   test = (char *)malloc(1000, as); */
/*   printf("4 : ADD ALLOUE EST <%x>\n\n", test); */
/*   for (i = 0; i < 1000; i++) */
/*     test[i] = 0; */

/*   printf("5 : TENTATIVE D ALLOC de 1096\n"); */
/*   test = (char *)malloc(1096, as); */
/*   printf("5 : ADD ALLOUE EST <%x>\n\n", test); */
/*   for (i = 0; i < 1096; i++) */
/*     test[i] = 0; */

/*   printf("6 : TENTATIVE D ALLOC de 1896\n"); */
/*   test = (char *)malloc (1896, as); */
/*   printf("6 : ADD ALLOUE EST <%x>\n\n", test); */
/*   for (i = 0; i < 1896; i++) */
/*     test[i] = 0; */

/*   printf("7 : TENTATIVE D ALLOC de 1896\n"); */
/*   test1 = (char *)malloc (1896, as); */
/*   printf("7 : ADD ALLOUE EST <%x>\n\n", test1); */
/*   for (i = 0; i < 1896; i++) */
/*     test1[i] = 0; */

/*   printf("8 : TENTATIVE D ALLOC de 1896\n"); */
/*   test = (char *)malloc (1896, as); */
/*   printf("8 : ADD ALLOUE EST <%x>\n\n", test); */
/*   for (i = 0; i < 1896; i++) */
/*     test[i] = 0; */

/*   printf("########## FREE ############\n"); */
/*   free(test1); */
/*   free(test); */
/*   printf("########## FIN FREE ############\n\n"); */

/*   printf("9 : TENTATIVE D ALLOC de 1896\n"); */
/*   test = (char *)malloc (1896, as); */
/*   printf("9 : ADD ALLOUE EST <%x>\n\n", test); */
/*   for (i = 0; i < 1896; i++) */
/*     test[i] = 0; */
#endif
}
