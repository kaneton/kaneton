/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Mar  4 11:33:03 2005 Castaing Antoine
** Last update Fri Mar 18 00:41:56 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef EXCEPTION_H_
# define EXCEPTION_H_

# include "../../include/kaneton/types.h"
# include "exception_hh.h"
# include "idt.h"
/*
** this is the list of exception throw by the processor
 */
# define DIVIDE_ERROR                       0
# define DEBUG                              1
# define NMI_INTERRUPT                      2
# define BREAKPOINT                         3
# define OVERFLOW                           4
# define BOUND_RANGE_EXCEDEED               5
# define INVALID_OPCODE                     6
# define DEVICE_NOT_AVAILABLE               7
# define DOUBLE_FAULT                       8
# define COPROCESSOR_SEGMENT_OVERRUN        9
# define INVALID_TSS                       10
# define SEGMENT_NOT_PRESENT               11
# define STACK_SEGMENT_FAULT               12
# define GENERAL_PROTECTION                13
# define PAGE_FAULT                        14
# define INTEL_RESERVED_1                  15
# define FLOATING_POINT_ERROR              16
# define ALIGNEMENT_CHECK                  17
# define MACHINE_CHECK                     18
# define INTEL_RESERVED_2                  19
# define INTEL_RESERVED_3                  20
# define INTEL_RESERVED_4                  21
# define INTEL_RESERVED_5                  22
# define INTEL_RESERVED_6                  23
# define INTEL_RESERVED_7                  24
# define INTEL_RESERVED_8                  25
# define INTEL_RESERVED_9                  26
# define INTEL_RESERVED_10                 27
# define INTEL_RESERVED_11                 28
# define INTEL_RESERVED_12                 29
# define INTEL_RESERVED_13                 30
# define INTEL_RESERVED_14                 31

/*
** Some error can be return by the function of exception
** - The number of the exception is too big or is the double fault
**
*/


typedef void (*exception_handler_t)(int exception_number);

typedef void (*exception_wrapper_t)();

/*
** On pourra mettre un int pour savoir si erreur
** d ailleurs reflechir a politique d erreur
*/

int exception_init(void);

int exception_set_routine(int exception_number,
			  exception_handler_t routine);

int exception_rm_routine(int except_no);

exception_handler_t exception_get_routine(int exception_number);

#endif
