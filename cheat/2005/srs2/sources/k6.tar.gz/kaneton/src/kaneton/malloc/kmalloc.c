/*
** Copyright (C) xebech aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Fri Oct  7 17:21:29 2005 xebech
** Last update Fri Nov 11 00:59:13 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "kmalloc.h"
#include "../../lib/memory/mm.h"
#include "../../lib/memory/as.h"
#include "../../lib/console/console.h"
#include "../../bootloader/ch_cr.h"
#include "../../bootloader/phys_mem_mapping.h"

/* #define DEBUG_LIBC  */

static int	find_nb_page(int size)
{
  int	nb_page = (size + sizeof (struct little_chunck) +
		   sizeof (struct big_chunck)) / 4096;
  if ((size + sizeof (struct little_chunck) +
       sizeof (struct big_chunck)) % 4096)
    nb_page++;
  return nb_page;
}



int	find_prev_little(unsigned int		size,
			 struct big_chunck	*big,
			 struct little_chunck	**little)
{
  struct little_chunck	*tmp = (struct little_chunck *)((void *)big + sizeof (struct big_chunck));
  struct little_chunck	*tmp2 = 0;
  int			lost_size = 0;


  while (tmp && tmp->next && (big->free - lost_size > size))
    {
      if (!tmp->used)
	{
	  if (tmp->size > size)
	    {
	      if (tmp->size > size + sizeof (struct little_chunck) + 1)
		{
#ifdef DEBUG_LIBC
		  printf("je decoupe en deux le chunk trop gros\n");
#endif
		  tmp2 = (void *)tmp + sizeof (struct little_chunck) + size;
		  tmp2->used = 0;
		  tmp2->size = tmp->size - sizeof (struct little_chunck) - size;
		  tmp2->prev = tmp;
		  tmp2->next = tmp->next;
		  tmp->next = tmp2;
		  tmp->size = size;
		  big->free -= sizeof (struct little_chunck);
		}
	      big->free -= tmp->size;
	      tmp->used = 1;
	      *little = tmp;
#ifdef DEBUG_LIBC
	  printf("Little de taille %d devrait avoir l @ %x\n",
		 tmp->size, *little);
#endif
	  return 1;
	    }
	  else
	    lost_size += tmp->size;
	}
      tmp = tmp->next;
    }

  if (big->free - lost_size - tmp->size < size)
      return 0;

  if (!tmp->next)
    {
#ifdef DEBUG_LIBC
      printf("Creation d'un little chunk a la suite de celui a l'@ %x\n",
	     tmp);
#endif
      *little = tmp;
      return 1;
    }
  return 0;
}



/*
** Cette fonction cherche un big chunck qui
** puisse contenir size
*/
static struct big_chunck	*find_chunck_not_full(unsigned int		size,
						      struct little_chunck	**little,
						      struct big_chunck		*l_malloc)
{
  struct big_chunck		*res = l_malloc;


  while (res)
    {
      if (res->free > size + sizeof (struct little_chunck))
	{
/* 	  if (toto) */
/* 	    { */
/* 	      printf("J'ai trouve un big chunk ayant un free suffisant\n"); */
/* 	      printf("son free est %d et la taille demande est %d\n", */
/* 		     res->free, size); */
/* 	    } */
#ifdef DEBUG_LIBC
	  printf("J'ai trouve un big chunk ayant un free suffisant\n");
	  printf("son free est %d et la taille demande est %d\n",
		 res->free, size);
#endif
	  if (find_prev_little(size, res, little))
	    return res;
	  /*
	  ** METTRE 2 AUTRES CAS :
	  ** - PAS DE RES DU TT, FO CONTINUER LE PARCOURS
	  ** - ON A PAS TROUVE DE CHUNK LIBRE MS Y A DE LA PLACE A LA FIN
	  */
	}
      res = res->next;
    }
#ifdef DEBUG_LIBC
  printf("Je n'ai pas trouve de big chunk ayant un free suffisant\n");
#endif
  return res;
}

void	init_malloc()
{
}



struct big_chunck	*find_last_big(struct big_chunck		*l_malloc)
{
  struct big_chunck	*res = l_malloc;

  while (res && res->next)
    res = res->next;
  return res;
}

/*
** Cette fonction retrouve le big chunck de l'addr
** ainsi que le precedent de ce chunk.
** Il retourne NULL si il n y a pas de chunk qui couvre
** cette partie de la memoire
*/
 struct big_chunck	*find_big_and_prev(void			*addr,
					   struct big_chunck	**prev,
					   struct big_chunck	*l_malloc)
{
  struct big_chunck	*res = NULL;

  *prev = NULL;
  if (!l_malloc)
    return NULL;
  res = l_malloc;
  if ((addr > (void *)res) && (addr < (void *)res + res->nb_page * 4096))
    return res;
  if (res->next && (addr > (void *)res->next) &&
      (addr < (void *)res->next + res->next->nb_page))
    {
#ifdef DEBUG_LIBC
      printf("Le big chunk est trouve %x\n",
	     res->next);
#endif
      *prev = res;
      return res->next;
    }
  while (res->next->next)
    {
      if ((addr > (void *)res->next) &&
	  (addr < (void *)res->next + res->next->nb_page * 4096))
	{
	  *prev = res;
#ifdef DEBUG_LIBC
	  printf("Le big chunk est trouve %x\n",
		 res->next);
#endif
	  return res->next;
	}
      res = res->next;
    }
  if ((addr > (void *)res->next) &&
      (addr < (void *)res->next + res->next->nb_page* 4096))
    {
      *prev = res;
#ifdef DEBUG_LIBC
      printf("Le big chunk est trouve %x\n",
	     res->next);
#endif
      return res->next;
    }
#ifdef DEBUG_LIBC
  printf("Pas de big chunk trouve\n");
#endif
  return NULL;
  /*  while (res->next && ((addr < (void *)res->next) ||
	 (addr > (void *)res->next + res->next->nb_page)))
    {
#ifdef DEBUG_LIBC
      printf("find_big_prev l @ est %x et le chunk est %x\n",
	     addr, res->next);
#endif
    res = res->next;
    }
  if (!res->next&& ((addr < (void *)res) ||
		    (addr > (void *)res + res->nb_page)))
    return NULL;
  else
    if (!res->next)
      return res;
  *prev = res;
  res = res->next;*/

  return res;
}
/*
** Cette fonction fusionne le chunk passe en arg
** et son suivant
*/
void	fusion(struct little_chunck *first)
{
  struct little_chunck *second = first->next;

#ifdef DEBUG_LIBC
  printf("FUSION\n");
  printf("le premier avait une taille de %d a l @ %x\n",
	 first->size, first);
  printf("le second  avait une taille de %d a l @ %x\n",
	 second->size, second);

#endif

  first->size += sizeof (struct little_chunck) + second->size;
#ifdef DEBUG_LIBC
  printf("Cela donne donc une taille de %d a l @ %x\n",
	 first->size, first);
#endif
  first->next = second->next;
  first->next->prev = first;
}

void		free(void *addr)
{
  struct little_chunck	*little = (struct little_chunck *)(addr - sizeof (struct little_chunck));
  struct big_chunck	*big = NULL;
  struct big_chunck	*prev_big = NULL;
  struct big_chunck	*l_malloc = NULL;

  if (!(big = find_big_and_prev(addr, &prev_big, l_malloc)))
      return;
#ifdef DEBUG_LIBC
  printf("Free : Le pointeur <%x> est trouve et son chunk <%x>\n",
	 addr, little);
#endif
  little->used = 0;
  if (!little->prev && !little->next)
    {
#ifdef DEBUG_LIBC
      printf("Free : Pas de chunk precedent ni suivant\n");
      printf("Free : dc suppression du big chunk\n");
#endif
      if (prev_big)
	prev_big->next = big->next;
      else
	l_malloc = big->next;
      mm_rel(little->asid, (t_vaddr)big, big->nb_page);
      return;
    }
  if (little->prev && !little->prev->used)
    {
#ifdef DEBUG_LIBC
      printf("Free : fusion avec le precedent\n");
#endif
      fusion(little->prev);
    }
  if (little->next &&!little->next->used)
    {
#ifdef DEBUG_LIBC
      printf("Free : fusion avec le suivant\n");
#endif
      fusion(little);
    }
  if (!little->next)
    little->prev->next = NULL;
  big->free += little->size;
}


void			*malloc(unsigned int size,
				t_asid asid)
{
  int			nb_pages = 0;
  t_vaddr		addr = 0;
  t_as			*as;
  /*
  ** big_tmp est utilise :
  ** soit pour le nouvo chunck
  ** soit pour recup un chunck non plein
  */
  struct big_chunck	*big_tmp = 0;

  struct big_chunck	*l_malloc = 0;


  /*
  ** little_tmp est utilise pour stocker le nouvo chunk
   */
  struct little_chunck	*little_tmp = 0;
  /*
  **
  */
  struct little_chunck	*little = 0;
  /*
  ** pareil pour big_tmp, utilise seulement pour creer un nouvo big chunk
  */
  struct big_chunck	*big_prev = 0;


#ifdef DEBUG_LIBC
  printf("taille d'un big chunk %d et d un little %d\n",
	 sizeof (struct big_chunck),
	 sizeof (struct little_chunck));
#endif

  if (!size)
    return NULL;

  /*   if (asid == 2) */
  /*     printf("Debut malloc\n"); */

  as_get(asid,&as);
  l_malloc = (struct big_chunck *)as->l_malloc;

  /*   if (asid == 2) */
  /*     printf("l_malloc : %x\n", l_malloc); */

  /*On passe en USER*/
  set_pd_address(as->pd_addr);
 /* CAS OU IL FO CREER UN NOUVO BIG CHUNCK */
  if (!(big_tmp = find_chunck_not_full(size, &little, l_malloc)))
    {
      /*       if (asid == 2) */
      /* 	printf("Creation nouveau big chunk\n"); */
      nb_pages = find_nb_page(size);

      /*On passe en kern pour le mm_rsv*/
      set_pd_address(PD_ENTRY);
      mm_rsv(asid, &addr, nb_pages);
      set_pd_address(as->pd_addr);

#ifdef DEBUG_LIBC
      printf("MALLOC BC ASID %d SIZE %d NB_PAGES %d ADDR %x\n", asid, size, nb_pages, addr);
#endif

      big_tmp = (struct big_chunck *)addr;
      big_tmp->nb_page = nb_pages;
      big_tmp->free = nb_pages * 4096 - sizeof (struct big_chunck)
	- sizeof (struct little_chunck) - size;
      big_tmp->next = 0;
      if ((big_prev = find_last_big(l_malloc)))
	big_prev->next = big_tmp;
      else
	{
	  l_malloc = big_tmp;
	   set_pd_address(PD_ENTRY);
	   as->l_malloc = (t_vaddr)l_malloc;
	   set_pd_address(as->pd_addr);
	}
      little_tmp = (struct little_chunck *)(addr + sizeof (struct big_chunck));
      little_tmp->prev = NULL;
      little_tmp->next = NULL;
#ifdef DEBUG_LIBC
      printf("\nmalloc-> NEW LITTLE CHUNCK\n");
      printf("l adresse du nouvo little chunk est <%x>\n", (void *)little_tmp);
#endif
    }
  else
    {
/* #ifdef DEBUG_LIBC */
/*       if (asid == 2) */
/* 	printf("Pas besoin de big chunk, little a l addr %x\n",(void *)little); */
/* #endif */
      if (!little->next)
	{
	  little_tmp = (struct little_chunck *)((void *)little +
						sizeof (struct little_chunck) +
						little->size);
	  little->next = little_tmp;
	  little_tmp->prev = little;
	  little_tmp->next = NULL;

	  big_tmp->free = big_tmp->free - size - sizeof (struct little_chunck);
/* #ifdef DEBUG_LIBC */
/* 	  if (asid == 2) */
/* 	    { */
/* 	      printf("\nmalloc-> NEW LITTLE CHUNCK\n"); */
/* 	      printf("l adresse du nouvo little chunck est <%x>\n", little_tmp); */
/* 	    } */
/* #endif */
	}
      else
	{
	  little_tmp = little;
	  big_tmp->free = big_tmp->free - size;
	}
    }
  little_tmp->size = size;
  little_tmp->asid = asid;
  little_tmp->used = 1;
/* #ifdef DEBUG_LIBC */
/*   if (asid == 2) */
/*     printf("\nle little chunk a une taille de %d et un asid %d size : %x\n", */
/* 	   little_tmp->size, little_tmp->asid, (void *)little_tmp + sizeof(struct little_chunck)); */
/* #endif */
  set_pd_address(PD_ENTRY);
  /*   if (asid == 2) */
  /*     for (i = 0; i != 5000000; i++) */
  /* 	; */
  return (void *)((void *)little_tmp + sizeof(struct little_chunck));
}
