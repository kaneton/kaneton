/*
** Copyright (C) Laurent Decool aka traktopel <laurent.decool@gmail.com>
**
** Part of Kaneton
**
** Started on  Wed Oct  5 14:49:25 2005 Laurent Decool
** Last update Wed Oct  5 15:12:36 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "keys.h"
#include "../../../include/kaneton/types.h"
#include "../../../lib/console/console.h"
#include "../../../include/kaneton/ioports.h"
#include "../../../lib/shell/parse_cmd.h"
#include "../../../lib/shell/print_fct.h"
#include "../../../lib/shell/sh_clear.h"

#define PROMPT		"Kaneton_sh> "
#define SHOW_PROMPT	printf(PROMPT); mark_prompt();
#define SEND_COMMAND	parse_video_mem(ttys[current_tty].addr)

static int	kb_driver_nb_char_cmd = 0;

static char	standard_keys[58][2] =
  {
    {   0,0   } ,	/*0*/
    {   0,0   } ,	/*1*/
    { '1','!' } ,	/*2*/
    { '2','@' } ,	/*3*/
    { '3','#' } ,	/*4*/
    { '4','$' } ,	/*5*/
    { '5','%' } ,	/*6*/
    { '6','^' } ,	/*7*/
    { '7','&' } ,	/*8*/
    { '8','*' } ,	/*9*/
    { '9','(' } ,	/*10*/
    { '0',')' } ,	/*11*/
    { '-','_' } ,	/*12*/
    { '=','+' } ,	/*13*/
    {8,8} ,		/*14*/
    { '\t','\t'},	/*15*/
    { 'q','Q' } ,	/*16*/
    { 'w','W' } ,	/*17*/
    { 'e','E' } ,	/*18*/
    { 'r','R' } ,	/*19*/
    { 't','T' } ,	/*20*/
    { 'y','Y' } ,	/*21*/
    { 'u','U' } ,	/*22*/
    { 'i','I' } ,	/*23*/
    { 'o','O' } ,	/*24*/
    { 'p','P' } ,	/*25*/
    { '[','{' } ,	/*26*/
    { ']','}' } ,	/*27*/
    {  13,13  } ,	/*28*/
    {   0,0   } ,	/*29*/
    { 'a','A' } ,	/*30*/
    { 's','S' } ,	/*31*/
    { 'd','D' } ,	/*32*/
    { 'f','F' } ,	/*33*/
    { 'g','G' } ,	/*34*/
    { 'h','H' } ,	/*35*/
    { 'j','J' } ,	/*36*/
    { 'k','K' } ,	/*37*/
    { 'l','L' } ,	/*38*/
    { ';',':' } ,	/*39*/
    {  39,34  } ,	/*40*/
    { '`','~' } ,	/*41*/
    {   0,0   } ,	/*42*/
    { '\\','|'} ,	/*43*/
    { 'z','Z' } ,	/*44*/
    { 'x','X' } ,	/*45*/
    { 'c','C' } ,	/*46*/
    { 'v','V' } ,	/*47*/
    { 'b','B' } ,	/*48*/
    { 'n','N' } ,	/*49*/
    { 'm','M' } ,	/*50*/
    { ',','<' } ,	/*51*/
    { '.','>' } ,	/*52*/
    { '/','?' } ,	/*53*/
    {   0,0   } ,	/*54*/
    {   0,0   } ,	/*55*/
    {   0,0   } ,	/*56*/
    { ' ',' ' }	,	/*57*/
  };

/* static char	num_keys[] = */
/*   { */
/*     '7', */
/*     '8', */
/*     '9', */
/*     '-', */
/*     '4', */
/*     '5', */
/*     '6', */
/*     '+', */
/*     '1', */
/*     '2', */
/*     '3', */
/*     '0', */
/*     '.', */
/*     '\n' */
/*   }; */

/* static fct_key	direction_keys[] = */
/*   { */
/*     keyboard_home,		/\* 0xE0 0x47 *\/ */
/*     keyboard_haut,		/\* 0xE0 0x48 *\/ */
/*     keyboard_page_up,		/\* 0xE0 0x49 *\/ */
/*     keyboard_empty_func, */
/*     keyboard_gauche,		/\* 0xE0 0x4B *\/ */
/*     keyboard_empty_func, */
/*     keyboard_droite,		/\* 0xE0 0x4D *\/ */
/*     keyboard_empty_func, */
/*     keyboard_fin,		/\* 0xE0 0x4F *\/ */
/*     keyboard_bas,		/\* 0xE0 0x50 *\/ */
/*     keyboard_page_down,		/\* 0xE0 0x51 *\/ */
/*     keyboard_insert,		/\* 0xE0 0x52 *\/ */
/*     keyboard_suppr		/\* 0xE0 0x53 *\/ */
/*   }; */

char	kb_buffer[KEY_BUFF_SIZE][2];	/* Keys buffer with state (Shift/or not) */
t_uint8	start_buffer = 0;
t_uint8	end_buffer = 0;

struct s_keyboard	kb;

static void	load_leds(void)
{
  /* FIXME todo */
}

static void	capslock(void)
{
  if (kb.caps_lock == 1)
    kb.caps_lock = 0;
  else
    kb.caps_lock = 1;
  load_leds();
}

static void	numlock(void)
{
  if (kb.num_lock == 1)
    kb.num_lock = 0;
  else
    kb.num_lock = 1;
  load_leds();
}

static void	alt_key(void)
{
  if (kb.alt == 1)
    kb.alt = 0;
  else
    kb.alt = 1;
}

/*
** Check if the scancode is a standard key scancode or not
**
** @return	0 if it's a standard key,
**		2 if the action is done by the function itself,
**		1 otherwise
*/
static int	is_standard_key(char code)
{
  switch (code)
    {
    case 1:
      return 1;
      break;	/* ESCAPE */
    case 28:
      cons_print_char('\n');
      reinit_buff();
      SHOW_PROMPT;
      kb_driver_nb_char_cmd = 0;
      return 2;
      break;	/* ENTER */
    case 29:
      alt_key();
      return 1;
      break;	/* LEFT CONTROL  */
    case 42:
      capslock();
      return 2;
      break;	/* LEFT SHIFT  */
    case 54:
      capslock();
      return 2;
      break;	/* RIGHT SHIFT */
    case 56:
      alt_key();
      return 1;
      break;	/* LEFT ALT */
    case 58:
      capslock();
      return 2;
      break;	/* CAPSLOCK */
    case 59:
      print_idt();
      /*keyboard_f1();*/
      return 2;
      break;	/* F1 */
    case 60:
      print_gdt();
      /*  keyboard_f2(); */
      return 2;
      break;	/* F2 */
    case 61:
      switch_tty(2);
      /* keyboard_f3(); */
      return 2;
      break;	/* F3 */
    case 62:
      switch_tty(3);
      /* keyboard_f4(); */
      return 2;
      break;	/* F4 */
    case 63:
      hard_scrolling(-COLUMNS);
      return 2;
      break;	/* F5 */
    case 64:
      hard_scrolling(COLUMNS);
      return 2;
      break;	/* F6 */
    case 65:
      cons_clear_screen();
      SHOW_PROMPT;
      return 2;
      break;	/* F7 */
    case 66:
      keyboard_f8();
      return 2;
      break;	/* F8 */
    case 67:
      keyboard_f9();
      return 2;
      break;	/* F9 */
    case 68:
      keyboard_f10();
      return 2;
      break;	/* F10 */
    case 69:
      numlock();
      return 2;
      break;	/* NUMLOCK */
    case 87:
      return 1;
      break;	/* PAUSE */
    default:
      return 0;
      break;
    }
}

static int	launch_extended_keys(char code)
{
  switch (code)
    {
    case 71 :
      keyboard_home();
      return 0;
      break;	/* HOME */
    case 72 :
      keyboard_haut();
      return 0;
      break;	/* UP */
    case 73 :
      hard_scrolling(-COLUMNS);
      return 0;
      break;	/* PAGE_UP */
    case 75 :
      keyboard_gauche();
      return 0;
      break;	/* LEFT */
    case 77 :
      keyboard_droite();
      return 0;
      break;	/* RIGHT */
    case 79 :
      keyboard_fin();
      return 0;
      break;	/* END */
    case 80 :
      keyboard_bas();
      return 0;
      break;	/* DOWN */
    case 81 :
      hard_scrolling(COLUMNS);
      return 0;
      break; /* PAGE_DOWN */
    case 83 :
      keyboard_suppr();
      return 0;
      break;	/* SUPPR */
    default:
      break;
    }
  return 1;
}

/* static void	directions_keys(int code) */
/* { */
/*   direction_keys[code](); */
/* } */

/* static char	num_pad(int code) */
/* { */
/*   if (code == 53) */
/*     return '\\'; */
/*   else */
/*     if (code == 55) */
/*       return '*'; */
/*     else */
/*       return num_keys[code - START_INDEX_NUMPAD]; */
/* } */

/* static void	add_to_kb_buffer(int code, char mode) */
/* { */
/*   if (start_buffer + 1 != end_buffer) */
/*     { */
/*       kb_buffer[start_buffer][1] = code; */
/*       /\* Va servir pout tout ce qui est alt,  *\/ */
/*       if (mode == 'S') /\* Shift char *\/ */
/* 	kb_buffer[start_buffer][2] = MODE_SHIFT; */
/*       else */
/* 	if (mode == 'A') /\* Alt char *\/ */
/* 	  kb_buffer[start_buffer][2] = MODE_SHIFT; */
/*       else */
/* 	kb_buffer[start_buffer][2] = 0; */
/*       start_buffer++; */
/*       if (start_buffer > KEY_BUFF_SIZE) */
/* 	start_buffer = 0; */
/*     } */
/*   else */
/*     printf("Buffer full !"); */
/* } */

void	keyboard_init(void)
{
  kb.num_lock = 0;
  kb.caps_lock = 0;
  kb.scroll_lock = 0;
  kb.ext_key = 0;
  kb.alt = 0;
}

static void	shortcut_alt(int code)
{
  switch (code)
    {
    case 49 :/* alt + n */
      cons_goto_next_line();
      reinit_buff();
      SHOW_PROMPT;
      break;
    default:
      break;
    }
  return;
}

void	keyboard_irq(int a)
{
  int	code;
/*   int	res; */

/*   printf("CLAVIER\n"); */
  a = a;
/*   asm("cli"); */

  if ((inb(KEYBOARD_PORT2) & 0x1) != 1)
    {
      printf("PB rien dans le tampon !!\n");
/*       asm("sti"); */
      return;
    }

  code = inb(KEYBOARD_PORT);

  if (code < 128 && !is_standard_key(code) && launch_extended_keys(code))
    {
      if (standard_keys[code][kb.caps_lock] != '\b')
	buff_cmd[sh_buf_pos++] = standard_keys[code][kb.caps_lock];
      else
	if (sh_buf_pos){
	  buff_cmd[sh_buf_pos] = 0;
	  sh_buf_pos--;
	}
      kb_driver_nb_char_cmd++;
#ifdef DEBUG
      printf("\n la chaine deja taper est : <%s>\n",buff_cmd);
#endif
      printf("%c", standard_keys[code][kb.caps_lock]);
    }
  /*  if (kb.ext_key)
      launch_extended_keys(code);*/
  if (kb.alt)
    shortcut_alt(code);
  if (code == 170 || code == 182)
    kb.caps_lock = 0;
  if ( code == 157)
    kb.alt =0;
  if (code == 184)
    kb.ext_key = 0;
   inb(KEYBOARD_RESET);

/*   if (kb.ext_key == 1 && (code > 83 || code < 71)) */
/*     { */
/*       printf("Touche etendue %d non geree. ", code); */
/*       kb.ext_key = 0; */
/*       asm("sti"); */
/*       return; */
/*     } */
/*   else */
/*     if (kb.ext_key == 1) */
/*       { */
/* 	launch_extended_keys(code); */
/* 	asm("sti"); */
/*       } */
/*   if (!is_standard_key(code)) */
/*     printf("[%c]\n", standart_keys[code][0]); */
/*     /\*    add_to_kb_buffer(code, 'S');*\/ */
/*   kb.ext_key = 0; */
/*   for (a = 1000000; a > 0; --a) */
/*     ; */
   outb(0x20, 0x20);
   asm("sti");
}
