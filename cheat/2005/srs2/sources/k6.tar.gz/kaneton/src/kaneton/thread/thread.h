/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Mon Nov 14 22:21:05 2005 Nicolas Clermont
** Last update Mon Nov 14 22:21:07 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef THREAD_H_
# define THREAD_H_

# include "../prior.h"
# include "../status.h"
# include "../wait.h"
# include "../../lib/set/set.h"
# include "../../include/kaneton/types.h"
# include "../cpu.h"

/*!
** Define the size of threads' stack, in number of pages
*/
# define THREAD_STACKSZ	1

/* typedef int t_thrctx; */

typedef struct		s_thread
{
  t_thrid		thrid;
  t_tskid		tskid;
  t_ownid		ownid;
  t_prior		prior;
  t_status		sched;
  t_wait		wait;
  t_setid		wait_list;
  t_tskid		wait_from_tskid;
  t_vaddr		stack;
  t_vsize		stacksz;
  t_arch_dep_cpu	cpu_state;
}			t_thread;

/*!
** Initialize the threads manager
*/
int	thread_init(void);

/*!
** Create and initialize a new thread
** @param prior		The new thread priority
** @param thrid		Return the id of the new thread
*/
int	thread_rsv(t_prior prior,
		   t_thrid *thrid);

/*!
** Fill prior with the actual priority of the thread thrid
*/
int	thread_prior(t_thrid thrid,
		     t_prior *prior);

/*!
** Update the priority of the thread thrid with prior
*/
int	thread_grade(t_thrid thrid,
		     t_prior prior);

/*!
** Equivalent of the UNIX function wait()
*/
int	thread_wait(t_thrid thrid,
		    t_wait *wait);

/*!
** Fill thread with the addess of the thread structure thrid
*/
int	thread_get(t_thrid thrid,
		   t_thread **thread);

/*!
** Free the thread structure thrid
*/
int	thread_rel(t_thrid thrid);

/*!
** Clone a thread
*/
int	thread_clone(t_thrid old, t_thrid *new);

/*!
** Make the thread thrid executable
*/
int	thread_run(t_thrid thrid);

/*!
** Stop the thread thrid
*/
int	thread_stop(t_thrid thrid);

/*!
** Fill tskid with the id of the task that owned the thread thrid
*/
int	thread_tskid(t_thrid thrid, t_tskid *tskid);

/*!
** Fill ownid with the id of the owner the thread thrid
*/
int	thread_ownid(t_thrid thrid, t_ownid *ownid);

/*!
** Change the owner of the thread thrid with ownid
*/
int	thread_give(t_thrid thrid, t_ownid ownid);

/*!
** Reserve a stack of size npages for the thread thrid
*/
int	thread_stack(t_thrid thrid, t_vsize npages);

int	thread_load(t_thrid thrid, t_thrctx *thrctx);

int	thread_store(t_thrid thrid, t_thrctx *thrctx);

/*!
** Copy size octets of args on the stack of thread thrid
*/
int	thread_args(t_thrid thrid, void *args, t_size size);

/*!
** Attach the thread thrid to the task tskid
*/
int	thread_attach(t_thrid thrid, t_tskid tskid);

/*!
** Detach the thread thrid from the task tskid
*/
int	thread_detach(t_thrid thrid, t_tskid tskid);

int	thread_exit(t_thrid thrid);

/*!
** Reinitialize the thread manager
*/
int	thread_clean(void);

/*!
** Get the virtual address of the stack of the thread thrid
*/
t_vaddr thread_get_stack_vaddr(t_thrid thrid);

#endif /* !THREAD_H_ */
