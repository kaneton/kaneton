/*
** Copyright (C) Castaing Antoine aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Fri Sep 16 22:26:57 2005 Castaing Antoine
** Last update Fri Oct  7 17:46:52 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "events.h"
#include "interruption.h"

int	event_init(void)
{
  int_init();

}

int	event_rsv(t_eventid eventid, t_event event)
{
  if (eventid > IDT_ENTRIES)
    return -ERROR_WRONG_ARG;
  int_rsv(INT_TYPE_INT,eventid,0,0,(t_vaddr)event);
}

int	event_rel(t_eventid eventid)
{
  int_rel((t_uint8)eventid);
}

int	event_clean(void)
{
  int_clear();
}

int	event_flush(void)
{
}
