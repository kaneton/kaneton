/*
** bochs.c for kaneton in /home/xebech/kaneton/src/kaneton/drivers/bochs
**
** Made by xebech
** Login   <xebech@epita.fr>
**
** Started on  Wed Mar 23 19:27:28 2005 xebech
** Last update Wed Mar 23 19:30:28 2005 xebech
*/
#include "bochs.h"
#include "../../../include/kaneton/ioports.h"

void sos_bochs_putstring(const char* str)
{
  for ( ; str && (*str != '\0') ; str++)
    sos_bochs_putchar(*str);
}
