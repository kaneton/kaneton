/*
** Copyright (C) Castaing Antoine aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Sun Mar  6 02:40:18 2005 Castaing Antoine
** Last update Fri Oct  7 17:49:33 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../include/kaneton/types.h"
#include "i8259.h"

int	pic_init(void)
{
  i8259_pic_init();
  i8259_pic_enable(1);
  i8259_pic_enable(0);
  enable_IRQ();

  return 0;
}

int	pic_enable(t_event_id eventid)
{
  i8259_pic_enable(eventid);
  return 0;
}

int	pic_disable(t_event_id eventid)
{
  i8259_pic_disable(eventid);
  return 0;
}

int	pic_clear(void)
{
  i8259_pic_clear();
  return 0;
}


