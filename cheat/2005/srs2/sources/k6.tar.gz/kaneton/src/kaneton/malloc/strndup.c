/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Sep 26 19:35:34 2005 Damien Laniel
** Last update Fri Oct  7 11:02:50 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "kmalloc.h"
#include "string.h"

/*!
** Duplicate a string
**
** @param str	The string to duplicate
** @param n	Maximum number of characters to copy
** @return The duplicated string
*/
char		*strndup(const char *str, unsigned int n)
{
  char		*answer = 0;
  unsigned int	i = 0;
  unsigned int	size = n;

  if (!str)
    return NULL;
  if (strlen(str) < size)
    size = strlen(str);
  if (!(answer = malloc((size + 1) * sizeof (char), 1)))
    return NULL;
  for (i = 0; i < size; ++i)
    answer[i] = str[i];
  answer[i] = '\0';
  return answer;
}
