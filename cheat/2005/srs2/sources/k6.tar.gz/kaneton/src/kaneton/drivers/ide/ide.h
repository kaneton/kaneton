/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Tue Sep 27 14:02:45 2005 Damien Laniel
** Last update Fri Nov 11 19:17:53 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef IDE_H_
# define IDE_H_

# include "../../../include/kaneton/types.h"
# include "../../scheduler/scheduler.h"

int	schedyield(void);
void	print(void);

/* Controllers and their base I/O ports address */
typedef enum	e_ata_controller
  {
    ATA_CTRL1 = 0x1f0,
    ATA_CTRL2 = 0x170,
    /* Ioports of controller 3 and 4 are to check if needed */
    /*     ATA_CTRL3 = 0xf0, */
    /*     ATA_CTRL4 = 0x70 */
  }		t_ata_controller;

/* Master or slave drives */
typedef enum	e_ata_master_slave
  {
    ATA_MASTER = 0xa0,
    ATA_SLAVE = 0xb0
  }		t_ata_master_slave;

/* ATA or ATAPI */
typedef enum	e_ata_atapi
  {
    ATA,
    ATAPI
  }		t_ata_atapi;

/*
** Device information returned by identify command
** See page 115 (page 130 of the pdf) of ata specifications for more details
** This struture is taken from kos
*/
typedef struct s_ide_device_info
{
  t_uint16 general_config_info;      /* 0 */
  t_uint16 nb_logical_cylinders;     /* 1 */
  t_uint16 reserved1;                /* 2 */
  t_uint16 nb_logical_heads;         /* 3 */
  t_uint16 unformatted_bytes_track;  /* 4 */
  t_uint16 unformatted_bytes_sector; /* 5 */
  t_uint16 nb_logical_sectors;       /* 6 */
  t_uint16 vendor1[3];               /* 7-9 */
  t_uint8  serial_number[20];        /* 10-19 */
  t_uint16 buffer_type;              /* 20 */
  t_uint16 buffer_size;              /* 21 */
  t_uint16 ecc_bytes;                /* 22 */
  t_uint8  firmware_revision[8];     /* 23-26 */
  t_uint8  model_number[40];         /* 27-46 */
  t_uint8  max_multisect;            /* 47 */
  t_uint8  vendor2;
  t_uint16 dword_io;                 /* 48 */
  t_uint8  vendor3;                  /* 49 */
  t_uint8  capabilities;
  t_uint16 reserved2;                /* 50 */
  t_uint8  vendor4;                  /* 51 */
  t_uint8  pio_trans_mode;
  t_uint8  vendor5;                  /* 52 */
  t_uint8  dma_trans_mode;
  t_uint16 fields_valid;             /* 53 */
  t_uint16 cur_logical_cylinders;    /* 54 */
  t_uint16 cur_logical_heads;        /* 55 */
  t_uint16 cur_logical_sectors;      /* 56 */
  t_uint16 capacity1;                /* 57 */
  t_uint16 capacity0;                /* 58 */
  t_uint8  multsect;                 /* 59 */
  t_uint8  multsect_valid;
  t_uint32 lba_capacity;             /* 60-61 */
  t_uint16 dma_1word;                /* 62 */
  t_uint16 dma_multiword;            /* 63 */
  t_uint16 pio_modes;                /* 64 */
  t_uint16 min_mword_dma;            /* 65 */
  t_uint16 recommended_mword_dma;    /* 66 */
  t_uint16 min_pio_cycle_time;       /* 67 */
  t_uint16 min_pio_cycle_time_iordy; /* 68 */
  t_uint16 reserved3[11];            /* 69-79 */
  t_uint16 major_version;            /* 80 */
  t_uint16 minor_version;            /* 81 */
  t_uint16 command_sets1;            /* 82 */
  t_uint16 command_sets2;            /* 83 dixit lk : b14 (smart enabled) */
  t_uint16 reserved4[4];             /* 84-87 */
  t_uint16 dma_ultra;                /* 88 dixit lk */
  t_uint16 reserved5[37];            /* 89-125 */
  t_uint16 last_lun;                 /* 126 */
  t_uint16 reserved6;                /* 127 */
  t_uint16 security;                 /* 128 */
  t_uint16 reserved7[127];
} __attribute__((packed)) t_ide_device_info;

/*!
** Initialize IDE manager
*/
void			ide_init(void);

/*!
** Select the drive to use
**
** @param	controller	Controller on which to select a drive
** @param	master_slave	Drive to select
*/
void			ide_select_drive(t_ata_controller controller, t_ata_master_slave master_slave);

/*!
** Get a device information
**
** @param	controller	Controller on which is the drive to use
*/
t_ide_device_info	*ide_get_device_info(t_ata_controller controller);

/*!
** Print information about an IDE device
**
** @param	controller	Controller on which is the drive to use
*/
void			ide_print_device_infos(t_ata_controller controller);

/*!
** Check if a drive is an ATA or ATAPI drive
**
** @param	controller	Controller on which is the drive to use
*/
t_ata_atapi		ide_ata_or_atapi(t_ata_controller controller);

/*!
** Get the status code of a drive
**
** @param	controller	Controller on which is the drive to use
*/
char			ide_get_status_code(t_ata_controller controller);

/*!
** Print the status of a drive
**
** @param	status		Status code
*/
void			ide_print_status_string(char status_code);

/*!
** Get the error code of a drive
**
** @param	controller	Controller on which is the drive to use
*/
char			ide_get_error_code(t_ata_controller controller);

/*!
** Write some datas to a drive.
** The address is given in CHS (Cylinder/Head/Sector) mode
**
** @param	controller	Controller on which is the drive to use
** @param	cylinder	Cylinder to use
** @param	head		Head to use
** @param	sector		Start sector
** @param	data		Datas to write
** @param	data_size	Size in bytes of the datas to write
** @return	0 if success, 1 otherwise
*/
int		ide_write(t_ata_controller controller,
			  t_uint16 cylinder,
			  t_uint8 head,
			  t_uint8 sector,
			  const void *data,
			  t_uint32 data_size);

/*!
** Read some datas from a drive.
** The address is given in CHS (Cylinder/Head/Sector) mode
**
** @param	controller	Controller on which is the drive to use
** @param	cylinder	Cylinder to use
** @param	head		Head to use
** @param	sector		Start sector
** @param	data_size	Size in bytes of the datas to read
** @return	Read datas. NULL if an error occurs
*/
char		*ide_read(t_ata_controller controller,
			  t_uint16 cylinder,
			  t_uint8 head,
			  t_uint8 sector,
			  t_uint32 data_size);

#endif /* IDE_H_ */
