#ifndef KANETON_KANETON_CLASS_H_
# define KANETON_KANETON_CLASS_H_

# include "../include/kaneton/types.h"

# define CLASS_KERNEL	0x1
# define CLASS_DRIVER	0x2
# define CLASS_SERVICE	0x3
# define CLASS_USER	0x4

typedef t_uint8		t_class;

#endif /* !KANETON_KANETON_CLASS_H_ */
