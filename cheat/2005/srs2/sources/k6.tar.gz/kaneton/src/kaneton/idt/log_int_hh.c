/*
** Copyright (C) Castaing Antoine aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Fri Sep 23 21:18:07 2005 Castaing Antoine
** Last update Fri Nov 11 20:56:42 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../lib/console/console.h"
#include "../trap/trap.h"
#include "idt.h"
#include "../../bootloader/ch_cr.h"
#include "../../bootloader/phys_mem_mapping.h"
/* #define DEBUG_KERN_LOG_INT_HH */


/* extern t_trap		*tab_traps[256]; */

void	log_int_high_handler(int inter)
{

#ifdef DEBUG_KERN_LOG_INT_HH
  printf("High Handler avec inter a %d\n la trap est %d\n",inter,
	 EXCEPTION_ENTRIES + IRQ_ENTRIES + inter);
#endif
  set_pd_address((unsigned int)PD_ENTRY);
  tab_traps[EXCEPTION_ENTRIES + IRQ_ENTRIES + inter]->behave(0);
}



void	log_int_null_handler(int inter)
{
/*   asm("cli\n"); */
  inter = inter;
/*   asm("sti\n"); */
}

