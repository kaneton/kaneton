/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Feb 28 03:50:00 2005 Damien Laniel
** Last update Mon Nov 28 11:43:01 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../lib/memory/as.h"
#include "../lib/memory/pm.h"
#include "../lib/memory/vm.h"
#include "../lib/console/console.h"
#include "idt/interruption.h"
#include "../lib/shell/parse_conf.h"
#include "recover.h"
#include "../bootloader/multiboot.h"
#include "../bootloader/phys_mem_mapping.h"
#include "malloc/kmalloc.h"
#include "thread/thread.h"
#include "mod/mod.h"
#include "scheduler/scheduler.h"
#include "drivers/ide/ide.h"
#include "drivers/ide/part.h"
#include "test/test.h"
#include "trap/trap.h"

/*!
** Used to manage the memory and the address space
*/
t_pm			*pm;
t_as_list		*as_list;

/*!
** Launch the modules service
*/
int			launch_mod_srv()
{
  t_thrid		thrid;
  t_tskid		tskid;
  t_asid		asid;
  t_as			*as = NULL;
  t_thread		*thread = NULL;
  t_vaddr		mod_vaddr;
  t_vaddr		grub_vaddr;
  t_vsize		mod_npages;
  t_vaddr		entry_point = 0;
  t_thrctx		thrctx;
  multiboot_info_t	*grub = (multiboot_info_t *)GRUB_ADDR;
  module_t		*module = (module_t *)grub->mods_addr;

  module += 2;
  task_rsv(CLASS_USER, BEHAV_TIMESHARING, PRIOR_TIMESHARING, &tskid);
  as_rsv(&asid);
  as_attach(asid, tskid);
  as_get(asid, &as);
  mod_npages = (module->mod_end - module->mod_start) / PAGE_SIZE;
  if ((module->mod_end - module->mod_start) % PAGE_SIZE)
    mod_npages++;
  printf("npages de Service mod: %d\n", mod_npages);
  vm_rsv(asid, &mod_vaddr, mod_npages, VM_FLAG_ANY);
  vm_map(asid, module->mod_start, mod_vaddr, mod_npages);
  /* TEMP (CRT) map la struct grub ds l'as du service mod*/
  vm_rsv(asid, &grub_vaddr, 1, VM_FLAG_ANY);
  printf("grub_vaddr pour asid %d : %x\n", asid, grub_vaddr);
  /*   while (1); */
  vm_map(asid, GRUB_ADDR, grub_vaddr, 1);
  /* Get the entry point of the module */
  set_pd_address(as->pd_addr);
  entry_point = *(t_vaddr *)(mod_vaddr + 0x18);
  set_pd_address(PD_ENTRY);
  /* Creation of the thread for the modules service */
  thread_rsv(PRIOR_TIMESHARING, &thrid);
  thread_attach(thrid, tskid);
  thread_stack(thrid, 1);
  /* We load the context */
  thread_get(thrid, &thread);
  thrctx.pc = entry_point;
  thrctx.sp = thread->stack + PAGE_SIZE;
  thread_load(thrid, &thrctx);
  printf("* Service Modules started...\n");
  thread_run(thrid);

  return 0;
}

/*!
**
*/
int			main(void)
{
  init_ttys();
  cons_clear_screen();
  recover_from_bootloader();
  vm_init(KASID);
  parse_conf_file((char *)file_conf_addr);
  init_malloc();
  set_init();
  task_init();
  thread_init();

  sched_init(1000);
  cons_clear_screen();

/*     ide_init(); */
/*     ide_select_drive(ATA_CTRL1, ATA_MASTER); */
/*     test_ide(); */
  /*   part_detect(); */

  cons_clear_screen();
  cons_goto_next_line();
  cons_goto_next_line();
/*   printf("Running process : "); */
  cons_goto_next_line();

  /*   mod_init(GRUB_ADDR); */
  launch_mod_srv();
  trap_init();
  int_init();

/*   cons_goto_next_line(); */
/*   printf("Kaneton_sh>"); */

  quit = 1;
  while(quit)
    ;
  return 0;
}
