/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Sun Nov  6 23:45:15 2005 Nicolas Clermont
** Last update Mon Nov 14 22:21:48 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef KANETON_KANETON_STATUS_H_
# define KANETON_KANETON_STATUS_H_

# include "../include/kaneton/types.h"

/*!
** Possible status for a thread
*/
# define STATUS_RUN		0x1
# define STATUS_STOP		0x2
# define STATUS_MSG		0x3
# define STATUS_ZOMBIE		0x4
# define STATUS_WAIT		0x5
# define STATUS_MSG_FROM	0x6

/*!
** Possible values for the status field of 
** the wait structure
*/
# define STATUS_EXITED		0x0
# define STATUS_TERMINATED	0x1

typedef t_uint32		t_status;

#endif /* !KANETON_KANETON_STATUS_H_ */
