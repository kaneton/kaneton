/*
** Copyright (C) Castaing Antoine aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Fri Sep 23 18:56:12 2005 Castaing Antoine
** Last update Fri Oct  7 17:44:56 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef LOG_INT_H_
# define LOG_INT_H_

# include "../../include/kaneton/types.h"
# include "log_int_hh.h"
# include "idt.h"

typedef void (*log_int_handler_t)(int exception_number);

typedef void (*log_int_wrapper_t)();

/*
** On pourra mettre un int pour savoir si erreur
** d ailleurs reflechir a politique d erreur
*/

int log_int_init(void);

int log_int_set_routine(int exception_number,
			log_int_handler_t routine);

int log_int_rm_routine(int except_no);

log_int_handler_t log_int_get_routine(int exception_number);

#endif
