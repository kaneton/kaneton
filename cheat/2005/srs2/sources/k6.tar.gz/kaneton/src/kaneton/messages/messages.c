/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Tue Oct  4 23:06:17 2005 Nicolas Clermont
** Last update Wed Nov 23 10:50:42 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "messages.h"
#include "../malloc/kmalloc.h"
#include "../task/task.h"
#include "../../lib/memory/as.h"
#include "../../lib/memory/vm.h"
#include "../../lib/memory/mm.h"
#include "../../lib/console/console.h"
#include "../../bootloader/phys_mem_mapping.h"
#include "../../bootloader/ch_cr.h"
#include "../thread/thread.h"
#include "../scheduler/scheduler.h"
#include "../../bootloader/gdt_segments.h"
/* #define DEBUG_KERNEL_MSG 1 */

/*!
** FIXME : CURENT AS !!!
*/
t_msg_hdr	*create_msg(t_tskid src,
			    t_tskid dest,
			    int data_size)
{
  t_msg_hdr	*new = NULL;
  t_vsize	nb_page;
  t_vaddr	new_vaddr = 0;
  t_asid	asid = 0;
  t_as		*as;

  if (task_asid(src, &asid))
    return NULL;
/*  printf("Create msg\n"); */
/*   while (1); */
  if (as_get(asid, &as))
    return NULL;
/*     printf("Create msg\n"); */
/*   while (1); */
  nb_page = (data_size + sizeof (t_msg_hdr)) / PAGE_SIZE;
  if ((data_size + sizeof (t_msg_hdr)) % PAGE_SIZE)
    nb_page++;
  mm_rsv(asid, &new_vaddr, nb_page);

  set_pd_address(as->pd_addr);
  new = (t_msg_hdr *)new_vaddr;
  new->src = src;/*FIXME : KTASKID*/
  new->dest = dest;
  new->data = (t_vaddr)(new + sizeof (t_msg_hdr));
  new->data_size = data_size;
  set_pd_address(PD_ENTRY);

  return new;
}

/* #define DEBUG_KERNEL_MSG */
int		send_msg(t_msg_hdr *msg_hdr, t_tskid tskid_src)
{
  t_asid	asid_src;
  t_as		*as_src;
  t_tskid	dest;
  t_task	*tsk;
  t_msg_kern	*msg_kern = NULL;
/*   int		i = 0; */
  /*   t_iterator	it_msg; */
  /*   int		i = 0; */


#ifdef DEBUG_KERNEL_MSG
  printf("Entrer ds Send_msg avec tskid_src %d\n",
	 tskid_src);
#endif
/*   for (i = 0; i < 10000000; i++) */
/*     ; */
  /*   while (1); */
  if (task_asid(tskid_src, &asid_src))
    {
      printf("task_asid est pourri avec tskid_src %d\n",
	     tskid_src);
      return -1;
    }
  if (as_get(asid_src, &as_src))
    {
      printf("as_get est pourri avec asid_src %d\n",
	     asid_src);
      return -1;
    }
  set_pd_address((unsigned int)as_src->pd_addr);
  dest = msg_hdr->dest;
  set_pd_address((unsigned int)PD_ENTRY);

/*   if ((tskid_src == 5) && dest == 4) */
/*     { */
/*       printf("                  Entrer ds Send_msg venant tskid_src %d vers %d\n", */
/* 	     tskid_src, dest); */
/*       while (1); */
/*     } */
  if (task_get(dest, &tsk))
    {
      printf("task_get est pourri avec dest %d\n", dest);
      return -1;
    }
 /*  printf("Juste avt le wake up\n"); */
/*   while (1); */
#ifdef DEBUG_KERNEL_MSG
  printf("Juste avt le wake up\n");
#endif
 /*Reveille des thread qui dorme*/
  if (task_wakeup_thread_msg(dest, tskid_src))
    {
      while (1)
	printf("Task wake up foire\n");
      return -1;
    }
#ifdef DEBUG_KERNEL_MSG
  printf("Juste aps le wake up\n");
#endif
  msg_kern = malloc(sizeof (t_msg_kern), KASID);
  msg_kern->src = tskid_src;
  msg_kern->msg = (t_vaddr)msg_hdr;
#ifdef DEBUG_KERNEL_MSG
  printf("la tache source est %d\n",  msg_kern->src);
  printf("l @ du msg est %x\n",  msg_kern->msg);
#endif
  set_insert(tsk->msg, (void *)msg_kern);
#ifdef DEBUG_KERNEL_MSG
  printf("Sortie ds Send_msg\n");
#endif
  /*  while (1); */
  /*   if (dest == 2) */
  /*     SET_FOREACH(FOREACH_FORWARD, tsk->msg, &it_msg) */
  /*     { */
  /*       if (i % 16 == 0) */
  /* 	printf("Iteration %d Data: ---%s---\n", i++, (char *)((t_msg_hdr *)((((t_msg_kern *)ITERATOR_ADDR(&it_msg))->msg)))->data); */
  /*       else */
  /* 	i++; */
  /*       if (i > 160) */
  /* 	while (1);	 */
  /*     } */

  return 0;
}


/* #define DEBUG_KERNEL_GET_MSG */
/* #define DEBUG_KERNEL_GET_MSG */
t_vaddr		get_msg(t_tskid dst)
{
  t_task	*tsk;
  t_iterator	it;
  t_asid	asid_src;
  t_asid	asid_dst;
  t_as		*as_src;
  t_as		*as_dst;
  t_msg_kern	*tmp;
  t_paddr	addr_msg_hdr;
  t_vaddr	src_vaddr_msg_data;
  t_paddr	paddr_msg_data = NULL;
  t_vaddr	dst_addr_msg_hdr;
  t_vaddr	dst_addr_msg_data;
  t_vaddr	msg_hdr_tmp;
  unsigned int	offset;

#ifdef DEBUG_KERNEL_GET_MSG
  printf("Entrer ds Get_msg\n");
#endif

  if (task_get(dst, &tsk))
    {
      printf("Task_get tout pourri sur tskid_dest %d\n", dst);
      return 0;
    }
  if (!set_head(tsk->msg, &it))
    {
      if (task_asid(dst, &asid_dst))
	return 0;
      if (as_get(asid_dst, &as_dst))
	return 0;
      tmp = (t_msg_kern	*)it.addr;
      if (task_asid(tmp->src, &asid_src))
	return 0;
      if (as_get(asid_src, &as_src))
	return 0;
      /*ICI on map chez le destinataire le header du msg*/
      addr_msg_hdr = vm_to_pm((word *)as_src->pd_vaddr, tmp->msg,
				  asid_src, as_src->pd_addr);
#ifdef DEBUG_KERNEL_GET_MSG
      printf("Le res du vm_to_pm est %x qui est a l @ virt %x\nasid_src %d et dest %d\n",
	     addr_msg_hdr, tmp->msg, asid_src, dst);
#endif


      offset = addr_msg_hdr & 0xFFF;
      vm_rsv(asid_dst, &dst_addr_msg_hdr, 1, VM_FLAG_ANY);
      vm_map(asid_dst, (addr_msg_hdr >> 12) << 12, dst_addr_msg_hdr, 1);
      dst_addr_msg_hdr += offset;

#ifdef DEBUG_KERNEL_GET_MSG
      printf("hdr :\nphys -> %x\nsrc virt -> %x\ndst virt -> %x\noffset -> %x\n",
	     addr_msg_hdr, tmp->msg, dst_addr_msg_hdr, offset);
#endif

      /*ICI on map les data du msg*/
      msg_hdr_tmp = tmp->msg;

      set_pd_address((unsigned int)as_src->pd_addr);
      src_vaddr_msg_data = ((t_msg_hdr *)msg_hdr_tmp)->data;

#ifdef DEBUG_KERNEL_GET_MSG
      printf("apres passage userland %s\n", (char *)src_vaddr_msg_data);
#endif

      set_pd_address((unsigned int)PD_ENTRY);
      if (src_vaddr_msg_data)
	{
	  paddr_msg_data = vm_to_pm((word *)as_src->pd_vaddr, src_vaddr_msg_data,
				    asid_src, as_src->pd_addr);
	  offset = paddr_msg_data & 0xFFF;
#ifdef DEBUG_KERNEL_GET_MSG
	  printf("Offset data : %x\n", offset);
	  printf("l @ physique du msg data est <%s>\n", (char *)(paddr_msg_data - 1));
#endif
	  paddr_msg_data = (paddr_msg_data >> 12) << 12;
	  vm_rsv(asid_dst, &dst_addr_msg_data, 1, VM_FLAG_ANY);
#ifdef DEBUG_KERNEL_GET_MSG
	  printf("vm rsv fait a l @ : %x\n", dst_addr_msg_data);
#endif
	  vm_map(asid_dst, paddr_msg_data, dst_addr_msg_data, 1);
	  dst_addr_msg_data += offset;
      /* Dans le dest on ecrit dans le champ data
      ** la nouvelle vaddr */
	  set_pd_address((unsigned int)as_dst->pd_addr);
#ifdef DEBUG_KERNEL_GET_MSG
	  printf("vm_map fait ds destination\n");
	  printf("dans dest data st a @ %x et <%s>\n", dst_addr_msg_data, (char *)dst_addr_msg_data);
#endif
	  ((t_msg_hdr *)dst_addr_msg_hdr)->data = dst_addr_msg_data;
	  set_pd_address((unsigned int)PD_ENTRY);
	}
      else
	{
	  set_pd_address((unsigned int)as_dst->pd_addr);
#ifdef DEBUG_KERNEL_GET_MSG
	  printf("vm_map fait ds destination\n");
	  printf("dans dest data st a @ %x et <%s>\n", dst_addr_msg_data, (char *)dst_addr_msg_data);
#endif
	  ((t_msg_hdr *)dst_addr_msg_hdr)->data = NULL;
	  set_pd_address((unsigned int)PD_ENTRY);
	}
#ifdef DEBUG_KERNEL_GET_MSG
      printf("data :\nphys -> %x\nsrc virt -> %x\ndst virt -> %x\n",
	     paddr_msg_data, src_vaddr_msg_data, dst_addr_msg_data);
#endif
      set_delete(tsk->msg, it.id);
#ifdef DEBUG_KERNEL_GET_MSG
      printf("delete msg\n");
#endif
      /*       while (1); */
      return dst_addr_msg_hdr;
    }
  else
    {
#ifdef DEBUG_KERNEL_GET_MSG
      printf("Y a pas de messages \n");
#endif
      return 0;
    }
}

t_vaddr		get_msg_from(t_tskid receiver, t_tskid sender)
{
  t_task	*tsk;
  t_iterator	it;
  t_asid	asid_src;
  t_asid	asid_dst;
  t_as		*as_src;
  t_as		*as_dst;
  t_msg_kern	*tmp;
  t_paddr	addr_msg_hdr;
  t_vaddr	src_vaddr_msg_data;
  t_paddr	paddr_msg_data;
  t_vaddr	dst_addr_msg_hdr;
  t_vaddr	dst_addr_msg_data;
  t_vaddr	msg_hdr_tmp;
  unsigned int	offset;


#ifdef DEBUG_KERNEL_GET_MSG
  printf("Entrer ds Get_msg\n");
#endif

  if (task_get(receiver, &tsk))
    {
      printf("Task_get tout pourri sur tskid_dest %d\n", receiver);
      return 0;
    }
  /*  if (set_head(tsk->msg, &it)) */
  /*     { */
  /* #ifdef DEBUG_KERNEL_GET_MSG */
  /*       printf("Y a pas de messages \n"); */
  /* #endif */
  /*       return 0; */
  /*     } */

  /*  while (1) */
  /*     { */
  SET_FOREACH(FOREACH_FORWARD, tsk->msg, &it)
    {
      tmp = (t_msg_kern	*)it.addr;
     /*  printf("                            get msg from\n"); */
/*       printf("                            venant de %d vers %d\n", */
/* 	     sender, receiver); */
/*       while (1); */
      if (tmp->src == sender)
	{
	  if (task_asid(receiver, &asid_dst))
	    return 0;
	  if (as_get(asid_dst, &as_dst))
	    return 0;
	  /*       tmp = (t_msg_kern	*)it.addr; */
	  if (task_asid(tmp->src, &asid_src))
		return 0;
	  if (as_get(asid_src, &as_src))
	    return 0;
	  /*ICI on map chez le destinataire le header du msg*/
	  addr_msg_hdr = vm_to_pm((word *)as_src->pd_vaddr, tmp->msg,
				  asid_src, as_src->pd_addr);
#ifdef DEBUG_KERNEL_GET_MSG_FROM
	  printf("Le res du vm_to_pm est %x qui est a l @ virt %x\nasid_src %d et dest %d\n", addr_msg_hdr, tmp->msg, asid_src, receiver);
#endif

	  offset = addr_msg_hdr & 0xFFF;
	  vm_rsv(asid_dst, &dst_addr_msg_hdr, 1, VM_FLAG_ANY);
	  vm_map(asid_dst, (addr_msg_hdr >> 12) << 12, dst_addr_msg_hdr, 1);
	  dst_addr_msg_hdr += offset;

#ifdef DEBUG_KERNEL_GET_MSG_FROM
	  printf("hdr :\nphys -> %x\nsrc virt -> %x\ndst virt -> %x\noffset -> %x\n",
		 addr_msg_hdr, tmp->msg, dst_addr_msg_hdr, offset);
#endif

	  /*ICI on map les data du msg*/
	  msg_hdr_tmp = tmp->msg;

	  set_pd_address((unsigned int)as_src->pd_addr);
	  src_vaddr_msg_data = ((t_msg_hdr *)msg_hdr_tmp)->data;

#ifdef DEBUG_KERNEL_GET_MSG_FROM
	  printf("apres passage userland %s\n", (char *)src_vaddr_msg_data);
#endif

	  set_pd_address((unsigned int)PD_ENTRY);
	  paddr_msg_data = vm_to_pm((word *)as_src->pd_vaddr, src_vaddr_msg_data,
				    asid_src, as_src->pd_addr);
	  offset = paddr_msg_data & 0xFFF;
#ifdef DEBUG_KERNEL_GET_MSG_FROM
	  printf("Offset data : %x\n", offset);
	  printf("l @ physique du msg data est <%s>\n", (char *)(paddr_msg_data - 1));
#endif
	  paddr_msg_data = (paddr_msg_data >> 12) << 12;
	  vm_rsv(asid_dst, &dst_addr_msg_data, 1, VM_FLAG_ANY);
#ifdef DEBUG_KERNEL_GET_MSG_FROM
	  printf("vm rsv fait a l @ : %x\n", dst_addr_msg_data);
#endif
	  vm_map(asid_dst, paddr_msg_data, dst_addr_msg_data, 1);
	  dst_addr_msg_data += offset;
	  /* Dans le dest on ecrit dans le champ data
	  ** la nouvelle vaddr */
	  set_pd_address((unsigned int)as_dst->pd_addr);
#ifdef DEBUG_KERNEL_GET_MSG_FROM
	  printf("vm_map fait ds destination\n");
	  printf("dans dest data st a @ %x et <%s>\n", dst_addr_msg_data, (char *)dst_addr_msg_data);
#endif
	  ((t_msg_hdr *)dst_addr_msg_hdr)->data = dst_addr_msg_data;
	  set_pd_address((unsigned int)PD_ENTRY);
#ifdef DEBUG_KERNEL_GET_MSG_FROM
	  printf("data :\nphys -> %x\nsrc virt -> %x\ndst virt -> %x\n",
		 paddr_msg_data, src_vaddr_msg_data, dst_addr_msg_data);
#endif
	  set_delete(tsk->msg, it.id);
#ifdef DEBUG_KERNEL_GET_MSG_FROM
	  printf("delete msg\n");
#endif
	      /*       while (1); */
	  return dst_addr_msg_hdr;
	}
    }
/* if (set_next(tsk->msg, it, &it)) */
/*       { */
/* #ifdef DEBUG_KERNEL_GET_MSG */
/*       printf("On a parcouru ts les msg, aucun ne provient de %d\n", sender); */
/* #endif */
/*       return 0; */
/*       } */
/* } */
  return 0;
}

int	my_sched_switch(t_thrid thrid)
{
  /*Instance du thread courant*/
  t_thread	*thread = NULL;
  /*pointeur nous permttant de visiter la pile*/
  unsigned int	*temp;
  /*Iterateur pour le set*/
/*   t_iterator	it; */
  /*Identifiant de la tache courant*/
  t_tskid	tskid;
  /*Identifiant de l as courant*/
  t_asid	asid;
  /*As courant*/
  t_as		*as;
  /*tss*/
  t_tss		*tss = (t_tss *)TSS;


  /*On passe en as kernel*/
/*   set_pd_address((unsigned int)PD_ENTRY);s */

  /*Si le thrid est a -1 on  est dans le kernel
  **et donc pas encore de thread courant*/

  /*Ici il y a deja des threads en exec donc je sched*/

  if (thread_get(thrid, &thread))
    return 1;
#ifdef DEBUG_KERNEL_MSG
  printf("scheduler thd a save %d\n", thrid);

  /*JE SAVE L ANCIEN THREAD*/
 /*  while (1); */
  printf("ebp val du debut %x\n", sched->ebp_val);
#endif
  temp = (unsigned int *)((void *)sched->ebp_val);
#ifdef DEBUG_SCHED
  printf("le ancien ebp est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.ebp = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo ebp est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("le ancien eip est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.eip = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo eip est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif


  temp++;
#ifdef DEBUG_SCHED
  printf("le ancien cs est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.cs = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo cs est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("les ancien eflags sont <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.eflags = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo eflags est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("l ancien potentiel esp <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.esp = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo esp est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("l ancien potentiel ss <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  thread->cpu_state.ss = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo ss est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp = (unsigned int *)((void *)sched->ebp_val);
  temp--;
  thread->cpu_state.ds = *temp;
#ifdef DEBUG_SCHED
  printf("le ds mis est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif


  temp--;
 /*  thread->cpu_state.eax = *temp; */
 thread->cpu_state.eax = 0;
#ifdef DEBUG_SCHED
  printf("le nouvo eax est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  thread->cpu_state.ecx = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo ecx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  thread->cpu_state.edx = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo edx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  thread->cpu_state.ebx = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo ebx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  /* ESP */

  temp--;
  /* EBP */

  temp--;
  thread->cpu_state.esi = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo esi est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  thread->cpu_state.edi = *temp;
#ifdef DEBUG_SCHED
  printf("le nouvo edi est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  temp--;
#ifdef DEBUG_KERNEL_MSG
  printf("sched -> sched->thrid avt next %d\n", sched->thrid);
#endif
  sched_next(&(sched->thrid));
  if (thread_get(sched->thrid, &thread))
    return 1;
#ifdef DEBUG_KERNEL_MSG
  printf("sched -> sched->thrid apres next %d\n", sched->thrid);
#endif
  /*
  ** Ici on fait le switch vers le prochain thread
  */
  sched->tick = 100;
  temp = (unsigned int *)((void *)sched->ebp_val);


#ifdef DEBUG_SCHED
  printf("le ancien ebp est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.ebp;
#ifdef DEBUG_SCHED
  printf("le nouvo ebp est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("le ancien eip est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.eip;
#ifdef DEBUG_SCHED
  printf("le nouvo eip est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif


  temp++;
#ifdef DEBUG_SCHED
  printf("le ancien cs est <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.cs;
#ifdef DEBUG_SCHED
  printf("le nouvo cs est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("les ancien eflags sont <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.eflags;
#ifdef DEBUG_SCHED
  printf("le nouvo eflags est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("l ancien potentiel esp <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.esp;
#ifdef DEBUG_SCHED
  printf("le nouvo esp est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp++;
#ifdef DEBUG_SCHED
  printf("l ancien potentiel ss <");
  my_printnbr((unsigned int)*temp);
  printf("> a l @ <%x>\n", temp);
#endif
  *temp = thread->cpu_state.ss;
#ifdef DEBUG_SCHED
  printf("le nouvo ss est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif
#ifdef DEBUG_KERNEL_MSG
  printf("ebp val du milieu %x\n", sched->ebp_val);
#endif
  temp = (unsigned int *)((void *)sched->ebp_val);

  temp--;
  *temp = thread->cpu_state.ds;
#ifdef DEBUG_SCHED
  printf("le ds mis est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif


  temp--;
  *temp = thread->cpu_state.eax;
#ifdef DEBUG_SCHED
  printf("le nouvo eax est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.ecx;
#ifdef DEBUG_SCHED
  printf("le nouvo ecx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.edx;
#ifdef DEBUG_SCHED
  printf("le nouvo edx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.ebx;
#ifdef DEBUG_SCHED
  printf("le nouvo ebx est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  /* ESP */

  temp--;
  /* EBP */

  temp--;
  *temp = thread->cpu_state.esi;
#ifdef DEBUG_SCHED
  printf("le nouvo esi est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.edi;
#ifdef DEBUG_SCHED
  printf("le nouvo edi est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  temp--;
  *temp = thread->cpu_state.ebp;
#ifdef DEBUG_SCHED
  printf("le nouvo ebp est <");
  my_printnbr(*temp);
  printf("> a l @ <%x>\n", temp);
#endif

  if (thread_tskid(sched->thrid, &tskid))
    return 1;
  if (task_asid(tskid, &asid))
    return 1;
  if (as_get(asid, &as))
    return 1;

  tss->esp0 = sched->ebp_val + 4 * 6;
  tss->ss0 = 0x10;
  tss->esp = thread->cpu_state.esp;
  tss->ss = thread->cpu_state.ss;
  tss->cs = thread->cpu_state.cs;
  tss->cr3 = as->pd_addr;




  /* while (1); */
/*   set_pd_address((unsigned int)as->pd_addr); */

  return 0;
}


int	wait_msg(t_thrid src)
{
  t_vaddr	dst_msg;
  t_tskid	tskid_dest;
  t_thread	*thread = NULL;
/*   t_thrid	next_thrid; */
  t_tskid	tmp;
/*  int		i = 0; */

  if (thread_tskid(src, &tskid_dest))
    {
      printf("Wait msg kern pb thread_tskid\n");
      while (1)
	printf("Wait msg kern pb thread_tskid\n");
      return 0;
    }

  if ((dst_msg = get_msg(tskid_dest)))
    return (t_vaddr)dst_msg;
/*   printf("                         pas de msg pour %d\n",tskid_dest); */
#ifdef DEBUG_KERNEL_MSG
  printf("##########################\n");
  printf("pas de msg pour %d\n",src);
#endif

  if (thread_get(src, &thread))
    return 0;
  thread->sched = STATUS_MSG;
#ifdef DEBUG_KERNEL_MSG
  printf("messages kern -> thread get src %d reussi\n", src);
#endif
/*   if (sched_next(&next_thrid)) */
/*     return 0; */
/*   printf("                        wait msg avt sched thread est %d\n", sched->thrid); */
  my_sched_switch(src);
  sched_remove(src);
/*   printf("                        wait msg avt sched thread est %d\n", sched->thrid); */
/*   while (1); */
 if (thread_tskid(sched->thrid, &tmp))
    {
      printf("Wait msg kern pb thread_tskid\n");
      while (1)
	printf("Wait msg kern pb thread_tskid\n");
      return 0;
    }
/*  printf("                         Je schedule vers la tache : %d\n",tmp); */
/*  for (i = 0; i < 10000000; i++) */
/* 	    ; */

 return 0;

}

int	wait_msg_from(t_thrid dest, t_tskid src)
{
  t_vaddr	dst_msg;
  t_tskid	tskid_dest;
  t_thread	*thread = NULL;
/*   t_thrid	next_thrid; */

/*   printf("###################################\n"); */
/*   printf("Wait Msg From %d\n", src); */
  if (thread_tskid(dest, &tskid_dest))
      return 0;

  if ((dst_msg = get_msg_from(tskid_dest, src)))
    return (t_vaddr)dst_msg;

 /*  printf("##########################\n"); */
/*   printf("pas de msg pour %d\n", tskid_dest); */
/*   while (1); */
#ifdef DEBUG_KERNEL_MSG
  printf("##########################\n");
  printf("pas de msg pour %d\n",dest);
#endif
  if (thread_get(dest, &thread))
    return 0;
/*   printf("wait msg from -> thread get dest %d de la tache %d\n", dest, tskid_dest); */
#ifdef DEBUG_KERNEL_MSG
  printf("wait msg from -> thread get dest %d reusssi\n", dest);
#endif
 /*  printf("wait msg from -> tache source %d\n", src); */
  thread->wait_from_tskid = src;
  thread->sched = STATUS_MSG_FROM;

/*   if (sched_next(&next_thrid)) */
/*     return 0; */
  my_sched_switch(dest);

  sched_remove(dest);
/*   printf("wait msg from -> Je schedule vers le thread %d\n", sched->thrid); */
 /*  while (1); */
  return 0;

}
