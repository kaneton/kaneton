/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Mon Sep 26 19:43:56 2005 Nicolas Clermont
** Last update Tue Oct  4 22:45:59 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "test.h"

#define DEBUG_CONSOLE 1
void		launch_console(void)
{
  t_tskid	tskid;
  t_thrid	thrid;
  t_thrid	thrid2;
  t_asid	asid;
  t_as		*as;
  t_thread	*thread;
  t_thread	*thread2;
  t_vaddr	cons_vaddr = 0;
  t_vaddr	entry_point;
  t_vaddr	entry_point2;
  t_thrctx	thrctx;

  task_rsv(CLASS_USER, BEHAV_TIMESHARING, PRIOR_TIMESHARING, &tskid);
  as_rsv(&asid);
  as_attach(asid, tskid);
  as_get(asid, &as);
  /* On mappe le code de la premiere console */
  vm_rsv(asid, &cons_vaddr, 2, VM_FLAG_ANY);
  vm_map(asid, console_addr, cons_vaddr, 2);
  set_pd_address(as->pd_addr);
  entry_point = *(t_vaddr *)(cons_vaddr + 0x18);
  set_pd_address(PD_ENTRY);

#ifdef DEBUG_CONSOLE
  printf("VADDR 1 : %x  Entry point 1 : %x\n",
	 cons_vaddr, entry_point);
#endif

  /* On mappe le code de la premiere console */
  vm_rsv(asid, &cons_vaddr, 2, VM_FLAG_ANY);
  vm_map(asid, console_addr2, cons_vaddr, 2);
  set_pd_address(as->pd_addr);
  entry_point2 = *(t_vaddr *)(cons_vaddr + 0x18);
  set_pd_address(PD_ENTRY);

#ifdef DEBUG_CONSOLE
  printf("VADDR 2 : %x  Entry point 2 : %x\n",
	 cons_vaddr, entry_point2);
#endif

  thread_rsv(PRIOR_TIMESHARING, &thrid);
  thread_attach(thrid, tskid);

  thread_rsv(PRIOR_TIMESHARING, &thrid2);
  thread_attach(thrid2, tskid);

  thread_stack(thrid, 1);
  thread_stack(thrid2, 1);

  thread_get(thrid, &thread);
  thread_get(thrid2, &thread2);

#ifdef DEBUG_CONSOLE
  printf("Entry point 1 : <%x>\n", entry_point);
  printf("Entry point 2 : <%x>\n", entry_point2);
  printf("Stack_addr 1 : <%x>\n", thread->stack);
  printf("Stack_addr 2 : <%x>\n", thread2->stack);
#endif

  thrctx.pc = entry_point;
  thrctx.sp = thread->stack + PAGE_SIZE;
  thread_load(thrid, &thrctx);

  thrctx.pc = entry_point2;
  thrctx.sp = thread2->stack + PAGE_SIZE;
  thread_load(thrid2, &thrctx);

  thread_run(thrid);
  thread_run(thrid2);
}

int		test_mod_load_entry(void)
{
  t_tskid	tskid;
  t_thrid	thrid;
  t_asid	asid;
  t_thread	*thread;
  t_thrctx	thrctx;

  task_rsv(CLASS_USER,
	   BEHAV_TIMESHARING,
	   PRIOR_TIMESHARING,
	   &tskid);
  as_rsv(&asid);
  as_attach(asid, tskid);
  thread_rsv(PRIOR_TIMESHARING, &thrid);
  thread_attach(thrid, tskid);
  thread_stack(thrid, 1);
  mod_load(1, asid);
  mod_entry(1, &(thrctx.pc));

  thread_get(thrid, &thread);
  thrctx.sp = thread->stack + PAGE_SIZE;
  thread_load(thrid, &thrctx);
  thread_run(thrid);
  printf("Le nouveau module a ete demarre !!!\n");

  return 0;
}

int	        test_mod_function(void)
{
  t_vaddr	entry;

  mod_function(1, "cons_clear_screen", &entry);
  printf("Virtual address of the function cons_clear_screen : %x\n", entry);

  return 0;
}

int		test_task_thread(void)
{
  t_thrid thrid;
  t_thrid thrid2; 
  t_thread *thread;   
  
  thread_init(); 
  thread_rsv (0, &thrid);
  thread_rsv (0, &thrid2);
  thread_get(thrid, &thread);
  
  return 0;
}
