/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Mar  4 11:36:06 2005 Castaing Antoine
** Last update Sun Mar  6 02:39:07 2005 Castaing Antoine
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef IRQ_H_
# define IRQ_H_

# include "pic.h"

# define IRQ_TIMER                         0
# define IRQ_KEYBOARD                      1
# define IRQ_SLAVE_PIC                     2
# define IRQ_COM2                          3
# define IRQ_COM1                          4
# define IRQ_LPT2                          5
# define IRQ_FLOPPY                        6
# define IRQ_LPT1                          7
# define IRQ_8_NOT_DEFINED                 8
# define IRQ_RESERVED_1                    9
# define IRQ_RESERVED_2                    10
# define IRQ_RESERVED_3                    11
# define IRQ_RESERVED_4                    12
# define IRQ_COPROCESSOR                   13
# define IRQ_HARDDISK                      14
# define IRQ_RESERVED_5                    15



typedef void (*irq_wrapper_t)();

typedef void (*irq_handler_t)(int irq);

/*
** this function enable the pic
*/
int irq_init(void);

int irq_set_routine(int irq,
		    irq_handler_t routine);

irq_handler_t irq_get_routine(int irq);

int irq_rm_routine(int except_no);
#endif
