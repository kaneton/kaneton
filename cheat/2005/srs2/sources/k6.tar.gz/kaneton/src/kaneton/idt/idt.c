/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:38:14 2005 Castaing Antoine
** Last update Fri Oct  7 17:51:07 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "idt.h"
#include "irq.h"
#include "exception.h"
#include "../../include/kaneton/types.h"
#include "../../lib/console/console.h"
#include "../../bootloader/phys_mem_mapping.h"

extern void irq1(int irq);
extern void irq2(int irq);
extern void irq3(int irq);
extern void irq4(int irq);
extern void irq5(int irq);
extern void irq6(int irq);
extern void irq7(int irq);
extern void irq8(int irq);
extern void irq9(int irq);
extern void irq10(int irq);
extern void irq11(int irq);
extern void irq12(int irq);
extern void irq13(int irq);
extern void irq14(int irq);
extern void irq15(int irq);
extern void irq16(int irq);
extern void exceptdivbyzero(int exception_number);
extern void exceptdebug(int exception_number);
extern void exceptnmi(int exception_number);
extern void exceptbreakpoint(int exception_number);
extern void exceptoverflow(int exception_number);
extern void exceptboundrange(int exception_number);
extern void exceptinvalidopcode(int exception_number);
extern void exceptdevicenotavail(int exception_number);
extern void exceptdoublefault(int exception_number);
extern void exceptcoproc(int exception_number);
extern void exceptinvalidtss(int exception_number);
extern void exceptsegmentnotpresent(int exception_number);
extern void exceptstacksegfault(int exception_number);
extern void exceptgeneralprotect(int exception_number);
extern void exceptpagefault(int exception_number);
extern void exceptintelrsv(int exception_number);
extern void exceptfloatingpointerror(int exception_number);
extern void exceptalignementcheck(int exception_number);
extern void exceptmachinecheck(int exception_number);
extern void logicialinterruption(int exception_number);
extern void syscallnoarg(int li_no);

/* idt_entry_t *idt = (idt_entry_t *)0x200000; */

void				idt_add_entry(t_uint8 entry,
					      t_vaddr handler)
{

  union u_easy_convert_valeur	handl;

#ifdef DEBUG_IDT
  printf("Ajout de l'entre %d dans l idt\n avec un handler a l adresse %d\n", (int)entry, (int)handler);
#endif
  handl.val32 = handler;
  idt[entry].offset_low = handl.val16;
  handl.val32 = handl.val32 >> 16;
  idt[entry].offset_high = handl.val16;
  idt[entry].seg_sel = 0x08;
  idt[entry].p = 1;
  idt[entry].flags = 0;
  idt[entry].type = 6;
  idt[entry].dpl = 3;
  idt[entry].zero = 0;
  idt[entry].gate_size = 1;
}


void	idt_init(void)
{
  int i;

  idt = (idt_entry_t *)IDT_ADDR;
#ifdef DEBUG_IDT
  printf("Ajout de l'entre un handler a l adresse <%x>\n", (unsigned int)exceptdivbyzero);
#endif
  idt_add_entry(DIVIDE_ERROR, (t_vaddr)exceptdivbyzero);
  idt_add_entry(DEBUG, (t_vaddr)exceptdebug);
  idt_add_entry(NMI_INTERRUPT, (t_vaddr)exceptnmi);
  idt_add_entry(BREAKPOINT, (t_vaddr)exceptbreakpoint);
  idt_add_entry(OVERFLOW, (t_vaddr)exceptoverflow);
  idt_add_entry(BOUND_RANGE_EXCEDEED, (t_vaddr)exceptboundrange);
  idt_add_entry(INVALID_OPCODE, (t_vaddr)exceptinvalidopcode);
  idt_add_entry(DEVICE_NOT_AVAILABLE, (t_vaddr)exceptdevicenotavail);
  idt_add_entry(DOUBLE_FAULT, (t_vaddr)exceptdoublefault);
  idt_add_entry(COPROCESSOR_SEGMENT_OVERRUN, (t_vaddr)exceptcoproc);
  idt_add_entry(INVALID_TSS, (t_vaddr)exceptinvalidtss);
  idt_add_entry(SEGMENT_NOT_PRESENT, (t_vaddr)exceptsegmentnotpresent);
  idt_add_entry(STACK_SEGMENT_FAULT, (t_vaddr)exceptstacksegfault);
  idt_add_entry(GENERAL_PROTECTION, (t_vaddr)exceptgeneralprotect);
  idt_add_entry(PAGE_FAULT, (t_vaddr)exceptpagefault);
  idt_add_entry(INTEL_RESERVED_1, (t_vaddr)exceptintelrsv);
  idt_add_entry(FLOATING_POINT_ERROR, (t_vaddr)exceptfloatingpointerror);
  idt_add_entry(ALIGNEMENT_CHECK, (t_vaddr)exceptalignementcheck);
  idt_add_entry(MACHINE_CHECK, (t_vaddr)exceptmachinecheck);
  for (i = 19; i < 32; i++)
    idt_add_entry(i, (t_vaddr)exceptintelrsv);

  idt_add_entry(IRQ_TIMER + EXCEPTION_ENTRIES, (t_vaddr)irq1);
  idt_add_entry(IRQ_KEYBOARD + EXCEPTION_ENTRIES, (t_vaddr)irq2);
  idt_add_entry(IRQ_SLAVE_PIC + EXCEPTION_ENTRIES, (t_vaddr)irq3);
  idt_add_entry(IRQ_COM2 + EXCEPTION_ENTRIES, (t_vaddr)irq4);
  idt_add_entry(IRQ_COM1 + EXCEPTION_ENTRIES, (t_vaddr)irq5);
  idt_add_entry(IRQ_LPT2 + EXCEPTION_ENTRIES, (t_vaddr)irq6);
  idt_add_entry(IRQ_FLOPPY + EXCEPTION_ENTRIES, (t_vaddr)irq7);
  idt_add_entry(IRQ_LPT1 + EXCEPTION_ENTRIES, (t_vaddr)irq8);
  idt_add_entry(IRQ_8_NOT_DEFINED + EXCEPTION_ENTRIES, (t_vaddr)irq9);
  idt_add_entry(IRQ_RESERVED_1 + EXCEPTION_ENTRIES, (t_vaddr)irq10);
  idt_add_entry(IRQ_RESERVED_2 + EXCEPTION_ENTRIES, (t_vaddr)irq11);
  idt_add_entry(IRQ_RESERVED_3 + EXCEPTION_ENTRIES, (t_vaddr)irq12);
  idt_add_entry(IRQ_RESERVED_4 + EXCEPTION_ENTRIES, (t_vaddr)irq13);
  idt_add_entry(IRQ_COPROCESSOR + EXCEPTION_ENTRIES, (t_vaddr)irq14);
  idt_add_entry(IRQ_HARDDISK + EXCEPTION_ENTRIES, (t_vaddr)irq15);
  idt_add_entry(IRQ_RESERVED_5 + EXCEPTION_ENTRIES, (t_vaddr)irq16);
  idt_add_entry(IRQ_ENTRIES + EXCEPTION_ENTRIES, (t_vaddr)syscallnoarg);
  for (i = 49; i < 176; i++)
      idt_add_entry(i, (t_vaddr)logicialinterruption);

/*   cons_print_int_base((unsigned int)idt, 10); */
}
