/*
** Copyright (C) Laurent Decool aka traktopel <laurent.decool@gmail.com>
**
** Part of Kaneton
**
** Started on  Wed Oct  5 14:49:25 2005 Laurent Decool
** Last update Wed Oct  5 15:25:13 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
** Map of us keyboard
*/
extern char standard_keys[58][2];

char standard_keys[58][2] =
     {
       {   0,0   } ,
       {   0,0   } ,
       { '1','!' } ,
       { '2','@' } ,
       { '3','#' } ,
       { '4','$' } ,
       { '5','%' } ,
       { '6','^' } ,
       { '7','&' } ,
       { '8','*' } ,
       { '9','(' } ,
       { '0',')' } ,
       { '-','_' } ,
       { '=','+' } ,
       {   8,8   } ,
       {   9,9   } ,
       { 'q','Q' } ,
       { 'w','W' } ,
       { 'e','E' } ,
       { 'r','R' } ,
       { 't','T' } ,
       { 'y','Y' } ,
       { 'u','U' } ,
       { 'i','I' } ,
       { 'o','O' } ,
       { 'p','P' } ,
       { '[','{' } ,
       { ']','}' } ,
       {  13,13  } ,
       {   0,0   } ,
       { 'a','A' } ,
       { 's','S' } ,
       { 'd','D' } ,
       { 'f','F' } ,
       { 'g','G' } ,
       { 'h','H' } ,
       { 'j','J' } ,
       { 'k','K' } ,
       { 'l','L' } ,
       { ';',':' } ,
       {  39,34  } ,
       { '`','~' } ,
       {   0,0   } ,
       { '\\','|'} ,
       { 'z','Z' } ,
       { 'x','X' } ,
       { 'c','C' } ,
       { 'v','V' } ,
       { 'b','B' } ,
       { 'n','N' } ,
       { 'm','M' } ,
       { ',','<' } ,
       { '.','>' } ,
       { '/','?' } ,
       {   0,0   } ,
       {   0,0   } ,
       {   0,0   } ,
       { ' ',' ' } ,
   };

extern char	num_keys[];
char	num_keys[] =
{
  '7',
  '8',
  '9',
  '-',
  '4',
  '5',
  '6',
  '+',
  '1',
  '2',
  '3',
  '0',
  '.',
  '\n'
};


/*
** This table contain the name of each function to call
** when a direction key is pressed
*/

extern char	*direction_keys[];
char	*direction_keys[] =
  {
    "keyboard_home", /* 0xE0 0x47 */
    "keyboard_haut", /* 0xE0 0x48 */
    "keyboard_page_up", /* 0xE0 0x49 */
    "keyboard_empty_func",
    "keyboard_gauche", /* 0xE0 0x4B */
    "keyboard_empty_func",
    "keyboard_droite", /* 0xE0 0x4D */
    "keyboard_empty_func",
    "keyboard_fin", /* 0xE0 0x4F */
    "keyboard_bas", /* 0xE0 0x50 */
    "keyboard_page_down", /* 0xE0 0x51 */
    "keyboard_insert", /* 0xE0 0x52 */
    "keyboard_suppr", /* 0xE0 0x53 */
  };

