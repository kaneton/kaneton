/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Mon Sep 26 19:38:29 2005 Nicolas Clermont
** Last update Mon Sep 26 20:09:21 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "test.h"

/*!
** Test the memory
*/
void			test_area(void)
{
  t_as			*as = NULL;
  /*  t_asid		test_asid; */
  t_paddr		addr;
  int			i;
  /*  t_vaddr		vaddr; */

  /* as_rsv(&test_asid); */
  /*    mm_rsv(1, &vaddr, 100); */
  /*     mm_rel(1, vaddr, 100); */
  /*     machdep_pm_rsv(test_asid, &addr, 10, PM_FLAG_ANY); */
  /*     machdep_pm_rel(2, addr, 10); */
  /*   vm_init(0); */
  /*     for (i = 0; i < 200; i++) */
  /*       if (mm_rsv(test_asid, &vaddr, 20)) */
  /*         { */
  /*   	printf("ERROR"); */
  /*   	while (1); */
  /*         } */
  /*   / */
  /*              TEST ON VM_RSV */
  /*   / */
  /*   vm_rsv(test_asid, &addr2, 12, 0); */
  /*   vm_rsv(test_asid, &addr, 1, 0);   */
  /*   vm_rsv(test_asid, &addr, 100, 0); */
  /*   vm_rsv(test_asid, &addr, 1, 0);   */
  /*   vm_rsv(test_asid, &addr, 10, 0);  */
  /*vm_rel(test_asid, addr2 + 0x9000 , 90);*/
  /*  cons_clear_screen();*/
  /*   machdep_as_get(test_asid, &test_as); */
  /*   machdep_print_vm_ascii(test_as); */
  /*  machdep_pm_rsv(test_asid, &addr, 1, PM_FLAG_ANY); */
  /*  machdep_pm_rsv(test_asid, &addr, 10, PM_FLAG_ANY);*/
  /*  machdep_pm_rsv(test_asid, &addr, 10, PM_FLAG_ANY);*/
  /*  machdep_pm_rsv(test_asid, &addr, 10, PM_FLAG_ANY);*/
  /*  as_rsv(&test_asid);                               */
  /*  machdep_pm_rsv(test_asid, &addr, 10, PM_FLAG_ANY);*/
  /*  machdep_pm_rsv(test_asid, &addr, 10, PM_FLAG_ANY);*/
  /*  for (i = 0; i < 200; i++) */
  /*     as_rsv(&test_asid); */
  as_get(1, &as);

  for (i = 0; i < 7; i++)
    {
      mm_rsv(1, &addr, 1000);
      /*       mm_rel(1, addr, 1000); */
      /*      machdep_pm_rsv(1, &addr, 20, PM_FLAG_ANY);
	      machdep_vm_rsv(1, &addr, 100000000, VM_FLAG_ANY);*/
    }
  printf("It is done !!\n");
  as_print(as);
}

/*!
** Test the memory
*/
void		test_pm_rel(void)
{
  /*************************************/
  /*  Test pour la fusion a gauche     */
  /*************************************/
  machdep_pm_rel(2, 0x11c000, 10);
  machdep_pm_rel(3, 0x126000, 10);
  /*************************************/
  /*  Test pour la fusion a droite     */
  /*************************************/
  machdep_pm_rel(3, 0x130000, 10);
  /*************************************/
  /* Test pour fusion droite ET gauche */
  /*************************************/
  machdep_pm_rel(2, 0x112000, 10);
  machdep_pm_rel(3, 0x126000, 10);
  machdep_pm_rel(2, 0x11c000, 10);
  /*               Variante            */
  /* as_rel(2);                        */
}

/*!
** Test the virtual memory
*/
void		print_kernel_vm(void)
{
  t_as			*as = NULL;
  t_vaddr		vaddr;
  int			i;

  for (i = 0; i < 5; i++)
    if (mm_rsv(KASID, &vaddr, 20))
      {
	printf("ERROR");
	while (1);
      }
  mm_rel(KASID, vaddr, 20);
  machdep_as_get(KASID, &as);
  machdep_print_vm_ascii(as);
}

/*!
** Debug
*/
void		debug_mem(void)
{
  int		timer = 0;

  test_area();

  for (timer = 0; timer < 5000000; timer ++)
    ;
  cons_clear_screen();
  print_addr_space();
  
  cons_goto_next_line();
  print_phys_mem();
  cons_goto_next_line();

  for (timer = 0; timer < 5000000; timer ++)
    ;
  
  cons_clear_screen();
  test_pm_rel();
  cons_clear_screen();
  
  print_addr_space();
  print_phys_mem();
  cons_goto_next_line();

  for (timer = 0; timer < 5000000; timer ++)
    ;
  print_kernel_vm();
}
