/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Mon Nov  7 00:05:09 2005 Nicolas Clermont
** Last update Mon Nov  7 00:34:46 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "trap.h"
#include "behave.h"
#include "../scheduler/scheduler.h"
#include "../task/task.h"
#include "../../lib/memory/as.h"

int endoffork;

t_tskid		fork(void)
{
  t_tskid	choice;
  t_thrctx	thrctx;
  t_tskid	tskid;
  t_thrid	thrid;
  t_asid	asid;
  t_tskid	new;

  sched_thrid(&thrid);
  thread_tskid(thrid, &tskid);

  task_asid(tskid, &asid);

  task_rsv(CLASS_USER, BEHAV_TIMESHARING, PRIOR_TIMESHARING, &new);

  as_clone(asid, &asid);
  as_attach(asid, new);

  /*
  ** Only the calling thread is cloned
  */
  thread_clone(thrid, &thrid);
  thread_attach(thrid, new);
  
  thread_store(thrid, &thrctx);
  thrctx.pc = (t_pc)endoffork;
  thread_load(thrid, &thrctx);
  
  thread_run(thrid);
  task_run(new);

  /* endoffork: */

  sched_thrid(&thrid);
  thread_tskid(thrid, &choice);

  return (choice == tskid ? new : 0);
}
