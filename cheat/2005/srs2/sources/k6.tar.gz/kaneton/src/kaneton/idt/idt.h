/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Mar  4 12:43:51 2005 Castaing Antoine
** Last update Wed Oct  5 16:46:50 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef IDT_H_
# define IDT_H_

# include "../../include/kaneton/types.h"

# define IDT_ENTRIES		176
# define EXCEPTION_ENTRIES	32
# define IRQ_ENTRIES		16
# define LOG_INT_ENTRIES	128

typedef struct
{
  t_uint16 offset_low;
  t_uint16 seg_sel;
  t_uint8 flags;
  t_uint8 type:3;
  t_uint8 gate_size:1;
  t_uint8 zero:1;
  t_uint8 dpl:2;
  t_uint8 p:1;
  t_uint16 offset_high;
} idt_entry_t __attribute__((packed));


/* typedef struct */
/* { */
/*   t_uint16 limit; */
/*   t_uint32 base; */
/* } t_idtr __attribute__((packed)); */


void	idt_init(void);

idt_entry_t	*idt;

struct idtr{
    unsigned short limit;
    unsigned int base;
} __attribute__((packed));

#endif /* !KANETON_H_ */
