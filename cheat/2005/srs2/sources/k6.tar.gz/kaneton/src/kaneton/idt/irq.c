/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Sun Mar  6 02:35:56 2005 Castaing Antoine
** Last update Wed Nov  9 12:36:37 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "irq.h"
#include "idt.h"
#include "../../include/kaneton/error.h"
#include "irq_hh.h"
#include "../drivers/timer/timer.h"
#include "../drivers/keyboard/keys.h"

#include "../../lib/console/console.h"
irq_handler_t tabirqhandler[IRQ_ENTRIES] =
  { NULL, };


/*!
** This function init the kernel management of the irqs
** It puts into tabirqhandler the kernel handler
** @return int This is the error code.
** 0 all looks fine else a value indicates an error
*/
int	irq_init(void)
{
  int	i;
/*   extern t_trap		*tab_traps[256]; */

  timer_init();
/*   keyboard_init(); */
  irq_set_routine(IRQ_TIMER, timer_tick);
/*   irq_set_routine(IRQ_KEYBOARD, keyboard_irq); */
  for (i = 1; i < IRQ_ENTRIES; i++)
    irq_set_routine(i, irqs_how_handler);
  return 0;
}


/*!
** This function remove an handler from the table of the irq.
** The kernel replace this function with a function which do nothing
** @param except_no This is the irq exception number.
** The value is between 0 and 15
*/
int	irq_rm_routine(int except_no)
{
  tabirqhandler[except_no] = 0;
  return 0;
}


/*!
** This function permit to set a new  handler for an irq exception
** @param irq This is the irq number
** It is between 0 and 15
** @param fct This is the handler
** @return int if the value return is 0 there is no error else
** read include/kaneton/error.h
*/
int	irq_set_routine(int irq,
			irq_handler_t fct)
{
  if ((irq < 0) ||
      (irq >= IRQ_ENTRIES ))
    return -ERROR_WRONG_ARG;

  tabirqhandler[irq] = fct;

  return NO_ERROR;
}

/*!
** This function permit to get the handler of an exception
** @param irq This arument is the irq exception number.
** It is between 0 and 15
** @return irq_handler_t This is the handler of the irq
*/
irq_handler_t irq_get_routine(int irq)
{
  return tabirqhandler[irq];
}
