/*
** kmalloc.h for kaneton in /home/xebech/koinkoin
**
** Made by xebech
** Login   <xebech@epita.fr>
**
** Started on  Thu Oct  6 16:35:56 2005 xebech
** Last update Fri Oct  7 17:29:05 2005 xebech
*/

#ifndef KANETON_KMALLOC_H_
# define KANETON_KMALLOC_H_


#include "../../include/kaneton/types.h"

void		init_malloc();
void		free(void *addr);
void		*malloc(unsigned int size,
			t_asid asid);

/* #define DEBUG_LIBC */
struct big_chunck
{
  int			nb_page;
  unsigned int		free;
  struct big_chunck	*next;
}__attribute__((packed));

struct little_chunck
{
  unsigned int		size;
  t_asid		asid;
  struct little_chunck	*next;
  struct little_chunck	*prev;
  char			used;
}__attribute__((packed));


#endif /* !KANETON_KMALLOC_H_ */
