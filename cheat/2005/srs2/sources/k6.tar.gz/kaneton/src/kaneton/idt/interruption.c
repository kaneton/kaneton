/*
** Copyright (C) Castaing Antoine aka xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Mar  4 11:33:03 2005 Castaing Antoine
** Last update Fri Oct  7 17:46:05 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "exception.h"
#include "irq.h"
#include "idt.h"
#include "log_int.h"
#include "../../bootloader/phys_mem_mapping.h"
#include "../../lib/console/console.h"
#include "../../include/kaneton/error.h"
#include "../../include/kaneton/types.h"

/*
# define asm_lidt(IdtPtr) __asm__ volatile ("lidt %0\n" : : "m"(*IdtPtr))

  unsigned char		*p;
  unsigned int		i;

  struct {
  unsigned short idt_size;
  unsigned int idt_base;
  } kdata;
  asm_lidt(p);
*/


# define asm_lidt(IdtPtr) __asm__ volatile ("lidt %0\n" : : "m"(*IdtPtr))

int		load_idtr(t_uint32 __attribute__((unused)) base)
{
  struct idtr	idtr;
  unsigned char	*p;

  p = (unsigned char*)&idtr;
  idtr.base = base;
  idtr.limit = IDT_ENTRIES * sizeof(idt_entry_t) - 1;
  asm_lidt(p);
  asm("sidt %0"::"m"(idtr));

  return 0;
}

/* MA FCT DE LA MORT */
int	int_init(void)
{
  idt_init();
#ifdef DEBUG_INT
  printf("idt initialise\n");
#endif
  exception_init();
#ifdef DEBUG_INT
  printf("exception initialise\n");
#endif
  log_int_init();
#ifdef DEBUG_INT
  printf("interruption logicielle initialise\n");
#endif
  irq_init();
#ifdef DEBUG_INT
  printf("irq initialise\n");
#endif
  load_idtr((t_uint32)idt);
  pic_init();
#ifdef DEBUG_INT
  printf("pic initialise\n");
#endif
  return 0;
}


/*!
**
**
** @param start
** @param size
** @param pl
** @param type
** @param segid
**
** @return
*/

int				int_rsv(t_uint8		entry,
					t_inttype	type,
					t_segid		segid,
					t_pl		pl,
					t_vaddr		handler)
{
  /*
  ** Interrupt Gate
  */
  t_inttype	type2 = type;
  t_segid	segid2 = segid;
  t_pl		pl2 = pl;

  type = type2;
  segid = segid2;
  pl = pl2;

  if (type == INT_TYPE_INT)
    {
      /* Base */
      if (entry < EXCEPTION_ENTRIES)
	exception_set_routine(entry, (exception_handler_t)handler);
      else
	if (entry < IRQ_ENTRIES + EXCEPTION_ENTRIES)
	  irq_set_routine(entry - EXCEPTION_ENTRIES, (irq_handler_t)handler);
	else
	  if (entry < IRQ_ENTRIES + EXCEPTION_ENTRIES + LOG_INT_ENTRIES)
	    log_int_set_routine(entry - EXCEPTION_ENTRIES - IRQ_ENTRIES, (log_int_handler_t)handler);
	  else
	    return -ERROR_WRONG_ARG;
      /* idt[entry].seg_sel = segid;
       idt[entry].p = 1;
       idt[entry].flags = 0;
       idt[entry].type = 6;
       idt[entry].dpl = pl;
       idt[entry].zero = 0;
       */
    }

  /*
  ** Trap Gate
  */
  if (type == INT_TYPE_TRAP)
    {
      if (entry < EXCEPTION_ENTRIES)
	exception_set_routine(entry, (exception_handler_t)handler);
      else
	if (entry < IRQ_ENTRIES + EXCEPTION_ENTRIES)
	  irq_set_routine(entry - EXCEPTION_ENTRIES, (irq_handler_t)handler);
	else
	  return -ERROR_WRONG_ARG;
/*       idt[entry].seg_sel = segid; */
/*       idt[entry].p = 1; */
/*       idt[entry].flags = 0; */
/*       idt[entry].dpl = pl; */
/*       idt[entry].type = 7; */
    }

  /*
  ** Task Gate
  */
  if (type == INT_TYPE_TASK)
    {
      /*      idt[entry].p = 1;
      idt[entry].dpl = pl;
      idt[entry].type = 5;
      idt[entry].seg_sel = segid;*/
    }
  return load_idtr((unsigned int) idt);
}


/*
** Mettre la case du tableau de fct a 0
*/
int	int_rel(t_uint8 entry)
{
  if (entry < EXCEPTION_ENTRIES)
	exception_rm_routine(entry);
      else
	if (entry < IRQ_ENTRIES + EXCEPTION_ENTRIES)
	  irq_rm_routine(entry - EXCEPTION_ENTRIES);
	else
	  return -ERROR_WRONG_ARG;
  /*  idt[entry].seg_sel = 0;
  idt[entry].flags = 0;
  idt[entry].type = 0;
  idt[entry].gate_size = 0;
  idt[entry].zero = 0;
  idt[entry].dpl = 0;
  idt[entry].p = 0;*/
  return load_idtr((unsigned int) idt);
}

/*
** A changer : mettre le tabeau de fct a sa valeur init
*/
int	int_clear(void)
{
 exception_init();
 irq_init();
 pic_init();
 return load_idtr((t_uint32)idt);
}

