/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Mon Sep 26 19:56:03 2005 Nicolas Clermont
** Last update Thu Oct 20 18:32:30 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef TEST_H_
# define TEST_H_

# include "../../lib/memory/as.h"
# include "../../lib/memory/pm.h"
# include "../../lib/memory/vm.h"
# include "../../lib/memory/mm.h"
# include "../../lib/memory/ia-32/vm_print_ascii.h"
# include "../../lib/list/list.h"
# include "../../lib/console/console.h"
# include "../idt/interruption.h"
# include "../../lib/shell/parse_conf.h"
# include "../recover.h"
# include "../../bootloader/phys_mem_mapping.h"
# include "../../bootloader/ch_cr.h"
# include "../task/task.h"
# include "../thread/thread.h"
# include "../mod/mod.h"
# include "../scheduler/scheduler.h"

/*!
** Test the memory
*/
void	test_area(void);
void	test_pm_rel(void);
void	print_kernel_vm(void);
void	debug_mem(void);

void	test_malloc();

/*!
** Test task/thread/exec
*/
void	launch_console(void);
int	test_mod_load_entry(void);
int	test_mod_function(void);
int	test_task_thread(void);

/*!
** Test interruption
*/
void	test_div_zero(void);

/*!
** Test IDE driver
*/
void	test_ide(void);

/*!
** Test sets
*/
void	test_set(void);

#endif	/* !TEST_H_ */
