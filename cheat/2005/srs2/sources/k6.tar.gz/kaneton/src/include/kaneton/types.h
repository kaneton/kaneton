/*
** types.h for kaneton K1 in /u/a2/castai_a
**
** Made by antoine castaing
** Login   <castai_a@epita.fr>
**
** Started on  Sat Feb  5 13:54:43 2005 antoine castaing
** Last update Sun Oct  9 20:11:30 2005 Antoine Castaing
*/

#ifndef KANETON_TYPES_H_
# define KANETON_TYPES_H_

/* # include <sys/param.h> */
/* # include "tmp.h" */

typedef unsigned int	t_uint32;
typedef unsigned short	t_uint16;
typedef unsigned char	t_uint8;
typedef signed char	t_sint8;
typedef signed short	t_sint16;
typedef signed int	t_sint32;

# define NULL	0

typedef enum e_bool
  {
    true,
    false
  } t_bool;

#define PAGE_SIZE	4096

#define KASID	1

int	mem_upper;

# define PL_KERNEL	0x00
# define PL_SERVICE	0x01
# define PL_USER	0x03

# define PL_READ	0x04
# define PL_WRITE	0x08
# define PL_EXEC	0x10

# define SEG_TYPE_MEM	0x00
# define SEG_TYPE_TSS	0x01

# define INT_TYPE_INT	0x00
# define INT_TYPE_TRAP	0x01
# define INT_TYPE_TASK	0x02
# define INT_TYPE_CALL	0x03

typedef unsigned char		byte;
typedef unsigned int		word;
typedef signed long		slong;
typedef unsigned long		dword;

typedef t_uint32 t_id;

typedef t_uint32 t_size;

typedef t_uint32 t_paddr;

typedef t_uint32 t_vaddr;

typedef t_uint32 t_psize;

typedef t_uint32 t_vsize;

typedef t_uint32 t_pattr;

typedef t_uint32 t_vattr;

typedef t_uint8  t_inttype;

typedef t_uint16 t_pl;

typedef t_uint8  t_segtype;

typedef t_uint32 t_segid;

typedef t_uint32 t_asid;

typedef t_uint16 t_pmflags;

typedef t_uint16 t_vmflags;

typedef t_uint32 t_event_id;

typedef t_id t_thrid;

typedef t_id t_trapid;

typedef t_id t_tskid;


#define ID_UNUSED	((t_id) -1)

typedef	t_id	t_modid;
typedef	t_id	t_ownid;

/* Lifetime of a module */
#define	LIFETIME_INFINITE	0x1
#define	LIFETIME_FINITE		0x2

typedef t_uint8	t_lifetime;

/*
** Union permettant une decoupe des valeurs
*/
union u_easy_convert_valeur
{
  t_uint32	val32;
  t_uint32	val31:31;
  t_uint32	val30:30;
  t_uint32	val29:29;
  t_uint32	val28:28;
  t_uint32	val27:27;
  t_uint32	val26:26;
  t_uint32	val25:25;
  t_uint32	val24:24;
  t_uint32	val23:23;
  t_uint32	val22:22;
  t_uint32	val21:21;
  t_uint32	val20:20;
  t_uint32	val19:19;
  t_uint32	val18:18;
  t_uint32	val17:17;
  t_uint32	val16:16;
  t_uint32	val15:15;
  t_uint32	val14:14;
  t_uint32	val13:13;
  t_uint32	val12:12;
  t_uint32	val11:11;
  t_uint32	val10:10;
  t_uint32	val9:9;
  byte		val8:8;
  byte		val7:7;
  byte		val6:6;
  byte		val5:5;
  byte		val4:4;
  byte		val3:3;
  byte		val2:2;
  byte		val1:1;
};

#endif /* !KANETON_TYPES_H_ */
