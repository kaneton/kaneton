#ifndef CPU_
# define CPU_

/*int get_eip(void);*/
int get_esp(void);
int get_ebp(void);
int get_eax(void);
int get_ebx(void);
int get_ecx(void);
int get_edx(void);

#endif /* !CPU_ */
