/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Feb 28 03:45:00 2005 Damien Laniel
** Last update Wed Nov 16 01:30:13 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "phys_mem_mapping.h"
#include "ch_cr.h"
#include "../lib/console/console.h"
#include "../lib/memory/pm.h"
#include "../lib/memory/vm.h"
#include "../lib/memory/as.h"
#include "../lib/memory/ia-32/vm_area.h"

/*!
** Fill the page pt with 0
** @param	pt	Address of the page to init
*/
void		init_page(t_pte *pt)
{
  register int	i = 0;

  for (; i < 1024; ++i)
    pt[i] = 0;
}

/*!
** Add at the first free entry of pd address | mask
** @param	pd	Address of the page directory
** @param	mask	Mask to aplly to the page table
** @param	address	Physical address of the page table
** @return	index or -1 if the pd is full
*/
static int	add_page_entry_first_fit(word *pd, int mask,
					 t_paddr address)
{
  unsigned int	i = 0;

  for (; i < 1024; ++i)
    if (pd[i] == 0)
      {
	pd[i] = address | mask;
	return i;
      }

  return -1;
}

/*!
** Add (address | mask) at the entry pos of pd
** @param	pd	Address of the page directory
** @param	mask	Mask to apply to the page table
** @param	address	Physical address of the page table
** @param	pos	Index of the entry in the pd
*/
static void	add_page_entry_pos(word *pd, word mask,
				   t_paddr address, int pos)
{
  pd[pos] = address | mask;
/*   printf("add_page_entry_pos pd[pos]  %x\n", pd[pos]); */
}

/*!
** Map the 1024 first physical pages in the pti
** @param	pti	Address of the pti
** @param	mask	Mask to apply on each entry (so page)
*/
static void	identity_mapping(t_pte *pti, int mask)
{
  unsigned int	i = 0;

  for (; i < 1024; ++i)
    add_page_entry_first_fit(pti, mask, i * 4096);
}

/*!
** Create a new page table and its entry in the page directory
** @param	pd		Virtual address of the page directory
** @param	pt_paddr	Physical address of the new page table
** @param	pt_vaddr	Virtual address of the new page table
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int		create_new_pt(t_vaddr pd_vaddr, t_paddr pt_paddr,
			      t_vaddr pt_vaddr, int protection_mode)
{
  int		mask_pde = PRESENT | D;

  if (pd_vaddr == 0 || pt_paddr == 0)
    return 1;

  mask_pde |= protection_mode;
  init_page((t_pte *)pt_vaddr);
  add_page_entry_first_fit((word*)pd_vaddr, mask_pde, pt_paddr);

  return 0;
}

/*!
** Create a new page table and its entry in the pd at pos
** @param	pd		Address of the page directory
** @param	pt_paddr	Physical address of the new page table
** @param	pos		Index in the page directory
** @param	pt_vaddr	Virtual address of the new page table
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int		create_new_pt_at(t_vaddr pd_vaddr, t_paddr pt_paddr, int pos,
				 t_vaddr pt_vaddr, int protection_mode)
{
  int		mask_pde = PRESENT | D;

  if (pd_vaddr == 0 || pt_paddr == 0)
    return 1;

  mask_pde |= protection_mode;
  init_page((t_pte *)pt_vaddr);
  add_page_entry_pos((word*)pd_vaddr, mask_pde, pt_paddr, pos);

  return 0;
}

/*!
** Map a page and return the index of the pt entry
** @param	pt_vaddr	Linear address of the pt in which to map
** @param	page		Address of the page to map
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int		map_new_page(t_vaddr pt_vaddr, t_paddr page,
			     int protection_mode)
{
  int		index = -1;
  int		mask_pte = PRESENT;

  if (pt_vaddr == 0 || page == 0)
    return 1;

  mask_pte |= protection_mode;
  index = add_page_entry_first_fit((word*)pt_vaddr, mask_pte, page);

  return index;
}

/*!
** Map a page at entry index in the pt
** @param	pt_vaddr	Linear address of the pt in which to map
** @param	page		Address of the page to map
** @param	index		Index in the page table
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int		map_new_page_at(t_vaddr pt_vaddr, t_paddr page,
				int index, int protection_mode)
{
  int		mask_pte = PRESENT;

  if (pt_vaddr == 0 || page == 0)
    return 1;

  mask_pte |= protection_mode;
/*   printf("mask pte %x pt_vaddr %x page %x index %d", mask_pte, pt_vaddr , page, index); */
  add_page_entry_pos((word*)pt_vaddr, mask_pte, page, index);

  return 0;
}

/*!
** Map a page table at the entry index of pd
** @param	pd_vaddr	Virtual address of the page table used for map
** @param	pt_paddr	Physical address of the page table to map
** @param	index		Index in the page table
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int		map_pt_at(t_vaddr pd_vaddr, t_paddr pt_paddr,
			  int index, int protection_mode)
{
  int		mask_pde = PRESENT | D;

  if (pd_vaddr == 0 || pt_paddr == 0)
    return 1;

  mask_pde |= protection_mode;
  add_page_entry_pos((word*)pd_vaddr, mask_pde, pt_paddr, index);

  return 0;
}

/*!
** FIXME : A REVOIR AVEC SET_PD_ADDR / MODULES EN MEMOIRE HAUTE
*/
static int	tcreate_new_pt_at(t_vaddr pd_vaddr, t_paddr pd_paddr, t_paddr pt_paddr,
				  int pos, t_vaddr pt_vaddr, int protection_mode)
{
  int		mask = PRESENT | D;

  if (pd_vaddr == 0 || pt_paddr == 0)    return 1;
  mask |= protection_mode;
  set_pd_address(pd_paddr);
  init_page((t_pte *)pt_vaddr);
  set_pd_address((unsigned int)PD_ENTRY);
  add_page_entry_pos((word*)pd_vaddr, mask, pt_paddr, pos);

  return 0;
}

/*!
** Map the page at the physical address paddr to the virtual address vaddr
** @param	pd_vaddr	Virtual address of the page directory of the as
** @param	vaddr		Virtual address where to map the page
** @param	paddr		Physical address of the page to map
** @param	asid		Identifier of the address space
** @param	pd_paddr	Physical address of the pd of the as asid
*/
/* # define DEBUG_MAP 1 */
int		map_page_vaddr(t_vaddr pd_vaddr, t_vaddr vaddr, t_paddr paddr,
			       t_asid asid, t_paddr pd_paddr)
{
  unsigned int	save_cr3 = (unsigned int)get_CR3();
  int		pd_entry = 0;
  int		pt_entry = 0;
  t_paddr	pt_paddr = 0;
  t_vaddr	pt_vaddr = 0;
  t_paddr	ptt_paddr = 0;
  t_vaddr	ptt_vaddr = 0;
  t_vm_area	*pt_vm_area;
  t_vm_area	fake_vm_area;
  t_as		*as;

  /*   KERNEL SPACE */
  set_pd_address((unsigned int)PD_ENTRY);

  if (!pd_vaddr)
    return 1;

  pd_entry = vaddr >> 22;
  vaddr -= (vaddr >> 22) << 22;
  pt_entry = vaddr >> 12;

#ifdef DEBUG_MAP
  if (asid == 2)
    {
      printf("CR3 : %x\n", save_cr3);
      printf("ASID : %d\n", asid);
      printf("PHYSICAL PD ADDR <%x>\n", pd_paddr);
      printf("PTT ADDR         <%x>\n", VIRTUAL_PTT);
      printf("VIRTUAL  PD ADDR <%x>\n", pd_vaddr);
      printf("pd_entry : %d\n", pd_entry);
      printf("((word *)pd_vaddr)[pd_entry] : %x\n", ((word *)pd_vaddr)[pd_entry]);
      /*       while (1); */
    }
#endif

  if (!((word *)pd_vaddr)[pd_entry])
    {
      /* The page table doesn't exist. We need to create it. */
      pm_rsv(asid, &pt_paddr, 1, PM_FLAG_ANY);
      /* LA PTT USER EST MAPPE DS PTPD ! */
      /* PAS BESOIN DE CHANGER D'AS POUR MAPPER LA NOUVELLE PT DS PTT USER */
      /* ptt_paddr = vm_to_pm(as->pd_vaddr, VIRTUAL_PTT, asid, as->pd_addr); */
      /* pt_pm_to_vm(asid, ptt_paddr);*/
      if (asid != KASID)
	{
	  ptt_paddr = (((word *)pd_vaddr)[2] >> 12) * PAGE_SIZE;
	  ptt_vaddr = ptm_pm_to_vm(asid, ptt_paddr);
	}
      else
	{
	  ptt_paddr = PTT_ENTRY;
	  ptt_vaddr = VIRTUAL_PTT;
	}
/* #ifdef DEBUG_MAP */
/*       if (paddr == 0x129000) */
/* 	{ */
/* 	  printf("ptt_paddr : %x\n", ptt_paddr); */
/* 	  printf("ptt_vaddr : %x\n", ptt_vaddr); */
/* 	  while (1); */
/* 	} */
/* #endif */
      /*       USER SPACE  */
      /*       set_pd_address(pd_paddr); */
      pt_vaddr = PTT_PDE << 22;
      pt_vaddr |= (map_new_page(ptt_vaddr, pt_paddr, USER | RW)) << 12;
      tcreate_new_pt_at(pd_vaddr, pd_paddr, pt_paddr, pd_entry, pt_vaddr, USER | RW);
      /* Create the vm_area describing the new PT */
      vm_rsv(asid, &pt_vaddr, 1, VM_FLAG_SPECIFIC);
      vm_area_init(pt_vaddr, 0, 0, 0, 0, &fake_vm_area);
      as_get(asid, &as);
      pt_vm_area = (t_vm_area *)list_find_item(as->vas_used, &fake_vm_area,
					    vm_area_cmp_start);
      pt_vm_area->mapped_pm_area = pt_paddr;

#ifdef DEBUG_MAP
      if (asid == 2)
	{
	  printf("PTT : %x, PT ADDR : %x, PADDR : %x\n", VIRTUAL_PTT, pt_paddr, paddr * PAGE_SIZE);
	  printf("PTENTRY : %x, VADDR : %x\n", pt_entry, vaddr);
	  printf("PT VADDR : %x, PADDR : %x, PT_PADDR : %x\n", pt_vaddr, paddr, pt_paddr);
	  printf("ASID : %d\n", asid);
	  /* 	  while (1); */
	}
#endif
      /* USER SPACE */
      set_pd_address(pd_paddr);
/*       printf("1ere entree (vide) : %x\n", ((word *)pt_vaddr)[0]); */
      map_new_page_at(pt_vaddr, paddr, pt_entry, USER | RW);
/*       printf("1ere entree : %x\n", ((word *)pt_vaddr)[0]); */
    }
  else
    {
      /* The page table exists. Just fill the entry desired.*/
      pt_paddr = (((word *)pd_vaddr)[pd_entry] >> 12) * PAGE_SIZE;
      pt_vaddr = pt_pm_to_vm(asid, pt_paddr);
     /*  printf("pt_entry : %d pd_paddr : %x pt_vaddr : %x\n", pt_entry, pd_paddr, pt_vaddr); */
      /*       USER SPACE */
      set_pd_address(pd_paddr);
      if (!(((word *)pt_vaddr)[pt_entry]))
	{
	  map_new_page_at(pt_vaddr, paddr, pt_entry, USER | RW);
	  if (((word *)pt_vaddr)[0] & D)
	    ((word *)pt_vaddr)[0] -= D;
/* 	  printf("1ere entree : %x\n", ((word *)pt_vaddr)[0]); */
/* 	  printf("2ere entree : %x\n", ((word *)pt_vaddr)[1]); */
	}
      else
	printf("C�st occupe !!\n");
    }
  /*   USER SPACE */
  /*   set_pd_address(pd_paddr); */
  set_pd_address(save_cr3);
  return 0;
}

/*!
** Unmap the page at the linear address vaddr
** @param	pd	Virtual address of the page directory of the as
** @param	vaddr	Virtual address of the page to unmap
** @param	pd_addr	Physical address of the pd of the as asid
** @param	asid	Identifier of the address space
*/
int		unmap_page_vaddr(t_vaddr pd_vaddr, t_vaddr vaddr,
				 t_paddr pd_paddr, t_asid asid)
{
  int		i = 0;
  int           pd_entry = 0;
  int           pt_entry = 0;
  t_paddr       pt_paddr = 0;
  t_vaddr	pt_vaddr = 0;

  if (!pd_vaddr)
    return 1;

  pd_entry = vaddr >> 22;
  vaddr -= (vaddr >> 22) << 22;
  pt_entry = vaddr >> 12;

  /* KERNEL SPACE*/
  set_pd_address((unsigned int)PD_ENTRY);
  if (!(pt_paddr = ((word *)pd_vaddr)[pd_entry]))
    return 1;

  /* USER SPACE*/
  pt_paddr = (pt_paddr >> 12) * PAGE_SIZE;
  set_pd_address((unsigned int)pd_paddr);
  pt_vaddr = pt_pm_to_vm(asid, pt_paddr);
  if (!((word *)pt_vaddr)[pt_entry])
    return 1;
  ((word *)pt_vaddr)[pt_entry] = 0;
  /* Delete the page table if empty */
  for (i = 0; i < 1024; i++)
    if (((word *)pt_vaddr)[i])
      break;
  if (i == 1024)
    /* FIXME : delete the page table if it has no more entry */
    printf("The page table is empty, ready to be deleted.\n");
  return 0;
}

/*!
** Get the index (in the kernel PD) of the PT pt_addr
** @param	
*/
int		get_pt_index(t_vaddr pt_addr)
{
  return 0;
}

/*!
** Start the paging. Initialize the system page tables needed by
** the kernel to run
** @param	kern	Kernel physical address
*/
int		launch_paging(t_paddr kern)
{
  int		i;

  /* Create the page directory and all the page tables */
  init_page((t_pde *)PD_ENTRY);
  create_new_pt(PD_ENTRY, PTI_ENTRY, PTI_ENTRY, SUPERUSER | RW);
  identity_mapping((t_pte *)PTI_ENTRY, PRESENT | RW | SUPERUSER);
  create_new_pt(PD_ENTRY, PTM_ENTRY, PTM_ENTRY, SUPERUSER | RW);
  create_new_pt(PD_ENTRY, PTT_ENTRY, PTT_ENTRY, SUPERUSER | RW);
  create_new_pt_at(PD_ENTRY, PTK_ENTRY, PTK_PDE, PTK_ENTRY, SUPERUSER | RW);
  create_new_pt(PD_ENTRY, PTAS_ENTRY, PTAS_ENTRY, SUPERUSER | RW);
  create_new_pt(PD_ENTRY, PTPD_ENTRY, PTPD_ENTRY, SUPERUSER | RW);
  /* Map the page tables and the needed system pages */
  map_new_page(PTAS_ENTRY, ASLIST, SUPERUSER | RW);
  map_new_page(PTAS_ENTRY, PASLIST, SUPERUSER | RW);
  map_new_page(PTAS_ENTRY, AREA_VM, SUPERUSER | RW);
  map_new_page(PTM_ENTRY, PTT_ENTRY, SUPERUSER | RW);
  map_new_page(PTM_ENTRY, AREA, SUPERUSER | RW);
  map_new_page(PTT_ENTRY, GDT_ENTRY, SUPERUSER | RW);
  map_new_page(PTT_ENTRY, PTI_ENTRY, SUPERUSER | RW);
  map_new_page(PTT_ENTRY, PTM_ENTRY, SUPERUSER | RW);
  map_new_page(PTT_ENTRY, PTK_ENTRY, SUPERUSER | RW);
  map_new_page(PTT_ENTRY, PTAS_ENTRY, SUPERUSER | RW);
  map_new_page(PTT_ENTRY, PTPD_ENTRY, SUPERUSER | RW);
  /* Map kernel code ReadOnly */
  for (i = 0; i < K_NPAGES; i++)
    map_new_page(PTK_ENTRY, kern + PAGE_SIZE * i,
		 SUPERUSER | RDONLY);

  return 0;
}
