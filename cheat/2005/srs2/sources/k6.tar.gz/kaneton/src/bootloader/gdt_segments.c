/*
** Copyright (C) Decool Laurent aka traktopel <laurent.decool@gmail.com>
**
** Part of Kaneton
**
** Started on  Mon Feb 28 03:50:00 2005 Damien Laniel
** Last update Wed Dec  7 10:26:30 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "gdt_segments.h"
#include "phys_mem_mapping.h"
#include "../include/kaneton/types.h"
#include "../lib/console/console.h"

struct s_gdt_segment *gdt = (struct s_gdt_segment *) GDT_ENTRY;
t_segid	g_max_seg_id;
int	seg_init(void)
{
  g_max_seg_id = 0;
  /* Limit */
  gdt[0].limit = 0x0000;
  gdt[0].limit2 = 0x0;
  /* Base */
  gdt[0].base = 0x0000;
  gdt[0].base2 = 0x00;
  gdt[0].base3 = 0x00;
  /* Type */
  gdt[0].type = 0x0;
  /* S */
  gdt[0].s = 0;
  /* DPL = Descriptor Privilege Level */
  gdt[0].dpl = 0;
  /* P = Present */
  gdt[0].p = 0;
  /* AVL = Available */
  gdt[0].avl = 0;
  /* 0 */
  gdt[0].o = 0;
  /* B = Big */
  gdt[0].b = 0;
  /* G = granularity */
  gdt[0].g = 0;
  g_max_seg_id++;
  return load_gdtr(g_max_seg_id, (unsigned int) gdt);
}

/*!
**
**
** @param start
** @param size
** @param pl
** @param type
** @param segid
**
** @return
*/
int				seg_add(t_paddr		start,
					t_paddr		size,
					t_pl		pl,
					t_segtype	type,
					t_segid		*segid,
					int		s,
					int		b,
					int		g,
					int		avl)
{
/*   int				code_or_data = 0; */
  union u_easy_convert_valeur	base;
  union u_easy_convert_valeur	limit;
  union u_easy_convert_valeur	tmp_pl;

  type = type;

  base.val32 = start;
  limit.val32 = size & 0xFFFFF;
  tmp_pl.val32 = pl;
/*   int val = 0; */

  *segid = g_max_seg_id++;

  /* Limit */
  gdt[*segid].limit = limit.val16;
  limit.val32 = limit.val32 >> 16;
  gdt[*segid].limit2 = limit.val4;



 /* Base */
  gdt[*segid].base = base.val16;
  base.val32 = base.val32 >> 16;
  gdt[*segid].base2 = base.val8;
  base.val32 = base.val32 >> 8;
  gdt[*segid].base3 = base.val8;


  /* S */
  gdt[*segid].s = s;
  /* DPL = Descriptor Privilege Level */

  gdt[*segid].dpl = tmp_pl.val2;

  tmp_pl.val32 = tmp_pl.val32 >> 2;

/*   while (1); */

  /*si c en READ-ONLY c un segment de data*/
  if (tmp_pl.val3 == 1)
    {
      tmp_pl.val32 = 0;
    }
  /*si c en READ/WRITE c un segment de data*/
  if (tmp_pl.val3 == 3)
    {
      tmp_pl.val32 = 0x2;
    }
  /*si c 7 alors c un tss*/
  if (tmp_pl.val3 == 7)
    {
      tmp_pl.val32 = 0x9;
    }
  /*si c en EXECUTE-ONLY c un segment de code*/
  if (tmp_pl.val32 == 4)
    {
      tmp_pl.val32 = 0x8;
    }
  /*si c en EXECUTE/READ c un segment de code*/
  if (tmp_pl.val32 == 5)
    {
      tmp_pl.val32 = 0xA;
    }

  /* Type */
  gdt[*segid].type = tmp_pl.val32;
  /* P = Present */
  gdt[*segid].p = 1;
  /* AVL = Available */
  gdt[*segid].avl = avl;
  /* 0 */
  gdt[*segid].o = 0;
  /* B = Big */
  gdt[*segid].b = b;
  /* G = granularity */
  gdt[*segid].g = g;
  return load_gdtr(g_max_seg_id, (unsigned int) gdt);
}

int				seg_modify(t_segid	segid,
					   t_paddr	start,
					   t_paddr	size,
					   t_pl		pl,
					   t_segtype	type)
{
  union u_easy_convert_valeur	base;
  union u_easy_convert_valeur	limit;
  union u_easy_convert_valeur	tmp_pl;

  type = type;

  base.val32 = start;
  limit.val32 = size;
  tmp_pl.val32 = pl;

  /* Limit */
  gdt[0].limit = limit.val16;
  limit.val32 = limit.val32 >> 16;
  gdt[segid].limit2 = limit.val4;


  /* Base */
  gdt[segid].base3 = base.val8;
  base.val32 = base.val32 >> 8;
  gdt[segid].base2 = base.val8;
  base.val32 = base.val32 >> 8;
  gdt[segid].base = base.val16;
  /* DPL = Descriptor Privilege Level */
  gdt[segid].dpl = tmp_pl.val3;
  tmp_pl.val32 = tmp_pl.val32 >> 3;
  /* Type */
  /*Le masque sert pour conserver le status du segment (data, code, ...)*/
  gdt[segid].type = gdt[segid].type & 0x8;
  gdt[segid].type += tmp_pl.val3;
  return load_gdtr(g_max_seg_id, (unsigned int) gdt);
}

int	seg_remove(t_segid segid)
{
  for (; segid < g_max_seg_id; segid++)
    gdt[segid] = gdt[segid + 1];
  g_max_seg_id -= 1;
  return load_gdtr(g_max_seg_id, (unsigned int) gdt);
}

int	seg_clear(void)
{
  g_max_seg_id = 0;
  return load_gdtr(g_max_seg_id, (unsigned int) gdt);
}

int		load_gdtr(int nb_segments, unsigned int base)
{
  struct s_gdtr	gdtr;

/*   printf("nb segment <%d>\n", nb_segments); */
  gdtr.limit = nb_segments * sizeof(struct s_gdt_segment);
  gdtr.base = base;
  asm("lgdt %0"::"m"(gdtr));
  return 0;
}
