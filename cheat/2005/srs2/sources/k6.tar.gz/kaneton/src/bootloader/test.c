/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Wed Oct  5 16:33:42 2005 Damien Laniel
** Last update Wed Oct  5 16:34:11 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

int power(int nb, int expon)
{
  if (expon == 0)
    return 1;
  return (nb * power(nb, expon - 1));
}
/*!
** Print an integer on the console
**
** @param console	pointer to console address
** @param attrib	character attributes
** @param i		integer to print
** @param base		base of i (2, 10, 16, ...)
*/
void    cons_print_int_base(int nb,
			    int base)
{
  int   i = 0;
  int	j = 0;
  int	b = 0;
  int   nb_tmp = nb;

  if (nb == 0)
    {
      printf("%c", '0');
      return;
    }
  for (b = base; nb_tmp / b > 0; ++i, nb_tmp /= b)
    ;
  for (j = 0; nb >= 0 && i >= 0; ++j, --i)
    {
      printf("%c", (nb / power(b, i) + '0'));
      nb -= (nb / power(b, i)) * power(b, i);
    }
}

int main ()
{
  int	i = 0;

/*   for (; i < 2; ++i) */
  cons_print_int_base(15, 10);
  return 0;
}
