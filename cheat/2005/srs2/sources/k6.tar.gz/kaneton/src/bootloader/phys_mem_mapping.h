/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Feb 28 03:48:12 2005 Damien Laniel
** Last update Mon Nov 21 01:41:18 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef PHYS_MEM_MAPPING_H_
# define PHYS_MEM_MAPPING_H_

#include "struct_mapping.h"

# define PTI_PDE	0x0
# define PTM_PDE	0x1
# define PTT_PDE	0x2
# define PTAS_PDE	0x3
# define PTPD_PDE	0x4
# define PTK_PDE	768
# define K_NPAGES       29
# define STACK_ADDR	0x300000

/*
** Addresses des structures systemes
*/
# define GDT_ENTRY	0x2000
# define PD_ENTRY	0x3000
# define PTK_ENTRY	0x4000
# define PTT_ENTRY	0x5000
# define PTM_ENTRY	0x6000
# define AREA		0x7000
# define PTI_ENTRY	0x8000
# define PTAS_ENTRY	0x9000
# define ASLIST		0xa000
# define AREA_VM	0xb000
# define PASLIST	0xc000
# define PTPD_ENTRY	0xd000
# define TSS		0xe000
# define SCHED_ENTRY	0xf000
/*
** GRUB_ADDR utilisee pour la recuperation du multiboot,
*/
# define GRUB_ADDR	0x204000
# define IDT_ADDR	0x200000
# define VIRTUAL_PTT	0x400000
# define VIRTUAL_PTM	0x802000
# define VM_AREA	0x401000
# define VM_ASLIST	0xc00000
# define VIRTUAL_GDT	0x800000

/*
** Les flags s'appliquant sur les pages
*/
# define SUPERUSER	0
# define RDONLY		0
# define PRESENT	1
# define RW		2
# define USER		4
# define PWT		8
# define PCD		16
# define ACCESSED	32
# define D		64
# define PS		128
# define G		256

/*
** Adresses des modules charges par Grub
*/
t_paddr			kern_addr;
t_psize			kern_npages;
t_paddr			file_conf_addr;
t_paddr			console_addr;
t_paddr			console_addr2;
t_size			console_size;
t_paddr			keyboard_addr;
t_size			keyboard_size;

/*!
** Fill the page pt with 0
** @param	pt	Address of the page to init
*/
void			init_page(t_pte *pt);

/*!
** Create a new page table and its entry in the page directory
** @param	pd		Virtual address of the page directory
** @param	pt_paddr	Physcical address of the new page table
** @param	pt_vaddr	Virtual address of the new page table
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int			create_new_pt(t_vaddr pd_vaddr, t_paddr pt_paddr,
				      t_vaddr pt_vaddr, int protection_mode);

/*!
** Create a new page table and its entry in the pd at pos
** @param	pd		Address of the page directory
** @param	new_pt		Physical address of the new page table
** @param	pos		Index in the page directory
** @param	v_pt		Virtual address of the new page table
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int			create_new_pt_at(t_vaddr pd_vaddr, t_paddr new_pt, int pos,
					 t_vaddr v_pt, int protection_mode);

/*!
** Map a page and return the index of the pt entry
** @param	pt_vaddr	Linear address of the pt in which to map
** @param	page		Address of the page to map
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int			map_new_page(t_vaddr pt_vaddr, t_paddr page,
				     int protection_mode);

/*!
** Map a page at entry index in the pt
** @param	pt_vaddr	Linear address of the pt in which to map
** @param	page		Address of the page to map
** @param	index		Index in the page table
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int			map_new_page_at(t_vaddr pt_vaddr, t_paddr page,
					int index, int protection_mode);

/*!
** Map a page table at the entry index of pd
** @param	pd_vaddr	Linear address of the page table used for map
** @param	pt_paddr	Physical address of the page table to map
** @param	index		Index in the page table
** @param	protection_mode (USER ou SUPERUSER) | (RW ou RDONLY)
*/
int			map_pt_at(t_vaddr pd_vaddr, t_paddr pt_paddr,
				  int index, int protection_mode);

/*!
** Map the page at the physical address paddr to the virtual address vaddr
** @param	pd_vaddr	Virtual address of the page directory of the as
** @param	vaddr		Virtual address where to map the page
** @param	paddr		Physical address of the page to map
** @param	asid		Identifier of the address space
** @param	pd_paddr	Physical address of the pd of the as asid
*/
int			map_page_vaddr(t_vaddr pd_vaddr, t_vaddr vaddr, t_paddr paddr,
				       t_asid asid, t_paddr pd_paddr);

/*!
** Unmap the page at the linear address vaddr
** @param	pd_vaddr	Virtual address of the page directory of the as
** @param	vaddr		Virtual address of the page to unmap
** @param	pd_paddr	Physical address of the pd of the as asid
** @param	asid		Identifier of the address space
*/
int			unmap_page_vaddr(t_vaddr pd_vaddr, t_vaddr vaddr,
					 t_paddr pd_paddr, t_asid asid);

/*!
** Start the paging. Initialize the system page tables needed by
** the kernel to run
** @param	kern	Kernel physical address
*/
int			launch_paging(t_paddr kern);

#endif			/* !PHYS_MEM_MAPPING_H_ */
