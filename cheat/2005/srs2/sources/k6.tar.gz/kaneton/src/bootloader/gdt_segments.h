/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Feb 28 02:41:30 2005 Damien Laniel
** Last update Tue Mar  8 17:51:06 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef GDT_SEGMENTS_H_
# define GDT_SEGMENTS_H_

# include "../include/kaneton/types.h"

/* t_segid	g_max_seg_id; */

struct s_gdtr
{
  unsigned short limit;
  unsigned int base;
} __attribute__((packed));

typedef struct		s_tss
{
  t_uint16		link, unused0;
  t_uint32		esp0;
  t_uint16		ss0,  unused1;
  t_uint32		esp1;
  t_uint16		ss1,  unused2;
  t_uint32		esp2;
  t_uint16		ss2,  unused3;
  t_uint32		cr3;/*32*/
  t_uint32		eip;
  t_uint32		eflags;
  t_uint32		eax;
  t_uint32		ecx;
  t_uint32		edx;
  t_uint32		ebx;/*56*/
  t_uint32		esp;
  t_uint32		ebp;
  t_uint32		esi;
  t_uint32		edi;
  t_uint16		es,   unused4;
  t_uint16		cs,   unused5;/*80*/
  t_uint16		ss,   unused6;
  t_uint16		ds,   unused7;
  t_uint16		fs,   unused8;
  t_uint16		gs,   unused9;
  t_uint16		ldts, unused10;
  t_uint16		debugtrap, iomapbase;
} __attribute__ ((packed))	t_tss;


struct s_gdt_segment
{
  /* Limit (4Go) */
  unsigned short limit:16;
  /* Base */
  unsigned short base:16;
  byte	base2;
  /* Type */
  byte	type:4;
  /* S */
  byte	s:1;
  /* DPL */
  byte	dpl:2;
  /* P */
  byte	p:1;
  /* LIMIT */
  byte	limit2:4;
  /* AVL */
  byte	avl:1;
  /* 0 */
  byte	o:1;
  /* B */
  byte	b:1;
  /* G */
  byte	g:1;
  /* Base */
  byte	base3;
} __attribute__ ((packed));

int	seg_init(void);
int	seg_add(t_paddr		start,
		t_paddr		size,
		t_pl		pl,
		t_segtype	type,
		t_segid		*segid,
		int		s,
		int		b,
		int		g,
		int		avl);

int	seg_modify(t_segid	segid,
		   t_paddr	start,
		   t_paddr	size,
		   t_pl		pl,
		   t_segtype	type);

int	seg_remove(t_segid segid);
int	seg_clear(void);
int	load_gdtr(int nb_segments, unsigned int base);

#endif /* !GDT_SEGMENTS_H_ */
