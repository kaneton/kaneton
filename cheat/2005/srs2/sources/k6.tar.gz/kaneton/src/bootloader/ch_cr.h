/*
** Copyright (C) Antoine Castaing aka xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Sat Feb  5 13:42:59 2005 Antoine Castaing
** Last update Wed Oct 12 16:22:26 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef CH_CR_
# define CH_CR_

# include "../include/kaneton/types.h"

word	get_pd_address(void);
word	get_CR0(void);
word	get_CR1(void);
word	get_CR2(void);
word	get_CR3(void);
word	get_CR4(void);
word	get_EAX(void);
word	get_EBX(void);
word	get_ECX(void);
word	get_EDX(void);
word	get_EBP(void);
word	get_ESP(void);
void	set_CR0(word c);
void	set_CR3(word c);
void	set_32bits_mode(void);
void	set_pd_address(word address);
void	set_virtual_memory(void);
void	flush_tlb(void);

#endif /* !CH_CR_ */
