#include "cpu.h"

/*int get_eip(void)
{
  register unsigned int x;
  
  asm ("mov eip,eax":"=r"(x));
  
  
  return (x);
}*/

int get_esp(void)
{
  register unsigned int x;
  
  asm ("mov %%esp,%0":"=r"(x));
  return (x);
}

int get_ebp(void)
{
register unsigned int x;
  
  asm ("mov %%ebp,%0":"=r"(x));
  return (x);
}

int get_eax(void)
{
register unsigned int x;
  
  asm ("mov %%eax,%0":"=r"(x));
  return (x);
}

int get_ebx(void)
{
register unsigned int x;
  
  asm ("mov %%ebx,%0":"=r"(x));
  return (x);
}

int get_ecx(void)
{
register unsigned int x;
  
  asm ("mov %%ecx,%0":"=r"(x));
  return (x);
}

int get_edx(void)
{
register unsigned int x;
  
  asm ("mov %%edx,%0":"=r"(x));
  return (x);
}
