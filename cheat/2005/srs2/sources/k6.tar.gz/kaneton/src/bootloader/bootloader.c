/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Feb 28 03:48:23 2005 Damien Laniel
** Last update Mon Nov 14 03:21:03 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "multiboot.h"
#include "gdt_segments.h"
#include "ch_cr.h"
#include "struct_mapping.h"
#include "phys_mem_mapping.h"
#include "../lib/memory/as.h"
#include "../lib/memory/pm.h"
#include "../lib/console/console.h"
#include "../include/kaneton/types.h"

/* #define DEBUG	1 */

extern t_pm		*pm;
extern t_as_list	*as_list;

/*!
** This function is called cmain to avoid multiple definition of _start label
** the Struct given by Grub give us the number and the position of every module
**
** @param magic			Magic Number given by GRUB
** @param multiboot_struct	Structure given by GRUB
*/
int	cmain(unsigned long magic, unsigned long multiboot_struct)
{
  multiboot_info_t	*grub = (multiboot_info_t *) multiboot_struct;
  module_t		*module = (module_t *)grub->mods_addr;
  multiboot_info_t	*grub_cp = (multiboot_info_t *)GRUB_ADDR;
  char			*msg_vm = "Virtual Memory Started !!!";
  char			*msg_magic = "ERROR : Bad Magic Number";
  unsigned int		i = 0;
  extern t_segid	g_max_seg_id;
  unsigned int		mod_npages;

  init_ttys();
  *grub_cp = *grub;

  if (magic != MULTIBOOT_BOOTLOADER_MAGIC)
    {
      cons_print_string(msg_magic);
      while (1)
	;
    }

  mem_upper = grub->mem_upper;

  cons_clear_screen();
  cons_print_string("Number of modules : ");
  cons_print_int_base(grub->mods_count, 10);
  cons_goto_next_line();

  for (i = 0; i < grub->mods_count; ++i, ++module)
    {
      cons_print_string((char *) module->string);
      cons_goto_next_line();
    }
  cons_goto_next_line();

  module = (module_t *)grub->mods_addr;
  kern_addr = (unsigned long)module->mod_start;
  kern_npages = ((unsigned long)module->mod_end - kern_addr) / PAGE_SIZE;
  if (((unsigned long)module->mod_end - kern_addr) % PAGE_SIZE)
    kern_npages++;
  module++;
  file_conf_addr = (unsigned long)module->mod_start;
  module++;
  console_addr = (unsigned long)module->mod_start;
  console_size = (unsigned long)module->mod_end - console_addr;
  module++;
  console_addr2 = (unsigned long)module->mod_start;
  module++;
  keyboard_addr = (unsigned long)module->mod_start;
  keyboard_size = ((unsigned long)module->mod_end - keyboard_addr) / PAGE_SIZE;
  if (((unsigned long)module->mod_end - keyboard_addr) % PAGE_SIZE)
    keyboard_size++;

#ifdef DEBUG
  printf("KERN ADDR: Ox%x\n", kern_addr);
  printf("MODULE ADDR: Ox%x\n", file_conf_addr);
  printf("CONSOLE ADDR: Ox%x\n", console_addr);
  printf("CONSOLE SIZE: Ox%x\n", console_size);
  printf("CONSOLE2 ADDR: Ox%x\n", console_addr2);
  printf("KEYBOARD ADDR: Ox%x\n", keyboard_addr);
  printf("KEYBOARD SIZE: Ox%x\n", keyboard_size);
  while (1);
#endif

  pm_init(0, 0xffffffff);
  /*!
  ** Reserve the physical memory used by the modules
  ** TEMP : A plus CA quand fs et fichier modules
  */
  module = (module_t *)grub->mods_addr;
  module += 2;
  for (i = 2; i < grub->mods_count; ++i, ++module)
    {
      mod_npages = ((unsigned long)module->mod_end - (unsigned long)module->mod_start) / PAGE_SIZE;
      if (((unsigned long)module->mod_end - (unsigned long)module->mod_start) % PAGE_SIZE)
  	mod_npages++;
      pm_rsv(0, (t_paddr *)(&(module->mod_start)), mod_npages, PM_FLAG_SPECIFIC);
      }
  pm_rsv(0, (t_paddr *)GRUB_ADDR, 1, PM_FLAG_SPECIFIC);
  as_init();

  set_32bits_mode();

  asm(" ljmp $0x8,$next	\n \
      next:	        \n \
	mov $0x10,%ax	\n \
	mov %ax, %ds	\n \
	mov %ax, %es	\n \
	mov %ax, %fs	\n \
	mov %ax, %gs	\n \
	mov %ax, %ss	\n \
	nop	        \n \
	nop	        \n");

  launch_paging(kern_addr);

  set_pd_address((unsigned int)PD_ENTRY);
  set_virtual_memory();
  flush_tlb();
  cons_print_string(msg_vm);

  load_gdtr(g_max_seg_id, VIRTUAL_GDT);

  asm("	mov $0xc0000000, %eax \n \
	add $0x18, %eax	      \n \
	mov (%eax), %ebx      \n \
	jmp %ebx");

  while (1)
    ;
  return 0;
}
