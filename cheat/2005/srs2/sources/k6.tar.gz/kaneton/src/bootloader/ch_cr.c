/*
** Copyright (C) Antoine Castaing aka xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Sat Feb  5 13:42:59 2005 Antoine Castaing
** Last update Wed Oct  5 16:40:07 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "ch_cr.h"

/*!
** Set to 1 the PE flag of CR0 to enable protected mode
*/
void	set_32bits_mode(void)
{
  set_CR0(get_CR0() | 1);
}

/*!
** Get the Page Directory physical address
**
** @return physical address of the Page Directory
*/
word	get_pd_address(void)
{
  return (get_CR3() >> 12) << 12;
}

/*!
** Set the Page Directory physical address into CR3 register.
**
** @param address address of the Page Directory
*/
void	set_pd_address(word address)
{
  set_CR3(address);
}

/*!
** Set to 1 the PG flag of CR0 to activate virtual memory support.
*/
void	set_virtual_memory(void)
{
  unsigned long int	i = 1 << 31;

  set_CR0(get_CR0() | i);
}

/*!
** Make the processor refresh the TLB
*/
void	flush_tlb(void)
{
  set_CR3(get_CR3());
}

/*!
** Get CR0 register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of CR0
*/
word	get_CR0 (void)
{
  register unsigned int  x;

  asm ("mov %%cr0,%0":"=r"(x));
  return (x);
}

/*!
** Get CR1 register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of CR1
*/
word	get_CR1 (void)
{
  register unsigned int  x;

  asm ("mov %%cr1,%0":"=r"(x));
  return (x);
}

/*!
** Get CR2 register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of CR2
*/
word	get_CR2 (void)
{
  register unsigned int  x;

  asm ("mov %%cr2,%0":"=r"(x));
  return (x);
}

/*!
** Get CR3 register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of CR3
*/
word	get_CR3 (void)
{
  register word x;

  asm ("mov %%cr3,%0":"=r"(x));
  return (x);
}

/*!
** Get CR4 register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of CR4
*/
word	get_CR4 (void)
{
  register word x;

  asm ("mov %%cr4,%0":"=r"(x));
  return (x);
}

/*!
** Get eax register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of eax
*/
word	get_EAX (void)
{
  register word x;

  asm ("mov %%eax,%0":"=r"(x));
  return (x);
}

/*!
** Get eax register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of eax
*/
word	get_EBX (void)
{
  register word x;

  asm ("mov %%ebx,%0":"=r"(x));
  return (x);
}

/*!
** Get eax register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of eax
*/
word	get_ECX (void)
{
  register word x;

  asm ("mov %%ecx,%0":"=r"(x));
  return (x);
}

/*!
** Get eax register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of eax
*/
word	get_EDX (void)
{
  register word x;

  asm ("mov %%edx,%0":"=r"(x));
  return (x);
}

/*!
** Get eax register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of eax
*/
word	get_EBP (void)
{
  register word x;

  asm ("mov %%ebp,%0":"=r"(x));
  return (x);
}

/*!
** Get eax register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @return value of eax
*/
word	get_ESP (void)
{
  register word x;

  asm ("mov %%esp,%0":"=r"(x));
  return (x);
}

/*!
** Set CR0 register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @param c the value to put in CR0
*/
void	set_CR0(word c)
{
  asm ("mov %0, %%cr0"::"r" (c));
}

/*!
** Set CR3 register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @param c the value to put in CR3
*/
void	set_CR3(word c)
{
  asm("mov %0, %%cr3"::"r" (c));
}

/*!
** Set SS register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @param ss the value to put in SS
*/
void	set_ss (t_uint16 ss)
{
  register t_uint16 value = ss;

  asm("mov %0,%%ss"::"r"(value));
}

/*!
** Set DS register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @param ds the value to put in DS
*/
void	set_ds (t_uint16 ds)
{
  register t_uint16 value = ds;

  asm("mov %0, %%ds"::"r"(value));
}

/*!
** Set ES register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @param es the value to put in ES
*/
void	set_es(t_uint16 es)
{
  register t_uint16 value = es;

  asm("mov %0, %%es"::"r"(value));
}

/*!
** Set FS register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @param fs the value to put in FS
*/
void	set_fs (t_uint16 fs)
{
  register t_uint16 value = fs;

  asm ("mov %0, %%fs"::"r"(value));
}

/*!
** Set GS register.
**
** CAUTION : the parameters in the asm inline are swapped !!!
**
** @param gs the value to put in GS
*/
void set_gs (t_uint16 gs)
{
  register t_uint16 value = gs;

  asm ("mov %0, %%gs"::"r"(value));
}
