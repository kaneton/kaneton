/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Wed Oct  5 16:25:54 2005 Damien Laniel
** Last update Wed Oct  5 16:25:55 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

void	write_string(int colour, char *string, unsigned short int* videoMem)
{
  while (*string != 0)
    {
      *videoMem = *string;
      string++;
      videoMem++;
      *videoMem = colour;
      videoMem++;
    }
}

int	main()
{
  char* msg = "Micro-Kernel started...";
  int	colour = 0x7;
  unsigned short int* videoMem = (unsigned short int*)0xB8000;

  write_string(colour, msg, videoMem);
  while (1)
    ;
}
