/*
** util_str.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 01:30:57 2002 nicolas clermont
** Last update Sun Nov 13 15:03:00 2005 Antoine Castaing
*/
#include "my_printf.h"

int		my_printchar(char c, char *buffer)
{
  int		i;

  i = 0;
  while (buffer[i] != -1 && i < MY_BUFFER_SIZE)
    i++;
  if (buffer[i] != -1)
    {
      my_flush(buffer);
      i = 0;
    }
  buffer[i] = c;
  return 1;
}

int		my_flush(char *buffer)
{
  int		size;
  int		i;

  size = 0;
  while (buffer[size] != -1 && size < MY_BUFFER_SIZE)
    size++;
  if (size == MY_BUFFER_SIZE)
    write(STDOUT, buffer, MY_BUFFER_SIZE);
  else
    write(STDOUT, buffer, size);
  for (i = 0; i < MY_BUFFER_SIZE; i++)
    buffer[i] = -1;
  return 1;
}

int		my_printstr(char *s, char *buffer)
{
  int		i;

  for (i = 0; *s; i++)
    my_printchar(*s++, buffer);
  return i;
}

unsigned int	my_printdigit(unsigned int i, char *buffer)
{
  my_printchar('0' + i, buffer);
  return 1;
}

int		my_strlen(char *str)
{
  int		count;

  count = 0;
  while (*str != '\0')
    {
      str++;
      count++;
    }
  return count;
}
