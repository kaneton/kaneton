/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sat Mar 19 17:09:58 2005 Damien Laniel
** Last update Mon Mar 28 15:00:42 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef VM_AREA_H
# define VM_AREA_H

# include "../../../include/kaneton/types.h"
# include "../../list/list.h"

# define VM_AREA_FREE	0
# define VM_AREA_USED	1

# define VAS_NODE_SIZE		sizeof(t_vm_area_list)
# define VAS_NODE_ADDR		list_search_free_phys_space_pt(PTAS_ENTRY, VAS_NODE_SIZE, 1)

# define VM_AREA_NODE_SIZE	sizeof(t_vm_area)
# define VAS_NEW_NODE_ADDR	list_search_free_phys_space_pt(PTAS_ENTRY, VM_AREA_NODE_SIZE, 2)

typedef t_list	t_vm_area_list;

/*!
** Virtual memory area
*/
typedef struct		s_vm_area
{
  t_vaddr		start;
  t_vsize		nbpages;
  t_vattr		attr;
  int			compt_ref;
  t_paddr		mapped_pm_area;
}			t_vm_area;

/*!
** Create a struct that identify a virtual memory area
** @param	start	Virtual address of the beginning of the area
** @param	npages	Number of virtual pages of the area
** @param	attr	The attribute of the area
*/
void		vm_area_init(t_vaddr start, t_vsize npages, t_vattr attr,
			     int type, t_vaddr mappped_pm_area, t_vm_area *new_area);

/*!
** Free some pages in the virtual memory area
** @param	area	Identify the virtual area to free
** @param	start	The address where beginning to free
** @param	npages  The number of pages to free
*/
void		vm_area_free_pages(t_vaddr start, t_vsize npages);

/*!
** Modify an area
** @param	area	The area to modify
** @param	n_start	The new address of the virtual area
** @param	n_npages The new number of pages of the area
*/
void		vm_area_modify(t_vm_area *area, t_vaddr n_start, t_psize n_npages);

/*!
** Copy an area structure
** @param	source
** @param	destination
*/
int		vm_area_copy(const void *source, void *destination);

/*!
** Compare two virtual memory area
** @param	area1	a virtual memory area
** @param	area2	a virtual memory area
** @return	0 the same, 1 different
*/
int		vm_area_cmp(const void *area1, const void *area2);

/*!
** Compare two mapped physical address
** @param	vmarea1	a vm area
** @param	vmarea2	a second vm area
** @return	0 the same, 1 if different
*/
int		vm_area_cmp_mapped_addr(const void *vmarea1, const void *vmarea2);

/*!
** Compare the number of pages of two virtual memory areas
** @param	vmarea1	a virtual memory area
** @param	vmarea2	a virtual memory area
** @return	0 the same, 1 if vmarea1 is greater, -1 if vmarea2 is greater
*/
int             vm_area_cmp_npages_ge(const void *vmarea1, const void *vmarea2);

/*!
** Compare two virtual memory area by address
** @param	area1	a virtual memory area
** @param	area2	a virtual memory area
** @return	0 the same, 1 different
*/
int		vm_area_cmp_start(const void *vmarea1, const void *vmarea2);

/*!
** Compare the number of virtual pages of two areas
** @param	area1	a virtual memory area
** @param	area2	a virtual memory area
** @return	0 the same, 1 different
*/
int		vm_area_cmp_npages(const void *area1, const void *area2);

/*!
** Clear the memory occupied by the structure
** @param	area	area to clear
*/
void		vm_area_clear(void *area);

/*!
** Modify a vm area
** @param	area	The area to modify
** @param	n_start	The new address of the virtual area
** @param	n_npages The new number of pages of the area
*/
void		vm_area_modify(t_vm_area *area, t_vaddr n_start, 
			       t_vsize n_npages);

/*!
** Print the structure
** @param	area	Area to print
*/
void		vm_area_print(const void *area);

/*!
** Add an area to a list and sort it using a cmp_func
*/
void		vm_area_list_add(struct s_list ** list,
				 void * area,
				 t_cmp_func cmp_func);

/*!
**
*/
void		vm_area_list_delete(struct s_list ** list, 
				    void * area);

int		is_vaddr_in_vmarea(const void *vmarea1, 
				   const void *vmarea2);

/*!
**
*/
int             vm_area_cmp_start_le(const void *vmarea1, 
				     const void *vmarea2);

#endif /* !VM_AREA_H */
