/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Sep 26 20:12:33 2005 Damien Laniel
** Last update Sat Dec  3 19:48:29 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef KANETON_LIBC_H_
# define KANETON_LIBC_H_

# include "messages.h"
# include "my_printf/my_printf.h"

# define SERVICE_MOD	2
# define STDOUT		3
# define STDIN		5
# define IDE_TSKID	6

/* # define DEBUG_LIBC */

void	*malloc(unsigned int size);

int	unsubscribe_trap(t_trapid trap);

int	subscribe_trap(t_trapid trap);

void	free(void *);

t_msg	*wait_msg();

t_msg	*get_msg();

t_msg	*wait_msg_from(t_tskid dest);

t_msg	*get_msg_from(t_tskid dest);

int	send_msg(t_msg *msg_hdr);

t_msg	*create_msg(t_tskid dest, int data_size);

int     atoi(char *str);

int	my_atoi_base(char *str);

/*!
** Write to dest
*/
int	write(t_tskid dest, const char *string, unsigned int count);

int     write_color(t_tskid dest, const char *string,
                    unsigned int count, char color);

int	my_printf(const char *buf, ...);

/*!
** Send a message to the kernel to stop the execution
*/
void	exit(int status);

/*!
**
*/
t_tskid	fork(void);

/* char * gets (char * s); */

int	getchar(void);

int	subscribe_stdin();

int	unsubscribe_stdin();

int	getc(t_tskid dest);

int	read(t_tskid dest, char *buf, int count);

void	*memcpy(void *dest, const void *src, unsigned int n);

#endif /* !KANETON_LIBC_H_ */
