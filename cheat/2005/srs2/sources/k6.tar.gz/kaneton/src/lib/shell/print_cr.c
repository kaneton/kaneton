#include "../console/console.h"
#include "../../bootloader/ch_cr.h"

/*
**
*/
void print_cr()
{
  printf("CR0 : %d ", get_CR0());
  cons_goto_next_line();
  /* printf("CR1 : %d ", get_CR1());
     cons_goto_next_line();*/
  printf("CR2 : %d ", get_CR2());
  cons_goto_next_line();
  printf("CR3 : %d ", get_CR3());
  cons_goto_next_line();
  printf("CR4 : %d ", get_CR4());
  cons_goto_next_line();
  }


