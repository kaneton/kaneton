/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Mar  7 01:00:58 2005 Damien Laniel
** Last update Mon Mar  7 01:06:09 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "list.h"
#include "../console/console.h"

static t_list	*list_create_node(const t_paddr	node_addr,
				  void		*data,
				  t_list	*next,
				  t_copy_func	copy_func)
{
  t_list	*new_node = (t_list *) node_addr;

  new_node->next = next;
  if (copy_func)
    {
      new_node->data = (void *)(node_addr + sizeof(t_list));
      copy_func(data, new_node->data);
    }
  else
    new_node->data = data;
  return new_node;
}

void		list_add_item_end(t_list	**list,
				  const t_paddr node_addr,
				  void *	data,
				  t_copy_func	copy_func)
{
  t_list *cur_node = *list;

  if (cur_node)
    {
      while (cur_node->next)
	cur_node = cur_node->next;
      cur_node->next = list_create_node(node_addr, data, NULL, copy_func);
    }
  else
    *list = list_create_node(node_addr, data, NULL, copy_func);
}

void		list_add_item_sorted(t_list		**list,
				     const t_paddr	node_addr,
				     void		*data,
				     t_copy_func	copy_func,
				     t_cmp_func		cmp_func)
{
  t_list	*cur_node = *list;

  if (cur_node)
    {
      if (cmp_func(cur_node->data, data) > 0)
	*list = list_create_node(node_addr, data, cur_node, copy_func);
      else
	{
	  while (cur_node->next && cmp_func(cur_node->next->data, data) <= 0)
	    cur_node = cur_node->next;
	  cur_node->next = list_create_node(node_addr, data, cur_node->next, copy_func);
	}
    }
  else
    *list = list_create_node(node_addr, data, NULL, copy_func);
}
