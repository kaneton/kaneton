/*
** Copyright (C) xebech aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Thu Oct  6 18:33:27 2005 xebech
** Last update Sun Nov 13 16:18:07 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef LIBC_SYSCALL_H_
# define LIBC_SYSCALL_H_

# define SYSCALL_MALLOC			1

# define SYSCALL_FREE			2

# define SYSCALL_GET_MSG		3

# define SYSCALL_WAIT_MSG		4

# define SYSCALL_SEND_MSG		5

# define SYSCALL_CREATE_MSG		6

# define SYSCALL_EXIT			7

# define SYSCALL_SUBSCRIBE_TRAP		8

# define SYSCALL_UNSUBSCRIBE_TRAP	9

# define SYSCALL_VM_RSV			10

# define SYSCALL_VM_MAP			11

# define SYSCALL_MM_REL			12

# define SYSCALL_TASK_RSV		13

# define SYSCALL_AS_RSV			14

# define SYSCALL_THREAD_RSV		15

# define SYSCALL_AS_ATTACH		16

# define SYSCALL_THREAD_ATTACH		17

# define SYSCALL_THREAD_STACK		18

# define SYSCALL_THREAD_LOAD		19

# define SYSCALL_THREAD_RUN		20

# define SYSCALL_THREAD_GET_STACK_ADDR	21

# define SYSCALL_AS_SET_MODID		22

# define SYSCALL_AS_GET_MODID		23

# define SYSCALL_AS_GET_PD_PADDR	24

# define SYSCALL_FORK			25

# define SYSCALL_HE_GET_PARAM		26

# define SYSCALL_AS_MODID_TASKID	27

# define SYSCALL_TASK_CREATE		28

# define SYSCALL_GET_MSG_FROM		29

# define SYSCALL_WAIT_MSG_FROM		30

#endif
