/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Thu Mar 24 14:29:22 2005 xebech
** Last update Tue Apr  5 23:52:30 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "../../bootloader/phys_mem_mapping.h"
#include "../console/console.h"

void	print_modules()
{
  char	*conf = (char *) file_conf_addr;
  printf("l adresse du fichier est <0x%x>\n", file_conf_addr);
  printf("%s\n", conf);
}
