/*
** format_nyz.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 00:52:15 2002 nicolas clermont
** Last update Sun Nov 13 15:35:41 2005 Antoine Castaing
*/
#include "my_printf.h"

int		type_z(va_list *arg, char *buffer, t_type *tab)
{
  va_list	*tmp_arg;
  t_type	*tmp_tab;

  tmp_arg = arg;
  tmp_tab = tab;
  return (my_printchar('z', buffer));
}

int		type_r(va_list *arg, char *buffer, t_type *tab)
{
  char		*str;
  char		*str_tmp;
  char		*str_tmp2;
  int		i;
  t_type	*tmp_tab;

  tmp_tab = tab;
  str = va_arg(*arg, char*);
  str_tmp = malloc(my_strlen(str) + 1);
  str_tmp2 = str_tmp;
  for (i = (my_strlen(str) - 1); i >= 0; i--)
    *str_tmp++ = str[i];
  *str_tmp = '\0';
  return (my_printstr(str_tmp2, buffer));
}

/* int		type_y(va_list *arg, char *buffer, t_type *tab) */
/* { */
/*   int		right; */
/*   char		*mode; */
/*   t_type	*tmp_tab; */

/*   tmp_tab = tab; */
/*   right = va_arg(*arg, int); */
/*   mode = check_rights(right); */
/*   return (my_printstr(mode, buffer)); */
/* } */

int		type_n(va_list *arg, char *buffer, t_type *tab)
{
  int		*var;
  char		*tmp_buf;

  tmp_buf = buffer;
  var = va_arg(*arg, int*);
  *var = tab[3].mask;
  return 0;
}
