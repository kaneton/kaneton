/*
** util_right.h for  in /u/a1/clermo_n/PRINT/printf
** 
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
** 
** Started on  Wed Oct 30 01:54:27 2002 nicolas clermont
** Last update Wed Oct 30 01:54:48 2002 nicolas clermont
*/
#include "my_printf.h"

char			*check_rights(int mode);
