/*
** my_strdup.c for dpi in /home/lolo/dpi
**
** Made by Laurent Decool
** Login Laurent <lolo@traktopel.homedns.org>
**
** Started on  Sat Apr 16 12:17:49 2005 Laurent Decool
** Last update Wed Nov 23 14:06:24 2005 Antoine Castaing
*/


/*
** This function is unsafe, please use strndup instead
*/


#include "libc.h"
/* #include "str.h" */

/*!
** The my_strdup() duplicate a string.
**
** @param str the string to duplicate.
** @return The my_strdup() returns the string diplucated.
*/
char	*strdup(const char *str)
{
  char	*answer = 0;
  int	i = 0;

  if (!str)
    return NULL;
  if ((answer = malloc(sizeof (char) * (strlen((char *)str) + 1))) == NULL)
    return NULL;
  for (i = 0; str[i]; i++)
    answer[i] = str[i];
  answer[i] = '\0';
  return answer;
}
