/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sat Mar 26 16:02:57 2005 Nicolas Clermont
** Last update Wed Nov 16 02:07:50 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef IA_32_PM_H
# define IA_32_PM_H

#include "area.h"
#include "../../../include/kaneton/types.h"
#include "../../list/list.h"

# define PM_FLAG_ANY		0
# define PM_FLAG_DMA		1
# define PM_FLAG_SPECIFIC	2
# define PM_FLAG_NODE_PAGE	4

/*!
** Describe all the physical memory
*/
typedef struct		s_pm
{
  t_area_list		*used;
  t_area_list		*free;
}			t_pm;

/*!
** Print on screen the areas of the two lists
*/
void			print_phys_mem(void);

/*!
** Initialise le gestionnaire de memoire physique
*/
int			machdep_pm_init(t_paddr start, t_psize size);

/*!
** Allouer un nombre donne de pages contigues de memoire physique
*/
int			machdep_pm_rsv(t_asid asid, t_paddr *addr, t_psize npages, t_pmflags flags);

/*!
** Modifier les attributs d'une page physique --> bonus ?
*/
int			machdep_pm_attr(t_asid aisd, t_paddr addr, t_psize npages, t_pattr attr);

/*!
** Libere un certain nombre de pages de memoire physique
*/
int			machdep_pm_rel(t_asid asid, t_paddr addr, t_psize npages);

/*!
** Libere toute la memoire physique que l'espace d'adressage asid utilise
** @param		asid	Identify the address space to free
*/
int			machdep_pm_flush(t_asid asid);

/*!
** Reinitialise la gestion de la memoire physique en liberant toutes les pages de
** memoire physique utilisees
*/
int			machdep_pm_clear(void);

/*!
** Print the pjysical memory in ascii art
*/
void			machdep_print_pm(void);

/*!
** Add an area to the free list with optimization
*/
int			fusion_free_area(t_paddr addr, t_psize npages);

/*!
** Screen display when all the memory is used
*/
void			print_fatal_screen(void);

/*!
** Translate a physical memory page address into a virtual page
** address.
*/
t_vaddr			pm_to_vm(t_paddr page_paddr);

#endif			/* !IA_32_PM_H */
