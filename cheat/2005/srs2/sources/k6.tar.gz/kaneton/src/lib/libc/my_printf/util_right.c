/*
** util_right.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 01:32:44 2002 nicolas clermont
** Last update Wed Oct 30 01:33:14 2002 nicolas clermont
*/
#include "my_printf.h"

static char		check_dright(int mode)
{
  int			maske;
  char			type;

  maske = mode & 00170000;
  type = '-';
  if (maske == 0040000)
    type = 'd';
  if (maske == 0120000)
    type = 'l';
  if (maske == 0140000)
    type = 's';
  if (maske == 0010000)
    type = 'f';
  if (maske == 0060000)
    type = 'b';
  if (maske == 0020000)
    type = 'c';
  return type;
}

static char		check_rright(int mode, int mask)
{
  if (mode & mask)
    return 'r';
  else
    return '-';
}

static char		check_wright(int mode, int mask)
{
  if (mode & mask)
    return 'w';
  else
    return '-';
}

static char		check_xright(int mode, int mask)
{
  if (mode & mask)
    return 'x';
  else
    return '-';
}

char			*check_rights(int mode)
{
  char			*right, *t_right;

  right = malloc(11);
  t_right = right;
  *right++ = check_dright(mode);
  *right++ = check_rright(mode, S_IRUSR);
  *right++ = check_wright(mode, S_IWUSR);
  *right++ = check_xright(mode, S_IXUSR);
  *right++ = check_rright(mode, S_IRGRP);
  *right++ = check_wright(mode, S_IWGRP);
  *right++ = check_xright(mode, S_IXGRP);
  *right++ = check_rright(mode, S_IROTH);
  *right++ = check_wright(mode, S_IWOTH);
  *right++ = check_xright(mode, S_IXOTH);
  *right = '\0';
  return t_right;
}
