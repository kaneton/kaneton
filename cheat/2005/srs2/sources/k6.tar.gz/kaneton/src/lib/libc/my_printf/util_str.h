/*
** util_str.h for  in /u/a1/clermo_n/PRINT/printf
** 
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
** 
** Started on  Wed Oct 30 01:55:07 2002 nicolas clermont
** Last update Wed Oct 30 01:56:02 2002 nicolas clermont
*/
#include "my_printf.h"

int		my_printchar(char c, char *buffer);
int		my_flush(char *buffer);
int		my_printstr(char *s, char *buffer);
unsigned int	my_printdigit(unsigned int i, char *buffer);
int		my_strlen(char *str);
