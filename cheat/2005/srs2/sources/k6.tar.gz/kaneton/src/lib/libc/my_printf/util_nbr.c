/*
** util_nbr.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 01:28:55 2002 nicolas clermont
** Last update Wed Oct 30 06:48:08 2002 nicolas clermont
*/
#include "my_printf.h"

int		recurse(int nbr, char *buffer)
{
  int		i;

  i = 0;
  if (nbr)
    {
      i = 1 + recurse(nbr / 10, buffer);
      my_printdigit(nbr % 10, buffer);
    }
  return i;
}

static int	my_printnbr_neg(int nbr, char *buffer, t_type *tab)
{
  int		i, j;
  int		max;

  i = 0;
  max = my_nbrlen(nbr);
  if (tab[7].mask > my_nbrlen(nbr))
    max = tab[7].mask;
  if (tab[8].mask != 1 && !flag_det(tab, FLAG_ZERO)
      && !flag_det(tab, FLAG_MOINS))
    for (j = 0; j < (tab[8].mask - (max + 1)); j++)
      i += my_printchar(' ', buffer);
  i += my_printchar('-', buffer);
  if (tab[7].mask > my_nbrlen(nbr))
    for (j = 0; j < (tab[7].mask - my_nbrlen(nbr)); j++)
      i += my_printchar('0', buffer);
  if ((tab[9].mask & FLAG_ZERO) == FLAG_ZERO)
    for (j = 0; j < (tab[8].mask - (my_nbrlen(nbr) + 1)); j++)
      i += my_printchar('0', buffer);
  i += recurse(-nbr, buffer);
  return i;
}

int		my_printnbr(int nbr, char *buffer, t_type *tab)
{
  int		i;

  i = 0;
  if (nbr)
    {
      if (nbr < 0)
	i += my_printnbr_neg(nbr, buffer, tab);
      else
	i += recurse(nbr, buffer);
    }
  else
    i += my_printchar('0', buffer);
  return i;
}

int		nbrlen_u(unsigned int nbr)
{
  int		i;

  i = 0;
  if (nbr)
    i = 1 + nbrlen_u(nbr / 10);
  return i;
}

static int	recurse_u(unsigned int nbr, char *buffer)
{
  int		i;

  i = 0;
  if (nbr)
    {
      i = 1 + recurse_u(nbr / 10, buffer);
      my_printdigit(nbr % 10, buffer);
    }
  return i;
}

int		my_printnbr_u(unsigned int nbr, char *buffer)
{
  int		i;

  i = 0;
  if (nbr)
    i = recurse_u(nbr, buffer);
  else
    my_printchar('0', buffer);
  return i;
}

int             my_nbrlen(int fsize)
{
  int           nb_u;

  nb_u = 0;
  if (fsize == 0)
    return 1;
  while (fsize != 0)
  {
      fsize /= 10;
      nb_u++;
  }
  return nb_u;
}
