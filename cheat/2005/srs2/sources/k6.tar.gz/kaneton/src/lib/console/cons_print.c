/*
** Copyright (C) Antoine Castaing aka xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Wed Mar 23 23:38:39 2005 Antoine Castaing
** Last update Sun Nov 13 17:49:47 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "console.h"
#include "../../include/kaneton/stdarg.h"

/*!
** Power function
*/
int power(int nb, int exp)
{
  if (exp == 0)
    return 1;
  return nb * power(nb, exp - 1);
}


/*!
** Print a character on the screen
**
** @param g_console	pointer to console address
** @param attrib	character attributes
** @param c		character to print
*/
void	cons_print_char(char c)
{
  int	i = (((int)(ttys[current_tty].addr) - (int)(ttys[current_tty].start_addr)) / 2) % 80;

  switch(c)
    {
    case 007:		/* ring the bell */
      /* If we want the bell*/
      break;

    case '\b':		/* backspace */
      if (i > 24)
	{
	  ttys[current_tty].addr--;
	  *(ttys[current_tty].addr) = ttys[current_tty].attrib;
	  ttys[current_tty].addr--;
	  *(ttys[current_tty].addr) = 0;
	}
      break;

    case '\n':
      if ((((int) ttys[current_tty].addr - (int)ttys[current_tty].start_addr) / 2) >= (COLUMNS * 24))
	{
#ifdef DEBUG
	  printf("<%i>", ttys[current_tty].current_scroll_offset);
#endif
	  hard_scrolling(COLUMNS);
	  /* 	ttys[current_tty].current_scroll_offset += COLUMNS; */
	}
      update_curseur();
      cons_goto_next_line();
      return;

    case '\t':		/* tab */
      for (; i < TAB_SIZE; i++)
	{
	  *(ttys[current_tty].addr) = 0;
	  ttys[current_tty].addr++;
	  *(ttys[current_tty].addr) = ttys[current_tty].attrib;
	  ttys[current_tty].addr++;
	}
      break;

    default:
      *(ttys[current_tty].addr) = c;
      ttys[current_tty].addr++;
      *(ttys[current_tty].addr) = ttys[current_tty].attrib;
      ttys[current_tty].addr++;
    }
  update_curseur();
}

/*!
** Print on the console the mesage msg
** in the color specified by the attrib parameter
**
** @param console	pointer to console address
** @param attrib	character attributes
** @param msg		string to print
*/
void	cons_print_string(char *msg)
{
  for (; *msg; ++msg)
    cons_print_char(*msg);
}

/*!
** Print an integer on the console
**
** @param console	pointer to console address
** @param attrib	character attributes
** @param i		integer to print
** @param base		base of i (2, 10, 16, ...)
*/
void	cons_print_int_base(int nb, int base)
{
   int	i = 0;
   int	j = 0;
   int	b = 0;
   int	nb_tmp = nb;

#ifdef DEBUG
  printf("print_int\n");
#endif
  if (nb == 0)
    {
#ifdef DEBUG
  printf("le nombre est 0\n");
#endif
      cons_print_char('0');
      return;
    }
  for (b = base; nb_tmp / b > 0; ++i, nb_tmp /= b)
    ;
  for (j = 0; nb >= 0 && i >= 0; ++j, --i)
    {
#ifdef DEBUG
  printf("je suis ds la boucle\n");
#endif
      if ((nb / power(b, i)) > 9)
	cons_print_char((char)(nb / power(b, i) - 10  + 'A'));
      else
	cons_print_char((char)(nb / power(b, i) + '0'));
      nb -= (nb / power(b, i)) * power(b, i);
    }
}

/* static void     affich(char tab[], int n) */
/* { */
/*   for (; n > 0; n--) */
/*     cons_print_char(tab[n]); */
/* } */

/* void    my_printnbr(unsigned int n) */
/* { */
/*   int   i = 0; */
/*   char  tab[12] = {0,0,0,0,0,0,0,0,0,0,0,0}; */

/*   while (n > 0) */
/*     { */
/*       i++; */
/*       tab[i] =  n % 16; */
/*       if (tab[i] > 9) */
/* 	tab[i] = tab[i] - 10 + 'a'; */
/*       else */
/* 	tab[i] += '0'; */

/*       n /= 16; */
/*     } */
/*   affich(tab, i); */
/* } */

/*!
** Printf
*/
void	printf(char *buf, ...)
{
  char *str = buf;

  va_list args_ptr;
  va_start(args_ptr, buf);
  for (str = buf ; *str ; str++)
    {
      if (*str != '%')
	cons_print_char(*str);
      else
	{
	  str++;
	  switch(*str)
	    {
	      /* Integer */
	    case 'd':
	    case 'i':
	      cons_print_int_base(va_arg(args_ptr, int), 10);
	      break;
	      /* Char */
	    case 'c':
	      cons_print_char(va_arg(args_ptr, char));
	      break;
	      /* String */
	    case 's':
	      cons_print_string(va_arg(args_ptr, char *));
	      break;
	      /* Hexa value */
	    case 'x':
	      cons_print_int_base(va_arg(args_ptr, int), 16);
	      break;
	      /* Address*/
	    case 'p':
	      cons_print_int_base((int) va_arg(args_ptr, void *), 16);
	      break;
	    default :
	      cons_print_char('%');
	      cons_print_char(*str);
	    }
	}
    }
}
