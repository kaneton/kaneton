/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Mar  7 01:00:26 2005 Damien Laniel
** Last update Mon Mar  7 01:07:04 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "list.h"

void		list_delete_item(t_list		**list,
				 const void	*data,
				 t_cmp_func	cmp_func,
				 t_clear_func	clear_func)
{
  t_list	*cur_node = *list;
  t_list	*prev_node = NULL;

  if (cur_node)
    {
      if (!(cmp_func(cur_node->data, data)))
	{
	  *list = cur_node->next;
	  if (clear_func)
	    clear_func(cur_node->data);
	  cur_node->data = NULL;
	  cur_node->next = NULL;
	  return;
	}
      for (prev_node = cur_node, cur_node = cur_node->next;
	   cur_node;
	   prev_node = cur_node, cur_node = cur_node->next)
	{
	  if (!(cmp_func(cur_node->data, data)))
	    {
	      prev_node->next = cur_node->next;
	      if (clear_func)
		clear_func(cur_node->data);
	      cur_node->data = NULL;
	      cur_node->next = NULL;
	      return;
	    }
	}
    }
}
