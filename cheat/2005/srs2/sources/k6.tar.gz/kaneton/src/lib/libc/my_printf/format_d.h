/*
** format_d.h for  in /u/a1/clermo_n/PRINT/printf
** 
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
** 
** Started on  Wed Oct 30 01:45:02 2002 nicolas clermont
** Last update Wed Oct 30 01:45:30 2002 nicolas clermont
*/
#include "my_printf.h"

int		type_d(va_list *arg, char *buffer, t_type *tab);
