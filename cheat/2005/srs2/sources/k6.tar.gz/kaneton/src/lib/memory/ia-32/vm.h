/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sat Mar 19 17:06:25 2005 Damien Laniel
** Last update Thu Nov 10 23:34:12 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef IA32_VM_H_
# define IA32_VM_H_

#include "../../../include/kaneton/types.h"

#define VM_FLAG_ANY		0x00
#define VM_FLAG_SPECIFIC	0x01

#define VM_ATTR_NONE	0
#define VM_ATTR_EXEC	1
#define VM_ATTR_WRITE	2
#define VM_ATTR_READ	4

int	machdep_vm_init(t_asid asid);

/*!
** Allocate n pages of virtual memory
** @param	asid	Identifier of the as to which we want to allocate memory
** @param	addr	Return parameters that contain the address of the allocated area
** @param	npages	Number of pages we want to allocate
** @param	flags
*/
int	machdep_vm_rsv(t_asid asid, t_vaddr *addr, t_vsize npages, t_vmflags flags);

/*!
** Free n memory pages of virtual memory
** @param	asid	Identifier of the as where we want to free space
** @param	addr	Beginning of the area to free
** @param	npages	Number of pages to free
*/
int	machdep_vm_rel(t_asid asid, t_vaddr addr, const t_vsize npages);

/*!
** Modify the attributes of some pages of virtual memory
** @param	asid	Identifier of the as to modify
*/
int	machdep_vm_attr(t_asid asid, t_vaddr addr, t_vsize npages, t_vattr attr);

/*!
** Clear all the virtual memory area of an address space
** @param	asid	Identifier of the as to flush
*/
int	machdep_vm_flush(t_asid asid);

int	machdep_vm_clear(void);

/*!
** Map npages pages from (to) paddr to (from) vaddr
** @param	asid	Identifier of the as of which to map memory
** @param	paddr	Physical address to map
** @param	vaddr	Virtual address to map
** @param	npages	Number of pages to map
*/
int	machdep_vm_map(t_asid asid, t_paddr paddr, t_vaddr vaddr, t_vsize npages);

/*!
** Unmap npages pages of vaddr
** @param	asid	Identifier of the as of which to unmap memory
** @param	vaddr	Virtual address to unmap
** @param	npages	Number of pages to unmap
*/
int	machdep_vm_unmap(t_asid asid, t_vaddr vaddr, t_vsize npages);

/*!
** Copy 'nbytes' bytes from address 'src' to address 'dst'
** @param	from	Identifier of the as to copy from
** @param	src	Address to copy from
** @param	to	Identify the as to copy to
** @param	dst	Address to copy to
** @param	nbytes	Number of bytes to copy
*/
int	machdep_vm_copy(t_asid from, t_vaddr src, t_asid to, t_vaddr dst, t_vsize nbytes);

t_paddr vm_to_pm(word *pd, t_vaddr vaddr, t_asid asid, t_paddr pd_addr);

/*
** Translate a physical memory page address into a virtual page
** address.
** @param asid		Owner of the page table
** @param to_translate	Physical page address to translate
** @return		The virtual page address
*/
t_vaddr	pt_pm_to_vm(t_id asid, t_paddr to_translate);
t_vaddr	ptm_pm_to_vm(t_id asid, t_paddr to_translate);

#endif /* !IA32_VM_H_ */
