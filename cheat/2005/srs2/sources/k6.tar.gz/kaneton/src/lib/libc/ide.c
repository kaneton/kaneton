/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Nov 28 14:14:31 2005 Damien Laniel
** Last update Sat Dec  3 17:52:16 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "ide.h"
#include "libc.h"

/*!
** Write some datas to a drive.
** The address is given in CHS (Cylinder/Head/Sector) mode
**
** @param	controller	Controller on which is the drive to use
** @param	cylinder	Cylinder to use
** @param	head		Head to use
** @param	sector		Start sector
** @param	data		Datas to write
** @param	data_size	Size in bytes of the datas to write
** @return	0 if success, 1 otherwise
*/
int				ide_write(t_ata_controller controller,
					  t_ata_master_slave master_slave,
					  t_uint16 cylinder,
					  t_uint8 head,
					  t_uint8 sector,
					  const void *data,
					  t_uint32 data_size)
{
  t_msg				*msg = NULL;
  t_uint32			data_current_offset = 0;

  /* Create the message, specying the size of all what we will write into it */
  msg = create_msg(IDE_TSKID, sizeof(t_ide_msg_type)
			      + sizeof(t_ata_controller)
			      + sizeof(t_ata_master_slave)
			      + sizeof(t_uint16)
			      + sizeof(t_uint8)
			      + sizeof(t_uint8)
			      + sizeof(t_uint32)
                              + data_size);

  *(t_ide_msg_type *)(msg->data + data_current_offset) = IDE_MSG_WRITE;
  data_current_offset += sizeof(t_ide_msg_type);

  /* Defines where to write + data size */
  *(t_ata_controller *)(msg->data + data_current_offset) = controller;
  data_current_offset += sizeof(t_ata_controller);
  *(t_ata_master_slave *)(msg->data + data_current_offset) = master_slave;
  data_current_offset += sizeof(t_ata_master_slave);
  *(t_uint16 *)(msg->data + data_current_offset) = cylinder;
  data_current_offset += sizeof(t_uint16);
  *(t_uint8 *)(msg->data + data_current_offset) = head;
  data_current_offset += sizeof(t_uint8);
  *(t_uint8 *)(msg->data + data_current_offset) = sector;
  data_current_offset += sizeof(t_uint8);
  *(t_uint32 *)(msg->data + data_current_offset) = data_size;
  data_current_offset += sizeof(t_uint32);

  /* Datas to write on the disk */
  memcpy(msg->data + (void *)data_current_offset, data, data_size);

  return send_msg(msg);
}

/*!
** Read some datas from a drive.
** The address is given in CHS (Cylinder/Head/Sector) mode
**
** @param	controller	Controller on which is the drive to use
** @param	cylinder	Cylinder to use
** @param	head		Head to use
** @param	sector		Start sector
** @param	data_size	Size in bytes of the datas to read
** @return	Read datas. NULL if an error occurs
*/
char		*ide_read(t_ata_controller controller,
			  t_ata_master_slave master_slave,
			  t_uint16 cylinder,
			  t_uint8 head,
			  t_uint8 sector,
			  t_uint32 data_size)
{
  t_msg		*msg = NULL;
  t_msg		*msg_rcv = NULL;
  t_uint32	data_current_offset = 0;
  char		*read_buffer = NULL;

  /* Create the message, specying the size of all what we will write into it */
  msg = create_msg(IDE_TSKID, sizeof(t_ide_msg_type)
			      + sizeof(t_ata_controller)
			      + sizeof(t_ata_master_slave)
			      + sizeof(t_uint16)
			      + sizeof(t_uint8)
			      + sizeof(t_uint8)
			      + sizeof(t_uint32));

  *(t_ide_msg_type *)(msg->data + data_current_offset) = IDE_MSG_READ;
  data_current_offset += sizeof(t_ide_msg_type);

  /* Defines where to write + data size */
  *(t_ata_controller *)(msg->data + data_current_offset) = controller;
  data_current_offset += sizeof(t_ata_controller);
  *(t_ata_master_slave *)(msg->data + data_current_offset) = master_slave;
  data_current_offset += sizeof(t_ata_master_slave);
  *(t_uint16 *)(msg->data + data_current_offset) = cylinder;
  data_current_offset += sizeof(t_uint16);
  *(t_uint8 *)(msg->data + data_current_offset) = head;
  data_current_offset += sizeof(t_uint8);
  *(t_uint8 *)(msg->data + data_current_offset) = sector;
  data_current_offset += sizeof(t_uint8);
  *(t_uint32 *)(msg->data + data_current_offset) = data_size;
  data_current_offset += sizeof(t_uint32);

  send_msg(msg);

  /* Wait for read result */
  msg_rcv = wait_msg_from(IDE_TSKID);
  if (msg_rcv && msg_rcv->data)
    {
      read_buffer = malloc(data_size);
      memcpy(read_buffer, (void *)(msg_rcv->data), data_size);
    }
  else
    {
      if (!msg_rcv)
	{
	  write(STDOUT, "IDE : no message\n", strlen("IDE : no message\n"));
	  while (1);
	}
      else
	{
	  write(STDOUT, "IDE : data NULL\n", strlen("IDE : data NULL\n"));
	  while (1);
	}
    }

  return read_buffer;
}
