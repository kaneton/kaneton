/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sat Mar 26 18:27:14 2005 Nicolas Clermont
** Last update Tue Sep 27 11:27:39 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "sh_test.h"
#include "../console/console.h"
#include "../libc/libc.h"
#include "../libc/string.h"
#include "parse_cmd.h"
#include "test_as.h"
#include "test_pm.h"
#include "test_vm.h"
#include "test_mm.h"
#include "test_pmrel.h"
#include "test_mmrel.h"
#include "test_asrel.h"
#include "test_list.h"
#include "test_set.h"
#include "test_task.h"

#define NB_TEST_FCT 10

char test_as_rsv[6] = "asrsv";
char test_pm_rsv[6] = "pmrsv";
char test_vm_rsv[6] = "vmrsv";
char test_mm_rsv[6] = "mmrsv";
char test_pm_rl[6] = "pmrel";
char test_mm_rl[6] = "mmrel";
char test_as_rl[6] = "asrel";
char test_list_str[5] = "list";
char test_set_str[4] = "set";
char test_task_str[4] = "task";

struct s_mtest_builtin test_arg[NB_TEST_FCT] =
  {
    {(char *)(&test_as_rsv), (fct_mtest)test_asrsv},
    {(char *)(&test_pm_rsv), (fct_mtest)test_pmrsv},
    {(char *)(&test_vm_rsv), (fct_mtest)test_vmrsv},
    {(char *)(&test_mm_rsv), (fct_mtest)test_mmrsv},
    {(char *)(&test_pm_rl), (fct_mtest)test_pmrel},
    {(char *)(&test_mm_rl), (fct_mtest)test_mmrel},
    {(char *)(&test_as_rl), (fct_mtest)test_asrel},
    {(char *)(&test_list_str), (fct_mtest)test_list},
    {(char *)(&test_set_str), (fct_mtest)test_set},
    {(char *)(&test_task_str), (fct_mtest)test_task}
  };

void	sh_test(char *arg[NB_MAX_ARG], int nb_arg)
{
  int	i = 0;

  switch (nb_arg){
      case 0:
	if (info_general)
	  printf("%s", info_general);
	else
	  printf("L'aide de Kaneton n'est pas active\n");
	break;
  default:
    for (i = 0; i < NB_TEST_FCT; i++)
      if (!strcmp(test_arg[i].fct_label, arg[0]))
	test_arg[i].fct(arg, nb_arg);
    break;
  }
}
