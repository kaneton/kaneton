/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sun Mar  6 21:00:43 2005 Damien Laniel
** Last update Wed Dec  7 10:23:55 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "list.h"
#include "../../bootloader/phys_mem_mapping.h"
#include "../console/console.h"
#include "../memory/pm.h"

#define DBG	0
#define DEBUG   0

t_paddr		list_search_free_phys_space(t_paddr start, int node_size, int ptas)
{
  char		*tampon, *cur_node = (char*)start, *tmp;
  t_bool	success = false;
  int		index, i = 0, decal = 0;
  t_paddr	new_start;
  t_paddr	*replace = NULL;

  if (DEBUG)
    printf("List_search_free_phys_space start %x \n", start);


  if (start == AREA + 8)
    decal += 8;
  for (; success == false &&
	 cur_node < (char*)(start + (PAGE_SIZE - decal) - 4 - node_size + 1);
       cur_node += node_size)
    {
      success = true;
      for (i = 0; i < node_size; ++i)
	if (cur_node[i] != 0)
	  {
	    success = false;
	    break;
	  }
    }
  if ((success == false) && (ptas == 1))
    return NULL;
  if (success == true)
    return (t_paddr)cur_node - node_size;
 /*  if (start == AREA + 8) */
/*     decal += 8; */
  tmp = cur_node;
  while (cur_node != (char*)(start + PAGE_SIZE - (decal + 4)))
    {
      /*       printf("TOTOTOTOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO %d %x %d\n", decal, tmp, node_size); */
      cur_node++;
    }
  replace = (t_paddr*) cur_node;
  if (DEBUG)
    {
      printf("cur_node Addr Value : %x\n", (int)cur_node);
      printf("cur_node Data Value : %x\n", (t_paddr)(*cur_node));
      printf("replace Data Value : %x\n", *replace);
    }

  if (*replace == 0)
    {
      tampon = (char*)(start);
      for (i = 0; i < node_size; i++)
	*tampon++ = 0;
      pm_rsv(0, &new_start, 1, PM_FLAG_ANY);
      if (DBG)
	printf("Start %x \n", (int)new_start);
      index = map_new_page(PTM_ENTRY, new_start, USER | RW);
      /* Former l'@ lineaire */
      new_start = (1 << 22) + (index << 12);
      list_init(new_start);
      tampon = (char*)(new_start);
      for (i = 0; i < node_size; i++)
	*tampon++ = 1;
      *replace = new_start;
      if (DBG)
	{
	  printf("INDEX: %d\n", index);
	  printf("1 << 22: %x\n", 1 << 22);
	  printf("index << 22: %x\n", index << 12);
	  printf("NEW_START_PAGE: %x\n", new_start);
	  printf("NEW_START_NODE: %x\n", *replace);
	  printf("NEW_START_NODE: %x\n", (int)(*((unsigned int *)cur_node)));
	  while(1);
	}
      return new_start + node_size;
    }
  return list_search_free_phys_space(*replace, node_size, 0);
}

t_paddr		list_search_free_phys_space_pt(t_paddr pt_addr,
					       int node_size,
					       int pos)
{
  /*   static t_vaddr last_vmarea = 0; */
  int		j = pos, pt_index = 0;
  t_paddr	new_addr = 0;
  t_pte		*pt = NULL;
  t_vaddr	page_vaddr;
  /*   static int	index_current_vmarea_page = 2; */

  pt = (t_pte *)pt_addr;
  /*   if (pos == 2) */
  /*     j = index_current_vmarea_page; */
  while (pt[j] != 0 && !new_addr && j < 1024)
  {
    /*     if (pos == 2) */
    /*       new_addr = optim_list_search_free_phys_space((t_paddr)(pt[j] >> 12) * PAGE_SIZE,  */
    /* 						   node_size, 1, pos, &last_vmarea); */
    /*     else */
    //FIXME : C l'@ Lineaire de la page qu'il faut passer.
    /*     page_vaddr = pm_to_vm((t_paddr)(pt[j] >> 12) * PAGE_SIZE); */
    page_vaddr = (PTAS_PDE << 22) + (j << 12);
    /*     printf("PAGE_VADDR : %x P_ADDR : %x\n", page_vaddr,  */
    /* 	   (t_paddr)(pt[j] >> 12) * PAGE_SIZE); */
    /*     while (1); */
    new_addr = list_search_free_phys_space(/* (t_paddr)(pt[j] >> 12) * PAGE_SIZE, */
					   page_vaddr,
					   node_size, 1);
    j += 3;
  }
  if (j == 1024)
    //La PT est pleine. Mapper une autre PT ?
    return NULL;
  if (!new_addr)
    {
      /*       printf("-----------On remappe une page pour vm ou pour pas/vas\n"); */
      //FIXME : Former l'@ lineaire
      pm_rsv(0, &new_addr, 1, PM_FLAG_ANY);
      map_new_page_at(pt_addr, new_addr, j, USER | RW);
      if (pt_addr == PTAS_ENTRY)
	{
	  /* 	  printf("-----------------C DANS LA  PTAS : pos %d paddr %x\n",  */
	  /* 		 pos, new_addr); */
	  pt_index = 3;
	}
      else
	{
	  /*       pt_index = get_pt_index(pt_addr); */
	  printf("---------------Mais ke se passe t il ?\n");
	  while(1);
	}
      new_addr = (pt_index << 22) + (j << 12);
      list_init(new_addr);
      /*       printf("NEW_ADDR %x%x\n", new_addr / 0x10, new_addr % 0x10); */
    }

  /*   if (pos == 2) */
  /*       index_current_vmarea_page = j - 3; */

  return new_addr;
}

/* #define DEBUG_OPTIM */
//FIXME last en param pour vm et pm
//Rajouter un param pos pour l'index ds PATS 4 pour pm ki y est po
//Separer pas et vas ?
t_paddr		optim_list_search_free_phys_space(t_paddr *start, int node_size,
						  int ptas/*, int pos, t_vaddr *last*/)
{
  static t_vaddr last = 0;
  t_paddr	new_start = 0;
  t_vaddr	next_page = 0;
  int		i, index, decal = 0;
  unsigned int	tampon_sz = 4;
  char		*tampon = NULL;

  /* Initialisation - premier passage ou debut de page */
  if (last == 0)
    {
      last = list_search_free_phys_space(*start, node_size, ptas);
      return last;
    }

  /* Si la page en cours est AREA, on decale car presence structure pm */
  if (*start == AREA + sizeof(t_pm))
    decal = 8;

  /* Si on a de la place sur la page */
  //FIXME POURQUOI * 2 ??
  if (last < (*start + (PAGE_SIZE - decal) - (2 * node_size + tampon_sz)))
    {
      last = (last + node_size);
      return last;
    }
  /*   if (pos == 2) */
  /*     return 0; */
  /* Si il y a une page suivante */
  if ((next_page = *(t_vaddr *)(*start + PAGE_SIZE - tampon_sz - decal)))
    {
      printf("PAGE SUIVANTE = %x lu a %x et last %x node %x\n", next_page, (*start + PAGE_SIZE - tampon_sz - decal), last, node_size);
      while (1);
      last = 0; /*???*/
      *start = next_page;
      optim_list_search_free_phys_space(start, node_size, ptas);
    }
  else
    {
      /*Si il n'y en a pas */
      tampon = (char*)(*start);
      for (i = 0; i < node_size; i++)
	*tampon++ = 0;
      new_start = *start;
      pm_rsv(0, &new_start, 1, PM_FLAG_NODE_PAGE);
#ifdef DEBUG_OPTIM
      printf("Start %x \n", (int)new_start);
#endif
      index = map_new_page(PTM_ENTRY, new_start, USER | RW);
      /* Former l'@ lineaire */
      new_start = (1 << 22) + (index << 12);
      list_init(new_start);
      *start = new_start;
      /* Mise en place du tampon en debut de nouvelle page */
      tampon = (char*)(new_start);
      for (i = 0; i < node_size; i++)
	*tampon++ = 1;
      /* Ecriture de l'@ de la nouvelle page ds le tampon de fin de l'ancienne */
      *(t_vaddr *)next_page = new_start;
      last = new_start + node_size;
#ifdef DEBUG_OPTIM
      printf("Index ds la PTM: %d\n", index);
      printf("Addr de la nouvelle page de noeuds: %x\n", new_start);
      printf("Valeur ds le tampon de fin de la prec: %x\n", *(t_vaddr *)next_page);
      while(1);
#endif
      return new_start + node_size;
    }
  return 0;
}
