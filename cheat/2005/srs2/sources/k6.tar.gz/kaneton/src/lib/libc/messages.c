/*
** Copyright (C) Antoine Castaing aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Sun Oct  9 11:29:03 2005 Antoine Castaing
** Last update Wed Nov 23 10:58:41 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "messages.h"
#include "syscall.h"
#include "libc.h"

t_tskid	get_src(t_msg *msg){
  if (msg)
    return msg->src;
  return (t_tskid)-1;
}

t_tskid	get_dest(t_msg *msg){
  if (msg)
    return msg->dest;
  return (t_tskid)-1;
}

void	*get_data(t_msg *msg){
  if (msg)
    return (void *)msg->data;
  return NULL;
}

int	get_data_size(t_msg *msg){
  if (msg)
    return msg->data_size;
  return -1;
}

void	set_src(t_msg *msg, t_tskid src){
  if (msg)
    msg->src = src;
}

void	set_dest(t_msg *msg, t_tskid dest){
  if (msg)
    msg->dest = dest;
}

void	set_data(t_msg *msg, void *data){
  if (msg)
    msg->data = (t_vaddr)data;
}

void	set_data_size(t_msg *msg, int type){
  if (msg)
    msg->data_size = type;
}

t_msg	*get_msg()
{
  int		syscall = SYSCALL_GET_MSG;
  unsigned int	res;

#ifdef DEBUG_LIBC_MESSAGES
  printf("Debut get_msg de la libc\n");
#endif
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" int $0x30");
  asm ("mov %%eax, %0":"=m"(res));
#ifdef DEBUG_LIBC_MESSAGES
  printf("Fin du get_msg de la libc avec l @ %x\n", res);
#endif
  return (t_msg *)res;
}

t_msg	*get_msg_from(t_tskid dest)
{
  int		syscall = SYSCALL_GET_MSG_FROM;
  unsigned int	res;

#ifdef DEBUG_LIBC_MESSAGES
  printf("Debut get_msg_from de la libc\n");
#endif
  asm("mov %0, %%eax"::"m"(syscall));
  asm("mov %0, %%ebx"::"m"(dest));
  asm(" int $0x30");
  asm ("mov %%eax, %0":"=m"(res));
#ifdef DEBUG_LIBC_MESSAGES
  printf("Fin du get_msg_from de la libc avec l @ %x\n", res);
#endif
  return (t_msg *)res;
}

t_msg		*wait_msg()
{
  int		syscall = SYSCALL_WAIT_MSG;
  unsigned int	res;
  t_msg		*msg_hdr;


#ifdef DEBUG_LIBC_MESSAGES
  printf("Debut wait_msg de la libc\n");
#endif
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" int $0x30");
  asm ("mov %%eax, %0":"=m"(res));
#ifdef DEBUG_LIBC_MESSAGES
  my_printf("#####################################\n");
  my_printf("Dans wait_msg avt get)msg res %x\n", res);
  /* while (1); */
#endif
  if (res)
    return (t_msg *)res;
  msg_hdr = get_msg();
#ifdef DEBUG_LIBC_MESSAGES
  if (msg_hdr == NULL)
    printf("On nous a reveille mais get_msg() ne nous renvoie rien\n");
#endif
  return msg_hdr;
}

t_msg		*wait_msg_from(t_tskid dest)
{
  int		syscall = SYSCALL_WAIT_MSG_FROM;
  unsigned int	res;
  t_msg		*msg_hdr;

/*   my_printf("wait_msg_from -> dest %d\n", dest); */
/*   while (1); */
#ifdef DEBUG_LIBC_MESSAGES
  printf("Debut wait_msg_from de la libc\n");
#endif
  asm("mov %0, %%eax"::"m"(syscall));
  asm("mov %0, %%ebx"::"m"(dest));
  asm(" int $0x30");
  asm ("mov %%eax, %0":"=m"(res));
#ifdef DEBUG_LIBC_MESSAGES
  my_printf("#####################################\n");
  my_printf("Dans wait_msg_from avt get)msg res %x\n", res);
  /* while (1); */
#endif
  if (res)
    return (t_msg *)res;
  msg_hdr = get_msg_from(dest);
/*   msg_hdr = get_msg(); */
/* #ifdef DEBUG_LIBC_MESSAGES */
 if (msg_hdr == NULL)
    my_printf("On nous a reveille mais get_msg_from() ne nous renvoie rien\n");
/* #endif */
  return msg_hdr;
}

/*!
** Send the message header to the kernel using int 0x30
** The value are put in registers :
** EAX -> Fill with the no of the interruption
** EBX -> fill with the pointer on the msg header
*/
int		send_msg(t_msg *msg_hdr)
{
  t_vaddr	msg_hdr_addr = (t_vaddr)msg_hdr;
  int		syscall = SYSCALL_SEND_MSG;
  int		res = -1;

#ifdef DEBUG_LIBC_MESSAGES
  printf("send_msg de la libc avec l @ de msg %x\n",
	 msg_hdr);
#endif
  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (msg_hdr_addr));
  asm(" int $0x30");
  asm ("mov %%eax, %0":"=m"(res));
#ifdef DEBUG_LIBC_MESSAGES
  printf("Fin du send_msg de la libc avec le ret %d\n", res);
#endif
  return 0;
}

t_msg	*create_msg(t_tskid dest, int data_size)
{
   int		syscall = SYSCALL_CREATE_MSG;
   t_msg	*res = NULL;

  asm("mov %0, %%eax"::"m"(syscall));
  asm(" mov %0, %%ebx"::"m" (dest));
  asm(" mov %0, %%ecx"::"m" (data_size));
  asm(" int $0x30");
  asm ("mov %%eax, %0":"=m"(res));

  return res;
}
