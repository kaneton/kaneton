/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Nov 28 12:48:36 2005 Damien Laniel
** Last update Mon Nov 28 18:05:51 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef LIBC_IDE_H_
# define LIBC_IDE_H_

#include "../../include/kaneton/types.h"

/* Controllers and their base I/O ports address */
typedef enum	e_ata_controller
  {
    ATA_CTRL1 = 0x1f0,
    ATA_CTRL2 = 0x170,
    /* Ioports of controller 3 and 4 are to check if needed */
    /*     ATA_CTRL3 = 0xf0, */
    /*     ATA_CTRL4 = 0x70 */
  }		t_ata_controller;

/* Master or slave drives */
typedef enum	e_ata_master_slave
  {
    ATA_MASTER = 0xa0,
    ATA_SLAVE = 0xb0
  }		t_ata_master_slave;

typedef enum	e_ide_msg_type
  {
    IDE_MSG_WRITE,
    IDE_MSG_READ
  }		t_ide_msg_type;

typedef struct		s_ide_msg_write_header
{
  t_ide_msg_type	msg_type;
  t_ata_controller	controller;
  t_ata_master_slave	master_slave;
  t_uint16		cylinder;
  t_uint8		head;
  t_uint8		sector;
  t_uint32		data_size;
} 			t_ide_msg_write_header;

/*!
** Write some datas to a drive.
** The address is given in CHS (Cylinder/Head/Sector) mode
**
** @param	controller	Controller on which is the drive to use
** @param	cylinder	Cylinder to use
** @param	head		Head to use
** @param	sector		Start sector
** @param	data		Datas to write
** @param	data_size	Size in bytes of the datas to write
** @return	0 if success, 1 otherwise
*/
int		ide_write(t_ata_controller controller,
			  t_ata_master_slave master_slave,
			  t_uint16 cylinder,
			  t_uint8 head,
			  t_uint8 sector,
			  const void *data,
			  t_uint32 data_size);

/*!
** Read some datas from a drive.
** The address is given in CHS (Cylinder/Head/Sector) mode
**
** @param	controller	Controller on which is the drive to use
** @param	cylinder	Cylinder to use
** @param	head		Head to use
** @param	sector		Start sector
** @param	data_size	Size in bytes of the datas to read
** @return	Read datas. NULL if an error occurs
*/
char		*ide_read(t_ata_controller controller,
			  t_ata_master_slave master_slave,
			  t_uint16 cylinder,
			  t_uint8 head,
			  t_uint8 sector,
			  t_uint32 data_size);

#endif /* LIBC_IDE_H_ */
