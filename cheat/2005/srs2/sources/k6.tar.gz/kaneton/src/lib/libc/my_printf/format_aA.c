/*
** format_aA.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 00:49:50 2002 nicolas clermont
** Last update Sun Nov 13 15:13:07 2005 Antoine Castaing
*/
#include "my_printf.h"

static int	convert_basenb1(t_uint32 nb)
{
  int		nb1;

  nb1 = nb / 0x10;
  if ((nb / 0x10) == 0xA)
    nb1 = 10;
  if ((nb / 0x10) == 0xB)
    nb1 = 11;
  if ((nb / 0x10) == 0xC)
    nb1 = 12;
  if ((nb / 0x10) == 0xD)
    nb1 = 13;
  if ((nb / 0x10) == 0xE)
    nb1 = 14;
  if ((nb / 0x10) == 0xF)
    nb1 = 15;
  return (nb1 * 16);
}

static int	convert_basenb2(t_uint32 nb)
{
  int		nb2;

  nb2 = nb % 0x10;
  if ((nb % 0x10) == 0xA)
    nb2 = 10;
  if ((nb % 0x10) == 0xB)
    nb2 = 11;
  if ((nb % 0x10) == 0xC)
    nb2 = 12;
  if ((nb % 0x10) == 0xD)
    nb2 = 13;
  if ((nb % 0x10) == 0xE)
    nb2 = 14;
  if ((nb % 0x10) == 0xF)
    nb2 = 15;
  return nb2;
}

int		type_a(va_list *arg, char *buffer, t_type *tab)
{
  unsigned int	nb1, nb2, nb3, nb4;
  int		i;
  t_uint32	adress;

  i = 0;
  adress = va_arg(*arg, t_uint32);
  nb1 = convert_basenb1(adress & 0xFF) + convert_basenb2(adress & 0xFF);
  nb2 = convert_basenb1((adress & 0xFF00) / 0x100) +
    convert_basenb2((adress & 0xFF00) / 0x100);
  nb3 = convert_basenb1((adress & 0xFF0000) / 0x10000) +
    convert_basenb2((adress & 0xFF0000) / 0x10000);
  nb4 = convert_basenb1(((adress & 0xFF000000) / 0x1000000) & 0xFF) +
    convert_basenb2(((adress & 0xFF000000) / 0x1000000) & 0xFF);
  i += my_printnbr(nb4, buffer, tab);
  my_printchar('.', buffer);
  i += my_printnbr(nb3, buffer, tab);
  my_printchar('.', buffer);
  i += my_printnbr(nb2, buffer, tab);
  my_printchar('.', buffer);
  i += my_printnbr(nb1, buffer, tab);
  return i + 3;
}

int		type_A(va_list *arg, char *buffer, t_type *tab)
{
  int		i;
  t_uint32	*adress;

  i = 0;
  adress = va_arg(*arg, t_uint32*);
  i += my_printnbr(convert_basenb1(adress[0] & 0xFF), buffer, tab);
  i += my_printchar(':', buffer);
  i += my_printnbr(convert_basenb2(adress[0] & 0xFF), buffer, tab);
  i += my_printchar(':', buffer);
  i += my_printnbr(convert_basenb1((adress[1] & 0xFF)), buffer, tab);
  i += my_printchar(':', buffer);
  i += my_printnbr(convert_basenb2((adress[1] & 0xFF)), buffer, tab);
  i += my_printchar(':', buffer);
  i += my_printnbr(convert_basenb1((adress[2] & 0xFF)), buffer, tab);
  i += my_printchar(':', buffer);
  i += my_printnbr(convert_basenb2((adress[2] & 0xFF)), buffer, tab);
  i += my_printchar(':', buffer);
  i += my_printnbr(convert_basenb1(((adress[3] & 0xFF)) & 0xFF), buffer, tab);
  i += my_printchar(':', buffer);
  i += my_printnbr(convert_basenb2(((adress[3] & 0xFF)) & 0xFF), buffer, tab);
  return i;
}
