/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon May 16 19:26:54 2005 Damien Laniel
** Last update Sun Nov 13 18:24:52 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "set.h"
#include "dlist.h"
#include "../../kaneton/malloc/kmalloc.h"
#include "../console/console.h"

t_set_set	*set_set;

static int	cmp_set(const void *data1, const void *data2)
{
  t_set		*s1 = (t_set *) data1;
  t_set		*s2 = (t_set *) data2;

  if (s1->setid > s2->setid)
    return 1;
  else
    if (s1->setid < s2->setid)
      return -1;
  return 0;
}

static int	cmp_object(const void *data1, const void *data2)
{
  t_id		id1 = * (t_id *) data1;
  t_id		id2 = * (t_id *) data2;

  if (id1 > id2)
    return 1;
  else
    if (id1 < id2)
      return -1;
  return 0;
}

static void	free_set(void *data)
{
  t_set		*set = (t_set *) data;

  free(set->data);
  free(set);
}

/* static void	print_string(const void *msg) */
/* { */
/*   cons_print_string((char *) msg); */
/* } */

/* static void	add(t_set_set **set_set, void *data) */
/* { */
/* /\*   t_set		*set = (t_set *) data; *\/ */

/*   set_list_add_item_end(set_set, data); */
/* } */

/* static void	delete(t_set_set **set_set, void *data) */
/* { */
/* /\*   t_set		*set = (t_set *) data; *\/ */

/*   set_list_delete_item(set_set, data, cmp_set, free_set); */
/* } */

static t_set	*set_find_set(t_setid setid)
{
  t_set_set	*cursor;

  for (cursor = set_set; NULL != cursor; cursor = cursor->next)
    if (setid == ((t_set *)cursor->data)->setid)
      return cursor->data;
  return NULL;
}

int	set_init(void)
{
  set_set = NULL;
  return 0;
}

int			set_rsv(t_type_set type, t_sort sort, t_size objectsz,
				t_setsz setsz, t_setid *setid)
{
  t_set			*s;
  static t_setid	cur_set_id = 0;

  s = malloc(sizeof (t_set), KASID);
  s->setid = cur_set_id;
  *setid = cur_set_id;
  cur_set_id++;
  s->type = type;
  s->sort = sort;
  s->objectsz = objectsz;
  s->initsz = setsz;
  switch (s->type)
    {
    case SET_TYPE_LIST:
      if (!(s->data = malloc(sizeof (t_set_list **), KASID)))
	return 1;
      *(t_set_list **)(s->data) = NULL;
      break;
    case SET_TYPE_DLIST:
      if (!(s->data = malloc(sizeof (t_set_dlist **), KASID)))
	return 1;
      *(t_set_dlist **)(s->data) = NULL;
      break;
    default:
      s->data = NULL;
    }
  set_list_add_item_end(&set_set, s);
  return 0;
}

int		set_rel(t_setid setid)
{
  t_set		s;

  s.setid = setid;
  set_list_delete_item(&set_set, &s, cmp_set, free_set);
  return 0;
}

int		set_get(t_setid setid, t_id id, t_iterator *iterator)
{
  t_set		*s;

  if ((s = set_find_set(setid)) == NULL)
    return 1;
  iterator->id = id;
  switch (s->type)
    {
    case SET_TYPE_LIST:
      iterator->addr = set_list_find_item(*(t_set_list **)(s->data), &id, cmp_object);
      return (NULL == iterator->addr) ? 1 : 0;
    case SET_TYPE_DLIST:
      iterator->addr = set_dlist_find_item_eq(*(t_set_dlist **)(s->data), &id, cmp_object);
      return (NULL == iterator->addr) ? 1 : 0;
    default:
      return 1;
    }
}

int		set_head(t_setid setid, t_iterator *iterator)
{
  t_set		*s;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  switch (s->type)
    {
    case SET_TYPE_LIST:
      if ((iterator->addr = set_list_get_item_head(*(t_set_list **)(s->data))) == NULL)
	return 1;
      iterator->id = *((t_id *)iterator->addr);
      return 0;
    case SET_TYPE_DLIST:
      if (NULL == (iterator->addr = set_dlist_get_item_head(*(t_set_dlist **)(s->data))))
	return 1;
      iterator->id = *((t_id *)iterator->addr);
      return 0;
    default:
      return 1;
    }
}

int		set_tail(t_setid setid, t_iterator *iterator)
{
  t_set		*s;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  switch (s->type)
  {
    case SET_TYPE_LIST:
      if ((iterator->addr = set_list_get_item_end(*(t_set_list **)(s->data))) == NULL)
	return 1;
      iterator->id = *((t_id *)iterator->addr);
      return 0;
    case SET_TYPE_DLIST:
      if (NULL == (iterator->addr = set_dlist_get_item_end(*(t_set_dlist **)(s->data))))
	return 1;
      iterator->id = *((t_id *)iterator->addr);
      return 0;
    default:
      return 1;
  }
}

/* static int	set_prev_list(t_set_list *l, t_iterator current, t_iterator *previous) */
/* { */
/*   if (NULL == l) */
/*     return 1; */
/*   while (NULL != l->next) */
/*   { */
/*     if (current.addr == l->next) */
/*     { */
/*       previous->addr = l; */
/*       previous->id = *((t_id *)l->data); */
/*       return 0; */
/*     } */
/*     l = l->next; */
/*   } */
/*   return 1; */
/* } */

/* static int	set_prev_dlist(t_iterator current, t_iterator *previous) */
/* { */
/*   if (NULL == current.addr) */
/*     return 1; */
/*   previous->id = *((t_id *)((t_set_dlist *)current.addr)->prev->data); */
/*   previous->addr = ((t_set_dlist *)current.addr)->prev; */
/*   return 0; */
/* } */

int		set_prev(t_setid setid, t_iterator current, t_iterator *previous)
{
  t_set		*s;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  switch (s->type)
  {
    case SET_TYPE_LIST:
      if ((previous->addr = set_list_find_prev_item(*(t_set_list **)(s->data), &(current.id), cmp_object)) == NULL)
	return 1;
      previous->id = *((t_id *)previous->addr);
      return 0;
    case SET_TYPE_DLIST:
      if ((previous->addr = set_dlist_find_prev_item(*(t_set_dlist **)(s->data), &(current.id), cmp_object)) == NULL)
	return 1;
      previous->id = *((t_id *)previous->addr);
      return 0;
    default:
      return 1;
  }
}

/* static int	set_next_list(t_iterator current, t_iterator *next) */
/* { */
/*   if (NULL == current.addr) */
/*     return 1; */
/*   next->id = *((t_id *)((t_set_list *)current.addr)->next); */
/*   next->addr = ((t_set_list *)current.addr)->next; */
/*   return 0; */
/* } */

int		set_next(t_setid setid, t_iterator current, t_iterator *next)
{
  t_set		*s;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  switch (s->type)
  {
    case SET_TYPE_LIST:
      if ((next->addr = set_list_find_next_item(*(t_set_list **)(s->data), &(current.id), cmp_object)) == NULL)
	return 1;
      next->id = *((t_id *)next->addr);
      return 0;
    case SET_TYPE_DLIST:
      if ((next->addr = set_dlist_find_next_item(*(t_set_dlist **)(s->data), &(current.id), cmp_object)) == NULL)
	return 1;
      next->id = *((t_id *)next->addr);
      return 0;
    default:
      return 1;
  }
}

int		set_insert(t_setid setid, void *object)
{
  t_set		*s;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  switch (s->sort)
    {
    case SET_SORT_ENABLE:
    case SET_SORT_DISABLE:
      switch (s->type)
	{
	case SET_TYPE_LIST:
	  set_list_add_item_end(s->data, object);
	  return 0;
	case SET_TYPE_DLIST:
	  set_dlist_add_item_end(s->data, object);
	  return 0;
	default:
	  return 1;
	}
    case SET_SORT_MANUAL:
      return 1;
    default:
      return 1;
    }
}

int		set_insert_head(t_setid setid, void *object)
{
  t_set		*s;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  switch (s->sort)
    {
    case SET_SORT_MANUAL:
      switch (s->type)
	{
	case SET_TYPE_LIST:
	  set_list_add_item_head(s->data, object);
	  return 0;
	case SET_TYPE_DLIST:
	  set_dlist_add_item_head(s->data, object);
	  return 0;
	default:
	  return 1;
	}
    case SET_SORT_ENABLE:
    case SET_SORT_DISABLE:
      return 1;
    default:
      return 1;
    }
}

int		set_insert_tail(t_setid setid, void *object)
{
  t_set		*s;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  switch (s->sort)
    {
    case SET_SORT_MANUAL:
      switch (s->type)
	{
	case SET_TYPE_LIST:
	  set_list_add_item_end(s->data, object);
	  return 0;
	case SET_TYPE_DLIST:
	  set_dlist_add_item_end(s->data, object);
	  return 0;
	default:
	  return 1;
	}
    case SET_SORT_ENABLE:
    case SET_SORT_DISABLE:
      return 1;
    default:
      return 1;
    }
}

int		set_insert_before(t_setid setid, t_id id, void *object)
{
  t_set		*s;
  t_set_list	*l;
  t_set_list	*n;
  t_set_dlist	*ll;
  t_set_dlist	*nn;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  switch (s->sort)
    {
    case SET_SORT_MANUAL:
      switch (s->type)
	{
	case SET_TYPE_LIST:
	  if (NULL == (l = *(t_set_list **)(s->data)))
	    return 1;
	  if (id == *((t_id *)l->data))
	    {
	      n = (t_set_list *)malloc(sizeof (t_set_list), KASID);
	      n->data = object;
	      n->next = l;
	      s->data = n;
	      return 0;
	    }
	  while (NULL != l->next)
	    if (id == *((t_id *)l->next->data))
	      {
		n = (t_set_list *)malloc(sizeof (t_set_list), KASID);
		n->data = object;
		n->next = l->next;
		l->next = n;
		return 0;
	      }
	    else
	      l = l->next;
	  return 1;
	case SET_TYPE_DLIST:
	  if (NULL == (ll = *(t_set_dlist **)(s->data)))
	    return 1;
	  if (id == *((t_id *)ll->data))
	    {
	      nn = (t_set_dlist *)malloc(sizeof (t_set_dlist), KASID);
	      nn->data = object;
	      nn->next = ll;
	      ll->prev = nn;
	      nn->prev = NULL;
	      s->data = n;
	      return 0;
	    }
	  while (NULL != ll->next)
	    if (id == *((t_id *)ll->next->data))
	      {
		nn = (t_set_dlist *)malloc(sizeof (t_set_dlist), KASID);
		nn->data = object;
		nn->next = ll->next;
		nn->prev = ll;
		ll->next = nn;
		if (NULL != nn->next)
		  nn->next->prev = nn;
		return 0;
	      }
	    else
	      ll = ll->next;
	  return 1;
	default:
	  return 1;
	}
    case SET_SORT_ENABLE:
    case SET_SORT_DISABLE:
      return 1;
    default:
      return 1;
    }
}

int	set_insert_after(t_setid setid, t_id id, void *object)
{
  t_set         *s;
  t_set_list    *l;
  t_set_list    *n;
  t_set_dlist   *ll;
  t_set_dlist   *nn;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  switch (s->sort)
    {
    case SET_SORT_MANUAL:
      switch (s->type)
	{
	case SET_TYPE_LIST:
	  for (l = *(t_set_list **)(s->data); NULL != l; l = l->next)
	    if (id == *((t_id *)l->data))
	      {
		n = (t_set_list *)malloc(sizeof (t_set_list), KASID);
		n->data = object;
		n->next = l->next;
		l->next = n;
		return 0;
	      }
	  return 1;
	case SET_TYPE_DLIST:
	  for (ll = *(t_set_dlist **)(s->data); NULL != ll; ll = ll->next)
	    if (id == *((t_id *)ll->data))
	      {
		nn = (t_set_dlist *)malloc(sizeof (t_set_dlist), KASID);
		nn->data = object;
		nn->next = ll->next;
		nn->prev = ll;
		ll->next = nn;
		if (NULL != nn->next)
		  nn->next->prev = nn;
		return 0;
	      }
	  return 1;
	default:
	  return 1;
	}
    case SET_SORT_ENABLE:
    case SET_SORT_DISABLE:
      return 1;
    default:
      return 1;
    }
}

int		set_delete(t_setid setid, t_id id)
{
  t_set		*s;

  if (NULL == (s = set_find_set(setid)))
    return 1;
  set_list_delete_item(s->data, &id, cmp_object, free);
  return 0;
}

int	set_clear(void)
{
  set_list_free(&set_set, free_set);
  return 0;
}
