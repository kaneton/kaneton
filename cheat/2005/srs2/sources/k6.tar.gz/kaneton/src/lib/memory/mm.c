/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sat Mar 19 15:29:00 2005 Damien Laniel
** Last update Sun Nov 13 18:47:24 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "pm.h"
#include "vm.h"
#include "as.h"
#include "ia-32/vm.h"
#include "../console/console.h"

/*!
** Reserve physical and virtual memory and map
** @param	asid	The address space
** @param	vaddr	Start of the allocation (result)
** @param	npages	Number of pages to reserve
*/
int		mm_rsv(t_asid asid, t_vaddr *vaddr, t_vsize npages)
{
  int		ret_code = 0;
  t_paddr	paddr;

  if ((ret_code = pm_rsv(asid, &paddr, npages, PM_FLAG_ANY)))
    {
      while (1)
	printf("mm_rsv: error on pm_rsv\n");
      return ret_code;
    }
  
  if ((ret_code = vm_rsv(asid, vaddr, npages, VM_FLAG_ANY)))
    {
      while (1)
	printf("mm_rsv: erro on vm_rsv\n");
      return ret_code;
    }

  if ((ret_code = machdep_vm_map(asid, paddr, *vaddr, npages)))
    {
      while (1)
	printf("mm_rsv: error on vm_map");
      return ret_code;
    }

  return 0;
}

int		mm_rel(t_asid asid, t_vaddr vaddr, t_vsize npages)
{
  int		ret_code = 0;
  t_paddr	paddr;
  t_as		*as;

  as_get(asid, &as);
  paddr = vm_to_pm((word *)as->pd_vaddr, vaddr, asid, as->pd_addr);
  if ((ret_code = pm_rel(asid, paddr, npages)))
    {
      while (1)
	printf("mm_rel: error on pm_rel\n");
      return ret_code;
    }
  if ((ret_code = vm_rel(asid, vaddr, npages)))
    {
      while (1)
	printf("mm_rel: error on vm_rel\n");
      return ret_code;
    }
  if ((ret_code = vm_unmap(asid, vaddr, npages)))
    {
      while (1)
	printf("mm_rel: error on vm_rel\n");
      return ret_code;
    }
  return 0;
}
