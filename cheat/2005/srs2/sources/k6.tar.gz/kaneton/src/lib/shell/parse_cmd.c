/*
** Copyright (C) Castaing Antoine alias xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Sun Mar 12 01:45:27 2005 Castaing Antoine
** Last update Tue Oct  4 22:44:22 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../console/console.h"
#include "../../kaneton/drivers/keyboard/keys.h"
#include "../libc/libc.h"
#include "../libc/string.h"
#include "parse_cmd.h"
#include "print_gdt.h"
#include "print_idt.h"
#include "print_modules.h"
#include "sh_clear.h"
#include "sh_info.h"
#include "sh_echo.h"
#include "sh_test.h"
#include "../../kaneton/recover.h"
#include "../../kaneton/drivers/timer/timer.h"
#include "sh_enable.h"
#include "sh_disable.h"
/* # define DEBUG */


void sh_quit(char *arg[NB_MAX_ARG], int nb_arg)
{
  printf("Kaneton shot down.\n");
  __asm__ __volatile__ (
  "		hlt		;"
  );
  nb_arg = 0;
  arg[0] = 0;
#ifdef DEBUG
  printf("quit : <%d>\n", quit);
#endif
  quit = 0;
#ifdef DEBUG
  printf("quit : <%d>\n", quit);
#endif
}

/*
** \brief this function test if the char is a separator
** \param c it is a pointer on the char
** \return int it is a boolean to say if the char is aseparator or not
*/
static int	is_sep(char *c)
{
  char	sep[5] = " \n\t\0\"";
  int	i = 0;

  for (; i < 5; i++)
    if (*c == sep[i])
      {
	return i + 1;
      }

  return 0;
}


char fct_info_print[5] = "info";
char fct_test[5] = "test";
char fct_echo[5] = "echo";
char fct_clear[6] = "clear";
char fct_time[5] = "time";
char fct_quit[5] = "quit";
char fct_enable[7] = "enable";
char fct_disable[8] = "disable";

struct s_shell_builtin shell_fct[NB_BUILTIN] =
   {
     {(char *)(&fct_clear), (fct_shell)sh_clear},
     {(char *)(&fct_info_print), (fct_shell)sh_info},
     {(char *)(&fct_echo), (fct_shell)sh_echo},
     {(char *)(&fct_test), (fct_shell)sh_test},
     {(char *)(&fct_time), (fct_shell)time},
     {(char *)(&fct_quit), (fct_shell)sh_quit},
     {(char *)(&fct_disable), (fct_shell)sh_disable},
     {(char *)(&fct_enable), (fct_shell)sh_enable}
};


int call_cmd(char *cmd,char *arg[NB_MAX_ARG], int nb_arg)
{
  int	i = 0;

  if (cmd)
    {
#ifdef DEBUG
      printf("%s\n",cmd);
#endif
      for (; i < NB_BUILTIN; i++)
	{
#ifdef DEBUG
	  printf("nb_builtin %d et i %d\n", NB_BUILTIN, i);
	  printf("la commande %s match %s\n", cmd, shell_fct[i].fct_label);
#endif
	  if (!strcmp(shell_fct[i].fct_label, cmd)){
#ifdef DEBUG
	    printf("%s == %s\n", shell_fct[i].fct_label
		   , cmd);
#endif
	    shell_fct[i].fct(arg, nb_arg);
	    return 0;
	  }
#ifdef DEBUG
	  printf("%s != %s\n", shell_fct[i].fct_label
		 , cmd);
#endif
	}
      return 1;
    }
  return 1;
}

void	parse_buff(char *file)
{
  int	temp;
  char	*cur = file;
  int	i = 0;
  char	*cmd = 0;
  char	*arg[NB_MAX_ARG];
  int	nb_arg = 0;
  int	quoted = 0;

  while (*cur)
    {
      for (i = 0; ((!(temp = is_sep(cur))) && !quoted) ||
	     ((*cur != '\"') && quoted && *cur);
	   i++,cur++)
	;
      if (cur != file) {
	if (!cmd) {
	  if (quoted)
	    {
	      quoted = 0;
	      ++file;
	    }
	  cmd = file;
	  *cur = '\0';
	}
	else {
      	  if (quoted)
	    {
	      quoted = 0;
	      ++file;
	    }
	  if (nb_arg < NB_MAX_ARG - 1)
	    arg[nb_arg++] = file;
	  *cur = '\0';
	}
	switch (temp){
	case 1:
	  file = ++cur;
	  break;
	case 2:
	  call_cmd(cmd, arg, nb_arg);
	  cmd = 0;
	  nb_arg = 0;
	  file = ++cur;
	  break;
	case 3:
	  file = ++cur;
	  break;
	case 4:
	  call_cmd(cmd,arg, nb_arg);
	  return;
	  break;
	case 5:
	  call_cmd(cmd, arg, nb_arg);
	  cmd = 0;
	  nb_arg = 0;
	  file = ++cur;
	  break;
	default: break;
	}
      }
      else {
	if (*cur == '\"')
	  quoted = 1;
	cur++;
	file++;
      }
    }
}

void	reinit_buff()
{
  unsigned char	i = 0;

  buff_cmd[sh_buf_pos] = '\n';
  buff_cmd[sh_buf_pos + 1] = 0;
  parse_buff(buff_cmd);
  printf("la chaine de commande est : <%s>\n",buff_cmd);
 /*  while (1); */
  for (; i < 255; i++)
    buff_cmd[i] = 0;
  sh_buf_pos = 0;
}
