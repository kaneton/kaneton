/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sat Mar 26 18:57:24 2005 Nicolas Clermont
** Last update Fri Oct  7 11:06:23 2005 xebech
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "test_vm.h"
#include "../console/console.h"
#include "../../kaneton/malloc/string.h"
#include "parse_cmd.h"
#include "../memory/vm.h"

void		test_vmrsv(char *arg[NB_MAX_ARG], int nb_arg)
{
  t_vaddr	test_addr;

  if (nb_arg != 3)
    {
      printf("vmrsv: wrong number of arguments\n");
      printf("Usage: test vmrsv asid npages\n");
    }
  else
    {
      vm_rsv(atoi(arg[1]), &test_addr, atoi(arg[2]), VM_FLAG_ANY);
      printf("The vm_area of %d pages for as %d reserved begin at 0x%x\n", atoi(arg[2]), atoi(arg[1]), test_addr);
    }
}
