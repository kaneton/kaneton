/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sat Mar 19 15:33:48 2005 Damien Laniel
** Last update Thu May 19 23:36:16 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "vm.h"
#include "ia-32/vm.h"

int	vm_init(t_asid asid)
{
  return machdep_vm_init(asid);
}

int	vm_rsv(t_asid asid, t_vaddr *addr, t_vsize npages, t_vmflags flags)
{
  return machdep_vm_rsv(asid, addr, npages, flags);
}

int	vm_rel(t_asid asid, t_vaddr addr, t_vsize npages)
{
  return machdep_vm_rel(asid, addr, npages);
}

int	vm_attr(t_asid asid, t_vaddr addr, t_vsize npages, t_vattr attr)
{
  return machdep_vm_attr(asid, addr, npages, attr);
}

int	vm_flush(t_asid asid)
{
  return machdep_vm_flush(asid);
}

int	vm_clear(void)
{
  return machdep_vm_clear();
}

int	vm_map(t_asid asid, t_paddr paddr, t_vaddr vaddr, t_vsize npages)
{
  return machdep_vm_map(asid, paddr, vaddr, npages);
}

int	vm_unmap(t_asid asid, t_vaddr addr, t_vsize npages)
{
  return machdep_vm_unmap(asid, addr, npages);
}

int	vm_copy(t_asid from, t_vaddr src, t_asid to, t_vaddr dst, t_vsize nbytes)
{
  return machdep_vm_copy(from, src, to, dst, nbytes);
}
