/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:43:13 2005 Castaing Antoine
** Last update Fri Jun 10 22:43:14 2005 Castaing Antoine
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../console/console.h"
#include "../../bootloader/ch_cr.h"

/*
** Print the CPU registers
*/

void	print_reg(void)
{
  printf("CPU Registers :\n");
  printf("   CR0             : 0x%x%x\n", get_CR0() / 0x10, get_CR0() % 0x10);
  /*   printf("   CR1             : 0x%x\n", get_CR1()); */
  printf("   CR2             : 0x%x%x\n", get_CR2() / 0x10, get_CR2() % 0x10);
  printf("   CR3             : 0x%x%x\n", get_CR3() / 0x10, get_CR3() % 0x10);
  printf("   CR4             : 0x%x%x\n", get_CR4() / 0x10, get_CR4() % 0x10);
  printf("Extended Registers :\n");
  printf("   EAX             : 0x%x%x\n", get_EAX() / 0x10, get_EAX() % 0x10);
  printf("   EBX             : 0x%x%x\n", get_EBX() / 0x10, get_EBX() % 0x10);
  printf("   ECX             : 0x%x%x\n", get_ECX() / 0x10, get_ECX() % 0x10);
  printf("   EDX             : 0x%x%x\n", get_EDX() / 0x10, get_EDX() % 0x10);
  printf("Stack Ragisters :\n");
  printf("   EBP             : 0x%x%x\n", get_EBP() / 0x10, get_EBP() % 0x10);
  printf("   ESP             : 0x%x%x\n", get_ESP() / 0x10, get_ESP() % 0x10);
}
