/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sun Nov 13 16:53:15 2005 Nicolas Clermont
** Last update Sat Dec  3 20:45:23 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mod.h"
#include "string.h"

/*!
** List modules and their associated tasks/threads...
*/
int		ps(void)
{
  t_msg		*msg, *answer;

  msg = create_msg(SERVICE_MOD, 1);
  *(char *)(msg->data) = MOD_CMD_PS;
  send_msg(msg);
  answer = wait_msg();

  return 0;
}

/*!
** Get the module identifier of the module named "module_name"
** @param	module_name	We search its modid
** @return	The modid of module_name
*/
t_modid		get_modid(char *module_name)
{
  t_msg		*msg;
  t_modid	modid;

  msg = create_msg(SERVICE_MOD, 1 + strlen(module_name));
  *(char *)(msg->data) = (char)MOD_CMD_GET_MODID;
  strncpy((char *)(msg->data + 1), module_name, strlen(module_name));
  send_msg(msg);
  msg = wait_msg();
  modid = *(unsigned int *)(msg->data);

  return modid;
}

/*!
** Get the task identifier of the module named "module_name"
** @param	module_name	We search its task id
** @return	The task id of module_name
*/
t_tskid		get_tskid(char *module_name)
{
  t_msg		*msg;
  t_tskid	tskid;

  msg = create_msg(SERVICE_MOD, 1 + strlen(module_name));
  *(char *)(msg->data) = (char)MOD_CMD_GET_TSKID;
  strncpy((char *)(msg->data + 1), module_name, strlen(module_name));
  send_msg(msg);
  msg = wait_msg();
  tskid = *(unsigned int *)(msg->data);

  return tskid;
}

/*!
** Execute the program module_name
*/
int	exec(char *module_name)
{
  t_msg *msg;
  int   return_value;

  msg = create_msg(SERVICE_MOD, 1 + strlen(module_name));
  *(char *)(msg->data) = (char)MOD_CMD_EXEC;
  strncpy((char *)(msg->data + 1), module_name, strlen(module_name));
  send_msg(msg);
  msg = wait_msg();
  return_value = *(unsigned int *)(msg->data);

  return return_value;
}
