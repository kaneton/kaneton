/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Wed May 25 02:13:11 2005 Damien Laniel
** Last update Mon Sep 26 20:25:10 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


/*
** This function is unsafe, please use strncpy instead
*/


/* void	strcpy (char *dest, const char *src) */
/* { */
/*   int	i = 0; */

/*   for (i = 0; src[i]; ++i) */
/*     dest[i] = src[i]; */
/*   dest[i] = '\0'; */
/* } */
