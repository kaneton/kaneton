/*
** format_hX.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 02:52:40 2002 nicolas clermont
** Last update Wed Oct 30 06:30:35 2002 nicolas clermont
*/
#include "my_printf.h"

static int	lXflag_mz(char *buffer, t_type *tab, unsigned long int x)
{
  int		i;
  int		j;

  i = 0;
  if ((tab[9].mask & FLAG_SHARP) == FLAG_SHARP)
    i += my_printstr("0X", buffer);
  if ((tab[9].mask & FLAG_DOT) == FLAG_DOT)
    for (j = 0; j < (tab[7].mask - my_baselen(x, "0123456789ABCDEF")); j++)
      i += my_printchar('0', buffer);
  if ((tab[9].mask & FLAG_ZERO) != FLAG_ZERO)
    i += my_printnbr_base(x, "0123456789ABCDEF", buffer);
  return i;
}

static int	lXflag_d_notm(char *buffer, t_type *tab, unsigned long int x)
{
  int		i;
  int		j;
  int		decal;

  i = decal = 0;
  if (flag_det(tab, FLAG_SHARP))
    decal = 2;
  if (tab[8].mask > tab[7].mask)
    for (j = 0; j < (tab[8].mask - (tab[7].mask + decal)); j++)
      i += my_printchar(' ', buffer);
  if (flag_det(tab, FLAG_SHARP))
    i += my_printstr("0X", buffer);
  for (j = 0; j < (tab[7].mask - my_baselen(x, "0123456789ABCDEF")); j++)
    i += my_printchar('0', buffer);
  i += my_printnbr_base(x, "0123456789ABCDEF", buffer);
  return i;
}

static int	lXflag_width(char *buffer, t_type *tab, char *fill,
			     unsigned long int x)
{
  int		i;
  int		j;
  int		decal;
  int		max;

  i = decal = 0;
  max = my_baselen(x, "0123456789ABCDEF");
  if (tab[8].mask > max)
  {
    if ((tab[9].mask & FLAG_SHARP) == FLAG_SHARP)
      decal = 2;
    if (flag_det(tab, FLAG_ZERO) && !flag_det(tab, FLAG_MOINS))
      *fill = '0';
    if ((tab[9].mask & FLAG_DOT) == FLAG_DOT)
      if (tab[7].mask > max)
	max = tab[7].mask;
    for (j = 0; j < (tab[8].mask - (max + decal)); j++)
      i += my_printchar(*fill, buffer);
  }
  return i;
}

int			type_X_long(va_list *arg, char *buffer, t_type *tab)
{
  unsigned int long	x;
  int			i;
  int			decal;
  char			fill;

  fill = ' ';
  i = decal = 0;
  x = va_arg(*arg, unsigned int);
  if (flag_det(tab, FLAG_MOINS) || flag_det(tab, FLAG_ZERO))
      i += lXflag_mz(buffer, tab, x);
  if (flag_det(tab, FLAG_DOT) && !flag_det(tab, FLAG_MOINS))
    return (i += lXflag_d_notm(buffer, tab, x));
  if (tab[8].mask != 1)
    i += lXflag_width(buffer, tab, &fill, x);
  if ((tab[9].mask & FLAG_MOINS) != FLAG_MOINS)
    {
      if (flag_det(tab, FLAG_SHARP) && !flag_det(tab, FLAG_ZERO))
	i += my_printstr("0X", buffer);
      i += my_printnbr_base(x, "0123456789ABCDEF", buffer);
    }
  return i;
}
