/*
** util_base.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 01:26:53 2002 nicolas clermont
** Last update Wed Oct 30 01:28:02 2002 nicolas clermont
*/
#include "my_printf.h"

int		recurse_nbr_base(unsigned int nbr, char *base, int size,
				 char *buffer)
{
  int		i;

  i = 1;
  if (nbr / size)
    {
      i = 1 + recurse_nbr_base(nbr / size, base, size, buffer);
      my_printchar(base[nbr % size], buffer);
    }
  else
    if (base[nbr % size])
      my_printchar(base[nbr % size], buffer);
  return i;
}

unsigned int	my_printnbr_base(unsigned int nbr, char *base, char *buffer)
{
  return (recurse_nbr_base(nbr, base, my_strlen(base), buffer));
}

int		my_baselen(unsigned int nbr, char *base)
{
  int		i;
  int		size;

  i = 1;
  size = my_strlen(base);
  if (nbr / size)
      i = 1 + my_baselen(nbr / size, base);
  return i;
}
