/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon May 16 19:14:47 2005 Damien Laniel
** Last update Sun Nov 13 18:24:31 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef SET_H_
# define SET_H_

#include "../../include/kaneton/types.h"
#include "list.h"

#define	FOREACH_FORWARD		0x01
#define	FOREACH_BACKWARD	0x02


/* #define	SET_FOREACH(_mode_, _setid_, _iterator_)	\ */
/* _set_foreach(_mode_, _setid_, _iterator_) */

/*
** @param _mode_ can be FOREACH_FORWARD or FOREACH_BACKWARD
*/
#define	SET_FOREACH(_mode_, _setid_, _iterator_)				\
  for ((_iterator_)->id = ID_UNUSED, (_iterator_)->addr = NULL;			\
       ((ITERATOR_UNUSED((_iterator_)) == 0) ? ((_mode_) == FOREACH_FORWARD ?	\
					   set_head((_setid_), (_iterator_)) :	\
					   set_tail((_setid_), (_iterator_))) :	\
	 ((_mode_ == FOREACH_FORWARD) ?						\
	  set_next((_setid_), *(_iterator_), (_iterator_)) :			\
	  set_prev((_setid_), *(_iterator_), (_iterator_)))) == 0;		\
       )


#define ITERATOR_UNUSED(_iterator_)	\
((((_iterator_)->id == ID_UNUSED) &&	\
((_iterator_)->addr == NULL)) ? 0 : -1)

#define ITERATOR_ID(_iterator_)		\
(_iterator_)->id

#define ITERATOR_ADDR(_iterator_)	\
(_iterator_)->addr

typedef struct	s_iterator
{
  t_id		id;
  void		*addr;
}		t_iterator;

typedef t_set_list	t_set_set;
typedef t_id		t_setid;
typedef t_uint32	t_setsz;
/* typedef t_uint32	t_type; */
/* typedef t_uint32	t_sort; */

typedef enum
  {
    SET_TYPE_ANY,
    SET_TYPE_ARRAY,
    SET_TYPE_LIST,
    SET_TYPE_DLIST,
    SET_TYPE_BTREE,
    SET_TYPE_STACK,
    SET_TYPE_QUEUE,
    SET_TYPE_CIRCULAR
  } t_type_set;

typedef enum
  {
    SET_SORT_ENABLE,
    SET_SORT_DISABLE,
    SET_SORT_MANUAL
  } t_sort;

typedef struct	s_set
{
  t_setid	setid;
  t_type_set	type;
  t_sort	sort;
  t_size	objectsz;
  t_setsz	initsz;
  void		*data;
}		t_set;

int	set_init(void);

int	set_rsv(t_type_set type, t_sort sort, t_size objectsz,
		t_setsz setsz, t_setid *setid);

int	set_rel(t_setid setid);

int	set_get(t_setid setid, t_id id, t_iterator *iterator);

int	set_head(t_setid setid, t_iterator *iterator);

int	set_tail(t_setid setid, t_iterator *iterator);

int	set_prev(t_setid setid, t_iterator current, t_iterator *previous);

int	set_next(t_setid setid, t_iterator current, t_iterator *next);

int	set_insert(t_setid setid, void *object);

int	set_insert_head(t_setid setid, void *object);

int	set_insert_tail(t_setid setid, void *object);

int	set_insert_before(t_setid setid, t_id id, void *object);

int	set_insert_after(t_setid setid, t_id id, void *object);

int	set_delete(t_setid setid, t_id id);

int	set_clear(void);

#endif /* !SET_H_ */
