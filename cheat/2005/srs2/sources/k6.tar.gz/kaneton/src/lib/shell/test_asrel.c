/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sat Mar 26 20:03:51 2005 Nicolas Clermont
** Last update Wed Dec  7 10:30:07 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "test_pmrel.h"
#include "../console/console.h"
#include "../../kaneton/malloc/string.h"
#include "parse_cmd.h"
#include "../memory/as.h"

void		test_asrel(char *arg[NB_MAX_ARG], int nb_arg)
{
/*   t_paddr	test_addr; */

  if (nb_arg != 2)
    {
      printf("asrel: wrong number of arguments\n");
      printf("Usage: test asrel asid\n");
    }
  else
    {
      as_rel(atoi(arg[1]));
      printf("The adress space %d has been remove.\n", (unsigned int)arg[1]);
    }
}
