/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Mon Mar 28 15:08:23 2005 Nicolas Clermont
** Last update Tue Mar 29 02:55:07 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef AREA_H
# define AREA_H

# include "../../../kaneton/class.h"
# include "../../../include/kaneton/types.h"
# include "../../list/list.h"

/*!
** List of physical memory area
*/
typedef t_list		t_area_list;

# define AREA_FREE		0
# define AREA_USED		1

/*!
** Attribute of physical pages
*/
# define PM_ATTR_NONE		0
# define PM_ATTR_SHARE		1
# define PM_ATTR_COW		2
# define PM_ATTR_RESIDENT	4
# define PM_ATTR_AGGREGATE	8

/*!
** This structure describe a physical memory area
*/
typedef struct		s_area
{
  t_paddr		start;
  t_psize		nbpages;
  t_pattr		attr;
  t_class		auth_shared_class;
  int			compt_ref;
}			t_area;

/*!
** Create a struct that identify a physical memory area
** @param	start	Physical address of the beginning of the area
** @param	npages	Number of physical pages of the area
** @param	attr	The attribute of the area
*/
void			area_init(t_paddr start, t_psize npages, t_pattr attr,
				  int type, t_area *new, t_class auth_shared_class);

/*!
** Free all the physical memory identify by an area
** @param	pm_area	Identify the physical area to free
** @param	as_rel	Represent the address space that own the area
*/
void			area_free_pm(t_area *pm_area, void *as);

/*!
** Free n pages in the physical memory area
** @param	start	The address where beginning to free
** @param	npages  The number of pages to free
*/
void			area_free_pages(t_paddr start, t_psize npages);

/*!
** Copy an area structure
** @param	source
** @param	destination
*/
int			area_copy(const void *source, void *destination);

/*!
** Compare two physical memory area
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 the same, 1 different
*/
int			area_cmp(const void *area1, const void *area2);

/*!
** Compare the number of physical pages of two areas
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 the same, 1 different
*/
int			area_cmp_npages(const void *area1, const void *area2);

/*!
** Compare the start address of two areas
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 the same, 1 different
*/
int			area_cmp_start(const void *area1, const void *area2);

/*!
** Compare if the start address of as2 belong to as1
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 the same, 1 different
*/
int			is_addr_in_area(const void *area1, const void *area2);

/*!
** Clear the memory occupied by the structure
** @param	area	area to clear
*/
void			area_clear(void *area);

/*!
** Print the structure
** @param	area	Area to print
*/
void			area_print(const void *area);

/*!
** Modify the properties of an area
** @param	area	Area to modify
** @pram	n_start New start address
** @pram	n_npages New number of pages
*/
void		 	area_modify(t_area *area, t_paddr n_start, t_psize n_npages);

/*!
** Compare the number of physical pages of two areas
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 superior or equal, 1 inferior
*/
int			area_cmp_nbpages(const void *area1, const void *area2);

int			area_cmp_dma(const void *area1, const void *area2);

int			area_cmp_any(const void *area1, const void *area2);

/*!
** Compare if two areas are physically contigous
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 contigous, 1 not
*/
int			area_cmp_cont_down(const void * area1, const void * area2);

/*!
** Compare if two areas are physically contigous
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 contigous, 1 not
*/
int			area_cmp_cont_up(const void * area1, const void * area2);

#endif			/* !AREA_H */
