/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Mon Mar 28 15:07:55 2005 Nicolas Clermont
** Last update Sun Nov 13 18:48:07 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "as.h"
#include "area.h"
#include "../../console/console.h"

/*!
** Create a struct that identify a physical memory area
** @param	start	Physical address of the beginning of the area
** @param	npages	Number of physical pages of the area
** @param	attr	The attribute of the area
*/
void		area_init(t_paddr start, t_psize npages, t_pattr attr, 
			  int type, t_area *new, t_class auth_shared_class)
{
  new->start = start;
  new->nbpages = npages;
  new->attr = attr;
  new->auth_shared_class = auth_shared_class;
  if (type == AREA_USED)
    new->compt_ref = 1;
  else
    new->compt_ref = 0;
}

/*!
** Free all the physical memory identify by an area
** @param	pm_area	Identify the physical area to free
** @param	as_rel	Represent the address space that own the area
*/
void		area_free_pm(t_area *pm_area, void *as_rel)
{
  t_paddr	*pm_to_flush = NULL;
  t_vm_area	fake_area, *vm_area = NULL;
  t_as		*as = NULL;

  as = (t_as*)as_rel;
  fake_area.mapped_pm_area = pm_area->start;
  if (!(vm_area = list_find_item(as->vas_used, &fake_area, vm_area_cmp_mapped_addr)))
    {
      while (1)
	printf("area_free_pm: Pas de correspondance\n");
    }

#ifdef DEBUG
  vm_area_print(vm_area);
  area_print(pm_area);
  int i = 0;
  while (i != 2000000) 
    i++;
#endif

  pm_area->attr = 0;
  pm_area->compt_ref = 0;
  for (pm_to_flush = (t_paddr*)vm_area->start;
       pm_to_flush != (t_paddr*)(vm_area->start + (vm_area->nbpages * PAGE_SIZE));
       pm_to_flush++)
    {
#ifdef DEBUG
      if (pm_to_flush >= (t_paddr*)0x3FFFFF)
	{
	  printf("Fin de l'identity mapping %x\n", pm_to_flush);
	  printf("next %x\n", pm_to_flush + 1);
	}
#endif
      *pm_to_flush = 0;
    }
}

/*!
** Free n pages in the physical memory area
** @param	start	The address where beginning to free
** @param	npages  The number of pages to free
*/
void		area_free_pages(t_paddr start, t_psize npages)
{
  t_paddr	*pm_to_flush = 0;

  for (pm_to_flush = (t_paddr*)start;
       pm_to_flush != (t_paddr*)(start + (npages * PAGE_SIZE));
       pm_to_flush++)
    *pm_to_flush = 0;
}

/*!
** Modify an area
** @param	area	The area to modify
** @param	n_start	The new address of the physical area
** @param	n_npages The new number of pages of the area
*/
void		area_modify(t_area *area, t_paddr n_start, t_psize n_npages)
{
  area->start = n_start;
  area->nbpages = n_npages;
}

/*!
** Copy an area structure
** @param	source
** @param	destination
*/
int		area_copy(const void *source, void *destination)
{
  t_area	*sour = (t_area *)source;
  t_area	*dest = (t_area *)destination;

  if (!source || !destination)
    return 1;
  * dest = * sour;

  return 0;
}

/*!
** Compare two physical memory area
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 the same, 1 different
*/
int		area_cmp(const void *area1, const void *area2)
{
  t_area	*ar1 = (t_area *)area1;
  t_area	*ar2 = (t_area *)area2;

  if (ar1->nbpages > ar2->nbpages || ar1->start > ar2->start)
    return 1;
  if (ar1->nbpages < ar2->nbpages || ar1->start < ar2->start)
    return -1;
  return 0;
}

/*!
** Compare the number of physical pages of two areas
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 the same, 1 different
*/
int		area_cmp_npages(const void *area1, const void *area2)
{
  t_area	*ar1 = (t_area *)area1;
  t_area	*ar2 = (t_area *)area2;

 if (ar1->nbpages > ar2->nbpages)
    return 1;
  if (ar1->nbpages < ar2->nbpages)
    return -1;
  return 0;
}

/*!
** Compare the number of physical pages of two areas
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 superior or equal, 1 inferior
*/
int		area_cmp_nbpages(const void *area1, const void *area2)
{
  t_area	*ar1 = (t_area *)area1;
  t_area	*ar2 = (t_area *)area2;

  if (ar1->nbpages >= ar2->nbpages)
    return 0;
  else
    return 1;
}

/*!
** Compare the number of physical pages of two areas for DMA use
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 superior or equal, 1 inferior
*/
int		area_cmp_dma(const void *area1, const void *area2)
{
  t_area	*ar1 = (t_area *)area1;
  t_area	*ar2 = (t_area *)area2;

  if (ar1->nbpages >= ar2->nbpages && ar1->start < 0x400000)
    return 0;
  else
    return 1;
}

/*!
** Compare the number of physical pages of two areas for no DMA use
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 superior or equal, 1 inferior
*/
int		area_cmp_any(const void *area1, const void *area2)
{
  t_area	*ar1 = (t_area *)area1;
  t_area	*ar2 = (t_area *)area2;

  if (ar1->nbpages >= ar2->nbpages && ar1->start >= 0x400000)
    return 0;
  else
    return 1;
}

/*!
** Compare which area has the smaller start address
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 equal, 1 different
*/
int		area_cmp_start(const void * area1, const void * area2)
{
  t_area *	a1 = (t_area *) area1;
  t_area *	a2 = (t_area *) area2;

  if (a1->start > a2->start)
    return 1;
  if (a1->start < a2->start)
    return -1;
  return 0;
}

/*!
** Compare if two areas are physically contigous
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 contigous, 1 not
*/
int		area_cmp_cont_down(const void * area1, const void * area2)
{
  t_area *	a1 = (t_area *) area1;
  t_area *	a2 = (t_area *) area2;

  if ((a1->start + a1->nbpages * PAGE_SIZE) == a2->start)
    return 0;
  else
    return 1;
}

/*!
** Compare if two areas are physically contigous
** @param	area1	a physical memory area
** @param	area2	a physical memory area
** @return	0 contigous, 1 not
*/
int		area_cmp_cont_up(const void * area1, const void * area2)
{
  t_area *	a1 = (t_area *) area1;
  t_area *	a2 = (t_area *) area2;

  if (a1->start ==  (a2->start + a2->nbpages * PAGE_SIZE))
    return 0;
  else
    return 1;
}

/*!
** Compare if the start address of area2 belong to area1
** @param	area1	a physical memory area
** @param	area2	a physical memory area
*/
int		is_addr_in_area(const void * area1, const void * area2)
{
  t_area *	a1 = (t_area *) area1;
  t_area *	a2 = (t_area *) area2;

  if ((a2->start >= a1->start) &&
      (a2->start < (a1->start + a1->nbpages * PAGE_SIZE)))
    return 0;
  else
    return 1;
}

/*!
** Clear the memory occupied by the structure
** @param	area	area to clear
*/
void		area_clear(void *area)
{
  t_area	*ar = (t_area *)area;

  ar->start = 0;
  ar->nbpages = 0;
  ar->attr = 0;
  ar->compt_ref = 0;
}

/*!
** Print the structure
** @param	area	Area to print
*/
void		area_print(const void *area)
{
  t_area	*ar = (t_area *)area;

  if (ar)
    {
      printf("Area address : %x, Area number of pages : %d",
	     ar->start, ar->nbpages);
      printf(", Area number of access: %d\n", ar->compt_ref);
    }
  else
    printf("Area NULL\n");
}
