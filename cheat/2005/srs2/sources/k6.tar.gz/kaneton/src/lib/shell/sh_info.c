/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:41:59 2005 Castaing Antoine
** Last update Tue Sep 27 11:27:15 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include "sh_info.h"
#include "../console/console.h"
#include "../libc/libc.h"
#include "../libc/string.h"
#include "parse_cmd.h"
#include "print_cpu.h"
#include "print_gdt.h"
#include "print_idt.h"
#include "print_reg.h"
#include "print_modules.h"
#include "print_pm.h"
#include "print_as.h"
#include "print_pmascii.h"

#define NB_INFO_FCT 8

char info_as[3] = "as";
char info_pm[3] = "pm";
char info_cpu[4] = "cpu";
char info_gdt[4] = "gdt";
char info_idt[4] = "idt";
char info_reg[4] = "reg";
char info_modules[8] = "modules";
char info_pmascii[8] = "pmascii";


struct s_info_builtin info_arg[NB_INFO_FCT] =
  {
    {(char *)(&info_as), (fct_info)print_as},
    {(char *)(&info_pm), (fct_info)print_pm},
    {(char *)(&info_cpu), (fct_info)print_cpu},
    {(char *)(&info_idt), (fct_info)print_idt},
    {(char *)(&info_gdt), (fct_info)print_gdt},
    {(char *)(&info_reg), (fct_info)print_reg},
    {(char *)(&info_modules), (fct_info)print_modules},
    {(char *)(&info_pmascii), (fct_info)print_pmascii}
  };

void	sh_info(char *arg[NB_MAX_ARG], int nb_arg)
{
  int	i = 0;
  int	j = 0;

  int k =0;

  switch (nb_arg)
    {
    case 0:
      if (info_general)
	  printf("%s", info_general);
      else
	printf("L'aide de Kaneton n est pas active\n");
      break;
    default:
      for (; i < nb_arg; i++)
	for (j = 0; j < NB_INFO_FCT; j++, ++k)
	  if (!strcmp(info_arg[j].fct_label, arg[i]))
	    info_arg[j].fct();
      break;
    }
}

