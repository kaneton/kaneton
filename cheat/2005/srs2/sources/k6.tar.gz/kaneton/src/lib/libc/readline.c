/*
** Copyright (C) Antoine Castaing aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Sun Nov 13 15:40:49 2005 Antoine Castaing
** Last update Wed Nov 23 12:20:31 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "libc.h"

int getc(t_tskid dest)
{
t_msg		*msg;
t_msg		*msg2;
 char		*tmp;
 char		res;

  msg = create_msg(dest, 0);
  msg->data = NULL;
/*   my_printf("src %d\ndest %d\ndata %x\nsize %d\n", msg->src, msg->dest, */
/* 	    msg->data, msg->data_size); */
  send_msg(msg);
/*   while (1); */

  msg2 = wait_msg_from(dest);
  if (msg2)
    {
     /*  my_printf("GETC je recup le msg du clavier\n"); */
/*       my_printf("la size des data est %d et les data %s\n", msg2->data_size, msg2->data); */
      tmp = (char *)msg2->data;
      res = tmp[0];
/*       my_printf("On met ds res %d %c\n", res, res); */
      return res;
    }
  else
    return NULL;
}

int getchar (void)
{
  char res;
  res = getc(STDIN);
  return res;
}

/* char * gets (char * s) */
/* { */
/* } */

int	subscribe_stdin()
{
  t_msg		*msg;

  msg = create_msg(STDIN, 1);
  msg->data = NULL;
  send_msg(msg);

  return 0;
}

int	unsubscribe_stdin()
{
  t_msg		*msg;

  msg = create_msg(STDIN, 42);
  msg->data = NULL;
  send_msg(msg);

  return 0;
}

int	read(t_tskid dest, char *buf, int count)
{
  int	i = 0;
  t_msg	*msg;
  char	*tmp;

  subscribe_stdin();
  while (i < count)
    {
      msg = wait_msg_from(dest);
      if (msg)
	{
	  tmp = (char *)(msg->data);
	  buf[i++] = tmp[0];
	  if (tmp[0] == '\n')
	    {
/* 	    { */
/* 	      if(i + 1 < count) */
/* 		{ */
/* 		  buf[i] = '\0'; */
	    unsubscribe_stdin();
	    return i;
	    }
/* 		} */
/* 	    } */
	}
    }
  unsubscribe_stdin();
  return i;
}
