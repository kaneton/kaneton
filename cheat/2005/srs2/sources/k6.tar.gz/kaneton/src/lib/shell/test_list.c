/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Tue May 17 12:06:02 2005 Damien Laniel
** Last update Tue May 24 16:48:34 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "parse_cmd.h"
#include "../set/list.h"
#include "../console/console.h"
#include "../../include/kaneton/types.h"

#define STRING_SIZE	8

static int	cmp_string(const void *data, const void *data2)
{
  char		*str = (char *) data;
  char		*str2 = (char *) data2;
  unsigned int	i = 0;

  for (i = 0; str[i] && str2[i] && i < STRING_SIZE; ++i)
    if (str[i] > str2[i])
      return 1;
    else
      if (str[i] < str2[i])
	return -1;
  return 0;
}

static void	clear_string(void *data)
{
  char		*str = (char *) data;
  unsigned int	i = 0;

  for (i = 0; i < STRING_SIZE; ++i)
    str[i] = 0;
}

static void	print_string(const void *msg)
{
  cons_print_string((char *) msg);
}

static void	add(t_set_list **list, void *data)
{
  char *	str = (char *) data;

  set_list_add_item_end(list, str);
}

static void	delete(t_set_list **list, void *data)
{
  char *	str = (char *) data;

  set_list_delete_item(list, str, cmp_string, clear_string);
}

static void	print_list(t_set_list *list, char *msg)
{
  cons_print_string(msg);
  cons_goto_next_line();
  set_list_print(list, print_string);
  cons_goto_next_line();
}

/* static void	find_item(t_set_list *list, void *data) */
/* { */
/*   char *	data_searched = (char *) data; */
/*   void *	data_found; */

/*   data_found = set_list_find_item(list, data_searched, cmp_string); */
/*   cons_print_string("item found : "); */
/*   print_string(data_found); */
/*   cons_goto_next_line(); */
/* } */

void		test_list(char *arg[NB_MAX_ARG], int nb_arg)
{
  char *	msg = "Test of liblist";
  t_set_list *	list = NULL;

  arg = arg;
  if (nb_arg > 1)
    printf("Arguments are useless\n");

  cons_print_string(msg);
  cons_goto_next_line();
  cons_goto_next_line();

  add(&list, "1st node");
  add(&list, "2nd node");
  add(&list, "3rd node");
  delete(&list, "2nd node");
  add(&list, "4th node");
/*   delete(&list, "1st node"); */
/*   add(&list, "1st node"); */
/*   add(&list, "8th node"); */
/*   add(&list, "6th node"); */

  print_list(list, "list : ");

/*   find_item(list, "3rd node"); */

/*   set_list_free(&list, clear_string); */
/*   print_list(list, "empty list : "); */
}
