/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:49:33 2005 Castaing Antoine
** Last update Fri Jun 10 22:49:33 2005 Castaing Antoine
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

struct		s_buf
{
  char		str[MY_BUF_SIZE];
  int		fd;
  unsigned int	pos;
  unsigned int	taille;
};
static int      my_strlen(char *str)
{
  int           i = 0;

  while (str[i] != '\0')
    i++;
  return i;
}
void    my_printstr(char str[])
{
  int   length;

  length = my_strlen(str);
  write(1, str, length);
  write(1, "\n", 1);
}
char    *my_strcat(char *s, char *append)
{
  int   taille1;
  int   taille2;
  int   i;
  int   j;

  taille1 = my_strlen(s);
  taille2 = my_strlen(append);
  j = 0;
  for (i = taille1; i < taille1 + taille2; i++)
    {
      s[i] = append[j];
      j++;
    }
  s[i] = 0;
  return s;
}
static struct s_buf    *alloc_getln_buf(int fd)
{
  struct s_buf	*buffer;

  if ((buffer = malloc(sizeof (struct s_buf))) == NULL)
      exit(0);
  buffer->fd = fd;
  buffer->pos = MY_BUF_SIZE;
  buffer->taille = MY_BUF_SIZE;
  return buffer;
}
static void	parc_cpy_1(struct s_buf **buf, char **str, int *j)
{
  for (; (((*buf)->pos <= (*buf)->taille) && ((*buf)->str[(*buf)->pos]) &&\
	  ((*buf)->str[(*buf)->pos] != '\n')); (*buf)->pos++)
    {
      (*str)[*j] = (*buf)->str[(*buf)->pos];
      (*j)++;
    }
  (*str)[*j] = 0;

}
static void	parc_cpy_2(struct s_buf **buf, char **str)
{
  read((*buf)->fd, (*buf)->str, MY_BUF_SIZE) ;
  for ((*buf)->pos = 0; ((*buf)->str[(*buf)->pos] &&
			 ((*buf)->str[(*buf)->pos] != '\n')); (*buf)->pos++)
    (*str)[(*buf)->pos] = (*buf)->str[(*buf)->pos];
  (*str)[(*buf)->pos] = 0;

}
char	*my_getln(struct s_buf *buf)
{
  char	*str;
  int	j = 0;

  str = malloc (sizeof (char) * MY_BUF_SIZE);
  if (buf->pos < buf->taille)
    parc_cpy_1(&buf, &str, &j);
  else
    parc_cpy_2(&buf, &str);
  if (buf->pos == buf->taille)
    {
      str = realloc(str,my_strlen(str) + MY_BUF_SIZE), buf->pos = MY_BUF_SIZE;
      return my_strcat(str, my_getln(buf));
    }
  if ((buf->str[buf->pos] == '\n'))
    {
      if (buf->pos == 0)
	str[buf->pos] = '\n', str[buf->pos + 1] = 0;
      else
	buf->pos++, str[buf->pos] = 0;
      return str;
    }
  if (!buf->str[buf->pos])
    return str;
  return NULL;
}
