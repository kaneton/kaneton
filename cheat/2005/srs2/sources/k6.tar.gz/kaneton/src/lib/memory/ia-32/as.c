/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Tue Apr  5 23:59:12 2005 Nicolas Clermont
** Last update Sun Nov 13 00:41:19 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "as.h"
#include "../pm.h"
#include "../vm.h"
#include "../../console/console.h"
#include "../../../bootloader/phys_mem_mapping.h"

#define NODE_SIZE	(sizeof(t_as_list) + sizeof(t_as))
#define FIRST_NODE_ADDR	list_search_free_phys_space(ASLIST, NODE_SIZE, 0)
#define NEW_NODE_ADDR	list_search_free_phys_space_pt(PTAS_ENTRY, NODE_SIZE, 0)
#define PAS_NODE_ADDR	list_search_free_phys_space_pt(PTAS_ENTRY, sizeof(t_area_list), 1)

extern t_pm	*pm;

/*!
** The kernel address space and his identifier
*/
t_as		kas;

/*!
** Contains all the address space
*/
t_as_list	*as_list;

/*
** Compare if two as have the same modid
** @param	as1	An address space
** @param	as2	An address space
** @return	0 equal, 1 different
*/
int		as_cmp_modid(const void * as1, const void * as2)
{
  t_as *	a1 = (t_as *) as1;
  t_as *	a2 = (t_as *) as2;

  if (a1->modid > a2->modid)
    return 1;
  if (a1->modid < a2->modid)
    return -1;
  return 0;
}

t_tskid as_modid_taskid(t_modid mod)
{
  t_as		as_searched;
  t_as		*as_found;

  as_searched.modid = mod;
  as_found = (t_as *)(list_find_item(as_list, &as_searched, as_cmp_modid));
  return as_found->tskid;
}
/*!
** Copy an address space
** @param	source		t_as source
** @param	destination	t_as destination
*/
static int	as_copy(const void * source, void * destination)
{
  t_as *	sour = (t_as *) source;
  t_as *	dest = (t_as *) destination;

  if (!sour || !dest)
    return 1;
  * dest = * sour;
  return 0;
}

/*
** Compare if two as have the same asid
** @param	as1	An address space
** @param	as2	An address space
** @return	0 equal, 1 different
*/
int		as_cmp_asid(const void * as1, const void * as2)
{
  t_as *	a1 = (t_as *) as1;
  t_as *	a2 = (t_as *) as2;

  if (a1->asid > a2->asid)
    return 1;
  if (a1->asid < a2->asid)
    return -1;
  return 0;
}

/*!
** Clear the memory occupied by the structure
** @param	as	as to clear
*/
static void	as_clear_as(void * as)
{
  t_as *	a = (t_as *) as;

  a->asid = 0;
  /*   area_clear(a->pas); */
  a->pas = NULL;
  a->vas_used = NULL;
  a->vas_free = NULL;
}

/*!
** Print the structure, ie the identifier and the physical memory used
*/
void		as_print(const void * as)
{
  t_as *	a = (t_as *) as;

  if (a)
    {
      ttys[0].attrib = 0x0e;
      printf("*");
      ttys[0].attrib = 0x07;
      printf(" Address space identifier : %d\n", a->asid);
      printf("\tAdress space owner id : %d\n", a->ownid);
      printf("\tAdress space taskid : %d\n", a->tskid);
      printf("\tAdress space Module Id : %d\n", a->modid);
      printf("Physical Memory\n");
      list_print(a->pas, area_print);
      printf("Virtual Memory USED\n");
      list_print(a->vas_used, vm_area_print);
      printf("Virtual Memory FREE\n");
      list_print(a->vas_free, vm_area_print);
    }
  else
    printf("AS NULL\n");
}

/*!
** Print all the adress space
*/
void		print_addr_space(void)
{
  printf("Espaces d'adressage:\n");
  list_print((t_list *)as_list, as_print);
}

/*!
** Add an address space to the list
** @param	list	The list where to add the address space
** @param	as	The address space to add
*/
static void	as_list_add(struct s_list ** list, void * as)
{
  t_as *	a = (t_as *) as;
  t_paddr	node_addr;

  node_addr = NEW_NODE_ADDR;
  list_add_item_sorted(list, node_addr, a, as_copy, as_cmp_asid);
}

/*!
** Remove an address space from the list
** @param	list	Where to remove the address space
** @param	as	The address space to delete
*/
static void	as_list_delete(struct s_list ** list, void * as)
{
  t_as *	a = (t_as *) as;

  list_delete_item(list, a, as_cmp_asid, as_clear_as);
}

/*!
** Initialize address space management
*/
int		machdep_as_init(void)
{
  kas.asid = KASID;
  kas.tskid = 0;
  kas.ownid = 0;
  kas.modid = -1;
  kas.pd_addr = PD_ENTRY;
  kas.pd_vaddr = PD_ENTRY;
  kas.vas_used = NULL;
  kas.vas_free = NULL;
  kas.l_malloc = 0;
  as_list = NULL;
  list_init(ASLIST);
  list_init(AREA_VM);
  list_add_item_sorted(&as_list, FIRST_NODE_ADDR, &kas, as_copy, as_cmp_asid);

  return 0;
}

/*!
** Reserv an address space
** @param	asid	Result parameters. The ID of the new as.
*/
int		machdep_as_rsv(t_asid *asid)
{
  static t_asid	cur_asid = 2;
  t_as		new_as;

  /* Initialize the new as */
  new_as.asid = cur_asid;
  new_as.tskid = 0;
  new_as.ownid = 0;
  new_as.modid = -1;
  new_as.pd_addr = 0;
  new_as.pd_vaddr = 0;
  new_as.l_malloc = 0;
  new_as.pas = NULL;
  new_as.vas_used = NULL;
  new_as.vas_free = NULL;
  /* Add it to the list */
  as_list_add(&as_list, &new_as);
  *asid = cur_asid;
  cur_asid++;

  return 0;
}

/*!
** Return the address of the structure that describes the as asid
** @param	asid	Identify the as to return
** @param	as	Result parameters that contains the as asid
*/
int		machdep_as_get(t_asid asid, t_as **as)
{
  t_as		as_searched;
  t_as		*as_found;

  as_searched.asid = asid;
  as_found = (t_as *)(list_find_item(as_list, &as_searched, as_cmp_asid));
  if (as_found)
    {
      *as = as_found;
      return 0;
    }

  return 1;
}

/*!
** Free the address space specified
** @param	asid	Identify the adress space to free
*/
int		machdep_as_rel(t_asid asid)
{
  t_as		fake_as;

  machdep_pm_flush(asid);
  fake_as.asid = asid;
  as_list_delete(&as_list, &fake_as);
  return 0;
}

/*!
** Delete all the address space
*/
int		machdep_as_clear(void)
{
  t_as_list	*cur_node = as_list;
  t_as_list	*next_tmp;
  t_asid	test_asid;

  for (; cur_node; )
    {
      next_tmp = cur_node->next;
      test_asid = ((t_as *)(cur_node->data))->asid;
      machdep_as_rel(test_asid);
      cur_node = next_tmp;
    }
  return 0;
}

/*!
** Free all the address space physical memory
*/
void		machdep_as_pm_clear(void)
{
  t_as_list	*cur_node = as_list;

  for (; cur_node; cur_node = cur_node->next)
    machdep_as_rel(((t_as *)(cur_node->data))->asid);
}

/*!
** Clone an address space
** @param	old	Identifie the address space to clone
** @param	new	The clone
*/
int		machdep_as_clone(t_asid old, t_asid *new)
{
  t_as		*old_as = NULL, *new_as = NULL;
  t_area	*old_pas_area = NULL;
  t_area_list	*old_head_pas = NULL;

  machdep_as_get(old, &old_as);
  /* Error: if the source doesn't exist */
  if (!old_as)
    return 1;
  machdep_as_rsv(new);
  machdep_as_get(*new, &new_as);
  /* Clone the Physical Address Space used */
  for (old_head_pas = old_as->pas; old_head_pas;
       old_head_pas = old_head_pas->next)
    {
      old_pas_area = (t_area*)list_find_item(pm->used, old_head_pas->data, area_cmp);
      list_add_item_end(&(new_as->pas), PAS_NODE_ADDR, old_pas_area, NULL);
      old_pas_area->compt_ref++;
    }
  /* Clone the Virtual Address Space used */
  vm_copy(old, 0, *new, 0, 0xffffffff);
  /* Clone the Page Directory address --> NON JE CROIS PAS */
  /* new_as->pd_addr = old_as->pd_addr; */
  return 0;
}

/*!
** Fill tskid with the id of the task using the address space asid
*/
int		machdep_as_tskid(t_asid asid, t_tskid *tskid)
{
  t_as		*as;

  if (machdep_as_get(asid, &as))
    return 1;
  *tskid = as->tskid;

  return 0;
}

/*!
** Fill the modid parameter with the id of  the module in the address space owner id
*/
int		machdep_as_modid(t_asid asid, t_modid *modid)
{
  t_as		*as;

  if (machdep_as_get(asid, &as))
    return 1;
  *modid = as->modid;

  return 0;
}

/*!
** Fill the ownid parameter with the address space owner id
*/
int		machdep_as_ownid(t_asid asid, t_ownid *ownid)
{
  t_as		*as;

  if (machdep_as_get(asid, &as))
    return 1;
  *ownid = as->ownid;

  return 0;
}

/*!
** Change owner of the address space
*/
int		machdep_as_give(t_asid asid, t_ownid ownid)
{
  t_as		*as;

  if (machdep_as_get(asid, &as))
    return 1;
  as->ownid = ownid;

  return 0;
}

/*!
** Detach the address space of a task
** @param	asid	Identify the as to detach
** @param	tskid	The task that lost its as
*/
int		machdep_as_detach(t_asid asid, t_tskid tskid)
{
  //FIXME : MOVER DS ATTACH A CAUSE TASK_GET
  t_as		*as = NULL;
  t_task	*task = NULL;

  tskid = tskid;
  /*   if (task_get(tskid, &task)) */
  /*     return 1; */
  if (machdep_as_get(asid, &as))
    return 1;
  task->asid = 0;
  as->tskid = 0;

  return 0;
}

/*!
** Attach the module modid to the as asid
*/
int	machdep_as_set_modid(t_asid asid, t_modid modid)
{
  t_as	*as = NULL;

  if (machdep_as_get(asid, &as))
    return -1;
  
  as->modid = modid;

  return 0;
}

/*!
** Get the physical address of the Page Directory of the as asid
*/
int	machdep_as_get_pd_paddr(t_asid asid, t_paddr *pd_paddr)
{
  t_as	*as = NULL;

  if (machdep_as_get(asid, &as))
    return -1;
  
  *pd_paddr = as->pd_addr;

  return 0;
}
