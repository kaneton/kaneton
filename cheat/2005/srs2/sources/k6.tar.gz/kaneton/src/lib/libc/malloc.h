#ifndef KANETON_MALLOC_H_
# define KANETON_MALLOC_H_


#include "../../include/kaneton/types.h"
/* #define DEBUG_LIBC */
struct big_chunck
{
  int			nb_page;
  unsigned int		free;
  struct big_chunck	*next;
}__attribute__((packed));

struct little_chunck
{
  unsigned int		size;
  t_asid		asid;
  struct little_chunck	*next;
  struct little_chunck	*prev;
  char			used;
}__attribute__((packed));

int	toto;

struct big_chunck	*l_malloc;

#endif /* !KANETON_MALLOC_H_ */
