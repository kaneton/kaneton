/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:43:49 2005 Castaing Antoine
** Last update Fri Jun 10 22:43:50 2005 Castaing Antoine
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../lib/console/console.h"
#include "../../bootloader/gdt_segments.h"
#include "../../bootloader/phys_mem_mapping.h"


/*
** Print the value of all records of the segments of the GDT
*/
void print_gdt(void)
{
  extern t_segid	g_max_seg_id;
  struct s_gdt_segment	*gdt1 = (struct s_gdt_segment *) GDT_ENTRY;
  unsigned int		i;

  cons_clear_screen();

  for (i = 0; i < g_max_seg_id; i++)
    {
	printf("Affichage de la GDT[%d]\n", i);

	/* Limit */
	printf(" gdt[%d].limit : %d\n", i, gdt1[i].limit);
	printf(" gdt[%d].limit2 : %d\n", i, gdt1[i].limit2);

	/* Base */
	printf(" gdt[%d].base : %d\n", i, gdt1[i].base);
	printf(" gdt[%d].base2 : %d\n", i, gdt1[i].base2);
	printf(" gdt[%d].base3 : %d\n", i, gdt1[i].base3);

	/* Type */
	printf(" gdt[%d].type : %d\n", i, gdt1[i].type);

	/* S */
	printf(" gdt[%d].s : %d\n", i, gdt1[i].s);

	/* DPL = Descriptor Privilege Level */
	printf(" gdt[%d].dpl : %d\n", i, gdt1[i].dpl);

	/* P = Present */
	printf(" gdt[%d].p : %d\n", i, gdt1[i].p);

	/* AVL = Available */
	printf(" gdt[%d].avl : %d\n", i, gdt1[i].avl);

	/* 0 */
	printf(" gdt[%d].o : %d\n", i, gdt1[i].o);

	/* B = Big */
	printf(" gdt[%d].b : %d\n", i, gdt1[i].b);

	/* G = granularity */
	printf(" gdt[%d].g : %d\n", i, gdt1[i].g);
	cons_goto_next_line();
    }
}
