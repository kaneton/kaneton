/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sat Mar 26 16:02:48 2005 Nicolas Clermont
** Last update Wed Dec  7 10:13:29 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "pm.h"
#include "as.h"
#include "../../../bootloader/phys_mem_mapping.h"
#include "../../../bootloader/gdt_segments.h"
#include "../../../include/kaneton/types.h"
#include "../../../lib/console/console.h"
#include "../../../kaneton/error.h"

#define NODE_SIZE	(sizeof(t_area_list) + sizeof(t_area))
#define NEW_NODE_ADDR	list_search_free_phys_space(AREA + sizeof(t_pm), NODE_SIZE, 0)
#define KPAS_NODE_ADDR	list_search_free_phys_space(PASLIST, sizeof(t_area_list), 0)

#define PAS_NODE_ADDR	list_search_free_phys_space_pt(PTAS_ENTRY, sizeof(t_area_list), 1)
#define ERR_PM_REL	"PM ERROR: NON CONTIGOUS PHYSICAL SPACE"

extern t_as		kas;

/*!
** The Physical Memory
*/
t_pm		*pm;

/*!
** Add sorted an area to the list free or used
** @param	list	List where to add the area
** @param	area	The area to add
** @pram	cmp_func	Function of comparaison used for sorted
*/
static void	pm_list_add(struct s_list ** list, void * area, t_cmp_func cmp_func)
{
  t_area *	ar = (t_area *) area;
  t_paddr	node_addr;
  static t_vaddr current_page = AREA + sizeof(t_pm);

  node_addr = optim_list_search_free_phys_space(&current_page, NODE_SIZE, 0);
  list_add_item_sorted(list, node_addr, ar, area_copy, cmp_func);
}

static void	pm_list_add_node_page_area(struct s_list ** list, void * area,
					   t_cmp_func cmp_func, t_paddr node_page)
{
  t_area *	ar = (t_area *) area;
  t_paddr	node_addr;

  /*   node_addr = NEW_NODE_ADDR; */
  node_addr = list_search_free_phys_space(node_page, NODE_SIZE, 0);
  list_add_item_sorted(list, node_addr, ar, area_copy, cmp_func);
}

/*!
** Delte an area from the list free or used
** @param	list	List where to delete the area
** @param	area	The area to delete
*/
static void	pm_list_delete(struct s_list ** list, void * area)
{
  t_area *	ar = (t_area *) area;

  list_delete_item(list, ar, area_cmp, area_clear);
}

/*!
** Print on screen the areas of the two lists
*/
void		print_phys_mem(void)
{
  printf("Etat de la memoire physique, par zone:\n");
  printf("* Liste free:\n");
  list_print(pm->free, area_print);
  printf("* Liste used:\n");
  list_print(pm->used, area_print);
}

/*!
** Add a new free area which start at addr and of len npages by testing
** if it is contiguous with another area and fusion its.
** @param	addr	Start address of the new free area
** @param	npages	Size of the new free area
*/
int		fusion_free_area(t_paddr addr, t_psize npages)
{
  t_area	new_free_area;
  t_area	*free_exist_before, *free_exist_after;

  area_init(addr, npages, PM_ATTR_NONE, AREA_FREE, &new_free_area, 0);
  free_exist_after = list_find_item(pm->free, &new_free_area, area_cmp_cont_up);
  free_exist_before = list_find_item(pm->free, &new_free_area, area_cmp_cont_down);
  if (free_exist_after && !free_exist_before)
    area_modify(free_exist_after, new_free_area.start, free_exist_after->nbpages + new_free_area.nbpages);
  if (free_exist_before && !free_exist_after)
    area_modify(free_exist_before, free_exist_before->start, free_exist_before->nbpages + new_free_area.nbpages);
  if (free_exist_after && free_exist_before)
    {
      area_modify(free_exist_before, free_exist_before->start, free_exist_before->nbpages
		  + new_free_area.nbpages + free_exist_after->nbpages);
      list_delete_item(&(pm->free), free_exist_after, area_cmp, area_clear);
    }
  if (!free_exist_before && !free_exist_after)
    pm_list_add(&(pm->free), &new_free_area, area_cmp_npages);

  return 0;
}

/*!
** Create a physical area
** @param	start	Physical address of the beginning of the area
** @param	npages	Number of pages of the area
** @param	attr	Attribute of the area
** @param	class	Class of the area (for permission)
*/
static int	init_kernel_area(t_paddr start, t_psize npages, t_pattr attr, t_class class)
{
  t_area	new;
  t_area	*karea = NULL;

  area_init(start, npages, attr, AREA_USED, &new, class);
  pm_list_add(&(pm->used), &new, area_cmp_start);
  if (!(karea = (t_area*)list_find_item(pm->used, &new, area_cmp)))
    {
      printf("Init physical area failed\n");
      return 1;
    }
  list_add_item_end(&(kas.pas), KPAS_NODE_ADDR, karea, NULL);

  return 0;
}

/*!
** Initialize the physical memory manager
** @param	start	Segment Base Address
** @param	size	Segment size
*/
#define SIZEOF_TSS 0x67
int		machdep_pm_init(t_paddr start, t_psize size)
{
  int		i,seg_pos = 0;
  char		*tampon = NULL;
  t_area	new;

  /* Initialisation de la GDT*/
  seg_init();
  seg_add(start, size, PL_KERNEL | PL_EXEC | PL_READ , SEG_TYPE_MEM, &seg_pos, 1, 1, 1, 0);
  seg_add(start, size, PL_KERNEL | PL_WRITE | PL_READ , SEG_TYPE_MEM, &seg_pos, 1, 1, 1, 0);
  seg_add(TSS, sizeof(t_tss), PL_KERNEL | PL_READ | PL_WRITE | PL_EXEC,SEG_TYPE_TSS, &seg_pos, 0, 0, 0, 1);
  seg_add(start, size, PL_USER | PL_EXEC | PL_READ , SEG_TYPE_MEM, &seg_pos, 1, 1, 1, 0);
  seg_add(start, size, PL_USER | PL_WRITE | PL_READ , SEG_TYPE_MEM, &seg_pos, 1, 1, 1, 0);

  /* Initialisation des listes d'areas */
  list_init(AREA);
  pm = (t_pm*)AREA;
  list_init(PASLIST);
  kas.pas = 0;
  /* Mise en place du tampon pour l'ajout du dernier elmt de la page */
  tampon = (char*)(AREA + sizeof(t_pm));
  for (i = 0; i < (int)NODE_SIZE; i++)
    *tampon++ = 1;

  /* Les areas */
  init_kernel_area(0, 2, PM_ATTR_RESIDENT, CLASS_KERNEL);
  /* Ajout des areas FREE */
  area_init(file_conf_addr + PAGE_SIZE,
	    (IDT_ADDR - (file_conf_addr + PAGE_SIZE)) / PAGE_SIZE,
    	    PM_ATTR_NONE, AREA_FREE, &new, 0);
  pm_list_add(&(pm->free), &new, area_cmp_npages);
  area_init(IDT_ADDR + 2 * PAGE_SIZE, (STACK_ADDR - IDT_ADDR - 2 * PAGE_SIZE) / PAGE_SIZE,
  	    PM_ATTR_NONE, AREA_FREE, &new, 0);
  pm_list_add(&(pm->free), &new, area_cmp_npages);
  area_init(STACK_ADDR + 3 * PAGE_SIZE, mem_upper / 4 - STACK_ADDR / PAGE_SIZE - 3,
  	    PM_ATTR_NONE, AREA_FREE, &new, 0);
  pm_list_add(&(pm->free), &new, area_cmp_npages);
  /* Ajout des areas USED decoupees selon sharing */
  init_kernel_area(GDT_ENTRY, 1, PM_ATTR_RESIDENT | PM_ATTR_SHARE, CLASS_USER);
  init_kernel_area(PD_ENTRY, 1, PM_ATTR_RESIDENT, CLASS_KERNEL);
  init_kernel_area(PTK_ENTRY, 1, PM_ATTR_RESIDENT | PM_ATTR_SHARE, CLASS_KERNEL);
  init_kernel_area(PTT_ENTRY, 2, PM_ATTR_RESIDENT, CLASS_KERNEL);
  init_kernel_area(AREA, 1, PM_ATTR_RESIDENT | PM_ATTR_SHARE, CLASS_KERNEL);
  init_kernel_area(PTI_ENTRY, 1, PM_ATTR_RESIDENT, CLASS_KERNEL);
  init_kernel_area(PTAS_ENTRY, (PTPD_ENTRY - PTAS_ENTRY) / PAGE_SIZE,
		   PM_ATTR_RESIDENT | PM_ATTR_SHARE, CLASS_KERNEL);
  init_kernel_area(PTPD_ENTRY, 1, PM_ATTR_RESIDENT | PM_ATTR_SHARE, CLASS_KERNEL);
  init_kernel_area(TSS, (0x10000 - TSS) / PAGE_SIZE,
		   PM_ATTR_RESIDENT | PM_ATTR_SHARE, CLASS_USER);
  init_kernel_area(0x10000, (file_conf_addr - 0x10000) / PAGE_SIZE,
		   PM_ATTR_RESIDENT | PM_ATTR_SHARE, CLASS_USER);

  init_kernel_area(file_conf_addr, 1, PM_ATTR_RESIDENT | PM_ATTR_SHARE,
		   CLASS_KERNEL);

  init_kernel_area(IDT_ADDR, 2, PM_ATTR_RESIDENT | PM_ATTR_SHARE, CLASS_USER);
  init_kernel_area(STACK_ADDR, 3, PM_ATTR_RESIDENT | PM_ATTR_SHARE, CLASS_USER);

  return 0;
}

/*!
** Do the job when the flag PM_FLAG_SPECIFIC is used
** @param	addr	 The address where we want to reserve space
** @param	npages	 Number of pages we want to reserve
** @param	old_free The area in which we will reserve if possible
*/
static int	machdep_pm_rsv_specific(t_paddr *addr, t_psize npages, t_area **old_free)
{
  t_area	split_free;
  t_area	cmp;

  area_init(*addr, npages, PM_ATTR_NONE, 0, &cmp, 0);

  if (!(*old_free = (t_area *)list_find_item(pm->free, &cmp, is_addr_in_area)))
    return 1;
  if ((((*old_free)->start + (*old_free)->nbpages * PAGE_SIZE) - *addr) / PAGE_SIZE < npages)
    return 1;

  if ((*old_free)->start != *addr)
    {
      area_init((*old_free)->start, (*addr - (*old_free)->start) / PAGE_SIZE,
		PM_ATTR_NONE, AREA_FREE, &split_free, 0);
      pm_list_add(&(pm->free), &split_free, area_cmp_npages);
      area_modify(*old_free, *addr, (*old_free)->nbpages - split_free.nbpages);
    }
  /*   printf("c po par la\n"); */
  /*   while (1); */

  return 0;
}

/*!
** Allocate n contigues pages of physical memory
** @param	asid	Identify the as to which we want to allocate memory
** @param	addr	Return parameters that contain the address of the allocated area
** @param	npages	Number of pages we want to allocate
** @param	flags
*/
int		machdep_pm_rsv(t_asid asid, t_paddr *addr, t_psize npages, t_pmflags flags)
{
  t_psize	old_pages;
  t_as		*as;
  t_area	*old_free = NULL;
  t_area	*new_pas_area = NULL;
  t_area	new_used, cmp;
  t_paddr	node_page = 0;

  if (flags & PM_FLAG_SPECIFIC)
    {
      if (machdep_pm_rsv_specific(addr, npages, &old_free))
	return 1;
    }
  else
    {
      if (flags & PM_FLAG_NODE_PAGE)
	node_page = *addr;
      area_init(0, npages, PM_ATTR_NONE, 0, &cmp, 0);
      if (!(old_free = (t_area *)list_find_item(pm->free, &cmp, area_cmp_nbpages)))
	{
	  print_fatal_screen();
	  while (1)
	    print_fatal_screen();
	  return 1;
	}
      *addr = old_free->start;
    }
  old_pages = old_free->nbpages;
  if (npages == old_free->nbpages)
    {
      list_delete_item(&(pm->free), old_free, area_cmp, area_clear);
      old_free = NULL;
    }
  else
    area_modify(old_free, *addr + npages * PAGE_SIZE, old_pages - npages);

  area_init(*addr, npages, PM_ATTR_NONE, AREA_USED, &new_used, CLASS_USER);
  /*  pm_list_add(&(pm->used), &new_used, area_cmp_start); */

  if (flags & PM_FLAG_NODE_PAGE)
    pm_list_add_node_page_area(&(pm->used), &new_used, area_cmp_start, node_page);
  else
    {
    /*   printf("Je susi par ici\n"); */
/*       while (1); */

      pm_list_add(&(pm->used), &new_used, area_cmp_start);
    }

  if (asid != 0)
    {
      machdep_as_get(asid, &as);
      new_pas_area = (t_area*)list_find_item(pm->used, &new_used, area_cmp);
      list_add_item_end(&(as->pas), PAS_NODE_ADDR, new_pas_area, NULL);
    }

  return 0;
}

/*!
** Modify the attribute of a physical page area
** @param	asid		The address space which own the pages to modify
** @param	addr		Beginning of the area to modify
** @param	npages		Number of pages to modify
** @param	attribute	New attributes of the pages
*/
int		machdep_pm_attr(t_asid asid, t_paddr addr, t_psize npages, t_pattr attr)
{
  /* BONUS */
  /* A FINIR*/
  t_as		*as_mod = NULL;
  t_area	*area = NULL, new_split, new_split2;
  t_area	fake_area;
  t_psize	pages_rest = npages, tmp_npages;

  attr = attr;

  machdep_as_get(asid, &as_mod);
  /*test si null + error + test continuite func lolo */
  area_init(addr, npages, PM_ATTR_NONE, 0, &fake_area, 0);
  area = (t_area*)list_find_item(as_mod->pas, &fake_area, is_addr_in_area);
  if (addr == area->start && npages == area->nbpages)
    area->attr = attr;
  if (addr == area->start && npages < area->nbpages)
    {
      area_init(addr + npages * PAGE_SIZE, area->nbpages - npages, PM_ATTR_NONE, AREA_USED,
		&new_split, area->auth_shared_class);
      list_add_item_end(&(as_mod->pas), PAS_NODE_ADDR, &new_split, NULL);
      area->nbpages = npages;
      area->attr = attr;
    }
  if (addr != area->start && (addr + npages * PAGE_SIZE) <
      (area->start + area->nbpages * PAGE_SIZE))
    {
      area_init(area->start, (addr - area->start) / PAGE_SIZE, PM_ATTR_NONE,
		AREA_USED, &new_split, area->auth_shared_class);
      area_init(addr + npages * PAGE_SIZE, area->start + area->nbpages * PAGE_SIZE,
		PM_ATTR_NONE, AREA_USED, &new_split2, area->auth_shared_class);
      area_modify(area, addr, npages);
      area->attr = attr;
      list_add_item_end(&(as_mod->pas), PAS_NODE_ADDR, &new_split, NULL);
      list_add_item_end(&(as_mod->pas), PAS_NODE_ADDR, &new_split2, NULL);
    }
  if (addr != area->start  && (addr + npages * PAGE_SIZE) >=
      (area->start + area->nbpages * PAGE_SIZE))
    {
      tmp_npages = area->nbpages;
      area_modify(area, area->start, (addr - area->start) / PAGE_SIZE);
      if ((pages_rest = npages - (tmp_npages - area->nbpages)))
	/* FIXME FAKE_AREA INIT */
	area = list_find_item(as_mod->pas, &fake_area, area_cmp_start);
      for (; (pages_rest > 0) && (pages_rest >= area->nbpages);)
	{
	  pages_rest -= area->nbpages;
	  area_modify(area, area->start, area->nbpages);
	  area->attr = attr;
	  area = list_find_item(as_mod->pas, &fake_area, area_cmp_start);
	}
      if (pages_rest)
	{
	  area_init(area->start + pages_rest * PAGE_SIZE, area->nbpages - pages_rest,
		    area->attr, AREA_USED, &new_split, area->auth_shared_class);
	  area_modify(area, area->start, pages_rest);
	  list_add_item_end(&(as_mod->pas), PAS_NODE_ADDR, &new_split, NULL);
	}
    }
  return 0;
}

/*!
** Free an area
** @param	ar	The area to free
** @param	ar_list	The list where to delete the area
*/
static int	area_rel(t_area* ar, t_area_list** ar_list, t_as *as)
{
  area_free_pm(ar, as);
  list_delete_item(ar_list, ar, area_cmp, NULL);
  pm_list_delete(&(pm->used), ar);

  return 0;
}

/*!
** Free n physical memory pages in area
** @param	area	Identify the area where we want to free space
** @param	addr	Identify the beginning of the area to free
** @param	npages	Identify the number of page we want to free
*/
static int	pm_rel_in_one_area(t_area *rel_area, t_paddr addr, t_psize npages,
				   t_area_list **pas_list)
{
  t_psize	tmp_npages;
  t_area	split_used_area;
  t_area	*new_pas_area = NULL;

  area_free_pages(addr, npages);
  if (rel_area->start == addr)
    area_modify(rel_area, rel_area->start + npages * PAGE_SIZE,
		rel_area->nbpages - npages);
  else
    {
      tmp_npages = rel_area->nbpages;
      area_modify(rel_area, rel_area->start, (addr - rel_area->start) / PAGE_SIZE);
      area_init(addr + npages * PAGE_SIZE, tmp_npages - npages - rel_area->nbpages,
		PM_ATTR_NONE, AREA_USED, &split_used_area, rel_area->auth_shared_class);
      pm_list_add(&(pm->used), &split_used_area, area_cmp_start);
      new_pas_area = (t_area*)list_find_item(pm->used, &split_used_area, area_cmp);
      list_add_item_end(pas_list, PAS_NODE_ADDR, new_pas_area, NULL);
    }
  fusion_free_area(addr, npages);

  return 0;
}



/*!
** Verify if the space memory describe by addr and nbytes belong to the list
** @param	list	The list in which to verify the space memory
** @param	addr	The beginning of the space memory
** @param	nbytes	The size in bytes of the space memory
*/
static int              get_nb_pm_area(t_area_list *list,
                                       t_paddr begin_addr,
                                       int nbbytes)
{
  int                   nb_area = 0;
  t_paddr               tmp_addr;
  t_area		fake_area;
  t_area		*area;

  fake_area.start = begin_addr;
  if (!(area = (t_area *)list_find_item(list, &fake_area,
					is_addr_in_area)))
    return -1;
  tmp_addr = area->nbpages * PAGE_SIZE + area->start;

  nbbytes -= (area->start + area->nbpages * PAGE_SIZE) - begin_addr;
  nb_area++;
  /*
  ** On remet l'adresse du debut de l'area fake a la fin de la precedente
  */
  fake_area.start = area->start + area->nbpages * PAGE_SIZE;
  for (; nbbytes > 0; nb_area++)
    {
      if (!(area = (t_area *) list_find_item(list, &fake_area, area_cmp_start)))
	return -1;
      nbbytes -= area->nbpages * PAGE_SIZE;
      tmp_addr = fake_area.start + (area->nbpages * PAGE_SIZE);
      fake_area.start = tmp_addr;
    }
  return nb_area;
}

/*!
** Free n physical memory pages
** @param	asid	Identify the as where we want to free space
** @param	addr	Identify the beginning of the area to free
** @param	npages	Identify the number of page we want to free
*/
int		machdep_pm_rel(t_asid asid, t_paddr addr, t_psize npages)
{
  t_as		*used_as = NULL;
  t_area	cmp_area;
  t_area	*searched_area = NULL;
  t_psize	tmp_npages, npages_rest = npages;
  t_paddr	tmp_start;

  machdep_as_get(asid, &used_as);

  if (get_nb_pm_area(used_as->pas, addr, npages * PAGE_SIZE) == -1)
    return error(ERR_PM_REL, __FILE__, __LINE__);

  area_init(addr, npages, PM_ATTR_NONE, 0, &cmp_area, 0);
  searched_area = list_find_item(used_as->pas, &cmp_area, is_addr_in_area);
  /* Si a l'interieur d'une seule area */
  if ((addr + npages * PAGE_SIZE) < (searched_area->start + searched_area->nbpages * PAGE_SIZE))
    return pm_rel_in_one_area(searched_area, addr, npages, &(used_as->pas));
  /* Si sur plusieurs areas */
  if (searched_area->start != addr)
    {
      area_free_pages(addr, ((searched_area->start + searched_area->nbpages * PAGE_SIZE) - addr) / PAGE_SIZE);
      tmp_npages = searched_area->nbpages;
      area_modify(searched_area, searched_area->start, (addr - searched_area->start) / PAGE_SIZE);
      area_init(searched_area->start + tmp_npages * PAGE_SIZE, 0, PM_ATTR_NONE, 0, &cmp_area, 0);
      if ((npages_rest = npages - (tmp_npages - searched_area->nbpages)))
	searched_area = list_find_item(used_as->pas, &cmp_area, area_cmp_start);
    }

  for (; npages_rest > 0 && npages_rest >= searched_area->nbpages; )
    {
      tmp_npages = searched_area->nbpages;
      tmp_start = searched_area->start;
      area_rel(searched_area, &(used_as->pas), used_as);

#ifdef DEBUG
      area_print(searched_area);
      while(1);
#endif

      npages_rest = npages_rest - tmp_npages;
      area_init(tmp_start + tmp_npages * PAGE_SIZE, 0, PM_ATTR_NONE, 0, &cmp_area, 0);
      if (npages_rest && !(searched_area = list_find_item(used_as->pas, &cmp_area, area_cmp_start)))
	return error(ERR_PM_REL, __FILE__, __LINE__);
    }
  if (npages_rest)
    {
      area_free_pages(searched_area->start, npages_rest);
      area_modify(searched_area, searched_area->start + npages_rest * PAGE_SIZE, searched_area->nbpages - npages_rest);
    }
  fusion_free_area(addr, npages);

  return 0;
}

/*!
** Free all the physical memory that the as asid use
** @param	asid	Identify the as to physical free
*/
int		machdep_pm_flush(t_asid asid)
{
  t_as		*as_flushed;
  t_area_list	*cur = NULL;

  /* Recherche de l'as correspondant a asid */
  machdep_as_get(asid, &as_flushed);
  /* Virer les areas correspondantes de used et mettre dans free */
  for (cur = as_flushed->pas; cur; cur = cur->next)
    {
      area_free_pm((t_area *)cur->data, as_flushed);
      fusion_free_area(((t_area *)cur->data)->start,
		       ((t_area *)cur->data)->nbpages);
      pm_list_delete(&(pm->used), (t_area *)cur->data);
    }
  /* Mettre la liste pas de l'as a jour */
  list_clear(&(as_flushed->pas), NULL);
  return 0;
}

/*!
** Reinitialize the physical memory management by freeing all the
** physical memory pages used
*/
int		machdep_pm_clear(void)
{
  t_area_list	*list_used;
  t_area	area_free;

  /* Flush sur toutes les areas */
  for (list_used = pm->used; list_used; list_used = list_used->next)
    area_free_pm((t_area *)list_used->data, NULL);
  /* Passer tous used en free ? */
  area_init(0, mem_upper / 4, PM_ATTR_NONE, AREA_FREE, &area_free, 0);
  pm_list_add(&(pm->free), &area_free, area_cmp_npages);
  /* Flush sur la liste used */
  list_clear(&(pm->used), area_clear);
  machdep_as_pm_clear();
  return 0;
}

/*!
** Get the index of the PT pt_paddr in the KERNEL PD
*/
int		get_pt_pde(t_paddr pt_paddr)
{
  t_vaddr	*pd = (t_vaddr *)PD_ENTRY;
  int		i = 0;

  for (; i < 1024; i++)
    if (pd[i])
      if ((pd[i] >> 12) * PAGE_SIZE == pt_paddr)
	return i;

  return -1;
}

/*!
** Translate a physical memory page address into a virtual page
** address.
*/
t_vaddr		pm_to_vm(t_paddr page_paddr)
{
  t_vaddr	*ptt = (t_vaddr *)PTT_ENTRY, *pt_vaddr = NULL;
  t_vaddr	page_vaddr = 0;
  t_paddr	pt_paddr = 0;
  int		i = 1, j = 0, pt_pde = 0;

  for (; i < 1024; i++)
    if (ptt[i])
      {
	pt_paddr = (ptt[i] >> 12) * PAGE_SIZE;
	pt_vaddr = (t_vaddr *)((PTT_PDE << 22) + (i << 12));
	for (j = 0; j < 1024; j++)
	  if ((pt_vaddr[i] >> 12) * PAGE_SIZE == page_paddr)
	    {
	      pt_pde = get_pt_pde(pt_paddr);
	      page_vaddr = (pt_pde << 22) + (j << 12);
	      return page_vaddr;
	    }
      }

  return 0;
}
