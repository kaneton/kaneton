/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sun Jun  5 15:03:04 2005 Damien Laniel
** Last update Wed Dec  7 10:15:09 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "as.h"
#include "../pm.h"
#include "../vm.h"
#include "../../console/console.h"
#include "../../../bootloader/phys_mem_mapping.h"
#include "../../../bootloader/ch_cr.h"
#include "../../../kaneton/task/task.h"

#define PAS_NODE_ADDR	list_search_free_phys_space_pt(PTAS_ENTRY, sizeof(t_area_list), 1)

extern t_pm	*pm;

int	as_attach(t_asid asid, t_tskid tskid)
{
  return machdep_as_attach(asid, tskid);
}

/*!
** Attach an address space to a task
*/
int		machdep_as_attach(t_asid asid, t_tskid tskid)
{
  t_as		*as = NULL;
  t_task	*task = NULL;
  t_area_list	*pm_tmp = pm->used;
  t_paddr	pd_addr;
  t_paddr	pti_addr;
  t_paddr	ptt_addr;
  t_paddr	ptm_addr;
  t_paddr	area_start;
  t_vaddr	pd_vaddr;
  t_vaddr	ptt_vaddr;
  t_vaddr	ptm_vaddr;
  t_vaddr	pti_vaddr;
  t_vm_area	vm_area;
  unsigned int	i = 0;

  if (machdep_as_get(asid, &as))
    {
      printf("as_get pourri sur asid %d\n", asid);
      return 1;
    }
  if (task_get(tskid, &task))
    {
      printf("task_get pourri sur asid %d\n", tskid);
      return 1;
    }
  if (task->asid)
    {
      printf("y a deja un asid a la tache et y vaut %d\n", task->asid);
      return 1;
    }
  if (task->ownid != as->ownid)
    {
      printf("Pb de ownid : task %d, as %d\n", task->ownid, as->ownid);
      return 1;
    }

  task->asid = asid;
  as->tskid = tskid;


  /*
  ** On reserve de la memoire physique
  ** pour la page directory de l'as de la  tache
  */
  pm_rsv(asid, &pd_addr, 1, PM_FLAG_ANY);
  as->pd_addr = pd_addr;
  pd_vaddr = PTPD_PDE << 22;
  pd_vaddr |= (map_new_page(PTPD_ENTRY, pd_addr, SUPERUSER | RW)) << 12;
  init_page((void *)pd_vaddr);
  as->pd_vaddr = pd_vaddr;

  /*
  ** On reconstruit PTI / PTT / PTM
  */
  /* PTI */
  pm_rsv(asid, &pti_addr, 1, PM_FLAG_ANY);
  /* Map + Calcul de l'@ lineaire de la PTM user dans l'espace Kernel*/
  pti_vaddr = PTPD_PDE << 22;
  pti_vaddr |= (map_new_page(PTPD_ENTRY, pti_addr, SUPERUSER | RW)) << 12;
  create_new_pt(pd_vaddr, pti_addr, pti_vaddr, USER | RW);

  /* PTM */
  pm_rsv(asid, &ptm_addr, 1, PM_FLAG_ANY);
  /* Map + Calcul de l'@ lineaire de la PTM user dans l'espace Kernel*/
  ptm_vaddr = PTPD_PDE << 22;
  ptm_vaddr |= (map_new_page(PTPD_ENTRY, ptm_addr, SUPERUSER | RW)) << 12;
  create_new_pt(pd_vaddr, ptm_addr, ptm_vaddr, USER | RW);

  /* PTT */
  pm_rsv(asid, &ptt_addr, 1, PM_FLAG_ANY);
  /* Map + Calcul de l'@ lineaire de la PTT user dans l'espace Kernel*/
  ptt_vaddr = PTPD_PDE << 22;
  ptt_vaddr |= (map_new_page(PTPD_ENTRY, ptt_addr, SUPERUSER | RW)) << 12;
  create_new_pt(pd_vaddr, ptt_addr, ptt_vaddr, USER | RW);

  /* Map des Pages Tables de l'as user*/
  map_new_page(ptt_vaddr, GDT_ENTRY, USER | RDONLY);
  map_new_page(ptt_vaddr, pti_addr, USER | RW);
  map_new_page(ptt_vaddr, ptm_addr, USER | RW);
  map_new_page(ptt_vaddr, PTK_ENTRY, USER | RDONLY);
  map_pt_at(pd_vaddr, PTK_ENTRY, 768, USER | RDONLY);
  map_new_page(ptm_vaddr, ptt_addr, USER | RW);

  /*
  ** Initialisation de la memoire virtuelle de l'as
  */
  vm_init(asid);

  for (; pm_tmp; pm_tmp = pm_tmp->next)
    {
      if (((t_area *)(pm_tmp->data))->auth_shared_class < task->class)
	;
      /* 	printf("Access Refused at adress <%x>\n", ((t_area *)(pm_tmp->data))->start); */
      else
	{
	  area_start = ((t_area *)(pm_tmp->data))->start;
	  if (area_start != pd_addr && area_start != pti_addr && area_start != ptm_addr && area_start != ptt_addr)
	    {
	      ((t_area *)(pm_tmp->data))->compt_ref++;
	      list_add_item_end(&(as->pas), PAS_NODE_ADDR, (t_area *)(pm_tmp->data), NULL);
	      vm_area_init(((t_area *)(pm_tmp->data))->start, ((t_area *)(pm_tmp->data))->nbpages,
			   VM_ATTR_READ | VM_ATTR_WRITE | VM_ATTR_EXEC, VM_AREA_USED,
			   0, &vm_area);
	      vm_area.mapped_pm_area = ((t_area *)pm_tmp->data)->start;
	      vm_area_list_add(&(as->vas_used), &vm_area, vm_area_cmp_start);
	      for (i = 0; i < ((t_area *)(pm_tmp->data))->nbpages; ++i)
		map_new_page_at(pti_vaddr, ((t_area *)(pm_tmp->data))->start + i * PAGE_SIZE,
				(((t_area *)(pm_tmp->data))->start + i * PAGE_SIZE) / PAGE_SIZE, USER | RW);
	    }
	}
    }

  unmap_page_vaddr(PD_ENTRY, pti_vaddr, PD_ENTRY, KASID);

  return 0;
}
