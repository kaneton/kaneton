/*
** util_nbr.h for  in /u/a1/clermo_n/PRINT/printf
** 
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
** 
** Started on  Wed Oct 30 01:52:41 2002 nicolas clermont
** Last update Wed Oct 30 01:53:55 2002 nicolas clermont
*/
#include "my_printf.h"

int		recurse(int nbr, char *buffer);
int		my_printnbr(int nbr, char *buffer, t_type *tab);
int		nbrlen_u(unsigned int nbr);
int		my_printnbr_u(unsigned int nbr, char *buffer);
int             my_nbrlen(int fsize);
