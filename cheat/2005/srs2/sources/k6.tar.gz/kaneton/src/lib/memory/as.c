/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Sat Mar 26 16:03:45 2005 Nicolas Clermont
** Last update Mon Nov  7 00:30:29 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "as.h"

int	as_init(void)
{
  return machdep_as_init();
}

int	as_rsv(t_asid *asid)
{
  return machdep_as_rsv(asid);
}

int	as_get(t_asid asid, t_as **as)
{
  return machdep_as_get(asid, as);
}

int	as_rel(t_asid asid)
{
  return machdep_as_rel(asid);
}

int	as_clone(t_asid old, t_asid *new)
{
  return machdep_as_clone(old, new);
}

int	as_clear(void)
{
  return machdep_as_clear();
}

int	as_tskid(t_asid asid, t_tskid *tskid)
{
  return machdep_as_tskid(asid, tskid);
}

int	as_modid(t_asid asid, t_modid *modid)
{
  return machdep_as_modid(asid, modid);
}

int	as_ownid(t_asid asid, t_ownid *ownid)
{
  return machdep_as_ownid(asid, ownid);
}

int	as_give(t_asid asid, t_ownid ownid)
{
  return machdep_as_give(asid, ownid);
}

/* int	as_attach(t_asid asid, t_tskid tskid) */
/* { */
/*   return machdep_as_attach(asid, tskid); */
/* } */

int	as_detach(t_asid asid, t_tskid tskid)
{
  return machdep_as_detach(asid, tskid);
}

int	as_set_modid(t_asid asid, t_modid modid)
{
  return machdep_as_set_modid(asid, modid);
}

int	as_get_pd_paddr(t_asid asid, t_paddr *pd_paddr)
{
  return machdep_as_get_pd_paddr(asid, pd_paddr);
}
