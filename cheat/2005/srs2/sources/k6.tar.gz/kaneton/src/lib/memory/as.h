/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Sat Mar 26 16:04:05 2005 Nicolas Clermont
** Last update Mon Nov  7 00:30:18 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef AS_H
# define AS_H

# include "ia-32/as.h"
# include "../../include/kaneton/types.h"

int	as_init(void);

int	as_rsv(t_asid *asid);

int	as_get(t_asid asid, t_as **as);

int	as_rel(t_asid asid);

int	as_clone(t_asid old, t_asid *new);

int	as_clear(void);

int	as_tskid(t_asid asid, t_tskid *tskid);

int	as_modid(t_asid asid, t_modid *modid);

int	as_ownid(t_asid asid, t_ownid *ownid);

int	as_give(t_asid asid, t_ownid ownid);

int	as_attach(t_asid asid, t_tskid tskid);

int	as_detach(t_asid asid, t_tskid tskid);

int	as_set_modid(t_asid asid, t_modid modid);

int	as_get_pd_paddr(t_asid asid, t_paddr *pd_paddr);

#endif	/* !AS_H */
