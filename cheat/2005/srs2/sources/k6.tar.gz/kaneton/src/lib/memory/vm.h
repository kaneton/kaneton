/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sat Mar 19 17:01:22 2005 Damien Laniel
** Last update Wed Mar 23 00:01:26 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef VM_H_
# define VM_H_

#include "ia-32/vm.h"
#include "../../include/kaneton/types.h"

int	vm_init(t_asid asid);

int	vm_rsv(t_asid asid, t_vaddr *addr, t_vsize npages, t_vmflags flags);

int	vm_rel(t_asid asid, t_vaddr addr, t_vsize npages);

int	vm_attr(t_asid asid, t_vaddr addr, t_vsize npages, t_vattr attr);

/*!
** Nettoie un espace d'adressage de tout son espace virtuel.
*/
int	vm_flush(t_asid asid);

int	vm_clear(void);

int	vm_map(t_asid asid, t_paddr paddr, t_vaddr vaddr, t_vsize npages);

int	vm_unmap(t_asid asid, t_vaddr addr, t_vsize npages);

int	vm_copy(t_asid from, t_vaddr src, t_asid to, t_vaddr dst, t_vsize nbytes);

#endif /* !VM_H_ */
