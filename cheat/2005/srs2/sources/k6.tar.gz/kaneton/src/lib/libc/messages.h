/*
** Copyright (C) Antoine Castaing aka Xebech <castai_a@epita.fr>
**
** Part of Kaneton
**
** Started on  Sun Oct  9 11:19:02 2005 Antoine Castaing
** Last update Mon Oct 17 16:45:19 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef USER_MESSAGES_H_
# define USER_MESSAGES_H_

#include "../../include/kaneton/types.h"

typedef struct	s_msg {
  t_tskid	src;
  t_tskid	dest;
  t_vaddr	data;
  int		data_size;
}t_msg;

t_tskid	get_src(t_msg *msg);

t_tskid	get_dest(t_msg *msg);

void	*get_data(t_msg *msg);

int	get_type(t_msg *msg);

void	set_src(t_msg *msg, t_tskid src);

void	set_dest(t_msg *msg, t_tskid dest);

void	set_data(t_msg *msg, void *data);

void	set_type(t_msg *msg, int type);

#endif
