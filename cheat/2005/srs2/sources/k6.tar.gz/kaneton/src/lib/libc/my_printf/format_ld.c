/*
** format_hd.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 02:18:33 2002 nicolas clermont
** Last update Wed Oct 30 06:33:53 2002 nicolas clermont
*/
#include "my_printf.h"

static int	type_ld_dot(t_type *tab, char *buffer, long int i)
{
  int		j;
  int		count;

  count = 0;
  if (((tab[9].mask & FLAG_DOT) == FLAG_DOT ) && (i >= 0))
      for (j = 0; j < (tab[7].mask - my_nbrlen(i)); j++)
	count += my_printchar('0', buffer);
  count += my_printnbr(i, buffer, tab);
  return count;
}

static int	ldflag_p_sup(t_type *tab, long int i, char *buffer)
{
  int		count, j;
  int		decal;
  int		max;
  char		fill;

  count = decal = 0;
  fill = ' ';
  max = my_nbrlen(i);
  if (tab[7].mask > tab[8].mask)
    count += my_printchar('+', buffer);
  if (tab[8].mask > max)
  {
    decal = 1;
    if (flag_det(tab, FLAG_ZERO) && !(flag_det(tab, FLAG_MOINS)))
      fill = '0';
    if (tab[7].mask > max)
      max = tab[7].mask;
    if ((tab[8].mask > tab[7].mask) && !(flag_det(tab, FLAG_MOINS)))
      for (j = 0; j < (tab[8].mask - (max + decal)); j++)
	count += my_printchar(fill, buffer);
    if (tab[7].mask <= tab[8].mask)
      count += my_printchar('+', buffer);
  }
  return count;
}

static int	ldflag_width(long int i, t_type *tab, char *buffer, int ever)
{
  int		count;
  int		j;
  int		max;
  int		decal;
  char		fill;

  count = decal = 0;
  max = my_nbrlen(i);
  fill = ' ';
  if (i < 0)
    decal = 1;
  if (flag_det(tab, FLAG_ZERO) && !flag_det(tab, FLAG_MOINS) && (i >= 0))
    fill = '0';
  if (tab[7].mask > max)
    max = tab[7].mask;
  if ((i >= 0) && (tab[8].mask > tab[7].mask) && (ever == 0))
    for (j = 0; j < (tab[8].mask - (max + decal)); j++)
      count += my_printchar(fill, buffer);
  return count;
}

static int	ldflag_p(t_type *tab, long int i, int *ever, char *buffer)
{
  int		k;
  int		count;
  int		j;
  int		max;

  k = count = 0;
  max = my_nbrlen(i);
  if (flag_det(tab, FLAG_PLUS) || i < 0)
    k = 1;
  if (tab[7].mask > max)
    max = tab[7].mask;
  if (tab[8].mask > tab[7].mask)
    for (j = 0; j < (tab[8].mask - (max + k)); j++)
      *ever = count += my_printchar(' ', buffer);
  return count;
}

static int	ldflag_p_m(t_type *tab, long int i, char *buffer, int ever)
{
  int		count;
  int		max;
  int		j;
  int		decal;

  max = my_nbrlen(i);
  decal = 0;
  count = 0;
  if (tab[7].mask > max)
    max = tab[7].mask;
  if ((i >= 0) && (tab[8].mask > tab[7].mask) && (ever == 0))
    for (j = 0; j < (tab[8].mask - (max + decal)); j++)
      count += my_printchar(' ', buffer);
  return count;
}

int		type_d_long(va_list *arg, char *buffer, t_type *tab)
{
  long int	i;
  int		count;
  int		decal, max, ever;
  char		fill;

  count = decal = ever = 0;
  fill = ' ';
  i = va_arg(*arg, int);
  max = my_nbrlen(i);
  if ((flag_det(tab, FLAG_PLUS)) && (i >= 0))
    count += ldflag_p_sup(tab, i, buffer);
  if (flag_det(tab, FLAG_MOINS))
  {
    count += type_ld_dot(tab, buffer, i);
    count += ldflag_p(tab, i, &ever, buffer);
  }
  if ((tab[8].mask > max) && (!flag_det(tab, FLAG_SPACE)
     || !flag_det(tab, FLAG_MOINS)) && !flag_det(tab, FLAG_PLUS))
    count += ldflag_width(i, tab, buffer, ever);
  if (flag_det(tab, FLAG_PLUS) && flag_det(tab, FLAG_MOINS))
      count += ldflag_p_m(tab, i, buffer, ever);
  if (!flag_det(tab, FLAG_MOINS))
    count += type_ld_dot(tab, buffer, i);
  return count;
}
