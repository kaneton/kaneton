/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:49:18 2005 Castaing Antoine
** Last update Tue Sep 27 11:26:33 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include "parse_conf.h"
#include "parse_cmd.h"
#include "../libc/libc.h"
#include "../libc/string.h"
#include "../console/console.h"

#define NB_OPT_CONF 2
/* #define DEBUG */
char mod_keyboard[9] = "keyboard";
char mod_info[5] = "info";

void	load_info(char *arg[NB_MAX_ARG], int nb_arg)
{
#ifdef DEBUG
  if (arg[0])
    printf("arg por clavie %s\n",arg[0]);
#endif
  nb_arg =nb_arg;
  info_general = arg[0];
}

void	change_keyboard(char *arg[NB_MAX_ARG], int nb_arg)
{
  nb_arg = nb_arg;
#ifdef DEBUG
  if (arg[0])
    printf("arg por clavie %s\n",arg[0]);
#endif
  arg[0] = 0;
  return;
}

struct s_mod_builtin mod_name[NB_OPT_CONF] =
  {
    {(char *)(&mod_keyboard), (fct_mod)change_keyboard},
    {(char *)(&mod_info), (fct_mod)load_info}
  };

/** \brief this function test if the char is a separator
 ** \param c it is a pointer on the char
 ** \return int it is a boolean to say if the char is aseparator or not
*/
static int	is_sep(char *c)
{
  char	sep[5] = " \n\t\0\"";
  int	i = 0;

  for (; i < 5; i++)
    if (*c == sep[i])
      {
	return i + 1;
      }

  return 0;
}

/*
** Attention cmd and arg can be 0, so
** The module fonction have to take it in consideration
** @param cmd The command name
** @param arg id the argument of the cmd
*/
void	call_conf(char *cmd, char *arg[NB_MAX_ARG], int nb_arg)
{
 int	i = 0;

 if (cmd)
   {
#ifdef DEBUG
     printf(cmd);
     printf("\n");
#endif
     for (; i < NB_OPT_CONF; ++i)
       {
	 if (!strcmp(mod_name[i].fct_label, cmd)){
#ifdef DEBUG
	    printf("%s == %s et avec %d\n", mod_name[i].fct_label
		   , cmd, nb_arg);
#endif
	 mod_name[i].fct(arg, nb_arg);
	 return;
	 }
#ifdef DEBUG
	 printf("%s != %s\n", mod_name[i].fct_label
		, cmd);
#endif
       }
   }
}
/* #define DEBUG */
int	parse_conf_file(char *file)
{
  int	temp;
  char	*cur = file;
  int	i = 0;
  char	*cmd = 0;
  char	*arg[NB_MAX_ARG];
  int	nb_arg = 0;
  int	quoted = 0;

#ifdef DEBUG
  printf("le fichier est <%s>\n", file);
#endif

  info_general = 0;
  while (*cur)
    {
     /*  for (i = 0; (!(temp = is_sep(cur))); i++,cur++) */
/* 	; */
      for (i = 0; ((!(temp = is_sep(cur))) && !quoted) ||
	     ((*cur != '\"') && quoted && *cur);
	   i++,cur++)
	;
      if (cur != file) {
	if (!cmd) {
	  if (quoted)
	    {
	      quoted = 0;
	      ++file;
	    }
	  cmd = file;
	  *cur = '\0';
	}
	else {
	  if (quoted)
	    {
	      quoted = 0;
	      /* ++file; */
#ifdef DEBUG
	      printf("chaine quote : <%s> et les arg <%d>\n",
		     file, nb_arg);
#endif
	    }
	  if (nb_arg < NB_MAX_ARG - 1)
	    arg[nb_arg++] = file;
#ifdef DEBUG
	  printf("reste apres l arg <%s>\n",
		 cur);
#endif
	  *cur = '\0';
	}
	switch (temp){
	case 1:
	  file = ++cur;
	break;
	case 2:
	  call_conf(cmd, arg, nb_arg);
	  cmd = 0;
	  nb_arg = 0;
	  file = ++cur;
#ifdef DEBUG
	  printf("Si il reste un arg c <%s>\n le curr <%s>\n", file,cur);
#endif
	  break;
	case 3:
	  file = ++cur;
	  break;
	case 4:
	  call_conf(cmd,arg, nb_arg);
	  /* return 0; */
	  break;
	case 5:
	  call_conf(cmd, arg, nb_arg);
	  cmd = 0;
	  nb_arg = 0;
	  file = ++cur;
	  break;
	default: break;
	}
      }
      else {
	if (*cur == '\"') quoted = 1;
	cur++;
	file++;
      }
    }
#ifdef DEBUG
  printf("#######################\n <%s>\n\n", info_general);
#endif
  return 0;
}


