/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Tue May 24 16:41:25 2005 Damien Laniel
** Last update Mon May 30 21:11:31 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "parse_cmd.h"
#include "../set/set.h"
#include "../console/console.h"
#include "../../include/kaneton/types.h"
#include "../libc/libc.h"

#define STRING_SIZE	8

/* static int	cmp_string(const void *data, const void *data2) */
/* { */
/*   char		*str = (char *) data; */
/*   char		*str2 = (char *) data2; */
/*   unsigned int	i = 0; */

/*   for (i = 0; str[i] && str2[i] && i < STRING_SIZE; ++i) */
/*     if (str[i] > str2[i]) */
/*       return 1; */
/*     else */
/*       if (str[i] < str2[i]) */
/*	return -1; */
/*   return 0; */
/* } */

/* static void	clear_string(void *data) */
/* { */
/*   char		*str = (char *) data; */
/*   unsigned int	i = 0; */

/*   for (i = 0; i < STRING_SIZE; ++i) */
/*     str[i] = 0; */
/* } */

/* static void	print_string(const void *msg) */
/* { */
/*   cons_print_string((char *) msg); */
/* } */

typedef t_id	t_string_id;

typedef struct	s_set_string
{
  t_string_id	id;
  char		*str;
}		t_set_string;

void		test_set(char *arg[NB_MAX_ARG], int nb_arg)
{
  char *	msg = "Test of libset";
  t_setid	setid = 0;
  t_set_string	str;
  t_set_string	str2;
  t_set_string	str3;
  t_set_string	str4;
  t_set_string	str5;
  t_set_string	str6;
  t_iterator	it;
  t_iterator	it2;

  arg = arg;
  if (nb_arg > 1)
    printf("Arguments are useless\n");

  cons_print_string(msg);
  cons_goto_next_line();
  cons_goto_next_line();


  str.id = 0;
  str.str = "1st item";
  str2.id = 1;
  str2.str = "2nd item";
  str3.id = 3;
  str3.str = "3rd item";
  str4.id = 7;
  str4.str = "4th item";
  str5.id = 10;
  str5.str = "5th item";
  str6.id = 15;
  str6.str = "6th item";


  set_init();
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_set_string), 0, &setid);
  if (set_insert(setid, &str))
    printf("ERROR : set_insert\n");
  if (set_insert_head(setid, &str2))
    printf("ERROR : set_insert_head\n");
  if (set_insert(setid, &str4))
    printf("ERROR : set_insert\n");
  if (set_insert_tail(setid, &str3))
    printf("ERROR : set_insert_tail\n");
  if (set_head(setid, &it))
    printf("ERROR : set_head\n");
  else
    printf("id (1) : %d, head (2nd) : %s\n", it.id, ((t_set_string *)it.addr)->str);
  if (set_tail(setid, &it))
    printf("ERROR : set_tail\n");
  else
    printf("id (3) : %d, tail (3rd) : %s\n", it.id, ((t_set_string *)it.addr)->str);
  if (set_get(setid, 7, &it))
    printf("ERROR : set_get\n");
  else
    printf("id (7) : %d, get (4th) : %s\n", it.id, ((t_set_string *)it.addr)->str);
  if (set_next(setid, it, &it2))
    printf("ERROR : set_next\n");
  else
    printf("id (3) : %d, next (3rd) : %s\n", it2.id, ((t_set_string *)it2.addr)->str);
  if (set_prev(setid, it, &it2))
    printf("ERROR : set_prev\n");
  else
    printf("id (0) : %d, prev (1st) : %s\n", it2.id, ((t_set_string *)it2.addr)->str);
  printf("foreach forward :\n");
  SET_FOREACH(FOREACH_FORWARD, setid, &it)
    printf("id : %d, string : %s\n", it.id, ((t_set_string *)it.addr)->str);
  printf("foreach backward :\n");
  printf("Delete id : 7\n");
  set_delete(setid, 7);
  SET_FOREACH(FOREACH_BACKWARD, setid, &it)
    printf("id : %d, string : %s\n", it.id, ((t_set_string *)it.addr)->str);
}
