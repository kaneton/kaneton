/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Mar  7 01:00:20 2005 Damien Laniel
** Last update Mon Mar  7 01:05:41 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "list.h"
#include "../memory/pm.h"

void	*list_find_item(const t_list	*list,
			const void	*data,
			t_cmp_func	cmp_func)
{
  while (list)
    {
      if (!(cmp_func(list->data, data)))
	  return list->data;
      list = list->next;
    }
  return NULL;
}


/*
** Find the nearest lower or equasl element in the given list
**
** @param	list		The list
** @param	data		The comparison element
** @param	cmp_func	The comparison function
*/
void		*list_find_item_le(const t_list	*list,
				   const void	*data,
				   t_cmp_func	cmp_func)
{
  int		tmp = 1;
  void		*tmp_data = NULL;

  while (list)
    {
      if ((cmp_func(list->data, data) < 0) &&
	  (cmp_func(list->data, data) < tmp))
	{
	  tmp = cmp_func(list->data, data);
	  tmp_data = list->data;
	}
      list = list->next;
    }
  return tmp_data;
}

/*
** Find the nearest upper or equal element in the given list
**
** @param	list		The list
** @param	data		The comparison element
** @param	cmp_func	The comparison function
*/
void		*list_find_item_ge(const t_list	*list,
				   const void	*data,
				   t_cmp_func	cmp_func)
{
  int		tmp = -1;
  void		*tmp_data = NULL;

  while (list)
    {
      if ((cmp_func(list->data, data)) > 0 &&
	  ((cmp_func(list->data, data) < tmp) || (tmp < 0)))
	{
	  tmp = cmp_func(list->data, data);
	  tmp_data = list->data;
	}
      list = list->next;
    }
  return tmp_data;
}

