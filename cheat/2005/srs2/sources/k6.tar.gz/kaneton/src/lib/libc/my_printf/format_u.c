/*
** format_u.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 00:57:17 2002 nicolas clermont
** Last update Wed Oct 30 04:13:49 2002 nicolas clermont
*/
#include "my_printf.h"

static int	type_u_fmoins(t_type *tab, unsigned int u, char *buffer)
{
  int		i;
  int		j;

  j = 0;
  if (tab[7].mask > nbrlen_u(u))
    for (i = 0; i < (tab[7].mask - nbrlen_u(u)); i++)
      j += my_printchar('0', buffer);
  j += my_printnbr_u(u, buffer);
  return j;
}

int		type_u(va_list *arg, char *buffer, t_type *tab)
{
  unsigned int	u;
  int		i, j, max;
  char		fill;

  if (flag_det(tab, FLAG_SHORT) || flag_det(tab, FLAG_LONG))
    return (type_u_short(arg, buffer, tab));
  j = 0;
  fill = ' ';
  if ((u = va_arg(*arg, unsigned int)) == 0)
    return (my_printchar('0', buffer));
  if ((tab[9].mask & FLAG_MOINS) == FLAG_MOINS)
    j += type_u_fmoins(tab, u, buffer);
  if ((tab[8].mask != 1) && (tab[8].mask > (max = nbrlen_u(u))))
    {
      if ((tab[9].mask & FLAG_ZERO) == FLAG_ZERO
	  && ((tab[9].mask & FLAG_MOINS) != FLAG_MOINS))
	fill = '0';
      if (tab[7].mask > max)
	max = tab[7].mask;
      for (i = 0; i < (tab[8].mask - max); i++)
	j += my_printchar(fill, buffer);
    }
  if ((tab[9].mask & FLAG_MOINS) != FLAG_MOINS)
    j += type_u_fmoins(tab, u, buffer);
  return j;
}
