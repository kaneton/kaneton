/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:49:11 2005 Castaing Antoine
** Last update Fri Jun 10 22:49:12 2005 Castaing Antoine
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/



#ifndef PARSE_CONF_H_
# define PARSE_CONF_H_

#include "parse_cmd.h"

typedef int    (*fct_mod)(char *arg[NB_MAX_ARG], int nb_arg);

struct		s_mod_builtin
{
  char		*fct_label;
  fct_mod	fct;
};
int	parse_conf_file(char *file);

#endif
