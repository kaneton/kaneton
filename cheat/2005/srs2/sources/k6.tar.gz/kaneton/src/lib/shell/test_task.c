/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Fri Jun  3 16:32:34 2005 Damien Laniel
** Last update Fri Jun  3 21:35:23 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "parse_cmd.h"
#include "../../kaneton/task/task.h"
#include "../console/console.h"

void		test_task(char *arg[NB_MAX_ARG], int nb_arg)
{
  t_tskid	tskid;
  t_tskid	tskid2;
  t_task	*task = NULL;

  arg = arg;
  if (nb_arg > 1)
    printf("Arguments are useless\n");

  if (!task_init())
    printf("task_init : OK\n");
  else
    printf("task_init : FAILED\n");
  if (!task_rsv(CLASS_USER, BEHAV_TIMESHARING, PRIOR_TIMESHARING, &tskid))
    printf("task_rsv : OK\n");
  else
    printf("task_rsv : FAILED\n");
  if (!task_get(tskid, &task) && task != NULL)
    printf("task_get : OK\n");
  else
    printf("task_get : FAILED\n");

  if (!task_rsv(CLASS_USER, BEHAV_TIMESHARING, PRIOR_TIMESHARING, &tskid2))
    printf("task_rsv : OK\n");
  else
    printf("task_rsv : FAILED\n");
/*   task_print(tskid2); */
  if (!task_rel(tskid2))
    printf("task_rel : OK\n");
  else
    printf("task_rel : FAILED\n");
  if (task_rel(tskid2))
    printf("task_rel on unexistant task : OK\n");
  else
    printf("task_rel on unexistant task : FAILED\n");

/*   task_print(tskid2); */
/*   task_print(tskid); */
}
