/*
** format_o.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 00:45:53 2002 nicolas clermont
** Last update Wed Oct 30 04:10:21 2002 nicolas clermont
*/

#include "my_printf.h"

static int	oflag_m(t_type *tab, char *buffer, unsigned int o)
{
  int		i;
  int		k;
  int		j;

  k = i = 0;
  if ((tab[9].mask & FLAG_SHARP) == FLAG_SHARP && o != 0)
    k = i += my_printchar('0', buffer);
  if ((tab[9].mask & FLAG_DOT) == FLAG_DOT)
    for (j = 0; j < (tab[7].mask - (my_baselen(o, "01234567") + k)); j++)
      i += my_printchar('0', buffer);
  i += my_printnbr_base(o, "01234567", buffer);
  return i;
}

static int	oflag_d_notm(t_type *tab, unsigned int o, int *ever, char *buffer)
{
  int		i;
  int		j;

  i = 0;
  if (tab[8].mask != 1 && tab[8].mask > tab[7].mask)
    if (tab[7].mask > my_baselen(o, "01234567"))
      for (j = 0; j < (tab[8].mask - tab[7].mask); j++)
	*ever = i += my_printchar(' ', buffer);
  for (j = 0; j < (tab[7].mask - my_baselen(o, "01234567")); j++)
    i += my_printchar('0', buffer);
  i += my_printnbr_base(o, "01234567", buffer);
  return i;
}

static int	oflag_width(t_type *tab, unsigned int o, int ever, char *buffer)
{
  int		i;
  int		j;
  int		max;
  int		decal;
  char		fill;

  i = decal = 0;
  fill = ' ';
  if (tab[8].mask > (max = my_baselen(o, "01234567")))
  {
    if ((tab[9].mask & FLAG_SHARP) == FLAG_SHARP)
      decal = 1;
    if (flag_det(tab, FLAG_ZERO) && !flag_det(tab, FLAG_MOINS))
      fill = '0';
    if (tab[7].mask > max)
    {
      max = tab[7].mask;
      if (flag_det(tab, FLAG_SHARP) && flag_det(tab, FLAG_MOINS) && o != 0)
	max--;
    }
    if (ever == 0)
      for (j = 0; j < (tab[8].mask - (max + decal)); j++)
	i += my_printchar(fill, buffer);
  }
  return i;
}

int		type_o(va_list *arg, char *buffer, t_type *tab)
{
  unsigned int	o;
  int		i;
  int		decal, ever;
  char		fill;

  if (flag_det(tab, FLAG_SHORT) || flag_det(tab, FLAG_LONG))
    return (type_o_short(arg, buffer, tab));
  fill = ' ';
  i = decal = ever = 0;
  o = va_arg(*arg, unsigned int);
  if ((tab[9].mask & FLAG_MOINS) == FLAG_MOINS)
    i += oflag_m(tab, buffer, o);
  if (flag_det(tab, FLAG_DOT) && !flag_det(tab, FLAG_MOINS))
    i += oflag_d_notm(tab, o, &ever, buffer);
  if (tab[8].mask != 1)
    i += oflag_width(tab, o, ever, buffer);
  if (!flag_det(tab, FLAG_MOINS) && !flag_det(tab, FLAG_DOT))
  {
    if ((tab[9].mask & FLAG_SHARP) == FLAG_SHARP && o != 0)
      i += my_printchar('0', buffer);
    i += my_printnbr_base(o, "01234567", buffer);
  }
  return i;
}
