/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sat Mar 19 17:14:17 2005 Damien Laniel
** Last update Sat Jun  4 20:39:56 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "vm_area.h"
#include "../../console/console.h"
#include "../../../bootloader/phys_mem_mapping.h"

/*
** #define VM_NODE_SIZE		((sizeof(t_vm_area_list) + sizeof(t_vm_area)))
** #define VM_NEW_NODE_ADDR	list_search_free_phys_space(AREA_VM, VM_NODE_SIZE)
*/


/*!
** Create a struct that identify a virtual memory area
** @param	start		Virtual address of the beginning of the area
** @param	npages		Number of virtual pages of the area
** @param	attr		The attribute of the area
** @param	compt_ref	Number of access to the area
** @param	mappped_pm_area The physical address of the area
*/
void		vm_area_init(t_vaddr	start,
			     t_vsize	npages,
			     t_vattr	attr,
			     int	type,
			     t_vaddr	mapped_pm_area,
			     t_vm_area	*new_area)
{
  new_area->start = start;
  new_area->nbpages = npages;
  new_area->attr = attr;
  new_area->compt_ref = 0;
  if (type == VM_AREA_USED)
    new_area->compt_ref = 1;
  new_area->mapped_pm_area = mapped_pm_area;
}

/*!
** Free some pages in the virtual memory area
** @param	area	Identify the virtual area to free
** @param	start	The address where beginning to free
** @param	npages  The number of pages to free
*/
void		vm_area_free_pages(t_vaddr start, t_vsize npages)
{
  t_vaddr	*vm_to_flush = 0;

  for (vm_to_flush = (t_vaddr*)start;
       vm_to_flush != (t_vaddr*)(start + (npages * PAGE_SIZE));
       vm_to_flush++)
    *vm_to_flush = 0;
}

/*!
** Modify a virtual memory area
** @param	area	The area to modify
** @param	n_start	The new address of the virtual area
** @param	n_npages The new number of pages of the area
*/
void		vm_area_modify(t_vm_area *area,
			       t_vaddr n_start,
			       t_psize n_npages)
{
  area->start = n_start;
  area->nbpages = n_npages;
}

/*!
** Copy a virtual memory area structure
** @param	source		First area
** @param	destination	Second area
*/
int		vm_area_copy(const void *source, void *destination)
{
  t_vm_area	*sour = (t_vm_area *)source;
  t_vm_area	*dest = (t_vm_area *)destination;

  /*  * dest = * sour;*/
  dest->start = sour->start;
  dest->nbpages = sour->nbpages;
  dest->attr = sour->attr;
  dest->compt_ref = sour->compt_ref;
  dest->mapped_pm_area = sour->mapped_pm_area;
  return 0;
}

/*!
** Compare two virtual memory areas
** @param	vmarea1	a vm area
** @param	vmarea2	a second vm area
** @return	0 the same, 1 if vmarea1 is greater, -1 if vmarea2 is greater
*/
int		vm_area_cmp(const void *vmarea1, const void *vmarea2)
{
  t_vm_area	*var1 = (t_vm_area *)vmarea1;
  t_vm_area	*var2 = (t_vm_area *)vmarea2;

  if (var1->nbpages > var2->nbpages || var1->start > var2->start)
    return 1;
  if (var1->nbpages < var2->nbpages || var1->start < var2->start)
    return -1;
  return 0;
}

/*!
** Compare two mapped physical address
** @param	vmarea1	a vm area
** @param	vmarea2	a second vm area
** @return	0 the same, 1 if different
*/
int		vm_area_cmp_mapped_addr(const void *vmarea1, const void *vmarea2)
{
  t_vm_area	*var1 = (t_vm_area *)vmarea1;
  t_vm_area	*var2 = (t_vm_area *)vmarea2;

  if (var1->mapped_pm_area == var2->mapped_pm_area)
    return 0;
  else
    return 1;
}

/*!
** Compare the number of pages of two virtual memory areas
** @param	vmarea1	a virtual memory area
** @param	vmarea2	a virtual memory area
** @return	0 the same, 1 if vmarea1 is greater, -1 if vmarea2 is greater
*/
int		vm_area_cmp_npages(const void *vmarea1, const void *vmarea2)
{
  t_vm_area	*var1 = (t_vm_area *)vmarea1;
  t_vm_area	*var2 = (t_vm_area *)vmarea2;

  if (var1->nbpages > var2->nbpages)
    return 1;
  if (var1->nbpages < var2->nbpages)
    return -1;
  return 0;
}

/*!
** Compare the number of pages of two virtual memory areas
** @param	vmarea1	a virtual memory area
** @param	vmarea2	a virtual memory area
** @return	0 the same, 1 if vmarea1 is greater, -1 if vmarea2 is greater
*/
int             vm_area_cmp_npages_ge(const void *vmarea1, const void *vmarea2)
{
  t_vm_area	*var1 = (t_vm_area *)vmarea1;
  t_vm_area	*var2 = (t_vm_area *)vmarea2;

  if (var1->nbpages >= var2->nbpages)
    return 0;
  else
    return 1;
}

/*!
** Compare the number of pages of two virtual memory areas
** @param	vmarea1	a virtual memory area
** @param	vmarea2	a virtual memory area
** @return	0 the same, 1 if vmarea1 is greater, -1 if vmarea2 is greater
*/
int             vm_area_cmp_start_le(const void *vmarea1, const void *vmarea2)
{
  t_vm_area	*var1 = (t_vm_area *)vmarea1;
  t_vm_area	*var2 = (t_vm_area *)vmarea2;

  if (var1->start <= var2->start)
    return 0;
  else
    return 1;
}

/*!
** Compare two vm areas by address
** @param	area1	a vm area
** @param	area2	a second vm area
** @return	0 the same, 1 different
*/
int		vm_area_cmp_start(const void *vmarea1, const void *vmarea2)
{
  t_vm_area	*var1 = (t_vm_area *)vmarea1;
  t_vm_area	*var2 = (t_vm_area *)vmarea2;

  return var1->start - var2->start;
}

/*!
** Clear the memory occupied by the structure
** @param	area	area to clear
*/
void		vm_area_clear(void *area)
{
  t_vm_area	*ar = (t_vm_area *)area;

  ar->start = 0;
  ar->nbpages = 0;
  ar->attr = 0;
  ar->compt_ref = 0;
  ar->mapped_pm_area = 0;
}

/*!
** Print the structure
** @param	area	Area to print
*/
void		vm_area_print(const void *area)
{
  t_vm_area	*ar = (t_vm_area *)area;

  if (ar)
    {
      cons_print_string("Area address : ");
      cons_print_int_base(ar->start, 16);
      cons_print_string(", Area number of pages : ");
      cons_print_int_base(ar->nbpages, 10);
      cons_goto_next_line();
      cons_print_string("   Area number of access: ");
      cons_print_int_base(ar->compt_ref, 10);
      cons_print_string(", Physical Address: ");
      cons_print_int_base(ar->mapped_pm_area, 16);
      cons_goto_next_line();
    }
  else
    printf("VM Area NULL\n");
}

/*!
** Add a vm area in the given list
** @param	list	The vm area list
** @param	area	Thea area to add
** @param	cmp_fun The comparision function wanted
*/
void		vm_area_list_add(struct s_list **list,
				 void * vmarea,
				 t_cmp_func cmp_func)
{
/*   t_vm_area		*var = (t_vm_area *) vmarea; */
  t_vm_area		*area_node;

  area_node = (t_vm_area *)VAS_NEW_NODE_ADDR;

  vm_area_copy(vmarea, (t_vm_area *)area_node);

  list_add_item_sorted(list, VAS_NODE_ADDR, area_node, NULL, cmp_func);

}

int		vm_area_cmp_cont_down(const void * area1, const void * area2)
{
  t_vm_area *	a1 = (t_vm_area *) area1;
  t_vm_area *	a2 = (t_vm_area *) area2;

  if ((a1->start + a1->nbpages * PAGE_SIZE) == a2->start)
    return 0;
  else
    return 1;
}

int		vm_area_cmp_cont_up(const void * area1, const void * area2)
{
  t_vm_area *	a1 = (t_vm_area *) area1;
  t_vm_area *	a2 = (t_vm_area *) area2;

  if (a1->start ==  (a2->start + a2->nbpages * PAGE_SIZE))
    return 0;
  else
    return 1;
}

/*!
** Compare if the start address of vmarea2 belong to vmarea1
** @param	area1	a physical memory area
** @param	area2	a physical memory area
*/
int		is_vaddr_in_vmarea(const void * vmarea1, const void * vmarea2)
{
  t_vm_area *	a1 = (t_vm_area *) vmarea1;
  t_vm_area *	a2 = (t_vm_area *) vmarea2;

  if ((a2->start >= a1->start) &&
      (a2->start < (a1->start + a1->nbpages * PAGE_SIZE)))
    return 0;
  else
    return 1;
}

/*!
** Delete an area from the vm area list
** @param	list	The vm area list
** @param	area	The vm area to delete from the list
*/
void		vm_area_list_delete(struct s_list ** list, void * area)
{
  t_vm_area *	ar = (t_vm_area *) area;

  list_delete_item(list, ar, vm_area_cmp, vm_area_clear);
}
