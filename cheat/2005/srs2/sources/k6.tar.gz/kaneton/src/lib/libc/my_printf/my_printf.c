/*
** my_printf.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 02:04:55 2002 nicolas clermont
** Last update Tue Nov 15 00:26:05 2005 Nicolas Clermont
*/
#include "my_printf.h"

void		init_printf(t_type *tab, char *buffer)
{
  int		i;
  const char	tabc[] = {'d', 'u', 's', 'c', 'x', 'X', 'o', 'i', 'p', 'z'
		       , 'r', 'a', 'A', 'n', 0};

  for (i = 0; i < MY_BUFFER_SIZE; i++)
    buffer[i] = -1;
  for (i = 0; i < 15; i++)
    tab[i].c = tabc[i];
  tab[0].func = &type_d;
  tab[1].func = &type_u;
  tab[2].func = &type_s;
  tab[3].func = &type_c;
  tab[4].func = &type_x;
  tab[5].func = &type_X;
  tab[6].func = &type_o;
  tab[7].func = &type_d;
  tab[8].func = &type_p;
  tab[9].func = &type_z;
  tab[10].func = &type_r;
  tab[11].func = &type_a;
  tab[12].func = &type_A;
  tab[13].func = &type_n;
}

int		display(t_type *tab, char type, va_list *arg, char *buffer)
{
  int		i, j;

  j = 0;
  for (i = 0; tab[i].c; i++)
    if (tab[i].c == type)
      return ((*tab[i].func)(arg, buffer, tab));
  if (type == '%')
    j += my_printchar('%', buffer);
  if (type != '%' && type != '#' && type != 'b')
    {
      j += my_printchar(type, buffer);
      return j;
    }
  return j;
}

static int	is_space(const char **format)
{
  int		mask;

  mask = 0;
  if (**format == ' ')
    {
      mask = FLAG_SPACE;
      while (**format == ' ')
	(*format)++;
    }
  return mask;
}

static int	is_sharp(const char **format)
{
  int		mask;

  mask = 0;
  if (**format == '#')
    {
      mask = FLAG_SHARP;
      while (**format == '#')
	(*format)++;
    }
  return mask;
}

static int	is_plus(const char **format)
{
  int		mask;

  mask = 0;
  if (**format == '+')
    {
      mask = FLAG_PLUS;
      while (**format == '+')
	(*format)++;
    }
  return mask;
}

static int	is_zero(const char **format)
{
  int		mask;

  mask = 0;
  if (**format == '0')
    {
      mask = FLAG_ZERO;
      while (**format == '0')
	(*format)++;
    }
  return mask;
}

static int	is_moins(const char **format)
{
  int		mask;

  mask = 0;
  if (**format == '-')
    {
      mask = FLAG_MOINS;
      while (**format == '-')
	(*format)++;
    }
  mask |= is_sharp(format);
  mask |= is_plus(format);
  return mask;
}

static int	is_star(const char **format, va_list *arg)
{
  int		width;

  width = 1;
  if (**format == '*')
    {
      while (**format == '*')
	(*format)++;
      width = va_arg(*arg, int);
    }
  return width;
}

static int	is_width(const char **format)
{
  int		width;

  if (('0' < **format) && (**format <= '9'))
    {
      width = **format - '0';
      (*format)++;
      while (('0' <= **format) && (**format <= '9'))
	{
	  width *= 10;
	  width += **format - '0';
	  (*format)++;
	}
    }
  else
    width = 1;
  return width;
}

static int	is_dot(const char **format, t_type *tab, va_list *v1)
{
  tab[7].mask = 1;
  if (**format == '.')
    {
      tab[9].mask |= FLAG_DOT;
      while (**format == '.')
	(*format)++;
      if (**format == '*')
	tab[7].mask = is_star(format, v1);
      else
	tab[7].mask = is_width(format);
    }
  return 0;
}

static int	is_b(const char **format, va_list *v1, char *buffer)
{
  int		i;
  char		*str;
  int		nb;

  i = 0;
  if (**format == 'b')
  {
    str = va_arg(*v1, char*);
    while (*str != '\0')
    {
      i += nb = is_specific(&str, buffer);
      if (nb == 0)
	i += my_printchar(*str, buffer);
      str++;
    }
  }
  return i;
}

static int	is_short(const char **format)
{
  int		mask;

  mask = 0;
  if (**format == 'h')
  {
    mask = FLAG_SHORT;
    (*format)++;
    if (**format == 'h')
      (*format)++;
  }
  return mask;
}

static int	is_long(const char **format)
{
  int		mask;

  mask = 0;
  if (**format == 'l')
  {
    mask = FLAG_LONG;
    (*format)++;
  }
  return mask;
}

int		is_specific(char **format, char *buffer)
{
  int		i;

  i = 0;
  if (**format == '\\')
    {
      (*format)++;
      if (**format == 'n')
	i += my_printchar('\n', buffer);
      if (**format == 't')
	i += my_printchar('\t', buffer);
      if (**format == 'a')
	i += my_printchar('\a', buffer);
      if (**format == 'b')
	i += my_printchar('\b', buffer);
      if (**format == 'v')
	i += my_printchar('\v', buffer);
      if (**format == 'r')
	i += my_printchar('\r', buffer);
      if (**format == 'f')
	i += my_printchar('\f', buffer);
    }
  return i;
}

static int	option_get(const char **format)
{
  int		mask;

  mask = 0;
  mask |= is_space(format);
  mask |= is_sharp(format);
  mask |= is_plus(format);
  mask |= is_zero(format);
  mask |= is_moins(format);
  mask |= is_short(format);
  mask |= is_long(format);
  return mask;
}

static int	draw_dog(char *buffer)
{
  int		i;

  i = 0;
  i += my_printstr("      __   _,--===--,_    __\n", buffer);
  i += my_printstr("     /  \\.     .-.      ./  \\\n", buffer);
  i += my_printstr("    /  ,/  _   : :    _  \\/` \\ \n", buffer);
  i += my_printstr("    \\  `| /o\\  :_:   /o\\ |\\__/\n", buffer);
  i += my_printstr("     `-'| := ~`  _ `~ =: |\n", buffer);
  i += my_printstr("        \\`      (_)     `/\n", buffer);
  i += my_printstr(" .--.     \\      |       /   .--.\n", buffer);
  i += my_printstr("{     }--|  /,.-'-.,\\  |--{      }\n", buffer);
  i += my_printstr("(_)_)_)  \\_/`~-===-~`\\_/  (_(_(_))\n", buffer);
  return i;
}

static int	is_mouf(char *buffer, const char **format)
{
  int		i;

  i = 0;
  if (**format == 'm')
  {
    (*format)++;
    if (**format == 'o')
    {
      (*format)++;
      if (**format == 'u')
      {
	(*format)++;
	if (**format == 'f')
	  {
	    (*format)++;
	    draw_dog(buffer);
	  }
      }
    }
  }
  return i;
}

static int	make_percent(char *buffer, const char **format,
			     va_list *v1, t_type *tab)
{
  int		i;

  i = 0;
  i += is_mouf(buffer, format);
  i += is_b(format, v1, buffer);
  tab[8].mask = is_star(format, v1);
  tab[9].mask = option_get(format);
  if (tab[8].mask == 1)
    tab[8].mask = is_star(format, v1);
  if (tab[8].mask == 1)
    tab[8].mask = is_width(format);
  is_dot(format, tab, v1);
  tab[9].mask |= option_get(format);
  return i;
}

static int	make_nopercent(const char **format, char *buffer)
{
  int		i;
  int		nb;

  i = nb = 0;
  
  i += my_printchar(**format, buffer);
  return i;
}

static int	print_space(t_type *tab, char *buffer)
{
  int		i;

  i = 0;
  if (flag_det(tab, FLAG_SPACE))
  {
    if (tab[8].mask != 1)
      tab[8].mask--;
    i += my_printchar(' ', buffer);
  }
  return i;
}

int		my_printf(const char *format, ...)
{
  va_list	v1;
  t_type	tab[15];
  int		i, nb;
  char		buffer[MY_BUFFER_SIZE];

  nb = 0;
  init_printf(tab, buffer);
  va_start(v1, format);
  for (i = 0; *format; format++)
    if (*format != '%')
	i += make_nopercent(&format, buffer);
    else
      {
	format++;
	if (*format)
	  {
	    i += make_percent(buffer, &format, &v1, tab);
	    i += print_space(tab, buffer);
	    tab[3].mask = i;
	    i += display(tab, *format, &v1, buffer);
	  }
      }
  va_end(v1);
  my_flush(buffer);
  return i;
}
