/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Sun Nov  6 23:49:33 2005 Nicolas Clermont
** Last update Sun Nov  6 23:49:35 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "pm.h"
#include "../../console/console.h"

/*!
** Define the colors used to print the memory
*/
#define USED_FG	0x02
#define USED_BG	0x20
#define FREE_FG	0x0e
#define FREE_BG	0xe0
#define WHI_BLK 0x07

extern t_pm	*pm;

/*!
** Set foreground and background color
*/
static void	set_bg_fg_color(int *fg, int *bg, int fg_val, int bg_val)
{
  *fg = fg_val;
  *bg = bg_val;
}

/*!
** Print part of an area in ascii art
*/
static void	print_line(char *msg, int data, int fg, int bg)
{
  int		i, st, len;

  st = (int)ttys[0].addr;
  ttys[0].attrib = fg;
  printf("|");
  ttys[0].attrib = bg;
  printf("%s", msg);
  printf("%x", data);
  len = (int)ttys[0].addr - st;
  len /= 2;
  for (i = 0; i < (18 - len); i++)
    printf(" ");
  ttys[0].attrib = fg;
  printf("|");
}

/*!
** Print the line on the top and bottom of an area
** @param fg	Foreground color
** @param bg	Background color
*/
static void	print_top_bottom(int *fg, int *bg, t_area_list **old_head,
				 t_area_list **list_tmp, int *nbused, int nbarea)
{
  int		i, printed_free;

  for (i = 0; i < 19; i++)
    cons_print_char('-');
  if (ttys[0].attrib == FREE_FG)
    {
      ttys[0].attrib = USED_FG;
      *fg = USED_FG;
      *bg = USED_BG;
      printed_free = 1;
    }
  else
    {
      printed_free = 0;
      *old_head = *list_tmp;
      *list_tmp = (*list_tmp)->next;
      (*nbused)++;
    }
  if (*list_tmp && !printed_free)
    if ((((t_area*)((*old_head)->data))->start + ((t_area*)((*old_head)->data))->nbpages * PAGE_SIZE) !=
	(((t_area*)((*list_tmp)->data))->start))
      {
	ttys[0].attrib = FREE_FG;
	*fg = FREE_FG;
	*bg = FREE_BG;
      }
  if (!(*list_tmp) && (nbarea != 3))
    {
      ttys[0].attrib = FREE_FG;
      for (i = 0; i < 19; i++)
	cons_print_char('-');
    }
}

/*!
** Manage the display of a part of an area
*/
static void	print_data_line(int *fg, int *bg, t_area_list **list_tmp,
				t_area_list **old_head, char *msg, t_paddr data_to_print)
{
  int		printed_free;

  print_line(msg, data_to_print, *fg, *bg);
  if (ttys[0].attrib == FREE_FG)
    {
      set_bg_fg_color(fg, bg, USED_FG, USED_BG);
      printed_free = 1;
    }
  else
    {
      printed_free = 0;
      *old_head = *list_tmp;
      *list_tmp = (*list_tmp)->next;
    }
  if (*list_tmp && !printed_free)
    if ((((t_area*)((*old_head)->data))->start + ((t_area*)((*old_head)->data))->nbpages * PAGE_SIZE) !=
	(((t_area*)((*list_tmp)->data))->start))
      set_bg_fg_color(fg, bg, FREE_FG, FREE_BG);
}

/*!
** Print the last free area on a new line
** @param	old_head	Allow to determine the start address of the area
*/
static void	print_last_free(t_area_list *old_head)
{
  int		i;

  ttys[0].attrib = FREE_FG;
  for (i = 0; i < 19; i++)
    cons_print_char('-');
  ttys[0].attrib = WHI_BLK;
  cons_goto_next_line();
  print_line("Begin: 0x", ((t_area*)(old_head->data))->start +
	     ((t_area*)(old_head->data))->nbpages * PAGE_SIZE, FREE_FG, FREE_BG);
  ttys[0].attrib = WHI_BLK;
  cons_goto_next_line();
  print_line("End  : 0x", mem_upper * 1024, FREE_FG, FREE_BG);
  ttys[0].attrib = WHI_BLK;
  cons_goto_next_line();
  print_line("ComptRef  : ", 0, FREE_FG, FREE_BG);
  ttys[0].attrib = WHI_BLK;
  cons_goto_next_line();
  ttys[0].attrib = FREE_FG;
  for (i = 0; i < 19; i++)
    cons_print_char('-');
  ttys[0].attrib = WHI_BLK;
  cons_goto_next_line();
}

/*!
** Print a list of area
** @param	ar_list	Area list to print
** @param	fg	Foreground color
** @param	bg	Background color
*/
static void	machdep_print_ascii_list(t_area_list *ar_list, int fg, int bg)
{
  int           i, nbarea = 0, nbused = 0;
  t_area_list   *list_tmp, *cur_head, *old_head, *cur_old_head;
  int           cur_bg, cur_fg;
  t_paddr       data_to_print;

  set_bg_fg_color(&cur_fg, &cur_bg, fg, bg);
  cur_head = ar_list;
  old_head = cur_head;
  while (cur_head)
    {
      set_bg_fg_color(&fg, &bg, cur_fg, cur_bg);
      cur_old_head = old_head;
      for (i = 0; i < nbused; i++)
        cur_head = cur_head->next;
      ttys[0].attrib = fg;
      for (list_tmp = cur_head, nbarea = 0; list_tmp && nbarea < 4; nbarea++)
	print_top_bottom(&fg, &bg, &old_head, &list_tmp, &nbused, nbarea);
      nbused = 0;
      ttys[0].attrib = WHI_BLK;
      cons_goto_next_line();
      set_bg_fg_color(&fg, &bg, cur_fg, cur_bg);
      old_head = cur_old_head;
      for (list_tmp = cur_head, nbarea = 0; list_tmp && nbarea < 4; nbarea++)
        {
          if (fg == USED_FG)
            data_to_print = ((t_area*)(list_tmp->data))->start;
          else
            data_to_print = ((t_area*)(old_head->data))->start + ((t_area*)(old_head->data))->nbpages * PAGE_SIZE;
	  print_data_line(&fg, &bg, &list_tmp, &old_head, "Begin: 0x", data_to_print);
	  if (!list_tmp && (nbarea != 3))
	    print_line("Begin: 0x", ((t_area*)(old_head->data))->start +
		       ((t_area*)(old_head->data))->nbpages * PAGE_SIZE, FREE_FG, FREE_BG);
	}
      ttys[0].attrib = WHI_BLK;
      cons_goto_next_line();
      set_bg_fg_color(&fg, &bg, cur_fg, cur_bg);
      old_head = cur_old_head;
      for (list_tmp = cur_head, nbarea = 0; list_tmp && nbarea < 4; nbarea++)
        {
          if (fg == USED_FG)
            data_to_print = ((t_area*)(list_tmp->data))->nbpages * PAGE_SIZE + ((t_area*)(list_tmp->data))->start;
          else
            data_to_print = ((t_area*)(list_tmp->data))->start;
	  print_data_line(&fg, &bg, &list_tmp, &old_head, "End  : 0x", data_to_print);
	  if (!list_tmp && (nbarea != 3))
	    print_line("End  : 0x", mem_upper * 1024, FREE_FG, FREE_BG);
	}
      ttys[0].attrib = WHI_BLK;
      cons_goto_next_line();
      set_bg_fg_color(&fg, &bg, cur_fg, cur_bg);
      old_head = cur_old_head;
      for (list_tmp = cur_head, nbarea = 0; list_tmp && nbarea < 4; nbarea++)
        {
          if (fg == USED_FG)
            data_to_print = ((t_area*)(list_tmp->data))->compt_ref;
          else
            data_to_print = 0;
	  print_data_line(&fg, &bg, &list_tmp, &old_head, "ComptRef  : ", data_to_print);
	  if (!list_tmp && (nbarea != 3))
	    print_line("ComptRef  : ", 0, FREE_FG, FREE_BG);
	}
      ttys[0].attrib = WHI_BLK;
      cons_goto_next_line();
      set_bg_fg_color(&fg, &bg, cur_fg, cur_bg);
      old_head = cur_old_head;
      ttys[0].attrib = fg;
      for (list_tmp = cur_head, nbarea = 0; list_tmp && nbarea < 4; nbarea++)
	print_top_bottom(&fg, &bg, &old_head, &list_tmp, &nbused, nbarea);
      set_bg_fg_color(&cur_fg, &cur_bg, fg, bg);
      ttys[0].attrib = WHI_BLK;
      cons_goto_next_line();
      if (!list_tmp)
        for (; cur_head; cur_head = cur_head->next)
          ;
    }
  if (!list_tmp && (nbarea == 4))
    print_last_free(old_head);
}

/*!
** Print a representation of the physical memory in ASCII art
*/
void		machdep_print_pm(void)
{
  ttys[0].attrib = USED_BG;
  cons_print_char(' ');
  ttys[0].attrib = USED_FG;
  printf(" Zone Used    ");
  ttys[0].attrib = FREE_BG;
  cons_print_char(' ');
  ttys[0].attrib = FREE_FG;
  printf(" Zone Free");
  ttys[0].attrib = WHI_BLK;
  cons_goto_next_line();
  machdep_print_ascii_list(pm->used, USED_FG, USED_BG);
}
