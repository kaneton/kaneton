/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Thu Jun  9 22:38:31 2005 Nicolas Clermont
** Last update Wed Dec  7 10:25:04 2005 Antoine Castaing
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "vm.h"
#include "../vm.h"
#include "pm.h"
#include "vm_area.h"
#include "area.h"
#include "as.h"
#include "../as.h"
#include "../../list/list.h"
#include "../../console/console.h"
#include "../../../bootloader/phys_mem_mapping.h"
#include "../../../bootloader/ch_cr.h"
#include "../../../kaneton/error.h"

#define VM_BASE_ADDRESS		0
/* 4 Go */
#define VM_NB_PAGES		0xFFFFFFFF / PAGE_SIZE
#define KAS_USED_PAGES		(file_conf_addr / PAGE_SIZE + 1)
#define KAS_USED_ADDRESS	(file_conf_addr + PAGE_SIZE)

#define VIRTUAL_MEM_UPPER	0xFFFFFFFF

#define VAS_FLAG_USED		0x0
#define VAS_FLAG_FREE		0x1

extern t_as_list	*as_list;

extern t_pm		*pm;

static int		get_nb_vm_area(t_area_list *list,
				       t_vaddr begin_addr,
				       int nbbytes)
{
  int			nb_area = 0;
  t_vaddr		tmp_addr;
  t_vm_area		fake_vm_area;
  t_vm_area		*area;

  fake_vm_area.start = begin_addr;
  area = (t_vm_area *) list_find_item(list,
				      &fake_vm_area,
				      is_addr_in_area);

  if (area->nbpages * PAGE_SIZE + area->start < begin_addr)
    return -1;
  tmp_addr = area->nbpages * PAGE_SIZE + area->start;

  nbbytes -= (area->start + area->nbpages * PAGE_SIZE) - begin_addr;
  nb_area++;

  /*
  ** On remet l'adresse du debut de l'area fake a la fin de la precedente
  */
  fake_vm_area.start = area->start + area->nbpages * PAGE_SIZE;

  for (; nbbytes > 0; nb_area++)
    {
      area = (t_vm_area *) list_find_item(list,
					  &fake_vm_area,
					  vm_area_cmp_start);
      if (area == NULL)
	  return -1;
      nbbytes -= area->nbpages * PAGE_SIZE;
      tmp_addr = fake_vm_area.start + (area->nbpages * PAGE_SIZE);
      fake_vm_area.start = tmp_addr;
    }
  return nb_area;
}


/*!
** Initialize the virtual memory of an address space
** @param	asid	Identifier of the address space to initialize
*/
int		machdep_vm_init(t_asid asid)
{
  t_as		*as;
  t_vm_area	karea;

  as_get(asid, &as);
  as->vas_free = (t_vm_area_list *)NULL;
  as->vas_used = (t_vm_area_list *)NULL;
  if (asid == KASID)
    {
      /* Used kernel virtual memory */
      vm_area_init(0, KAS_USED_PAGES,
		   VM_ATTR_READ | VM_ATTR_WRITE | VM_ATTR_EXEC, VM_AREA_USED,
		   0, &karea);
      vm_area_list_add(&(as->vas_used), &karea, vm_area_cmp_start);
      vm_area_init(IDT_ADDR, 2,
		   VM_ATTR_READ | VM_ATTR_WRITE | VM_ATTR_EXEC, VM_AREA_USED,
		   0, &karea);
      karea.mapped_pm_area = IDT_ADDR;
      vm_area_list_add(&(as->vas_used), &karea, vm_area_cmp_start);
      vm_area_init(STACK_ADDR, 3,
		   VM_ATTR_READ | VM_ATTR_WRITE | VM_ATTR_EXEC, VM_AREA_USED,
		   0, &karea);
      karea.mapped_pm_area = STACK_ADDR;
      vm_area_list_add(&(as->vas_used), &karea, vm_area_cmp_start);
      /* Free kernel virtual memory */
       vm_area_init(0x1400000, (VIRTUAL_MEM_UPPER - 0x1400000) / PAGE_SIZE,
		    VM_FLAG_ANY, VM_AREA_FREE, 0, &karea);
       vm_area_list_add(&(as->vas_free), &karea, vm_area_cmp_npages);
    }
  else
    {
      /*
      ** The Free Virtual Adress Space
      */
      vm_area_init(0x1000000, VM_NB_PAGES - 0x1000000 / PAGE_SIZE,
		   VM_ATTR_NONE, VM_AREA_FREE, 0, &karea);
      vm_area_list_add(&(as->vas_free), &karea, vm_area_cmp_npages);
     }
   return 0;
 }

 /*!
 ** Allocate n pages of virtual memory
 ** @param	asid	Identify the as to which we want to allocate memory for
 ** @param	addr	Return parameters that contain the address of the allocated area
 ** @param	npages	Number of pages we want to allocate
 ** @param	flags
 */
 int		machdep_vm_rsv(t_asid asid, t_vaddr *addr, t_vsize npages, t_vmflags flags)
 {
   t_as		*as;
   t_vm_area	*old_free = NULL;
   t_vm_area	new_used;
   t_vm_area	fake_vm_area;

   /* NIKO A DIT : PAS BIEN !!!! c pour les tests */
   /*   if (!asid) */
   /*     return 1; */
   flags = flags;

   /* We get the address space corresponding to the given asid */
   machdep_as_get(asid, &as);

   if (flags & VM_FLAG_SPECIFIC)
     {
       vm_area_init(*addr, npages, 0, 0, 0, &fake_vm_area);
       if (list_find_item(as->vas_used, &fake_vm_area,
			  is_vaddr_in_vmarea))
	 return 1;
       vm_area_init(*addr + npages * PAGE_SIZE, 0, 0, 0, 0,
		    &fake_vm_area);
       if (list_find_item(as->vas_used, &fake_vm_area,
			  is_vaddr_in_vmarea))
	 return 1;
       vm_area_init(*addr, npages,
		    VM_ATTR_READ | VM_ATTR_WRITE | VM_ATTR_EXEC, VM_AREA_FREE,
		    0, &new_used);
       vm_area_list_add(&(as->vas_used), &new_used, vm_area_cmp_start);

       return 0;
     }

   /* We make a fake vm_area filling with the wanted size */
   vm_area_init(0, npages, 0, 0, 0, &fake_vm_area);
   /* Get a free area which contains the same number of pages as we want to reserve or more */
   old_free = (t_vm_area *)list_find_item(as->vas_free,
					  &fake_vm_area,
					  vm_area_cmp_npages_ge);

   if (!old_free)
     return 1;

  /* Set the address of the reserved area */
  *addr = old_free->start;

  /*
  ** Check if the free area to use contains the exact same number of page
  ** as the area we want to reserve
  ** If so, use it, else modify it
  */
  if (npages == old_free->nbpages)
    {
      list_delete_item(&(as->vas_free), old_free, vm_area_cmp, vm_area_clear);
      old_free = NULL;
    }
  else
    vm_area_modify(old_free, *addr + npages * PAGE_SIZE,
		   old_free->nbpages - npages);

  /* Add the new used area to the used list of the address space */
  vm_area_init(*addr, npages,
	       VM_ATTR_READ | VM_ATTR_WRITE | VM_ATTR_EXEC, VM_AREA_FREE,
	       0, &new_used);
  vm_area_list_add(&(as->vas_used), &new_used, vm_area_cmp_start);
  return 0;
}



/*!
** Modify the attribute of a virtual page
** FIXME : BONUS
*/
int		machdep_vm_attr(t_asid asid, t_vaddr addr, t_vsize npages,
				t_vattr attr)
{
  asid = asid;
  addr = addr;
  npages = npages;
  attr = attr;
  return 0;

/*   t_as		*as_mod; */

/*   as_mod = list_find_item(as_list, asid, as_cmp_asid); */
/*   return 0; */
}

int		machdep_vm_flush(t_asid asid)
{
  t_as		*as;
  t_vm_area	tmp_area;

  as_get(asid, &as);
  list_clear(&(as->vas_used), NULL);
  list_clear(&(as->vas_free), NULL);

  vm_area_init(VM_BASE_ADDRESS, VM_NB_PAGES, VM_ATTR_NONE, 0, 0, &tmp_area);
  vm_area_list_add(&(as->vas_free), &tmp_area, vm_area_cmp_npages);

  return 0;
}

/*!
** Translate a physical memory page address into a virtual page
** address.
** @param asid		Owner of the page table
** @param to_translate	Physical page address to translate
** @return		The virtual page address
*/
t_vaddr			pt_pm_to_vm(t_id asid, t_paddr to_translate)
{
  /* FIXME : ON DEVRAIT PAS AVOIR BESOIN DE CHNAGER D'AS !!!*/
  /* FIXME : PTT MAPPER PAR AS KERNEL */
  int		i = 0;
  t_as		*as_found;
  t_paddr	pt_paddr = 0;
  t_vaddr	pt_vaddr = 0;
  t_vaddr	pd_vaddr = 0;
  t_vaddr	ptt_vaddr = 0;
  t_paddr	ptt_paddr = 0/* = VIRTUAL_PTT*/;

  as_get(asid, &as_found);
  pd_vaddr = as_found->pd_vaddr;
/*   printf("pd_vaddr : %x\n", pd_vaddr); */
  /*   set_pd_address((unsigned int)as_found->pd_addr); */
  ptt_paddr = (((word *)pd_vaddr)[2] >> 12) * PAGE_SIZE;
/*   printf("ptt_paddr : %x\n", ptt_paddr); */
  ptt_vaddr = ptm_pm_to_vm(asid, ptt_paddr);
  if (asid == KASID)
    ptt_vaddr = ptt_paddr;
/*   printf("ptt_vaddr : %x\n", ptt_vaddr); */
  for (pt_vaddr = 0; i < 1024; ++i)
    {
      pt_paddr = (((word *)(ptt_vaddr))[i] >> 12) * PAGE_SIZE;
      if (pt_paddr == to_translate)
	{
	  pt_vaddr += PTT_PDE << 22;
	  pt_vaddr += i << 12;
	  break;
	}
    }

  return pt_vaddr;
}

/*!
** Translate the physical address of a USER PTM to a linear address using PTPD
** @param
*/
//FIXME : DEGAGER ASID Y EN A PAS BESOIN
t_vaddr			ptm_pm_to_vm(t_id asid, t_paddr to_translate)
{
  int		i = 1;
  t_paddr	pt_addr = 0;
  t_vaddr	ret = 0;

  asid = asid;
  for (ret = 0; i < 1024; ++i)
    {
      pt_addr = (((word *)(PTPD_ENTRY))[i] >> 12) * PAGE_SIZE;
      if (pt_addr == to_translate)
	{
	  ret += PTPD_PDE << 22;
	  ret += i << 12;
	  break;
	}
    }

  return ret;
}

/*
** Translate a virtual adress into a physical address
** @param	pd	Page directory to use for translation
** @param	vaddr	Virtual adress to translate
** @return	The physical address
*/
t_paddr         vm_to_pm(word *pd, t_vaddr vaddr, t_asid asid, t_paddr pd_addr)
{
  /* FIXME : ON DEVRAIT PAS AVOIR BESOIN DE CHNAGER D'AS !!!*/
  /* FIXME : PTT MAPPER PAR AS KERNEL */
  /* FIXME : pd doit etre l'adresse virtuelle */
  int           pd_entry;
  int           pt_entry;
  int           offset;
  t_paddr       pt;
  t_paddr       paddr;
  t_vaddr	v_pt;

  pd_entry = (vaddr >> 22);
  pd_entry = pd_entry & 0x3FF;
  pt_entry = (vaddr >> 12);
  pt_entry = pt_entry & 0x3FF;
  offset = vaddr & 0xFFF;

  /* KERNEL SPACE */
  /*   set_pd_address((unsigned int)PD_ENTRY); */
  pt = pd[pd_entry];
  /* USER   SPACE */
  /* set_pd_address((unsigned int)pd_addr); */
  pt = pt >> 12;
  pt &= 0xFFFFF;
  pt *= PAGE_SIZE;
  v_pt = pt_pm_to_vm(asid, pt);
  set_pd_address((unsigned int)pd_addr);
  paddr = (((word *)v_pt)[pt_entry] >> 12);
  set_pd_address((unsigned int)PD_ENTRY);
  paddr &= 0xFFFFF;
  paddr *= PAGE_SIZE;
  return (paddr + offset);
}

int		machdep_vm_clear(void)
{
  t_as_list	*cur_as;

  for (cur_as = as_list; cur_as; cur_as = cur_as->next)
    vm_flush(((t_as *)cur_as->data)->asid);
  return 0;
}

/*!
** Map npages pages from (to) paddr to (from) vaddr
** @param	asid	Identifier of the as of which to map memory
** @param	paddr	Physical address to map
** @param	vaddr	Virtual address to map
** @param	npages	Number of pages to map
*/
int		machdep_vm_map(t_asid asid,
			       t_paddr paddr,
			       t_vaddr vaddr,
			       t_vsize npages)
{
  unsigned int	i = 0;
  t_paddr	tmp_paddr, pd_paddr;
  t_vaddr	tmp_vaddr, pd_vaddr;
  t_as		*as;
  t_vm_area	*vm_area;
  t_vm_area	fake_vm_area;

  if (!npages)
    return 1;

  /*   printf("Asid : %d paddr %x vaddr %x npages %d\n", */
  /* 	 asid, paddr, vaddr, npages); */
  as_get(asid, &as);
  pd_paddr = as->pd_addr;
  pd_vaddr = as->pd_vaddr;
  for (i = 0, tmp_vaddr = vaddr, tmp_paddr = paddr; i < npages;
       ++i, tmp_vaddr += PAGE_SIZE, tmp_paddr += PAGE_SIZE)
    map_page_vaddr(pd_vaddr, tmp_vaddr, tmp_paddr, asid, pd_paddr);
  vm_area_init(vaddr, 0, 0, 0, 0, &fake_vm_area);
  vm_area = (t_vm_area *)list_find_item(as->vas_used, &fake_vm_area, vm_area_cmp_start);
  vm_area->mapped_pm_area = paddr;
  flush_tlb();

  return 0;
}

/*!
** Unmap npages pages of vaddr
** @param	asid	Identifier of the as of which to unmap memory
** @param	vaddr	Virtual address to unmap
** @param	npages	Number of pages to unmap
*/
int		machdep_vm_unmap(t_asid asid, t_vaddr vaddr, t_vsize npages)
{
  unsigned int	i = 0;
  t_vaddr	v_pd;
  t_as		*as;

  if (!npages)
    return 1;
  as_get(asid, &as);
  v_pd = as->pd_vaddr;
  for (i = 0; i < npages; ++i, vaddr += PAGE_SIZE)
    unmap_page_vaddr(v_pd, vaddr, as->pd_addr, asid);
  flush_tlb();
  return 0;
}

/*!
** Copy 'nbytes' bytes from address 'src' to address 'dst'
** @param	from	Identifier of the as to copy from
** @param	src	Address to copy from
** @param	to	Identify the as to copy to
** @param	dst	Address to copy to
** @param	nbytes	Number of bytes to copy
** @return
*/
int	machdep_vm_copy(t_asid from,
			t_vaddr src,
			t_asid to,
			t_vaddr dst,
			t_vsize nbytes)
{
  /*  while(1);*/
  int			cpt = 0;
  t_as			*as_from;
  t_as			*as_to;

  t_vm_area		*area_from;
  t_vm_area		*area_to;

  t_vm_area		fake_vm_area_from;
  t_vm_area		fake_vm_area_to;

  t_paddr		pm_from_start;
  t_paddr		pm_to_start;

  int			nbbytes_from;
  int			nbbytes_to;
  int			address_from;
  int			address_to;

  int			nb_vm_area_from;
  int			nb_vm_area_to;

  /* Recuperation de l'as de depart et de celui de destination */
  as_get(from, &as_from);
  as_get(to, &as_to);

  /* Creation des fakes pour la recherche */
  fake_vm_area_from.start = src;
  fake_vm_area_to.start = dst;

  nb_vm_area_from = get_nb_vm_area(as_from->vas_used, fake_vm_area_from.start, nbytes);
  nb_vm_area_to = get_nb_vm_area(as_to->vas_used, fake_vm_area_to.start, nbytes);

  if (nb_vm_area_from == -1)
    return -1;

  if (nb_vm_area_to == -1)
    return -1;
#ifdef DEBUG
  printf("NB area src : %d | NB area dst : %d \n",
	 nb_vm_area_from, nb_vm_area_to);
#endif

  /* iteration sur le nonmbre d'area source */

  /* Recuperation des vm_area  */
  area_from = (t_vm_area *) list_find_item(as_from->vas_used,
					   &fake_vm_area_from,
					   vm_area_cmp_start_le);
#ifdef DEBUG
  printf("<<1st Area From : start <%d> | nbpages <%d> | phys_mem <%d> | >>\n",
	 area_from.start, area_from.nbpages, area_from.mappped_pm_area);
#endif

  area_to = (t_vm_area *) list_find_item(as_to->vas_used,
					 &fake_vm_area_to,
					 vm_area_cmp_start_le);
#ifdef DEBUG
  printf("<<1st Area To : start <%d> | nbpages <%d> | phys_mem <%d> | >>\n",
	 area_to.start, area_to.nbpages, area_to.mappped_pm_area);
#endif

  /* On calcule le nb d'octets 'concernes' dans chaque vm_area */
  nbbytes_from = area_from->start + area_from->nbpages * PAGE_SIZE - address_from;
  nbbytes_to = area_to->start + area_to->nbpages * PAGE_SIZE - address_to;

  /* On calcule les adresses physiques de depart */
  pm_from_start = (t_paddr)area_from->mapped_pm_area + address_from - area_from->start;
  pm_to_start = (t_paddr)area_to->mapped_pm_area + address_to - area_to->start;



  for (cpt = 1; nbytes > 0; cpt++)
    {
#ifdef DEBUG
      printf("CPT -> %d \n", cpt);
      printf("FROM : pm_start <%d> nb octets to copy from this vmarea <%d>\n", pm_from_start, nbbytes_from);
      printf("TO : pm_start <%d> nb octets copyable in this area <%d>\n", pm_to_start, nbbytes_to);
      printf("nb bytes left to copy : <%d>\n", nbbytes);
#endif

      /*
      ** The less wide area is copied/filled (src/dest)
      ** the numbers of bytes to copy is refresh
      */
      if (nbbytes_from > nbbytes_to)
	{
	  for (; nbbytes_to > 0; nbbytes_to--, nbbytes_from--, pm_to_start++, pm_from_start++)
	    pm_to_start = pm_from_start;
	  nbytes -= nbbytes_to;
	}
      else
	{
	  for (; nbbytes_from > 0; nbbytes_from--, nbbytes_to--, pm_to_start++, pm_from_start++)
	    pm_to_start = pm_from_start;
	  nbytes -= nbbytes_from;
	}


      /*
      ** if the byte comming from the src area area copied and we still need to copy
      ** any bytes, we take the following area and refresh the parameters
      ** like the number of byte left to copy
      */
      if (!nbbytes_from && nbytes)
	{
	  fake_vm_area_from.start = area_from->start + area_from->nbpages * PAGE_SIZE;
	  area_from = (t_vm_area *) list_find_item(as_from->vas_used,
						   &fake_vm_area_from,
						   vm_area_cmp_start);
	  if (!area_from)
	    return -1;
	  pm_from_start = area_from->mapped_pm_area;
	  if (nbytes > (area_from->nbpages * PAGE_SIZE))
	    nbbytes_from = area_from->nbpages * PAGE_SIZE;
	  else
	    nbbytes_from = nbytes;
	}


      /*
      ** The same as above but for the destinations area now
      */
      if (!nbbytes_to && nbytes)
	{
	  fake_vm_area_to.start = area_to->start + area_to->nbpages * PAGE_SIZE;
	  area_to = (t_vm_area *) list_find_item(as_to->vas_used,
						    &fake_vm_area_to,
						    vm_area_cmp_start_le);
	  if (!area_to)
	    return -1;
	  pm_to_start = area_to->mapped_pm_area;
	  if (nbytes > (area_to->nbpages * PAGE_SIZE))
	    nbbytes_to = area_to->nbpages * PAGE_SIZE;
	  else
	    nbbytes_to = nbytes;
	}
    }
  return 0;
}

/*!
** Free n memory pages of virtual memory
** If the virtual memory area to free maps a physical memory area,
** and this physical memory area is not shared, you must free this
** physical memory outside of this function
** @param	asid	Identify the as where we want to free space
** @param	addr	Beginning of the area to free
** @param	npages	Number of pages we want to free
*/
int		machdep_vm_rel(t_asid asid,
			       t_vaddr addr,
			       const t_vsize npages)
{
  t_as		*as;
  t_vm_area	*area_to_free;
  t_vm_area	new_free_area;
  t_vm_area	fake_area;
  t_vsize	tmp_vm_area_size = 0;
  int		npages_tmp = npages;
  int		cpt = 0;

#ifdef DEBUG
  printf("START DEBUG VM_REL \n");
#endif

  as_get(asid, &as);

  if (get_nb_vm_area(as->vas_used, addr, npages * PAGE_SIZE) == -1)
    return error("machdep_vm_rel error", __FILE__, __LINE__);

  fake_area.start = addr;
  /* Here we get the area containing the begining vaddr to free */

  area_to_free = (t_vm_area *)list_find_item(as->vas_used,
					     &fake_area, is_addr_in_area);

#ifdef DEBUG
  vm_area_print(area_to_free);
#endif

  if (!area_to_free)
    return 1;

  /* Here we create a vm area with all the good parameters */
  vm_area_init(addr,
	       npages,
	       0,
	       VM_AREA_FREE,
	       area_to_free->mapped_pm_area,
	       &new_free_area);

  /*
  ** If the address of pages to rel is in inside an area
  ** (understand not the start address)
  ** we get the nbpages from the address in this area
  */
  if (area_to_free->start != addr)
    tmp_vm_area_size = area_to_free->nbpages -
      (addr - area_to_free->start) / PAGE_SIZE;
  else
    tmp_vm_area_size = area_to_free->nbpages;

#ifdef DEBUG
  printf("%d pages dispo depuis l'adresse\n", tmp_vm_area_size);
#endif

  /* Refresh the nb of pages to rel */
  npages_tmp = npages - tmp_vm_area_size;

#ifdef DEBUG
  printf("nbpages <<%d>>\n", npages_tmp);
#endif

  /* If it's exactly the area size  */
  if (npages_tmp == 0 && area_to_free->start == addr)
    vm_area_list_delete(&(as->vas_used), area_to_free);
  else
    if (npages_tmp <= 0)
      {
	/* if the pages start at the begining of the vm_area */
	if (area_to_free->start == addr)
	  {
/* 	    printf("CAS 1\n"); */
/* 	    printf("new addr <%x>\n", area_to_free->start + npages * PAGE_SIZE); */
	    vm_area_modify(area_to_free, area_to_free->start + npages * PAGE_SIZE,
			   -npages_tmp);

	  }
	else
	  {
/* 	    printf("CAS 2\n"); */
/* 	    printf("on tombe sur la fin de l'area ??\n"); */
	    /* Si la fin tombe PAS sur la fin de l' area donc il faut ajouter une area */
	    if (npages_tmp != 0)
	      {
/* 		printf("CAS 3\n"); */
		npages_tmp = area_to_free->nbpages - npages - (addr - area_to_free->start) / PAGE_SIZE;
		vm_area_init(addr + npages * PAGE_SIZE, npages_tmp ,
			     VM_FLAG_ANY, 0, 0, &fake_area);
		vm_area_list_add(&(as->vas_used), &fake_area, vm_area_cmp_start);
	      }
	    vm_area_modify(area_to_free, area_to_free->start,
			   (addr - area_to_free->start) / PAGE_SIZE);

	  }
	npages_tmp = 0;
      }

 /* If it concerns more than one area */
  fake_area.start = area_to_free->start + area_to_free->nbpages * PAGE_SIZE;
  if (npages_tmp > 0)
    {
      if (area_to_free->start == addr)
	vm_area_list_delete(&(as->vas_used), area_to_free);
      else
	{
	  vm_area_modify(area_to_free, area_to_free->start,
			 (addr - area_to_free->start) / PAGE_SIZE);
	}
    }
  for (cpt=0; npages_tmp > 0; ++cpt)
    {
      area_to_free = (t_vm_area *)list_find_item(as->vas_used,
						 &fake_area,
						 vm_area_cmp_start);
      if (!area_to_free)
	return 1;
      fake_area.start = area_to_free->start + area_to_free->nbpages * PAGE_SIZE;
      if (npages_tmp >= (int)area_to_free->nbpages)
	{
	  vm_area_list_delete(&(as->vas_used), area_to_free);
	  npages_tmp -= area_to_free->nbpages;
	}
      else
	{
	  vm_area_modify(area_to_free, area_to_free->start + npages_tmp * PAGE_SIZE,
			 area_to_free->nbpages - npages_tmp);
	  npages_tmp = 0;
	}
    }

  if (npages_tmp)
    return 1;
  vm_area_list_add(&(as->vas_free), &new_free_area, vm_area_cmp_npages);
  return 0;
}
