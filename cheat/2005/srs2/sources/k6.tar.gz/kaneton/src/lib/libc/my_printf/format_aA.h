/*
** format_aA.h for  in /u/a1/clermo_n/PRINT/printf
** 
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
** 
** Started on  Wed Oct 30 01:43:53 2002 nicolas clermont
** Last update Wed Oct 30 01:44:36 2002 nicolas clermont
*/
#include "my_printf.h"

int		type_a(va_list *arg, char *buffer, t_type *tab);
int		type_A(va_list *arg, char *buffer, t_type *tab);
