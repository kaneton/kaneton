/*
** format_scp.c for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 01:41:17 2002 nicolas clermont
** Last update Wed Oct 30 05:17:28 2002 nicolas clermont
*/
#include "my_printf.h"

static int	type_s_precision(char *str, char *buffer, t_type *tab)
{
  char		*str_tmp;
  char		*str_ret;
  int		i;

  if ((tab[9].mask & FLAG_DOT) == FLAG_DOT)
    if (tab[7].mask < my_strlen(str))
    {
      str_tmp = malloc(tab[7].mask + 1);
      str_ret = str_tmp;
      for (i = 0; i < tab[7].mask; i++)
	*str_tmp++ = * str++;
      *str_tmp = '\0';
      return (my_printstr(str_ret, buffer));
    }
  return 0;
}

int		type_s(va_list *arg, char *buffer, t_type *tab)
{
  char		*s;
  int		max;
  int		i, j;

  j = 0;
  if ((s = va_arg(*arg, char*)) == NULL)
    return (my_printstr("(null)", buffer));
  if ((tab[9].mask & FLAG_MOINS) == FLAG_MOINS)
    if ((j += type_s_precision(s, buffer, tab)) == 0)
      j += my_printstr(s, buffer);
  if (tab[8].mask != 1)
    {
      if (tab[7].mask < (max = my_strlen(s)))
	max = tab[7].mask;
      if (tab[8].mask > max)
	for (i = 0; i < (tab[8].mask - max); i++)
	  j += my_printchar(' ', buffer);
    }
  if ((tab[9].mask & FLAG_MOINS) != FLAG_MOINS)
    if ((j += type_s_precision(s, buffer, tab)) == 0)
      j += my_printstr(s, buffer);
  return j;
}

int		type_c(va_list *arg, char *buffer, t_type *tab)
{
  char		c;
  int		len;
  int		i, j;

  j = 0;
  c = va_arg(*arg, int);
  if ((tab[9].mask & FLAG_MOINS) == FLAG_MOINS)
    j += my_printchar(c, buffer);
  if (tab[8].mask != 1)
  {
    len = 1;
    if (tab[8].mask > len)
      for (i = 0; i < (tab[8].mask - len); i++)
	j += my_printchar(' ', buffer);
  }
  if ((tab[9].mask & FLAG_MOINS) != FLAG_MOINS)
    j += my_printchar(c, buffer);
  return j;
}

int		type_p(va_list *arg, char *buffer, t_type *tab)
{
  unsigned int	p;
  int		i, j;
  int		len;

  i = 0;
  p = va_arg(*arg, unsigned int);
  if ((tab[9].mask & FLAG_MOINS) == FLAG_MOINS)
    {
      my_printstr("0x", buffer);
      i += my_printnbr_base(p, "0123456789abcdef", buffer);
    }
  if (tab[8].mask != 1)
    {
      len = my_baselen(p, "0123456789abcdef");
      if (tab[8].mask > len)
	for (j = 0; j < (tab[8].mask - (len + 2)); j++)
	  i += my_printchar(' ', buffer);
    }
  if ((tab[9].mask & FLAG_MOINS) != FLAG_MOINS)
    {
      my_printstr("0x", buffer);
      i += my_printnbr_base(p, "0123456789abcdef", buffer);
    }
  return (i + 2);
}

int		flag_det(t_type *tab, int flag)
{
  if ((tab[9].mask & flag) == flag)
    return 1;
  else
    return 0;
}
