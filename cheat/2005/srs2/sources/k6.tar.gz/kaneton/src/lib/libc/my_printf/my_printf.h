/*
** my_printf.h for  in /u/a1/clermo_n/PRINT/printf
**
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
**
** Started on  Wed Oct 30 02:04:36 2002 nicolas clermont
** Last update Sun Nov 13 15:30:21 2005 Antoine Castaing
*/
#ifndef MY_PRINTF_H_
# define MY_PRINTF_H_

# define FLAG_PLUS	1
# define FLAG_SHARP	2
# define FLAG_SPACE	4
# define FLAG_ZERO	8
# define FLAG_MOINS	16
# define FLAG_DOT	32
# define FLAG_b		64
# define FLAG_SHORT	128
# define FLAG_LONG	256

#include "../../../include/kaneton/types.h"
#include "../../../include/kaneton/stdarg.h"
/* #include <stdarg.h> */
/* #include <unistd.h> */
/* #include <stdlib.h> */
/* #include <sys/types.h> */
/* #include <sys/stat.h> */
#include "../libc.h"
#include "../write.h"
#include "../string.h"

typedef struct  s_type
{
  char          c;
  int		mask;
  int           (*func)(va_list *arg, char *buffer, struct s_type *tab);
}		t_type;

#include "format_hd.h"
#include "format_ho.h"
#include "format_hu.h"
#include "format_hx.h"
#include "format_hX.h"
#include "format_ld.h"
#include "format_lo.h"
#include "format_lu.h"
#include "format_lx.h"
#include "format_lX.h"
#include "format_X.h"
#include "format_aA.h"
#include "format_d.h"
#include "format_nyz.h"
#include "format_o.h"
#include "format_scp.h"
#include "format_u.h"
#include "format_x.h"
#include "util_base.h"
#include "util_nbr.h"
/* #include "util_right.h" */
#include "util_str.h"
#include "my_printf_define.h"


/* int		my_printf(const char *format, ...); */
void		init_printf(t_type *tab, char *buffer);
int		is_specific(char **format, char *buffer);
#endif
