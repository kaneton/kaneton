/*
** Copyright (C) Castaing Antoine et Lolo <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Mon Feb 28 03:56:55 2005 Laurent Decool
** Last update Wed Oct  5 16:51:39 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef LIB_CONSOLE_H
# define LIB_CONSOLE_H

#include "curseur.h"
#include "cons_print.h"

# define CONSOLE_ADDRESS		0xB8000
# define DEFAULT_CONSOLE_ATTRIB		0x07

/*!
** These two port are used for the VGA cursor
** and scrolling
**
** Register index port.
** port to send DATA
*/
# define IO_VGA_PORT_CMD		0x3D4
# define IO_VGA_PORT_DATA		0x3D5

/*!
** Height and width of consoles
*/
# define LINES		25
# define COLUMNS	80

# define SIZE_PROMPT	12

# define CONSOLE_COLOR_BLACK	0x0
# define CONSOLE_COLOR_BLUE	0x1
# define CONSOLE_COLOR_GREEN	0x2
# define CONSOLE_COLOR_CYAN	0x3
# define CONSOLE_COLOR_RED	0x4
# define CONSOLE_COLOR_MAGENTA	0x5
# define CONSOLE_COLOR_YELLOW	0x6
# define CONSOLE_COLOR_WHITE	0x7
# define TAB_SIZE		0x3

# define VGA_COMMAND_PORT	0x3D4
# define VGA_DATA_PORT		0x3D5


# define VGA_SET_CURSOR_START	0xA
# define VGA_SET_CURSOR_END	0xB
# define VGA_SET_ADDRESS_HIGH	0xC
# define VGA_SET_ADDRESS_LOW	0xD
# define VGA_SET_CURSOR_HIGH	0xE
# define VGA_SET_CURSOR_LOW	0xF

# define VGA_REG_START_CUR	0xA
# define VGA_REG_END_CUR	0xB

/*
** Definiton of the current tty
*/
int	current_tty;
int	console_attrib;

typedef struct s_tty
{
  char	*start_addr;
  char	*end_addr;
  int	current_scroll_offset;
  char	*addr;
  int	attrib;
}	t_tty;

t_tty	ttys[8];

/* void	update_curseur(void); */
void    cons_backspace(void);
void	init_ttys(void);
void	cons_clear_screen(void);

void	cons_goto_next_line(void);

void	update_tty(int tty_id, char new_attrib);

void	hard_scrolling(int pos);
int	switch_tty(int tty);

void	mark_prompt(void);

#endif	/* !LIB_CONSOLE_H */
