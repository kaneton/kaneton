/*
** format_nyz.h for  in /u/a1/clermo_n/PRINT/printf
** 
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
** 
** Started on  Wed Oct 30 01:45:56 2002 nicolas clermont
** Last update Wed Oct 30 01:46:51 2002 nicolas clermont
*/
#include "my_printf.h"

int		type_z(va_list *arg, char *buffer, t_type *tab);
int		type_r(va_list *arg, char *buffer, t_type *tab);
int		type_y(va_list *arg, char *buffer, t_type *tab);
int		type_n(va_list *arg, char *buffer, t_type *tab);
