/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Sun Nov 13 16:48:59 2005 Nicolas Clermont
** Last update Sun Nov 13 18:17:35 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef _LIBC_MOD_H_
# define _LIBC_MOD_H_

# include "libc.h"

# define MOD_CMD_PS		0
# define MOD_CMD_GET_MODID	1
# define MOD_CMD_GET_TSKID	2
# define MOD_CMD_EXEC		3

/*!
** List modules and their associated tasks/threads...
*/
int	ps(void);

/*!
** Get the module identifier of the module named "module_name"
** @param	module_name	We search its modid
** @return	The modid of module_name
*/
t_modid	get_modid(char *module_name);

/*!
** Get the task identifier of the module named "module_name"
** @param	module_name	We search its task id
** @return	The task id of module_name
*/
t_tskid	get_tskid(char *module_name);

/*!
** Execute the program module_name
*/
int	exec(char *module_name);

#endif	/* !_LIBC_MOD_H_ */
