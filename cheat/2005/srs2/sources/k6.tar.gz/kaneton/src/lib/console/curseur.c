/*
** Copyright (C) Antoine Castaing aka xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Wed Mar 23 23:38:39 2005 Antoine Castaing
** Last update Wed Oct  5 16:19:43 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "console.h"
#include "../../include/kaneton/ioports.h"

void	update_curseur_pos_in_char(int offset)
{
  int	arg_to_give_reg_14 = offset >> 8;/* Args to give to the MSB register */
  int	arg_to_give_reg_15 = offset & 0xFF;/* Args to give to the LSB register */

  outb(VGA_SET_CURSOR_HIGH,VGA_COMMAND_PORT);
  outb(arg_to_give_reg_14, VGA_DATA_PORT );
  outb(VGA_SET_CURSOR_LOW, VGA_COMMAND_PORT);
  outb(arg_to_give_reg_15, 0x3D5);
}

/*
** @param x This is the column
** @param y This is the line
*/
void	update_curseur_x_y(int x, int y)
{
  update_curseur_pos_in_char(x + 1 + COLUMNS * y);
}

void	update_curseur(void)
{
  update_curseur_pos_in_char(((int) ttys[current_tty].addr - (CONSOLE_ADDRESS) + (4096 * current_tty)/*-1*/) / 2);
}
