/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Sat Mar 19 18:03:25 2005 Damien Laniel
** Last update Wed Oct  5 14:46:01 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../include/kaneton/types.h"

/*!
** Reserve some physical memory and map it to a virtual address
**
** @param asid Represent the as to use
** @param vaddr Virtual address of the reserved memory
** @param npages Number of pages to reserve
*/
int	mm_rsv(t_asid asid, t_vaddr *vaddr, t_vsize npages);

/*!
** Free some physical memory, given its virtual address
**
** @param asid Represent the as to use
** @param vaddr Virtual address of the reserved memory
** @param npages Number of pages to free
*/
int	mm_rel(t_asid asid, t_vaddr vaddr, t_vsize npages);
