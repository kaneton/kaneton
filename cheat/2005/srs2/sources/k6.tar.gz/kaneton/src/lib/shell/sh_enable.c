/*
** Copyright (C) Castaing Antoine aka Xebech <xebech@xebech.homelinux.com>
**
** Part of Kaneton
**
** Started on  Fri Jun 10 22:42:20 2005 Castaing Antoine
** Last update Tue Sep 27 11:27:52 2005 Damien Laniel
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include "../console/console.h"
#include "../libc/libc.h"
#include "../libc/string.h"
#include "../../kaneton/idt/pic.h"
#include "../../include/kaneton/types.h"
#include "parse_cmd.h"
#include "sh_enable.h"

#define NB_ENABLE_FCT 1

char enable_pic[4] = "pic";


struct s_enable_builtin enable_arg[NB_ENABLE_FCT] =
  {
    {(char *)(&enable_pic), (my_fct_enable)pic_enable}
  };

void	sh_enable(char *arg[NB_MAX_ARG], int nb_arg)
{
  int	j = 0;

  switch (nb_arg)
    {
    case 0:
      printf("Wrong number of args\n");
      if (info_general)
	printf("%s", info_general);
      else
	printf("L'aide de Kaneton n est pas active\n");
      break;
    case 1:
      printf("Wrong number of args\n");
      if (info_general)
	printf("%s", info_general);
      else
	printf("L'aide de Kaneton n est pas active\n");
      break;
    case 2:
      for (j = 0; j < NB_ENABLE_FCT; j++)
	if (!strcmp(enable_arg[j].fct_label, arg[0]))
	  enable_arg[j].fct((t_event_id)atoi(arg[1]));
      break;
    default:
      printf("Wrong number of args\n");
      if (info_general)
	printf("%s", info_general);
      else
	printf("L'aide de Kaneton n est pas active\n");
      break;
  }
}
