/*
** util_base.h for  in /u/a1/clermo_n/PRINT/printf
** 
** Made by nicolas clermont
** Login   <clermo_n@epita.fr>
** 
** Started on  Wed Oct 30 01:51:37 2002 nicolas clermont
** Last update Wed Oct 30 01:52:23 2002 nicolas clermont
*/
#include "my_printf.h"

int		recurse_nbr_base(unsigned int nbr, char *base, int size,
				 char *buffer);
unsigned int	my_printnbr_base(unsigned int nbr, char *base, char *buffer);
int		my_baselen(unsigned int nbr, char *base);
