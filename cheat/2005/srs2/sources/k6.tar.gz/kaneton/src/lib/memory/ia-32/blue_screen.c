/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
** 
** Part of Kaneton 
** 
** Started on  Tue Mar 29 02:36:30 2005 Nicolas Clermont
** Last update Tue Mar 29 02:37:00 2005 Nicolas Clermont
** 
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "../../../lib/console/console.h"

void		print_fatal_screen(void)
{
  int		i;

  ttys[0].attrib = 0x1e;
  for (i = 0; i < 10; i++)
    cons_goto_next_line();
  for(i = 0; i < 33; i++)
    cons_print_char(' ');
  printf("Fatal Error !");
  cons_goto_next_line();
  cons_goto_next_line();
  for(i = 0; i < 24; i++)
    cons_print_char(' ');
  printf("All the memory is being used !!!");
  cons_goto_next_line();
  cons_goto_next_line();
  for(i = 0; i < 13; i++)
    cons_print_char(' ');
  printf("If you were on a stupid OS, you would need to reboot.");
  cons_goto_next_line();
  for(i = 0; i < 13; i++)
    cons_print_char(' ');
  printf("Fortunately, you use Kaneton OS, so just hit F7 x2...");
  cons_goto_next_line();
  cons_goto_next_line();
  for(i = 0; i < 33; i++)
    cons_print_char(' ');
  printf("And relax !!!");
  for (i = 0; i < 8; i++)
    cons_goto_next_line();
  ttys[0].attrib = 0x07;
}
