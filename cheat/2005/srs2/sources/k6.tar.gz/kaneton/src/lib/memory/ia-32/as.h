/*
** Copyright (C) Nicolas Clermont aka nico <clermo_n@epita.fr>
**
** Part of Kaneton
**
** Started on  Mon Mar 28 15:13:31 2005 Nicolas Clermont
** Last update Sat Nov 12 22:36:08 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef IA32_AS_H
# define IA32_AS_H

# include "../../../include/kaneton/types.h"
# include "../../list/list.h"
# include "area.h"
# include "vm_area.h"
# include "../../../kaneton/task/task.h"

/*!
** The list that contains all the address spaces
*/
typedef t_list	t_as_list;

/*!
** The structure that describe an address space
*/
typedef struct		s_as
{
  t_asid		asid;
  t_tskid		tskid;
  t_ownid		ownid;
  t_modid		modid;
  t_vaddr		l_malloc;
  t_area_list		*pas;
  t_vm_area_list	*vas_used;
  t_vm_area_list	*vas_free;
  t_paddr		pd_addr;
  t_vaddr		pd_vaddr;
} t_as;

t_tskid as_modid_taskid(t_modid mod);

/*!
** Initialise la gestion des espaces d'adressage
*/
int	machdep_as_init(void);

/*!
** Reserve un espace d'adressage
*/
int	machdep_as_rsv(t_asid *asid);

/*!
** Retourne l'adresse de la structure a partir de son identifiant
*/
int	machdep_as_get(t_asid asid, t_as **as);

/*!
** Libere l'espace d'adressage specifie
*/
int	machdep_as_rel(t_asid asid);

/*!
** Detruit tous les espaces d'adressage
*/
int	machdep_as_clear(void);

/*!
** Free the address space physical memory
** Used by pm_clear()
*/
void	machdep_as_pm_clear(void);

/*!
** Print an address space
*/
void	as_print(const void * as);

/*!
** Print all the adress space
*/
void	print_addr_space(void);

/*!
** Clone an address space
*/
int	machdep_as_clone(t_asid old, t_asid *new);

/*!
** Fill tskid with the id of the task using the address space asid
*/
int	machdep_as_tskid(t_asid asid, t_tskid *tskid);

/*!
** Fill the modid parameter with the id of  the module in the address space owner id
*/
int	machdep_as_modid(t_asid asid, t_modid *modid);

/*!
** Attach the module modid to the as asid
*/
int	machdep_as_set_modid(t_asid asid, t_modid modid);

/*!
** Fill the ownid parameter with the address space owner id
*/
int	machdep_as_ownid(t_asid asid, t_ownid *ownid);

/*!
** Change owner of the address space
*/
int	machdep_as_give(t_asid asid, t_ownid ownid);

/*!
** Attach an address space to a task
*/
int	machdep_as_attach(t_asid asid, t_tskid tskid);

/*!
** Attach an address space to a task
*/
int	machdep_as_detach(t_asid asid, t_tskid tskid);

/*!
** Get the physical address of the Page Directory of the as asid
*/
int	machdep_as_get_pd_paddr(t_asid asid, t_paddr *pd_paddr);

#endif	/* !IA32_AS_H */
