#ifndef KANETON_PRINT_ASCII_H_
# define KANETON_PRINT_ASCII_H_

void		machdep_print_vm_ascii(t_as *as);

#endif /* !KANETON_PRINT_ASCII_H_ */
