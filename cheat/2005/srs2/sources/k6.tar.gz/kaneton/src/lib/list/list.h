/*
** Copyright (C) Damien Laniel aka heretik <heretik@tuxfamily.org>
**
** Part of Kaneton
**
** Started on  Mon Mar  7 01:00:14 2005 Damien Laniel
** Last update Mon Nov 14 02:45:58 2005 Nicolas Clermont
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef	LIST_H_
# define LIST_H_

#include "../../include/kaneton/types.h"

typedef struct	s_list
{
  struct s_list	*next;
  void		*data;
} t_list;

/*!
** Copy source data to destination data
**
** @param	source		address where we read the data
** @param	destination	address where we write the data
** @return	0 success, 1 failed
*/
typedef int	(*t_copy_func)(const void *source, void *destination);

/*!
** Compare two datas
**
** @param	data	address of the first data to compare
** @param	data2	address of the second data to compare
** @return	0 if equals, 1 if the first data is greater, -1 if the second data is greater
*/
typedef int	(*t_cmp_func)(const void *data, const void *data2);

/*!
** Clear data memory
**
** @param	data	address of the data to clear
*/
typedef void	(*t_clear_func)(void *data);

/*!
** Print data
**
** @param	data	address of the data to print
*/
typedef void	(*t_print_func)(const void *data);

/*!
** Initialize list memory to 0, from memory_start to the the end of the page
**
** @param	memory_start	start physical address of list
*/
void		list_init(t_paddr memory_start);

/*!
** Search for a free space in physical memory for a node
**
** @param	start		physical address of the page where we start to search
** @param	node_size	size of the node for which to search space
** @return	physical address of the space we found, NULL if none found
*/
t_paddr		list_search_free_phys_space(t_paddr start, int node_size, int ptas);

/*!
** Search for a free space in physical memory for a node
**
** @param	pt_addr		physical address of the page table where we search
** @param	node_size	size of the node for which to search space
** @return	physical address of the space we found, NULL if the page table is full
*/
t_paddr		list_search_free_phys_space_pt(t_paddr pt_addr, int node_size, int pos);

/*!
** Add an item at the end of the list
**
** @param	list		list in which to add an item
** @param	addr		physical address of the node, given by list_search_free_phys_space()
** @param	data		data to write in the node
** @param	copy_func	function which copies a data to memory
** @see		list_search_free_phys_space()
*/
void		list_add_item_end(t_list	**list,
				  const t_paddr	addr,
				  void		*data,
				  t_copy_func	copy_func);

/*!
** Add an item in the list, sorted with cmp_func
**
** @param	list		list in which to add an item
** @param	addr		physical address of the node, given by list_search_free_phys_space()
** @param	data		data to write in the node
** @param	copy_func	function which copies a data to memory
** @param	cmp_func	function which compares two datas
*/
void		list_add_item_sorted(t_list		**list,
				     const t_paddr	node_addr,
				     void		*data,
				     t_copy_func	copy_func,
				     t_cmp_func		cmp_func);

/*!
** Delete an item from the list
**
** @param	list		list in which to delete an item
** @param	data		data of the node to delete. you may have to	\
**				create a fake data which contains the infos you need
** @param	cmp_func	function which compares two datas
** @param	clear_func	function which clears a data memory
*/
void		list_delete_item(t_list		**list,
				 const void	*data,
				 t_cmp_func	cmp_func,
				 t_clear_func	clear_func);

/*!
** Return the size of the list
**
** @param	list	list which to get the size
** @return	size of the list
*/
unsigned int	list_size(const t_list *list);

/*!
** Search for an item in the list, which data is equal to given data
**
** @param	list		list in which to search the item
** @param	data		data of the item to search. you may have to	\
**				create a fake data which contains the infos you need
** @param	cmp_func	function which compares two datas
** @return	pointer to the found data, NULL if none found
*/
void		*list_find_item(const t_list	*list,
				const void	*data,
				t_cmp_func	cmp_func);

/*
** Find the nearest upper or equal element in the given list
**
** @param	list		The list
** @param	data		The comparison element
** @param	cmp_func	The comparison function
*/
void		*list_find_item_ge(const t_list	*list,
				   const void	*data,
				   t_cmp_func	cmp_func);

/*
** Find the nearest lower or equasl element in the given list
**
** @param	list		The list
** @param	data		The comparison element
** @param	cmp_func	The comparison function
*/
void		*list_find_item_le(const t_list	*list,
				   const void	*data,
				   t_cmp_func	cmp_func);

/*!
** Clear the list. Delete all nodes from the list
**
** @param	list		list to clear
** @param	clear_func	function which clear a data memory
*/
void		list_clear(t_list **list, t_clear_func clear_func);

/*!
** Print the list
**
** @param	list		list to print
** @param	print_func	function which prints a data
*/
void		list_print(const t_list *list, t_print_func print_func);

/*!
** Optimized Version of list_search_free_phys_space
**
*/
t_paddr		optim_list_search_free_phys_space(t_paddr *start, 
						  int node_size, 
						  int ptas);
#endif /* !LIST_H_ */
