#include <userland.h>
#include "shell.h"

int	userland_sh(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  k_shell();
  return 0;
}
