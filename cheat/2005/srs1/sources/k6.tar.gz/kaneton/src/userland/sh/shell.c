#include <keyboard.h>
#include <console.h>
#include <stdio.h>
#include <asm.h>
#include <int.h>
#include <test.h>
#include <types.h>
#include <string.h>
#include <ide.h>
#include <pci.h>
#include <stdlib.h>
#include <userland.h>
#include <unistd.h>
#include <vfs.h>
#include "builtins/builtins.h"
#include "shell.h"

/*
** command table
*/
const static _t_cmds commands[] =
{
  /* { "asinfos",		shell_asinfos,		"Display informations about address spaces" }, */
  { "cat",              builtin_cat,            "concatenate files and print on the standard output" },
  { "cd",               builtin_cd,             "change the current directory" },
  { "clear",		cons_clear,		"Clear the screen" },
  { "date",		k_date_display,		"Display the current date and time" },
  /* { "div0",		shell_div_zero,		"Test division by zero exception" }, */
  { "help",		shell_help,		"Print this help message"},
  /* { "ide_read",		shell_disk_read,	"read from a disk"}, */
  /* { "ide_write",	shell_disk_write,	"write to a disk"}, */
  { "kaneton",		shell_kaneton,		"So fun display! ;-)" },
  { "ls",               userland_ls,            "list directory contents" },
  { "lside",		userland_lside,		"list IDE devices" },
  { "lspart",           userland_lspart,	"list partitions" },
  { "lspci",		lspci,			"Display PCI device" },
  /* { "malloc",		shell_malloc,		"Allocate dynamic memory" }, */
  { "mkdir",            userland_mkdir,         "create a directory" },
  { "mount",            userland_mount,         "mount a file system" },
  /* { "pminfos",		shell_pminfos,		"Display informations about physical memory" }, */
  { "pwd",              builtin_pwd,            "print name of current/working directory" },
  { "reboot",		shell_reboot,		"stop the system." },
  { "rm",		userland_rm,		"remove files or directories" },
  /* { "segdebug",		seg_debug,		"A small tool to debug segments manager" }, */
  { "sh",		userland_sh,		"Shell" },
  /* { "showkey",		shell_showkey,		"Keyboard test command"}, 
  { "testas",		shell_test_as,		"Test AS management" },
  { "testpm",		shell_test_pm,		"Test AS/PM management" },
  { "testvm",		shell_test_vm,		"Test VM management" },
  { "testmal",		shell_testmalloc,	"Test the malloc function" },*/
  { "thread1",		shell_thread1,		"start thread1" },
  /* { "timer",		k_timer_display,	"Test the timer" }, */
  { "touch",            userland_touch,         "change file timestamps" }, 
  { "uname",		userland_uname,		"Print system information" },
  /* { "vaddr",		shell_firstvaddr,	"Give the first virtual address" }, */
  { NULL,		NULL,			NULL }
};


/*
** Print shell help
*/
int		shell_help(int argc, char **argv)
{
  unsigned int	i;
  unsigned int	j;

  (void) argc;
  (void) argv;
  for (i = 0; commands[i].command; ++i)
  {
    printf("%s", commands[i].command);
    for (j = 0; j < 21 - strlen(commands[i].command); ++j)
      printf(" ");
    printf("- %s\n", commands[i].help);
  }
  return 0;
}

/*
** Main loop
*/
void		k_shell(void)
{
  char		c;
  unsigned char	print = 0; /* do we have to print the char */
  char		buffer[4096];
  int		pos = 0;
  char		pwd[MAXPATHLEN];

  memset(buffer, 0, 4096);
  printf("%s:%s$ ", SHELL_PROMPT, getcwd(pwd, MAXPATHLEN));
  while (1)
  {
    k_get_char(&c);
    print = 0;
    if (c == '\n')
    {
      putchar('\n');
      if (!strcmp(buffer, "exit"))
        break;
      shell_command_launch(buffer);
      pos = 0;
      memset(buffer, 0, 4096);
      printf("%s:%s$ ", SHELL_PROMPT, getcwd(pwd, MAXPATHLEN));
      print = 0;
    }
    else
      if (c == 14)
      {
        if (pos)
        {
          buffer[--pos] = 0;
          print = 1;
        }
      }
      else
      {
        print = 1;
        buffer[pos++] = c;
      }
    if (print)
      putchar(c);
  }
}

/*
 * check if the command is in the table command
 * If so, it execute the associated command
 */
int	shell_command_launch(char *buffer)
{
  int	i;
  int	j;
  char	*argv[SHELL_MAXARGS];
  int	argc = 0;
  char	*whitespaces = " \t\n";

  for (i = 0, j = 0; buffer[i + j]; ++i)
    if (strchr(whitespaces, buffer[i + j]))
    {
      argv[argc++] = strndup(buffer + j, i);
      j += i + 1;
      i = -1;
    }
  argv[argc++] = strndup(buffer + j, i);
  for (i = 0; commands[i].command; ++i)
    if (!strcmp(argv[0], commands[i].command))
    {
      commands[i].function(argc, argv);
      break;
    }
  if (!commands[i].command && buffer[0] != 0)
    error_command(argc, argv);
  for (i = 0; i < argc; ++i)
    free(argv[i]);
  return 0;
}
