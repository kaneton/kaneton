#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <userland.h>

int	userland_touch(int argc, char **argv)
{
  int	fd;

  if (argc < 2)
    printf("touch: file arguments missing\n");
  else
  {
    fd = open(argv[1], O_CREAT);
    close(fd);
  }
  return 0;
}
