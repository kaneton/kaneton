#ifndef __BUILTINS_H_
# define __BUILTINS_H_

# define SHELL_HOME "/"

int	builtin_cat(int argc, char **argv);
int	builtin_cd(int argc, char **argv);
int	builtin_pwd(int argc, char **argv);

#endif /* !__BUILTINS_H_ */
