#ifndef LS_H
# define LS_H

# define LS_ERRMSG_NOTFOUND "No such file or directory"

struct	s_flags
{
  int	a;
  int	l;
};

#endif /* !LS_H */
