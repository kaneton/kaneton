#ifndef BUILTINS_CAT_H
# define BUILTINS_CAT_H

# define CAT_ERRMSG_NOTFOUND "No such file or directory"

#endif /* !BUILTINS_CAT_H */
