#ifndef BUILTINS_CD_H
# define BUILTINS_CD_H

# define CD_ERRMSG_NOTFOUND "no such file or directory"

#endif /* !BUILTINS_CD_H */
