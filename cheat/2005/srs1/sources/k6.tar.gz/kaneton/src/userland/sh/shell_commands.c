#include <keyboard.h>
#include <console.h>
#include <stdio.h>
#include <asm.h>
#include <int.h>
#include <test.h>
#include <pm.h>
#include <vm.h>
#include <as.h>
#include <paging.h>
#include <version.h>
#include <machdep/segments.h>
#include <mm.h>
#include <stdlib.h>
#include <malloc.h> /*DELETE after debug*/
#include <unistd.h>
#include <modules.h>
#include <cpu.h>
#include <ipc.h>
#include <scheduler.h>
#include <ide.h>
#include "shell.h"

/*
 * reboot the shell
 */
int	shell_reboot(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  cons_init_msg("Cleaning CPU",     cpu_clean());
  cons_init_msg("Cleaning modules", mod_clean());
  cons_init_msg("Cleaning IPC",	    ipc_clean());
  cons_init_msg("Cleaning set",     set_clean());
  cons_init_msg("Cleaning IDE",     ide_clean());
  k_reboot();
  return 0;
}

/*
 * Get physical memory informations
 */
int		shell_pminfos(int argc, char **argv)
{
  extern _t_pm	_pm;
  int		usedpages = 0;
  unsigned int	i = 0;

  (void) argc;
  (void) argv;
  printf("Physical memory :\n");
  printf("\t Start           = %x\n", _pm._start);
  printf("\t Length          = %x\n", _pm._size);
  printf("\t Number of pages = %d\n", _pm._nbpages);
  for (i = 0; i < _pm._nbpages; i++)
    {
      if (PM_NBREF(i) > 0)
	usedpages++;
    }
  printf("\t Used pages      = %d\n", usedpages);
  return 0;
}


/*
 * Print address spaces informations
 */
int	shell_asinfos(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  as_print();
  return 0;
}

int	shell_malloc(int argc, char **argv)
{
  void	*ptr;

  (void) argc;
  (void) argv;
  while (1)
    {
      ptr = malloc(10);
      printf("$>malloc returned: [%x]\n", (unsigned int)ptr);
      memset(ptr, 0, 1);
    }
  return 0;
}

/*
 *  Fun display
 */
int	shell_kaneton(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  cons_attr(0, 0, 1, 6);
  printf("             ,-.\n");
  printf("         ,--' ~.).\n");
  printf("       ,'         `.\n");
  printf("      ; (((__   __)))\n");
  printf("      ;  ( (#) ( (#)\n");
  printf("      |   \\_/___\\_/|\n");
  printf("     ,'  ,-'    `__'.\n");
  printf("    (   ( ._   ____`.)--._        _\n");
  printf("     `._ `-.`-' \(`-'  _  `-. _,-' `-/`.\n");
  printf("      ,')   `.`._))  ,' `.   `.  ,','  ;\n");
  printf("    .'  .     `--'  /     ).   `.      ;\n");
  printf("   ;     `-        /     '  )         ;\n");
  printf("   \\                       ')       ,'\n");
  printf("    \\                     ,'       ;\n");
  printf("     \\               `~~~'       ,'\n");
  printf("      `.                      _,'\n");
  printf("        `.                ,--'\n");
  printf("          `-._________,--'',\n");
  cons_attr(0, 0, 0, 7);
  return 0;
}

/*
 * Error : command unknow
 */
int	error_command(int argc, char **argv)
{
  (void) argc;
  printf("k-shell: command not found: %s\n", argv[0]);
  return 0;
}

int	shell_div_zero(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  k_div_zero();
  return 0;
}

int		shell_test_pm(int argc, char **argv)
{
  t_paddr	ad3;
  int		i = 1;

  (void) argc;
  (void) argv;
  while (i < 10000)
    {
      if (pm_rsv(kas.asid, &ad3, i, PM_FLAG_ANY))
	{
	  printf("PM rsv failed\n");
	  return 1;
	}
      if (pm_rel(kas.asid, ad3, i))
	{
	  printf("PM rel failed\n");
	  return 1;
	}
      printf("TEST:%d succeed\n", i);
      i++;
    }
/*   pm_rsv(kas.asid, &ad2, 2, PM_FLAG_ANY); */
/*   pm_rsv(kas.asid, &addr, 2, PM_FLAG_ANY); */
/*   pm_rel(kas.asid, ad2, 2); */
/*   pm_rel(kas.asid, ad3, 2); */
/*   pm_rsv(kas.asid, &addr, 4, PM_FLAG_ANY); */
/*   pm_rsv(kas.asid, &addr, 2, PM_FLAG_ANY); */


  /* pm_rsv and pm_rel tested for flag_any 100% */
  /* need to test with flag_specific */
  return 0;
}

int		shell_test_vm(int argc, char **argv)
{
  t_vaddr	addr;
  int		i = 1;

  (void) argc;
  (void) argv;
/*   printf("INITIAL TEST\n"); */
/*   mm_rsv(kas.asid, &addr,1024); */
/*   mm_rel(kas.asid, addr, 1024); */
/*   printf("END INITIAL TEST\n"); */

/*   printf("INITIAL TEST 2\n"); */
/*   mm_rsv(kas.asid, &addr, 1025); */
/*   mm_rel(kas.asid, addr, 1025); */
/*   printf("END INITIAL TEST 2\n"); */

/*   printf("INITIAL TEST 3\n"); */
/*   mm_rsv(kas.asid, &addr, 515); */
/*   mm_rel(kas.asid, addr, 515); */
/*   printf("END INITIAL TEST 3\n"); */

/*   printf("INITIAL TEST 4\n"); */
/*   mm_rsv(kas.asid, &addr, 512); */
/*   mm_rel(kas.asid, addr, 512); */
/*   printf("END INITIAL TEST4 \n"); */

  while (i)
    {
      //      printf("Test %d Trying to rsv\n", i);
      mm_rsv(kas.asid, &addr, i);
      mm_rel(kas.asid, addr, i);
      printf("Test %d : Rel: Succeed\n", i);
      //      printf("----------------------------------------\n");
      i++;
    }
  //  dump_map();
/*   mm_rsv(kas.asid, &addr, 5); */
/*   mm_rsv(kas.asid, &addr, 5); */
  //  mm_rsv(kas.asid, &addr, 5);
  return 0;
}

int		shell_test_as(int argc, char **argv)
{
  t_asid	asid;
  t_vaddr	addr = 0xbbbbbbbb;

  (void) argc;
  (void) argv;
  as_rsv(&asid);
  as_pm_add(asid, 0xdeadbeef, 2);
  as_pm_add(kas.asid, 0xfeeeaaaa, 42);
  as_vm_add(asid, &addr, 1, VM_FLAG_ANY);
  as_vm_add(asid, &addr, 2, VM_FLAG_ANY);
  return 0;
}

int	shell_test_as2(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  printf("as_vm_del(): [res: %d]\n", as_vm_del(2, 0x1000, 1));
  return 0;
}

int	seg_debug(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  print_gdt();
  return 0;
}

int			shell_firstvaddr(int argc, char **argv)
{
  struct x86_pte	*pt;
  struct x86_pde	*pd = (struct x86_pde *)ADDR_PD;
  int			pde = 0;
  int			pte = 0;

  (void) argc;
  (void) argv;
  while (pde < 1024)
    {
      if ((pd[pde]).present == 0)
	{
	  pt = (struct x86_pte *) (pd[pde].pt_paddr << 12);
	  while (pte < 1024)
	    {
	      if (pt[pte].present == 0)
		{
		  printf("First virtual address free is %x\n", (pde << 22) + (pte << 12));
		  printf("\tIts entry in PD is %d\n", pde);
		  printf("\tIts entry in PT is %d\n", pte);
		  return 1;
		}
	      pte++;
	    }
	  pte = 0;
	}
      pde++;
    }
  return 0;
}

int	shell_showkey(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  k_register_tty_handler(showkey);
  return 0;
}

int	shell_testmalloc(int argc, char **argv)
{
  void	*ptr1;
  void	*ptr2;
  void	*ptr3;
  void	*ptr4;
  int	i = 1;

  (void) argc;
  (void) argv;
  printf("START test*\n");
  i = 1;
  while (i <= 300)
  {
    ptr1 = malloc(10);
    memset(ptr1, 0xf, 10);
    ptr2 = malloc(10);
    memset(ptr2, 0xf, 10);
    ptr3 = malloc(i + i);
    memset(ptr3, 0, i + i );
    free(ptr2);
    ptr4 = malloc(i*i + i*i);
    memset(ptr4, 0, i*i + i*i);
    free(ptr3);
    free(ptr4);
    i++;
    free(ptr1);
    printf("test %d\n", i);
    //    sleep(8);
  }
  debug_malloc();
  dump_as(kas.asid);
  dump_map();
  return 0;
}

int	shell_thread1(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  thread1_start();
  return 0;
}

int		shell_disk_read(int argc, char **argv)
{
  char		block[512];

  (void) argc;
  (void) argv;
  ide_read(0, 0, block, 512);
  printf("%s\n", block);
  return 0;
}

int		shell_disk_write(int argc, char **argv)
{
  t_uint16	buf[] = { 0xdead, 0xbeef };

  (void) argc;
  (void) argv;
  ide_write_block(0, 0, 0, buf, 10);
  printf("Wrote 1 sector.\n");
  return 0;
}
