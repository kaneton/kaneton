#include <stdio.h>
#include <vfs.h>
#include <string.h>
#include <sys/mount.h>
#include <userland.h>

int	userland_mount(int argc, char **argv)
{
  if (argc == 2 && !strcmp(argv[1], "-h"))
  {
    printf("usage: mount [-h] [device directory]\n");
    return 0;
  }
  if (argc == 3)
  {
    if (mount(argv[1][0] - 'a', argv[1][1] - '1', argv[2]) == -1)
    {
      printf("mount: unknown fs\n");
      return -1;
    }
    return 0;
  }
  return vfs_list();
}
