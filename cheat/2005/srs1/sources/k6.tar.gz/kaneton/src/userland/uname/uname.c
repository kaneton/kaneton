#include <stdio.h>
#include <string.h>
#include <version.h>
#include <userland.h>

int	userland_uname(int argc, char **argv)
{
  char	str[512];

  strcpy(str, "Kaneton");
  if (argc == 2 && !strcmp(argv[1], "-a"))
  {
    strcat(str, " ");
    strcat(str, version());
  }
  printf("%s\n", str);
  return 0;
}
