#include <vfs.h>
#include <stdio.h>
#include <unistd.h>
#include "builtins.h"

int		builtin_pwd(int argc, char **argv)
{
  char	pwd[MAXPATHLEN];

  (void) argc;
  (void) argv;
  printf("%s\n", getcwd(pwd, MAXPATHLEN));
  return 0;
}
