#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include "builtins.h"
#include "cat.h"

int	builtin_cat(int argc, char **argv)
{
  int	fd;
  char	buf[512];
  int	rcount;

  if (argc > 1)
  {
    if (((fd = open(argv[1], 0)) < 0))
    {
      printf("%s: %s: %s\n", argv[0], argv[1], CAT_ERRMSG_NOTFOUND);
      return 0;
    }
    while ((rcount = read(fd, buf, 511)) > 0)
    {
      buf[rcount] = '\0';
      printf("%s", buf);
    }
    close(fd);
  }
  return 0;
}
