#include <ide.h>

int	userland_lside(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  ide_list();
  return 0;
}
