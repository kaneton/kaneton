#include <string.h>
#include <unistd.h>
#include "builtins.h"
#include "cd.h"

int		builtin_cd(int argc, char **argv)
{
  if (chdir(argc < 2 ? SHELL_HOME : argv[1]))
    printf("%s: %s: %s\n", argv[0], CD_ERRMSG_NOTFOUND, argv[1]);
  return 0;
}
