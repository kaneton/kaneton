#ifndef __SHELL_H
# define __SHELL_H

# define SHELL_PROMPT "kaneton"
# define SHELL_MAXARGS 512

/*
 * structures / types
 */

typedef struct	_s_cmds
{
  char	*command;
  int	(*function)(int argc, char **argv);
  char	*help;
} _t_cmds;

/*
 * prototypes
 */

void	k_shell(void);
int	shell_command_launch(char *buffer);

/*
 * function command
 */
int	shell_help(int argc, char **argv);
int	shell_reboot(int argc, char **argv);
int	shell_kaneton(int argc, char **argv);
int	error_command(int argc, char **argv);
int	shell_div_zero(int argc, char **argv);
int	shell_pminfos(int argc, char **argv);
int	shell_asinfos(int argc, char **argv);
int	shell_test_pm(int argc, char **argv);
int	shell_test_vm(int argc, char **argv);
int	shell_test_as(int argc, char **argv);
int	shell_test_as2(int argc, char **argv);
int	shell_firstvaddr(int argc, char **argv);
int	shell_malloc(int argc, char **argv);
int	shell_testmalloc(int argc, char **argv);
int	shell_thread1(int argc, char **argv);
int	shell_disk_read(int argc, char **argv);
int	shell_disk_write(int argc, char **argv);
/* Function used for debugging segments */
int	seg_debug(int argc, char **argv);
int	shell_showkey(int argc, char **argv);

#endif
