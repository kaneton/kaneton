#include <part.h>

int	userland_lspart(int argc, char **argv)
{
  (void) argc;
  (void) argv;
  part_list();
  return 0;
}
