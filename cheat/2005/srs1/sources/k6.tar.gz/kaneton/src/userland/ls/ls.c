#include <string.h>
#include <fat.h>
#include <dirent.h>
#include <userland.h>
#include <console.h>
#include "ls.h"

int	print_digit(unsigned int n)
{
  if (n < 10)
    printf("0");
  printf("%d", n);
  return 0;
}

int	print_date(t_uint16 wrt_date, t_uint16 wrt_time)
{
  print_digit(((wrt_date & 0xfe00) >> 9) + 1980);
  printf("-");
  print_digit((wrt_date & 0x01e0) >> 5);
  printf("-");
  print_digit(wrt_date & 0x1f);
  printf(" ");
  print_digit((wrt_time & 0xfe00) >> 11);
  printf(":");
  print_digit((wrt_time & 0x7e0) >> 5);
  return 0;
}

int			userland_ls(int argc, char **argv)
{
  struct s_dir		*dir;
  struct dirent		*dirent;
  struct s_flags	flags = { 0, 0 };

  if (argc > 1)
  {
    if (strchr(argv[1], 'a'))
      flags.a = 1;
    if (strchr(argv[1], 'l'))
      flags.l = 1;
  }
  if (!(dir = opendir(".")))
  {
    printf("%s: %s: %s\n", argv[0], ".", LS_ERRMSG_NOTFOUND);
    return 1;
  }
  while ((dirent = readdir(dir)))
    if (dirent->d_name[0] != '.' || flags.a)
    {
      if (flags.l)
      {
        if (dirent->attr == 0x10)
          printf("d");
        else
	  printf("-");
        printf(" ");
      }
      if (dirent->attr == 0x10)
	cons_blue(dirent->d_name);
      else
        printf("%s", dirent->d_name);
      if (flags.l)
      {
        if (strlen(dirent->d_name) < 7)
          printf("\t\t");
        printf("\t\t%d ", dirent->file_size);
	print_date(dirent->wrt_date, dirent->wrt_time);
      }
      printf("%c", flags.l ? '\n' : '\t');
    }
  if (!flags.l)
    printf("\n");
  closedir(dir);
  return 0;
}
