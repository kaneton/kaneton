/*
** Globa Descriptor Table 
** This part of the kernel is machine dependant
*/

#include <gdt.h>
#include <console.h>
#include <paging.h>
#include <string.h>

_t_gdt *_gdt = (_t_gdt *) ADDR_GDT;


static unsigned short _gdt_place = 1;
static unsigned short _kernel_code_segment;
static unsigned short _kernel_data_segment;
static unsigned short _user_code_segment;
static unsigned short _user_data_segment;

/*
 * Add An Entry To Global Descriptor Table
 */

unsigned short k_gdt_new_segment(unsigned int base, unsigned int length,
				 unsigned int type, unsigned int flags)
{
  _gdt[_gdt_place].__limit = length;
  _gdt[_gdt_place].__base = base;
  _gdt[_gdt_place]._base_16 = (base & 0xff0000) >> 16;
  _gdt[_gdt_place]._base_24 = (base & 0xff000000) >> 24;
  // type + s + dpl + 1
  _gdt[_gdt_place]._type = type & 0xff;
  // limit4 + avl + 0 + d + b
  _gdt[_gdt_place]._flags = (flags | ((length & 0xf0000) >> 16));
  return (_gdt_place++ << 3);
}

/*
** Deletes an entry in GDT
*/
int		k_gdt_remove(unsigned int entry)
{
  entry = entry;
  return 0;
}

/*
** Clears the GDT
*/
int		k_gdt_clear(void)
{
  return 0;
}

void k_gdt_update_cpu_segments(unsigned int new_code, unsigned int new_data)
{
  __asm__ __volatile__ ("pushl %0\n"
			"pushl $cs_jump\n"
   			"lret\n"
			//"ljmp $0x8, $cs_jump\n"
			"cs_jump:\n"
			"mov %1, %%eax\n"
			"mov %%ax, %%ds\n"
			"mov %%ax, %%es\n"
			"mov %%ax, %%fs\n"
			"mov %%ax, %%gs\n"
			"mov %%ax, %%ss"
			: : "g" (new_code), "g" (new_data));
}


/*
 * Initialize And Load Global Descriptor Table
 */

int k_init_gdt()
{
  memset(_gdt, 0x0, sizeof (_t_gdt) * GDT_SIZE);
  _kernel_code_segment = k_gdt_new_segment(0,
					   0xfffff,
					   GDT_DPL0 | GDT_APPLICATION | GDT_PRESENT | GDT_CODE | GDT_READABLE,
					   GDT_AVAILABLE | GDT_USE32 | GDT_GRANULAR);
  _kernel_data_segment = k_gdt_new_segment(0,
					   0xfffff,
					   GDT_DPL0 | GDT_APPLICATION | GDT_PRESENT | GDT_DATA | GDT_WRITABLE | GDT_READABLE,
					   GDT_AVAILABLE | GDT_USE32 | GDT_GRANULAR);
  _user_code_segment = k_gdt_new_segment(0,
					 0xfffff,
					 GDT_DPL3 | GDT_APPLICATION | GDT_PRESENT | GDT_CODE | GDT_READABLE,
					 GDT_AVAILABLE | GDT_USE32 | GDT_GRANULAR);
  _user_data_segment = k_gdt_new_segment(0,
					 0xfffff,
					 GDT_DPL3 | GDT_APPLICATION | GDT_PRESENT | GDT_DATA | GDT_WRITABLE,
					 GDT_AVAILABLE | GDT_USE32 | GDT_GRANULAR);

  k_lgdt(5);
  return 0;
}

void	k_lgdt(unsigned int x)
{
  static _t_gdtr gdtr;

  gdtr._addr = (unsigned int) _gdt;
  gdtr._size = x * sizeof (_t_gdt);

  /*
   * code asm inline pour loader la gdt
   */
  __asm__ volatile ("lgdt %0":: "m" (gdtr));

  __asm__ volatile ("mov %cr0,%eax\n"
	       "or %ax,1\n"
	       "mov %eax,%cr0");

  k_gdt_update_cpu_segments(_kernel_code_segment,
			    _kernel_data_segment);
}

