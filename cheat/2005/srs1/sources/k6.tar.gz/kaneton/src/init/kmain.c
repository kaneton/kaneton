#include <console.h>
#include <gdt.h>
#include <multiboot.h>
#include <paging.h>
#include <kernel_load.h>

unsigned long int total_mem_size = 0;

/** System halting function */
void		khalt()
{
  cons_print_string("\nSystem halted !!!\n");
  while (1);
}


/** This function checks the multiboot_info structure */
static void	       check_multiboot(unsigned long magic, 
				       multiboot_info_t *mbi)
{
  /** Checking if the we are booted by a multiboot complient software */
  cons_print_string("Checking multiboot magic number ... ");
  if (magic != MULTIBOOT_BOOTLOADER_MAGIC)
    {
      cons_print_string("FAILED\n");
      khalt();
    }
  else
    cons_print_string("OK\n");


  /** Displaying Kernel command line */
  if (!(((char *)mbi->cmdline)[0]))
    cons_print_string("No kernel command line\n");
  else
    {
      cons_print_string("Kernel command-line is : ");
      cons_print_string((char *)mbi->cmdline);
      cons_print_string("\n");
    }
}

/*
** This function displays modules loaded in GRUB and their place in memory.
*/
static void display_modules(multiboot_info_t *mbi)
{
  /* FIXME: Not yet implemented */
  unsigned int		i;
  module_t	*pmod;

  cons_print_string("Checking for modules ...");
  if (!(mbi->flags & 8))
    {
      cons_print_string("\nError: No module found, can't continue");
      khalt();
    }
  cons_print_string("OK\n");
  for (i = 0, pmod = (module_t *) mbi->mods_addr;
       i < mbi->mods_count;
       pmod++, i++)
    {
      cons_print_string("Module ");
      cons_print_num(i + 1);
      cons_print_string(": ");
      cons_print_string((char *)pmod->string);
      cons_print_string(" from address ");
      cons_print_addr(pmod->mod_start);
      cons_print_string(" to ");
      cons_print_addr(pmod->mod_end);
      cons_print_string("\n");
    }
}

/*
** This fundtion displays the memory map passed by GRUB. 
** The memory map describe the state of physical memory at boot : what areas are
** reserved, what areas are available for operating system use etc...
*/
void		display_mmap(multiboot_info_t *mbi)
{
  /* Are mmap_* valid? */
  if ((mbi->flags & (1 << 6)))
    {
      int	i = 0;
      memory_map_t *mmap;

      cons_print_string("Memory map : base = ");
      cons_print_addr(mbi->mmap_addr);
      cons_print_string(", length = ");
      cons_print_num(mbi->mmap_length);
      cons_print_string("\n");

      /* We display all mmap slots. */
      for (i = 0, mmap = (memory_map_t *) mbi->mmap_addr;
           (unsigned long) mmap < mbi->mmap_addr + mbi->mmap_length;
           mmap = (memory_map_t *) ((unsigned long) mmap
                                    + mmap->size + sizeof (mmap->size)),
	     i++)
	{
	  cons_print_string("Area");
	  cons_print_num(i);
	  cons_print_string(": ");
	  cons_print_string("base_addr=");
	  cons_print_addr(mmap->base_addr_high);
	  cons_print_addr_rec(mmap->base_addr_low);
	  cons_print_string(", length=");
	  cons_print_addr(mmap->length_high);
	  cons_print_addr_rec(mmap->length_low);
	  cons_print_string(", type=");
	  cons_print_addr(mmap->type);
	  cons_print_string("\n");
	}
    }
}


void kmain(unsigned long magic, multiboot_info_t *mbi)
{
  /** Initializing console driver */
  cons_init_console();

  /** Printing kernel welcome msg */
  cons_print_string("Kaneton K1!!\n");

  check_multiboot(magic, mbi);

  /** Calculating ant printing total memory size */
  total_mem_size = mbi->mem_upper * 1024 + 0x100000;
  cons_print_string("Memory: ");
  cons_print_num(total_mem_size);
  cons_print_string(" bytes aka ");
  cons_print_num(total_mem_size / (1024 * 1024));
  cons_print_string("MB\n");
  
  /* Display modules */
  display_modules(mbi);

  /* Displays the meomry map */
  display_mmap(mbi);

  /* init GDT table */
  cons_init_msg("Init GDT", k_init_gdt());

  /* init memory paging */
  cons_init_msg("Init memory paging", k_paging_setup(mbi));

  /* jump on the kerbel */
  k_kernel_load(mbi);
}
