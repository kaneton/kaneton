#include <multiboot.h>
#include <console.h>
#include <paging.h>
#include <elf.h>

void	k_kernel_load(multiboot_info_t *mbi)
{
  Elf32_Ehdr *elf = (Elf32_Ehdr *) ADDR_V_KERNEL;

  __asm__ volatile ("movl %0, %%ebx" : : "g"(mbi) : "ebx");
  __asm__ volatile ("jmp *%0" : : "g" (elf->e_entry));
}
