#include <messages.h>
#include <stdio.h>

t_setid	msgid_;


int	msg_init()
{
  set_rsv(SET_TYPE_LIST, SET_SORT_ENABLE, sizeof(t_msg), 0, &msgid_);
  return 0;
}

int	msg_clean()
{
  t_iterator	it;
  t_msg		*msg;

  SET_FOREACH(FOREACH_FORWARD, msgid_, &it)
    {
      msg = (t_msg *)ITERATOR_ADDR(&it);
      free(msg);
      set_delete(msgid_, ITERATOR_ID(&it));
    }
  set_rel(msgid_);
  return 0;
}

int		msg_create(t_msgid *msgid)
{
  t_msg		*msg = NULL;

  if ((msg = malloc(sizeof(t_msg))) == NULL)
    return -1;
  msg->msghd = NULL;
  set_insert_id(msgid_, msg, &(msg->msgid));
  *msgid = msg->msgid;
  return 0;
}

int		msg_delete(t_msgid msgid)
{
  t_msg		*msg = NULL;
  t_iterator	it;

  if (set_get(msgid_, msgid, &it) != 0)
    return -1;
  msg = (t_msg *)ITERATOR_ADDR(&it);
  if (msg == NULL)
    return -1;
  free(msg->msghd);
  free(msg);
  return 0;
}

int		msg_storehd(t_msgid msgid, t_msghd *phd)
{
  t_msg		*msg = NULL;
  t_iterator	it;

  if (set_get(msgid_, msgid, &it) != 0)
    return -1;
  msg = (t_msg *)ITERATOR_ADDR(&it);
  if (msg == NULL)
    return -1;
  msg->msghd = phd;
  return 0;
}

int		msg_loadhd(t_msgid msgid, t_msghd *phd)
{
  t_msg		*msg = NULL;
  t_iterator	it;

  if (set_get(msgid_, msgid, &it) != 0)
    return -1;
  msg = (t_msg *)ITERATOR_ADDR(&it);
  if (msg == NULL || msg->msghd == NULL)
    return -1;
  phd->knty = msg->msghd->knty;
  phd->sbty = msg->msghd->sbty;
  phd->srcid = msg->msghd->srcid;
  phd->dstid = msg->msghd->dstid;
  phd->datasz = msg->msghd->datasz;
  return 0;
}

int		msg_storedata(t_msgid msgid, t_data data, size_t sz)
{
  t_msg		*msg = NULL;
  t_iterator	it;

  if (set_get(msgid_, msgid, &it) != 0)
    return -1;
  msg = (t_msg *)ITERATOR_ADDR(&it);
  if (msg == NULL || msg->msghd == NULL)
    return -1;
  msg->msghd->datasz = sz;
  msg->data = data;
  return 0;
}

t_data		msg_loaddata(t_msgid msgid, size_t *psz)
{
  t_msg		*msg = NULL;
  t_iterator	it;

  if (set_get(msgid_, msgid, &it) != 0)
    return NULL;
  msg = (t_msg *)ITERATOR_ADDR(&it);
  if (msg == NULL || msg->msghd == NULL)
    return NULL;
  *psz = msg->msghd->datasz;
  return msg->data;
}

int	msg_send(t_msgid msgid)
{
  return 0;
}

int	msg_rcv(t_sbtype type, t_msgid *msgid)
{
  return 0;
}

