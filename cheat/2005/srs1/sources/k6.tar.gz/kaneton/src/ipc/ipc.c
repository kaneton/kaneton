#include <ipc.h>



int	ipc_init(void)
{
  int	res = 0;

  res += event_init();
  res += msg_init();
  res += trap_init();
  return res;
}

int	ipc_clean(void)
{
  int	res = 0;

  res += event_clean();
  res += trap_clean();
  res += msg_clean();
  return res;
}
