#include <traps.h>


t_setid	trapsid_;
extern _t_idt _idt[];

int	trap_init(void)
{
  int	res = 0;

  res = set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof(t_trap), 0, &trapsid_);
  // FIXME : Add traps according idt table
  trap_load_idt();
  return res;
}

int	trap_load_idt(void)
{
  // interrupts
  trap_add(IDT_DPL3, TRAP_INT_00, NULL);
  trap_add(IDT_DPL3, TRAP_INT_01, NULL);
  trap_add(IDT_DPL3, TRAP_INT_02, NULL);
  trap_add(IDT_DPL3, TRAP_INT_03, NULL);
  trap_add(IDT_DPL3, TRAP_INT_04, NULL);
  trap_add(IDT_DPL3, TRAP_INT_05, NULL);
  trap_add(IDT_DPL3, TRAP_INT_06, NULL);
  trap_add(IDT_DPL3, TRAP_INT_07, NULL);
  trap_add(IDT_DPL3, TRAP_INT_08, NULL);
  trap_add(IDT_DPL3, TRAP_INT_09, NULL);
  trap_add(IDT_DPL3, TRAP_INT_10, NULL);
  trap_add(IDT_DPL3, TRAP_INT_11, NULL);
  trap_add(IDT_DPL3, TRAP_INT_12, NULL);
  trap_add(IDT_DPL3, TRAP_INT_13, NULL);
  trap_add(IDT_DPL3, TRAP_INT_14, NULL);
  trap_add(IDT_DPL3, TRAP_INT_15, NULL);
  trap_add(IDT_DPL3, TRAP_INT_16, NULL);
  trap_add(IDT_DPL3, TRAP_INT_17, NULL);
  trap_add(IDT_DPL3, TRAP_INT_18, NULL);

  // IRQ
  trap_add(IDT_DPL3, TRAP_IRQ_00, NULL);
  trap_add(IDT_DPL3, TRAP_IRQ_01, NULL);
  trap_add(IDT_DPL3, TRAP_IRQ_02, NULL);
  trap_add(IDT_DPL3, TRAP_IRQ_03, NULL);
  trap_add(IDT_DPL3, TRAP_IRQ_04, NULL);
  trap_add(IDT_DPL3, TRAP_IRQ_05, NULL);
  trap_add(IDT_DPL3, TRAP_IRQ_06, NULL);
  trap_add(IDT_DPL3, TRAP_IRQ_07, NULL);
  trap_add(IDT_DPL3, TRAP_IRQ_08, NULL);
  return 0;
}

int		trap_add(t_pl pl, t_trapid trapid, t_behave behave)
{
  int		res = 0;
  t_trap	*trap = NULL;

  trap = malloc(sizeof(t_trap));
  if (trap == NULL)
    return -1;
  trap->pl = pl;
  trap->trapid = trapid;
  trap->behave = behave;
  set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof(t_tskid), 0, &(trap->lstid));
  res = set_insert(trapsid_, trap);
  return res;
}

int		trap_clean(void)
{
  int		res = 0;
  t_iterator	it;
  t_iterator	ite;
  t_trap	*trap;

  SET_FOREACH(FOREACH_FORWARD, trapsid_, &it)
    {
      trap = (t_trap *)ITERATOR_ADDR(&it);
      SET_FOREACH(FOREACH_FORWARD, trap->lstid, &ite)
	{
	  free((t_tskid *)ITERATOR_ADDR(&ite));
	  ITERATOR_ADDR(&ite) = NULL;
	}
      free(trap);
      ITERATOR_ADDR(&it) = NULL;
    }
  res = set_rel(trapsid_);
  return res;
}

int		trap_grade(t_trapid trapid, t_pl pl)
{
  t_trap	*trap;
  t_iterator	it;
  int		res = 0;

  if (set_get(trapsid_, trapid, &it) == 0)
    {
      trap = (t_trap *)ITERATOR_ADDR(&it);
      if (!trap)
	return -1;
      trap->pl = pl;
      res = 0;
    }
  else
    return -1;
  return 0;
}

t_pl		trap_pl(t_trapid trapid)
{
  t_trap	*trap;
  t_iterator	it;

  if (set_get(trapsid_, trapid, &it) == 0)
    {
      trap = (t_trap *)ITERATOR_ADDR(&it);
      if (trap != NULL)
	return trap->pl;
    }
  return 0;
}

int		trap_subscribe(t_trapid trapid, t_tskid tskid)
{
  t_trap	*trap;
  t_iterator	it;
  t_tskid	*nskid;

  if (set_get(trapsid_, trapid, &it) == 0)
    {
      trap = (t_trap *)ITERATOR_ADDR(&it);
      if (trap == NULL)
	return -1;
      if ((nskid = malloc(sizeof(t_tskid))) == NULL)
	return -1;
      *nskid = tskid;
      if (set_insert(trap->lstid, nskid) != 0)
	return -1;
    }
  else
    return -1;
  return 0;
}

int		trap_unsubscribe(t_trapid trapid, t_tskid tskid)
{
  t_trap	*trap;
  t_iterator	it;
  int		res = 0;

  if (set_get(trapsid_, trapid, &it) == 0)
    {
      trap = (t_trap *)ITERATOR_ADDR(&it);
      if (trap == NULL)
	return -1;

      SET_FOREACH(FOREACH_FORWARD, trap->lstid, &it)
	{
	  if (*((t_tskid *)ITERATOR_ADDR(&it)) == tskid)
	    {
	      res = set_delete(trap->lstid, ITERATOR_ID(&it));
	      free(ITERATOR_ADDR(&it));
	      return res;
	    }
	}
      return -1;
    }
  else
    return -1;
  return 0;
}

int		trap_unsubscribe_all(t_tskid tskid)
{
  t_trap	*trap;
  t_iterator	it;

  SET_FOREACH(FOREACH_FORWARD, trapsid_, &it)
    {
      trap = (t_trap *)ITERATOR_ADDR(&it);
      trap_unsubscribe(trap->trapid, tskid);
    }
  return 0;
}

int		trap_setbehave(t_trapid trapid, t_behave behave)
{
  t_trap	*trap;
  t_iterator	it;

  if (set_get(trapsid_, trapid, &it) == 0)
    {
      trap = (t_trap *) ITERATOR_ADDR(&it);
      trap->behave = behave;
    }
  else
    return -1;
  return 0;
}

t_behave	trap_getbehave(t_trapid trapid)
{
  t_trap	*trap;
  t_iterator	it;

  if (set_get(trapsid_, trapid, &it) == 0)
    {
      trap = (t_trap *) ITERATOR_ADDR(&it);
      if (trap == NULL)
	return NULL;
      return trap->behave;
    }
  return NULL;
}

int		trap_delbehave(t_trapid trapid)
{
  t_trap	*trap;
  t_iterator	it;

  if (set_get(trapsid_, trapid, &it) == 0)
    {
      trap = (t_trap *) ITERATOR_ADDR(&it);
      if (trap == NULL)
	return -1;
      trap->behave = NULL;
    }
  return 0;
}


void		trap_display(void)
{
  t_trap	*trap;
  t_tskid	*tskid;
  t_iterator	it;
  t_iterator	ite;


  SET_FOREACH(FOREACH_FORWARD, trapsid_, &it)
    {
      trap = (t_trap *)ITERATOR_ADDR(&it);
      printf("----- TRAP [%d] -%x | %p | %d-\n", trap->trapid, trap->pl, trap->behave, trap->lstid);
      SET_FOREACH(FOREACH_FORWARD, trap->lstid, &ite)
	{
	  tskid = (t_tskid *)ITERATOR_ADDR(&ite);
	  printf("%d ", *tskid);
	}
      printf("\n");
    }
}




