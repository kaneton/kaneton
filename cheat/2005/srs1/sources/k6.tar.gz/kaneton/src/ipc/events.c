#include <events.h>


int event_init(void)
{
  return 0;
}

int event_rsv(t_eventid eventid, t_event event)
{
  return 0;
}

int event_rel(t_eventid eventid)
{
  return 0;
}

int event_clean(void)
{
  return 0;
}

int event_flush(void)
{
  return 0;
}

