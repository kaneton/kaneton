#include <console.h>
#include <keyboard.h>
#include <tty.h>
#include <stdio.h>
#include <clock.h>


/* This is a test driver */
/* It implements some function to test other drivers and features of the kernel */


void		k_div_zero()
{
  int i = 2;
  int j = 0;
  printf("\nTesting division by zero exception\n");
  i = i / j;
}


int			k_timer_display()
{
  extern unsigned int	ticks;

  printf("Number of miliseconds since boot : %d\n", ticks);
  return 0;
}

/*
** Test the cursor
*/
void		k_test_cursor()
{
  cons_set_cursor_pos(1, 1);
}


static char*	days[] =
  {
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
  };

static char*	months[] =
  {
    "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug",
    "Sep", "Oct", "Nov", "Dec"
  };


static void	print_padded2(unsigned char c)
{
  if (c < 10)
    printf("0");
  printf("%d", c);
}

int			k_date_display()
{
  struct s_datetime	dt;

  clock_get(&dt);
  printf("%s %s ", days[(dt.dow) - 1], months[dt.month - 1]);
  print_padded2(dt.day);
  printf(" ");
  print_padded2(dt.hour);
  printf(":");
  print_padded2(dt.min);
  printf(":");
  print_padded2(dt.sec);
  printf(" ");
  if (dt.year >= 10)
    printf("20");
  else if (dt.year > 100)
    printf("2");
  else
    printf("200");
  printf("%d\n", dt.year);
  return 0;
}


void		showkey(_t_keyboard keyboard)
{
  if (keyboard._keycode == KEY_ESC)
    {
      tty_restore_handler();
    }
  printf("key ");
  printf("%x", keyboard._keycode);
  printf("%s\n", keyboard._key_up ? " released" : " pressed");
}
