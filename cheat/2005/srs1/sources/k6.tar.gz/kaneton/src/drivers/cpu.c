#include <stdio.h>
#include <string.h>
#include <cpu.h>

struct s_cpu	cpu;

int		cpu_init(void)
{
  char		*name;
  unsigned int	i;

  /* Get vendor string */
  __asm__ volatile ("cpuid" : "=b" (((int *)cpu.vendor)[0]),
                              "=c" (((int *)cpu.vendor)[2]),
                              "=d" (((int *)cpu.vendor)[1])
                            : "a" (0));
  cpu.vendor[12] = '\0';

  /* Get name string */
  for (i = 0; i < 3; ++i)
    __asm__ volatile ("cpuid" : "=a" (((int *)cpu.name)[4 * i]),
                                "=b" (((int *)cpu.name)[4 * i + 1]),
                                "=c" (((int *)cpu.name)[4 * i + 2]),
                                "=d" (((int *)cpu.name)[4 * i + 3])
                              : "0" (0x80000002 + i));
  cpu.name[48] = '\0';

  /* Remove padding */
  name = cpu.name;
  while (*name == ' ')
    ++name;
  strcpy(cpu.name, name);

  /* Check name is a valid string */
  for (i = 0; cpu.name[i]; ++i)
    if (cpu.name[i] < 9 || cpu.name[i] > 126)
    {
      strcpy(cpu.name, cpu.vendor);
      break;
    }
  if (!*cpu.name)
    strcpy(cpu.name, cpu.vendor);

  printf(" (%s)", cpu.name);
  return 0;
}

int	cpu_clean(void)
{
  return 0;
}
