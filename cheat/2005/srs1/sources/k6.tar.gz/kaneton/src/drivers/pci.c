#include <pci.h>
#include <pci_list.h>
#include <stdio.h>
#include <stdlib.h>
#include <set.h>
#include <io.h>
#include <unistd.h>

t_setid	 set_pci_;

int		lspci(int argc, char **argv)
{
  unsigned int	i = 0;

  (void) argc;
  (void) argv;
  set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof (t_pci_unit), 0, &set_pci_);
  for (i = 0; i < PCI_MAX_BUS; ++i)
    pci_scan_bus(i);
  return 0;
}

void	pci_show_unit_small(t_pci_unit *pci_unit)
{
  printf("vendor_id %x\n", pci_unit->vendor_id);
  printf("device_id %x\n", pci_unit->pci_id);
  printf("class code (base %x)(sub %x)(prog %x)\n", pci_unit->base_class, pci_unit->sub_class, pci_unit->prog_if);
}

void			pci_show_unit(t_pci_unit *pci_unit, int bus)
{
  unsigned int		i = 0;
  t_pci_vendor		*vendor = NULL;
  t_pci_device		*device = NULL;
  t_pci_class_code	*class_code = NULL;

  for (i = 0; i < PCI_NB_VENDOR; ++i)
    if (pci_vendors[i].vendor_id == pci_unit->vendor_id)
      {
	vendor = &pci_vendors[i];
	break;
      }
  for (i = 0; i < PCI_NB_DEVICE; ++i)
    if ((pci_devices[i].vendor_id == pci_unit->vendor_id) &&
	(pci_devices[i].device_id == pci_unit->pci_id))

      {
	device = &pci_devices[i];
	break;
      }
  for (i = 0; i < PCI_NB_CLASS_CODE; i++)
    if ((pci_class_codes[i].base_class == pci_unit->base_class) &&
	(pci_class_codes[i].sub_class == pci_unit->sub_class) &&
	(pci_class_codes[i].prog_if == pci_unit->prog_if))
      {
	class_code = &pci_class_codes[i];
	break;
      }
  printf("[%d:%x.%x]\t ", bus, class_code->base_class, class_code->sub_class);
  if (vendor != NULL)
    printf("%s ", vendor->vendor_shortname);
  else
    printf("[%x] ", pci_unit->vendor_id);
  if (device != NULL)
    printf("%s\n", device->chip_desc);
  else
    printf("[%x:%x]\n", pci_unit->vendor_id, pci_unit->pci_id);
}


static t_uint32		pci_read_bus(t_pci_conf_addr *pca)
{
  unsigned int		*out;

  out = (unsigned int *) pca;
  outl(*out, PCI_CONF_ADDR_PORT);
  return inl(PCI_CONF_DATA_PORT);
}

int			pci_scan_bus(unsigned int bus)
{
  int			j = 0;
  int			k = 0;
  int			l = 0;
  t_pci_conf_addr	pca;
  t_uint32		val;
  t_uint16		u_id;
  t_uint16		v_id;
  t_pci_unit		*tmp;

  for (j = 0; j < PCI_BUS_MAX_DEV; ++j)
    {
      memset((void *) &(pca), 0, sizeof (t_pci_conf_addr));
      pca.ecd = 1;
      pca.bus = bus;
      pca.unit = j;

      for (k = 0; k < PCI_MAX_FUN; ++k)
	{
	  pca.func = k;
	  pca.reg = PCI_CONF_REG_ID;
	  val = pci_read_bus(&pca);
	  u_id = (val & PCI_UNIT_MASK) >> 16;
	  v_id = (val & PCI_VENDOR_MASK);
	  if (u_id == PCI_NO_UNIT)
	    continue;
	  tmp = malloc(sizeof (t_pci_unit));
	  if (tmp == NULL)
	    return 1;
	  memset(tmp, 0, sizeof (t_pci_unit));
	  pca.reg = PCI_CONF_REG_CLASS;
	  val = pci_read_bus(&pca);
	  tmp->pci_id = u_id;
	  tmp->vendor_id = v_id;
	  tmp->base_class = (val & PCI_BCLASS_MASK) >> 24;
	  tmp->sub_class = (val & PCI_SCLASS_MASK) >> 16;
	  tmp->prog_if = (val & PCI_PROGIF_MASK) >> 8;
	  for (l = 0; l < PCI_MAX_ADDR; ++l)
	    {
	      pca.reg = PCI_CONF_REG_BADDR + l;
	      val = pci_read_bus(&pca);
	      if (val & 0x01)
		{
		  tmp->conf[l].type = PCI_IOPORT_ADDR;
		  tmp->conf[l].addr.ioaddr = val & ~0x1;
		}
	      else if (val == 0)
		tmp->conf[l].type = PCI_EMPTY;
	      else
		{
		  tmp->conf[k].type = PCI_MEMORY_ADDR;
		  tmp->conf[k].addr.memaddr = (void *) (val & ~0xF);
		}
	    }
	  pca.reg = PCI_CONF_REG_IRQ;
	  val = pci_read_bus(&pca);
	  tmp->irq = val & 0xFF;
	  set_insert(set_pci_, (void *)tmp);
	  pci_show_unit(tmp, bus);
	}
    }
  return 0;
}
