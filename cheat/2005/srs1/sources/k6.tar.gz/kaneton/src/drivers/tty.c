#include <keyboard.h>
#include <stdio.h>
#include <stdlib.h>
#include <console.h>
#include <tty.h>

t_tty ttys[NB_TTYS];
static int current_tty = 1;
/*
** This tool function tells if the keycode is printable or not
*/
static int		printable(unsigned char c)
{
  if (c == KEY_CAPSLOCK || c == KEY_LEFTSHIFT || c == KEY_RIGHTSHIFT
      || c == KEY_LEFTALT || c == KEY_RIGHTALT || c == KEY_RIGHTCTRL
      || c == KEY_LEFTCTRL || c == KEY_PAGEUP || c == KEY_PAGEDOWN
      || c == KEY_UP || c == KEY_DOWN || c == KEY_LEFT || c == KEY_RIGHT
      || (c >= KEY_F1 && c <= KEY_F10) || c == KEY_END || c == KEY_HOME
      || c == KEY_INSERT || c == KEY_DELETE || c == KEY_F11 || c == KEY_F12
      || c == KEY_ESC || c == KEY_NUMLOCK)
    return 0;
  return 1;
}

static void		tty_switch(int tty)
{
  tty_save(&(ttys[current_tty - 1]));
  current_tty = tty;
  tty_dump(&(ttys[tty - 1]));
}


/*
** Handles shift+pageup and shift+pagedown
*/
static void		tty_handle_shift(_t_keyboard* k, int maj)
{
  if (maj)
  {
    /* Console moving (Shift-Up and Shift-Down) */
      switch (k->_keycode)
      {
        case KEY_UP:
          if (k->_key_up)
	    cons_move_up(1);
        case KEY_KP8:
          return;
        case KEY_DOWN:
	  if (k->_key_up)
            cons_move_down(1);
        case KEY_KP2:
	  return;
        case KEY_PAGEDOWN:
	  if (k->_key_up)
            cons_move_down(10);
        case KEY_KP3:
	  return;
        case KEY_PAGEUP:
	  if (k->_key_up)
            cons_move_up(10);
        case KEY_KP9:
          return;
      }
  }

  if (k->_key_up)
    cons_move_bottom(); /* FIXME */
}

void		tty_handler(_t_keyboard k)
{
  extern _t_keyboard _keyboard;
  static int maj = 0;
  static int alt = 0;

  if (k._keycode == KEY_LEFTSHIFT || k._keycode == KEY_RIGHTSHIFT)
    {
      if (_keyboard._key_up)
	maj = 0;
      else
	maj = 1;
      return;
    }
  if (k._keycode == KEY_LEFTALT || k._keycode == KEY_RIGHTALT)
    {
      if (_keyboard._key_up)
	alt = 0;
      else
	alt = 1;
      return;
    }
  tty_handle_shift(&_keyboard, maj);

  /* ALT is pressed  : console switching*/
  if (alt)
    {
      switch (k._keycode)
	{
	case KEY_F1:
	  {
	    if (k._key_up)
	      tty_switch(1);
	    break;
	  }
	case KEY_F2:
	  {
	    if (k._key_up)
	      tty_switch(2);
	    break;
	  }
	case KEY_F3:
	  {
	    if (k._key_up)
	      tty_switch(3);
	    break;
	  }
	case KEY_F4:
	  {
	    if (k._key_up)
	      tty_switch(4);
	    break;
	  }
	case KEY_F5:
	  {
	    if (k._key_up)
	      tty_switch(5);
	    break;
	  }
	case KEY_F6:
	  {
	    if (k._key_up)
	      tty_switch(6);
	    break;
	  }

	}
    }
  /* Handling printable chars */
  if (k._keycode < 0x80)
    {
      if ((k._keycode >= 71) && (k._keycode <= 83))
	{
	  if (KBR_NUMLOCK)
	    _keyboard._character = _keyboard._keyboard_table[k._keycode * 2];
	  else
	    _keyboard._character = _keyboard._keyboard_table[k._keycode * 2 + 1];
	}
      else
	{
	  if ((!KBR_CAPSLOCK && !maj) || (KBR_CAPSLOCK && maj))
	    _keyboard._character = _keyboard._keyboard_table[k._keycode * 2];
	  else
	    _keyboard._character = _keyboard._keyboard_table[k._keycode * 2 + 1];
	}
      if (k._keycode == KEY_KPSLASH)
	_keyboard._character = '/';
      if (!_keyboard._key_up && printable(k._keycode))
	_keyboard.waiting_chars[_keyboard.waiting_chars_count++] = _keyboard._character;
    }
}

int		tty_init(void)
{
  char*		msg = "Welcome to Kaneton! tty";
  int i = 0;
  int j = 0;
  int k = 0;

  for (i = 1; i < 6; i++)
    {
      ttys[i].x = 0;
      ttys[i].cursorx = 0;
      ttys[i].y = 3;
      ttys[i].cursory = 3;
      for (j = 0; j < 4000; j += 2)
	{
	  ttys[i].screen[j] = 0;
	  ttys[i].screen[j + 1] = CONSOLE_DEFAULT_ATTR;
	}
      for (j = 0, k= 0; msg[k]; k++, j +=2)
	{
	  ttys[i].screen[j] = msg[k];
	  ttys[i].screen[j + 1] = CONSOLE_DEFAULT_ATTR;
	}
      ttys[i].screen[j] = (i + 1) + '0';
      ttys[i].screen[j + 1] = CONSOLE_DEFAULT_ATTR;
    }
  k_register_tty_handler(tty_handler);
  return 0;
}


void		tty_restore_handler(void)
{
  extern _t_keyboard _keyboard;

  current_tty = 1;
  _keyboard._tty_handler = _keyboard._old_tty_handler;
}
