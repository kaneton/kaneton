/*
** A clock driver : it is mentionned as a bonus in subject
** WARNING: in bochs, the time is going very fast 
*/

#include <clock.h>
#include <io.h>

/*
** converts BCD to binary
*/
static unsigned char	bcd2bin(unsigned char c)
{
  unsigned char res = 0;

  unsigned char c1 = (c & 0xF0) >> 4;
  res += 10 * c1;
  c1 = c & 0x0F;
  res += c1;
  return res;
}

int		clock_init(void)
{
  return 0;
}

/*
** For the moment, the clock is fetched each time from the BIOS memory
** Later, the system will fetch date at boot time and update it with a timer
** interrupt.
*/
int		clock_get(struct s_datetime* dt)
{
  /* seconds */
  outb(0, 0x70);
  dt->sec = bcd2bin(inb(0x71));
  /* minutes */
  outb(2, 0x70);
  dt->min = bcd2bin(inb(0x71));
  /* hours */
  outb(4, 0x70);
  dt->hour = bcd2bin(inb(0x71) & 0x7F);
  /* day of week */
  outb(6, 0x70);
  dt->dow = bcd2bin(inb(0x71));
  /* day of month */
  outb(7, 0x70);
  dt->day = bcd2bin(inb(0x71));
  /* month */
  outb(8, 0x70);
  dt->month = bcd2bin(inb(0x71));
  /* year */
  outb(9, 0x70);
  dt->year = bcd2bin(inb(0x71));
  return 0;
}
