#include <asm.h>
#include <console.h>
#include <io.h>
#include <stdio.h>
#include <tty.h>

static int cons_pos = 0;

/*
** extern variables
*/
extern unsigned char _keyboard_qwerty_table[];

/*
** static variables
*/
static _t_console _console;

char	videobuf[VIDEOBUF_SIZE];

static void	video_set(unsigned int i, unsigned char val)
{
  char *video = (void *) CONSOLE_VIDEO_ADDR;

  videobuf[i + 4000] = val;
  video[i] = val;
}

/*
** Sets the cursor pos in absolute coordinates.
*/
static int set_cursor(unsigned short pos)
{
  outb(VGA_SET_CURSOR_HIGH, VGA_COMMAND_PORT);
  outb(pos >> 8, VGA_DATA_PORT);
  outb(VGA_SET_CURSOR_LOW, VGA_COMMAND_PORT);
  outb(pos & 0xff, VGA_DATA_PORT);
  return 0;
}

/*
** Function to set up cursor position
*/
int	cons_set_cursor_pos(unsigned char x, unsigned char y)
{
  set_cursor(x +  COLUMNS * y);
  return 0;
}


/*
** Hide the cursor
*/
static int	cons_hide_cursor(void)
{
  /* CRT index port => ask for access to register 0xa ("cursor start") */
  outb(0x0a, CRT_REG_INDEX);

  /* (RBIL Tables 708 & 654) CRT Register 0xa => bit 5 = cursor OFF */
  outb(1 << 5, CRT_REG_DATA);
  return 0;
}

static int	cons_show_cursor(void)
{
  outb(0x0a, CRT_REG_INDEX);
  outb(0 << 5, CRT_REG_DATA);

  /* FIXME outb(CRT_REG_INDEX, 0x0b);
     outb(CRT_REG_DATA, 1 << 5);*/

  /*outb(CRT_REG_INDEX, 0x0b);
    outb(CRT_REG_DATA, 1 << 6);
    outb(CRT_REG_INDEX, 0x0b);
    outb(CRT_REG_DATA, 1 << 6);*/

  /*
    outb(0x45, VGA_SET_CURSOR_HIGH);
    outb(VGA_DATA_PORT, pos >> 8);
    outb(VGA_COMMAND_PORT, VGA_SET_CURSOR_LOW);
    outb(VGA_DATA_PORT, pos & 0xFF);*/
  return 0;
}

/*
 * Initialize Console: cursor, video memory, color attributs
 */
int		cons_init_console(void)
{
  unsigned int	i;

  _console._cursor = 0;
  _console._oldcursor = 0;
  _console._attr = CONSOLE_DEFAULT_ATTR;
  for (i = 0; i < 4000; i += 2)
    {
      videobuf[i] = 0;
      videobuf[i + 1] = _console._attr;
    }
  for (i = 0; i < CONSOLE_SIZE; i += 2)
    {
      video_set(i, 0);
      video_set(i + 1, _console._attr);
    }
  set_cursor(0);
  _console._oldcoord = 0;
  _console._coord = 0;
  return 0;
}


/*
 * Print a String to the Console Screen
 */
void		cons_print_string(const char *string)
{
  unsigned int	i;

  for (i = 0; string[i]; ++i)
    cons_print_char(string[i]);
}

/*
 *  Print a Number to the Console Screen
 */
void cons_print_num(int number)
{
  int i;

  i = number % 10;
  number = number / 10;
  if (number)
    cons_print_num(number);
  cons_print_char(i + 48);
}

/*
** To print an adress in exadecimal format
*/
void cons_print_addr_rec(unsigned int n)
{
  unsigned int i;

  i = n % 16;
  n = n / 16;
  if (n)
    cons_print_addr_rec(n);
  if (i <= 9)
    cons_print_char(i + '0');
  else
    cons_print_char(i + 'A' - 10);
}


/*
 * print an hexa value
 */
void cons_print_addr(unsigned int n)
{
  cons_print_string("0x");
  cons_print_addr_rec(n);
}

/*
 * print an hexa value on 8 digits
 */
void cons_print_addr8(unsigned int n)
{
  char	eight[9] = "00000000\0";
  unsigned int i = 0;
  unsigned int count = 7;

  if (n == 0)
    {
      printf("(null)");
      return;
    }
  printf("0x");
  while (n > 0)
    {
      i = n % 16;
      n = n / 16;
      if (i <= 9)
	eight[count] = i + '0';
      else
	eight[count] = i + 'A' - 10;
      count--;
    }
  printf("%s", eight);
}


/*
 * Print a Char to the Console Screen
 */
void cons_print_char(unsigned char c)
{
  if (!c)
    return;
  if (c == '\n') {
    _console._cursor += (CONSOLE_X * 2) - (_console._cursor % (CONSOLE_X * 2));
    _console._coord += CONSOLE_X - (_console._coord % CONSOLE_X);
  }
  else if (c == '\t')
    {
      while (_console._cursor % CONSOLE_TABULATION) {
	_console._cursor += 2;
	_console._coord++;
      }
      _console._cursor += 2;
      _console._coord++;
    }
  else if (c == 14)
    {
      if (_console._cursor % (CONSOLE_X * 2) > 0)
	{
	  _console._coord--;
	  _console._cursor -= 2;
	  video_set(_console._cursor, 0);
	  video_set(_console._cursor + 1, _console._attr);
	}
    }
  else
    {
      video_set(_console._cursor, c);
      video_set(_console._cursor + 1, _console._attr);
      _console._cursor += 2;
      _console._coord++;
    }
  if (_console._cursor >= CONSOLE_SIZE)
    cons_scroll();
  cons_cursor();
}

/*
** Console refresh
*/
static void	cons_refresh(void)
{
  char		*video = (void *) CONSOLE_VIDEO_ADDR;
  unsigned int	i;

  for (i = 0; i < CONSOLE_SIZE; ++i)
    video[i] = videobuf[VIDEOBUF_SIZE - CONSOLE_SIZE + i - 160 * cons_pos];
}

/*
** Console moving (Shift-Up)
*/
void	cons_move_up(int offset)
{
  if (cons_pos < 25)
    {
      if (cons_pos == 0)
	cons_hide_cursor();
      cons_pos += offset;
      cons_refresh();
    }
}

/*
** Console move down (Shift-Down)
*/
void	cons_move_down(int offset)
{
  if (cons_pos > 0)
    {
      cons_pos -= offset;
      cons_refresh();
      if (cons_pos == 0)
	cons_show_cursor();
    }
}

void	cons_move_bottom(void)
{
  if (cons_pos > 0)
    {
      cons_pos = 0;
      cons_refresh();
      cons_show_cursor();
    }
}

/*
** Scroll the window
*/
void		cons_scroll(void)
{
  unsigned int	i;
  char		*video = (void *) CONSOLE_VIDEO_ADDR;

  for (i = 0; i < VIDEOBUF_SIZE - CONSOLE_SIZE - 160; ++i)
    videobuf[i] = videobuf[i + 160];
  for (i = 0; i < 160; ++i)
    videobuf[4000 - 160 + i] = video[i];
  for (i = 0; i < CONSOLE_SIZE - 160; ++i)
    video_set(i, video[i + 160]);
  for (i = CONSOLE_SIZE - 160; i < CONSOLE_SIZE; i += 2)
    {
      video_set(i, 0);
      video_set(i + 1, _console._attr);
    }
  _console._cursor = CONSOLE_SIZE - 160;
  _console._coord = 2000 - 80;
}

void cons_panic(char *message)
{
  unsigned char attr = _console._attr;

  _console._attr = 0x0C;
  cons_print_string(message);
  _console._attr = attr;
}

/*
** Print A Succeed message
*/
void cons_succeed(char *message)
{
  unsigned char attr = _console._attr;

  _console._attr = 0x0A;
  cons_print_string(message);
  _console._attr = attr;
}

/*
** Print A Succeed message
*/
void cons_blue(char *message)
{
  unsigned char attr = _console._attr;

  _console._attr = 0x0B;
  cons_print_string(message);
  _console._attr = attr;
}



/*
** Print a yellow message
*/
void cons_skipped(char *message)
{
  unsigned char attr = _console._attr;

  _console._attr = 0x0E;
  cons_print_string(message);
  _console._attr = attr;
}

/*
** Print the init message
*/
void cons_init_msg(char *message, int out)
{
  int steps;

  if (message != NULL)
    printf(" * %s", message);
  steps = 70 - (_console._coord % CONSOLE_X);
  for (; steps > 0; steps--)
    cons_print_char(' ');
  printf("[");
  if (out != 0)
    cons_panic("  KO  ");
  else
    if (out == 7)
      cons_skipped(" SKIP ");
    else
      cons_succeed("  OK  ");
  printf("]\n");

}

/*
** Print a centered message
*/
void cons_print_center(char *message)
{
  int len = 0;

  while (message[len])
    len++;
  _console._cursor -= _console._cursor % 160;
  _console._cursor += 80;
  _console._cursor -= (len / 2) * 2;
  cons_print_string(message);
}

/*
** erase one char
*/
void k_erase_char()
{
  video_set(_console._cursor - 2, 0);
  _console._cursor -= 2;
}

/*
** Clear all the screen
*/
int	cons_clear()
{
  cons_init_console();
  return 0;
}

/*
** Set the console attribute
*/
void cons_attr(unsigned char flicker,
	       unsigned char fore,
	       unsigned char intensity,
	       unsigned char back)
{
  _console._attr = 0;
  _console._attr |= back & 0x7;
  _console._attr |= (intensity << 3) & 0x8;
  _console._attr |= (fore << 4) & 0x70;
  _console._attr |= (flicker << 7) & 0x80;
}

/*
**  Set the cursor to the _console._cursor place
*/
void cons_cursor(void)
{
  _console._oldcursor = _console._cursor;
  _console._oldcoord = _console._coord;
  set_cursor(_console._coord);
}

/*
** Dumps a tty to the video memory : when switching
*/
int	tty_dump(t_tty *tty)
{
  int	i = 0;

  cons_init_console();
  _console._cursor = tty->y * COLUMNS * 2 + tty->x;
  _console._coord = tty->cursorx + COLUMNS * tty->cursory;
  cons_cursor();
  for (i = 0; i < 4000; i++)
    video_set(i, tty->screen[i]);
  return 0;
}

/*
** A function that is used for the handling of ttys for now.
** Later, it will not be useful since program call tty write function instead of calling directly
** function in the console driver
*/
int		tty_save(t_tty* tty)
{
  char *video = (void *) CONSOLE_VIDEO_ADDR;
  int i = 0;

  tty->x = _console._cursor % (COLUMNS * 2);
  tty->y = _console._cursor / (COLUMNS * 2);
  tty->cursorx = _console._coord % COLUMNS;
  tty->cursory = _console._coord / COLUMNS;
  for (i = 0; i < 4000; i++)
    {
      tty->screen[i] = video[i];
    }
  return 0;
}
