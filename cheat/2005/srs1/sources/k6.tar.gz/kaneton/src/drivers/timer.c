/* Timer driver */

#include <pic.h>
#include <timer.h>
#include <io.h>
#include <int.h>
#include <stdio.h>
#include <scheduler.h>

/* A counter to make tests */
unsigned int ticks;


/* Allows to change timer frequency */
int	k_timer_set_freq(unsigned int freq)
{
  unsigned int nb_tick;

  /* Invalid freq value */
  if (freq <= 0)
    {
      printf("Timer frequency must be greater or equal to 0\n");
      return -1;
    }
  /* Compute counter value */
  nb_tick = I8254_MAX_FREQ / freq;
  /* Counter must be between 1 and 65536 */
  if (nb_tick > 65536)
    {
      printf("Timer Frequency to low\n");
      return -1;
    }
  if (nb_tick <= 0)
    return -1;
  /* The i8254 interprets 0 to mean counter == 65536, because 65536
     cannot be coded on 16bits */
  if (nb_tick == 65536)
    nb_tick = 0;

  /* We want to configure timer0, we want to send both LSB+MSB to set
     timer0 freq (-> 0x30), and we configure timer0 in mode 2, ie as a
     rate generator (-> 0x4) ==> 0x34 */
  outbp(0x34, I8254_CONTROL);

  /* Send LSB of counter first */
  outbp(nb_tick & 0xff, I8254_TIMER0);

  /* Send MSB of counter */
  outbp((nb_tick >> 8) & 0xff, I8254_TIMER0);
  return 0;
}

void	timer_handler()
{
  unsigned char lsb, msb;
  unsigned short value;

  ticks += 50;
  outbp(0, 775);                /* latch counter 0 */
  lsb = inb(772);                    /* read LSB of count value */
  msb = inb(772);                    /* read MSB of count value */
  value = lsb + 256 * msb;     /* the value latched in the counter */
  /*   k_printf("%d\n", value); */
  outb(0x20, 0x20);
  sched_sched();
}

/*
** Init the timer 
*/
int		k_timer_init()
{
  ticks = 0;
  k_irq_set_handler(0, _k_timer_handler);
  return k_timer_set_freq(20);
}
