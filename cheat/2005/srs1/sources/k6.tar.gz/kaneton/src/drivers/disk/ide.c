#include <stdio.h>
#include <unistd.h>
#include <io.h>
#include <ide.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

struct s_disk	disks[4];

/*
** Wait until the controller is ready
*/
static int		ide_wait_ready(unsigned long controller_addr)
{
  int			status;
  unsigned int		i;
  struct timespec	time = { .tv_sec = 0, .tv_nsec = 1000 };

  for (i = 0; i < 300000; ++i)
  {
    status = inb(controller_addr + IDE_STATUS);
    if (!(status & IDE_STATUS_BUSY))
      break;
    nanosleep(&time, NULL);
  }
  return status;
}

/*
** init the IDE controller
*/
/* chiche bande avale  */
static int		ide_controller_init(void)
{
  int			status;
  struct timespec	ts = { .tv_sec = 0, .tv_nsec = 1000 };
  unsigned int		controller; /* Current selected IDE controller */
  unsigned long int	controller_addr;
  unsigned long int	disk_id;
  unsigned int		disk; /* num of the disk on selected controller */
  unsigned int	i = 0;

  printf("\n");
  for (controller = 0; controller < NUM_CONTROLLER; ++controller)
    for (disk = 0; disk < NUM_DEVICES; ++disk, ++i)
    {
      printf("controller %d, disk %d:", controller, disk);
      controller_addr = controller ? IDE_CONTROLLER_SEC : IDE_CONTROLLER_PRIM;
      disk_id = IDE_DISK | disk * IDE_DISK_SLAVE;
      /* get status */
      outb(disk_id, controller_addr + IDE_DRIVE);
      nanosleep(&ts, NULL);
      status = inb(controller_addr + IDE_STATUS);
      if (status)
      {
        /* present */
        /* select the disk */
        outb(disk_id, controller_addr + IDE_DRIVE);
	nanosleep(&ts, NULL);
	/* send reset */
	outb(IDE_A_nIEN | IDE_RD_SRST, controller_addr + IDE_DEVICE_CONTROL);
	nanosleep(&ts, NULL);
	outb(IDE_A_nIEN, controller_addr + IDE_DEVICE_CONTROL);
	nanosleep(&ts, NULL);
	inb(controller_addr + IDE_ERROR);
	outb(IDE_A_4BIT, controller_addr + IDE_DEVICE_CONTROL);
	nanosleep(&ts, NULL);

	outb(disk_id, controller_addr + IDE_DRIVE);
	 nanosleep(&ts, NULL);

	ide_wait_ready(controller_addr);
        if (!(status & IDE_STATUS_BUSY))
	{
          disks[i].present = 1;
	  printf(" found");
	  ide_get_dev_info(controller_addr, disk_id, disks + disk);
	}
	else
	{
	  disks[i].present = 0;
	  printf(" not found\n");
	}
      }
      else
      {
        disks[i].present = 0;
	printf(" not found\n");
      }
    }
  return 0;
}

/*
 * IDE string to ASCII
 */
static void	ide_string_to_ascii(char *dst, char *src, unsigned int len)
{
  unsigned int	i;

  for (i = 0; i < len; i += 2)
  {
    dst[i] = src[i + 1];
    dst[i + 1] = src[i];
  }
  dst[i] = '\0';
  strtrim(dst);
}

/*
** get information about a device
** fills the s_disk struct
*/
void				ide_get_dev_info(unsigned long	controller_addr,
                                                 unsigned int	disk_id,
                                                 struct s_disk	*disk)
{
  unsigned int			i = 0;
  t_uint16			buf[256];
  struct s_ide_device_info	*infos;
  struct timespec		time = { .tv_sec = 0, .tv_nsec = 1000};

  outb(IDE_A_nIEN | IDE_A_4BIT, controller_addr + IDE_DEVICE_CONTROL);
  nanosleep(&time, NULL);
  outb(disk_id, controller_addr + IDE_DRIVE);
  outb(IDE_C_ATA_IDENTIFY, controller_addr + IDE_CMD);
  ide_wait_ready(controller_addr);
  for (i = 0; i < 256; ++i)
    buf[i] = inw(controller_addr);
  infos = (struct s_ide_device_info *)buf;
  disk->cylinders = infos->nb_logical_cylinders;
  disk->heads = infos->nb_logical_heads;
  disk->sectors = infos->nb_logical_sectors;
  disk->blocks = infos->lba_capacity;
  //printf("lba_capacity %d %d %d %d", infos->lba_capacity, infos->lba_capacity * 2, infos->lba_capacity * 512, infos->lba_capacity * 1024);
  ide_string_to_ascii(disk->model_name, (char*)infos->model_number, 40);
  printf(" %s (CHS %d/%d/%d)\n", disk->model_name, disk->cylinders, disk->heads, disk->sectors);
}

/*
** Called function for init (in the main)
*/
int	ide_init(void)
{
  int	status = 0;

  status += ide_controller_init();
  return (status != 0);
}

/*
** Called function for cleaning (reboot)
*/
int	ide_clean(void)
{
  return 0;
}

int			ide_rw(int		rw_operation,
                               unsigned int	block_addr,
                               t_uint16		*buf,
                               unsigned long	controller_addr,
                               unsigned int	disk_id)
{
  t_uint8		sect;
  t_uint8		cyl_lo;
  t_uint8		cyl_hi;
  t_uint8		head;
  struct timespec	time = { .tv_sec = 0, .tv_nsec = 1000 };
  unsigned int		i;

  sect = block_addr & 0xff;
  cyl_lo = (block_addr >> 8) & 0xff;
  cyl_hi = (block_addr >> 16) & 0xff;
  head = ((block_addr >> 24) & 0x7) | 0x40;

  outb(disk_id, controller_addr + IDE_DRIVE);
  nanosleep(&time, NULL);
  outb(IDE_A_nIEN | IDE_RD_SRST, controller_addr + IDE_DEVICE_CONTROL);
  nanosleep(&time, NULL);
  outb(IDE_A_nIEN, controller_addr + IDE_DEVICE_CONTROL);
  inb(controller_addr + IDE_ERROR);

  ide_wait_ready(controller_addr);

  /* write to registers */
  outb(IDE_A_nIEN | IDE_A_4BIT, controller_addr + IDE_DEVICE_CONTROL);
  outb(1, controller_addr + 1);
  outb(0, controller_addr + IDE_PRECOMP);
  outb(1, controller_addr + IDE_SECTOR_COUNT);
  outb(sect, controller_addr + IDE_SECTOR_NUMBER);
  outb(cyl_lo, controller_addr + IDE_CYL_LSB);
  outb(cyl_hi, controller_addr + IDE_CYL_MSB);
  outb(disk_id | head, controller_addr + IDE_DRIVE);

  nanosleep(&time, NULL);
  outb(rw_operation, controller_addr + IDE_CMD);

  ide_wait_ready(controller_addr);

  if (rw_operation == IDE_C_READ)
    for (i = 0; i < 256; ++i)
      buf[i] = inw(controller_addr);
  else
    for (i = 0; i < 256; ++i)
      outw(buf[i], controller_addr);
  return 0;
}

int		ide_read_block(unsigned int disk, unsigned int block_addr, unsigned int offset, void *buf, size_t count)
{
  unsigned int	controllers[] = { IDE_CONTROLLER_PRIM, IDE_CONTROLLER_SEC };
  t_uint16	buf16[256];
  t_uint8	buf8[512];

  if (!ide_rw(IDE_C_READ, block_addr, buf16, controllers[disk < 2 ? 0 : 1], IDE_DISK | disk * IDE_DISK_SLAVE))
  {
    ide_buf16_to_buf8(buf16, buf8, count);
    memcpy(buf, buf8 + offset, count);
    return 0;
  }
  return -1;
}

int		ide_read(unsigned int disk, unsigned int addr, void *buf, size_t count)
{
  unsigned int	read_tot = 0;
  unsigned int	read;
  t_uint8	buf8[512];

  while (read_tot < count)
  {
    ide_read_block(disk, (addr + read_tot) / 512, (addr + read_tot) % 512, buf8, 512);
    if (count - read_tot >= 512)
      read = 512;
    else
      read = count;
    memcpy(buf + read_tot, buf8, read);
    read_tot += read;
  }
  return 0;
}

int		ide_buf8_to_buf16(char *buf8, t_uint16 *buf16, unsigned int size)
{
  unsigned int	i;

  for (i = 0; i < size / 2; i += 2)
    buf16[i] = (buf8[i * 2] & 0xff) + (buf8[i * 2 + 1] << 8);
  return 0;
}

int		ide_write_block(unsigned int disk, unsigned int block_addr, unsigned int offset, void *buf, size_t count)
{
  unsigned int	controllers[] = { IDE_CONTROLLER_PRIM, IDE_CONTROLLER_SEC };
  t_uint16	buf16[512];

  ide_buf8_to_buf16(buf + offset, buf16, count);
  if (!ide_rw(IDE_C_WRITE, block_addr, buf, controllers[disk < 2 ? 0 : 1], IDE_DISK | disk * IDE_DISK_SLAVE))
    return 0;
  return -1;
}

int		ide_write(unsigned int disk, unsigned int addr, void *buf, size_t count)
{
  char		rbuf[512];

  ide_read_block(disk, addr / 512, 0, rbuf, 512);
  strncpy(rbuf + addr % 512, buf, count);
  ide_write_block(disk, addr / 512, 0, rbuf, 512);
  return 0;
}

int		ide_buf16_to_buf8(t_uint16 *buf16, char *buf8, unsigned int size)
{
  unsigned int	i;

  for (i = 0; i < size / 2; ++i)
  {
    buf8[i * 2] = buf16[i];
    if (i < size / 2 - 1)
      buf8[i * 2 + 1] = buf16[i] >> 8;
  }
  return 0;
}

int		ide_list(void)
{
  unsigned int	i;

  printf("Disk\tName\t\tSize (in bytes)\n");
  for (i = 0; disks[i].present && i < 4; ++i)
    printf("%d\t%s\t%d\n", i + 1, disks[i].model_name, disks[i].blocks * 512);
  return 0;
}
