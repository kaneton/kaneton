#include <keyboard.h>
#include <keyboard_conversion.h>
#include <stdio.h>
#include <io.h>
#include <int.h>
#include <pic.h>
#include <console.h>

/*
 * global variables
 */

volatile _t_keyboard _keyboard;

/*
 * extern variables
 */
extern unsigned char _keyboard_qwerty_table[];
extern unsigned char _keyboard_azerty_table[];
extern unsigned char _keyboard_num_table[];

/*
** Keyboard Handler
 */
void		k_keyboard_isr(void)
{
  unsigned char	cc;  /* the final keycode */
  unsigned char	c;

  _keyboard._key_up = 0;
  _keyboard._character = _keyboard._keycode = 0;
  c = inb(DATA_PORT);
  if(c == EXT_CODE_PREFIX || c == 0xF0 /* Hack for some keyboards */)
    {
      /* sometimes there are several extended scancode prefix */
      while ((c = inb(DATA_PORT)) == EXT_CODE_PREFIX || c == 0xF0);
      /* Test if key is released */
      if(IS_BREAKCODE(c)) {
        _keyboard._key_up = 1;
        c -= BREAKCODE_LIMIT;
      }
      if(c >= (sizeof(extended_scancode_to_keycode)/sizeof(unsigned char)))
        {
          printf("Unknown extended scancode : %x\n", c);
          return;
        }
      /* Conversion of extended scancode to key code */
      cc = extended_scancode_to_keycode[c];
    }
  else  /* if not an extended scancode */
    {
      if(IS_BREAKCODE(c)) {
        _keyboard._key_up = 1;
        c -= BREAKCODE_LIMIT;
      }
      /* we know that scancodes less then 58 are mapped to key codes */
      if(c < REGULAR_CODE_LIM)
	cc = c;
      else
        {
          c -= REGULAR_CODE_LIM;
          cc = regular_scancode_to_keycode[c];
        }
    }

  /* Check if the keycode is correct */
  if (cc == KEY_RESERVED)
    return;
  /* At this point cc is a valid keycode so we update keyboard structure */
  _keyboard._keycode = cc;
  if (!_keyboard._key_up)
    _keyboard._keys[cc] = 1;
  else
    _keyboard._keys[cc] = 0;

  /* Calling tty handler */
  if (_keyboard._tty_handler)
    _keyboard._tty_handler(_keyboard);

  if (cc == KEY_CAPSLOCK && _keyboard._key_up)
    {
      KBR_CAPSLOCK = !KBR_CAPSLOCK;
      return;
    }
  if (cc == KEY_NUMLOCK && _keyboard._key_up)
    {
      _keyboard._num_lock = !_keyboard._num_lock;
      return;
    }
}


/*
** Keyboard initialization
 */
int		k_init_keyboard(void)
{
  unsigned int	i;

  _keyboard._keyboard_table = _keyboard_qwerty_table;
  for (i = 0; i < KEYBOARD_BUFFER_SIZE; i++)
    _keyboard._buffer[i] = 0;
  _keyboard._keycode = 0;
  _keyboard._character = 0;
  _keyboard._caps_lock = 0;
  _keyboard._num_lock = 0;
  _keyboard._tty_handler = 0;
  _keyboard._old_tty_handler = 0;
  k_irq_set_handler(1, _k_irq_01);
  return 0;
}

/*
** Register a tty handler
*/
void	k_register_tty_handler(void (*h)())
{
  _keyboard._old_tty_handler = _keyboard._tty_handler;
  _keyboard._tty_handler = h;
}


/*
** Get A Printable Character
 */
void	k_get_char(char *c)
{
  while (!_keyboard.waiting_chars_count)
    ;
  *c = _keyboard.waiting_chars[--_keyboard.waiting_chars_count];
}

/*
** Get A Printable String
 */
unsigned int k_get_string(unsigned char *buffer, unsigned int len)
{

  /*
   * active loop while the current char is not a CR ('\n')
   */
  char c;

  k_get_char(&c);
  while ((_keyboard._character != '\n') && (len-- > 0))
    {
      *(buffer++) = c;
      k_get_char(&c);
    }
  *(buffer) = '\0';
  return 0;
}
