/*
** Interruption Descriptor table
** This part of the kernel is machine dependant
*/

#include <types.h>
#include <int.h>
#include <gdt.h>
#include <asm.h>
#include <io.h>
#include <stdio.h>


/*
** A table containing exceptions description
*/
static char*	_exceptions[] =
  {
    "Division by zero",
    "Debug interrupt (single step)",
    "NMI IIIInterrupt",
    "Breakpoint",
    "Interrupt on overflow",
    "Bound range exceeded",
    "Invalid Opcode",
    "Device not available",
    "Double fault",
    "",
    "Invalid TSS",
    "Segment not present",
    "Stack exception",
    "General protection fault",
    "Page fault",
    "",
    "Floating point exception",
    "Alignment check"
  };

/*
 * global variables
 */
_t_idt _idt[IDT_SIZE];
_t_idtr idtr;
unsigned int _pIdt = 0;

/*
 * Add An Entry To Interrupt Descriptor Table
 */
int	int_rsv(t_uint8		entry,
                void		*vaddr,
                unsigned short	segment,
                unsigned short	type)
{
  _idt[entry].__offset = ((unsigned int)vaddr) & 0xffff;
  _idt[entry]._segment = segment;
  _idt[entry]._type = type;
  _idt[entry]._offset = ((unsigned int)vaddr & 0xffff0000) >> 16;

  __asm__ volatile ("lidt %0" : : "m" (idtr));

  return 0;
}

/*
** Clears the IDT
*/
int			int_clear(void)
{
  unsigned short	i = 0;

  for (i = 0; i < IDT_SIZE; i++)
    int_rel(i);
  return 0;
}

/*
** Remove one IDT entry
*/
int	int_rel(t_uint8 entry)
{
  int_rsv(entry, 0, 0x08, IDT_INTGATE | IDT_32);
  return 0;
}

/*
 * Initiliaze And Load Interrupt Descriptor Table
 */
int		int_init(void)
{
  unsigned int	i;

  idtr._size = IDT_SIZE * 8;
  idtr._addr = (unsigned int) _idt;

  for (i = 0; i < IDT_SIZE; i++)
    int_rsv(i, _k_null_int, 0x08, IDT_INTGATE);

  int_rsv(_pIdt++, _k_int_00, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_01, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_02, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_03, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_04, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_05, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_06, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_07, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_08, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_09, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_10, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_11, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_12, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_13, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_14, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_15, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_16, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_17, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);
  int_rsv(_pIdt++, _k_int_18, 0x08, IDT_INTGATE | IDT_32 | IDT_PRESENT);

  int_rsv(_pIdt++, _k_irq_00, 0x08, IDT_INTGATE | IDT_32);
  int_rsv(_pIdt++, _k_irq_01, 0x08, IDT_INTGATE | IDT_32);
  int_rsv(_pIdt++, _k_irq_02, 0x08, IDT_INTGATE | IDT_32);
  int_rsv(_pIdt++, _k_irq_03, 0x08, IDT_INTGATE | IDT_32);
  int_rsv(_pIdt++, _k_irq_04, 0x08, IDT_INTGATE | IDT_32);
  int_rsv(_pIdt++, _k_irq_05, 0x08, IDT_INTGATE | IDT_32);
  int_rsv(_pIdt++, _k_irq_06, 0x08, IDT_INTGATE | IDT_32);
  int_rsv(_pIdt++, _k_irq_07, 0x08, IDT_INTGATE | IDT_32);
  int_rsv(_pIdt++, _k_irq_08, 0x08, IDT_INTGATE | IDT_32);

  __asm__ volatile ("lidtl %0" :: "m" (idtr));
  return 0;
}

void	k_exception_handler(unsigned int num)
{
  printf("\nProcessor Exception %d!\n", num);
  printf("%s. System halted.\n", _exceptions[num]);
  while(1)
    ;
}
