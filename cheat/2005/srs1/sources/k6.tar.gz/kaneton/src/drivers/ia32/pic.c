/*
** IRQs and PIC handling 
*/

#include <asm.h>
#include <io.h>
#include <pic.h>
#include <int.h>
#include <console.h>


/*
 * Initialize Programmable Interrupt Controller
 */
int	pic_init(void)
{
  outbp(0x11, 0x20);
  outbp(0x20, 0x21);
  outbp(0x04, 0x21);
  outbp(0x01, 0x21);
  outbp(0xff, 0x21);
  outbp(0x11, 0xa0);
  outbp(0x70, 0xa1);
  outbp(0x02, 0xa1);
  outbp(0x01, 0xa1);
  outbp(0xff, 0xa1);
  outbp(0xfd, 0x21);
  return 0;
}

/*
 * Disable An IRQ
 */
int pic_disable(unsigned char irq)
{
  if (irq < 8)
    /*  irq on master PIC */
    outb(0x21, (inb(0x21) | (1 << irq)));
  else
    /*  irq on slave PIC */
    outb(0xa1, (inb(0xa1) | (1 << (irq-8))));
  return 0;
}


/*
 * Enable An IRQ
 */
int pic_enable(unsigned char irq)
{
  if (irq < 8)
    /*  irq on master PIC */
    outb(0x21, (inb(0x21) & ~(1 << irq)));
  else
    /*  irq on slave PIC */
    outb(0xa1, (inb(0xa1) & ~(1 << (irq - 8))));
  return 0;
}

int		k_irq_set_handler(unsigned char numirq, void* handler)
{
  CLI;
  if (!handler)
    return -1;
  int_rsv(IRQ_BASE + numirq, handler, 0x08, IDT_INTGATE | IDT_PRESENT | IDT_32);
  pic_enable(numirq);
  STI;
  return 0;
}

int		pic_clear(void)
{
  unsigned int	i;

  for (i = 0; i < IRQ_NUM; i++)
    pic_disable(i);
  return 0;
}
