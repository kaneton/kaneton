
extern int errno;

int kaneton(int c)
{
  return c - 1;
}


int main(int argc, char **argv)
{
  int	c  = 10;

  while ((c = kaneton(c - 1)))
    ;
  errno = argc;
  return 7;
}
