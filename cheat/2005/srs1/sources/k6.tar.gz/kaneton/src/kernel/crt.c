#include <stdio.h>
#include <crt.h>

extern int main(int, char **, char **);


char	**environ = {NULL};
int	  errno;

int	_kinit(t_env **mother_env)
{
  // FIXME : Get the t_env structure from the mother task
  errno = 0;
  // FIXME : Init environ (get it from the mother task)

  return 0;
}



int	_kstart(int argc, char **args)
{
  int	res = 0;
  t_env	*mother_env;

  _kinit(&mother_env);

  // Call the user code...
  res = main(argc, args, environ);

  mother_env->exit = res;
  mother_env->errno = errno;

  return res;
}
