#include <as.h>
#include <pm.h>
#include <vm.h>
#include <paging.h>
#include <multiboot.h>
#include <gdt.h>
#include <int.h>
#include <keyboard.h>
#include <userland.h>
#include <pic.h>
#include <timer.h>
#include <clock.h>
#include <modules.h>
#include <stdio.h>
#include <version.h>
#include <cpu.h>
#include <set.h>
#include <ipc.h>
#include <malloc.h>
#include <tty.h>
#include <scheduler.h>
#include <thread.h>
#include <ide.h>
#include <vfs.h>
#include <part.h>

multiboot_info_t	*_mbi;

void	launch(char *msg, int (*fun)(void))
{

  printf(" * %s", msg);
  if (fun != NULL)
    cons_init_msg(NULL, (*fun)());
  else
    cons_init_msg(NULL, 7);
}

void		_start(void)
{
  module_t	*pmod;
  char		startmsg[80];

  __asm__ volatile ("movl %%ebx, %0" :"=g"(_mbi) : : "ebx");
  pmod = ((module_t*)_mbi->mods_addr);

  cons_init_console();

  cons_print_center(" -----------------------------------------\n");
  strcpy(startmsg, "<       Starting Kaneton ");
  strcat(startmsg, version());
  strcat(startmsg, "      >\n");
  cons_print_center(startmsg);
  cons_print_center(" --------_________________________--------\n");
  cons_print_string("\n\n");

  cons_init_msg("Loading console driver", 0);
  launch("Loading GDT", k_init_gdt);
  launch("Loading IDT", int_init);
  launch("Loading PIC", pic_init);
  launch("Initializing keyboard", k_init_keyboard);
  launch("Initializing timer", k_timer_init);
  launch("Initializing clock", clock_init);
  launch("Initializing PM management", pm_init);
  launch("Initializing AS management", as_init);
  launch("Initializing VM management", vm_init);

  // HACK
  init_malloc();

  launch("Initializing Sets", set_init);
  launch("Initializing IPC", ipc_init);
  cons_init_msg("Initializing Modules", mod_init((t_paddr)_mbi));
  launch("Initializing CPU management", cpu_init);
  launch("Initializing tty driver", tty_init);
  launch("Initializing thread management", thread_init);
  launch("Starting scheduler", sched_init_default);
  launch("Detecting IDE devices", ide_init);
  launch("Detecting partitions", part_init);
  launch("Initializing VFS", vfs_init);
  launch("Mounting root partition", vfs_mount_init);

  // add init modules before this comment line
  cons_init_msg("Starting init", 0);

  while (1)
  {
    printf("\nKaneton %s\n\n", version());
    userland_sh(0, NULL);
  }
}
