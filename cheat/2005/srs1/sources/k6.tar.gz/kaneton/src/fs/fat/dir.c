#include <ide.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <ctype.h>
#include <vfs.h>
#include <string.h>
#include <fcntl.h>
#include <fat.h>

static char	*fat_dos_to_posix_name(char *dos_name, char *dos_ext, char *posix_name)
{
  unsigned int	i = 0;
  unsigned int	j;

  for (j = 0; j < 8 && dos_name[j] != ' '; ++j)
    posix_name[i++] = tolower(dos_name[j]);
  if (dos_ext[0] != ' ')
    posix_name[i++] = '.';
  for (j = 0; j < 3 && dos_ext[j] != ' '; ++j)
    posix_name[i++] = tolower(dos_ext[j]);
  posix_name[i] = '\0';
  return posix_name;
}

int		fat_posix_to_dos_name(const char *posix_name, char *dos_name, char *dos_ext)
{
  unsigned int	i;
  unsigned int	j;

  strcpy(dos_ext, "   ");
  for (i = 0; posix_name[i] && posix_name[i] != '.'; ++i)
    dos_name[i] = toupper(posix_name[i]);
  for (j = i; j < 8; ++j)
    dos_name[j] = ' ';
  for (j = 0, ++i; posix_name[i]; ++i, ++j)
   dos_ext[j] = toupper(posix_name[i]);
  for (; j < 3; ++j)
    dos_ext[j] = ' ';
  return 0;
}

static struct s_fat_dir	*fat_lookupdir(struct s_fat_dir *fat_dir, const char *name, int flags)
{
  struct s_fat_dirent	fat_dirent;
  char			d_name[13];
  unsigned int		i = 0;

  while (1)
  {
    ide_read(fat_dir->disk, fat_dir->start_sector * 512 + ++i * sizeof (struct s_fat_dirent), &fat_dirent,
      sizeof (struct s_fat_dirent));
    if (fat_dirent.attr == FAT_ATTR_LONG_NAME)
      continue;
    if (!fat_dirent.name[0])
    {
      if ((flags & O_CREAT) == O_CREAT || (flags & O_CREAT_DIR) == O_CREAT_DIR)
      {
	if ((flags & O_CREAT_DIR) == O_CREAT_DIR)
          fat_dirent.attr = FAT_ATTR_DIRECTORY;
        fat_posix_to_dos_name(name, fat_dirent.name, fat_dirent.ext);
	fat_dirent.file_size = 0;
	fat_dir->size = fat_dirent.file_size;
        ide_write(fat_dir->disk, fat_dir->start_sector * 512 +
          i * sizeof (struct s_fat_dirent), &fat_dirent, sizeof (struct s_fat_dirent));
	return fat_dir;
      }
      return NULL;
    }
    if (fat_dirent.name[0] != 0xe5 &&
          !strcmp(name, fat_dos_to_posix_name(fat_dirent.name, fat_dirent.ext, d_name)))
    {
      if ((flags & O_UNLINK) == O_UNLINK)
      {
	fat_dirent.name[0] = 0xe5;
        ide_write(fat_dir->disk, fat_dir->start_sector * 512 +
          i * sizeof (struct s_fat_dirent), &fat_dirent, sizeof (struct s_fat_dirent));
        return fat_dir;
      }
      fat_dir->start_sector = fat_cluster_to_sector(fat_dir->disk, fat_dir->part,
        (fat_dirent.fst_clus_hi << 16) + fat_dirent.fst_clus_lo);
      fat_dir->size = fat_dirent.file_size;
      return fat_dir;
    }
  }
  return NULL;
}

struct s_dir		*fat_opendir(struct s_dir *dir, const char *name, int flags)
{
  extern struct s_disk	disks[];
  struct s_fat_dir	*fat_dir;
  char			int_dir[MAXPATHLEN];
  unsigned int		i;

  fat_dir = malloc(sizeof (struct s_fat_dir));
  fat_dir->start_sector = fat_cluster_to_sector(dir->disk, dir->part, FAT_FS(dir->disk, dir->part).bs.root_clus);
  fat_dir->size = 0;
  ++name;
  while (*name)
  {
    for (i = 0; name[i] && name[i] != '/'; ++i)
      int_dir[i] = name[i];
    int_dir[i] = '\0';
    if (!(fat_dir = fat_lookupdir(fat_dir, int_dir, flags)))
      return NULL;
    name += i;
    if (!*name)
      break;
    else
      ++name;
  }
  fat_dir->current_pos = 0;
  dir->fs_dir = fat_dir;
  return dir;
}

struct dirent		*fat_readdir(struct s_dir *dir)
{
  struct s_fat_dirent	fat_dirent;
  struct dirent		*dirent;

  while (1)
  {
    ide_read(FAT_DIR(dir).disk, FAT_DIR(dir).start_sector * 512 +
      FAT_DIR(dir).current_pos++ * sizeof (struct s_fat_dirent), &fat_dirent,
      sizeof (struct s_fat_dirent));
    if (fat_dirent.attr == FAT_ATTR_LONG_NAME)
      continue;
    if (!fat_dirent.name[0])
      return NULL;
    if (fat_dirent.name[0] != 0xe5)
    {
      dirent = malloc(sizeof(struct dirent));
      fat_dos_to_posix_name(fat_dirent.name, fat_dirent.ext, dirent->d_name);
      dirent->attr = fat_dirent.attr;
      dirent->file_size = fat_dirent.file_size;
      dirent->wrt_time = fat_dirent.wrt_time;
      dirent->wrt_date = fat_dirent.wrt_date;
      return dirent;
    }
  }
  return NULL;
}

int	fat_closedir(struct s_dir *dir)
{
  free(&FAT_DIR(dir));
  return 0;
}
