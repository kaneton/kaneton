#include <fat.h>
#include <ide.h>
#include <part.h>

struct s_part_type part_types[] =
 { {  0x1, "FAT12",		FAT_FUNCTIONS },
   {  0x4, "FAT16 (< 32 MB)",	FAT_FUNCTIONS },
   {  0x6, "FAT16",		FAT_FUNCTIONS },
   {  0x7, "NTFS",		FAT_FUNCTIONS },
   {  0xb, "FAT32",		FAT_FUNCTIONS },
   {  0xc, "FAT32 (LBA)",	FAT_FUNCTIONS },
   {  0xe, "FAT16 (LBA)",	FAT_FUNCTIONS },
   {  0xf, "Extended",		NULL_FUNCTIONS },
   { 0x63, "Hurd",		NULL_FUNCTIONS },
   { 0x82, "Linux swap",	NULL_FUNCTIONS },
   { 0x83, "Linux",		NULL_FUNCTIONS },
   { 0xa5, "FreeBSD",		NULL_FUNCTIONS },
   { 0xa6, "OpenBSD",		NULL_FUNCTIONS },
   { 0xa9, "NetBSD",		NULL_FUNCTIONS },
   {  0x0, NULL,                NULL_FUNCTIONS }
};

extern struct s_disk	disks[4];

static char	*part_id_to_descr(unsigned char id)
{
  unsigned int	i;

  for (i = 0; i < sizeof(part_types) / sizeof(struct s_part_type); ++i)
    if (id == part_types[i].id)
      return part_types[i].descr;
  return "Unknown";
}


int		part_init(void)
{
  unsigned int	controller = 0;
  unsigned int	disk = 0;
  unsigned int	i;

  for (controller = 0; controller < NUM_CONTROLLER; ++controller)
    for (disk = 0; disk < NUM_DEVICES; ++disk)
    {
      if (!disks[controller * 2 + disk].present)
        continue;
      for (i = 0; i < 4; ++i)
        ide_read(controller * 2 + disk, 446 + i * sizeof (struct s_mbr_entry), &disks[controller * 2 + disk].parts[i].mbr_entry, sizeof (struct s_mbr_entry));
    }
  return 0;
}

int			part_list(void)
{
  extern struct s_disk	disks[];
  unsigned int		i;
  unsigned int		j;
  char			c = 'a';

  for (i = 0; i < 4; ++i, c++)
    if (disks[i].present)
    {
      printf("\nDisk %d:\n", i);
      printf("Device    Boot    Start       End      Blocks   Id  System\n");
      for (j = 0; j < 4; ++j)
        if (disks[i].parts[j].mbr_entry.id)
          printf("%c%d\t\t\t%c\t\t%d\t\t%d\t%d\t%x\t%s\n", c, j + 1,
                 disks[i].parts[j].mbr_entry.bootable ? '*' : ' ', disks[i].parts[j].mbr_entry.starting_sector,
                 disks[i].parts[j].mbr_entry.starting_sector + disks[i].parts[j].mbr_entry.nr_of_sectors,
                 disks[i].parts[j].mbr_entry.nr_of_sectors, disks[i].parts[j].mbr_entry.id,
                 part_id_to_descr(disks[i].parts[j].mbr_entry.id));
    }
  return 0;
}
