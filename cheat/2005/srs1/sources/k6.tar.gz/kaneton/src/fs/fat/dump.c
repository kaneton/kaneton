#include <ctype.h>
#include <fat.h>

int		fat_bs_dump(struct s_fat_bs *bs)
{
  unsigned int	i;

  printf("jmp_boot: %x %x %x\n", bs->jmp_boot0, bs->jmp_boot1, bs->jmp_boot2);
  printf("oem_name: ");
  for (i = 0; i < 8; ++i)
    printf("%c", bs->oem_name[i]);
  printf("\n");
  printf("byts_per_sec: %d\n", bs->byts_per_sec);
  printf("sec_per_clus: %d\n", bs->sec_per_clus);
  printf("rsvd_sec_cnt: %d\n", bs->rsvd_sec_cnt);
  printf("num_fats: %d\n", bs->num_fats);
  printf("root_ent_cnt: %d\n", bs->root_ent_cnt);
  printf("tot_sec16: %d\n", bs->tot_sec16);
  printf("media: %x\n", bs->media);
  printf("fat_sz16: %d\n", bs->fat_sz16);
  printf("sec_per_trk: %d\n", bs->sec_per_trk);
  printf("num_heads: %d\n", bs->num_heads);
  printf("hidd_sec: %d\n", bs->hidd_sec);
  printf("tot_sec32: %d\n", bs->tot_sec32);
  printf("fat_sz32: %d\n", bs->fat_sz32);
  printf("ext_flags: %x\n", bs->ext_flags);
  printf("fs_ver: %d\n", bs->fs_ver);
  printf("root_clus: %d\n", bs->root_clus);
  printf("fs_info: %d\n", bs->fs_info);
  printf("bk_boot_sec: %d\n", bs->bk_boot_sec);
  printf("drv_num: %x\n", bs->drv_num);
  printf("boot_sig: %x\n", bs->boot_sig);
  printf("vol_id: %x\n", bs->vol_id);
  printf("vol_lab: ");
  for (i = 0; i < 11; ++i)
    printf("%c", bs->vol_lab[i]);
  printf("\n");
  printf("fil_sys_type: ");
  for (i = 0; i < 8; ++i)
    printf("%c", bs->fil_sys_type[i]);
  printf("\n");
  return 0;
}

int		fat_dirent_dump(struct s_fat_dirent *dirent)
{
  unsigned int	i;

  printf("-------------------------\n");
  printf("name[0]: %x\n", dirent->name[0]);
  printf("name: ");
  for (i = 0; i < 8; ++i)  
    printf("%c", tolower(dirent->name[i]));
  printf(".");
  for (i = 0; i < 3; ++i)
    printf("%c", tolower(dirent->ext[i]));
  printf("\n");
  printf("attr: %x\n", dirent->attr);
  printf("nt_res: %x\n", dirent->nt_res);
  printf("crt_time_tenth: %d\n", dirent->crt_time_tenth);
  printf("crt_date: %d\n", dirent->crt_date);
  printf("lst_acc_date: %d\n", dirent->lst_acc_date);
  printf("fst_clus: %d\n", (dirent->fst_clus_hi << 16) + dirent->fst_clus_lo);
  printf("wrt_time: %d:%d:%d\n", (dirent->wrt_time & 0xfe00) >> 11,
    (dirent->wrt_time & 0x7e0) >> 5, (dirent->wrt_time & 0x1f) * 2);
  printf("wrt_date: %d-%d-%d\n", ((dirent->wrt_date & 0xfe00) >> 9) + 1980,
    (dirent->wrt_date & 0x01e0) >> 5, dirent->wrt_date & 0x1f);
  printf("file_size: %d\n", dirent->file_size);
  return 0;
}

int		fat_dirent_list(struct s_fat_dirent *dirent)
{
  unsigned int	i;

  for (i = 0; i < 8; ++i)
  {
    if (dirent->name[i] == ' ')
      break;
    printf("%c", tolower(dirent->name[i]));
  }
  if (dirent->ext[0] != ' ')
    printf(".");
  for (i = 0; i < 3; ++i)
    printf("%c", tolower(dirent->ext[i]));
  printf(" ");
  printf("%x ", dirent->attr);
  printf(" %d ", (dirent->fst_clus_hi << 16) + dirent->fst_clus_lo);
  printf(" %d-%d-%d", ((dirent->wrt_date & 0xfe00) >> 9) + 1980,
    (dirent->wrt_date & 0x01e0) >> 5, dirent->wrt_date & 0x1f);
  printf(" %d:%d:%d ", (dirent->wrt_time & 0xfe00) >> 11,
    (dirent->wrt_time & 0x7e0) >> 5, (dirent->wrt_time & 0x1f) * 2);
  printf(" %d\n", dirent->file_size);
  return 0;
}
