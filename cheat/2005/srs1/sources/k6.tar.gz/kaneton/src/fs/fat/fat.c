#include <ide.h>
#include <stdio.h>
#include <stdlib.h>
#include <vfs.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <fat.h>

extern struct s_disk	disks[];

int	fat_cluster_to_sector(unsigned int disk, unsigned int part, unsigned int cluster)
{
  return ((cluster - 2) * FAT_FS(disk, part).bs.sec_per_clus) +
    FAT_FS(disk, part).first_data_sector;
}

int	fat_mount(unsigned int source_disk, unsigned int source_part, const char *target)
{
  disks[source_disk].parts[source_part].fs = malloc(sizeof (struct s_fat_fs));
  ide_read(source_disk,
    disks[source_disk].parts[source_part].mbr_entry.starting_sector * 512,
    &FAT_FS(source_disk, source_part).bs, sizeof (struct s_fat_bs));
  printf(" (FAT32, block size %d) ",  FAT_FS(source_disk, source_part).bs.byts_per_sec);
  FAT_FS(source_disk, source_part).first_data_sector =
    disks[source_disk].parts[source_part].mbr_entry.starting_sector +
    FAT_FS(source_disk, source_part).bs.rsvd_sec_cnt +
    FAT_FS(source_disk, source_part).bs.num_fats * FAT_FS(source_disk, source_part).bs.fat_sz32;
  return 0;
}

/*
** FAT-specific open.
*/
int			fat_open(unsigned int disk, unsigned int part, const char *pathname, int flags)
{
  struct s_file		*file;
  struct s_dir		*dir;

  if ((dir = opendir_flags(pathname, flags)))
  {
    file = vfs_file_new(disk, part);
    file->fs_file = dir;
    return file->fd;
  }
  return -1;
}

ssize_t		fat_read(struct s_file *file, void *buf, size_t count)
{
  unsigned int	real_count;

  real_count = MIN(count, FAT_FILE(file).size - FAT_FILE(file).current_pos);
  if (real_count > 0)
  {
    ide_read(file->disk, FAT_FILE(file).start_sector * 512 +
      FAT_FILE(file).current_pos, buf, real_count);
    FAT_FILE(file).current_pos += real_count;
  }
  return real_count;
}

int	fat_close(struct s_file	*file)
{
  closedir(file->fs_file);
  return 0;
}

int		fat_unlink(unsigned int disk, unsigned int part, const char *pathname)
{
  struct s_dir	*dir;

  if ((dir = opendir_flags(pathname, O_UNLINK)))
    return 0;
  return -1;
}
