#include <sys/mount.h>
#include <set.h>
#include <fcntl.h>
#include <string.h>
#include <ide.h>
#include <vfs.h>
#include <part.h>
#include <dirent.h>
#include <fat.h>

extern t_setid	mountpoints;
extern struct s_disk	disks[];
extern struct s_part_type	part_types[];
static t_setid	files;
static int	nextfd = 3;
char	pwd[MAXPATHLEN];

int			vfs_init(void)
{
  strcpy(pwd, "/");
  set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof (struct s_mountpoint), 0,
    &mountpoints);
  set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof (struct s_file), 0, &files);
  return 0;
}

int	vfs_mount_init(void)
{
  mount(0, 0, "/");
  return 0;
}

int			vfs_list(void)
{
  struct s_mountpoint	*mountpoint;
  t_iterator		i;

  SET_FOREACH(FOREACH_FORWARD, mountpoints, &i)
  {
    mountpoint = i.addr;
    printf("%c%d on %s type %x\n", mountpoint->disk + 'a', mountpoint->part + 1,
      mountpoint->name, disks[mountpoint->disk].parts[mountpoint->part].mbr_entry.id);
  }
  return 0;
}

struct s_file	*vfs_file_new(unsigned int disk, unsigned int part)
{
  struct s_file	*file;

  file = malloc(sizeof(struct s_file));
  file->disk = disk;
  file->part = part;
  file->fd = nextfd++;
  set_insert(files, file);
  return file;
}

/*
** Handle other fileystems IDs.
*/
int				open(const char *pathname, int flags)
{
  struct s_mountpoint		*mountpoint;
  t_iterator			i;
  unsigned int			j;
  char				full_path[MAXPATHLEN];

  if (pathname[0] != '/')
  {
    strcpy(full_path, pwd);
    if (full_path[1])
      strcat(full_path, "/");
    strcat(full_path, pathname);
  }
  else
    strcpy(full_path, pathname);
  SET_FOREACH(FOREACH_FORWARD, mountpoints, &i)
  {
    mountpoint = i.addr;
    if (!strncmp(mountpoint->name, full_path, strlen(mountpoint->name)))
    {
      for (j = 0; part_types[j].id; ++j)
        if (disks[mountpoint->disk].parts[mountpoint->part].mbr_entry.id == part_types[j].id)
        {
          if (!part_types[j].open)
            return -1;
          return part_types[j].open(mountpoint->disk, mountpoint->part, full_path, flags);
        }
      break;
    }
  }
  return -1;
}

ssize_t		read(int fd, void *buf, size_t count)
{
  t_iterator	i;
  struct s_file	*file;
  unsigned int	j;

  SET_FOREACH(FOREACH_FORWARD, files, &i)
  {
    file = i.addr;
    if (file->fd == fd)
    {
      for (j = 0; part_types[j].id; ++j)
        if (disks[file->disk].parts[file->part].mbr_entry.id == part_types[j].id)
	{
           if (!part_types[j].read)
             return -1;
	   return part_types[j].read(file, buf, count);
	}
      break;
    }
  }
  return -1;
}

int		close(int fd)
{
  t_iterator	i;
  struct s_file	*file;
  unsigned int	j;

  SET_FOREACH(FOREACH_FORWARD, files, &i)
  {
    file = i.addr;
    if (file->fd == fd)
    {
      for (j = 0; part_types[j].id; ++j)
        if (disks[file->disk].parts[file->part].mbr_entry.id == part_types[j].id)
	{
          if (!part_types[j].close)
            return -1;
          set_delete(files, i.id);
          --nextfd;
	  return part_types[j].close(file);
        }
      return 0;
    }
  }
  return -1;
}

int	unlink(const char *pathname)
{
  struct s_mountpoint		*mountpoint;
  t_iterator			i;
  unsigned int			j;
  char				full_path[MAXPATHLEN];

  if (pathname[0] != '/')
  {
    strcpy(full_path, pwd);
    if (full_path[1])
      strcat(full_path, "/");
    strcat(full_path, pathname);
  }
  else
    strcpy(full_path, pathname);
  SET_FOREACH(FOREACH_FORWARD, mountpoints, &i)
  {
    mountpoint = i.addr;
    if (!strncmp(mountpoint->name, full_path, strlen(mountpoint->name)))
    {
      for (j = 0; part_types[j].id; ++j)
        if (disks[mountpoint->disk].parts[mountpoint->part].mbr_entry.id == part_types[j].id)
        {
          if (!part_types[j].unlink)
            return -1;
          return part_types[j].unlink(mountpoint->disk, mountpoint->part, full_path);
        }
      break;
    }
  }
  return -1;
}
