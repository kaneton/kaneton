#include <ide.h>
#include <part.h>
#include <string.h>
#include <set.h>
#include <dirent.h>
#include <string.h>
#include <fcntl.h>
#include <vfs.h>

extern struct s_disk	disks[];
extern struct s_part_type	part_types[];
extern char	pwd[];

char	*getcwd(char *buf, size_t size)
{
  strncpy(buf, pwd, size);
  return buf;
}

int		chdir(const char *path)
{
  int		i;
  char		new_pwd[MAXPATHLEN];
  struct s_dir	*dir;

  strcpy(new_pwd, pwd);
  if (!strcmp(path, ".."))
  {
    for (i = strlen(new_pwd) - 1; new_pwd[i] != '/'; --i)
      ;
    new_pwd[i ? i : 1] = '\0'; 
  }
  else
  {
    if (path[0] == '/')
      strcpy(new_pwd, path);
    else
    {
      if (new_pwd[strlen(new_pwd) - 1] != '/')
        strcat(new_pwd, "/");
      strcat(new_pwd, path);
    }
  }
  if ((dir = opendir(new_pwd)))
  {
    closedir(dir);
    strcpy(pwd, new_pwd);
    return 0;
  }
  return -1;
}

struct s_dir		*opendir_flags(const char *name, int flags)
{
  extern t_setid	mountpoints;
  struct s_mountpoint	*mountpoint;
  t_iterator		i;
  unsigned int		j;
  struct s_dir		*dir;
  extern char		pwd[];

  if (!strcmp(name, "."))
    name = pwd;
  SET_FOREACH(FOREACH_FORWARD, mountpoints, &i)
  {
    mountpoint = i.addr;
    if (!strncmp(mountpoint->name, name, strlen(mountpoint->name)))
    {
      for (j = 0; part_types[j].id; ++j)
        if (disks[mountpoint->disk].parts[mountpoint->part].mbr_entry.id ==
              part_types[j].id)
        {
          if (!part_types[j].opendir)
            return NULL;
	  dir = malloc(sizeof (struct s_dir));
          dir->disk = mountpoint->disk;
	  dir->part = mountpoint->part;
	  return part_types[j].opendir(dir, name, flags);
	}
      break;
    }
  }
  return NULL;
}

struct s_dir	*opendir(const char *name)
{
  return opendir_flags(name, 0);
}

struct dirent	*readdir(struct s_dir *dir)
{
  unsigned int	i;

  for (i = 0; part_types[i].id; ++i)
    if (disks[dir->disk].parts[dir->part].mbr_entry.id == part_types[i].id)
    {
      if (!part_types[i].readdir)
        return NULL;
      return part_types[i].readdir(dir);
    }
  return NULL;
}

int		closedir(struct s_dir *dir)
{
  unsigned int	i;

  for (i = 0; part_types[i].id; ++i)
    if (disks[dir->disk].parts[dir->part].mbr_entry.id == part_types[i].id)
    {
      if (!part_types[i].closedir)
        return -1;
      part_types[i].closedir(dir);
      free(dir);
      return 0;
    }
  return -1;
}

int	mkdir(const char *pathname)
{
  if (!opendir_flags(pathname, O_CREAT_DIR))
    return 0;
  return -1;
}

int	rmdir(const char *pathname)
{
  /* FIXME */
  return -1;
}
