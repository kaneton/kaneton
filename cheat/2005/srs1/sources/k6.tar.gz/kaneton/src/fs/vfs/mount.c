#include <ide.h>
#include <string.h>
#include <set.h>
#include <fat.h>
#include <vfs.h>
#include <sys/mount.h>

t_setid	mountpoints;

int			mount(unsigned int source_disk, unsigned int source_part, const char *target)
{
  extern struct s_disk		disks[4];
  extern struct s_part_type	part_types[];
  struct s_mountpoint		*mountpoint;
  unsigned int			i;

  for (i = 0; part_types[i].id; ++i)
    if (disks[source_disk].parts[source_part].mbr_entry.id == part_types[i].id)
    {
      if (part_types[i].mount != NULL)
        part_types[i].mount(source_disk, source_part, target);
      else
        return -1;
    }
  mountpoint = malloc(sizeof(struct s_mountpoint));
  mountpoint->disk = source_disk;
  mountpoint->part = source_part;
  strcpy(mountpoint->name, target);
  set_insert(mountpoints, mountpoint);
  return 0;
}

int	umount(const char *target)
{
  return 0;
}
