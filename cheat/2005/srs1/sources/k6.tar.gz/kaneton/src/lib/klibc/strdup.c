#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char	*strndup(const char *s, size_t n)
{
  int	i;
  char	*dst;

  dst = malloc(strlen(s) + 1);
  for (i = 0; s[i] && (n == -1 || i < n); i++)
    dst[i] = s[i];
  dst[i] = 0;
  return dst;
}

char	*strdup(const char *s)
{
  return strndup(s, -1);
}
