
unsigned int kstrcmp(unsigned char *str_1, unsigned char *str_2)
{
  while(*str_1 && *str_2)
    {
      if (*str_1 != *str_2)
        return *str_1 - *str_2;
      str_1++;
      str_2++;
    }
  return *str_1 - *str_2;
}
