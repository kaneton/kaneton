#include <console.h>
#include <string.h>
#include <stdio.h>

int putchar(int c)
{
  cons_print_char(c);
  return c;
}

int puts(const char *s)
{
  cons_print_string(s);
  cons_print_char('\n');
  return strlen(s) + 1;
}

int printf(const char *format, ...)
{
  int	*argptr = (void *) &format;

  argptr++;
  do
    if (*format != '%')
      cons_print_char(*format);
    else
      if (*(++format) == '%')
        cons_print_char(*format);
      else
	if (*format == 'd' || *format == 'i')
	{
	  if (*argptr < 0)
	  {
            cons_print_char('-');
	    *argptr *= -1;
	  }
          cons_print_num(*argptr++);
	}
	else if (*format == 'u')
	  cons_print_num(*argptr++);
  	else if (*format == 's')
	  cons_print_string((char *) *argptr++);
	else if (*format == 'c')
	  cons_print_char(*argptr++);
	else if (*format == 'x')
	  cons_print_addr(*argptr++);
	else if (*format == 'p')
	  cons_print_addr8(*argptr++);
	else
	  {
	    cons_print_char(*(format - 1));
	    cons_print_char(*format);
	  }
  while (*(format++ + 1));
  return 0;
}
