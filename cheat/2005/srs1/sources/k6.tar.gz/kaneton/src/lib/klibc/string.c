#include <string.h>

size_t		strlen(const char *s)
{
  unsigned int	i = 0;

  while (s[i])
    ++i;
  return i;
}

char		*strcpy(char *dest, const char *src)
{
  unsigned int	i;

  for (i = 0; src[i]; ++i)
    dest[i] = src[i];
  dest[i] = '\0';
  return dest;
}

char		*strncpy(char *dest, const char *src, size_t n)
{
  unsigned int	i;

  for (i = 0; src[i] && i < n; ++i)
    dest[i] = src[i];
  while (i < n)
    dest[i++] = '\0';
  return dest;
}

char		*strcat(char *dest, const char *src)
{
  unsigned int	dest_len;
  unsigned int	i;

  dest_len = strlen(dest);
  for (i = 0; src[i]; ++i)
    dest[dest_len + i] = src[i];
  dest[dest_len + i] = '\0';
  return dest;
}

void		*memcpy(void *dest, const void *src, size_t n)
{
  unsigned int	i;

  for (i = 0; i < n; ++i)
    ((char *)dest)[i] = ((char *)src)[i];
  return dest;
}

void		*memset(void *s, int c, size_t n)
{
  unsigned int	i;

  for (i = 0; i < n; ++i)
    ((char *)s)[i] = c;
  return s;
}

char		*strchr(const char *s, int c)
{
  unsigned int	i;

  for (i = 0; s[i]; ++i)
    if (s[i] == c)
      return (char *) (s + i);
  return NULL;
}

void		strtrim(char *s)
{
  unsigned int	i;
  char		*whitespaces = " \t\n";

  for (i = 0; strchr(whitespaces, s[i]); ++i)
    ;
  strcpy(s, s + i);
  for (i = strlen(s) - 1; strchr(whitespaces, s[i]); --i)
    ;
  s[i + 1] = '\0';
}

int	strncmp(const char *s1, const char *s2, size_t n)
{
  if ((!*s1 && !*s2) || !n)
    return 0;
  if (*s1 != *s2)
    return *s1 - *s2;
  return strncmp(s1 + 1, s2 + 1, n == -1 ? -1 : n - 1);
}

int	strcmp(const char *s1, const char *s2)
{
  return strncmp(s1, s2, -1);
}
