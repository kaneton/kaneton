#include <stdio.h>

void	panic(const char *str)
{
  printf("Kernel panic: ");
  printf(str);
  printf("\n");
  while (1)
    ;
}
