#include <unistd.h>
#include <time.h>

int			nanosleep(const struct timespec *req, struct timespec *rem)
{
  extern unsigned int	ticks;
  unsigned int		up;

  sleep(req->tv_sec);
  up = ticks + req->tv_nsec / 1000000;
  while (ticks < up)
    ;
  return 0;
}
