#include <unistd.h>

unsigned int		sleep(unsigned int seconds)
{
  extern unsigned int	ticks;
  unsigned int		up;

  up = ticks + 1000 * seconds;
  while (ticks < up)
    ;
  return 0;
}
