#ifndef __IDE_H_
# define __IDE_H_

# include <types.h>
# include <part.h>

# define IDE_CONTROLLER_PRIM	0x1F0
# define IDE_CONTROLLER_SEC	0x170

# define	NUM_CONTROLLER			2
# define	NUM_DEVICES			2

# define	IDE_PRIMARY_CONTROLLER		0
# define	IDE_SECONDARY_CONTROLLER	1

# define IDE_DRIVE	0x06
# define IDE_DISK	0xa0

# define HARDDISK_LBA_CAPABLE 0x1

# define PRIM_CONTROLLER_IOADDR		0x1F0
# define SECOND_CONTROLLER_IOADDR	0x170
# define IDE_DISK_MASTER		0x00
# define IDE_DISK_SLAVE			0x10

# define IDE_DEVICE_CONTROL             0x206

# define IDE_CMD                        0x07
# define         IDE_C_ATA_IDENTIFY     0xec

# define         IDE_A_nIEN             0x02
# define         IDE_A_4BIT             0x08


# define IDE_DRIVE			0x06
# define IDE_STATUS			0x07
# define	IDE_STATUS_BUSY		0x80


# define IDE_D_IBM	 0xa0
# define IDE_D_LBA	 0x40
# define IDE_D_MASTER	 0x00
# define IDE_D_SLAVE	 0x10

# define IDE_RD_SRST	 0x04

# define IDE_ERROR	 0x01

# define IDE_BLK_SIZE	 512

# define IDE_MASTER	 0x00
# define IDE_SLAVE	 0x01

# define IDE_PRESENT	 0x01
# define IDE_NOT_PRESENT 0x00


/*
 * for ide_read
 */

# define IDE_PRECOMP		0x00 /* (W) precompenstation */
# define IDE_SECTOR_COUNT	0x02 /* (W) sector count register */
# define IDE_SECTOR_NUMBER	0x03 /* (W) sector count register */
# define IDE_CYL_LSB		0x04 /* (W) cylinder# LSB */
# define IDE_CYL_MSB		0x05 /* (W) cylinder# MSB */

# define IDE_C_READ		0x20 /* read command */
# define IDE_C_WRITE		0x30 /* write command */

/*
** structures
*/

struct		s_ide_device_info
{
  t_uint16	general_config_info;      /* 0 */
  t_uint16	nb_logical_cylinders;     /* 1 */
  t_uint16	reserved1;                /* 2 */
  t_uint16	nb_logical_heads;         /* 3 */
  t_uint16	unformatted_bytes_track;  /* 4 */
  t_uint16	unformatted_bytes_sector; /* 5 */
  t_uint16	nb_logical_sectors;       /* 6 */
  t_uint16	vendor1[3];               /* 7-9 */
  t_uint8	serial_number[20];        /* 10-19 */
  t_uint16	buffer_type;              /* 20 */
  t_uint16	buffer_size;              /* 21 */
  t_uint16	ecc_bytes;                /* 22 */
  t_uint8	firmware_revision[8];     /* 23-26 */
  t_uint8	model_number[40];         /* 27-46 */
  t_uint8	max_multisect;            /* 47 */
  t_uint8	vendor2;
  t_uint16	dword_io;                 /* 48 */
  t_uint8	vendor3;                  /* 49 */
  t_uint8	capabilities;
  t_uint16	reserved2;                /* 50 */
  t_uint8	vendor4;                  /* 51 */
  t_uint8	pio_trans_mode;
  t_uint8	vendor5;                  /* 52 */
  t_uint8	dma_trans_mode;
  t_uint16	fields_valid;             /* 53 */
  t_uint16	cur_logical_cylinders;    /* 54 */
  t_uint16	cur_logical_heads;        /* 55 */
  t_uint16	cur_logical_sectors;      /* 56 */
  t_uint16	capacity1;                /* 57 */
  t_uint16	capacity0;                /* 58 */
  t_uint8	multsect;                 /* 59 */
  t_uint8	multsect_valid;
  t_uint32	lba_capacity;             /* 60-61 */
  t_uint16	dma_1word;                /* 62 */
  t_uint16	dma_multiword;            /* 63 */
  t_uint16	pio_modes;                /* 64 */
  t_uint16	min_mword_dma;            /* 65 */
  t_uint16	recommended_mword_dma;    /* 66 */
  t_uint16	min_pio_cycle_time;       /* 67 */
  t_uint16	min_pio_cycle_time_iordy; /* 68 */
  t_uint16	reserved3[11];            /* 69-79 */
  t_uint16	major_version;            /* 80 */
  t_uint16	minor_version;            /* 81 */
  t_uint16	command_sets1;            /* 82 */
  t_uint16	command_sets2;            /* 83 dixit lk : b14 (smart enabled) */
  t_uint16	reserved4[4];             /* 84-87 */
  t_uint16	dma_ultra;                /* 88 dixit lk */
  t_uint16	reserved5[37];            /* 89-125 */
  t_uint16	last_lun;                 /* 126 */
  t_uint16	reserved6;                /* 127 */
  t_uint16	security;                 /* 128 */
  t_uint16	reserved7[127];
} __attribute__((packed));

struct	s_disk
{
  int		present;
  t_uint16	cylinders;
  t_uint16	heads;
  t_uint16	sectors;
  unsigned int	blocks;
  char		model_name[41];
  struct s_part	parts[4];
};

void	ide_get_dev_info(unsigned long controller_addr, unsigned int disk_id, struct s_disk *disk);
void	ide_display(unsigned char *);
int	ide_init(void);
int	ide_clean(void);
int	ide_rw(int rw_operation, unsigned int block_addr, t_uint16 *buf, unsigned long controller_addr, unsigned int disk_id);
int	ide_read_block(unsigned int disk, unsigned int block_addr, unsigned int offset, void *buf, size_t count);
int	ide_read(unsigned int disk, unsigned int addr, void *buf, size_t count);
int	ide_write_block(unsigned int disk, unsigned int block_addr, unsigned int offset, void *buf, size_t count);
int	ide_write(unsigned int disk, unsigned int addr, void *buf, size_t count);
int	ide_buf16_to_buf8(t_uint16 *buf16, char *buf8, unsigned int size);
int	ide_list(void);

#endif /* !__IDE_H_ */
