#ifndef _KEYBOARD_H
#define _KEYBOARD_H

/*
** ports
*/
#define DATA_PORT    0x60
#define COMMAND_PORT 0x64

#define KEYBOARD_BUFFER_SIZE 1024

/*
 * Keys and buttons, taken from Linux source code,
 * include/linux/input.h
 */
#define KEY_RESERVED            0
#define KEY_ESC                 1
#define KEY_1                   2
#define KEY_2                   3
#define KEY_3                   4
#define KEY_4                   5
#define KEY_5                   6
#define KEY_6                   7
#define KEY_7                   8
#define KEY_8                   9
#define KEY_9                   10
#define KEY_0                   11
#define KEY_MINUS               12
#define KEY_EQUAL               13
#define KEY_BACKSPACE           14
#define KEY_TAB                 15
#define KEY_Q                   16
#define KEY_W                   17
#define KEY_E                   18
#define KEY_R                   19
#define KEY_T                   20
#define KEY_Y                   21
#define KEY_U                   22
#define KEY_I                   23
#define KEY_O                   24
#define KEY_P                   25
#define KEY_LEFTBRACE           26
#define KEY_RIGHTBRACE          27
#define KEY_ENTER               28
#define KEY_LEFTCTRL            29
#define KEY_A                   30
#define KEY_S                   31
#define KEY_D                   32
#define KEY_F                   33
#define KEY_G                   34
#define KEY_H                   35
#define KEY_J                   36
#define KEY_K                   37
#define KEY_L                   38
#define KEY_SEMICOLON           39
#define KEY_APOSTROPHE          40
#define KEY_GRAVE               41
#define KEY_LEFTSHIFT           42
#define KEY_BACKSLASH           43
#define KEY_Z                   44
#define KEY_X                   45
#define KEY_C                   46
#define KEY_V                   47
#define KEY_B                   48
#define KEY_N                   49
#define KEY_M                   50
#define KEY_COMMA               51
#define KEY_DOT                 52
#define KEY_SLASH               53
#define KEY_RIGHTSHIFT          54
#define KEY_KPASTERISK          55
#define KEY_LEFTALT             56
#define KEY_SPACE               57
#define KEY_CAPSLOCK            58
#define KEY_F1                  59
#define KEY_F2                  60
#define KEY_F3                  61
#define KEY_F4                  62
#define KEY_F5                  63
#define KEY_F6                  64
#define KEY_F7                  65
#define KEY_F8                  66
#define KEY_F9                  67
#define KEY_F10                 68
#define KEY_NUMLOCK             69
#define KEY_SCROLLLOCK          70
#define KEY_KP7                 71
#define KEY_KP8                 72
#define KEY_KP9                 73
#define KEY_KPMINUS             74
#define KEY_KP4                 75
#define KEY_KP5                 76
#define KEY_KP6                 77
#define KEY_KPPLUS              78
#define KEY_KP1                 79
#define KEY_KP2                 80
#define KEY_KP3                 81
#define KEY_KP0                 82
#define KEY_KPDOT               83
#define KEY_103RD               84
#define KEY_F13                 85
#define KEY_102ND               86
#define KEY_F11                 87
#define KEY_F12                 88
#define KEY_F14                 89
#define KEY_F15                 90
#define KEY_F16                 91
#define KEY_F17                 92
#define KEY_F18                 93
#define KEY_F19                 94
#define KEY_F20                 95
#define KEY_KPENTER             96
#define KEY_RIGHTCTRL           97
#define KEY_KPSLASH             98
#define KEY_SYSRQ               99
#define KEY_RIGHTALT            100
#define KEY_LINEFEED            101
#define KEY_HOME                102
#define KEY_UP                  103
#define KEY_PAGEUP              104
#define KEY_LEFT                105
#define KEY_RIGHT               106
#define KEY_END                 107
#define KEY_DOWN                108
#define KEY_PAGEDOWN            109
#define KEY_INSERT              110
#define KEY_DELETE              111
#define KEY_MACRO               112
#define KEY_MUTE                113
#define KEY_VOLUMEDOWN          114
#define KEY_VOLUMEUP            115
#define KEY_POWER               116
#define KEY_KPEQUAL             117
#define KEY_KPPLUSMINUS         118
#define KEY_PAUSE               119
#define KEY_F21                 120
#define KEY_F22                 121
#define KEY_F23                 122
#define KEY_F24                 123
#define KEY_KPCOMMA             124
#define KEY_LEFTMETA            125
#define KEY_RIGHTMETA           126
#define KEY_COMPOSE             127


/*
 * structures / types
 */

typedef struct _s_keyboard
{
  unsigned char *_keyboard_table;
  unsigned char _buffer[KEYBOARD_BUFFER_SIZE];
  /* While the scancodes are the data sent by keyboard and fetched by the inb call
     on port 60, keycodes are a unique int that represent a key of the keyboard. In keycode, the first bit is set
     when the key is released and is not set when the key is pressed. So the are 128 possible keys, each of them can
     be pressed or released. */
  unsigned char _keycode;
  /* The key has been pressed or released */
  unsigned char		_key_up;

  unsigned char	_character;

  unsigned char	waiting_chars[128];
  unsigned int	waiting_chars_count;

  /* The following table allows to know what keys are pressed at the same time.
  ** For example : if (_keys[KEY_LEFTSHIFT] && _keys[KEY_PAGEUP) is the test to know if
  ** the left shift button is pressed at the same time that the page up key */
  unsigned char		_keys[128];
  /* A tty handler */
  void (*_tty_handler)();
  /* old tty handler */
  void (*_old_tty_handler)();
  unsigned char _caps_lock;
  unsigned char _num_lock;
} _t_keyboard;

/*
 * Macros
 */

#define KBR_CAPSLOCK (_keyboard._caps_lock)
#define KBR_NUMLOCK (_keyboard._num_lock)
#define EXT_CODE_PREFIX 0xE0
#define REGULAR_CODE_LIM 0x58
#define BREAKCODE_LIMIT 0x80
#define IS_MAKY_EACODE(c) ((c) < BREAKCODE_LIMIT)
#define IS_BREAKCODE(c) ((c) >= BREAKCODE_LIMIT)


/*
 * prototypes
 */
void k_keyboard_isr(void);
int k_init_keyboard(void);
void k_get_char(char *c);
unsigned int k_get_string(unsigned char *buffer, unsigned int len);
void		k_register_tty_handler(void (*h)());


#endif
