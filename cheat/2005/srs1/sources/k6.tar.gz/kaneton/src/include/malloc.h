#ifndef __MALLOC_H_
# define _MALLOC_H_

# include <types.h>

# define IN_FREEING	0x1
# define FREE		0x2
# define NOT_FREE      	0x0

/*
** Structure Used by Malloc
*/

struct s_mblock
{
  t_vaddr	next;
  t_uint32	size;
  t_uint8	free;
};

struct s_mpage
{
  t_vaddr	next;
  t_uint32	nbpages;
  t_uint32	nbblocks;	/* Optional */
};

/*
** Usefull macros for malloc
*/

#define NEXT_BLOCK(block) \
((struct s_mblock *)(block->next))

#define SET_NEXT_BLOCK(block, new) \
(block->next = (t_vaddr)(new))

#define NEXT_PAGE(page) \
((struct s_mpage *)(page->next))

#define SET_NEXT_PAGE(page, new) \
(page->next = (t_vaddr)(new))

#define GET_FIRST_BLOCK(page) \
((struct s_mblock *)((t_vaddr)(page) + (t_vaddr)(sizeof(struct s_mpage))))

#define GET_BLOCK(addr) \
((struct s_mblock *)((t_vaddr)(addr) - (t_vaddr)(sizeof(struct s_mblock))))

#define GIVE_BLOCK(addr) \
((struct s_mblock *)((t_vaddr)(addr) + (t_vaddr)(sizeof(struct s_mblock))))

#define OCT(chiche) \
((chiche / 8))

/*
** Hack function
*/

void	init_malloc(void);
void	debug_malloc(void);
#endif
