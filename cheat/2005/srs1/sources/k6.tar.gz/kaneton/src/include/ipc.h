#ifndef _IPC_H_
# define _IPC_H_

#include <traps.h>
#include <events.h>
#include <messages.h>



int	ipc_init(void);
int	ipc_clean(void);


# endif /* !_IPC_H_ */
