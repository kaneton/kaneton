#ifndef __MESSAGES_H_
# define __MESSAGES_H_

# include <types.h>
# include <set.h>

int	msg_init();
int	msg_clean();
int	msg_create(t_msgid *);
int	msg_delete(t_msgid);
int	msg_storehd(t_msgid, t_msghd *);
int	msg_loadhd(t_msgid, t_msghd *);
int	msg_storedata(t_msgid, t_data, size_t);
t_data	msg_loaddata(t_msgid, size_t *);
int	msg_send(t_msgid);
int	msg_rcv(t_sbtype, t_msgid *);

#endif
