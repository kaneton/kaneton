/*
** Physical memory handling
*/

#ifndef __PM_H_
# define __PM_H_

# include <as.h>

typedef struct	i_machdep_pm
{
  int		(*pm_init)(void);
}		i_machdep_pm;

# include <machdep/pm.h>

/*
 *   int XXX XXXXX
 *        |    \  absolute position in the tab
 *        \  number of reference
 */

#define MEM_RSVED	0xFFF

#define PM_NBREF(i)     (((_pm._tab[i]) >> 20) & 0xFFF)
#define PM_ADDREF(i)    ((_pm._tab[i]) += (1 << 20))
#define PM_SETRSV(i)    ((_pm._tab[i]) = (MEM_RSVED << 20 & 0xFFF00000) + ((_pm._tab[i]) & 0xFFFFF))			 
#define PM_SETREF(i, n)	 ((_pm._tab[i]) = (n << 20 & 0xFFF00000) + ((_pm._tab[i]) & 0xFFFFF)) 
//#define PM_SETREF(i, n)	((_pm._tab[i]) = n)
#define PM_DELREF(i)    ((_pm._tab[i]) -= (1 << 20))
#define PM_POS(i)       ((_pm._tab[i]) & 0xFFFFF)
#define PM_SETPOS(i, n) ((_pm._tab[i]) = ((_pm._tab[i]) & 0xFFF00000) + (n & 0xFFFFF))

#define PM_FLAG_ANY		0x00
#define PM_FLAG_SPECIFIC	0x01
#define PM_FLAG_DMA		0x02

#define PM_FLAG_PT		0x10

typedef struct _s_pm
{
  unsigned int *_tab;
  t_paddr _start;
  t_psize _size;
  unsigned int _nbpages;
} _t_pm;


/*
** PM HANDLER
*/

int	pm_init();
void	pm_load_used(void);
int	pm_rsv(t_asid, t_paddr *, t_psize, t_pmflags);
int	pm_allocpages(unsigned int, t_psize);
int	pm_rel(t_asid, t_paddr, t_psize);
int	pm_flush(t_asid);
int	pm_clear(void);

/*
** Interfaces used for sharing
*/

void	pm_addref(t_paddr paddr);
void	pm_delref(t_paddr paddr);

/*
** Used for debug
*/
int	dump_map(void);

#endif /* !__PM_H_ */
