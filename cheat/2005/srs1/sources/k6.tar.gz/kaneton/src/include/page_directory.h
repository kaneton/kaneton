#ifndef _PAGE_DIRECTORY_H_
# define _PAGE_DIRECTORY_H_

/*
** PD Flags
*/

# define MASK_PD_NOTPRESENT	0x0
# define MASK_PD_PRESENT	0x1
# define MASK_PD_WRITE		0x2
# define MASK_PD_USER		0x4
# define MASK_PD_WRITE_THROUGH	0x8
# define MASK_PD_CACHE_DIS	0x10
# define MASK_PD_ACCESSED	0x20
# define MASK_PD_ZERO		0x40
# define MASK_PD_PAGESIZE	0x80
# define MASK_PD_GLOBAL_PAGE	0x100

# define MASK_PD_CUST		0x00000007
# define MASK_PD_ADDR		0x000FFFFF



/*
** PD Functions
*/

void	init_pd(void *pd_paddr);

void	insert_pd_entry(void *pd_paddr, unsigned long write, void *pt_paddr);

void	copy_pd(struct x86_pde *pd_dest, const struct x86_pde *pd_src);

void	insert_pd_entry_s(void			*pt_paddr,
			  unsigned long		custom,
			  unsigned long		flags,
			  struct x86_pde	*pd_paddr,
			  int			entry);

void	synchro_pd(struct x86_pde	*pd_dest,
		   const struct x86_pde	*kernel,
		   int			entry);

void delete_pd_entry(struct x86_pde *pd_addr, int entry);

#endif /* !_PAGE_DIRECTORY_H_ */
