#ifndef _CONSOLE_H
#define _CONSOLE_H

/*
 * defines
 */

#define CONSOLE_VIDEO_ADDR 0xb8000
#define CONSOLE_VIDEO_LIMIT 0xb8fa0
#define CONSOLE_SIZE 0xfa0
#define CONSOLE_X 80
#define CONSOLE_Y 25
#define CONSOLE_VIDEO_MEMORY CONSOLE_X * CONSOLE_Y
#define CONSOLE_BPP 2
#define VGA_OUTPUT_REGISTER 0x3cc
#define VGA_OUTPUT_READ_REGISTER 0x3cc
#define CONSOLE_TABULATION 8
#define CONSOLE_DEFAULT_CURSOR_STATUS 1
#define CONSOLE_DEFAULT_ATTR 0x07

#define CONSOLE_HEXADECIMAL_BASE_HIGH "0123456789ABCDEF"
#define CONSOLE_HEXADECIMAL_BASE_LOW "0123456789abcdef"
#define CONSOLE_DECIMAL_BASE "0123456789"
#define CONSOLE_OCTAL_BASE "01234567"
#define CONSOLE_BINARY_BASE "01"

#define CONSOLE_CURSOR_MASK 0x1

/*
** Cursor ports
*/
#define CRT_REG_INDEX 0x3d4
#define CRT_REG_DATA  0x3d5

/*
** Cursor attributes
*/
#define VGA_COMMAND_PORT 0x3D4
#define VGA_DATA_PORT    0x3D5

/* VGA commands */

#define VGA_SET_CURSOR_START 0xA
#define VGA_SET_CURSOR_END   0xB
#define VGA_SET_ADDRESS_HIGH 0xC
#define VGA_SET_ADDRESS_LOW  0xD
#define VGA_SET_CURSOR_HIGH  0xE
#define VGA_SET_CURSOR_LOW   0xF

#define VGA_REG_START_CUR 0xA
#define VGA_REG_END_CUR   0xB

#define VGA_COLOR_BLACK   0
#define VGA_COLOR_BLUE    1
#define VGA_COLOR_GREEN   2
#define VGA_COLOR_CYAN    3
#define VGA_COLOR_RED     4
#define VGA_COLOR_MAGENTA 5
#define VGA_COLOR_YELLOW  6
#define VGA_COLOR_WHITE   7

#define COLUMNS 80
#define ROWS    25

#define VIDEOBUF_SIZE	CONSOLE_SIZE * 2

/*
 * structures / types
 */

typedef struct _s_console
{
  unsigned char _attr;		/* consle character attributes */
  unsigned short _cursor;	/* The pointer in the video memory area */
  unsigned short _oldcursor;     /* Last position of the cursor */
  unsigned short _coord;	/* coordinate for the console blinking cursor */
  unsigned short _oldcoord;  /* last coordinate of the blinking cursor */
} _t_console;

/*
 * prototypes
 */

int	cons_init_console(void);
int	cons_set_cursor_pos(unsigned char, unsigned char);
void	cons_print_string(const char *);
void	cons_print_num(int);
void	cons_print_addr(unsigned int);
void	cons_print_addr8(unsigned int);
void	cons_print_addr_rec(unsigned int);
void	cons_print_char(unsigned char);
void	cons_move_up(int);
void	cons_move_down(int);
void	cons_move_bottom(void);
void	cons_scroll(void);
void	cons_panic(char *);
void	cons_succeed(char *);
void	cons_skipped(char *);
void	cons_init_msg(char *, int);
void	cons_print_center(char *);
int	cons_clear();
void	cons_attr(unsigned char,
                  unsigned char,
                  unsigned char,
                  unsigned char);
void	cons_cursor(void);
void	cons_blue(char *message);

/*
 * details for k_set_attr() function
 *
 *
 * flicker   :   0 = disable    1 = enable
 * back      :   0 = black      1 = blue       2 = green      3 = cyan
 *               4 = red        5 = magenta    6 = yellow     7 = white
 * intensity :   0 = disable    1 = enable
 * front     :   0 = black      1 = blue       2 = green      3 = cyan
 *               4 = red        5 = magenta    6 = yellow     7 = white
 */

#endif
