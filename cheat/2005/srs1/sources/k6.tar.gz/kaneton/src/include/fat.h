#ifndef __FAT_H_
# define __FAT_H_

# include <vfs.h>
# include <types.h>

# define FAT_ATTR_READ_ONLY	0x01
# define FAT_ATTR_HIDDEN	0x02
# define FAT_ATTR_SYSTEM	0x04
# define FAT_ATTR_VOLUME_ID	0x08
# define FAT_ATTR_DIRECTORY	0x10
# define FAT_ATTR_ARCHIVE	0x20
# define FAT_ATTR_LONG_NAME	(FAT_ATTR_READ_ONLY | FAT_ATTR_HIDDEN | FAT_ATTR_SYSTEM | FAT_ATTR_VOLUME_ID)

# define FAT_FS(disk, part)	(*(struct s_fat_fs *)disks[(disk)].parts[(part)].fs)
# define FAT_DIR(dir)           (*(struct s_fat_dir *)(dir)->fs_dir)
# define FAT_FILE(file)		(*(struct s_fat_dir *)((struct s_dir *)(file)->fs_file)->fs_dir)

struct		s_fat_bs
{
  t_uint8	jmp_boot0;
  t_uint8	jmp_boot1;
  t_uint8	jmp_boot2;
  char		oem_name[8];
  t_uint16	byts_per_sec;
  t_uint8	sec_per_clus;
  t_uint16	rsvd_sec_cnt;
  t_uint8	num_fats;
  t_uint16	root_ent_cnt;
  t_uint16	tot_sec16;
  t_uint8	media;
  t_uint16	fat_sz16;
  t_uint16	sec_per_trk;
  t_uint16	num_heads;
  t_uint32	hidd_sec;
  t_uint32	tot_sec32;
  /* FAT32-specific */
  t_uint32	fat_sz32;
  t_uint16	ext_flags;
  t_uint16	fs_ver;
  t_uint32	root_clus;
  t_uint16	fs_info;
  t_uint16	bk_boot_sec;
  t_uint32	reserved[3];
  t_uint8	drv_num;
  t_uint8	reserved1;
  t_uint8	boot_sig;
  t_uint32	vol_id;
  char		vol_lab[11];
  char		fil_sys_type[8];
} __attribute__ ((packed));

struct			s_fat_fs
{
  struct s_fat_bs	bs;
  int			first_data_sector;
};

struct		s_fat_dirent
{
  unsigned char	name[8];
  unsigned char	ext[3];
  t_uint8	attr;
  t_uint8	nt_res;
  t_uint8	crt_time_tenth;
  t_uint16	crt_time;
  t_uint16	crt_date;
  t_uint16	lst_acc_date;
  t_uint16	fst_clus_hi;
  t_uint16	wrt_time;
  t_uint16	wrt_date;
  t_uint16	fst_clus_lo;
  t_uint32	file_size;
} __attribute__ ((packed));

struct		s_fat_dir
{
  unsigned int	disk;
  unsigned int	part;
  unsigned int	start_sector;
  unsigned int	current_pos;
  unsigned int	size;
};

int	fat_cluster_to_sector(unsigned int disk, unsigned int part, unsigned int cluster);
int	fat_mount(unsigned int source_disk, unsigned int source_part, const char *target);
int	fat_open(unsigned int disk, unsigned int part, const char *pathname, int flags);
ssize_t fat_read(struct s_file *file, void *buf, size_t count);
int	fat_close(struct s_file *file);
struct s_dir	*fat_opendir(struct s_dir *dir, const char *name, int flags);
struct dirent	*fat_readdir(struct s_dir *dir);
int	fat_closedir(struct s_dir *dir);
int	fat_unlink(unsigned int disk, unsigned int part, const char *pathname);

#endif /*! __FAT_H_ */
