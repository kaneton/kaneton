/*
** Clock driver header file
*/


#ifndef __CLOCK_H_
# define __CLOCK_H_
#include <types.h>

struct		s_datetime
{
  t_uint8	sec;
  t_uint8	min;
  t_uint8	hour;
  t_uint8	dow;  /* day of week */
  t_uint8	day;
  t_uint8	month;
  t_uint8	year;
}t_datetime;

int		clock_init(void);
int		clock_get(struct s_datetime*);
#endif
