#ifndef TIME_H_
# define TIME_H_

typedef unsigned long int time_t;

struct		timespec
{
  time_t	tv_sec;
  long		tv_nsec;
};

int	nanosleep(const struct timespec *req, struct timespec *rem);

#endif /* !TIME_H_ */
