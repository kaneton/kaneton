#ifndef __UNISTD_H_
# define __UNISTD_H_

# include <stddef.h>

unsigned int	sleep(unsigned int seconds);
ssize_t	read(int fd, void *buf, size_t count);
int	close(int fd);
int	chdir(const char *path);
char	*getcwd(char *buf, size_t size);
int	unlink(const char *pathname);

#endif /* !__UNISTD_H_ */
