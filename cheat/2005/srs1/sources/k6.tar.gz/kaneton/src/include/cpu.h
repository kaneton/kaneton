#ifndef __CPU_H_
# define __CPU_H_

int	cpu_init(void);
int	cpu_clean(void);

struct	s_cpu
{
  char	vendor[13];
  char	name[49];
};

#endif /* !__CPU_H_ */
