/*
** tty.h for kaneton in /home/obert01/ing2/kernel/ksrs3/k4/src/drivers
**
** Made by Olivier BERT
** Login   <bert_o@epita.fr>
**
** Started on  Wed Jun  1 10:58:34 2005
** Last update Thu Jun  2 08:58:38 2005 
*/
#ifndef __TTY_H_
# define __TTY_H_
#include <console.h>

# define NB_TTYS	6

struct		s_tty
{
  /* current position in the screen */
  int x;
  int y;
  /* location of the blinking cursor */
  int cursorx;
  int cursory;
  char screen[CONSOLE_SIZE];
};

typedef struct s_tty t_tty;

int		tty_init(void);
void		tty_restore_handler(void);
int		tty_dump(t_tty*);
int		tty_save(t_tty *tty);
#endif
