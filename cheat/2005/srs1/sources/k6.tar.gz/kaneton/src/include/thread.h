#ifndef __THREAD_H_
# define __THREAD_H_

# include <scheduler.h>

typedef struct	s_thread
{
  t_thrid	thrid;
  t_tskid	tskid;
  t_ownid	ownid;

  t_prior	prior;
  
  t_status	sched;

  t_wait	wait;
  t_setid	waitlist;

  t_vaddr	stack;
  t_vsize	stacksz;

  struct s_ctx	ctx;
}		t_thread;

int	thread_init(void);
int	thread_rsv(t_prior prior, t_thrid *thrid);
int	thread_prior(t_thrid thrid, t_prior *prior);
int	thread_grade(t_thrid thrid, t_prior prior);
int	thread_wait(t_thrid thrid, t_wait *wait);
int	thread_get(t_thrid thrid, t_thread **thread);
int	thread_rel(t_thrid thrid);
int	thread_clone(t_thrid old, t_thrid *new);
int	thread_run(t_thrid thrid);
int	thread_stop(t_thrid thrid);
int	thread_tskid(t_thrid thrid, t_tskid *tskid);
int	thread_ownid(t_thrid thrid, t_ownid *ownid);
int	thread_give(t_thrid thrid, t_ownid ownid);
int	thread_stack(t_thrid thrid, t_vsize npages);
int	thread_load(t_thrid thrid, t_thrctx *thrctx);
int	thread_store(t_thrid thrid, t_thrctx *thrctx);
int	thread_args(t_thrid thrid, void *args, size_t size);
int	thread_attach(t_thrid thrid, t_tskid tskid);
int	thread_detach(t_thrid thrid, t_tskid tskid);
int	thread_exit(t_thrid thrid);
int	thread_clean(void);

#endif /* !__THREAD_H_ */
