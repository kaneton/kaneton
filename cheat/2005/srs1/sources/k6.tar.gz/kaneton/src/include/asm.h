#ifndef _ASM_H
#define _ASM_H

/*
 * defines
 */

#define CLI __asm__ volatile ("cli"::)
#define STI __asm__ volatile ("sti"::)

#endif
