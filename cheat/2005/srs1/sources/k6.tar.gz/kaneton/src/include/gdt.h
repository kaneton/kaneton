#ifndef _GDT_H
#define _GDT_H

/*
 * defines
 */

#define GDT_SIZE 0x100
#define GDT_ADDR 0x800               /* Global Descriptor Table Physical Address */

                                     /* level: 0 = kernel, 3 = user */
#define GDT_DPL0 0x00                /* 00000000 */
#define GDT_DPL1 0x20                /* 00100000 */
#define GDT_DPL2 0x40                /* 01000000 */
#define GDT_DPL3 0x60                /* 01100000 */

                                     /* type: normal code = GDT_USE32 | GDT_AVAILABLE */
#define GDT_USE16 0x00               /* 00000000 */
#define GDT_AVAILABLE 0x10           /* 00010000 */
#define GDT_USE32 0x40               /* 01000000 */
#define GDT_GRANULAR 0x80            /* 10000000 */

                                     /* flags: normal code = GDT_CODE | GDT_PRESENT |
					GDT_READABLE | GDT_APPLICATION */
#define GDT_SYSTEM 0x00              /* 00000000 = TSS. LDT. int. whatever */
#define GDT_APPLICATION 0x10         /* 00010000 = application code */

                                     /* flags: type of S_SYSTEM segments */
#define GDT_TSS16 0x1                /* 00000001 = 16 bit TSS (available) */
#define GDT_LDT 0x2                  /* 00000010 = LDT */
#define GDT_TSS16_BUSY 0x3           /* 00000011 = 16 bits TSS (busy) */
#define GDT_CALL16 0x4               /* 00000100 = 16 bits call gate */
#define GDT_TASK 0x5                 /* 00000101 = task gate */
#define GDT_INT16 0x6                /* 00000110 = 16 bits interrupt gate */
#define GDT_TRAP16 0x7               /* 00000111 = 16 bits trap gate */
#define GDT_TSS32 0x9                /* 00001001 = 32 bits TSS (available) */
#define GDT_TSS32_BUSY 0xB           /* 00001011 = 32 bits TSS (busy) */
#define GDT_CALL32 0xC               /* 00001100 = 32 bits call gate */
#define GDT_INT32 0xE                /* 00001110 = 32 bits interrupt gate */
#define GDT_TASK_GATE 0xF            /* 00001111 = 32 bits trap gate */

                                     /* flags: type of S_APPLICATION segments */
#define GDT_READABLE 0x02            /* 00000010 (only code) */
#define GDT_CONFORMING 0x04          /* 00000100 (only code) */
#define GDT_CODE 0x08                /* 00001000 */

#define GDT_DATA 0x00                /* 00000 */
#define GDT_WRITABLE 0x02            /* 00010 (only data) */
#define GDT_EXPAND_DOWN 0x04         /* 00100 (only data) */

#define GDT_ACCESSED 0x01            /* 00001 (both) */
#define GDT_PRESENT 0x80             /* 10000000
					(both. use for virtual paging & what not) */
/*
 * structures / types
 */

typedef struct _s_gdt
{
  unsigned short __limit;
  unsigned short __base;
  unsigned char _base_16;
  unsigned char _type;
  unsigned char _flags;
  unsigned char _base_24;
} __attribute__ ((packed)) _t_gdt;

typedef struct _s_gdtr
{
  unsigned short _size;
  unsigned int _addr;
} __attribute__ ((packed)) _t_gdtr;

/*
 * prototypes
 */

unsigned short k_gdt_new_segment(unsigned int base, unsigned int length,
				 unsigned int type, unsigned int flags);
int		k_gdt_remove(unsigned int entry);
int             k_gdt_clear(void);
int k_init_gdt();
unsigned short k_get_kernel_code_segment();
unsigned short k_get_kernel_data_segment();
unsigned short k_get_user_code_segment();
unsigned short k_get_user_data_segment();
void	k_lgdt(unsigned int x);

#endif
