#ifndef __DIRENT_H_
# define __DIRENT_H_

# define ATTR_READ_ONLY     0x01
# define ATTR_HIDDEN        0x02
# define ATTR_SYSTEM        0x04
# define ATTR_VOLUME_ID     0x08
# define ATTR_DIRECTORY     0x10
# define ATTR_ARCHIVE       0x20

struct		s_dir
{
  unsigned int	disk;
  unsigned int	part;
  void		*fs_dir;
};

struct		dirent
{
  char		d_name[256];
  t_uint8	attr;
  t_uint32	file_size;
  t_uint16      wrt_time;
  t_uint16      wrt_date;
};

struct s_dir	*opendir(const char *name);
struct dirent	*readdir(struct s_dir *dir);
int	closedir(struct s_dir *dir);

#endif /* !__DIRENT_H_ */
