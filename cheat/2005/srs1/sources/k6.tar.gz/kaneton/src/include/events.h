#ifndef __EVENTS_H_
# define __EVENTS_H_

#include <types.h>


typedef struct s_event
{
  void* (*fun)();
  /* put what you want ! ;-) */
} t_event;

int event_init(void);
int event_rsv(t_eventid eventid, t_event event);
int event_rel(t_eventid eventid);
int event_clean(void);
int event_flush(void);

#endif
