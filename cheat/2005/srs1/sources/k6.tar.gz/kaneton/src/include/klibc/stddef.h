#ifndef __STDDEF_H_
# define __STDDEF_H_

# define NULL ((void *)0)

typedef unsigned int	size_t;
typedef int	ssize_t;

#endif /* !__STDDEF_H_ */
