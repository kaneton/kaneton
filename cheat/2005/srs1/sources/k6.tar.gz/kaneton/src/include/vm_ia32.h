#ifndef __VM_IA32_H_
# define __VM_IA32_H_

int	map_in_pd(struct x86_pde *, void *, void *, unsigned long, unsigned int);
int     unmap_in_pd(struct x86_pde *, void *, unsigned int);
int	map_init_table(void *);

#endif /* !__VM_IA32_H_ */
