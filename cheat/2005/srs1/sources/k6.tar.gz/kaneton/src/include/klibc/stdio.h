#ifndef __STDIO_H_
# define __STDIO_H_

# include <stddef.h>

int	putchar(int);
int	puts(const char *);
int	printf(const char *, ...);

#endif /* !__STDIO_H_ */
