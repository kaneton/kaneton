/*
** Address space handling: machine-dependent part.
*/

#ifndef __IA32_AS_H_
# define __IA32_AS_H_

# define machdep_call_as(_function_)
# define machdep_include_as() \
  d_machdep_as machdep;

typedef struct	d_machdep_as
{
  t_uint32	pd;
}		d_machdep_as;

#endif /* !__IA32_AS_H_ */
