/*
** Physical memory handling: machine-dependent part.
*/

#ifndef __IA32_PM_H_
# define __IA32_PM_H_

# define machdep_call_pm(_function_) machdep_pm_interface._function_()
# define machdep_include_pm()

# include <machdep/segments.h>
# include <pm.h>

i_machdep_pm	machdep_pm_interface;

int	ia32_pm_init(void);

#endif /* !__IA32_PM_H_ */
