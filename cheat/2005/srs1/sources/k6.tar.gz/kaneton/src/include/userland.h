#ifndef __USERLAND_H_
# define __USERLAND_H_

int	userland_ls(int argc, char **argv);
int	userland_lside(int argc, char **argv);
int	userland_lspart(int argc, char **argv);
int	userland_mount(int argc, char **argv);
int	userland_mkdir(int argc, char **argv);
int	userland_rm(int argc, char **argv);
int	userland_sh(int argc, char **argv);
int	userland_touch(int argc, char **argv);
int	userland_uname(int argc, char **argv);

#endif /* !__USERLAND_H_ */
