
#ifndef _PAGE_TABLE_H_
# define _PAGE_TABLE_H_

# include <paging.h>

# define MASK_PT_NOTPRESENT	0x0
# define MASK_PT_PRESENT	0x1
# define MASK_PT_WRITE		0x2
# define MASK_PT_USER		0x4
# define MASK_PT_WRITE_THROUGH	0x8
# define MASK_PT_CACHE_DIS	0x10
# define MASK_PT_ACCESSED	0x20
# define MASK_PT_DIRTY		0x40
# define MASK_PT_ZERO		0x80
# define MASK_PT_GLOBAL_PAGE	0x100

# define MASK_PT_CUST		0x00000007
# define MASK_PT_ADDR		0x000FFFFF

// PAGE TABLE FLAGS
# define FL_PT_PRESENT		0x1
# define FL_PT_WRITE		0x2
# define FL_PT_USER		0x4
# define FL_PT_WRITE_THROUGH	0x8
# define FL_PT_CACHE_DISABLED	0x10
# define FL_PT_ACCESSED		0x20
# define FL_PT_DIRTY		0x40
# define FL_PT_ZERO		0x80
# define FL_PT_GLOBAL_PAGE	0x100


/*
** PT functions
*/

void	init_pt(void *pt_addr);

void	insert_pt_entry(void		*paddr,
			unsigned long	custom, 
			unsigned long	flags,
			struct x86_pte	*pt_addr,
			int		entry);

void	delete_pt_entry(struct x86_pte	*pt_addr, 
			int		entry);


#endif /* !_PAGE_TABLE_H_ */
