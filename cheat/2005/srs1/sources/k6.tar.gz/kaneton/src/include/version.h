#ifndef __VERSION_H_
# define __VERSION_H_

const char *version(void);

#endif /* !__VERSION_H_ */
