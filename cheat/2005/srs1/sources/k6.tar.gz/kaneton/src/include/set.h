#ifndef SET_H_
# define SET_H_

# include <types.h>
# include <set-types.h>
# include <stdlib.h>
# include <stdio.h>


# define NBSET	100

# define FOREACH_FORWARD	0x01
# define FOREACH_BACKWARD	0x02
# define SET_FOREACH(_mode_, _setid_, _iterator_)			\
	for ((_iterator_)->id = ID_UNUSED,				\
	     (_iterator_)->addr = NULL;					\
	     ((ITERATOR_UNUSED((_iterator_)) == 0) ?			\
	      ((_mode_) == FOREACH_FORWARD ?				\
	       set_head((_setid_), (_iterator_)) :			\
	       set_tail((_setid_), (_iterator_)))  :			\
	      ((_mode_) == FOREACH_FORWARD ?				\
	       set_next((_setid_), *(_iterator_), (_iterator_)) :	\
	       set_prev((_setid_), *(_iterator_), (_iterator_)))) == 0;	\
	     )


/* src/set/set.c */

t_set	*set_find(t_setid);
int	set_init(void);
t_type	set_choose_type(t_sort, size_t, t_setsz);
int	set_rsv(t_type, t_sort, size_t, t_setsz, t_setid *);
int	set_rel(t_setid);
int	set_get(t_setid, t_id, t_iterator *);
int	set_head(t_setid, t_iterator *);
int	set_tail(t_setid, t_iterator *);
int	set_prev(t_setid, t_iterator, t_iterator *);
int	set_next(t_setid, t_iterator, t_iterator *);
int	set_delete(t_setid, t_id);
int	set_clean(void);
int	set_display(t_setid);

/* SET_SORT_ENABLE  | SET_SORT_DISABLE */
int	set_insert(t_setid, void *);
int	set_insert_id(t_setid, void *, t_id *);

/* SET_SORT_MANUAL */
int	set_insert_head(t_setid, void *);
int	set_insert_tail(t_setid, void *);
int	set_insert_before(t_setid, t_id, void *);
int	set_insert_after(t_setid, t_id, void *);

#endif
