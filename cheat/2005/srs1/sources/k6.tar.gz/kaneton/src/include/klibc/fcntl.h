#ifndef __FCNTL_H_
# define __FCNTL_H_

# define O_CREAT	0x01
# define O_UNLINK	0x02
# define O_CREAT_DIR	0x03

int	open(const char *pathname, int flags);

#endif /* !__FCNTL_H_ */
