#ifndef __SYS_MOUNT_H_
# define __SYS_MOUNT_H_

int	mount(unsigned int source_disk, unsigned int source_part, const char *target);
int	umount(const char *target);

#endif /* !__SYS_MOUNT_H_ */
