#ifndef __STRING_H_
# define __STRING_H_

# include <stddef.h>
# include <types.h>

size_t	strlen(const char *);
char	*strcpy(char *dest, const char *src);
char	*strncpy(char *dest, const char *src, size_t n);
char	*strcat(char *dest, const char *src);
void	*memcpy(void *, const void *, size_t);
void	*memset(void *s, int c, size_t n);
char	*strndup(const char *s, size_t n);
char	*strdup(const char *s);
char	*strchr(const char *s, int c);
void	strtrim(char *s);
int	strcmp(const char *s1, const char *s2);
int	strncmp(const char *s1, const char *s2, size_t n);

#endif /* !__STRING_H_ */
