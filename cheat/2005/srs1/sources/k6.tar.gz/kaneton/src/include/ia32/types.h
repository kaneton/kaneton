#ifndef __IA32_TYPES_H_
# define __IA32_TYPES_H_

/*
** Machine-dependent type definitions.
*/

typedef t_uint32	t_paddr;
typedef t_uint32	t_psize;
typedef t_uint32	t_vaddr;
typedef t_uint32	t_vsize;

#endif
