#ifndef __MM_H_
# define __MM_H_

# include <as.h>
# include <types.h>

int	mm_rsv(t_asid, t_vaddr *, t_vsize);
int	mm_rel(t_asid, t_vaddr, t_vsize);

#endif /* !__MM_H_ */
