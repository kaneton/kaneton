#ifndef SET_TYPES_H_
# define SET_TYPES_H_

# include <stdlib.h>

# define SET_NOERR		 0x00
# define SET_NOTIMPLEMENTED	-0x01
# define SET_ERR_NOTFOUND	-0x02
# define SET_ERR_NOPLACE	-0x03



typedef struct s_set {
  t_setid	setid;
  t_type	type;
  t_sort	sort;
  size_t	objectsz;
  t_setsz	initsz;
  void*		data;
  t_id		nextid;
  t_setsz	nbelt;
} t_set;


/*
** array
** SET_TYPE_ARRAY 0x2
*/
typedef struct s_array {
  t_iterator		*it;
} t_array;

int	array_resize(t_set *);
int	array_rsv(t_set *);
int	array_rel(t_set *);
int	array_get(t_set *, t_id, t_iterator *);
int	array_head(t_set *, t_iterator *);
int	array_tail(t_set *, t_iterator *);
int	array_prev(t_set *, t_iterator, t_iterator *);
int	array_next(t_set *, t_iterator, t_iterator *);
int	array_insert(t_set *, void*);
int	array_delete(t_set *, t_id);
int	array_insert_head(t_set *, void *);
int	array_insert_tail(t_set *, void *);
int	array_insert_before(t_set *, t_id, void *);
int	array_insert_after(t_set *, t_id, void *);
int	array_display(t_set *);


/*
** simple chained list
**  SET_TYPE_LIST 0x3
*/
typedef struct s_slist {
  t_iterator		*it;
  struct s_slist	*next;
} t_slist;



int     slist_rsv(t_set *);
int     slist_rel(t_set *);
int     slist_get(t_set *, t_id, t_iterator *);
int     slist_head(t_set *, t_iterator *);
int     slist_tail(t_set *, t_iterator *);
int     slist_prev(t_set *, t_iterator, t_iterator *);
int     slist_next(t_set *, t_iterator, t_iterator *);
int     slist_insert(t_set *, void*);
int     slist_delete(t_set *, t_id);
int     slist_insert_head(t_set *, void *);
int     slist_insert_tail(t_set *, void *);
int     slist_insert_before(t_set *, t_id, void *);
int     slist_insert_after(t_set *, t_id, void *);
int     slist_display(t_set *);


/*
** double chained list
**  SET_TYPE_DLIST 0x4
*/
typedef struct s_dlist {
  t_iterator		*it;
  struct s_dlist	*next;
  struct s_dlist	*prev;
} t_dlist;



int     dlist_rsv(t_set *);
int     dlist_rel(t_set *);
int     dlist_get(t_set *, t_id, t_iterator *);
int     dlist_head(t_set *, t_iterator *);
int     dlist_tail(t_set *, t_iterator *);
int     dlist_prev(t_set *, t_iterator, t_iterator *);
int     dlist_next(t_set *, t_iterator, t_iterator *);
int     dlist_insert(t_set *, void*);
int     dlist_delete(t_set *, t_id);
int     dlist_insert_head(t_set *, void *);
int     dlist_insert_tail(t_set *, void *);
int     dlist_insert_before(t_set *, t_id, void *);
int     dlist_insert_after(t_set *, t_id, void *);
int     dlist_display(t_set *);




/*
** binary tree
**  SET_TYPE_BTREE 0x5
*/
typedef struct s_btree {
  t_iterator		*it;
  struct s_btree	*left;
  struct s_btree	*right;
  /* This structure needs to be updated.*/
  /* This is for a binary tree, not a real B-Tree*/
} t_btree;


#endif /* SET_TYPES_H_ */
