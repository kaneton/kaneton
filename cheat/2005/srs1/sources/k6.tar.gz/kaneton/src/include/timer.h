/* PC timer handling */
/* It uses IRQ 0 */

#ifndef __TIMER_H_
# define __TIMER_H_

/** 82c54 clock frequency */
#define I8254_MAX_FREQ 1193180

/* Ports to communicate with the 82c54 */
#define I8254_TIMER0  0x40
#define I8254_TIMER1  0x41
#define I8254_TIMER2  0x42
#define I8254_CONTROL 0x43


int	k_timer_set_freq(unsigned int freq);
int	k_timer_init();

#endif
