#ifndef CRT_H_
# define CRT_H_

typedef struct s_env
{
  int	errno;
  int	exit;
  char	**environ;
} t_env;




#endif /* !CRT_H_ */
