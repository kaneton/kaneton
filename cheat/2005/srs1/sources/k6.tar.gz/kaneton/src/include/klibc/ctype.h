#ifndef __CTYPE_H_
# define __CTYPE_H_

int	tolower(int c);
int	toupper(int c);

#endif /* !__CTYPE_H_ */
