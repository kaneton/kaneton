#ifndef __TEST_H_
# define __TEST_H_

void	k_div_zero();
int	k_timer_display();
void	k_test_cursor();
int	k_date_display();
void	showkey(_t_keyboard);

#endif
