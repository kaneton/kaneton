#ifndef __PIC_H_
# define __PIC_H_

# include <machdep/pic.h>

#endif /* !__PIC_H_ */
