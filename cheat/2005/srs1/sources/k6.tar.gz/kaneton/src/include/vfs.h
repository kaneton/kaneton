#ifndef __VFS_H_
# define __VFS_H_

# define MAXPATHLEN 4096

struct		s_mountpoint
{
  unsigned int	disk;
  unsigned int	part;
  char		name[MAXPATHLEN];
};

struct		s_file
{
  unsigned int	disk;
  unsigned int	part;
  int		fd;
  void		*fs_file;
};

int	vfs_init(void);
int	vfs_mount_init(void);
struct s_file	*vfs_file_new(unsigned int disk, unsigned int part);
int	vfs_list(void);
struct s_dir	*opendir_flags(const char *name, int flags);

#endif /* !__VFS_H_ */
