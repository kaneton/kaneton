/*
** Kaneton by {aita_a,avrill_m,bert_o,chatil_h,hugues_p}@epita.fr
**
** $Id$
*/

int	k_kernel_load(multiboot_info_t*);
