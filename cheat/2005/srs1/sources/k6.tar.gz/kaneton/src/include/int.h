#ifndef __INT_H_
# define __INT_H_

# include <machdep/int.h>

#endif /* !__INT_H_ */
