/*
** Memory paging header
*/

#ifndef _PAGING_H_
# define _PAGING_H_

#include <multiboot.h>

int k_paging_setup(multiboot_info_t *mbi);

# define PAGE_SIZE	4096
# define ADDR_PD	0x3000
# define ADDR_PTI	0x4000
# define ADDR_PTK	0x6000
# define ADDR_PTM	0x7000
# define ADDR_PTT	0x8000
# define ADDR_PTH	0x9000
# define ADDR_GDT	0xA000
# define ADDR_PTAP	0xB000

# define ADDR_V_KERNEL	0xC0000000
# define ADDR_V_PMTAB	0x2000000
# define ADDR_P_PMTAB	0x800000


# define PAGING_FLAG     0x80000000

/** The structure of a page directory entry. See Intel vol 3 section
    3.6.4 */
struct x86_pde
{
  unsigned long int present        :1; /* 1=PT mapped */
  unsigned long int write          :1; /* 0=read-only, 1=read/write */
  unsigned long int user           :1; /* 0=supervisor, 1=user */
  unsigned long int write_through  :1; /* 0=write-back, 1=write-through */
  unsigned long int cache_disabled :1; /* 1=cache disabled */
  unsigned long accessed           :1; /* 1=read/write access since last clear */
  unsigned long zero               :1; /* Intel reserved */
  unsigned long page_size          :1; /* 0=4kB, 1=4MB or 2MB (depending on PAE) */
  unsigned long global_page        :1; /* Ignored (Intel reserved) */
  unsigned long custom             :3; /* Do what you want with them */
  unsigned long pt_paddr           :20;
} __attribute__ ((packed));

/** The structure of a page table entry. See Intel vol 3 section
    3.6.4 */
struct x86_pte
{
  unsigned long present        :1; /* 1=PT mapped */
  unsigned long write          :1; /* 0=read-only, 1=read/write */
  unsigned long user           :1; /* 0=supervisor, 1=user */
  unsigned long write_through  :1; /* 0=write-back, 1=write-through */
  unsigned long cache_disabled :1; /* 1=cache disabled */
  unsigned long accessed       :1; /* 1=read/write access since last clear */
  unsigned long dirty          :1; /* 1=write access since last clear */
  unsigned long zero           :1; /* Intel reserved */
  unsigned long global_page    :1; /* 1=No TLB invalidation upon cr3 switch
                                   (when PG set in cr4) */
  unsigned long custom         :3; /* Do what you want with them */
  unsigned long paddr          :20;
} __attribute__ ((packed));


/** Structure of the x86 CR3 register: the Page Directory Base
    Register. See Intel x86 doc Vol 3 section 2.5 */
struct x86_pdbr
{
  unsigned long zero1          :3; /* Intel reserved */
  unsigned long write_through  :1; /* 0=write-back, 1=write-through */
  unsigned long cache_disabled :1; /* 1=cache disabled */
  unsigned long zero2          :7; /* Intel reserved */
  unsigned long pd_paddr       :20;
} __attribute__ ((packed));

/**
 * Helper macro to control the MMU: invalidate the whole TLB. See
 * Intel x86 vol 3 section 3.7.
 */
#define flush_tlb() \
  do { \
        unsigned long tmpreg; \
        __asm__ volatile ("movl %%cr3,%0\n\tmovl %0,%%cr3" :"=r" \
                     (tmpreg) : :"memory"); \
  } while (0)


/**
 * Helper macro to control the MMU: invalidate the TLB entry for the
 * page located at the given virtual address. See Intel x86 vol 3
 * section 3.7.
 */
#define invlpg(vaddr) \
  do { \
       __asm__ volatile ("invlpg %0"::"m"(*((unsigned *)(vaddr)))); \
  } while(0)

/**
 * Helper macro to compute the index in the PD for the given virtual
 * address
 */
#define VIRT_TO_PD_INDEX(vaddr) \
  (((unsigned)(vaddr)) >> 22)


/**
 * Helper macro to compute the index in the PT for the given virtual
 * address
 */
#define VIRT_TO_PT_INDEX(vaddr) \
  ( (((unsigned)(vaddr)) >> 12) & 0x3ff )


/**
 * Helper macro to compute the offset in the page for the given virtual
 * address
 */
#define VIRT_TO_PAGE_OFFSET(vaddr) \
  (((unsigned)(vaddr)) & SOS_PAGE_MASK)

/**
 * Helper macro to know if a pd entry is present
 */

#define PD_PRESENT(addr, entry) \
  (((struct x86_pde *)addr)[entry].present & MASK_PD_PRESENT)

/**
 * Helper macro to know if a pt entry is present
 */

#define PT_PRESENT(addr, entry) \
  (((struct x86_pte *)addr)[entry].present & MASK_PT_PRESENT)


#define PT_GET_ADDRESS(entry) \
  (((ADDR_PTT[entry].paddr << 22) & 0xFFC00000) + (((ADDR_PTT[entry].paddr)[0].paddr) << 12) & 0x003FF000)

/**
 * Functions used in init
 */

void make_pt_identity(struct x86_pte *pt_paddr);
void make_pt_PMarea(struct x86_pte *pt_paddr, unsigned int size);




#endif /* !_PAGING_H_ */
