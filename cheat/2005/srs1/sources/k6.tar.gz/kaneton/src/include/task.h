#ifndef __TASK_H_
# define __TASK_H_

typedef struct	s_task
{
  int		tskid;
  t_tskid	ptskid;
  t_asid	asid;

  t_setid	threads;
  t_setid	children;

  t_class	class;
  t_behav	behav;
  t_prior	prior;

  t_status	sched;

  t_wait	wait;
  t_setid	waitlist;
}		t_task;

int	task_init(void);
int	task_rsv(t_class class, t_behav behav, t_prior prior, t_tskid *tskid);
int	task_setid(t_setid *setid);
int	task_prior(t_tskid tskid, t_prior *prior);
int	task_grade(t_tskid tskid, t_prior prior);
int	task_wait(t_tskid tskid, t_wait *wait);
int	task_get(t_tskid tskid, t_task **task);
int	task_rel(t_tskid tskid);
int	task_clone(t_tskid old, t_tskid *new);
int	task_asid(t_tskid tskid, t_asid *asid);
int	task_ownid(t_tskid tskid, t_ownid *ownid);
int	task_give(t_tskid tskid, t_ownid ownid);
int	task_run(t_tskid tskid);
int	task_stop(t_tskid tskid);
int	task_exit(t_tskid tskid);
int	task_clean(void);

#endif /* !__TASK_H_ */
