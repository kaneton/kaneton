#ifndef _MODULES_H_
# define _MODULES_H_

# include <types.h>
# include <as.h>
# include <set.h>
# include <string.h>
# include <multiboot.h>

# define MOD_GRUB	0x10
# define MOD_SELF	0x00

# define MOD_LOADED	0x20
# define MOD_UNLOADED	0x00

# define MOD_ERROR	-0x01
# define MOD_OK		 0x00

# define MOD_VIRT_ADDR	0x08000000

typedef struct s_module
{
  void		*mod_start;
  void		*mod_end;
  char		*path;
  char		loaded;
  char		type;
  t_lifetime	lifetime;
  t_asid	asid;
} t_module;

int	mod_parse_mbi(t_paddr);
int	mod_init(t_paddr);
int	mod_add(char *, t_lifetime, t_modid *);
int	mod_remove(t_modid);
int	mod_load(t_modid, t_asid);
int	mod_unload(t_asid);
int	mod_reload(t_modid, t_asid);
int	mod_entry(t_modid, t_vaddr *);
int	mod_function(t_modid, char*, t_vaddr *);
int	mod_clean();

#endif /* !_MODULE_H_ */
