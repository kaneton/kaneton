/*
** Macros for machine dependence handling.
*/

#ifndef __IA32_MACHDEP_H_
# define __IA32_MACHDEP_H_

# define machdep_call(_mng_, _function_) \
  machdep_call_##_mng_(_function_)

# define machdep_include(_object_) \
  machdep_include_##_object_()

#endif /* !__IA32_MACHDEP_H_ */
