/*
** Definitions for segments library
*/

#ifndef SEGMENTS_H
# define SEGMENTS_H_

# include <types.h>

# define SEGID_UNUSED	((t_segid) -1)


/* 
** initialize segmentation
*/
int	seg_init(void);


/* 
** add a segment.
** pl is used to describle priviledge and access leve.
** type is used define if it's a TSS or MEM segment.
** segid is filled by the function with the id of the segment newly added.
** 
*/
int	seg_add(t_paddr start, t_psize size, t_pl pl, t_segtype type, t_segid *segid);


/* 
** edit the segment designated by segid
*/
int	seg_modify(t_segid segid, t_paddr start, t_psize size, t_pl pl, t_segtype type);


/* 
** delete the segment designated by segid
*/
int	seg_remove(t_segid segid);


/* 
** clear the segmentation. 
** You need to call seg_init again if you need to use segmentation again.
*/
int	seg_clear(void);

void	print_gdt(void);


#endif /* SEGMENTS_H_ */
