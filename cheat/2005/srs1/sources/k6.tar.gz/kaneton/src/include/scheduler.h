#ifndef SCHEDULER_H_
# define SCHEDULER_H_

# include <types.h>
# include <as.h>
# include <set.h>

# define QUANTUM_DEFAULT	10

struct		s_ctx
{
  t_uint16	gs;
  t_uint16	fs;
  t_uint16	es;
  t_uint16	ds;
  t_uint16	ss;
  t_uint16	reserved;
  t_uint32	eax;
  t_uint32	ebx;
  t_uint32	ecx;
  t_uint32	edx;
  t_uint32	esi;
  t_uint32	edi;
  t_uint32	ebp;
  t_uint32	error_code;
  t_vaddr	eip;
  t_uint32	cs;
  t_uint32	eflags;
} __attribute__ ((packed));

typedef struct	s_wait
{
  union
  {
    t_tskid	tskid;
    t_thrid	thrid;
  }		id;
  t_status	status;
  t_uint32	value;
}		t_wait;

# define WAIT_TSKID(_wait_)	(_wait_).id.tskid
# define WAIT_THRID(_wait_) 	(_wait_).id.thrid
# define WAIT_STATUS(_wait_) 	(_wait_).status
# define WAIT_VALUE(_wait) 	(_wait_).value

typedef struct	s_sched
{
  t_quantum	quantum;
  t_setid	run;
  t_thrid	thrid;
}		t_sched;

int	sched_init(t_quantum quantum);
int	sched_init_default(void);
int	sched_quantum(t_quantum quantum);
int	sched_yield(void);
int	sched_next(t_thrid*);
int	sched_sched(void);
int	sched_switch(t_thrid);
int	sched_thrid(t_thrid*);
int	sched_clean(void);

int	thread1_start(void);
void	ctx_switch(struct s_ctx **from_ctx, struct s_ctx *to_ctx);

#endif /* SCHEDULER_H_ */
