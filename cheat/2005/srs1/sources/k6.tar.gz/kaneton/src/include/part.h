#ifndef PART_H_
# define PART_H_

# include <stddef.h>
# include <vfs.h>

# define FAT_FUNCTIONS	fat_mount, fat_opendir, fat_readdir, fat_closedir, fat_open, fat_read, fat_close, fat_unlink
# define NULL_FUNCTIONS	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL

struct		s_mbr_entry
{
  unsigned char	bootable;
  unsigned char	begin_heads;
  unsigned char	begin_sectors;
  unsigned char	begin_cylinders;
  unsigned char	id;
  unsigned char	end_heads;
  unsigned char	end_sectors;
  unsigned char	end_cylinders;
  unsigned int	starting_sector;
  unsigned int	nr_of_sectors;
} __attribute__ ((packed));

struct			s_part
{
  struct s_mbr_entry	mbr_entry;
  void			*fs;
};

struct		s_part_type
{
  unsigned char	id;
  char		*descr;
  int		(*mount)(unsigned int source_disk, unsigned int source_part, const char *target);
  struct s_dir	*(*opendir)(struct s_dir *dir, const char *name, int flags);
  struct dirent	*(*readdir)(struct s_dir *dir);
  int		(*closedir)(struct s_dir *dir);
  int		(*open)(unsigned int disk, unsigned int part, const char *pathname, int flags);
  ssize_t	(*read)(struct s_file *file, void *buf, size_t count);
  int		(*close)(struct s_file *file);
  int		(*unlink)(unsigned int disk, unsigned int part, const char *pathname);
};

int	part_init(void);
int	part_list(void);

#endif /* !PART_H_ */
