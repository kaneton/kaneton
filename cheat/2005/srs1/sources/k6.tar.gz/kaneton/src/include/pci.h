#ifndef _PCI_H_
# define _PCI_H_

# include <types.h>
# include <string.h>

# define PCI_MAX_BUS		5
# define PCI_BUS_MAX_DEV	32
# define PCI_MAX_ADDR		6
# define PCI_MAX_FUN		8


# define PCI_UNIT_MASK		0xFFFF0000
# define PCI_VENDOR_MASK	0x0000FFFF

# define PCI_BCLASS_MASK	0xFF000000
# define PCI_SCLASS_MASK	0x00FF0000
# define PCI_PROGIF_MASK	0x0000FF00


# define PCI_CONF_REG_ID	0
# define PCI_CONF_REG_CLASS	2
# define PCI_CONF_REG_BADDR	4
# define PCI_CONF_REG_IRQ	8

# define PCI_NO_UNIT		0xFFFF

# define PCI_CONF_ADDR_PORT	0xCF8
# define PCI_CONF_DATA_PORT	0xCFC

enum	e_pci_type
{
	PCI_IOPORT_ADDR,
	PCI_MEMORY_ADDR,
	PCI_EMPTY
};

union		u_addr
{
  unsigned int	ioaddr;
  void		*memaddr;
};

typedef struct		s_pci_conf_addr {
  int			type     : 2;
  int			reg      : 6;
  int			func     : 3;
  int		        unit     : 5;
  int			bus      : 8;
  int			reserved : 7;
  int			ecd      : 1;
} t_pci_conf_addr  __attribute__((packed));

typedef struct		s_pci_unit_conf {
  enum e_pci_type	type;
  union u_addr		addr;
} t_pci_unit_conf;

typedef struct s_pci_unit {
  t_uint16		pci_id;
  t_uint16		vendor_id;
  t_uint8		base_class;
  t_uint8		sub_class;
  t_uint8		prog_if;
  t_uint8		irq;
  t_pci_unit_conf	conf[PCI_MAX_ADDR];
} t_pci_unit;


/*
**  Structures for pci listings.
*/
typedef struct s_pci_vendor
{
  unsigned short vendor_id ;
  char *	 vendor_shortname ;
  char *         vendor_fullname ;
} t_pci_vendor;

typedef struct s_pci_device
{
  unsigned short vendor_id ;
  unsigned short device_id ;
  char *	   chip ;
  char *	   chip_desc;
} t_pci_device;

typedef struct s_pci_class_code
{
  unsigned char	base_class;
  unsigned char	sub_class;
  unsigned char	prog_if;
  char *        base_desc;
  char *        sub_desc;
  char *	prog_desc;
}  t_pci_class_code;

/*
** defines for pci listings
*/
#define	PCI_NB_VENDOR		(sizeof (pci_vendors) / sizeof (struct s_pci_vendor))
#define	PCI_NB_DEVICE		(sizeof (pci_devices) / sizeof( struct s_pci_device))
#define	PCI_NB_CLASS_CODE	(sizeof (pci_class_codes) / sizeof (struct s_pci_class_code))
#define	PCI_COMMAND_FLAGS_LEN	(sizeof (pci_commands_flags) / sizeof (char *))
#define	PCI_STATUS_FLAGS_LEN	(sizeof (pci_status_flags) / sizeof (char *))
#define	PCI_DEV_SEL_FLAGS_LEN	(sizeof (pci_dev_sel_flags) / sizeof (char *))


/*
** prototypes for functions in drivers/pci.c
*/
int		lspci(int argc, char **argv);
void		pci_show_unit_small(t_pci_unit *);
void		pci_show_unit(t_pci_unit *, int);
/* static t_uint32	pci_read_bus(t_pci_conf_addr);*/
int		pci_scan_bus(unsigned int);


#endif /* ! _PCI_H_ */
