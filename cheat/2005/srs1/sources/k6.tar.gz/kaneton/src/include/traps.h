#ifndef __TRAPS_H_
# define __TRAPS_H_

# include <types.h>
# include <set.h>
# include <int.h>

# define TRAP_INT_00	0x000
# define TRAP_INT_01	0x001
# define TRAP_INT_02	0x002
# define TRAP_INT_03	0x003
# define TRAP_INT_04	0x004
# define TRAP_INT_05	0x005
# define TRAP_INT_06	0x006
# define TRAP_INT_07	0x007
# define TRAP_INT_08	0x008
# define TRAP_INT_09	0x009
# define TRAP_INT_10	0x010
# define TRAP_INT_11	0x011
# define TRAP_INT_12	0x012
# define TRAP_INT_13	0x013
# define TRAP_INT_14	0x014
# define TRAP_INT_15	0x015
# define TRAP_INT_16	0x016
# define TRAP_INT_17	0x017
# define TRAP_INT_18	0x018

# define TRAP_IRQ_00	0x100
# define TRAP_IRQ_01	0x101
# define TRAP_IRQ_02	0x102
# define TRAP_IRQ_03	0x103
# define TRAP_IRQ_04	0x104
# define TRAP_IRQ_05	0x105
# define TRAP_IRQ_06	0x106
# define TRAP_IRQ_07	0x107
# define TRAP_IRQ_08	0x108


int	 trap_init(void);
int	 trap_load_idt(void);
int	 trap_add(t_pl, t_trapid, t_behave);
int	 trap_clean(void);
int	 trap_grade(t_trapid, t_pl);
t_pl	 trap_pl(t_trapid);
int	 trap_subscribe(t_trapid, t_tskid);
int	 trap_unsubscribe(t_trapid, t_tskid);
int	 trap_unsubscribe_all(t_tskid);
int	 trap_setbehave(t_trapid, t_behave behave);
t_behave trap_getbehave(t_trapid);
int	 trap_delbehave(t_trapid);
void	 trap_display(void);

#endif
