#ifndef __IO_H_
#define __IO_H_

inline static void	outb(unsigned char value, unsigned short port)
{
  __asm__ volatile ("outb %%al, %%dx"::"d" (port), "a" (value));
}

inline static void	outw(unsigned int value, unsigned short port)
{
  __asm__ volatile ("outw %%ax, %%dx"::"d" (port), "a" (value));
}

inline static void	outl(unsigned long value, unsigned short port)
{
  __asm__ volatile ("outl %%eax, %%dx"::"d" (port), "a" (value));
}

inline static unsigned char	inb(unsigned short port)
{
  unsigned char			value;

  __asm__ volatile ("inb %%dx, %%al" : "=a" (value) : "d" (port));
  return value;
}

inline static unsigned int	inw(unsigned short port)
{
  unsigned int			value;

  __asm__ volatile ("inw %%dx, %%ax" : "=a" (value) : "d" (port));
  return value;
}

inline static unsigned long	inl(unsigned short port)
{
  unsigned long			value;

  __asm__ volatile ("inl %%dx, %%eax" : "=a" (value) : "d" (port));
  return value;
}

#define outbp(value, port) \
  __asm__ volatile ("outb %%al,%%dx; jmp 1f; 1:"::"d" (port), "a" (value));

#endif /* !__IO_H_ */
