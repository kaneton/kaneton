/*
** IRQs and PIC handling 
*/

#ifndef __IA32_PIC_H_
# define __IA32_PIC_H_

/* PIC ports */

# define PIC_MASTER 0x20
# define PIC_SLAVE  0xa0

# define IRQ_BASE	32
# define IRQ_NUM	16

/*
** prototypes 
*/
int	pic_init(void);
int	pic_enable(unsigned char);
int	pic_disable(unsigned char);
int	k_irq_set_handler(unsigned char, void *);
int	pic_clear(void);

#endif /* !__IA32_PIC_H_ */
