#ifndef __VM_H_
# define __VM_H_

# include <types.h>
# include <as.h>

# define VM_ATTR_EXEC	0x0
# define VM_ATTR_READ	0x1
# define VM_ATTR_WRITE	0x2

# define VM_FLAG_ANY		0x0
# define VM_FLAG_SPECIFIC	0x1
# define VM_FLAG_FORCE		0x10
# define VM_FLAG_PDALLOC	0x20

typedef t_uint8		t_vattr;
typedef t_uint16	t_vmflags;

int	vm_init(void);
int	vm_rsv(t_asid, t_vaddr *, t_vsize, t_vmflags);
int	vm_rel(t_asid, t_vaddr, t_vsize);
int	vm_attr(t_asid asid, t_vaddr, t_vsize, t_vattr);
int	vm_map(t_asid, t_paddr, t_vaddr, t_vsize);
int	vm_unmap(t_asid, t_vaddr, t_vsize);
int	vm_copy(t_asid, t_vaddr, t_asid, t_vaddr, t_vsize);
int	vm_flush(t_asid asid);
int	vm_clear(void);
int	vm_mm_rsv(t_asid asid, t_vaddr *vaddr, t_vsize npages, t_vmflags flags);
int	vm_mm_rel(t_asid asid, t_vaddr vaddr, t_vsize npages);

#endif /* !__VM_H_ */
