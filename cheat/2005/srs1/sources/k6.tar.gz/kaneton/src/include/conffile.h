#include <multiboot.h>
#include <modules.h>

#ifndef _CONFFILE_H_
# define _CONFFILE_H_

# define NBMODULES	4


# define SM_ACTIVATION(mod, smod)	_modules[mod]._smodules[smod]._activated
# define S_ACTIVATION(mod)		_modules[mod]._activated

typedef struct _s_smodules
{
  unsigned char		*_name;
  unsigned char		_activated;
} _t_smodules;


typedef struct _s_modules
{
  unsigned char		*_name;
  unsigned char		_activated;
  _t_smodules		_smodules[5];
} _t_modules;


short	get_name(char **);
short	get_sname(char **, unsigned int);
int	look_for_smod(short mod, char **);
int	load_configuration_file(module_t *);
void	shell_conffile(unsigned char *);

#endif /* !_CONFILE_H_ */
