/*
** Address space handling
*/

#ifndef __AS_H_
# define __AS_H_

# include <types.h>
# include <machdep/machdep.h>
# include <machdep/as.h>

# define ASID_UNUSED	((t_asid)-1)
# define AS_LIST_SIZE	256
# define AS_DATA_LIST_SIZE	500

typedef t_uint32	t_asid;

# include <vm.h>

struct		s_pas_data
{
  t_paddr	addr; /* physical memory address */
  t_psize	npages;
};

struct			s_vas_data
{
  t_vaddr		vaddr; /* virtual memory address */
  t_paddr		paddr; /* physical memory address */
  t_vsize		npages;
  char			is_mapped;
  t_vattr		attr;
  struct s_vas_data	*next;
};

/*
** The t_as structure
*/
typedef struct		s_as
{
  t_asid		asid;
  t_tskid		tskid;
  t_ownid		ownid;
  t_modid		modid;
  struct s_mpage	*mfirst;		// for malloc
  struct s_pas_data	*pas[AS_DATA_LIST_SIZE];
  struct s_vas_data	*vas[AS_DATA_LIST_SIZE];
  struct s_vas_data	*vas_list;
  struct x86_pde	*pd_addr;
  /* machdep_include(as); */
}			t_as;

extern t_as	kas;

/*
** Init address spaces management
*/
int	as_init(void);
int	as_rsv(t_asid *);
int	as_get(t_asid, t_as **);
int	as_rel(t_asid);
int	as_clone(t_asid, t_asid);
int	as_clear(void);
int	as_print(void);

int	as_synchro_pd(void);
int	as_vm_clear(void);

int	as_pm_add(t_asid, t_paddr, t_psize);
int	as_pm_del(t_asid, t_paddr, t_psize);
int	as_pm_top(t_asid, t_paddr *, t_psize *);

int	as_vm_add(t_asid, t_vaddr *, t_vsize, t_vmflags);
int	as_vm_del(t_asid, t_paddr, t_psize);

int	as_vm_attr(t_asid, t_vaddr, t_vsize, t_vattr);
int	as_vm_attr_get(t_asid, t_vaddr, t_vsize, t_vattr *);

int	as_vaddr_to_paddr(t_asid, t_vaddr, t_paddr *);
int	as_paddr_to_vaddr(t_asid, t_paddr, t_vaddr *);

int	as_tskid(t_asid asid, t_tskid *tskid);
int	as_modid(t_asid asid, t_modid *modid);
int	as_ownid(t_asid asid, t_ownid *ownid);
int	as_give(t_asid asid, t_ownid ownid);
int	as_attach(t_asid asid, t_tskid tskid);
int	as_detach(t_tskid tskid);

// debug
void	dump_as(t_asid asid);
#endif
