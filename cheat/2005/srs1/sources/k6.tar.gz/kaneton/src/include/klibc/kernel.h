#ifndef __KERNEL_H_
# define __KERNEL_H_

void    panic(const char *str);

#endif /* !__KERNEL_H_ */
