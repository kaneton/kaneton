#ifndef __STDLIB_H_
# define __STDLIB_H_

# include <stddef.h>

# define MAX(x, y)	((x) > (y) ? (x) : (y))
# define MIN(x, y)	((x) < (y) ? (x) : (y))

void	*malloc(size_t size);
void	free(void *ptr);
void	*realloc(void *ptr, size_t size);
void	*calloc(size_t nmemb, size_t size);

#endif /* !__STDLIB_H_ */
