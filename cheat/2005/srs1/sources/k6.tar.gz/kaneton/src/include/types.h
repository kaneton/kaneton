#ifndef __TYPES_H_
# define __TYPES_H_


#include <stdio.h>

/*
** Some commonly used types
*/

typedef unsigned char	t_uint8;
typedef signed char	t_sint8;
typedef unsigned short	t_uint16;
typedef signed short	t_sint16;
typedef unsigned int	t_uint32;
typedef signed int	t_sint32;

# include <machdep/types.h>

/*
** Privileges (machine independant)
*/
typedef t_uint16	t_pl;

# define PL_KERNEL	0x00
# define PL_SERVICE	0x01
# define PL_USER	0x02
# define PL_READ	0x04
# define PL_WRITE	0x08
# define PL_EXEC	0x10


/*
** identifiers
*/
typedef t_uint32	t_id;

# define ID_UNUSED   ((t_id)-1)


/*
** IA-32 segment type
*/
typedef t_uint8		t_segtype;

# define SEG_TYPE_MEM	0x00
# define SEG_TYPE_TSS	0x01


/*
** A segment ID
*/
typedef t_uint32	t_segid;


/*
** Flags for physical memory
*/
typedef t_uint16	t_pmflags;


/*
** Hardware event type
*/
typedef t_uint32	t_eventid;

#define EVENTID_UNUSED		ID_UNUSED


/*
** size of a set
*/
typedef t_uint32	t_setsz;


/*
** time for a task during a turn of execution
*/
typedef t_uint16	t_quantum;


/*
** thread identifier
*/
typedef t_id		t_thrid;


/*
** task class
*/
typedef t_uint8		t_class;

# define CLASS_KERNEL		0x01
# define CLASS_DRIVER		0x02
# define CLASS_SERVICE		0x03
# define CLASS_USER		0x04


/*
** behavior of a task
*/
typedef t_uint8		t_behav;

# define BEHAV_KERNEL		0x01
# define BEHAV_REALTIME		0x02
# define BEHAV_INTERACTIVE	0x03
# define BEHAV_TIMESHARING	0x04
# define BEHAV_BACKGROUND	0x05


/*
** priority of a task (as for the thread)
*/
typedef t_uint8		t_prior;

#define PRIOR_KERNEL		230
# define LPRIOR_KERNEL		210
# define HPRIOR_KERNEL		250

#define PRIOR_REALTIME		190
# define LPRIOR_REALTIME	170
# define HPRIOR_REALTIME	210

#define PRIOR_INTERACTIVE	150
# define LPRIOR_INTERACTIVE	130
# define HPRIOR_INTERACTIVE	170

#define PRIOR_TIMESHARING	90
# define LPRIOR_TIMESHARING	50
# define HPRIOR_TIMESHARING	130

#define PRIOR_BACKGROUND	30
# define LPRIOR_BACKGROUND	10
# define HPRIOR_BACKGROUND	50

#define PRIOR_THREAD		130
# define LPRIOR_THREAD		10
# define HPRIOR_THREAD		250


/*
** task identifier
*/
typedef t_id		t_tskid;

# define TSKID_UNUSED		ID_UNUSED


/*
** identifier of a set of elements
*/
typedef t_id		t_setid;

# define TSETID_UNUSED		ID_UNUSED


/*
** describe a state of an entity
*/
typedef t_uint32	t_status;

# define STATUS_RUN		0x01
# define STATUS_STOP		0x02
# define STATUS_MSG		0x03
# define STATUS_ZOMBIE		0x04

# define STATUS_EXITED		0x00
# define STATUS_TERMINATED	0x01


/*
** time of life of a module in memory
*/
typedef t_uint8		t_lifetime;

# define LIFETIME_INFINITE	0x1
# define LIFETIME_FINITE		0x2


/*
** contain data and an identifier for an object in a set
*/
typedef struct	s_iterator
{
  t_id		id;
  void		*addr;
}		t_iterator;

# define ITERATOR_UNUSED(_iterator_)	\
 ((((_iterator_)->id == ID_UNUSED) &&	\
  ((_iterator_)->addr == NULL)) ? 0 : -1)

# define ITERATOR_ID(_iterator_)	\
  (_iterator_)->id

# define ITERATOR_ADDR(_iterator_)	\
  (_iterator_)->addr


/*
** prgram counter
*/
typedef t_vaddr	t_pc;


/*
** stack pointer
*/
typedef t_vaddr	t_sp;


/*
** represent the context of execution (independant of archi)
*/
typedef struct	s_thrctx
{
  t_pc		pc;
  t_sp		sp;
}		t_thrctx;


/*
** identifier for a module
*/
typedef t_id		t_modid;

# define MODID_UNUSED	ID_UNUSED


/*
** type of a set structure
*/
typedef t_uint32	t_type;

# define SET_TYPE_UNUSED 0x0
# define SET_TYPE_ANY	 0x1
# define SET_TYPE_ARRAY	 0x2
# define SET_TYPE_LIST	 0x3
# define SET_TYPE_DLIST	 0x4
# define SET_TYPE_BTREE	 0x5


/*
** kind of sort for a set
*/
typedef t_uint32	t_sort;

# define SET_SORT_ENABLE	0x1
# define SET_SORT_DISABLE	0x2
# define SET_SORT_MANUAL	0x3


/*
** identifier for an owner of the set
*/
typedef t_tskid		t_ownid;

# define OWNID_UNUSED		TSKID_UNUSED

/*
** Types for messages handling
*/


typedef t_uint32 t_trapid;

typedef int (*t_behave) ();

typedef t_uint32 t_msgid;

typedef void * t_data;

typedef t_uint8 t_sbtype;

typedef struct s_trap
{
  t_trapid trapid;
  t_pl pl;
  t_behave behave;
  t_setid lstid;
} t_trap;

typedef struct s_msghd
{
  t_type knty;
  t_type sbty;
  t_tskid srcid;
  t_tskid dstid;
  size_t datasz;
} __attribute__ ((packed)) t_msghd;

typedef struct s_msg
{
  t_msgid msgid;
  t_msghd *msghd;
  t_data  data;
} t_msg;


# define TYPE_NRPL 0x0
# define TYPE_RPL 0x1
# define TYPE_BROAD 0x2
# define TYPE_MULTI 0x4
# define TYPE_UNI 0x8
# define TYPE_IRQ 0x0
# define TYPE_IDENT 0x1


#endif
