#ifndef __SYS_STAT_H_
# define __SYS_STAT_H_

int	mkdir(const char *pathname);
int	rmdir(const char *pathname);

#endif /* !__SYS_STAT_H_ */
