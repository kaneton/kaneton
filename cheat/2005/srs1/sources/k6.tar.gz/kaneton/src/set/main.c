#include <set.h>
#include <stdio.h>

#ifdef TEST
# include <stdlib.h>
#endif

int main()
{
  t_sort	sort = SET_SORT_DISABLE;
  t_type	type = SET_TYPE_ANY;
  t_setid	id;

  int		test = 10;
  int		test1 = 20;
  int		res = 0;
  t_iterator	p;
  t_iterator	q;

  printf ("test %p\ntest1 %p\n", &test, &test1);

  set_init();
  set_rsv(type, sort, sizeof(t_set), 8, &id);
  set_rsv(type, sort, sizeof(int), 8, &id);

  if (sort != SET_SORT_MANUAL)
    {
      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_delete(id, 5);
      printf("delete 5 (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);

      res = set_insert(id, &test);
      printf("insert (%d)\n", res);
    }
  else
    {
      res = set_insert_head(id, &test1);//1
      printf("insert head (%d)\n", res);
      //set_display(id);

      res = set_insert_head(id, &test);//2
      printf("insert head (%d)\n", res);
      //set_display(id);

      res = set_insert_head(id, &test);//3
      printf("insert head (%d)\n", res);
      //set_display(id);

      res = set_insert_tail(id, &test);//4
      printf("insert tail (%d)\n", res);
      //set_display(id);

      res = set_insert_before(id, 4, &test1);//5
      printf("insert before 7 (%d)\n", res);
      //set_display(id);

      res = set_insert_after(id, 3, &test1);//6
      printf("insert after 3 (%d)\n", res);
      //set_display(id);

      res = set_delete(id, 8);
      printf("delete 8 (%d)\n", res);
    }
  set_display(id);

  res = set_head(id, &p);
  printf("head : [%i] %p\n", p.id, p.addr);

  res = set_tail(id, &p);
  printf("tail : [%i] %p\n", p.id, p.addr, res);

  p.id = 3;
  res = set_prev(id, p, &q);
  res == 0 ?
    printf("prev %d : [%i] %p (%d)\n", p.id, q.id, q.addr, res) :
    printf("prev %d : ERROR (%d)\n", p.id, res);

  p.id = 1;
  res = set_prev(id, p, &q);
  res == 0 ?
    printf("prev %d : [%i] %p (%d)\n", p.id, q.id, q.addr, res) :
    printf("prev %d : ERROR (%d)\n", p.id, res);

  p.id = 5;
  res = set_prev(id, p, &q);
  res == 0 ?
    printf("prev %d : [%i] %p (%d)\n", p.id, q.id, q.addr, res) :
    printf("prev %d : ERROR (%d)\n", p.id, res);

  p.id = 5;
  res = set_next(id, p, &q);
  res == 0 ?
    printf("next %d : [%i] %p (%d)\n", p.id, q.id, q.addr, res) :
    printf("next %d : ERROR (%d)\n", p.id, res);

  p.id = 9;
  res = set_next(id, p, &q);
  res == 0 ?
    printf("next %d : [%i] %p (%d)\n", p.id, q.id, q.addr, res) :
    printf("next %d : ERROR (%d)\n", p.id, res);

  p.id = 4;
  res = set_next(id, p, &q);
  res == 0 ?
    printf("next %d : [%i] %p (%d)\n", p.id, q.id, q.addr, res) :
    printf("next %d : ERROR (%d)\n", p.id, res);

  p.id = 1;
  res = set_next(id, p, &q);
  res == 0 ?
    printf("next %d : [%i] %p (%d)\n", p.id, q.id, q.addr, res) :
    printf("next %d : ERROR (%d)\n", p.id, res);

  q.id = 4;
  res = set_get(id, q.id, &p);
  res == 0 ?
    printf("get %d : [%i] %p (%d)\n", q.id, q.id, q.addr, res) :
    printf("get %d : ERROR (%d)\n", q.id, q.id, res);

  q.id = 31;
  res = set_get(id, q.id, &p);
  res == 0 ?
    printf("get %d : [%i] %p (%d)\n", q.id, q.id, q.addr, res) :
    printf("get %d : ERROR (%d)\n", q.id, res);

  q.id = 1;
  res = set_get(id, q.id, &p);
  res == 0 ?
    printf("get %d : [%i] %p (%d)\n", q.id, q.id, q.addr, res) :
    printf("get %d : ERROR (%d)\n", q.id, res);

  q.id = 9;
  res = set_get(id, q.id, &p);
  res == 0 ?
    printf("get %d : [%i] %p (%d)\n", q.id, q.id, q.addr, res) :
    printf("get %d : ERROR (%d)\n", q.id, res);

  res = set_rel(id);
  printf("rel %d (%d)\n", id, res);
  set_clean();
  return 0;
}
