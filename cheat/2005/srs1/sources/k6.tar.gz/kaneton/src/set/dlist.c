#include <set.h>

int	dlist_rsv(t_set *set)
{
  set->data = NULL;
  return SET_NOERR;
}


int		dlist_rel(t_set *set)
{
  t_dlist	*head = set->data;
  t_dlist	*next;

  while (head != NULL)
    {
      next = head->next;
      free(head->it);
      free(head);
      head = next;
    }
  free(set);
  return SET_NOERR;
}

int	dlist_get(t_set *set, t_id id, t_iterator *iterator)
{
  t_dlist	*head = set->data;

  if (head != NULL)
    {
      while ((head->next != NULL ) && (head->it->id != id))
	head = head->next;

      if (head->it->id != id)
	return SET_ERR_NOTFOUND;
      else
	{
	  iterator->id = id;
	  iterator->addr = head->it->addr;
	}
      return SET_NOERR;
    }
  return SET_ERR_NOTFOUND;
}


int	dlist_head(t_set *set, t_iterator *iterator)
{
  t_dlist	*head = set->data;

  if (head != NULL)
    {
      iterator->id = head->it->id;
      iterator->addr = head->it->addr;
      return SET_NOERR;
    }
  return SET_ERR_NOTFOUND;
}

int	dlist_tail(t_set *set, t_iterator *iterator)
{
  t_dlist	*ptr = set->data;

  if (ptr != NULL)
    {
      while (ptr->next != NULL)
	ptr = ptr->next;

      iterator->id = ptr->it->id;
      iterator->addr = ptr->it->addr;

      return SET_NOERR;
    }
  return SET_ERR_NOTFOUND;
}


int	dlist_prev(t_set *set, t_iterator iterator, t_iterator *piterator)
{
  t_dlist	*ptr = set->data;

  if (ptr != NULL)
    {
      while ((ptr->next != NULL) && (ptr->next->it->id != iterator.id))
	ptr = ptr->next;
      if (ptr->next != NULL)
	{
	  piterator->id = ptr->it->id;
	  piterator->addr = ptr->it->addr;
	  return SET_NOERR;
	}
    }
  return SET_ERR_NOTFOUND;
}


int	dlist_next(t_set *set, t_iterator iterator, t_iterator *piterator)
{
  t_dlist	*ptr = set->data;

  if (ptr != NULL)
    {
      while ((ptr->next != NULL) &&(ptr->it->id != iterator.id))
	ptr = ptr->next;
      if (ptr->next != NULL)
	{
	  piterator->id = ptr->next->it->id;
	  piterator->addr = ptr->next->it->addr;
	  return SET_NOERR;
	}
    }
  return SET_ERR_NOTFOUND;
}


int		dlist_delete(t_set *set, t_id id)
{
  t_dlist	*ptr = set->data;
  t_dlist	*del;

  if (ptr != NULL)
    {
      if (ptr->it->id == id)
	{
	  del = ptr;
	  set->data = ptr->next;
	  if (ptr->next != NULL)
	    ptr->next->prev = NULL;
	  free(del->it);
	  free(del);
	  set->nbelt--;
	  return SET_NOERR;
	}
      while ((ptr->next != NULL) && (ptr->next->it->id != id))
	ptr = ptr->next;

      if (ptr->next != NULL)
	{
	  del = ptr->next;
	  ptr->next->next->prev = ptr;
	  ptr->next = ptr->next->next;
	  free(del->it);
	  free(del);
	  set->nbelt--;
	}
      else
	{
	  /*at this point, we have to delete the last element*/
	  ptr = set->data;
	  while (ptr->next->next != NULL)
	    ptr = ptr->next;
	  if (ptr->next->it->id == id)
	    {
	      del = ptr->next;
	      ptr->next = NULL;
	      free(del->it);
	      free(del);
	      set->nbelt--;
	    }
	  else
	    return SET_ERR_NOTFOUND;
	}
      return SET_NOERR;
    }
  return SET_ERR_NOTFOUND;
}


int		dlist_insert_head(t_set *set, void *d)
{
  t_dlist	*new;

  new = malloc(sizeof(t_dlist));
  new->it = malloc(sizeof(t_iterator));
  new->it->addr = d;
  new->it->id = set->nextid++;
  new->next = set->data;
  new->prev = NULL;
  set->data = new;
  set->nbelt++;
  return SET_NOERR;
}



int		dlist_insert_tail(t_set *set, void *d)
{
  t_dlist	*new;
  t_dlist	*ptr = set->data;

  if (set->data == NULL)
    {
      dlist_insert_head(set, d);
      return SET_NOERR;
    }
  while (ptr->next != NULL)
    ptr = ptr->next;

  new = malloc(sizeof(t_dlist));
  new->it = malloc(sizeof(t_iterator));
  new->it->addr = d;
  new->it->id = set->nextid++;
  new->next = NULL;
  new->prev = ptr;
  ptr->next = new;
  set->nbelt++;
  return SET_NOERR;
}

int		dlist_insert_before(t_set *set, t_id id, void *d)
{
  t_dlist	*new;
  t_dlist	*ptr = set->data;

  while ((ptr != NULL) && (ptr->next->it->id != id))
    ptr = ptr->next;

  if (ptr != NULL)
    {
      new = malloc(sizeof(t_dlist));
      new->it = malloc(sizeof(t_iterator));
      new->it->addr = d;
      new->it->id = set->nextid++;
      new->next = ptr->next;
      new->prev = ptr;
      ptr->next = new;
      set->nbelt++;
      return SET_NOERR;
    }
  else
    return SET_ERR_NOTFOUND;
}

int		dlist_insert_after(t_set *set, t_id id, void *d)
{
  t_dlist	*new;
  t_dlist	*ptr = set->data;

  while ((ptr != NULL) && (ptr->it->id != id))
    ptr = ptr->next;
  if (ptr != NULL)
    {
      new = malloc(sizeof(t_dlist));
      new->it = malloc(sizeof(t_iterator));
      new->it->addr = d;
      new->it->id = set->nextid++;
      new->next = ptr->next;
      new->prev = ptr;
      ptr->next = new;
      set->nbelt++;
      return SET_NOERR;
    }
  else
    return SET_ERR_NOTFOUND;
}


int	dlist_insert(t_set *set, void *d)
{
  if (set->sort == SET_SORT_DISABLE
      || set->sort == SET_SORT_MANUAL
      || set->data == NULL)
    dlist_insert_head(set, d);
   else
    {
      /*fixme ?*/
      dlist_insert_head(set, d);
    }
  return SET_NOERR;
}


int dlist_display(t_set *set)
{
  t_dlist	*ptr = set->data;

  while (ptr != NULL)
    {
      printf("- [%i] %p\n", ptr->it->id, ptr->it->addr);
      ptr = ptr->next;
    }
  return SET_NOERR;
}
