#include <set.h>

int		array_resize(t_set *set)
{
  t_array	*data = NULL;

  set->initsz *= 2;
  data = realloc(set->data, set->initsz * sizeof(t_iterator*));
  set->data = data;
  return SET_NOERR;
}

int	array_rsv(t_set *set)
{
  t_uint32	i = 0;
  t_array	*data;

  data = calloc(set->initsz, sizeof(t_iterator *));
  set->data = data;
  for (i = 0; i < set->initsz; i++)
    data[i].it = NULL;
  return SET_NOERR;
}


int	array_rel(t_set *set)
{
  t_array       *data = set->data;
  t_uint32      i = 0;

  while (i < set->nbelt &&
	 data[i].it != NULL)
    {
      if (data[i].it != NULL)
	free(data[i].it);
      i++;
    }
  free(set->data);
  return SET_NOERR;
}

int	array_get(t_set *set, t_id id, t_iterator *iterator)
{
  t_uint32	i = 0;
  t_array	*data = (t_array *)set->data;
  int		res = SET_NOERR;

  while (i < set->nbelt &&
	 data[i].it != NULL &&
	 data[i].it->id != id &&
	 i < set->nbelt )
    i++;
  if (i < set->nbelt &&
      data[i].it != NULL)
    {
      iterator->id = data[i].it->id;
      iterator->addr = data[i].it->addr;
      res = SET_NOERR;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}

int	array_head(t_set *set, t_iterator *iterator)
{
  t_array	*data = (t_array *)set->data;
  int		res = 0;

  if (data[0].it != NULL)
    {
      iterator->id = data[0].it->id;
      iterator->addr = data[0].it->addr;
      res = SET_NOERR;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}

int		array_tail(t_set *set, t_iterator *iterator)
{
  t_array	*data = (t_array *)set->data;
  t_uint32	i = 0;
  int		res = 0;

  if (data[0].it == NULL)
    res = SET_ERR_NOTFOUND;
  else
    {
      while (i < set->nbelt &&
	     data[i].it != NULL &&
	     i < set->initsz)
	i++;
      iterator->id = data[i - 1].it->id;
      iterator->addr = data[i - 1].it->addr;
      res = SET_NOERR;
    }
  return res;
}


int		array_prev(t_set *set, t_iterator iterator, t_iterator *piterator)
{
  t_array	*data = (t_array *)set->data;
  t_uint32	i = 0;
  int		res = 0;

  while (i < set->nbelt &&
	 data[i].it != NULL &&
	 data[i].it->id != iterator.id)
    i++;
  if (i < set->nbelt && i > 0 && data[i].it != NULL)
    {
      piterator->id = data[i - 1].it->id;
      piterator->addr = data[i - 1].it->addr;
      res = SET_NOERR;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int	array_next(t_set *set, t_iterator iterator, t_iterator *piterator)
{
  t_array	*data = (t_array *)set->data;
  t_uint32	i = 0;
  int		res = 0;

  while (i < set->nbelt &&
	 data[i].it != NULL &&
	 data[i].it->id != iterator.id)
    i++;
  if (i < (set->nbelt - 1) &&
      data[i].it != NULL &&
      data[i + 1].it != NULL)
    {
      piterator->id = data[i + 1].it->id;
      piterator->addr = data[i + 1].it->addr;
      res = SET_NOERR;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}

int		array_insert(t_set *set, void *d)
{
  int		res = 0;
  t_uint32	i = 0;
  t_array	*data = set->data;

  if (set->nbelt == set->initsz)
    {
      array_resize(set);
      data = set->data;
    }
  if (set->sort == SET_SORT_DISABLE)
    {
      while (i < set->nbelt &&
	     data[i].it != NULL)
	i++;
      data[i].it = malloc(sizeof(t_iterator));
      data[i].it->id = set->nextid++;
      data[i].it->addr = d;
      set->nbelt++;
      res = SET_NOERR;
      goto end;
    }
  if (set->sort == SET_SORT_ENABLE)
    {
      while (i < set->nbelt &&
	     data[i].it != NULL &&
	     data[i].it->id < set->nextid)
	i++;
      if (i == 0)
	{
	  res = array_insert_head(set, d);
	  goto end;
	}
      if (i == set->nbelt)
	{
	  res = array_insert_tail(set, d);
	  goto end;
	}
      if (i < set->initsz)
	{
	  res = array_insert_before(set, data[i].it->id, d);
	  goto end;
	}
      res = SET_ERR_NOPLACE;
      goto end;
    }
 end:
  return res;
}

int		array_delete(t_set *set, t_id id)
{
  t_array	*data = set->data;
  t_uint32	i = 0;
  int		res = 0;

  while (i < set->nbelt &&
	 data[i].it != NULL &&
	 data[i].it->id != id)
    i++;
  if (i < set->nbelt &&
      data[i].it != NULL &&
      data[i].it->id == id)
    {
      free(data[i].it);
      while (i < set->nbelt - 1 &&
	     data[i].it != NULL)
	{
	  data[i].it  = data[i + 1].it;
	  i++;
	}
      set->nbelt--;
      res = SET_NOERR;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}

int		array_insert_head(t_set *set, void *d)
{
  t_array	*data = (t_array *)set->data;
  t_uint32	i = 0;
  int		res = 0;

  if (set->nbelt < set->initsz)
    {
      array_resize(set);
      data = set->data;
    }
  for (i = set->nbelt; i > 0; i--)
    data[i].it = data[i - 1].it;
  data[0].it = malloc(sizeof(t_iterator));
  data[0].it->id = set->nextid++;
  data[0].it->addr = d;
  set->nbelt++;
  res = SET_NOERR;
  return res;
}

int		array_insert_tail(t_set *set, void *d)
{
  t_array	*data = set->data;
  int		res = 0;

  if (set->nbelt < set->initsz)
    {
      array_resize(set);
      data = set->data;
    }
  data[set->nbelt].it = malloc(sizeof(t_iterator));
  data[set->nbelt].it->id = set->nextid++;
  data[set->nbelt].it->addr = d;
  set->nbelt++;
  res = SET_NOERR;
  return res;
}

int		array_insert_before(t_set *set, t_id id, void *d)
{
  t_array	*data = set->data;
  int		res = 0;
  t_uint32	i = 0;
  t_uint32	pos = 0;

  if (set->nbelt < set->initsz)
    {
      array_resize(set);
      data = set->data;
    }
  while (i < set->initsz &&
	 data[i].it != NULL &&
	 data[i].it->id != id)
    i++;
  if (data[i].it != NULL &&
      data[i].it->id == id)
    {
      if (i == 0)
	res = array_insert_head(set, d);
      else
	{
	  pos = i;
	  for (i = set->nbelt - 1; i >= pos; i--)
	    data[i + 1].it = data[i].it;
	  data[pos].it = malloc(sizeof(t_iterator));
	  data[pos].it->id = set->nextid++;
	  data[pos].it->addr = d;
	  set->nbelt++;
	  res = SET_NOERR;
	}
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}

int		array_insert_after(t_set *set, t_id id, void *d)
{
  t_array	*data = set->data;
  int		res = 0;
  t_uint32	i = 0;
  t_uint32	pos = 0;

  if (set->nbelt < set->initsz)
    {
      array_resize(set);
      data = set->data;
    }
  while (i < set->initsz &&
	 data[i].it != NULL &&
	 data[i].it->id != id)
    i++;
  if (data[i].it != NULL &&
      data[i].it->id == id)
    {
      pos = i + 1;
      for (i = set->nbelt; i > pos; i--)
	data[i].it = data[i - 1].it;
      data[pos].it = malloc(sizeof(t_iterator));
      data[pos].it->id = set->nextid++;
      data[pos].it->addr = d;
      set->nbelt++;
      res = SET_NOERR;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int array_display(t_set *set)
{
  t_array	*data = set->data;
  t_uint32	i = 0;

  while (i < set->nbelt && data[i].it != NULL)
    {
      printf("- [%i] %p\n", data[i].it->id, data[i].it->addr);
      i++;
    }
  return SET_NOERR;
}
