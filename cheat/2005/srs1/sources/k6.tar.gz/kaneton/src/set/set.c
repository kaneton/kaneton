#include <set.h>
#include <stdio.h>


t_set		*sets_;
t_id		setsid_;

t_set	*set_find(t_setid id)
{
  t_iterator	it;

  it.addr = NULL;
  if (id == setsid_)
    return sets_;
  set_get(setsid_, id, &it);
  return (t_set*)it.addr;
}

int     set_init(void)
{
  int	res = 0;

  sets_ = malloc(sizeof(t_set));
  sets_->setid = setsid_ = 0;
  sets_->type = SET_TYPE_LIST;
  sets_->sort = SET_SORT_DISABLE;
  sets_->objectsz = sizeof(t_set *);
  sets_->initsz = 30;
  sets_->nextid = 0;
  sets_->data = NULL;
  sets_->nbelt = 0;

  res = set_insert(setsid_, sets_);
  return SET_NOERR;
}

t_type	set_choose_type(t_sort sort, size_t size, t_setsz setsize)
{
  (void) sort;
  (void) setsize;
  if (size <= sizeof(t_slist))
    return SET_TYPE_ARRAY;
  if (size < sizeof(t_dlist))
    return SET_TYPE_LIST;
  return SET_TYPE_DLIST;
}

int     set_rsv(t_type type, t_sort sort, size_t size, t_setsz setsize, t_setid *id)
{
  int	res = 0;
  t_set	*new = NULL;

  if (type == SET_TYPE_ANY)
    type = set_choose_type(sort, size, setsize);

  new = malloc(sizeof(t_set));
  new->setid = *id = sets_->nextid;
  new->type = type;
  new->sort = sort;
  new->objectsz = size;
  new->initsz = setsize;
  new->nextid = 1;
  new->nbelt = 0;
  new->data = NULL;
  res = set_insert(setsid_, new);

  switch (type) {
  case SET_TYPE_ARRAY:
    res = array_rsv(new);
    break;
  case SET_TYPE_LIST:
    res = slist_rsv(new);
    break;
  case SET_TYPE_DLIST:
    res = dlist_rsv(new);
    break;
  case SET_TYPE_BTREE:
  default:
    printf("no types implemented for that (set_rsv)\n");
  }
  return res;
}


int     set_rel(t_setid id)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(id);
  if (set != NULL)
    {
      switch (set->type) {
      case SET_TYPE_ARRAY:
	res = array_rel(set);
	break;
      case SET_TYPE_LIST:
	res = slist_rel(set);
	break;
      case SET_TYPE_DLIST:
	res = dlist_rel(set);
	break;
      case SET_TYPE_BTREE:
      default:
	printf("no types implemented for that (set_rel)\n");
      }
      free(set);
      res = set_delete(setsid_, id);
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_get(t_setid setid , t_id id, t_iterator *iterator)
{
  t_set *set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      switch (set->type) {
      case SET_TYPE_ARRAY:
	res = array_get(set, id, iterator);
	break;
      case SET_TYPE_LIST:
	res = slist_get(set, id, iterator);
	break;
      case SET_TYPE_DLIST:
	res = dlist_get(set, id, iterator);
	break;
      case SET_TYPE_BTREE:
      default:
	printf("no types implemented for that (set_get)\n");
      }
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_head(t_setid setid, t_iterator *iterator)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      switch (set->type) {
      case SET_TYPE_ARRAY:
	res = array_head(set, iterator);
	break;
      case SET_TYPE_LIST:
	res = slist_head(set, iterator);
	break;
      case SET_TYPE_DLIST:
	res = dlist_head(set, iterator);
	break;
      case SET_TYPE_BTREE:
      default:
	printf("no types implemented for that (set_head)\n");
      }
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_tail(t_setid setid, t_iterator *iterator)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      switch (set->type) {
      case SET_TYPE_ARRAY:
	res = array_tail(set, iterator);
	break;
      case SET_TYPE_LIST:
	res = slist_tail(set, iterator);
	break;
      case SET_TYPE_DLIST:
	res = dlist_tail(set, iterator);
	break;
      case SET_TYPE_BTREE:
      default:
	printf("no types implemented for that (set_tail)\n");
      }
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_prev(t_setid setid, t_iterator iterator, t_iterator *piterator)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      switch (set->type) {
      case SET_TYPE_ARRAY:
	res = array_prev(set, iterator, piterator);
	break;
      case SET_TYPE_LIST:
	res = slist_prev(set, iterator, piterator);
	break;
      case SET_TYPE_DLIST:
	res = dlist_prev(set, iterator, piterator);
	break;
      case SET_TYPE_BTREE:
      default:
	printf("no types implemented for that (set_prev)\n");
      }
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_next(t_setid setid, t_iterator iterator, t_iterator *piterator)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      switch (set->type) {
      case SET_TYPE_ARRAY:
	res = array_next(set, iterator, piterator);
	break;
      case SET_TYPE_LIST:
	res = slist_next(set, iterator, piterator);
	break;
      case SET_TYPE_DLIST:
	res = dlist_next(set, iterator, piterator);
	break;
      case SET_TYPE_BTREE:
      default:
	printf("no types implemented for that (set_next)\n");
      }
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_insert(t_setid setid, void *data)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      if (set->sort == SET_SORT_ENABLE ||
	  set->sort == SET_SORT_DISABLE)
	{
	  switch (set->type) {
	  case SET_TYPE_ARRAY:
	    res = array_insert(set, data);
	    break;
	  case SET_TYPE_LIST:
	    res = slist_insert(set, data);
	    break;
	  case SET_TYPE_DLIST:
	    res = dlist_insert(set, data);
	    break;
	  case SET_TYPE_BTREE:
	  default:
	    printf("no types implemented for that (set_insert)\n");
	  }
	}
      else
	res = SET_NOTIMPLEMENTED;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}

int     set_insert_id(t_setid setid, void *data, t_id *id)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      *id = set->nextid;
      if (set->sort == SET_SORT_ENABLE ||
	  set->sort == SET_SORT_DISABLE)
	{
	  switch (set->type) {
	  case SET_TYPE_ARRAY:
	    res = array_insert(set, data);
	    break;
	  case SET_TYPE_LIST:
	    res = slist_insert(set, data);
	    break;
	  case SET_TYPE_DLIST:
	    res = dlist_insert(set, data);
	    break;
	  case SET_TYPE_BTREE:
	  default:
	    printf("no types implemented for that (set_insert)\n");
	  }
	}
      else
	res = SET_NOTIMPLEMENTED;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_delete(t_setid setid, t_id id)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      switch (set->type) {
      case SET_TYPE_ARRAY:
	res = array_delete(set, id);
	break;
      case SET_TYPE_LIST:
	res = slist_delete(set, id);
	break;
      case SET_TYPE_DLIST:
	res = dlist_delete(set, id);
	break;
      case SET_TYPE_BTREE:
      default:
	printf("no types implemented for that (set_delete)\n");
      }
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_insert_head(t_setid setid, void *data)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      if (set->sort == SET_SORT_MANUAL)
	{
	  switch (set->type) {
	  case SET_TYPE_ARRAY:
	    res = array_insert_head(set, data);
	    break;
	  case SET_TYPE_LIST:
	    res = slist_insert_head(set, data);
	    break;
	  case SET_TYPE_DLIST:
	    res = dlist_insert_head(set, data);
	    break;
	  case SET_TYPE_BTREE:
	  default:
	    printf("no types implemented for that (set_insert_head)\n");
	  }
	}
      else
	res = SET_NOTIMPLEMENTED;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_insert_tail(t_setid setid, void *data)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      if (set->sort == SET_SORT_MANUAL)
	{
	  switch (set->type) {
	  case SET_TYPE_ARRAY:
	    res = array_insert_tail(set, data);
	    break;
	  case SET_TYPE_LIST:
	    res = slist_insert_tail(set, data);
	    break;
	  case SET_TYPE_DLIST:
	    res = dlist_insert_tail(set, data);
	    break;
	  case SET_TYPE_BTREE:
	  default:
	    printf("no types implemented for that (set_insert_tail)\n");
	  }
	}
      else
	res = SET_NOTIMPLEMENTED;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_insert_before(t_setid setid, t_id id, void *data)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      if (set->sort == SET_SORT_MANUAL)
	{
	  switch (set->type) {
	  case SET_TYPE_ARRAY:
	    res = array_insert_before(set, id, data);
	    break;
	  case SET_TYPE_LIST:
	    res = slist_insert_before(set, id, data);
	    break;
	  case SET_TYPE_DLIST:
	    res = dlist_insert_before(set, id, data);
	    break;
	  case SET_TYPE_BTREE:
	  default:
	    printf("no types implemented for that (set_insert_before)\n");
	  }
	}
      else
	res = SET_NOTIMPLEMENTED;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int     set_insert_after(t_setid setid, t_id id, void *data)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      if (set->sort == SET_SORT_MANUAL)
	{
	  switch (set->type) {
	  case SET_TYPE_ARRAY:
	    res = array_insert_after(set, id, data);
	    break;
	  case SET_TYPE_LIST:
	    res = slist_insert_after(set, id, data);
	    break;
	  case SET_TYPE_DLIST:
	    res = dlist_insert_after(set, id, data);
	    break;
	  case SET_TYPE_BTREE:
	  default:
	    printf("no types implemented for that (set_insert_after)\n");
	  }
	}
      else
	res = SET_NOTIMPLEMENTED;
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}


int		set_clean(void)
{
  t_iterator	it;
  int		res = 0;

  do {
    it.addr = NULL;
    set_head(setsid_, &it);
    if (it.addr != NULL)
      {
	if (it.id != setsid_)
	  set_rel(it.id);
	else
	  break;
      }
  } while (it.addr != NULL);
  set_delete(setsid_, setsid_);
  free(sets_);

  return res;
}


int	set_display(t_setid setid)
{
  t_set	*set = NULL;
  int	res = 0;

  set = set_find(setid);
  if (set != NULL)
    {
      printf("=> set [%d]: %d elts, capacity of %d (type %d)(sort %d)\n",
	     set->setid, set->nbelt, set->initsz, set->type, set->sort);
      switch (set->type) {
      case SET_TYPE_ARRAY:
	res = array_display(set);
	break;
      case SET_TYPE_LIST:
	res = slist_display(set);
	break;
      case SET_TYPE_DLIST:
	res = dlist_display(set);
	break;
      case SET_TYPE_BTREE:
      default:
	printf("no types implemented for that (set_display)\n");
      }
    }
  else
    res = SET_ERR_NOTFOUND;
  return res;
}
