#include <scheduler.h>
#include <task.h>
#include <paging.h>
#include <thread.h>
#include <kernel.h>
#include <string.h>

/*
 * the threads set of the system
 */
t_setid	threads;

static t_thrid	__thrid_count = 0;

int	thread_init(void)
{
  if (set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof (t_thread) * 10, 0, &threads) < 0)
  {
    panic("thread_init: set_rsv() failed");
    return -1;
  }
  return 0;
}

int		thread_rsv(t_prior prior, t_thrid *thrid)
{
  t_thread	*thread;

  if (!(thread = malloc(sizeof (t_thread))))
    return -1;
  thread->thrid = __thrid_count++;
  *thrid = thread->thrid;
  thread->tskid = TSKID_UNUSED;
  thread->ownid = OWNID_UNUSED;
  thread->prior = prior;
  thread->sched = STATUS_STOP;
  /* FIXME: thread->wait? */
  if (set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof (t_thrid), 0, &thread->waitlist) < 0)
  {
    panic("thread_rsv: set_rsv() failed");
    return -1;
  }
  thread->stacksz = 0;
  if (set_insert(threads, thread) < 0)
  {
    panic("thread_rsv: set_insert() failed");
    return -1;
  }
  return 0;
}

int		thread_prior(t_thrid thrid, t_prior *prior)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  *prior = thread->prior;
  return 0;
}

int		thread_grade(t_thrid thrid, t_prior prior)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  thread->prior = prior;
  return 0;
}

int	thread_wait(t_thrid thrid, t_wait *wait)
{
  /* FIXME */
  return 0;
}

int		thread_get(t_thrid thrid, t_thread **thread)
{
  t_iterator	it;

  SET_FOREACH(FOREACH_FORWARD, threads, &it)
    if (((t_thread *)ITERATOR_ADDR(&it))->thrid == thrid)
    {
      *thread = ITERATOR_ADDR(&it);
      return 0;
    }
  return -1;
}

int		thread_rel(t_thrid thrid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  thread_detach(thrid, thread->tskid);
  /* FIXME: as_detach? */
  return 0;
}

int		thread_clone(t_thrid old, t_thrid *new)
{
  t_thread	*old_thread;
  t_thread	*new_thread;

  if (thread_get(old, &old_thread) < 0)
    return -1;
  if (thread_rsv(old_thread->prior, new) < 0)
    return -1;
  if (thread_get(*new, &new_thread) < 0)
    return -1;
  new_thread->tskid = old_thread->tskid;
  new_thread->ownid = old_thread->ownid;
  new_thread->sched = old_thread->sched;
  /* FIXME: new_thread->stack? */
  /* FIXME: new_thread->stacksz? */
  return 0;
}

int		thread_run(t_thrid thrid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  thread->sched = STATUS_RUN;
  /* FIXME */
  return 0;
}

int		thread_stop(t_thrid thrid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  thread->sched = STATUS_STOP;
  /* FIXME */
  return 0;
}

int		thread_tskid(t_thrid thrid, t_tskid *tskid)
{
  t_iterator	it;

  SET_FOREACH(FOREACH_FORWARD, threads, &it)
    if (((t_thread *) ITERATOR_ADDR(&it))->thrid == thrid)
    {
      *tskid = ((t_thread *) ITERATOR_ADDR(&it))->tskid;
      return 0;
    }
  return -1;
}

int		thread_ownid(t_thrid thrid, t_ownid *ownid)
{
  t_iterator	it;

  SET_FOREACH(FOREACH_FORWARD, threads, &it)
    if (((t_thread *) ITERATOR_ADDR(&it))->thrid == thrid)
    {
      *ownid = ((t_thread *) ITERATOR_ADDR(&it))->ownid;
      return 0;
    }
  return -1;
}

int		thread_give(t_thrid thrid, t_ownid ownid)
{
  t_iterator	it;

  SET_FOREACH(FOREACH_FORWARD, threads, &it)
    if (((t_thread *) ITERATOR_ADDR(&it))->thrid == thrid)
    {
      ((t_thread *) ITERATOR_ADDR(&it))->ownid = ownid;
      return 0;
    }
  return -1;
}

int		thread_stack(t_thrid thrid, t_vsize npages)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  thread->stack = (t_vaddr) malloc(npages * PAGE_SIZE);
  thread->stacksz = npages * PAGE_SIZE;
  return 0;
}

int		thread_load(t_thrid thrid, t_thrctx *thrctx)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
  {
    panic("thread_load: thread_get() failed");
    return -1;
  }
  memset(&thread->ctx, 0, sizeof (struct s_ctx));
  thread->ctx.ebp = 0x66cd4; 
  thread->ctx.eip = (t_vaddr) thrctx->pc;
  thread->ctx.eflags = 0x202;
  thread->ctx.esi = 0x0;
  thread->ctx.edi = 0x5ac60;
  thread->ctx.cs = 0x8;
  thread->ctx.ds = 0x10;
  thread->ctx.es = thread->ctx.ds;
  thread->ctx.fs = thread->ctx.ds;
  thread->ctx.gs = thread->ctx.ds;
  thread->ctx.ss = thread->ctx.ds;
  return 0;
}

int	thread_store(t_thrid thrid, t_thrctx *thrctx)
{
  /* FIXME */
  return 0;
}

int		thread_args(t_thrid thrid, void *args, size_t size)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -2;
  if (!thread->stacksz)
  {
    /* No stack present. */
    return -1;
  }
  /* FIXME */
  return 0;
}

int		thread_attach(t_thrid thrid, t_tskid tskid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  thread->tskid = tskid;
  /* FIXME */
  return 0;
}

int		thread_detach(t_thrid thrid, t_tskid tskid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  thread->tskid = TSKID_UNUSED;
  /* FIXME */
  return 0;
}

int		thread_exit(t_thrid thrid)
{
  t_thread	*thread;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  thread->sched = STATUS_STOP;
  /* FIXME */
  return 0;
}

int	thread_clean(void)
{
  /* FIXME */
  return 0;
}
