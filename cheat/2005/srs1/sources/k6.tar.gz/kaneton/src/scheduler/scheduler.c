#include <machdep/segments.h>
#include <scheduler.h>
#include <thread.h>
#include <string.h>
#include <unistd.h>

t_quantum	_quantum;
t_iterator	current_thread_it;
extern t_setid	threads;

struct s_ctx	*ctx1p;
struct s_ctx	*ctx2p;

static int		thread1_started = 0;
extern unsigned int	ticks;

int	sched_init_default(void)
{
  return sched_init(QUANTUM_DEFAULT);
}

int	sched_thread1(void *data)
{
  printf("-- Starting thread 1 --");

  while (1)
  {
    sleep(1);
    printf("1");
  }
  return 0;
}

void	registers_print(struct s_ctx *ctx)
{
  printf("CPU dump\n");
  printf("-------------------\n");
  printf("ESP    = %x\n", (t_uint32) ctx);
  printf("EBP    = %x\n", ctx->ebp);
  printf("EIP    = %x\n", ctx->eip);
  printf("CS     = %x\n", ctx->cs);
  printf("EFLAGS = %x\n", ctx->eflags);
  printf("EAX    = %x\n", ctx->eax);
  printf("EBX    = %x\n", ctx->ebx);
  printf("ECX    = %x\n", ctx->ecx);
  printf("EDX    = %x\n", ctx->edx);
  printf("ESI    = %x\n", ctx->esi);
  printf("EDI    = %x\n", ctx->edi);
  printf("DS     = %x\n", ctx->ds);
  printf("ES     = %x\n", ctx->es);
  printf("FS     = %x\n", ctx->fs);
  printf("GS     = %x\n", ctx->gs);
  printf("SS     = %x\n", ctx->ss);
  printf("-------------------\n");
}

t_thrid	thread1_thrid;
t_thrid	shell_thrid;

int		sched_init(t_quantum quantum)
{
  /* FIXME: set_head(threads, &current_thread_it); */
  _quantum = quantum; 

  return 0;
}

int	thread1_start(void)
{
  ctx1p = malloc(sizeof(struct s_ctx) * 10);
  ctx2p = malloc(sizeof(struct s_ctx) * 10);

  memset(ctx2p, 0, sizeof (struct s_ctx));
  ctx2p->ebp = 0x66cd4; 
  ctx2p->eip = (t_vaddr) sched_thread1;
  ctx2p->eflags = 0x202;
  ctx2p->esi = 0x0;
  ctx2p->edi = 0x5ac60;
  ctx2p->cs = 0x8;
  ctx2p->ds = 0x10;
  ctx2p->es = ctx2p->ds;
  ctx2p->fs = ctx2p->ds;
  ctx2p->gs = ctx2p->ds;
  ctx2p->ss = ctx2p->ds;

  thread1_started = 1;
  return 0;
}

int	sched_quantum(t_quantum quantum)
{
  _quantum = quantum;
  return 0;
}

int	sched_yield(void)
{
  /* FIXME */
  return 0;
}

int		sched_next(t_thrid *thrid)
{
  t_iterator	next;

  do
    if (set_next(threads, current_thread_it, &next) < 0)
      set_head(threads, &next); /* Restart from the beginning */
  while (((t_thread *) ITERATOR_ADDR(&next))->sched != STATUS_RUN);
  *thrid = ((t_thread *) ITERATOR_ADDR(&next))->thrid;
  return 0;
}

int		sched_switch(t_thrid thrid)
{
  t_thread	*thread;
  t_thread	*current_thread;
  struct s_ctx	*current_ctx;

  if (thread_get(thrid, &thread) < 0)
    return -1;
  current_thread = ITERATOR_ADDR(&current_thread_it);
  current_ctx = &current_thread->ctx;
  ctx_switch(&current_ctx, &thread->ctx);
  return 0;
}

int	sched_sched(void)
{
  int	q = 1;

  if ((ticks / 50) % q)
    return 0;
  if (!thread1_started)
    return 0;
  if ((ticks / 50 / q) % 2)
    ctx_switch(&ctx1p, ctx2p); /* to thread1 */
  else
    ctx_switch(&ctx2p, ctx1p); /* to shell */
  return 0;
}

int	sched_thrid(t_thrid *thrid)
{
  *thrid = ((t_thread *) ITERATOR_ADDR(&current_thread_it))->thrid;
  return 0;
}

int	sched_clean(void)
{
  /* FIXME */
  return 0;
}
