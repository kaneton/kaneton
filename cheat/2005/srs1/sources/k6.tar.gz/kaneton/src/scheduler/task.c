#include <scheduler.h>
#include <thread.h>
#include <task.h>

/*
 * the tasks set of the system
 */

t_setid	tasks;

/*
 * the kernel task
 */

t_task	ktask;

static t_tskid __tskid_count = 0;

int	task_init(void)
{
  if (set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof (t_task), 0, &tasks) < 0)
    return -1;
  return 0;
}

int		task_rsv(t_class class, t_behav behav, t_prior prior, t_tskid *tskid)
{
  t_task	*task;

  if (!(task = malloc(sizeof (t_task))))
    return -1;
  task->tskid = __tskid_count++;
  /* FIXME: task->ptskid? */
  task->asid = ASID_UNUSED;
  if (set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof (t_thrid), 0, &task->threads) < 0)
    return -1;
  if (set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof (t_tskid), 0, &task->children) < 0)
    return -1;
  task->class = class;
  task->behav = behav;
  task->prior = prior;
  task->sched = STATUS_STOP;
  /* FIXME: task->wait? */
  if (set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof (t_thrid), 0, &task->waitlist) < 0)
    return -1;
  set_insert(tasks, task);
  return 0;
}

int	task_setid(t_setid *setid)
{
  *setid = tasks;
  return 0;
}

int		task_prior(t_tskid tskid, t_prior *prior)
{
  t_task	*task;

  if (task_get(tskid, &task) < 0)
    return -1;
  *prior = task->prior;
  return 0;
}

int		task_grade(t_tskid tskid, t_prior prior)
{
  t_task	*task;

  if (task_get(tskid, &task) < 0)
    return -1;
  task->prior = prior;
  return 0;
}

int		task_wait(t_tskid tskid, t_wait *wait)
{
  t_task	*task;

  /* FIXME: handle tskid == 0 case */
  if (task_get(tskid, &task) < 0)
    return -1;
  /* FIXME: set_insert(task->waitlist, <current thread id>); */
  /* FIXME: call sched_yield? */
  /* FIXME: fill wait struct */
  return 0;
}

int		task_get(t_tskid tskid, t_task **task)
{
  t_iterator	it;

  if (set_get(tasks, tskid, &it) < 0)
    return -1;
  *task = ITERATOR_ADDR(&it);
  return 0;
}

int		task_rel(t_tskid tskid)
{
  t_task	*task;

  if (task_get(tskid, &task) < 0)
    return -1;
  /* FIXME: Free AS, free threads? */
  set_delete(tasks, tskid);
  free(task);
  return 0;
}

int		task_clone(t_tskid old, t_tskid *new)
{
  t_task	*old_task;
  t_task	*new_task;
  t_asid	new_asid;
  t_thrid	new_thrid;
  t_iterator	it;

  if (task_get(old, &old_task) < 0)
    return -1;
  if (task_rsv(old_task->class, old_task->behav, old_task->prior, new) < 0)
    return -1;
  if (task_get(*new, &new_task) < 0)
    return -1;
  new_task->ptskid = old_task->ptskid;
  if (as_rsv(&new_asid) < 0)
    return -1;
  as_clone(old_task->asid, new_asid);
  SET_FOREACH(FOREACH_FORWARD, old_task->threads, &it)
    thread_clone(((t_thread *) ITERATOR_ADDR(&it))->thrid, &new_thrid);
  return 0;
}

int		task_asid(t_tskid tskid, t_asid *asid)
{
  t_task	*task;

  if (task_get(tskid, &task) < 0)
    return -1;
  *asid = task->asid;
  return 0;
}

int		task_ownid(t_tskid tskid, t_ownid *ownid)
{
  t_task	*task;

  if (task_get(tskid, &task) < 0)
    return -1;
  *ownid = task->ptskid;
  return 0;
}

int		task_give(t_tskid tskid, t_ownid ownid)
{
  t_task	*task;

  if (task_get(tskid, &task) < 0)
    return -1;
  task->ptskid = ownid;
  return 0;
}

int		task_run(t_tskid tskid)
{
  t_task	*task;

  /* FIXME: check if kernel, actual task or parent */
  /* FIXME: check if thread and AS are associated with the task */
  if (task_get(tskid, &task) < 0)
    return -1;
  task->sched = STATUS_RUN;
  return 0;
}

int		task_stop(t_tskid tskid)
{
  t_task	*task;

  /* FIXME: check if kernel, actual task or parent */
  if (task_get(tskid, &task) < 0)
    return -1;
  task->sched = STATUS_STOP;
  return 0;
}

int		task_exit(t_tskid tskid)
{
  t_task	*task;

  if (task_get(tskid, &task) < 0)
    return -1;
  /* FIXME: Stop running threads */
  task_stop(tskid);
  task_rel(tskid);
  return 0;
}

int		task_clean(void)
{
  t_iterator	it;

  SET_FOREACH(FOREACH_FORWARD, tasks, &it)
  {
    /* FIXME: call task_exit? */
    free(ITERATOR_ADDR(&it));
    set_delete(tasks, ITERATOR_ID(&it));
  }
  return 0;
}
