#include <modules.h>
#include <elf.h>
#include <types.h>
#include <set.h>
#include <as.h>

/*
** the id f the modules list (a set)
*/
t_setid	modid_;


int			mod_parse_mbi(t_paddr multiboot)
{
  multiboot_info_t	*mbi = (multiboot_info_t *)multiboot;
  module_t		*mod = NULL;
  t_module		*new = NULL;
  unsigned int		i  = 0;
  /* t_asid		asid; */

  mod = (module_t *)mbi->mods_addr;
  mod++;
  for (i = 1; i < mbi->mods_count; i++)
    {
      //printf("%s loaded\n", (char *)mod->string);
      if (strncmp("KONF", (char *)mod->mod_start, 4) != 0)
	{
	  new = malloc(sizeof(t_module));
	  //as_rsv(&asid);
	  //vm_map(asid, mod->mod_start, 0x08000000, ((mod->mod_end - mod->mod_start) / PAGE_SIZE) + 1);
	  new->mod_start = (void *)mod->mod_start;
	  new->mod_end = (void *)mod->mod_end;

	  // need a strdup ?
	  new->path = strdup((char*)mod->string);
	  new->loaded = MOD_UNLOADED;
	  new->type = MOD_GRUB;
	  /* new->asid = asid; */
	  new->lifetime = (i == mbi->mods_addr - 1) ? LIFETIME_FINITE : LIFETIME_INFINITE;

	  set_insert(modid_, new);
	}
      //      else
      //	printf("NOT LOADED\n");
      mod++;
    }
  return mbi->mods_count;
}

int	mod_init(t_paddr multiboot)
{
  set_rsv(SET_TYPE_LIST, SET_SORT_DISABLE, sizeof(t_module), 0, &modid_);
  // get modules loaded in memory by grub
  mod_parse_mbi(multiboot);

  // launch it according the conf file
  // FIXME

  return 0;
}

int		mod_add(char *path, t_lifetime lifetime, t_modid *modid)
{
  t_module	*mod = NULL;

  mod = malloc(sizeof(t_module));
  if (mod)
    {
      mod->path = strdup(path);
      mod->loaded = MOD_UNLOADED;
      mod->type = MOD_SELF;
      mod->lifetime = lifetime;
      mod->asid = 0;

      // FIXME : read the file to put it in main memory
      mod->mod_start = (unsigned long int)NULL;
      mod->mod_end = (unsigned long int)NULL;

      set_insert_id(modid_, mod, modid);
    }
  else
    return MOD_ERROR;
  return MOD_OK;
}


int		mod_remove(t_modid modid)
{
  t_iterator	it;
  t_module	*mod = NULL;

  if (set_get(modid_, modid, &it) == 0)
    {
      mod = (t_module *)ITERATOR_ADDR(&it);
      if (mod->loaded == MOD_LOADED)
	mod_unload(mod->asid);
      set_delete(modid_, modid);
      free(mod);
    }
  else
    return MOD_ERROR;
  return MOD_OK;
}

int		mod_load(t_modid modid, t_asid asid)
{
  t_iterator	it;
  t_module	*mod = NULL;

  if (set_get(modid_, modid, &it) == 0)
    {
      mod = (t_module *)ITERATOR_ADDR(&it);
      // FIXME
      // get memory (and map it) into the as asid
      // copy the module in the memory mapped

      mod->loaded = MOD_LOADED;
      mod->asid = asid;
    }
  else
    return MOD_ERROR;
  return MOD_OK;
}

int	mod_unload(t_asid asid)
{
  // FIXME
  // unmap the module into the asid

  return MOD_ERROR;
}

int		mod_reload(t_modid modid, t_asid asid)
{
  t_iterator	it;
  t_module	*mod = NULL;
  int		res = MOD_OK;

  if (set_get(modid_, modid, &it) == 0)
    {
      mod = (t_module *)ITERATOR_ADDR(&it);
      if (!(res = mod_unload(mod->asid)))
	res = mod_load(modid, asid);
    }
  else
    return MOD_ERROR;
  return res;
}

int		mod_entry(t_modid modid, t_vaddr *entry)
{
  t_iterator	it;
  t_module	*mod;

  if (set_get(modid_, modid, &it) == 0 &&
      entry != NULL)
    {
      mod = (t_module *)it.addr;
      if (mod->loaded != MOD_LOADED)
	goto error;
      *entry = ((Elf32_Ehdr *) mod->mod_start)->e_entry;
      return MOD_OK;
    }
 error:
  return MOD_ERROR;
}

int		mod_function(t_modid modid, char *function, t_vaddr *entry)
{
  int		i = 0;
  int		nb_sym = 0;
  t_iterator	it;
  t_module	*mod;
  Elf32_Ehdr   	*elf = NULL;
  Elf32_Shdr	*symsec = NULL;
  Elf32_Shdr	*strsec = NULL;
  Elf32_Sym	*symt = NULL;
  char		*strt = NULL;
  Elf32_Shdr	*sec  = NULL;

  if (set_get(modid_, modid, &it) == 0)
    {
      mod = (t_module *)ITERATOR_ADDR(&it);
      if (mod->loaded != MOD_LOADED)
	goto error;
      elf = (Elf32_Ehdr *) mod->mod_start;
      sec = (Elf32_Shdr *)((void *)elf + elf->e_shoff);
      strsec = &sec[elf->e_shstrndx];
      strt = (char *)((void *)elf + sec[elf->e_shstrndx].sh_offset);
      while (i < elf->e_shnum)
	{
	  if (sec->sh_type == SHT_SYMTAB)
	    symsec = (Elf32_Shdr *)sec;
	  else if (sec->sh_type == SHT_STRTAB &&
		   i != elf->e_shstrndx)
	    strsec = (Elf32_Shdr *)sec;
	  sec++;
	  i++;
	}

      if (symsec != NULL && strsec != NULL)
	{
	  symt = (Elf32_Sym *)((void *)elf + symsec->sh_offset);
	  strt = (char *)((void *)elf + strsec->sh_offset);
	  nb_sym = symsec->sh_size / sizeof(Elf32_Sym);

	  for (i = 0; i < nb_sym; i++)
	    {
	      if (strcmp(function, (void *)strt + symt[i].st_name) == 0 &&
		  ELF32_ST_TYPE(symt[i].st_info) == STT_FUNC)
		{
/* 		  printf("\"%s\" found @ %p\n", */
/* 			 strt + symt[i].st_name, (void *)elf  + (symt[i].st_value)); */
		  *entry = (t_vaddr)((void *)elf + symt[i].st_value);
		  return MOD_OK;
		}
	    }
	}
      else /* Error on finding tables */
	goto error;
    }
 error:
  return MOD_ERROR;
}


int		mod_clean()
{
  t_iterator	it;
  t_module	*mod;

  SET_FOREACH(FOREACH_FORWARD, modid_, &it)
    {
      mod = ITERATOR_ADDR(&it);
      if ((mod->type & MOD_GRUB) == 0)
	free(mod);
    }
  set_rel(modid_);
  return MOD_OK;
}
