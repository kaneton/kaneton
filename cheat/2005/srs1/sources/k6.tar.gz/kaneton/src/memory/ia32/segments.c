/*
** Used to handle segmentation
*/

#include <machdep/segments.h>
#include <gdt.h>
#include <paging.h>
#include <stdio.h>
#include <string.h>

extern _t_gdt *_gdt;

/* _t_gdt *_gdt = (_t_gdt *) ADDR_GDT; */

unsigned int	_gdt_size = 5;

int	get_gdt_type(t_pl pl, t_segtype type)
{
  int		ti = 0;

  if (pl & PL_USER)
    ti |= GDT_DPL3;
  else if (pl & PL_SERVICE)
    ti |= GDT_DPL1;		/* Intel has 2 level for services. We use the first one */
  else 
    ti |= GDT_DPL0;
  if (pl & PL_EXEC)
    ti |= GDT_CODE;
  else
    ti |= GDT_DATA;
  if (pl & PL_READ)
    ti |= GDT_READABLE;
  if (pl & PL_WRITE)
    ti |= GDT_WRITABLE;
  if (type & SEG_TYPE_TSS)
    ti |= GDT_SYSTEM;			/* FIXME : not sure about that */
  else
    ti |= GDT_APPLICATION;		/* FIXME : not sure about that */
  return ti;
}

int	seg_init(void)
{
  _gdt_size = 5;
  return 0;
}

int		seg_add(t_paddr start, t_psize size, t_pl pl, t_segtype type, t_segid *segid)
{
  unsigned int	i;

  for (i = 1; i < _gdt_size; i++)
    {
      if ((_gdt[i]._type & GDT_PRESENT) != GDT_PRESENT)
      {
	*segid = i;
	break;
      }
    }
  if (i == _gdt_size)
    {
      if (_gdt_size == GDT_SIZE)
	return 1;			/* Error : GDT is full */
      _gdt_size++;
      *segid = _gdt_size - 1;
    }
  _gdt[*segid].__limit = size;
  _gdt[*segid].__base = start;
  _gdt[*segid]._base_16 = (start & 0xff0000) >> 16;
  _gdt[*segid]._base_24 = (start & 0xff000000) >> 24;
  _gdt[*segid]._type = (get_gdt_type(pl, type) | GDT_PRESENT) & 0xff;
  _gdt[*segid]._flags = ((GDT_AVAILABLE | GDT_USE32 | GDT_GRANULAR) | ((size & 0xf0000) >> 16));

  k_lgdt(_gdt_size);
  return 0;
}

int	seg_modify(t_segid segid, t_paddr start, t_psize size, t_pl pl, t_segtype type)
{
  if (segid > GDT_SIZE)
    return 1;				/* Error : Invalid segid */
  _gdt[segid].__limit = size;
  _gdt[segid].__base = start;
  _gdt[segid]._base_16 = (start & 0xff0000) >> 16;
  _gdt[segid]._base_24 = (start & 0xff000000) >> 24;
  _gdt[segid]._type = (get_gdt_type(pl, type) | GDT_PRESENT) & 0xff;
  _gdt[segid]._flags = ((GDT_AVAILABLE | GDT_USE32 | GDT_GRANULAR) | ((size & 0xf0000) >> 16));

  k_lgdt(_gdt_size);
  return 0;
}

int	seg_remove(t_segid segid)
{
  if (segid > GDT_SIZE)
    return 1;				/* Error : Invalid segid */
  if (segid + 1 == _gdt_size)
    _gdt_size--;
  _gdt[segid]._type = 0;		/* to set GDT_PRESENT 0 */

  k_lgdt(_gdt_size);
  return 0;
}

int	seg_clear(void)
{
  _gdt_size = 5;

  memset(_gdt + 5, 0x0, sizeof (_t_gdt) * (GDT_SIZE - 5));

  k_lgdt(_gdt_size);

  return 0;
}

/*
** debug
*/


void	print_gdt_entry(int i)
{
  printf("* Entry: %d \n", i);
  printf("* base: %x           | limit : %x\n", _gdt[i].__base, _gdt[i].__limit);
  printf("* GDT READ/WRITE: %s | GDT_APPLICATION: %s \n",
	 (_gdt[i]._type & GDT_READABLE) == GDT_READABLE ? "oui" : "non"
	 , (_gdt[i]._type & GDT_APPLICATION) == GDT_APPLICATION ? "oui" : "non");
  printf("* GDT_CODE: %s       | Present : %d | DPL : %s \n", 
	 (_gdt[i]._type & GDT_CODE) == GDT_CODE ? "oui" : "non"
	 , (_gdt[i]._type & GDT_PRESENT) == GDT_PRESENT ? 1 : 0
	 , (_gdt[i]._type & GDT_DPL3 & 0xff) == GDT_DPL3 ? "User" : 
	 (_gdt[i]._type & GDT_DPL1 & 0xff) == GDT_DPL1 ? "Service (1)" :
	 (_gdt[i]._type & GDT_DPL2 & 0xff) == GDT_DPL2 ? "Service (2)" : "Kernel");
  printf("********************\n"); 
}

void	print_gdt(void)
{
  unsigned int	i;

  printf("********************\n * Gdt Table * \n********************\n");
  printf("*** size : %d ***\n", _gdt_size);
  for (i = 1; i < _gdt_size; i++)
    {
      print_gdt_entry(i);
    }
}

