/*
** Address spaces handling
*/

#include <paging.h>
#include <pm.h>
#include <string.h>
#include <stdio.h>
#include <kernel.h>
#include <as.h>

static int		as_vas_new_page(struct s_vas_data **vas_page)
{
  struct s_vas_data	vas;
  unsigned int		i;

  if (vm_mm_rsv(kas.asid, (t_vaddr *) vas_page, 1, VM_FLAG_FORCE) < 0)
  {
    panic("as_vas_new_page(): vm_mm_rsv() failed");
    return -1;
  }
  vas.npages = 0;
  for (i = 0; i < PAGE_SIZE / sizeof (struct s_vas_data); ++i)
    memcpy(&(*vas_page)[i], &vas, sizeof (struct s_vas_data));
  return 0;
}

static int	as_vm_get_free_vas(t_as *as, struct s_vas_data **vas, t_vmflags flags)
{
  unsigned int	i;
  unsigned int	j;

  for (i = 0; i < AS_DATA_LIST_SIZE; ++i)
  {
    if (as->vas[i])
    {
      for (j = 0; j < PAGE_SIZE / sizeof (struct s_vas_data) - (((flags & VM_FLAG_FORCE) == VM_FLAG_FORCE) ? 0 : 2); ++j)
      {
        if (!(&as->vas[i][j])->npages)
	{
          *vas = &as->vas[i][j];
	  return 0;
	}
      }
    }
    else
    {
      /* Need to rsv 1 page */
      if (as_vas_new_page(&as->vas[i]) < 0)
      {
        panic("as_vm_get_free_vas(): as_vas_new_page() failed");
        return -1;
      }
      *vas = as->vas[i];
      return 0;
    }
  }
  panic("as_vm_get_free_vas(): no space left");
  return -1;
}

static int	as_vm_new_as(t_as *as,
                             struct s_vas_data *next,
			     t_vaddr addr,
			     t_vsize npages,
			     struct s_vas_data **vas,
			     t_vmflags flags)
{
  if (as_vm_get_free_vas(as, vas, flags) < 0)
    return -1;
  (*vas)->next = next;
  (*vas)->vaddr = addr;
  (*vas)->npages = npages;
  (*vas)->is_mapped = 0;
  (*vas)->paddr = 0;
  (*vas)->attr = VM_ATTR_EXEC | VM_ATTR_READ | VM_ATTR_WRITE;
  return 0;
}

static int		as_vm_add_specific(t_as *as, t_vaddr addr, t_vsize npages, t_vmflags flags, t_vaddr *new_addr)
{
  struct s_vas_data	*vas_cur;
  struct s_vas_data	*vas_last;
  struct s_vas_data	*vas;
  const int		vm_base = 0xd0000000;

  if (!as->vas_list)
  {
    if (as_vm_new_as(as, NULL, addr, npages, &as->vas_list, flags) < 0)
    {
      panic("as_vm_add_specific(): as_vm_new_as() failed");
      return -1;
    }
    if ((flags & VM_FLAG_ANY) == VM_FLAG_ANY)
    {
      as->vas_list->vaddr = vm_base;
      *new_addr = as->vas_list->vaddr;
    }
    return 0;
  }
  if (!as->vas_list->next)
  {
    if (as_vm_new_as(as, NULL, addr, npages, &as->vas_list->next, flags) < 0)
    {
      panic("as_vm_add_specific(): as_vm_new_as() failed");
      return -1;
    }
    if ((flags & VM_FLAG_ANY) == VM_FLAG_ANY)
    {
      as->vas_list->next->vaddr = as->vas_list->vaddr + as->vas_list->npages * PAGE_SIZE;
      *new_addr = as->vas_list->next->vaddr;
    }
    return 0;
  }
  if (as_vm_new_as(as, NULL, addr, npages, &vas, flags) < 0)
  {
    panic("as_vm_add_specific(): as_vm_new_as() failed");
    return -1;
  }
  for (vas_cur = as->vas_list;; vas_cur = vas_cur->next)
    if (!vas_cur->next || (addr && vas_cur->next->vaddr > addr))
    {
      if ((flags & VM_FLAG_ANY) == VM_FLAG_ANY)
      {
	 for (vas_last = as->vas_list; vas_last->next; vas_last = vas_last->next)
           ;
         vas->vaddr = vas_last->vaddr + vas_last->npages * PAGE_SIZE;
	 *new_addr = vas->vaddr;
	/*for (vas_cur2 = as->vas_list; vas_cur2->next; vas_cur2 = vas_cur2->next)
	  if (vas_cur2->next->vaddr - (vas_cur2->vaddr + vas_cur2->npages * PAGE_SIZE) >= npages * PAGE_SIZE)
	    break;
	vas->vaddr = vas_cur2->vaddr + vas_cur2->npages * PAGE_SIZE;
	*new_addr = vas->vaddr;*/
      }
      /* ADDED vas->next = vas_cur->next->next; ADDED */
      vas_cur->next = vas;
      return 0;
    }
  panic("as_vm_add_specific(): no space left");
  return -1;
}

/*
** Function used by vm_rsv to seek and add pages.
*/
int			as_vm_add(t_asid asid, t_vaddr *addr, t_vsize npages, t_vmflags flags)
{
  t_as			*as;

  if (as_get(asid, &as) < 0)
  {
    panic("as_vm_add(): as_get() failed");
    return -1;
  }
  if ((flags & VM_FLAG_SPECIFIC) == VM_FLAG_SPECIFIC)
    return as_vm_add_specific(as, *addr, npages, flags, NULL);
  if ((flags & VM_FLAG_ANY) == VM_FLAG_ANY)
    return as_vm_add_specific(as, 0, npages, flags, addr);
  return 0;
}

static int	as_vm_del_as(struct s_vas_data *new, struct s_vas_data **vas)
{
  if ((*vas)->is_mapped)
  {
    panic("Cannot delete a mapped vas");
    return -1;
  }
  (*vas)->npages = 0;
  *vas = new;
  return 0;
}

int			as_vm_del(t_asid asid, t_vaddr addr, t_vsize npages)
{
  t_as			*as;
  struct s_vas_data	*vas_cur;

  if (as_get(asid, &as) < 0 || !as->vas_list)
    return -1;
  if (as->vas_list->vaddr == addr && as->vas_list->npages == npages)
    return as_vm_del_as(as->vas_list->next, &as->vas_list);
  for (vas_cur = as->vas_list; vas_cur->next; vas_cur = vas_cur->next)
    if (vas_cur->next->vaddr == addr && vas_cur->next->npages == npages)
      return as_vm_del_as(vas_cur->next->next, &vas_cur->next);
  return -1;
}

int			as_vm_attr(t_asid asid, t_vaddr vaddr, t_vsize npages, t_vattr attr)
{
  t_as			*as;
  struct s_vas_data	*vas_cur;

  if (as_get(asid, &as) < 0 || !as->vas_list)
  {
    panic("as_vm_attr(): as_get() failed");
    return -1;
  }
  if (as->vas_list->vaddr == vaddr && as->vas_list->npages == npages)
  {
    as->vas_list->attr = attr;
    return 0;
  }
  for (vas_cur = as->vas_list; vas_cur->next; vas_cur = vas_cur->next)
    if (vas_cur->next->vaddr == vaddr && vas_cur->next->npages == npages)
    {
      vas_cur->attr = attr;
      return 0;
    }
  return -1;
}

int			as_vm_attr_get(t_asid asid, t_vaddr vaddr, t_vsize npages, t_vattr *attr)
{
  t_as			*as;
  struct s_vas_data	*vas_cur;

  if (as_get(asid, &as) < 0 || !as->vas_list)
  {
    panic("as_vm_attr_get(): as_get() failed");
    return -1;
  }
  if (as->vas_list->vaddr == vaddr && as->vas_list->npages == npages)
  {
    *attr = as->vas_list->attr;
    return 0;
  }
  for (vas_cur = as->vas_list; vas_cur->next; vas_cur = vas_cur->next)
    if (vas_cur->next->vaddr == vaddr && vas_cur->next->npages == npages)
    {
      *attr = vas_cur->attr;
      return 0;
    }
  return -1;
}

int			as_vaddr_to_paddr(t_asid asid, t_vaddr vaddr, t_paddr *paddr)
{
  t_as			*as;
  struct s_vas_data	*vas_cur;

  if (as_get(asid, &as) < 0 || !as->vas_list)
  {
    panic("as_vaddr_to_paddr(): as_get() failed");
    return -1;
  }
/*   if (vaddr >= as->vas_list->vaddr && vaddr <= as->vas_list->vaddr + as->vas_list->npages * PAGE_SIZE) */
/*   { */
/*     *paddr = vaddr - as->vas_list->vaddr + as->vas_list->paddr; */
/*     printf("vaddr:%x, paddr:%x\n", vaddr, *paddr); */
/*     return 0; */
/*   } */
  for (vas_cur = as->vas_list; vas_cur; vas_cur = vas_cur->next)
    if (vaddr == vas_cur->vaddr)
      {
	*paddr = vas_cur->paddr;
	return 0;
      }
  panic("as_vaddr_to_paddr(): vaddr not found");
  return -1;
}

int			as_paddr_to_vaddr(t_asid asid, t_paddr paddr, t_vaddr *vaddr)
{
  t_as			*as;
  struct s_vas_data	*vas_cur;

  if (as_get(asid, &as) < 0 || !as->vas_list)
  {
    panic("as_paddr_to_vaddr(): as_get() failed");
    return -1;
  }
/*   if (paddr >= as->vas_list->paddr && paddr <= as->vas_list->paddr + as->vas_list->npages * PAGE_SIZE) */
/*   { */
/*     *vaddr = paddr - as->vas_list->paddr + as->vas_list->vaddr; */
/*     return 0; */
/*   } */
  for (vas_cur = as->vas_list; vas_cur; vas_cur = vas_cur->next)
    if (paddr == vas_cur->paddr)
      {
	*vaddr = vas_cur->vaddr;
	return 0;
      }
  panic("as_paddr_to_vaddr(): paddr not found");
  return -1;
}

void			dump_as(t_asid asid)
{
  t_as			*as;
  struct s_vas_data	*vas_cur;

  if (as_get(asid, &as) < 0 || !as->vas_list)
  {
    panic("as_paddr_to_vaddr(): as_get() failed");
    return;
  }
  printf("*vaddr*******paddr***npages********VAS_MAP******\n");
  for (vas_cur = as->vas_list; vas_cur; vas_cur = vas_cur->next)
    {
      printf("%x*%x*%x\n", vas_cur->vaddr, vas_cur->paddr, vas_cur->npages);
    }
  printf("************************************************\n");
}
