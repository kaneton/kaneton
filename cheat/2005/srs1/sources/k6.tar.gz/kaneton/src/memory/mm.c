#include <mm.h>

int	mm_rsv(t_asid asid, t_vaddr *vaddr, t_vsize npages)
{
  return vm_mm_rsv(asid, vaddr, npages, 0);
}

int	mm_rel(t_asid asid, t_vaddr vaddr, t_vsize npages)
{
  return vm_mm_rel(asid, vaddr, npages);
}
