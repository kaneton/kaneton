#include <paging.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <as.h>
#include <pm.h>
#include <page_directory.h>
#include <vm.h>
#include <vm_ia32.h>
#include <malloc.h>

int		vm_init(void)
{
  /*  map_init_table((void *)0xD0000000); */
  return 0;
}

int	vm_rsv(t_asid asid, t_vaddr *vaddr, t_vsize npages, t_vmflags flags)
{
  return as_vm_add(asid, vaddr, npages, flags);
}

 int	vm_rel(t_asid asid, t_vaddr vaddr, t_vsize npages)
 {
   return as_vm_del(asid, vaddr, npages);
 }

int	vm_attr(t_asid asid, t_vaddr vaddr, t_vsize npages, t_vattr attr)
{
  return as_vm_attr(asid, vaddr, npages, attr);
}

static unsigned long	get_flags_from_attr(t_vattr attr, t_asid asid)
{
  unsigned long		flags = MASK_PD_PRESENT;

  if (asid != kas.asid)
    flags |= MASK_PD_USER;
  if ((attr & VM_ATTR_WRITE) == VM_ATTR_WRITE)
    flags |= MASK_PD_WRITE;
  return flags;
}

int			vm_map(t_asid asid, t_paddr paddr, t_vaddr vaddr, t_vsize npages)
{
  t_vattr		attr = 0;
  unsigned long		flags;
  t_as			*as;
  struct s_vas_data	*vas_cur;
  int			i = 0;

  if (as_pm_del(asid, paddr, npages))
    return -1;
  if (as_get(asid, &as) < 0 || !as->vas_list)
    return -1;
  for (vas_cur = as->vas_list; vas_cur; vas_cur = vas_cur->next)
    {
      if (vas_cur->vaddr == vaddr && vas_cur->npages == npages)
	{
	  vas_cur->is_mapped = 1;
	  vas_cur->paddr = paddr;
	  attr = vas_cur->attr;
	}
    }
  flags = get_flags_from_attr(attr, asid);
  if (((i = map_in_pd(as->pd_addr, (void *)vaddr, (void *)paddr, flags, npages)) > 0) && (asid == kas.asid))
  {
    /*    printf("- as_synchro_pd()\n");*/
    /*    as_synchro_pd(); */
  }
  else if (i < 0)
    return -1;
  pm_addref(paddr);
  return 0;
}

int			vm_unmap(t_asid asid, t_vaddr vaddr, t_vsize npages)
{
  t_paddr		paddr;
  t_as			*as;
  struct s_vas_data	*vas_cur;
  int			j = 0;

  as_vaddr_to_paddr(asid, vaddr, &paddr);
  as_pm_add(asid, paddr, npages);
  if (as_get(asid, &as) < 0 || !as->vas_list)
    return -1;
  for (vas_cur = as->vas_list; vas_cur; vas_cur = vas_cur->next)
    if (vas_cur->vaddr == vaddr && vas_cur->npages == npages)
      vas_cur->is_mapped = 0;
  if ((j = (unmap_in_pd(as->pd_addr, (void *)vaddr, npages)) > 0) && (asid == kas.asid))
    {
      /*      printf("vm_rel : as_synchro_pd()\n"); */
      /*      as_synchro_pd(); */
    }
  else if (j < 0)
    return -1;
  pm_delref(paddr);
  return 0;
}


/*
** functions to alloc and free
**
*/
int	vm_mm_rsv(t_asid asid, t_vaddr *vaddr, t_vsize npages, t_vmflags flags)
{
  t_paddr	paddr;

  //  printf("Calling pm_rsv\n");
  if (pm_rsv(asid, &paddr, npages, PM_FLAG_ANY))
    {
      printf("mm: PM RSV FAILED \n");
      while (1)
	;
    }
  //  printf("Calling vm_rsv\n");
  if (vm_rsv(asid, vaddr, npages, flags))
    {
      printf("mm: VM RSV FAILED \n");
      while (1)
	;
    }
  //  printf("Calling vm_map\n");
  if (vm_map(asid, paddr, *vaddr, npages))
    {
      printf("mm: VM MAP FAILED \n");
      while (1)
	;
    }
  return 0;
}

int	vm_mm_rel(t_asid asid, t_vaddr vaddr, t_vsize npages)
{
  t_paddr	paddr;
  
  if (as_vaddr_to_paddr(asid, vaddr, &paddr))
    {
      printf("mm: as_vaddr_to_paddr failed\n");
      while (1)
	;
    }
  if (vm_unmap(asid, vaddr, npages))
    {
      printf ("mm: VM UNMAP FAILED \n");
      while (1)
	;
    }
  if (vm_rel(asid, vaddr, npages))
    {
      printf ("mm: VM RELEASE FAILED \n");
      while (1)
	;
    }
  if (pm_rel(asid, paddr, npages))
    {
      printf ("mm: PM RELEASE FAILED \n");
      while (1)
	;      
    }
  return 0;
}

int	vm_copy(t_asid from, t_vaddr src, t_asid to, t_vaddr dst, t_vsize nbytes)
{
  t_paddr	src_p;
  t_paddr	dst_p;

  as_vaddr_to_paddr(from, src, &src_p);
  as_vaddr_to_paddr(to, dst, &dst_p);
  memcpy((void *)dst_p, (void *)src_p, nbytes);
  return 0;
}

int			vm_flush(t_asid asid)
{
  t_as			*as;
  struct s_vas_data	*vas_cur;
  struct s_vas_data	*next;

  if (as_get(asid, &as) < 0)
    return -1;
  for (vas_cur = as->vas_list; vas_cur; vas_cur = next)
  {
    next = vas_cur->next;
    vm_unmap(asid, vas_cur->vaddr, vas_cur->npages);
    vm_rel(asid, vas_cur->vaddr, vas_cur->npages);
  }
  return 0;
}

int		vm_clear(void)
{
  return as_vm_clear();
}
