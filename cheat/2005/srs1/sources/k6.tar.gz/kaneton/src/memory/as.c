/*
** Address spaces handling
*/

#include <paging.h>
#include <page_directory.h>
#include <pm.h>
#include <as.h>
#include <string.h>
#include <stdio.h>
#include <mm.h>
#include <kernel.h>

t_as kas;
static t_as *as_list[AS_LIST_SIZE];
static t_asid asid_seq = 0;
char kvas0[PAGE_SIZE];
char pvas0[PAGE_SIZE];

static int	as_list_new_page(t_as **as_list_page)
{
  t_as		as;
  unsigned int	i;

  if (vm_mm_rsv(kas.asid, (t_paddr *) as_list_page, 1, VM_FLAG_FORCE) < 0)
    return -1;
  as.asid = ASID_UNUSED;
  for (i = 0; i < PAGE_SIZE / sizeof (t_as); ++i)
    memcpy(&(*as_list_page)[i], &as, sizeof (t_as));
  return 0;
}

static int             as_pas_new_page(struct s_pas_data **pas_page)
{
  struct s_pas_data    pas;
  unsigned int         i;

  if (vm_mm_rsv(kas.asid, (t_paddr *) pas_page, 1, VM_FLAG_FORCE) < 0) 
    return -1;
  pas.npages = 0;
  for (i = 0; i < PAGE_SIZE / sizeof (struct s_pas_data); ++i)
    memcpy(&(*pas_page)[i], &pas, sizeof (struct s_pas_data));
  return 0;
}

static int		as_data_init(t_as *as)
{
  unsigned int		i;
  struct s_vas_data	vas;
  struct s_pas_data	pas;

  for (i = 0; i < AS_DATA_LIST_SIZE; ++i)
  {
    as->pas[i] = NULL;
    as->vas[i] = NULL;
    as->vas_list = NULL;
  }
  if (as->asid == kas.asid)
  {
    as->vas[0] = (struct s_vas_data *) kvas0;
    as->pas[0] = (struct s_pas_data *) pvas0;
    vas.npages = 0;
    pas.npages = 0;
    for (i = 0; i < PAGE_SIZE / sizeof (struct s_vas_data); ++i)
      memcpy(&as->vas[0][i], &vas, sizeof (struct s_vas_data));
    for (i = 0; i < PAGE_SIZE / sizeof (struct s_pas_data); ++i)
      memcpy(&as->pas[0][i], &pas, sizeof (struct s_pas_data));
    return 0;
  }
  return 0;
}

int		as_init(void)
{
  unsigned int	i;

  asid_seq = 0;
  kas.asid = asid_seq;
  kas.pd_addr = (void *)0x3000;
  as_data_init(&kas);
  for (i = 0; i < AS_LIST_SIZE; ++i)
    as_list[i] = NULL;
  return 0;
}

static t_asid	as_fill(t_as *as)
{
  as->asid = ++asid_seq;
  mm_rsv(kas.asid, (t_vaddr *) &as->pd_addr, 1);
  as_data_init(as);
  return as->asid;
}

/*
** this functions is used to create a new as
** FIXME : dup PD kernel pour init vm.
**         ADD PD ADDR dans la struct
*/

int		as_rsv(t_asid* asid)
{
  unsigned int	i;
  unsigned int	j;
  t_as		*as;

  for (i = 0; i < AS_LIST_SIZE; ++i)
    if (as_list[i])
      for (j = 0; j < PAGE_SIZE / sizeof (t_as); ++j)
      {
        as = &as_list[i][j];
	if (as->asid == ASID_UNUSED)
	{
	  *asid = as_fill(as);
	  return 0;
	}
      }
    else
    {
      /* Need to rsv 1 page */
      if (as_list_new_page(&as_list[i]) < 0)
        return -1;
      as = as_list[i];
      *asid = as_fill(as);
      return 0;
    }
  panic("as_rsv(): no space left\n");
  return -1;
}

int		as_synchro_pd(void)
{
  unsigned int	i;
  unsigned int	j;

  for (i = 0; i < AS_LIST_SIZE && as_list[i]; ++i)
    for (j = 0; j < PAGE_SIZE / sizeof (t_as); ++j)
      synchro_pd((&as_list[i][j])->pd_addr, kas.pd_addr, 0xd0000000);
  return 0;
}

int		as_vm_clear(void)
{
  unsigned int	i;
  unsigned int	j;

  for (i = 0; i < AS_LIST_SIZE && as_list[i]; ++i)
    for (j = 0; j < PAGE_SIZE / sizeof (t_as); ++j)
      vm_flush((&as_list[i][j])->asid);
  return 0;
}

int		as_get(t_asid asid, t_as **as)
{
  unsigned int	i;
  unsigned int	j;
  t_as		*as_cur;

  if (asid == kas.asid)
  {
    /* Kernel AS */
    *as = &kas;
    return 0;
  }
  for (i = 0; i < AS_LIST_SIZE && as_list[i]; ++i)
    for (j = 0; j < PAGE_SIZE / sizeof (t_as); ++j)
    {
      as_cur = &as_list[i][j];
      if (as_cur->asid == asid)
      {
        *as = as_cur;
	return 0;
      }
    }
  panic("as_rsv(): asid not found\n");
  return -1;
}

static int	as_data_free(t_as *as)
{
  unsigned int	i;

  pm_flush(as->asid);
  for (i = 0; i < AS_DATA_LIST_SIZE && as->vas[i]; ++i)
    pm_rel(kas.asid, (t_paddr) as->vas[i], 1); /* FIXME: call vm_flush() ? */
  return 0;
}

int		as_rel(t_asid asid)
{
  t_as		*as;

  if (as_get(asid, &as) < 0)
    return -1;
  as->asid = ASID_UNUSED;
  as_data_free(as);
  return 0;
}

/*
** Function used to duplicate an as.
** FIXME : dupliquer virtuel. (en pesant a add ref physique sur les pages users)
*/

int		as_clone(t_asid old, t_asid new)
{
  t_as		*as_old;
  t_as		*as_new;
  unsigned int	i;

  if (as_get(old, &as_old) < 0 || as_get(new, &as_new) < 0)
    return -1;
  as_data_free(as_new);
  as_data_init(as_new);
  for (i = 0; i < AS_DATA_LIST_SIZE && as_old->pas[i]; ++i)
  {
    pm_rsv(kas.asid, (t_paddr *) as_new->pas[i], 1, PM_FLAG_ANY);
    memcpy(as_new->pas[i], as_old->pas[i], PAGE_SIZE);
  }
  for (i = 0; i < AS_DATA_LIST_SIZE && as_old->vas[i]; ++i)
  {
    pm_rsv(kas.asid, (t_paddr *) as_new->vas[i], 1, PM_FLAG_ANY);
    memcpy(as_new->vas[i], as_old->vas[i], PAGE_SIZE);
  }
  *as_new = *as_old;
  return 0;
}

int		as_clear(void)
{
  unsigned int	i;
  unsigned int	j;
  t_as		*as;

  for (i = 0; i < AS_LIST_SIZE && as_list[i]; ++i)
  {
    for (j = 0; j < PAGE_SIZE / sizeof (t_as); ++j)
    {
      as = as_list[i] + j * sizeof (t_as);
      if (as->asid != ASID_UNUSED)
        as_data_free(as);
    }
    pm_rel(kas.asid, (t_paddr) as_list[i], 1);
  }
  as_init();
  return 0;
}

int			as_data_print(t_as *as)
{
  unsigned int		i;
  unsigned int		j;
  struct s_pas_data	*pas;
  struct s_vas_data	*vas_cur;
  unsigned int		pas_count = 0;
  unsigned int		vas_count = 0;

  for (i = 0; i < AS_DATA_LIST_SIZE && as->pas[i]; ++i)
    for (j = 0; j < PAGE_SIZE / sizeof (struct s_pas_data); ++j)
    {
      pas = &as->pas[i][j];
      if (pas->npages > 0)
      {
        printf("    pas: [addr: %x][npages: %d]\n", pas->addr, pas->npages);
	++pas_count;
      }
    }
  printf("    %d pas found.\n", pas_count);
  for (vas_cur = as->vas_list; vas_cur; vas_cur = vas_cur->next)
  {
    printf("    vas: [vaddr: %x][npages: %d][attr: %x][is_mapped: %d][paddr: %x]\n",
      vas_cur->vaddr, vas_cur->npages, vas_cur->attr, vas_cur->is_mapped, vas_cur->paddr);
    ++vas_count;
  }
  printf("    %d vas found.\n", vas_count);
  return 0;
}

int		as_print(void)
{
  unsigned int	i;
  unsigned int	j;
  unsigned int	as_count = 1;
  t_as		*as;

  printf("KAS: [asid: %d]\n", kas.asid);
  as_data_print(&kas);
  for (i = 0; i < AS_LIST_SIZE && as_list[i]; ++i)
    for (j = 0; j < PAGE_SIZE / sizeof (t_as); ++j)
    {
      as = &as_list[i][j];
      if (as->asid != ASID_UNUSED)
      {
        printf("AS: [asid: %d]\n", as->asid);
	as_data_print(as);
	++as_count;
      }
    }
  printf("%d address space(s) found.\n", as_count);
  return 0;
}

int			as_pm_add(t_asid asid, t_paddr addr, t_psize npages)
{
  t_as			*as;
  struct s_pas_data	*pas;
  unsigned int		i;
  unsigned int		j;

  if (as_get(asid, &as) < 0)
    return -1;
  for (i = 0; i < AS_DATA_LIST_SIZE; ++i)
  {
    if (as->pas[i])
      for (j = 0; j < PAGE_SIZE / sizeof (struct s_pas_data); ++j)
      {
        pas = &as->pas[i][j];
        if (!pas->npages)
        {
          pas->addr = addr;
          pas->npages = npages;
	  return 0;
        }
      }
    else
    {
      /* Need to rsv 1 page */
      if (as_pas_new_page(&as->pas[i]) < 0)
        return -1;
      pas = as->pas[i];
      pas->addr = addr;
      pas->npages = npages;
      return 0;
    }
  }
  /* No space left */
  panic("as_pm_add(): no space left\n");
  return -1;
}

int			as_pm_del(t_asid asid, t_paddr addr, t_psize npages)
{
  t_as			*as;
  struct s_pas_data	*pas;
  unsigned int		i;
  unsigned int		j;

  if (as_get(asid, &as) < 0)
    return -1;
  for (i = 0; i < AS_DATA_LIST_SIZE && as->pas[i]; ++i)
    for (j = 0; j < PAGE_SIZE / sizeof (struct s_pas_data); ++j)
    {
      pas = &as->pas[i][j];
      if (pas->npages == npages && pas->addr == addr)
        pas->npages = 0;
    }
  return 0;
}

int			as_pm_top(t_asid asid, t_paddr *addr, t_psize *npages)
{
  t_as			*as;
  struct s_pas_data	*pas;
  unsigned int		i;
  unsigned int		j;

  if (as_get(asid, &as) < 0)
    return -2;
  for (i = 0; i < AS_DATA_LIST_SIZE && as->vas[i]; ++i)
    for (j = 0; j < PAGE_SIZE / sizeof (struct s_pas_data); ++j)
    {
      pas = &as->pas[i][j];
      if (pas->npages)
      {
        *addr = pas->addr;
	*npages = pas->npages;
	return 0;
      }
    }
  /* No more pas. */
  return -1;
}

int	as_tskid(t_asid asid, t_tskid *tskid)
{
  t_as	*as;

  if (as_get(asid, &as) < 0)
    return -1;
  *tskid = as->tskid;
  return 0;
}

int	as_modid(t_asid asid, t_modid *modid)
{
  t_as	*as;

  if (as_get(asid, &as) < 0)
    return -1;
  *modid = as->modid;
  return 0;
}

int	as_ownid(t_asid asid, t_ownid *ownid)
{
  t_as	*as;

  if (as_get(asid, &as) < 0)
    return -1;
  *ownid = as->ownid;
  return 0;
}

int	as_give(t_asid asid, t_ownid ownid)
{
  t_as	*as;

  if (as_get(asid, &as) < 0)
    return -1;
  as->ownid = ownid;
  return 0;
}

int	as_attach(t_asid asid, t_tskid tskid)
{
  /* FIXME */
  return 0;
}

int	as_detach(t_tskid tskid)
{
  /* FIXME */
  return 0;
}
