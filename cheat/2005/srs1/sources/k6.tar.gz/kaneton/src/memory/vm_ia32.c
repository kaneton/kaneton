/*
** Machdep functions used by vm handler.
** Mainly PD and PT tools.
*/

#include <page_table.h>
#include <page_directory.h>
#include <pm.h>
#include <paging.h>
#include <as.h>
#include <stdlib.h>
#include <stdio.h>
#include <kernel.h>
#include <string.h>

#define INVLPG(addr)   \
__asm__ __volatile__("invlpg %0": :"m" (*((char *)addr)))


#define FIRST_PT_PTK	0x3f0000

/*
** Helper functions
*/

/* static int	pt_vaddr_to_paddr(void *vaddr, void **paddr) */
/* { */
/*   struct x86_pte *ptt_addr = ((struct x86_pte *)(ADDR_PTT)); */

/*   if (!PT_PRESENT(ptt_addr, VIRT_TO_PT_INDEX(vaddr))) */
/*     return -1; */
/*   *paddr = (void *)ptt_addr[VIRT_TO_PT_INDEX(vaddr)].paddr; */
/*   return 0; */
/* } */

static int	pt_paddr_to_vaddr(void *paddr, void **vaddr)
{
  struct x86_pte *ptt_addr = ((struct x86_pte *)(ADDR_PTT));
  int		i;

  for (i = 0; i < 1024; i++)
    {
      if (!PT_PRESENT(ptt_addr, i))
      	continue;
      if ((void *)(ptt_addr[i].paddr << 12) == paddr)
	{
	  *vaddr = (void *)((2 << 22) + (i << 12));
	  break;
	  return 0;
	}
    }
  return 0;
  return -1;
}


static int	find_free_entry_in_ptt(struct x86_pte *pt_addr, int *entry)
{
  int		i;

  *entry = 0;
  for (i = 0; i < 1024 ; i++)
    {
      if (!PT_PRESENT(pt_addr, *entry))
	return 0;
      (*entry)++;
    }
  printf("[ERROR] No free entry found \n");
  return -1;
}

static int	 create_k_pt_in_ptt(t_paddr *paddr, t_vaddr *vaddr)
{
  int		 entry;
  struct x86_pte *ptt_addr = ((struct x86_pte *)(ADDR_PTT));

  if (pm_rsv(0, paddr, 1, PM_FLAG_PT))
    {
      printf("vm_ia32: can't rsv phys mem for pt\n");
      return -1;
    }
  if (find_free_entry_in_ptt(ptt_addr, &entry))
    {
      printf("vm_ia32: cannot found free entry in ptt\n");
      return -1;
    }
  *vaddr = (2 << 22) + (entry << 12);
  insert_pt_entry((struct x86_pte *)(*paddr),
		  0,
		  FL_PT_PRESENT | FL_PT_WRITE,
		  ptt_addr,
		  VIRT_TO_PT_INDEX(*vaddr));
  return 0;
}

static int	 delete_k_pt_in_ptt(t_paddr paddr, t_vaddr vaddr)
{
  struct x86_pte *ptt_addr = ((struct x86_pte *)(ADDR_PTT));

  delete_pt_entry((struct x86_pte *)(ptt_addr),
		  VIRT_TO_PT_INDEX(vaddr));
  if (pm_rel(kas.asid, paddr, 1))
    return -1;
  INVLPG(vaddr);
  return 0;
}


/*
** Function used to init a PT for PD management.
**   Deprecated
*/
int	map_init_table(void *vaddr)
{

  /* FIXME : MM_RSV A PAGE IN PTT */

  struct x86_pte	*pt_addr = (struct x86_pte *) FIRST_PT_PTK;
  struct x86_pde	*pd_addr = (struct x86_pde *) 0x3000;

  if (!PD_PRESENT(pd_addr, VIRT_TO_PD_INDEX(vaddr)))
    {
      init_pt(pt_addr);
      insert_pd_entry_s(pt_addr, 0, MASK_PD_WRITE | MASK_PD_PRESENT, pd_addr, VIRT_TO_PD_INDEX(vaddr));
    }
  return 0;
}



/*
** Function used to map in a page directory 1 v_addr to 1 p_addr
*/
int			map_table_in_pd(struct x86_pde	*pd_addr,
					void		*vaddr,
					void		*paddr,
					unsigned long	flags)
{
  int			ret = 0;
  struct x86_pte	*pt_paddr = NULL;
  struct x86_pte	*pt_vaddr = NULL;

  if (!PD_PRESENT(pd_addr, VIRT_TO_PD_INDEX(vaddr)))
    {
      if (create_k_pt_in_ptt((void *) &pt_paddr, (void *) &pt_vaddr))
	{
	  panic("vm_ia32: map_in_pd : unable to create pt in ptt\n");
	  return -1;
	}
      init_pt(pt_vaddr);
      insert_pd_entry_s(pt_paddr, 0, flags, pd_addr, VIRT_TO_PD_INDEX(vaddr));
      ret++;		/* Return 1 when a PT is created */
    }
  else
    {
      pt_paddr = (struct x86_pte *) ((pd_addr[VIRT_TO_PD_INDEX(vaddr)].pt_paddr) << 12);
      if ((ret = pt_paddr_to_vaddr(pt_paddr, (void **) (void *) &pt_vaddr)) != 0)
	{
	  printf("UNABLE TO RESOLVE ADDRESS RESOLUTION : %x ret:%d \n", (unsigned int) pt_paddr, ret);
	  return -1;
	}
    }
  
  if (!PT_PRESENT(pt_vaddr, VIRT_TO_PT_INDEX(vaddr)))
    {
      insert_pt_entry(paddr,
		      0,
		      flags | MASK_PT_PRESENT,
		      pt_vaddr,
		      VIRT_TO_PT_INDEX(vaddr));
    }
  else
    {
      printf("vm_ia32: map_in_pd : PT allready present\n");
      return -1;
    }
  return ret;
}


/*
** Helper Function for unmap_table_in_pd to know if a PT is free
**   Return 1 if PT is free.
*/
static int	is_pt_free(struct x86_pte *pt_addr)
{
  int	pte = 0;

  while(pte < 1024)
    {
      if (PT_PRESENT(pt_addr, pte))
	return 0;
      pte++;
    }
  return 1;
}


/*
** Function used to UNmap 1 virtual adress in a page directory
*/
int			unmap_table_in_pd(struct x86_pde	*pd_addr,
					  void			*vaddr)
{
  struct x86_pte	*pt_paddr = NULL;
  struct x86_pte	*pt_vaddr = NULL;

  pt_paddr = (struct x86_pte *) ((pd_addr[VIRT_TO_PD_INDEX(vaddr)].pt_paddr) << 12);
  pt_paddr_to_vaddr(pt_paddr, (void **) (void *) &pt_vaddr);
  if (PT_PRESENT(pt_vaddr, VIRT_TO_PT_INDEX(vaddr)))
    {
      delete_pt_entry(pt_vaddr, VIRT_TO_PT_INDEX(vaddr));
    }
  else
    return -1;
  if (is_pt_free(pt_vaddr))
    {
      delete_pd_entry(pd_addr, VIRT_TO_PD_INDEX(vaddr));
      if (delete_k_pt_in_ptt((t_paddr)pt_paddr, (t_vaddr)pt_vaddr))
	return -1;
      return 1;			/* Return 1 when a PT is deleted */
    }
  return 0;
}


/*
** Function used to map nb_pages pages in a page directory
**
*/
int		map_in_pd(struct x86_pde	*pd_addr,
			  void			*vaddr,
			  void			*paddr,
			  unsigned long		flags,
			  unsigned int		nb_pages)
{
  unsigned int	i;
  int		j = 0;

  if (flags != 0x3)
    printf("\n flag : %x\n", (unsigned int)flags);

  // Debuging hack
  flags = 0x3;

  //printf("vm_ia32: mapping : %x size : %d\n", (unsigned int)vaddr, nb_pages);
  for (i = 0; i < nb_pages; i++)
    {
      if((j += map_table_in_pd(pd_addr, vaddr + 0x1000 * i, paddr + 0x1000 * i, flags)) < 0)
	{
	  printf("vm_ia32 : Error\n");
	  return -1;
	}
      // For debug
      else
	{
	  memset(vaddr + 0x1000 * i, 0xf, 10);
	}
    }
  return j ? 1 : 0;
}


/*
** Function used to UNmap nb_pages pages in a page directory
*/
int		unmap_in_pd(struct x86_pde	*pd_addr,
			    void		*vaddr,
			    unsigned int	nb_pages)
{
  unsigned int	i = 0;
  int		j = 0;
  
  for (i = 0; i < nb_pages; i++)
    {
      switch (unmap_table_in_pd(pd_addr, vaddr + 0x1000 * i ))
	{
	case -1 :
	  return -1;
	  break;
	case 1:
	  j++;
	  break;
	}
      INVLPG(vaddr);
    }
  return j ? 1 : 0;
}


/*
** Function used to know if a vaddr is in an present PT
**   Return 1 if present
**
** Notes : Will be probably extended one day to n pages
**         Or will be changed to a macro
*/
int	is_addr_in_pt(struct x86_pde *pd_addr, void *vaddr)
{
  if (PD_PRESENT(pd_addr, VIRT_TO_PD_INDEX(vaddr)))
    return 1;
  return 0;
}
