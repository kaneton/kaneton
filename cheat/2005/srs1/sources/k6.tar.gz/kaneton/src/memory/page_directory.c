#include <paging.h>
#include <page_directory.h>
#include <string.h>

/*
** Function used to clean a page directory
*/
void init_pd(void *pd_paddr)
{
  memset(pd_paddr, 0, 4096);
}

/*
** Function used to copy a page directory
**
** Notes : Mainly used when generating new as
**         the function does not malloc the page directory.
*/
void	copy_pd(struct x86_pde *pd_dest, const struct x86_pde *pd_src)
{
  memcpy(pd_dest, pd_src, 4096);
}

/*
** Syncronise page directory from kernel page directory
*/
void	synchro_pd(struct x86_pde *pd_dest, const struct x86_pde *kernel, int entry)
{
  memcpy(pd_dest + entry, kernel + entry, 4096 - entry * 4);
}

/*
** Function used as interface to match insert_pt_entry
** Function used to add an entry in a page directory
** 
*/
void	insert_pd_entry_s(void			*pt_paddr,
			  unsigned long		custom,
			  unsigned long		flags,
			  struct x86_pde	*pd_addr,
			  int			entry)
{
  pd_addr[entry].present	=  flags & MASK_PD_PRESENT;
  pd_addr[entry].write		= (flags & MASK_PD_WRITE) >> 1;
  pd_addr[entry].user		= (flags & MASK_PD_USER) >> 2;
  pd_addr[entry].write_through	= (flags & MASK_PD_WRITE_THROUGH) >> 3;
  pd_addr[entry].cache_disabled	= (flags & MASK_PD_CACHE_DIS) >> 4;
  pd_addr[entry].accessed	= (flags & MASK_PD_ACCESSED) >> 5;
  pd_addr[entry].zero		= (flags & MASK_PD_ZERO) >> 6;
  pd_addr[entry].page_size	= (flags & MASK_PD_PAGESIZE) >> 7;
  pd_addr[entry].global_page	= (flags & MASK_PD_GLOBAL_PAGE) >> 8;

  pd_addr[entry].custom		=  custom & MASK_PD_CUST;
  pd_addr[entry].pt_paddr	= (unsigned long) pt_paddr >> 12;
}

/*
** Old function. Keeped for compatibility with old code
**   Will be deleted when old code will use the interface
*/
void insert_pd_entry(void *pd_addr, unsigned long write, void *pt_paddr)
{

  struct x86_pde *pde_paddr = pd_addr;

  pde_paddr->present = MASK_PD_PRESENT;
  pde_paddr->write = write;
  pde_paddr->user = 0;
  pde_paddr->write_through = 0;
  pde_paddr->cache_disabled = 0;
  pde_paddr->accessed = 0;
  pde_paddr->zero = 0;
  pde_paddr->page_size = 0;
  pde_paddr->global_page = 0;
  pde_paddr->custom = 0;
  pde_paddr->pt_paddr = (unsigned long) pt_paddr >> 12;
}

/*
** Function used to delete an entry in a page directory
*/
void delete_pd_entry(struct x86_pde *pd_addr, int entry)
{
  pd_addr[entry].present = 0;
}
