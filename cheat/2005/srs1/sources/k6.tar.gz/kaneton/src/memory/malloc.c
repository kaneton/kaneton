#include <types.h>
#include <string.h>
#include <mm.h>
#include <stdlib.h>
#include <malloc.h>
#include <paging.h>

#include <stdio.h> /* TO DEL */

// Temporary hack. For kernel.
void	*first_page;

/*
** Hack function
*/
void		init_malloc(void)
{
  first_page = NULL;
}

/*
** Helper function used to debug malloc
*/
void			debug_malloc(void)
{
  struct s_mpage	*cur_page;
  struct s_mblock	*cur_block;

  printf("Dropping mem. Start @ %x\n", (unsigned int)first_page);
  for (cur_page = first_page; cur_page != NULL; cur_page = NEXT_PAGE(cur_page))
    {
      printf("Parsing page %x nbpage: %d nbblocks: %d\n", (unsigned int)cur_page, cur_page->nbpages, cur_page->nbblocks);
      for (cur_block = GET_FIRST_BLOCK(cur_page); cur_block != NULL; cur_block = NEXT_BLOCK(cur_block))
	{
	  printf("Block: %x size: %x free: %d next:%x\n", (unsigned int)cur_block, cur_block->size * 8, cur_block->free, (unsigned int)NEXT_BLOCK(cur_block));
/* 	  if ((NEXT_BLOCK(cur_block) != 0) && */
/* 	      (unsigned int)cur_block + cur_block->size * 8 + sizeof (struct s_mblock) != NEXT_BLOCK(cur_block)) */
/* 	    panic("malloc insane\n"); */
	  if (cur_block->size == 0)
	    while(1)
	      ;
	}
    }
}



/*
** Helper function which rsv a page and create a block
** corresponding to the size of the page in it
** return : a pointer to the page
*/
static void	*create_page(size_t size)
{
  struct s_mpage	*new_page;
  struct s_mblock	*new_block;
  unsigned int		nb_pages;
  
  nb_pages = (size + sizeof (struct s_mpage) + sizeof (struct s_mblock))/ PAGE_SIZE + 1;
  //printf("Calling mm rsv. with kas.asid and nb pages : %d\n", nb_pages);
  if (mm_rsv(kas.asid, (void *) &new_page, nb_pages)) /* FIXME : asid */
    {
      //printf("MM RSV FAILED\n");
      return NULL;
    }
  //printf("GOT PAGE %x \n", (unsigned int)new_page);
  new_page->nbpages = nb_pages;
  new_page->nbblocks = 0;
  new_block = GET_FIRST_BLOCK(new_page);
  SET_NEXT_BLOCK(new_block, NULL);
  new_block->free = FREE;
  new_block->size = (nb_pages * OCT(PAGE_SIZE)) - sizeof(struct s_mpage);
  return new_page;
}

/*
** Helper function which take a free block, split it 
** correponding to size. It doesn't split if no enough place
*/

static void	split_block(struct s_mblock *cur_block, size_t size)
{
  struct s_mblock	*new_block;

  /* Moduler la size pour que ca fasse la taile qu'il faut	*/
  /* si indisponible : Ne pas splitter et garder la size	*/
  /* FIXME */

  if (cur_block->size > size + sizeof(struct s_mblock))
    {
      new_block = (struct s_mblock *)((t_vaddr)cur_block + size + sizeof(struct s_mblock));
      SET_NEXT_BLOCK(new_block, NEXT_BLOCK(cur_block));
      new_block->free = FREE;
      new_block->size = cur_block->size - size - sizeof (struct s_mblock);
      cur_block->size = size;
      SET_NEXT_BLOCK(cur_block, new_block);
    }
}

/*
** Helper function which alloc in a block
** return : pointer on the data.
*/

static void	*alloc_block(struct s_mpage *cur_page, struct s_mblock *cur_block)
{
  cur_block->free = NOT_FREE;
  cur_page->nbblocks++;
  //printf("****************************Malloc *\n");
  //debug_malloc();	/* FIXME */
  return GIVE_BLOCK(cur_block);
}

void			*malloc(size_t size)
{
  struct s_mpage	*cur_page;
  struct s_mblock	*cur_block;
  struct s_mpage	*tmp_page;

  /* printf("MALLOC: %d\n", size); */
  if (size < 1)
    return NULL;
  /* FIXME : alignement */
  for (cur_page = first_page; cur_page != NULL; cur_page = NEXT_PAGE(cur_page))
    {
      if (NEXT_PAGE(cur_page)->nbblocks == 0)
	{
	  tmp_page = NEXT_PAGE(cur_page);
	  SET_NEXT_PAGE(cur_page, NEXT_PAGE(NEXT_PAGE(cur_page)));
	  //printf("RELEASING [%x] %d  ", (unsigned int)tmp_page, (t_vsize)(tmp_page->nbpages));
	  mm_rel(kas.asid, (t_vaddr)(tmp_page), (t_vsize)(tmp_page->nbpages));	/* FIXME : asid */
	  //printf("      done \n");
	}
      /* FIXME  Si nb block 0 et taille >> Superieur au malloc. -> On mm_rel et on reconstruit*/
      //      if (cur_page ->nbpages * OCT(PAGE_SIZE) > size)
      //	{
	  for (cur_block = GET_FIRST_BLOCK(cur_page); cur_block != NULL;)
	    {
	      if (cur_block->free)
		{
		  if (cur_block->free == IN_FREEING)
		    {
		      cur_block->free = FREE;
		      cur_page->nbblocks--;
		    }
		  if (NEXT_BLOCK(cur_block) && NEXT_BLOCK(cur_block)->free)
		    {
		      if (NEXT_BLOCK(cur_block)->free == IN_FREEING)
			cur_page->nbblocks--;
		      NEXT_BLOCK(cur_block)->free = FREE;
		      cur_block->size = NEXT_BLOCK(cur_block)->size + cur_block->size + sizeof(struct s_mblock);
		      SET_NEXT_BLOCK(cur_block, NEXT_BLOCK(NEXT_BLOCK(cur_block)));
		      continue;
		    }
		  if (size < cur_block->size)
		    {
		      split_block(cur_block, size);
		      return alloc_block(cur_page, cur_block);
		    }
		}
	      cur_block = NEXT_BLOCK(cur_block);
	    }
	  //	}
    }
  if ((cur_page = create_page(size)) == NULL)
    return NULL;
  SET_NEXT_PAGE(cur_page, first_page);
  first_page = cur_page;
  cur_block = GET_FIRST_BLOCK(cur_page);
  split_block(cur_block, size);
  return alloc_block(cur_page, cur_block);
}

void			free(void *ptr)
{
  struct s_mblock	*block;

  block = GET_BLOCK(ptr);
  if (block->free)
    {
      printf("Error : Chuck pointer allready free\n");
      return;		/* Error. Chunk pointer allready free */
    }
  block->free = IN_FREEING && 0;
  //printf("****************************Free *\n");
  //debug_malloc();	/* FIXME */
  /* FIXME: Si Donnee grosse : -> Parcour pour la retrouver et faire le free reel. */
  return;
}

void	*realloc(void *ptr, size_t size)
{
  ptr = ptr;
  size = size;
  /* Recup le bock */
  /* Si cool nouvelle taille rentre. -> Ok, on concatene */
  /* Sinon : On malloc un nouveau truc */
  /*         On copie */
  /*         On free */
  return NULL;
}

void	*calloc(size_t nmemb, size_t size)
{
  void	*ptr;

  ptr = malloc(nmemb * size);
  if (ptr)
    memset(ptr, 0, nmemb * size);
  return ptr;
}
