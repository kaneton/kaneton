#include <machdep/pm.h>

i_machdep_pm	machdep_pm_interface =
{
  ia32_pm_init
};

int		ia32_pm_init(void)
{
  t_segid	res1;
  t_segid	res2;

  seg_init();
  seg_add(0,0xfffff, PL_READ | PL_EXEC | PL_SERVICE, SEG_TYPE_MEM, &res1);
  seg_add(0,0xfffff, PL_READ | PL_WRITE | PL_SERVICE, SEG_TYPE_MEM, &res2);
  return 0;
}
