#include <paging.h>
#include <multiboot.h>
#include <page_directory.h>
#include <page_table.h>
#include <string.h>
#include <gdt.h>

void	make_pt_identity(struct x86_pte *pt_paddr)
{
  int	i;

  init_pt(pt_paddr);
  for (i = 0; i != 1024; i++)
    insert_pt_entry((void *) (i * PAGE_SIZE), 0,
                    FL_PT_PRESENT | FL_PT_WRITE,
                    pt_paddr, i);
}

void	make_pt_PMarea(struct x86_pte *pt_paddr, unsigned int size)
{
  int	i;
  int	n = (size >> 12) / 1024;

  for (i = 0; i <= n; i++)
    insert_pt_entry((void *) (i * PAGE_SIZE + ADDR_P_PMTAB), 0,
                    FL_PT_PRESENT | FL_PT_WRITE,
                    pt_paddr, VIRT_TO_PT_INDEX(ADDR_V_PMTAB) + i);
}


int	k_update_cr3(struct x86_pde *pde, struct x86_pdbr *cr3)
{
  unsigned long int cr0;

  memset(cr3, 0, sizeof (struct x86_pdbr));
  cr3->pd_paddr = (unsigned long int) pde >> 12;
  cr3->write_through = 0;
  cr3->cache_disabled = 0;


  __asm__ volatile ("mov %0, %%eax\n"
                    "mov %%eax, %%cr3\n"
                    : : "g" (*cr3));

  __asm__ volatile ("movl %%cr0, %%eax\n"
                    : "=r" (cr0) : :"memory");

  cr0 = cr0 | PAGING_FLAG;
 
  __asm__ volatile ("mov %0, %%eax\n"
                    "mov %%eax, %%cr0"
                    : : "g" (cr0));
  return 0;
}

/*
 * Sets up and maps pages for kernel and activates the paged memory mode.
 */
int		k_paging_setup(multiboot_info_t *mbi)
{
  struct x86_pdbr	cr3;
  struct x86_pde	*pde = (struct x86_pde *) ADDR_PD;
  struct x86_pte	*pti = (struct x86_pte *) ADDR_PTI;
  struct x86_pte	*ptk = (struct x86_pte *) ADDR_PTK;
  struct x86_pte	*ptm = (struct x86_pte *) ADDR_PTM;
  struct x86_pte	*ptt = (struct x86_pte *) ADDR_PTT;
  struct x86_pte	*pth = (struct x86_pte *) ADDR_PTH;
  struct x86_pte	*ptpm = (struct x86_pte *) ADDR_PTAP;
  module_t		*pmod;
  int			i = 0;
  int			size = 0;

  init_pd(pde);

  make_pt_identity(pti);
  insert_pd_entry(pde + 0, 1, pti);

  /* Count the number of pages used by the kernel code and prepare his
     page tables entries */
  /* Insert the page directory entry so that the kernel is mapped in 0xC000000 */
  init_pt(ptk);
  pmod = (module_t *) mbi->mods_addr;
  size = (pmod->mod_end >> 12) - (pmod->mod_start >> 12);
  for (i = 0; i < size; i++)
    insert_pt_entry((void *)(pmod->mod_start + 4096 * i), 0, FL_PT_PRESENT, ptk, i);
  insert_pd_entry(pde + VIRT_TO_PD_INDEX(ADDR_V_KERNEL), 1, ptk);

  init_pt(ptm);
  insert_pt_entry(ptt, 0, FL_PT_PRESENT | FL_PT_WRITE, ptm, 0);
  insert_pd_entry(pde + 1, 1, ptm);

  init_pt(ptt);
  insert_pt_entry((void *) ADDR_GDT, 0, FL_PT_PRESENT | FL_PT_WRITE, ptt, 0) ;
  insert_pd_entry(pde + 2, 1, ptt);

  init_pt(pth);
  insert_pd_entry(pde + 3, 1, pth);

  init_pt(ptpm);
  make_pt_PMarea(ptpm, mbi->mem_upper * 1024 + 0x100000);
  insert_pd_entry(pde + VIRT_TO_PD_INDEX(ADDR_V_PMTAB), 1, ptpm);

  //  init_pt(ptvm);
  //  make_pt_VMarea(ptvm);
  //  insert_pd_entry(pde + VIRT_TO_PD_INDEX(ADDR_V_VMTAB), 1, ptvm);
  k_update_cr3(pde, &cr3);
  k_lgdt(5);
  return 0;
}
