#include <paging.h>
#include <page_table.h>
#include <stdio.h>
#include <string.h>

void	init_pt(void *pt_paddr)
{
  memset(pt_paddr, 0, 1024 * sizeof(struct x86_pte));
}

void	insert_pt_entry(void		*paddr,
			unsigned long	custom,
			unsigned long	flags,
			struct x86_pte	*pt_addr,
			int		entry)
{
  pt_addr[entry].present	= (flags & MASK_PT_PRESENT);
  pt_addr[entry].write		= (flags & MASK_PT_WRITE) >> 1;
  pt_addr[entry].user		= (flags & MASK_PT_USER) >> 2;
  pt_addr[entry].write_through	= (flags & MASK_PT_WRITE_THROUGH) >> 3;
  pt_addr[entry].cache_disabled	= (flags & MASK_PT_CACHE_DIS) >> 4;
  pt_addr[entry].accessed	= (flags & MASK_PT_ACCESSED) >> 5;
  pt_addr[entry].dirty		= (flags & MASK_PT_DIRTY) >> 6;
  pt_addr[entry].zero		= (flags & MASK_PT_ZERO) >> 7;
  pt_addr[entry].global_page	= (flags & MASK_PT_GLOBAL_PAGE) >> 8;

  pt_addr[entry].custom	= custom & MASK_PT_CUST;
  pt_addr[entry].paddr		= (unsigned long) paddr >> 12;
}

void	delete_pt_entry(struct x86_pte *pt_addr, int entry)
{
  pt_addr[entry].present = MASK_PT_NOTPRESENT;
}

