/*
** Physical memory handling
*/

#include <pm.h>
#include <paging.h>
#include <stdio.h>
#include <unistd.h>

/*
** global variables
 */
_t_pm			_pm;
unsigned int		_begin_search;
extern multiboot_info_t	*_mbi;

/*
 * init the table (all integer to 0)
 */
int		pm_init()
{
  unsigned int	i = 0;
  unsigned int	next = _pm._nbpages - 1;
  unsigned int	nbref;
  t_paddr	start = 0;
  t_psize	size = _mbi->mem_upper * 1024 + 0x100000;

  if (machdep_call(pm, pm_init) < 0)
    return -1;

  _pm._start = start;
  _pm._size = size;
  _pm._nbpages = size / 4096;
  _pm._tab = (unsigned int *)ADDR_V_PMTAB;
  pm_clear();
  pm_load_used();

  nbref = PM_NBREF(_pm._nbpages - 1);
  next = _pm._nbpages;
  for (i = _pm._nbpages - 1; i > 0; i--)
    {
      if (nbref == PM_NBREF(i))
	PM_SETPOS(i, 0);
      else
	{
	  PM_SETPOS(i + 1, next);
	  next = i + 1;
	  nbref = PM_NBREF(i);
	}
    }
  PM_SETPOS(i, next);

  _begin_search = 0;

  return 0;
}

/*
** setup the table with all used page with pd and pts
**  Dont call this function if there is pages not in idt
 */
void			pm_load_used(void)
{
  struct x86_pte	*pt;
  struct x86_pde	*pd = (struct x86_pde *)ADDR_PD;
  int			pde = 0;
  int			pte = 0;

  while (pde < 1024)
    {
      if ((pd[pde]).present == 1)
	{
	  pt = (struct x86_pte *) (pd[pde].pt_paddr << 12);
	  while (pte < 1024)
	    {
	      if (pt[pte].present == 1)
		  PM_ADDREF((pt[pte].paddr << 12) / PAGE_SIZE);
	      pte++;
	    }
	  pte = 0;
	}
      pde++;
    }
}

/*
** Used for debug
*/

int		dump_map(void)
{
  unsigned int	i = 0;
  int		k;

  printf("MAX : %d\n", _pm._nbpages);
  while (i < _pm._nbpages)
    {
      if (PM_POS(i) != 0)
	{
	  for (k = 0; k < 10000000; k++);
	  printf("@ %d ::: ref: %d, pos : %d:\n", i, PM_NBREF(i), PM_POS(i));
	}
      i++;
    }
  for (k = 0; k < 100000000; k++);
  return 0;
}


/*
** May be a bug : Modifications done before testing the asid.
*/

int		pm_rsv(t_asid asid, t_paddr *addr, t_psize npages, t_pmflags flags)
{
  unsigned int	i;
  unsigned int	temp;
  unsigned int	free_cpt = 0;
  unsigned int	pass = 0;

  if ((flags & PM_FLAG_SPECIFIC) ==  PM_FLAG_SPECIFIC)
    {
      // PM FLAGS SPECIFIC
      temp = (unsigned int)(*addr) >> 12;
      if (PM_POS(temp) == 0)
	{
	  // The position asked isn't at the start of a chunk.
	  temp--;
	  while (PM_POS(temp) == 0)
	    temp--;
	  i = PM_POS(temp);
	  if (PM_NBREF(i) == 0)
	    {
	      temp = (unsigned int)(*addr) >> 12;
	      PM_SETPOS(i, temp);
	      PM_SETREF(temp, 0);
	    }
	  else
	    return -1;
	}

      if (PM_NBREF(temp) == 0)
 	{
	  PM_SETRSV(temp);
	  if (PM_POS(temp) == 0)
	    PM_SETPOS((temp + npages - 1), PM_POS(temp));
	  PM_SETPOS(temp, (temp + npages - 1));
	  if (PM_POS(temp) < _begin_search)
	    _begin_search = PM_POS(temp);
	  //	  if ((flags & PM_FLAG_PT) != PM_FLAG_PT)
	    return as_pm_add(asid, *addr, npages);
	    //	  else
	    //	    return 0;
	}
      else
	return -1;
    }

  i = _begin_search;

  // PM FLAGS ANY
  while (i < _pm._nbpages)
    {
      if (PM_NBREF(i) == 0)
	// we may have a good position
	{

	  // optim at first free.
	  if (pass == 0)
	    {
	      pass++;
	      _begin_search = i;
	    }

	  if (PM_POS(i) >= npages + i)
	    // nice position !
	    {
	      //	      if ((flags & PM_FLAG_PT) != PM_FLAG_PT)
		if (as_pm_add(asid, i << 12, npages) < 0)
		  return -1;		// fail if has failed.p
	      *addr = i << 12;
	      return pm_allocpages(i, npages);
	    }
	  else
	    {
	      if (free_cpt == 0)
		_begin_search = i;
	      if ((PM_NBREF(PM_POS(i)) == 0) && (PM_POS(i) != _pm._nbpages))
		{
		  // We concat the chunk's
		  temp = PM_POS(PM_POS(i));
		  PM_SETPOS(PM_POS(i), 0);
		  PM_SETPOS(i, temp);
		}
	      else
		{
		  i = PM_POS(i);
		}
	    }
	}
      else
	// next free pages
	i = PM_POS(i);
    }
  return -1;
}

int pm_allocpages(unsigned int i, t_psize npages)
{
  PM_SETRSV(i);
  if (PM_POS((i + npages)) == 0)
    PM_SETPOS((i + npages), PM_POS(i));
  PM_SETPOS(i, (i + npages));
  return 0;
}


/* FIXME : check optim !!!. At least reset while testing */

int pm_rel(t_asid asid, t_paddr addr, t_psize npages)
{
  unsigned int i = (addr >> 12) & 0x0000ffff;

  if (PM_POS(i) == 0)		// Error : Middle of a block
    {
      printf("PM: Error while pm releasing : middle of a block\n");
      while (1)
	;
      return -1;
    }
  if (PM_NBREF(i) == MEM_RSVED)
    PM_SETREF(i, 0);
  else
    {
      if (i <= _begin_search)
	_begin_search = i;
      if (as_pm_del(asid, i << 12, npages))
	{
	  printf("PM: Error while pm releasing : as pm del failed\n");
	  while (1)
	    ;
	  return -1;
	}
      PM_DELREF(i);		// FIXME Not sure about that.
      return 0;
    }
  if (PM_NBREF(i) == 0)
    {
      if (PM_POS(i) != i + npages)
      	{
      	  printf("PM: Error while releasing : releasing not a full block [%d] instead of [%d]\n", PM_POS(i) - i, npages);
	  while (1)
	    ;
      	  return -2;
      	}
/*       if (PM_NBREF(PM_POS(i)) == 0) */
/* 	{ */
/* 	  PM_SETPOS(i, PM_POS(i + npages)); */
/* 	  PM_SETPOS(i + npages, 0); */
/* 	} */
    }
  if (i <= _begin_search)
    _begin_search = i;
  if (as_pm_del(asid, i << 12, npages))
    {
      printf("PM: Error while pm releasing : as pm del failed\n");
      while (1)
	;
      return -1;
    }
  return 0;
}

int pm_flush(t_asid asid)
{
  t_paddr	addr;
  t_psize	npages;
  int		res = 0;

  while ((res = as_pm_top(asid, &addr, &npages)) == 0)
    {
      pm_rel(asid, addr, npages);
    }
  return (res == -2) ? -1 : 0;
}

int pm_clear(void)
{
  unsigned int i = 0;

  for (i = 0; i < _pm._nbpages; i++)
    _pm._tab[i] = 0;

  _begin_search = 0;
  return 0;
}

/*
** Exported Funtions Used to add or delete ref on memory chunks
** Used by vm_map, vm_unmap, mm_map, mm_unmap
*/
void	pm_addref(t_paddr paddr)
{
  unsigned int i = (paddr >> 12) & 0x0000ffff;

  PM_ADDREF(i);
  if (PM_NBREF(i) == 0)
    PM_ADDREF(i);
}

void	pm_delref(t_paddr paddr)
{
  unsigned int i = (paddr >> 12) & 0x0000ffff;

  PM_DELREF(i);
  if (PM_NBREF(i) == 0)
    PM_SETREF(i, MEM_RSVED);
}
