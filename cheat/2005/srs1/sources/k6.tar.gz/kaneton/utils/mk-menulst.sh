#! /bin/sh

MENULST=grub/menu.lst
USBMENULST=grub/usb/menu.lst

{
  echo "timeout 0"
  echo
  echo "title=Kaneton"
  echo "kernel (fd0)/bootloader.elf"
  echo "module (fd0)/kaneton.elf"
  echo "module (fd0)/kaneton.conf"

  for module in `ls modules`; do
    echo "module (fd0)/$module"
  done

} > $MENULST

sed s/\(fd0\)/\(hd0,0\)/g < $MENULST > $USBMENULST
