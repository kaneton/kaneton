#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
##
## gen-changelog.py for kaneton in ~/work/kaneton
##
## Made by Matthieu Avrillon
## Login   <avrill_m@epita.fr>
##
## $Id: gen-changelog.py 136 2005-03-20 07:18:41Z matthieu $
##
## Based on:
## http://www.gnuenterprise.org/cgi-bin/viewcvs.cgi/*checkout*/gnue/trunk/gnue-common/utils/svn2cl
## Revision 5228 (Fri Mar 5 14:39:58 2004 UTC)
##

"""
Script that generates ChangeLog file, customized to fit dromadaire's needs.

Syntax:
  gen-changelog.py

Output is written to file "ChangeLog".
"""
SVNCMD="svn log -v --xml"

import xml.parsers.expat
import tempfile, os, sys, string, re

hackers = { "ski" : ("Adnan A�ta", "aita_a@srs.epita.fr"),
            "matthieu" : ("Matthieu Avrillon", "avrill_m@srs.epita.fr"),
	    "obert" : ("Olivier Bert", "bert_o@srs.epita.fr"),
	    "youb" : ("Hubert Chatillon", "chatil_h@srs.epita.fr"),
	    "root" : ("Hubert Chatillon", "chatil_h@srs.epita.fr"),
	    "pifi" : ("Pierre-Fran�ois Hugues", "hugues_p@srs.epita.fr") }

class Parser:
  def __init__(self, input, output):

    self.out = output
    self.package = os.path.basename (os.getcwd ())

    p = xml.parsers.expat.ParserCreate()

    p.StartElementHandler = self.start_element
    p.EndElementHandler = self.end_element
    p.CharacterDataHandler = self.char_data
    p.ParseFile(input)

    self.paths = []

  # 3 handler functions
  def start_element(self, name, attrs):
    self.text = ""
    if name == "paths":
      self.paths = []

  def end_element(self, name):
    if name == "logentry":
      self.out.write("\n")
    elif name == "author":
      self.author = self.text
      if hackers.has_key(self.author):
	hacker = hackers[self.author]
	self.author = hacker[0] + "  <" + hacker[1] + ">"
      else:
        print "Warning: no full name found for", self.author
    elif name == "path":
      p = string.split (self.text, '/', 2)
      if len (p) == 3:
        r = re.compile("^k\d$")
	if r.match(p [1]):
          self.paths.append(p [2])
    elif name == "msg":
      self.out.write("%s  %s\n\n\t" % (self.date, self.author))
      self.text = self.text.replace("$Rev$", "$Rev\$").replace("$Date$", "$Date\$");
      if len(self.paths) > 0:
        self.out.write(linewrap("* %s: %s" % (string.join(self.paths,', '), self.text)))
      else:
        self.out.write(linewrap("* " + self.text));
    elif name == "date":
      self.date = self.text[:10]

  def char_data(self, data):
    self.text += data.encode('ascii',"replace")


def linewrap(message,maxWidth=70,indent = "\t"):

  text = ""

  temptext = string.strip(str(message))
  buff = string.split(temptext.replace('\n\n','\r').replace('\n',' '),'\r')
  first = 1

  for strings in buff:
    while len(strings) > maxWidth:
      index = 0

      for sep in [' ',',',':','.',';']:
        ind = string.rfind(strings,sep,0,maxWidth-1)+1
        if ind > index: index = ind

      if index > maxWidth or index==0:
        index = maxWidth-1

      line = strings[:index].strip()
      if not first:
        text += indent
      text += "%s\n" % line
      strings = strings[index:].strip()

      first = 0
    line = strings.strip()
    if not first:
      text += indent
    text += "%s\n" % line
    first = 0

  return text

if __name__ == '__main__':
  filename = tempfile.mktemp('xml')
  if os.system(SVNCMD + '> %s' % filename):
    print "Unable to retrieve svn log"
    sys.exit(1)

  inp = open(filename)
  out = open("ChangeLog", 'w')

  try:
    Parser(inp, out)
  except:
    try:
      inp.close()
      os.unlink(filename)
      out.close()
    except:
      pass
    raise

  # Clean up input/output files
  inp.close()
  os.unlink(filename)
  out.close()
