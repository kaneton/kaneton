#!/bin/sh

DISK=sdb
PART="${DISK}1"
GRUB_STAGES_DIR=/boot/grub
MNTPOINT=/mnt/usbkey

DISK_DEV="/dev/$DISK"
PART_DEV="/dev/$PART"

dmesg | grep "^Attached scsi removable disk $DISK"
if [ $? -ne 0 ]; then
  echo "**********************************************"
  echo "*                                            *"
  echo "* not sure if $DISK_DEV is a removable device *"
  echo "*       stopping as a security measure       *"
  echo "*                                            *"
  echo "**********************************************"
  exit 1
fi

dd if=/dev/zero of=$DISK_DEV bs=512 count=1
echo ',,b,*' | sfdisk $DISK_DEV
install-mbr $DISK_DEV --force
mkdosfs $PART_DEV
mount $PART_DEV
mkdir -p $MNTPOINT/boot/grub
cp bootloader.elf kaneton.elf kaneton.conf modules/* $MNTPOINT
cp grub/usb/menu.lst $GRUB_STAGES_DIR/stage1 $GRUB_STAGES_DIR/stage2 $MNTPOINT/boot/grub
grub --no-floppy --batch < grub/usb/grub-install &>/dev/null
umount $PART_DEV
sync
